#!/bin/sh
javac -classpath .:../../../lib/sftp.jar -d . FtpDownloadDirExample.java
java -cp .:../../../lib/sftp.jar FtpDownloadDirExample
