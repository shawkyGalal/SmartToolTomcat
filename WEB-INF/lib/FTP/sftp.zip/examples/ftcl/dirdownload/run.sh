#!/bin/sh
java -jar ../../../lib/sftp.jar -f dirdownload.txt
