#!/bin/sh
java -jar ../../../lib/sftp.jar -f commandlinevar.txt -filter '*.gif'
