#!/bin/sh
javac -classpath .:../../../lib/sftp.jar -d . SFtpDownloadDirExample.java
java -cp .:../../../lib/sftp.jar SFtpDownloadDirExample
