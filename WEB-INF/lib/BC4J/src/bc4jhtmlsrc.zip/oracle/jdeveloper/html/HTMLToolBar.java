/*
 * @(#)HTMLToolBar.java
 *
 * Copyright 1999-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jdeveloper.html;

import java.io.PrintWriter;

/**
 * A Web Bean that provides methods to dynamically generate an HTML toolbar.
 *
 * @version PUBLIC
 *
 **/
public class HTMLToolBar extends HTMLElementContainer
{
   {
      setCSSClassName("clsPageToolbar");
   }

   public HTMLToolBar()
   {      
   }
   
   /**
    * Adds a button to the toolbar.
    *
    * @param sImage    the URL of the button's image file (GIF or JPEG)
    * @param sURL      the URL to link to when the button is clicked
    */
   public void addButton(String sImage , String sURL)
   {
      addElement(new HTMLImageURL(sImage, sURL));
   }

   /**
    * Adds a button to the toolbar.
    *
    * @param sImage    the URL of the button's image file (GIF or JPEG)
    * @param sURL      the URL to link to when the button is clicked
    * @param sTitle    the title that appears when the mouse pointer is held
    *                  over the button
    */
   public void addButton(String sImage , String sURL, String sTitle)
   {
      addElement(new HTMLImageURL(sImage, sURL, sTitle));
   }
   
   /**
    * Adds a separator to the toolbar.
    *
    * @param sURL   the URL of the separator image file (GIF or JPEG)
    */
   public void addSeparator(String sURL)
   {
      addElement(new HTMLImageURL(sURL, null, null));      
   }
   
   /**
    * Adds a disabled button to the toolbar.
    *
    * @param sURL - the URL of the disabled button's image file (GIF or JPEG)
    */
   public void addDisabledButton(String sURL)
   {
      addElement(new HTMLImageURL(sURL, null, null));      
   }

   /**
    * Adds a disabled button to the toolbar.
    *
    * @param sURL     the URL of the disabled button's image file (GIF or JPEG)
    * @param sTitle   the title that appears when the mouse pointer is held
    *                 over the button
    */
   public void addDisabledButton(String sURL, String sTitle)
   {
      addElement(new HTMLImageURL(sURL, null, sTitle));      
   }
   
   public void renderContainerHeader(PrintWriter out)
   {
      // generate form header , toolbar buttons, ...
      out.println("<TABLE BORDER=\"0\" CELLPADDING=\"2\" CELLLSPACING=\"0\" CLASS=\"" + getCSSClassName() + "\"><TR><TD>");
   }
   
   protected void renderContainerFooter(PrintWriter out)
   {
      out.println("</TD></TR></TABLE>");
   }

   public void render(PrintWriter out) throws Exception
   {
      renderContainerHeader(out);
      
      // this will render the buttons added by a user
      int nSize = Elements.size();
      
      for(int i = 0 ; i < nSize ; i++)
      {
		 out.print("<TD>");  
         elementAt(i).render(out);
		 out.print("</TD>");  		 
      }

      renderContainerFooter(out);
   }

}
