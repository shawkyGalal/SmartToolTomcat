/*
 * @(#)HTMLScript.java
 *
 * Copyright 1999-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jdeveloper.html;

import java.io.PrintWriter;

/**
 *
 *	Represents an HTML script block. You add HTMLScriptFunction function to the block. It will then
 * iterate over all the functions on order to create the full script.
 *
 * @version PUBLIC
 *
 **/
public class HTMLScript extends DHTMLElementContainer
{
   protected   String version = "JavaScript1.2";

   public HTMLScript()
   {
   }

   public void setVersion(String version)
   {
      this.version = version;
   }
   
   /**
   *	@param scriptFunction The script function to be added to the script.
   */
   public void addFunction(HTMLScriptFunction scriptFunction)
   {
      addElement(scriptFunction);
   }

   protected void renderContainerHeader(PrintWriter out)
   {
      out.println("<SCRIPT LANGUAGE=\"" + version + "\">");
      out.println("<!-- Hide from old browsers");      
   }
   
   protected void renderContainerFooter(PrintWriter out)
   {
      out.println("// end of script -->");            
      out.println("</SCRIPT>");      
   }
}