/*
 * @(#)DHTMLToolBar.java
 *
 * Copyright 2000-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jdeveloper.html;

import java.io.PrintWriter;
import oracle.jbo.html.databeans.ToolBarButton;

/**
 *
 *
 * @version PUBLIC
 */
public class DHTMLToolBar extends HTMLScript
{
   protected String name;
   protected boolean useModalPage;

   public DHTMLToolBar()
   {
      setVersion("javascript");
   }
   
   public DHTMLToolBar(String name)
   {
      this();
      setName(name);
   }
   
   public void setName(String name)
   {
      DHTMLElement.CheckValidName(name);
      this.name = name;
   }
   
   public String getName()
   {
      return name;
   }
   
   public void addPreDefinedButton(String buttonName, String sURL, boolean isEnabled, String sHelptext)
   {
      StringBuffer output = new StringBuffer();
      
      output.append(name);
      output.append(".addButton(\"");
      output.append(buttonName);
      output.append("\",\"");

      if (sURL != null)
      {
         int i = sURL.indexOf("javascript:");
         if (i == 0)
         {
            if (!useModalPage && sURL.indexOf("openModal") >= 0)
            {
               useModalPage = true;
            }
            output.append("function:");
            output.append(sURL.substring(11));
         }
         else
         {
            output.append("url:");
            output.append(sURL);
         }
         output.append("; ");
      }
         
      if (!isEnabled)
      {
         output.append("enabled:false; ");
      }
      
      output.append("helptext:");
      output.append(sHelptext);
      output.append("\");");
      
      addElement(new HTMLTextElement(output.toString()));
   }

   public void addButton(String sImage, String sRolloverImage, String sDisabledImage, String sURL, boolean isEnabled, String sHelptext, String sFrame)
   {
      StringBuffer output = new StringBuffer();
      
      output.append(name);
      output.append(".addButton(\"custom\",\"default-image:");
      output.append(sImage);
      output.append("; rollover-image:");
      output.append(sRolloverImage);
      output.append("; disabled-image:");
      output.append(sDisabledImage);
      output.append("; ");
      
      if (sURL != null)
      {
         int i = sURL.indexOf("javascript:");
         if (i == 0)
         {
            if (!useModalPage && sURL.indexOf("openModal") >= 0)
            {
               useModalPage = true;
            }
            output.append("function:");
            output.append(sURL.substring(11));
         }
         else
         {
            output.append("url:");
            output.append(sURL);
         }
         output.append("; ");
      }

      if (sFrame == null)
      {
         sFrame = "_self";
      }
      
      // The default for cabo is set to _top. So we need to set the frame only if different from _top.
      if (!sFrame.equals("_top"))
      {
         output.append("frame:");
         output.append(sFrame);         
         output.append("; ");
      }
         
      if (!isEnabled)
      {
         output.append("enabled:false; ");
      }
      
      output.append("helptext:");
      output.append(sHelptext);
      output.append("\");\n");
      
      addElement(new HTMLTextElement(output.toString()));
   }

   public void addButton(ToolBarButton button, String imageDir)
   {
      addButton(imageDir + button.getImageUrl(),
                imageDir + button.getRolloverImageUrl(),
                imageDir + button.getDisabledImageUrl(),
                button.getCommandUrl(),
                button.isEnabled(),
                button.getToolTipText(),
                button.getTargetUrl());
   }

   
   /**
    * Adds a button to the toolbar.
    *
    * @param sImage    the URL of the button's image file (GIF or JPEG)
    * @param sUrl      the URL to link to when the button is clicked
    */
   public void addButton(String sImage, String sURL)
   {
      addButton(sImage, sImage, sImage, sURL, true, null, null);
   }

   /**
    * Adds a button to the toolbar.
    *
    * @param sImage    the URL of the button's image file (GIF or JPEG)
    * @param sUrl      the URL to link to when the button is clicked
    * @param sTitle    the title that appears when the mouse pointer is held
    *                  over the button
    */
   public void addButton(String sImage, String sURL, String sHelptext)
   {
      addButton(sImage, sImage, sImage, sURL, true, sHelptext, null);
   }
   
   /**
    * Adds a disabled button to the toolbar.
    *
    * @param sUrl - the URL of the disabled button's image file (GIF or JPEG)
    */
   public void addDisabledButton(String sImage)
   {
      addButton(sImage, sImage, sImage, null, false, null, null);
   }

   /**
    * Adds a disabled button to the toolbar.
    *
    * @param sUrl     the URL of the disabled button's image file (GIF or JPEG)
    * @param sTitle   the title that appears when the mouse pointer is held
    *                 over the button
    */
   public void addDisabledButton(String sImage, String sHelptext)
   {
      addButton(sImage, sImage, sImage, null, false, sHelptext, null);
   }
   
   public void addDivider()
   {
      addElement(new HTMLTextElement(name + ".addDivider();"));
   }

   public void addSeparator()
   {
	   addDivider();
   }

   public void addTitle(String title)
   {
      addElement(new HTMLTextElement(name + ".addTitle(\"" + title + "\");"));
   }

   protected void renderContainerHeader(PrintWriter out)
   {
      super.renderContainerHeader(out);
      if (useModalPage)
      {
         // if (isInFrame()) needed here
         out.println("window.onFocus=top.checkModal;");
         out.println("window.onUnload=cancelModal();"); 
      }
      
      out.println(name + " = new toolbar();");
   }
   
   protected void renderContainerFooter(PrintWriter out)
   {
      out.println(name + ".render(window);");
      super.renderContainerFooter(out);
   }
}

