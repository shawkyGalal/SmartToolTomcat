/*
 * @(#)DHTMLElementContainer.java
 *
 * Copyright 2000-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jdeveloper.html;

import java.io.PrintWriter;
import java.util.Vector;

/**
 *	This class serves as a container for HTML elements. When it renders, it calls the render(0 method on it's containees.
 *
 * @version PUBLIC
 *
 **/
public class DHTMLElementContainer extends DHTMLElement
{
   protected Vector  Elements = new Vector();

   /**
   *	Adds an element to the collection of elements to be rendered
   */
   public void addElement(DHTMLElement elem)
   {
      Elements.addElement(elem);
   }

   /**
   *	Adds an element to the collection of elements to be rendered
   */
   public void addElement(HTMLElement elem)
   {
      Elements.addElement(elem);
   }
   
   /**
   *	Remove an element to the collection of elements to be rendered
   */
   public void removeElement(HTMLElement elem)
   {
      Elements.removeElement(elem);
   }
   
   /**
   *	Remove an element to the collection of elements to be rendered
   */
   public void removeElement(DHTMLElement elem)
   {
      Elements.removeElement(elem);
   }
   
   /**
   *	Remove an element to the collection of elements to be rendered
   */
   public void removeElementAt(int index)
   {
      Elements.removeElementAt(index);
   }
   
   /**
   *	@return the number of elements that have been added so far.
   */
   public int numberOfElements()
   {
      return Elements.size();
   }

   /**
   *	@return The element at the provided index
   */
   protected HTMLElement elementAt(int nIndex)
   {
      return (HTMLElement)Elements.elementAt(nIndex);
   }

   /**
   *	@return The index of the provided element
   */
   public int indexOf(Object object)
   {
      return Elements.indexOf(object);
   }

   protected void renderContainerHeader(PrintWriter out) throws Exception
   {

   }

   protected void renderContainerFooter(PrintWriter out) throws Exception
   {

   }

   protected void renderElementHeader(PrintWriter out) throws Exception
   {

   }

   protected void renderElementFooter(PrintWriter out) throws Exception
   {

   }

   /**
   *	Renders the container's header, contained objects and footer.
   */
   public void render(PrintWriter out) throws Exception
   {
      renderContainerHeader(out);

      int nSize = Elements.size();

      for(int i = 0 ; i < nSize ; i++)
      {
         renderElementHeader(out);
         elementAt(i).render(out);
         if(nSize > 1 && i != (nSize - 1))
            renderElementFooter(out);
      }

      renderContainerFooter(out);
   }
}