/*
 * @(#)TextArea.java
 *
 * Copyright 1999-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jdeveloper.html;

import oracle.jbo.Row;

/**
 *
 *	Represents a textarea field renderer.
 *
 * @version PUBLIC
 *
 **/
public class TextArea extends TextField
{
   public TextArea()
   {
      setDisplayHeight(10);
      setDisplayWidth(60);
   }

   public String createMultilineTextField()
   {
      if (getDisplayWidth() <= 0)
      {
         setDisplayWidth(20);
      }

      HTMLElementContainer htmlContainer = new HTMLElementContainer();
      
      HTMLTextAreaElement input = new HTMLTextAreaElement();
         
      // TEXTAREA use COLS instead of size
      input.setCols((String) htmlAttributes.remove("SIZE"));
      // Still give precedence to user setting
      input.setHtmlAttributes(htmlAttributes);
      
      htmlContainer.addElement(input);
      
      // also add the hidden field for use in comparisons
      htmlContainer.addElement(getHiddenFieldForValue());

      return htmlContainer.getAsString();
   }

   public String renderToString(Row row)
   {
      setValueFromRow(row);
      
      return createMultilineTextField();
   }
}

