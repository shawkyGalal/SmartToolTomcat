/*
 * @(#)ViewLinkLookupFieldRenderer.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jdeveloper.html;

import oracle.jdeveloper.html.ReadOnlyField;
import oracle.jbo.Row;
import oracle.jbo.AttributeDef;
import oracle.jbo.ViewObject;
import oracle.jbo.ViewLink;

public class ViewLinkLookupFieldRenderer extends ReadOnlyField 
{
  public ViewLinkLookupFieldRenderer()
  {
  }

  public String renderToString(Row row)
  {
    setValueFromRow(row);
    
    AttributeDef aDef = getAttributeDef();
    String       sAttrValue = getValue();

    String sDisplayViewLink = (String)aDef.getProperty("DISPLAY_VIEWLINK"); //NOTRANS
    String sDisplayAttribute = (String)aDef.getProperty("DISPLAY_ATTRIBUTE"); //NOTRANS
    
    if(sAttrValue == null || sDisplayViewLink == null || sDisplayAttribute == null || sDisplayAttribute.equals(""))
      return super.renderToString(row);

    ViewLink link = ds.getApplicationModule().findViewLink(sDisplayViewLink);

    if(link == null)
      throw new RuntimeException("DynamicListFieldRenderer could not find ViewLink Object:" + sDisplayViewLink);

    ViewObject displayView = link.getDestination();
    
    Row lookuprow = displayView.first();

    if(lookuprow != null)
      sAttrValue = (String)lookuprow.getAttribute(sDisplayAttribute);
    
    return sAttrValue;
  }
}