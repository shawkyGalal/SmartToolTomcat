/*
 * @(#)HTMLTableCell.java
 *
 * Copyright 1999-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jdeveloper.html;

import java.io.PrintWriter;

/**
 *
 *	Reperents an HTML TABLE's TD tag.
 *
 * @version PUBLIC
 *
 **/
public class HTMLTableCell extends HTMLElement
{
   protected   HTMLElement Element;
   protected   boolean     hasClass = false;
   
   {
      setCSSClassName("tablecell");
   }

   /**
   *	Constructs an a table cell whose contents are rendered by the provided HTMLElement.
   *
   *	@param elem	Element that will render the HTML TABLE's TD
   */
   public HTMLTableCell(HTMLElement elem)
   {
      Element = elem;
   }

   /**
   *	Constructs an a table cell whose contents are rendered by the provided HTMLElement.
   *
   *	@param elem		Element that will render the HTML TABLE's TD
   *	@param sClass	CSS class name for the table cell
   */
   public HTMLTableCell(HTMLElement elem, String sClass)
   {
      Element = elem;
      hasClass = true;

      setCSSClassName(sClass);
   }
   
   public void render(PrintWriter out) throws Exception
   {
      if(hasClass)
         out.print("<TD CLASS=\"" +getCSSClassName() + "\" >");         
      else
         out.print("<TD>");

      Element.render(out);

      out.println("</TD>");
   }   
}