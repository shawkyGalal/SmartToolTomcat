/*
 * @(#)DHTMLRow.java
 *
 * Copyright 2000-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jdeveloper.html;

import java.io.PrintWriter;

/**
 *
 *
 * @version PUBLIC
 */
public class DHTMLRow extends DHTMLElement
{
   protected String  text;
   protected String  state;
   protected int     childCount;
   protected String  url;
   protected String  nodeImage;
   protected boolean populated;
   
   public DHTMLRow()
   {
   }
   
   public void setText(String text)
   {
      this.text = text;
   }
   
   public String getText()
   {
      return text;
   }

   public void setState(String state)
   {
      this.state = state;
   }
   
   public String getState()
   {
      return state;
   }

   public void setChildCount(int childCount)
   {
      this.childCount = childCount;
   }
   
   public int getChildCount()
   {
      return childCount;
   }

   public void setUrl(String url)
   {
      this.url = url;
   }
   
   public String getUrl()
   {
      return url;
   }

   public void setNodeImage(String url)
   {
      this.nodeImage = url;
   }
   
   public String getNodeImage()
   {
      return nodeImage;
   }
   
   public void setPopulated(boolean populated)
   {
      this.populated = populated;
   }
   
   public boolean getPopulated()
   {
      return populated;
   }
   
   public void render(PrintWriter out) throws Exception
   {
      out.print("new row(\"text:" + ((text == null) ? "" : text));
      
      if (state != null && state.length() > 0)
      {
         out.print("; state:" + state);
      }
   
      if (childCount > 0)
      {
         out.print("; childcount:" + Integer.toString(childCount));
      }

      if (url != null && url.length() > 0)
      {
         out.print("; url:" + url);
      }

      if (nodeImage != null && nodeImage.length() > 0)
      {
         out.print("; nodeimage:" + nodeImage);
      }
      
      if (populated)
      {
         out.print("; populated:true"); // default is false
      }

      out.print("\")");
   }
}

