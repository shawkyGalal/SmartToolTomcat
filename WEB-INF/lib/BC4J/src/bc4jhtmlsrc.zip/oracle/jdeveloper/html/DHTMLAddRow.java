/*
 * @(#)DHTMLAddRow.java
 *
 * Copyright 2000-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jdeveloper.html;

import java.io.PrintWriter;

/**
 *
 *
 * @version PUBLIC
 */
public class DHTMLAddRow extends DHTMLElement
{
   protected String dataName;
   protected DHTMLElement row;
   
   public DHTMLAddRow(String dataName, DHTMLElement row)
   {
      setDataName(dataName);
      setRow(row);
   }
   
   public void setDataName(String dataName)
   {
      DHTMLElement.CheckValidName(dataName);
      this.dataName = dataName;
   }
   
   public String getDataName()
   {
      return dataName;
   }

   public void setRow(DHTMLElement row)
   {
      this.row = row;
   }
   
   public DHTMLElement getrow()
   {
      return row;
   }

   
   public void render(PrintWriter out) throws Exception
   {
      out.print(dataName + ".addRow(");
      row.render(out);
      out.println(");");
   }
}

