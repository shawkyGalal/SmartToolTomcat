/*
 * @(#)HTMLMenu.java
 *
 * Copyright 1999-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jdeveloper.html;

import java.io.PrintWriter;

/**
 *
 *	Reprents a collection of text URLs. You can add as many options as you like in order to
 * populate this menu. When it renders, all the menu options show up in a comma delimited fasshion.
 * @version PUBLIC
 *
 **/
public class HTMLMenu extends HTMLElementContainer
{
   /**
   *	@param sText	Menu item text.
   *	@param URL		Target URL for this hyperlink.
   */
   public void addMenuOption(String sText , String  URL)
   {
      addElement(new HTMLTextURL(sText , URL));
   }

   protected void renderElementFooter(PrintWriter out)
   {
      out.print(",");
   }
   
}