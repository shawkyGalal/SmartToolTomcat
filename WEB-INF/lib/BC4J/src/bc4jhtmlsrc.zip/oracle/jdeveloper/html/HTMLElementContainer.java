/*
 * @(#)HTMLElementContainer.java
 *
 * Copyright 1999-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jdeveloper.html;

import java.io.PrintWriter;
import java.util.Vector;

/**
 *	This class serves as a container for HTML elements. When it renders,
 * it calls the {@link #render(PrintWriter)} method on its containees.
 *
 * @version PUBLIC
 *
 **/
public class HTMLElementContainer extends HTMLElement
{
   protected Vector  Elements = new Vector();

   /**
   *	Adds an element to the collection of elements to be rendered
   */
   public void addElement(HTMLElement elem)
   {
      Elements.addElement(elem);
   }

   /**
   *	@return the number of elements that have been added so far.
   */
   protected int numberOfElements()
   {
      return Elements.size();
   }

   /**
   *	@return The element at the provided index
   */
   protected HTMLElement elementAt(int nIndex)
   {
      return (HTMLElement) Elements.elementAt(nIndex);
   }

   /**
    * Add a Header control the level parameter specifies H1, H2 up to H6.
    */

   public void addHeader(int nLevel , String sHeader)
   {
      if(nLevel > 0 && nLevel < 7)
      {
         addElement(new HTMLTextElement("<H" + nLevel + ">" + sHeader + "</H" + nLevel + ">"));
      }
   }

   /**
    *  Adds an HTML form to the HTML document.
    *
    *    The HTML form is populated via the HTMLForm interfaces. Once you
    * have populated the form, yoou may add it the the HTMLDocument.
    */
   public void addForm(HTMLForm aForm)
   {
      addElement(aForm);
   }

   /**
    *    Adds an image to the document.
    */
   public void addImage(String sName)
   {
      addElement(new HTMLTextElement("<IMG SRC=\"" + sName + "\" </IMG>"));
   }

   /**
    *    Adds an image to the document.
    */
   public void addImageClass(String sName, String sClass)
   {
      HTMLTextElement img = new HTMLTextElement("<IMG CLASS=" + sClass + " SRC=\"" + sName + "\" </IMG>");

      addElement(img);
   }

   public void addToolBar(HTMLToolBar aBar)
   {
      addElement(aBar);
   }

   /**
    *    Adds an image URL to the document.
    */
   public void addImageURL(HTMLImageURL aURL)
   {
      addElement(aURL);
   }

   /**
    *    Adds a text URL to the document.
    */
   public void addTextURL(HTMLTextURL aURL)
   {
      addElement(aURL);
   }

   /**
    *    Adds an HTML table to the document.
    */
   public void addTable(HTMLTable aTable)
   {
      addElement(aTable);
   }


   /**
    *  Starts the HTML document centered mode.
    *
    *  All objects added to the document when it's in centered mode will be centered in
    * the rendered page. If you call StartCenter() you must remember to call EndCenter().
    */
   public void startCenter()
   {
      addElement(new HTMLTextElement("<CENTER>"));
   }

   /**
    *  Stops the HTML document's centered mode.
    */
   public void endCenter()
   {
      addElement(new HTMLTextElement("</CENTER>"));
   }

   /**
    *    Causes nTimes lines to be skipped.
    */
   public void skipLine(int nTimes)
   {
      for(int i = 0; i < nTimes ; i++)
         addElement(new HTMLTextElement("<BR>"));
   }

   protected void renderContainerHeader(PrintWriter out) throws Exception
   {

   }

   protected void renderContainerFooter(PrintWriter out) throws Exception
   {

   }

   protected void renderElementHeader(PrintWriter out) throws Exception
   {

   }

   protected void renderElementFooter(PrintWriter out) throws Exception
   {

   }

   /**
   *	Renders the container's header, contained objects and footer.
   */
   public void render(PrintWriter out) throws Exception
   {
      renderContainerHeader(out);

      int nSize = Elements.size();

      for(int i = 0 ; i < nSize ; i++)
      {
         renderElementHeader(out);
         elementAt(i).render(out);
         if(nSize > 1 && i != (nSize - 1))
            renderElementFooter(out);
      }

      renderContainerFooter(out);
   }
}