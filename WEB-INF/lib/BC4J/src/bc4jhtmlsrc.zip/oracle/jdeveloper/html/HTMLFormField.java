/*
 * @(#)HTMLFormField.java
 *
 * Copyright 1999-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jdeveloper.html;

import java.io.PrintWriter;

/**
 *
 * This represents a FORM's field. You can construct variations on this object by passing
 * different HTMLElement classes for the label and the element. The label will show up to the left of
 * the element when rendered inside the HTML FORM.
 *
 * @version PUBLIC
 *
 **/
public class HTMLFormField extends HTMLTableCell
{
   protected   HTMLElement Label;
   protected   boolean     useLabel = true;
   

   /**
   *	Constructor providing a label and an element. The label will be used.
   */
   public HTMLFormField(HTMLElement Label , HTMLElement Element)
   {
      super(Element);
      this.Label =  Label;
      this.Element = Element;
      this.setCSSClassName("vrFormLabel");
   }


   /**
   *	Constructor providing a label, element and a boolean that controls wether to use the label or not.
   */
   public HTMLFormField(HTMLElement Label , HTMLElement Element, boolean     useLabel)
   {
      super(Element);
      this.Label =  Label;
      this.Element = Element;
      this.useLabel = useLabel;
      this.setCSSClassName("vrFormLabel");
   }
   
   public void render(PrintWriter out) throws Exception
   {

      if(useLabel && Label != null)
      {
         out.println("<TD CLASS=\"" + getCSSClassName() + "\" >");
         Label.render(out);
         out.println("</TD>");
      }

      if(useLabel && Label == null)
      {
         out.println("<TD CLASS=\"vrFormLabel\" >&nbsp;</TD>");
      }
      
      super.render(out);

   }
         
}