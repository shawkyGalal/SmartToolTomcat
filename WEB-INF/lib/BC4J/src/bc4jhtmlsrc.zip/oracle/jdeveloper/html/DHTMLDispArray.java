/*
 * @(#)DHTMLDispArray.java
 *
 * Copyright 2000-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jdeveloper.html;

import java.io.PrintWriter;

/**
 *
 *
 * @version PUBLIC
 */
public class DHTMLDispArray extends HTMLScript
{
   protected String name;
   
   public DHTMLDispArray()
   {
      setVersion("javascript");
   }
   
   public DHTMLDispArray(String name)
   {
      this();
      setName(name);
   }
   
   public void setName(String name)
   {
      DHTMLElement.CheckValidName(name);
      this.name = name;
   }
   
   public String getName()
   {
      return name;
   }
   
   public void addRow(DHTMLData[] dataOnly)
   {
      DHTMLArray array = new DHTMLArray();

      for (int i = 0; i < dataOnly.length; i++)
      {
         array.addElement(dataOnly[i]);
      }
      
      addRow(array);
   }

   public void addRow(DHTMLArray array)
   {
      addElement((DHTMLElement) new DHTMLAddRow(name, array));
   }

   protected void renderContainerHeader(PrintWriter out)
   {
      super.renderContainerHeader(out);
      out.println(name + " = new dispArray();");
   }
   
   protected void renderContainerFooter(PrintWriter out)
   {
      super.renderContainerFooter(out);
   }

}

