/*
 * @(#)HTMLDiv.java
 *
 * Copyright 1999-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jdeveloper.html;

import java.io.PrintWriter;

/**
 *
 *	This class represents and HTML DIV element.
 *
 * @version PUBLIC
 */
public class HTMLDiv extends HTMLElementContainer
{
   protected   String theID = null;
   protected   String theClickHandler = null;
   
   public HTMLDiv()
   {
      setCSSClassName("csDiv");
      theID = "divId";
   }
   
   /**
   *	@param sClass	the CSS class name for this DIV
   *	@param sID		the ID of this DIV
   */
   public HTMLDiv(String sClass , String sID)
   {
      setCSSClassName(sClass);
      theID = sID;
   }

   /**
   *	Sets the name of the JavaScript function that will be called when the DIV receives a mouse click.
   */
   public void setClickHandler(String sClickHandler)
   {
      theClickHandler = sClickHandler;
   }

   /**
   *	Inserts a line break BR tag nTimes.
   *
   *  @param nTimes Number of times to insert  aline break
   */
   public void skipLine(int nTimes)
   {
      for(int i = 0; i < nTimes ; i++)
         addElement(new HTMLTextElement("<BR>"));            
   }
   
   protected void renderContainerHeader(PrintWriter out)
   {
      if(theClickHandler == null)
         out.println("\n<DIV CLASS=\"" + getCSSClassName() + "\" ID=\"" + theID +"\">");
      else
         out.println("\n<DIV CLASS=\"" + getCSSClassName() + "\" ID=\"" + theID +"\" ONCLICK=\"" + theClickHandler + "\">");
   }
   
   protected void renderContainerFooter(PrintWriter out)
   {
      out.println("</DIV>\n");
   }

}

