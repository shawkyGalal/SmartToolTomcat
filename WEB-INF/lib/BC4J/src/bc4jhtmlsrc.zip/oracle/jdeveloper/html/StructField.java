/*
 * @(#)StructField.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jdeveloper.html;

import javax.servlet.jsp.PageContext;
import oracle.jbo.AttributeDef;
import oracle.jbo.JboException;
import oracle.jbo.Row;
import oracle.jbo.common.JBOClass;
import oracle.jbo.html.HtmlServices;

public class StructField extends HTMLFieldRendererImpl 
{
   protected HTMLFieldRenderer getEditFieldRenderer(PageContext page, AttributeDef attrDef)
   {
      HTMLFieldRenderer rField = null;
      
      String sClassRenderer = ds.getFieldRendererClassName(page, page.getSession(), attrDef, HtmlServices.EDIT_RENDERER_KEY);
      
      // Do not recurse in Struct or Array yet
      if ("oracle.jdeveloper.html.StructField".equals(sClassRenderer) ||
          "oracle.jdeveloper.html.ArrayField".equals(sClassRenderer))
      {
         sClassRenderer = "oracle.jdeveloper.html.ReadOnlyField";
      }

      if (sClassRenderer == null)
      {
         sClassRenderer = ds.getDefaultEditRendererClassName(attrDef);
      }
      
      try
      {
         rField = (HTMLFieldRenderer) JBOClass.forName(sClassRenderer).newInstance();
      }
      catch (Exception ex)
      {
         throw new JboException(ex.getMessage());
      }

      rField.setDatasource(ds);
      rField.setAttributeDef(attrDef);

      return rField;
   }

   public String renderToString(Row row)
   {
      HTMLElementContainer htmlContainer = new HTMLElementContainer();

      // For this release we are only dealing we one level of subtype.
      // This method will eventually recurse in the all the subtypes
      try
      {
         oracle.jbo.domain.Struct struct = (oracle.jbo.domain.Struct) row.getAttribute(getAttributeDef().getIndex());
      
         // If we don't have a struct yet, create a new one since we need to give the
         // ability to the user to create one
         if (struct == null)
         {
            struct = (oracle.jbo.domain.Struct)getAttributeDef().getJavaType().newInstance();
         }

         // Retrieve the definitons of subtype.
         AttributeDef[] aDef = struct.getStructureDef().getAttributeDefs();     

         for (int i = 0; i < aDef.length; i++)
         {
            // Get the field renderer associated with the current subType.
            HTMLFieldRenderer fldRnd = getEditFieldRenderer(page, aDef[i]);

            // Format the name of the request parameter
            String sName = HtmlServices.getStructAttributeName(getAttributeDef(), aDef[i]);
            
            htmlContainer.addElement(new HTMLTextElement(aDef[i].getName() + " "));

            // Set the field renderer with proper values and let it do its thing.
            fldRnd.setFieldName(sName);
            Object value = struct.getAttribute(i);
            String strValue;

            if (value == null)
            {
               strValue = "";
            }
            else
            {
               strValue = HTMLElement.quote(value.toString());
            }

            fldRnd.setValue(strValue);

            htmlContainer.addElement(new HTMLTextElement(fldRnd.renderToString(row)));
            htmlContainer.skipLine(1);
         }
      }
      catch (Exception e)
      {
         throw new JboException(e.getMessage());
      }

      return htmlContainer.getAsString();
   }
  
}