/*
 * @(#)HTMLImageURL.java
 *
 * Copyright 1999-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jdeveloper.html;

import java.io.PrintWriter;

/**
 *	This class represents an HTML image URL. The image URL presents an image that invokes a
 * URL when it's clicked. You may also provide a JavaScript click handler to respond when the image gets
 * a mouse click.
 *
 * @version PUBLIC
 *
 **/
public class HTMLImageURL extends HTMLElement
{
   protected   String ImageFile;
   protected   String URL;
   protected   String title = null;
   protected   String      Target = null;   
   protected   String      clickHandler = null;
   protected   String      theName = "imEx";
   
   {
      setCSSClassName("vrImages");
   }
   
   /**
   *	@param ImageFile	URL that points to the image file
   *	@param URL			URL to be invoked when user clicks on image
   */
   public HTMLImageURL(String ImageFile , String URL)
   {
      this.ImageFile = ImageFile;
      this.URL = URL;
   }

   /**
   *	@param ImageFile	URL that points to the image file
   *	@param URL			URL to be invoked when user clicks on image
   *	@sTitle				The alternate text displayed if image is not located.
   */   
   public HTMLImageURL(String ImageFile , String URL, String sTitle)
   {
      this.ImageFile = ImageFile;
      this.URL = URL;
      this.title = sTitle;      
   }
   
   /**
   *	Sets the image objects name on the HTML page.
   */
   public void setName(String name)
   {
      theName  = name;
   }

   /**
   *	Sets the target window for the URL.
   */
   public void setTarget(String target)
   {
      Target = target;
   }

   /**
   *	Sets the image's title or alternate text.
   */
   public void setTitle(String sTitle)
   {
      title = sTitle;
   }

   /**
   *	Sets the JavaScript code to be invoked when the user clicks the left mouse button on the image.
   */
   public void setClickHandler(String handler)
   {
      clickHandler = handler;
   }
   
   public void render(PrintWriter out) throws Exception
   {
      String sText = "";

      if(URL != null)
      {
         sText = "<A HREF=\"" + URL + "\"";

         if(Target != null)
            sText = sText + " TARGET=\"" + Target + "\"";
     
         if(clickHandler != null)
            sText = sText + " ONCLICK=\"" + clickHandler +"\"";

         sText = sText + ">";
      }

      sText = sText + "<img BORDER=\"0\" CLASS=\"" + getCSSClassName() + "\" ID=\"" + getCSSClassName() + "\" NAME=\"" + theName + "\" src=\"" + ImageFile + "\"";
      
      if(title != null)
      {
         sText = sText + " title = \"" + title + "\"";
    		 sText = sText + " alt = \"" + title + "\"";
      }

      sText = sText + " />";

      if(URL != null)
      {
         sText = sText + "</A>";         
      }

      out.print(sText);
   }
}