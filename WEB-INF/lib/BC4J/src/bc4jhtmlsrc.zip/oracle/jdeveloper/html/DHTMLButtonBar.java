/*
 * @(#)DHTMLButtonBar.java
 *
 * Copyright 2000-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jdeveloper.html;

import java.io.PrintWriter;
import java.util.Vector;

/**
 *
 *
 * @version PUBLIC
 */
public class DHTMLButtonBar extends HTMLScript
{
   protected Vector buttonNames = new Vector();
   protected String name;
   
   public DHTMLButtonBar()
   {
      setVersion("javascript");
   }

   public DHTMLButtonBar(String name)
   {
      this();
      setName(name);
   }
   
   public void setName(String name)
   {
      DHTMLElement.CheckValidName(name);
      this.name = name;
   }
   
   public String getName()
   {
      return name;
   }
   
   public void addElement(HTMLElement elem, String name)
   {
      super.addElement(elem);
      buttonNames.addElement(name);
   }
   
   public void addButton(DHTMLButtonElement button)
   {
      super.addElement(button);
      buttonNames.addElement(button.getName());
   }
   
   protected void renderContainerFooter(PrintWriter out)
   {
      int size = buttonNames.size();
      for (int i=0; i < size; i++)
      {
         String shp;
         
         if (i == 0)
         {
            shp = DHTMLButtonElement.shapeRS;
         }
         else if (i < size - 1)
         {
            shp = DHTMLButtonElement.shapeSS;
         }
         else
         {
            shp = DHTMLButtonElement.shapeSR;
         }
         
         // Modify button shape depending on their position in the bar.
         out.print(buttonNames.elementAt(i));
         out.print(".setButtonProperty(\"shape:");
         out.print(shp);
         out.println("\");");
      }
      
      out.print(name);
      out.print("=new buttonRow(");
      for (int i=0; i < size; i++)
      {
         out.print(buttonNames.elementAt(i));

         if (i < size - 1)
         {
            out.print(",");
         }
      }

      out.println(");");
      out.print(name);
      out.println(".render(window);");
      super.renderContainerFooter(out);
   }

}

