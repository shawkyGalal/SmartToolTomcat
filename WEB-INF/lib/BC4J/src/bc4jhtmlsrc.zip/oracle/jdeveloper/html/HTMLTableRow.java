/*
 * @(#)HTMLTableRow.java
 *
 * Copyright 1999-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jdeveloper.html;

import java.io.PrintWriter;

/**
 *
 * Represents an HTML TABLE'S TR tag.
 *
 * @version PUBLIC
 *
 **/
public class HTMLTableRow extends HTMLElementContainer
{
   protected   String align;
   
   {
      setCSSClassName("vrTableRow");
   }
   
   /**
   *	constructs a new table row
   */
    public HTMLTableRow()
	{
		super();
	}

   /**
   *	constructs a new table row
   *
   *	@param align	the new row's aligment
   */	
   public HTMLTableRow(String align)
	{
		super();
      this.align = align;
	}

   /**
   *	Adds a new element to the table row
   *
   *	@param elem		Element that will render it's contents to the table row.
   */
   public void addElement(HTMLElement elem)
   {
      super.addElement(new HTMLTableCell(elem));
   }

   /**
   *	Adds a table cell to the row.
   *
   *	@param	cell Element that will render it's contents to the table row.
   */
   public void addCell(HTMLTableCell cell)
   {
      super.addElement(cell);
   }

   /**
   *	Adds a text cell to the table row.
   *
   *	@param Text	text for new table cell
   */
   public void addTextCell(String Text)
   {
      super.addElement(new HTMLTableCell(new HTMLTextElement(Text)));
   }

   /**
   *	Adds a text cell to the table row.
   *
   *	@param Text			text for new table cell
   *	@param className	CSS class name for new text cell
   */
   public void addTextCell(String Text, String className)
   {
      HTMLTableCell cell = new HTMLTableCell(new HTMLTextElement(Text), className);
      super.addElement(cell);
   }


   /**
   *	Adds a new text cell to the row. The text cell's CSS classname is set to 'vrFormLabel'
   */
   
   public void addFieldLabel(String Text)
   {
      super.addElement(new HTMLTableCell(new HTMLTextElement(Text), "vrFormLabel"));
   }
   
   /**
   *	Adds a formatted text cell to the table row.
   */
   public void addFormattedTextCell(String Text)
   {
      super.addElement(new HTMLTableCell(new HTMLTextElement(Text)));
   }
  
   protected void renderContainerHeader(PrintWriter out)
   {
      out.println("<TR CLASS=\"" + getCSSClassName() + "\"");
	  
      if (align != null)
      {
         out.println(" ALIGN=" + align + " ");
      }
	  
      out.println(">");
   }
   
   protected void renderContainerFooter(PrintWriter out)
   {
      out.println("</TR>");      
   }

}
