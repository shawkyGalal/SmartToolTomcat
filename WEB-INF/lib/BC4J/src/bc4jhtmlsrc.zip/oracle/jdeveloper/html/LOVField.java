/*
 * @(#)LOVField.java
 *
 * Copyright 2000-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jdeveloper.html;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.jsp.PageContext;
import oracle.jbo.Row;

/**
 *
 *	Represents a date field render.
 *
 * @version PUBLIC
 *
 **/
public class LOVField extends TextField implements LOVFieldContext
{
   private static final String COMMA_SEP = "', '";
   protected String viewObjectName;
   protected String displayAttributes;
   protected String dataAttributes;
   protected HttpServletRequest request;
   protected String sLovUrl = "lovcomp.jsp";
   
   public LOVField()
   {
   }

   public void setLovVo(String voName)
   {
      viewObjectName = voName;
   }

   public String getLovVo()
   {
      return viewObjectName;
   }

   public void setDisplayAttributes(String dAttributes)
   {
      displayAttributes = dAttributes;
   }
   
   public String getDisplayAttributes()
   {
      return displayAttributes;
   }
   
   public void setDataAttributes(String dataAttr)
   {
      dataAttributes = dataAttr;
   }
   
   public String getDataAttributes()
   {
      return dataAttributes;
   }

   public void setLovUrl(String url)
   {
      sLovUrl = url;
   }

   public String getLovUrl()
   {
      return sLovUrl;
   }

   public void setHttpServletRequest(HttpServletRequest request)
   {
      this.request = request;
   }
   
   public String createLOVField()
   {
      final HTMLInputElement input = getHTMLInputElement(); // Get default TextField settings
      final DHTMLElementContainer cnt = new DHTMLElementContainer();

      cnt.addElement(input);

      String lovPath = getLovUrl();
      final String contextPath = ((HttpServletRequest) getPageContext().getRequest()).getContextPath();
      if (!lovPath.startsWith(contextPath))
      {
         if (!lovPath.startsWith("/"))
         {
            lovPath = "/" + lovPath;
         }
         
         lovPath = contextPath + lovPath;
      }

      String configName = (String) getPageContext().getAttribute("JBO_AMCONFIGNAME", PageContext.REQUEST_SCOPE);
      String definitionName = (String) getPageContext().getAttribute("JBO_AMDEFINITIONNAME", PageContext.REQUEST_SCOPE);
      
      if (configName == null && definitionName == null)
      {
         definitionName = "[unknown]." + ds.getApplicationId();
      }

      final StringBuffer buf = new StringBuffer();
      buf.append("<a onclick=\"launchLovDef('");
      buf.append(CABO_JSPS);
      buf.append("frameRedirect.jsp?redirect=");
      buf.append(lovPath);
      buf.append(COMMA_SEP);
      buf.append(getFormName());
      buf.append(COMMA_SEP);
      buf.append(getFieldName());
      buf.append(COMMA_SEP);
      if (configName != null)
      {
         buf.append(configName);
      }
      buf.append(COMMA_SEP);
      if (definitionName != null)
      {
         buf.append(definitionName);
      }
      buf.append(COMMA_SEP);
      buf.append(getLovVo());
      buf.append(COMMA_SEP);
      buf.append(getDataAttributes());
      buf.append(COMMA_SEP);
      buf.append(getDisplayAttributes());
      buf.append("'); return false\" href=\"#\"><img src=");
      buf.append(WebBean.defaultImageBase);
      buf.append("/FNDLSTOV.gif align=absmiddle border=0 alt=\"");
      buf.append(Res.getString(Res.LOV_TOOLTIP));
      buf.append("\"></a>");

      cnt.addElement(new HTMLTextElement(buf.toString()));
      // Add original value for comparison on the submit
      cnt.addElement(getHiddenFieldForValue());

      return cnt.getAsString();
   }

   public String renderToString(Row row)
   {
      final StringBuffer sRet = new StringBuffer();
      
      try
      {
         setValueFromRow(row);
         
         if (displayAttributes == null)
         {
            displayAttributes = "";
         }

         // At least one of page or request need to be valid
         sRet.append(initJS(getPageContext(), request, "/webapp/jsLibs/LovField.js"));
         sRet.append(createLOVField());
      }
      catch(Exception ex)
      {
         ex.printStackTrace();
      }

      return sRet.toString();   
   }

}

 