/*
 * @(#)DHTMLTable.java
 *
 * Copyright 2000-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jdeveloper.html;

import java.io.PrintWriter;

/**
 *
 *
 * @version PUBLIC
 */
public class DHTMLTable extends HTMLScript
{
   protected String name;
   protected String refName;
   protected String setting;
   protected String grid;
   protected String width;
   protected String widthPercent;
   protected String dataSource;

   public DHTMLTable()
   {
      setVersion("javascript");
   }

   public DHTMLTable(String name)
   {
      this();
      setName(name);
   }
   
   public void setName(String name)
   {
      DHTMLElement.CheckValidName(name);
      this.name = name;
   }
   
   public String getName()
   {
      return name;
   }
   
   public void setRefName(String refName)
   {
      DHTMLElement.CheckValidName(refName);
      this.refName = refName;
   }
   
   public String getRefName()
   {
      return refName;
   }

   public void setSetting(String setting)
   {
      this.setting = setting;
   }
   
   public String getSetting()
   {
      return setting;
   }

   public void setGrid(String grid)
   {
      // "none", "vertical", "horizontal", "both"
      this.grid = grid;
   }
   
   public String getGrid()
   {
      return grid;
   }

   public void setWidth(String width)
   {
      // Integer pixels
      this.width = width;
   }
   
   public String getWidth()
   {
      return width;
   }

   public void setWidthPercent(String widthPercent)
   {
      this.widthPercent = widthPercent;
   }
   
   public String getWidthPercent()
   {
      return widthPercent;
   }

   public void setDataSource(String dataSource)
   {
      this.dataSource = dataSource;
   }
   
   public String getDataSource()
   {
      return dataSource;
   }
   
   public void createTextCell(String cellName, String style, String wrap, String align)
   {
      StringBuffer output = new StringBuffer();
      boolean needsc = false;
      
      output.append(cellName);
      output.append("= new displayTextCell(\"");
      
      if (style != null && style.length() >0)
      {
         output.append("style:");
         output.append(style);
         needsc = true;
      }
      
      if (wrap != null && wrap.length() >0)
      {
         if (needsc)
         {
            output.append("; ");
         }
         output.append("wrap:");
         output.append(wrap);
         needsc = true;
      }

      if (align != null && align.length() >0)
      {
         if (needsc)
         {
            output.append("; ");
         }
         output.append("align:");
         output.append(align);
         needsc = true;
      }
      
      output.append("\");\n");
      
      addElement(new HTMLTextElement(output.toString()));
   }
   
   public void createLinkCell(String cellName, String style, String wrap, String align, String actionType, String defaultAction, String targetFrame)
   {
      String output = cellName + "= new displayLinkCell(\"";
      boolean needsc = false;
      
      if (style != null && style.length() >0)
      {
         output += "style:" + style;
         needsc = true;
      }
      
      if (wrap != null && wrap.length() >0)
      {
         if (needsc)
         {
            output += "; ";
         }
         output += "wrap:" + wrap;
         needsc = true;
      }

      if (align != null && align.length() >0)
      {
         if (needsc)
         {
            output += "; ";
         }
         output += "align:" + align;
         needsc = true;
      }
      
      if (actionType != null && actionType.length() >0)
      {
         if (needsc)
         {
            output += "; ";
         }
         output += "actiontype:" + actionType;
         needsc = true;
      }
      
      if (defaultAction != null && defaultAction.length() >0)
      {
         if (needsc)
         {
            output += "; ";
         }
         output += "defaultaction:" + defaultAction;
         needsc = true;
      }
      
      if (targetFrame != null && targetFrame.length() >0)
      {
         if (needsc)
         {
            output += "; ";
         }
         output += "targetframe:" + targetFrame;
      }
      
      output += "\");\n";
      
      addElement(new HTMLTextElement(output));
   }
   
   public void createIconCell(String cellName, String style, String wrap, String align, String actionType, String defaultAction, String targetFrame, String iconName, String textPosition) 
   {
      String output = cellName + "= new displayIconCell(\"";
      boolean needsc = false;
      
      if (style != null && style.length() >0)
      {
         output += "style:" + style;
         needsc = true;
      }
      
      if (wrap != null && wrap.length() >0)
      {
         if (needsc)
         {
            output += "; ";
         }
         output += "wrap:" + wrap;
         needsc = true;
      }

      if (align != null && align.length() >0)
      {
         if (needsc)
         {
            output += "; ";
         }
         output += "align:" + align;
         needsc = true;
      }
      
      if (actionType != null && actionType.length() >0)
      {
         if (needsc)
         {
            output += "; ";
         }
         output += "actiontype:" + actionType;
         needsc = true;
      }
      
      if (defaultAction != null && defaultAction.length() >0)
      {
         if (needsc)
         {
            output += "; ";
         }
         output += "defaultaction:" + defaultAction;
         needsc = true;
      }
      
      if (targetFrame != null && targetFrame.length() >0)
      {
         if (needsc)
         {
            output += "; ";
         }
         output += "targetframe:" + targetFrame;
         needsc = true;
      }
      
      if (iconName != null && iconName.length() >0)
      {
         if (needsc)
         {
            output += "; ";
         }
         output += "iconname:" + iconName;
         needsc = true;
      }
      
      if (textPosition != null && textPosition.length() >0)
      {
         if (needsc)
         {
            output += "; ";
         }
         output += "textposition:" + textPosition;
      }
      
      output += "\");\n";
      
      addElement(new HTMLTextElement(output));
   }
   
   public void addColumn(String columnName, String text, String cellObject, String wrap, String align)
   {
      String output = name + ".addColumn(new column(\"";

      if (columnName != null && columnName.length() > 0)
      {
         output += "name:" + columnName + "; ";
      }
      
      output += "text:" + ((text == null) ? "" : text);
      output += "; cellobject:" + cellObject;
      
      if (wrap != null && wrap.length() > 0)
      {
         output += "; wrap:" + wrap;
      }
      
      if (align != null && align.length() > 0)
      {
         output += "; align:" + align;
      }
      
      output += "\"));\n";
      
      addElement(new HTMLTextElement(output));
   }


   protected void renderContainerHeader(PrintWriter out)
   {
      super.renderContainerHeader(out);
      
      out.print(name);
      out.print(" = new table(\"");
      
      String tmpName;
      if (refName != null && refName.length() > 0)
      {
         tmpName = refName;
      }
      else
      {
         tmpName = name;
      }
         
      out.print("name:");
      out.print(tmpName);
      
      if (setting != null && setting.length() > 0)
      {
         out.print("; setting:");
         out.print(setting);
      }
      
      if (grid != null && grid.length() > 0)
      {
         out.print("; grid:");
         out.print(grid);
      }
      
      if (width != null && width.length() > 0)
      {
         out.print("; width:");
         out.print(width);
      }
      
      if (widthPercent != null && widthPercent.length() > 0)
      {
         out.print("; widthpercent:");
         out.print(widthPercent);
      }

      out.println("\");");
   }
   
   protected void renderContainerFooter(PrintWriter out)
   {
      if (dataSource != null && dataSource.length() > 0)
      {
         out.print(name);
         out.print(".setDataSource(");
         out.print(dataSource);
         out.println(");");
      }

      out.print("document.write(");
      out.print(name);
      out.println(".render(\"HTML\"));");
      super.renderContainerFooter(out);
   }

}

