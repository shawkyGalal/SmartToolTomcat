/*
 * @(#)StaticPickListContext.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jdeveloper.html;

public interface StaticPickListContext extends HTMLRenderingContext
{
   void setControlType(String sType);

   void setControlType(int nType);
   
   int getControlType();

   void setDataSource(String[] labels, String[] values);

   void setUseLineBreaks(boolean bUseBreaks);

   boolean getUseLineBreaks();

}
