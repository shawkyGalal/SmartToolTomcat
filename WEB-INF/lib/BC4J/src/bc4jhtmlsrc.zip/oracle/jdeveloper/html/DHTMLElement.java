/*
 * @(#)DHTMLElement.java
 *
 * Copyright 2000-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jdeveloper.html;


/**
 * A class representing the base root class used by all HTML
 * generation classes. Is is never instantiated, it simply
 * provides some common services shared by all derived
 * classes.
 *
 * @version PUBLIC
 *
 */
public abstract class DHTMLElement extends HTMLElement
{
   static public void CheckValidName(String name)
   {
      boolean invalidName = true;
   
      if (name != null)
      {
         name.trim();
         if (name.indexOf(' ') < 0)
         {
            invalidName = false;
         }
      }
   
      if (invalidName)
      {
         String error = Res.format(Res.DHTML_INVALID_NAME_ERROR, name);
         throw new RuntimeException(error);
      }
   }

   static public String filterDataChar(String sValue)
   {
      int idx;

      while ((idx = sValue.indexOf('\n')) >= 0)
      {
         sValue = sValue.substring(0, idx) + "\\n" + sValue.substring(idx + 1);
      }

      int start = 0;
      while ((idx = sValue.indexOf('"', start)) >= 0)
      {
         sValue = sValue.substring(0, idx) + "\\\"" + sValue.substring(idx + 1);
         start = idx + 3;
      }

      return sValue;
   }
}


