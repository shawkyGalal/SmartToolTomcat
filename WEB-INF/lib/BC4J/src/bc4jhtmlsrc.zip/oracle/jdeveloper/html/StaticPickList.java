/*
 * @(#)StaticPickList.java
 *
 * Copyright 1999-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jdeveloper.html;

import java.util.Hashtable;
import java.util.StringTokenizer;
import oracle.jbo.Row;

/**
 * This class represents a Static PickList. It's data is provided by two string arrays, one for the labels and another for
 * the prompts . It supports various renderings:
 * combobox, listbox,radio group and checbox group.
 *
 * @version PUBLIC
 *
 **/
public class StaticPickList extends HTMLFieldRendererImpl implements StaticPickListContext
{
   public static final int TYPE_COMBOBOX = 0;
   public static final int TYPE_LISTBOX = 1;
   public static final int TYPE_CHECKBOX_GROUP = 2;
   public static final int TYPE_RADIO_GROUP = 3;
   
   public boolean bUseLineBreaks = true; 
   protected   int nType = TYPE_COMBOBOX;

   protected   String    sQuery = "";
   protected   Hashtable values = new Hashtable();
   protected   Hashtable allvalues = new Hashtable();
   protected   String[]  aLabels = new String[0];
   protected   String[]  aValues = new String[0];
   protected   ListIterator iter;
   
   
   /**
   *	Constructs object. Default rendering is combo box.
   */
   public StaticPickList()
   {
   }
   
   public void setControlType(String sType)
   {
      if (sType.equalsIgnoreCase("COMBOBOX"))
      {
         nType = TYPE_COMBOBOX;
      }
      else if (sType.equalsIgnoreCase("LISTBOX"))
      {
         nType = TYPE_LISTBOX;
      }
      else if (sType.equalsIgnoreCase("RADIOGROUP"))
      {
         nType = TYPE_RADIO_GROUP;
      }
      else if (sType.equalsIgnoreCase("CHECKBOXGROUP"))
      {
         nType = TYPE_CHECKBOX_GROUP;
      }
   }

   public void setControlType(int nType)
   {
      this.nType = nType;
   }

   public int getControlType()
   {
      return nType;
   }
   
   public void setUseLineBreaks(boolean bUseBreaks)
   {
      this.bUseLineBreaks = bUseBreaks;
   }

   public boolean getUseLineBreaks()
   {
      return bUseLineBreaks;
   }
   
   /**
   *     Configures the source arrays for the prompts and values of the static picklist
   */
   public void setDataSource(String[] labels , String[] values)
   {
      aLabels = labels;
      aValues = values;
   }

   protected void prepareForMultiValueListGeneration()
   {
      String sValue;

      allvalues.clear();
      values.clear();

      for (int i = 0; i < aValues.length; i++)
      {
         allvalues.put(aValues[i], "");
      }

      // split up the field value
      StringTokenizer tokens = new StringTokenizer(this.getValue() , ",");

      while (tokens.hasMoreElements())
      {
         values.put(tokens.nextToken(),"");
      }
   }

   protected HTMLSelect createHTMLSelect(boolean bMultiple)
   {
      HTMLSelect aSelect = new HTMLSelect();
      
      // SELECT use WIDTH instead of SIZE
      aSelect.setWidth((String)htmlAttributes.remove("SIZE"));
      // SELECT use HEIGTH instead of ROWS
      aSelect.setHeight((String)htmlAttributes.remove("ROWS"));
      
      if (bMultiple)
      {
         aSelect.setMultiple();
      }
      
      aSelect.setHtmlAttributes(htmlAttributes);
      
      return aSelect;
   }
   
   protected HTMLElement generateComboBox()
   {
      HTMLSelect aSelect = createHTMLSelect(false);
      
      String sLabel;
      String sValue;
      String sCurrentValue = getValue();
      
      while (iter.hasNext())
      {
         sLabel = iter.getLabel();
         sValue = iter.getValue();

         if (sValue.equals(sCurrentValue))
         {
            aSelect.addSelectedOption(sLabel, sValue);
         }
         else
         {
            aSelect.addOption(sLabel , sValue);
         }

         iter.next();
      }

      return aSelect;
   }

   protected HTMLElement generateListBox()
   {
      // Create the SELECT with multiple true
      HTMLSelect aSelect = createHTMLSelect(true);
      
      prepareForMultiValueListGeneration();
      
      String sLabel;
      String sValue;

      while (iter.hasNext())
      {
         sLabel = iter.getLabel();
         sValue = iter.getValue();

         if (values.get(sValue) != null)
         {
            aSelect.addSelectedOption(sLabel, sValue);
         }
         else
         {
            aSelect.addOption(sLabel , sValue);
         }

         iter.next();
      }
      
      return aSelect;
   }

   protected HTMLElement generateCheckBoxGroup()
   {
      HTMLElementContainer container = new HTMLElementContainer();
      
      prepareForMultiValueListGeneration();

      String sLabel;
      String sValue;

      while (iter.hasNext())
      {
         sLabel = iter.getLabel();
         sValue = iter.getValue();
      
         if (values.get(sValue) != null)
         {
            HTMLInputElement input = new HTMLInputElement();

            input.setType("CHECKBOX");
            input.setChecked(true);
            input.setLabel(sLabel);
            
            input.setHtmlAttributes(htmlAttributes);
            input.setValue(sValue);
            
            container.addElement(input);
            if (bUseLineBreaks)
               container.skipLine(1);
         }
         else
         {
            HTMLInputElement input = new HTMLInputElement();

            input.setType("CHECKBOX");
            input.setChecked(false);
            input.setLabel(sLabel);
            
            input.setHtmlAttributes(htmlAttributes);
            input.setValue(sValue);
            
            container.addElement(input);
            if (bUseLineBreaks)
               container.skipLine(1);
         }

         iter.next();
      }

      return container;
   }

   protected HTMLElement generateRadioGroup()
   {
      HTMLElementContainer container = new HTMLElementContainer();
      
      String sLabel;
      String sValue;
      String sCurrentValue = getValue();

      while (iter.hasNext())
      {
         sLabel = iter.getLabel();
         sValue = iter.getValue();

         if (sValue.equals(sCurrentValue))
         {
            HTMLInputElement input = new HTMLInputElement();

            input.setType("RADIO");
            input.setChecked(true);
            input.setLabel(sLabel);

            input.setHtmlAttributes(htmlAttributes);
            input.setValue(sValue);

            container.addElement(input);
            if (bUseLineBreaks)
               container.skipLine(1);
         }
         else
         {
            HTMLInputElement input = new HTMLInputElement();

            input.setType("RADIO");
            input.setChecked(false);
            input.setLabel(sLabel);
            
            input.setHtmlAttributes(htmlAttributes);
            input.setValue(sValue);
            
            container.addElement(input);
            if (bUseLineBreaks)
               container.skipLine(1);
         }

         iter.next();
      }
      
      return container;
   }

   protected String getRenderedString()
   {
      HTMLElement elem;
      iter = new StaticPickListIterator();

      switch (nType)
      {
         case TYPE_COMBOBOX:
            {
               elem = generateComboBox();
               break;
            }
         case TYPE_LISTBOX:
            {
               elem = generateListBox();
               break;
            }
         case TYPE_CHECKBOX_GROUP:
            {
               elem = generateCheckBoxGroup();
               break;
            }
         case TYPE_RADIO_GROUP:
            {
               elem = generateRadioGroup();
               break;
            }

         default:
            return "";
      }

      return elem.getAsString();
   }

   public String renderToString(Row row)
   {
      setValueFromRow(row);
      return getRenderedString();
   }

   final class StaticPickListIterator implements ListIterator
   {
      private int i;

      StaticPickListIterator()
      {
         i = 0;
      }

      public boolean hasNext()
      {
         return (i < aLabels.length);
      }

      public void next()
      {
         i++;
      }
      
      public String getLabel()
      {
         return aLabels[i];
      }

      public String getValue()
      {
         return aValues[i];
      }
   }
}

