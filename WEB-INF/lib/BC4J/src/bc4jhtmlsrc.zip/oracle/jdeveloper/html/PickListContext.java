/*
 * @(#)PickListContext.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jdeveloper.html;

import oracle.jbo.ApplicationModule;
import oracle.jbo.RowSet;

public interface PickListContext extends HTMLRenderingContext
{
   void setLovVo(String voName);
   
   String getLovVo();
   
   void setDataAttributes(String sDataAttribute);

   String getDataAttributes();

   void setDisplayAttributes(String sDisplayAttribute);

   String getDisplayAttributes();

   void setControlType(String sType);

   void setControlType(int nType);
   
   int getControlType();

   void setUseLineBreaks(boolean bUseBreaks);

   boolean getUseLineBreaks();

   void setAllowNulls(boolean bSet);

   void setDataSourceInfo(RowSet qView);

   void setDataSourceInfo(ApplicationModule appModule, String sQuery);
}
