/*
 * @(#)DHTMLButton.java
 *
 * Copyright 2000-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jdeveloper.html;

import java.io.PrintWriter;

/**
 *
 *
 * @version PUBLIC
 */
public class DHTMLButton extends HTMLScript
{
   protected DHTMLButtonElement button;   // Aggregate DHTMLButtonElement

   public DHTMLButton()
   {
      setVersion("javascript");
      button = new DHTMLButtonElement();
      addElement(button);
   }

   public DHTMLButton(String name)
   {
      this();
      setName(name);
   }
   
   public void setName(String name)
   {
      button.setName(name);
   }
   
   public String getName()
   {
      return button.getName();
   }
   
   public void setShape(String shp)
   {
      button.setShape(shp);
   }
   
   public String getShape()
   {
      return button.getShape();
   }

   public void setText(String txt)
   {
      button.setText(txt);
   }
   
   public String getText()
   {
      return button.getText();
   }

   public void setActionType(String ac)
   {
      button.setActionType(ac);
   }

   public String getActionType()
   {
      return button.getActionType();
   }

   public void setUrl(String url)
   {
      button.setUrl(url);
   }

   public String getUrl()
   {
      return button.getUrl();
   }
   
   public void setTargetFrame(String trgFrm)
   {
      button.setTargetFrame(trgFrm);
   }

   public String getTargetFrame()
   {
      return button.getTargetFrame();
   }

   public void setAction(String act)
   {
      button.setAction(act);
   }

   public String getAction()
   {
      return button.getAction();
   }

   public void setEnabled(boolean enabled)
   {
      button.setEnabled(enabled);
   }

   public boolean getEnabled()
   {
      return button.getEnabled();
   }

   public void setDefaultButton(boolean defButton)
   {
      button.setDefaultButton(defButton);
   }

   public boolean getDefaultButton()
   {
      return button.getDefaultButton();
   }

   public void setGap(String gap)
   {
      button.setGap(gap);
   }

   public String getGap()
   {
      return button.getGap();
   }

   public void setLocatorControl(String locControl)
   {
      button.setLocatorControl(locControl);
   }

   public String getLocatorControl()
   {
      return button.getLocatorControl();
   }

   public void setLocatorObject(String locObject)
   {
      button.setLocatorObject(locObject);
   }

   public String getLocatorObject()
   {
      return button.getLocatorObject();
   }
   
   public void setButton(DHTMLButtonElement button)
   {
      removeElement(this.button);
      this.button = button;
      addElement(button);
   }
   
   protected void renderContainerFooter(PrintWriter out)
   {
      if (button != null)
      {
         out.print(button.getName());
         out.println(".render(window);");
      }
      super.renderContainerFooter(out);
   }
}

