/*
 * @(#)DHTMLButtonElement.java
 *
 * Copyright 2000-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jdeveloper.html;

import java.io.PrintWriter;

/**
 *
 *
 * @version PUBLIC
 */
public class DHTMLButtonElement extends DHTMLElement
{
   public static final String shapeRR     = "RR";
   public static final String shapeRS     = "RS";
   public static final String shapeSS     = "SS";
   public static final String shapeSR     = "SR";
   public static final String atURL       = "url";
   public static final String atFunction  = "function";
   
   protected String  name;
   protected String  shape;
   protected String  text;
   protected String  actionType;
   protected String  url;
   protected String  targetFrame;
   protected String  action;
   protected boolean enabled = true;
   protected boolean defaultButton = false;
   protected String  gap;
   protected String  locatorControl;
   protected String  locatorObject;
   
   public DHTMLButtonElement()
   {
   }
   
   public DHTMLButtonElement(String name)
   {
      setName(name);
   }
   
   public void setName(String name)
   {
      DHTMLElement.CheckValidName(name);
      this.name = name;
   }
   
   public String getName()
   {
      return name;
   }
   
   public void setShape(String shp)
   {
      if (shp == null || shp.length() == 0)
      {
         shp = null;
      }
      else if (shp.equalsIgnoreCase(shapeRR))
      {
         shape = shapeRR;
      }
      else if (shp.equalsIgnoreCase(shapeRS))
      {
         shape = shapeRS;
      }
      else if (shp.equalsIgnoreCase(shapeSS))
      {
         shape = shapeSS;
      }
      else if (shp.equalsIgnoreCase(shapeSR))
      {
         shape = shapeSR;
      }
   }
   
   public String getShape()
   {
      return shape;
   }

   public void setText(String txt)
   {
      text = txt;
   }

   public String getText()
   {
      return text;
   }

   public void setActionType(String ac)
   {
      if (ac.equalsIgnoreCase(atURL))
      {
         actionType = atURL;
      }
      else if (ac.equalsIgnoreCase(atFunction))
      {
         actionType = atFunction;
      }
   }

   public String getActionType()
   {
      return actionType;
   }

   public void setUrl(String url)
   {
      this.url = url;
   }

   public String getUrl()
   {
      return url;
   }
   
   public void setTargetFrame(String trgFrm)
   {
      this.targetFrame = trgFrm;
   }

   public String getTargetFrame()
   {
      return targetFrame;
   }

   public void setAction(String act)
   {
      this.action = act;
   }

   public String getAction()
   {
      return action;
   }
   
   public void setEnabled(boolean enabled)
   {
      this.enabled = enabled;
   }

   public boolean getEnabled()
   {
      return enabled;
   }

   public void setDefaultButton(boolean defButton)
   {
      defaultButton = defButton;
   }

   public boolean getDefaultButton()
   {
      return defaultButton;
   }

   public void setGap(String gap)
   {
      this.gap = gap;
   }

   public String getGap()
   {
      return gap;
   }

   public void setLocatorControl(String locControl)
   {
      locatorControl = locControl;
   }

   public String getLocatorControl()
   {
      return locatorControl;
   }
   
   
   public void setLocatorObject(String locObject)
   {
      locatorObject = locObject;
   }

   public String getLocatorObject()
   {
      return locatorObject;
   }
   
   public void render(PrintWriter out) throws Exception
   {
      StringBuffer buf = new StringBuffer();
      
      buf.append(name);
      buf.append(" = new button(\"text:");
      buf.append((text == null) ? "null" : text);
      
      if (shape != null)
      {
         buf.append("; shape:");
         buf.append(shape);
      }

      if (actionType != null && actionType.length() > 0)
      {
         buf.append("; actiontype:");
         buf.append(actionType);
      }
      
      if (url != null && url.length() > 0)
      {
         buf.append("; url:");
         buf.append(url);
      }

      if (targetFrame != null && targetFrame.length() > 0)
      {
         buf.append("; targetframe:");
         buf.append(targetFrame);
      }

      if (action != null && action.length() > 0)
      {
         buf.append("; action:");
         buf.append(action);
      }
      
      if (!enabled)
      {
         buf.append("; enabled:false"); // default is true
      }

      if (defaultButton)
      {
         buf.append("; defaultbutton:true");
      }
      
      if (gap != null && gap.length() > 0)
      {
         buf.append("; gap:");
         buf.append(gap);
      }
      
      if (locatorControl != null && locatorControl.length() > 0)
      {
         buf.append("; locatorcontrol:");
         buf.append(locatorControl);
      }

      if (locatorObject != null && locatorObject.length() > 0)
      {
         buf.append("; locatorobject:");
         buf.append(locatorObject);
      }
      
      buf.append("\");");

      out.println(buf.toString());
   }
}

