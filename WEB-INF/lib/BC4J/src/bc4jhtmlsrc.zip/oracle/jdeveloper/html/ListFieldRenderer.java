/*
 * @(#)ListFieldRenderer.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jdeveloper.html;

import oracle.jdeveloper.html.ReadOnlyField;
import oracle.jbo.Row;
import oracle.jbo.AttributeDef;
import java.util.StringTokenizer;

/**
**  The ListFieldRenderer takes advantage of the BC4J attribute properties in order to render an attribute
**  by mapping it's current value to a set of display values provided via the DISPLAY_LIST property. 
**  The syntax for this proper is <short Value=display value>,<short Value=display value>. If you need to map
**  Y to YES and N to NO, the value of the property would be Y=YES,N=NO. If the renderer doesn't find this property
**  in the attribute, it will defeault to rendering the raw value.
**/
public class ListFieldRenderer extends ReadOnlyField 
{
  public ListFieldRenderer()
  {
  }

  public String renderToString(Row row)
  {
    setValueFromRow(row);
    
    AttributeDef aDef = getAttributeDef();
    String       sAttrValue = getValue();
    
    String sList = (String)aDef.getProperty("DISPLAY_LIST");
    if(sAttrValue != null && sList != null)
    {
      StringTokenizer tokens = new StringTokenizer(sList, ",", false);
      
      while(tokens.hasMoreTokens())
      {
        String sEntry = tokens.nextToken();
        String sValue = sEntry.substring(sEntry.indexOf('=') + 1); 
        String sKey = sEntry.substring(0, sEntry.indexOf('='));

        if(sKey.equals(sAttrValue))
          return sValue;
      }
    }
    return super.renderToString(row);
  }
}