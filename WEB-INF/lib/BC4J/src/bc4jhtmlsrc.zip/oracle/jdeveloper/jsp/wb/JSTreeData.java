/*
 * @(#)JSTreeData.java
 *
 * Copyright 2000-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jdeveloper.jsp.wb;

import java.io.PrintWriter;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.PageContext;
import oracle.jdeveloper.html.HTMLScript;
import oracle.jdeveloper.html.WebBean;
import oracle.jdeveloper.html.WebBeanImpl;
import oracle.jdeveloper.html.DHTMLArray;
import oracle.jdeveloper.html.DHTMLRow;

public class JSTreeData extends HTMLScript implements WebBean
{
   protected WebBeanImpl   webBean = new WebBeanImpl();  // Aggregate WebBeanImpl
   DHTMLArray              array;                        // Aggregate DHTMLArray
   String                  paramLine;
   String                  paramText;
   String                  paramState;
   String                  paramChild;
   String                  paramToggle;

   public JSTreeData()
   {
      setVersion("javascript");
      array = new DHTMLArray();
      addElement(array);
   }
   
   public JSTreeData(String name)
   {
      this();
      setName(name);
   }

   public void setName(String name)
   {
      array.setName(name);
   }

   public String getName()
   {
      return array.getName();
   }

   public void addRow(DHTMLRow row)
   {
      array.addElement(row);
   }

   public void addRow(String text, String state, int childCount, String url, boolean populated)
   {
      addRow(text, state, childCount, url, populated, null);
   }

   public void addRow(String text, String state, int childCount, String url, boolean populated, String imageUrl)
   {
      DHTMLRow row = new DHTMLRow();

      row.setText(text);
      row.setState(state);
      row.setChildCount(childCount);
      if (url == null || url.length() == 0)
      {
//         url =
      }
      row.setUrl(url);
      row.setPopulated(populated);
      row.setNodeImage(imageUrl);

      addRow(row);
      if (paramLine != null && paramToggle != null)
      {
         int index = array.indexOf(row);
         int line = Integer.parseInt(paramLine);
         if (index == line)
         {
            if (paramToggle.equals("open"))
            {
               row.setState("closed");
            }
            else if (paramToggle.equals("closed"))
            {
               row.setState("open");
            }
         }
      }
   }

   public void initialize(ServletContext appContext, HttpSession session , HttpServletRequest request, HttpServletResponse response, PrintWriter out)
      throws Exception
   {
      // Delegate to helper class
      webBean.initialize(appContext, session, request, response, out);
      getParam();
   }

   public void initialize(PageContext page)
      throws Exception
   {
      // Delegate to helper class
      webBean.initialize(page);
      getParam();
   }

	public void  initialize(ServletContext application, HttpSession session , HttpServletRequest request, HttpServletResponse response, JspWriter out )
      throws Exception
   {
      // Delegate to helper class
      webBean.initialize(application, session, request,response, out);
      getParam();
   }

   public void internalInitialize()
      throws Exception
   {
      webBean.internalInitialize();
   }

   void getParam()
   {
      paramLine = webBean.getRequest().getParameter("line");
      paramText = webBean.getRequest().getParameter("text");
      paramState = webBean.getRequest().getParameter("state");
      paramChild = webBean.getRequest().getParameter("child");
      paramToggle = webBean.getRequest().getParameter("toggle");
   }

   /**
    * Renders the Toolbar to the output stream of the JSP page's response.
    */
   public void render()
      throws Exception
   {
      // Delegate to helper class
      render(webBean.getOut());
   }

	/**
	*	This is the main entry point for rendering the HTML content.
	*/
	public void render(PrintWriter out)
      throws Exception
   {
      webBean.initBeanForJS(WebBean.JSDataConstructLib);
      super.render(out);
   }
}

