/*
 * @(#)CalendarWB.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jdeveloper.jsp.wb;

import java.text.DateFormatSymbols;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;
import oracle.jbo.JboException;
import oracle.jbo.common.DefLocaleContext;
import oracle.jbo.common.JBOClass;
import oracle.jbo.format.DefaultDateFormatter;
import oracle.jbo.format.Formatter;
import oracle.jbo.html.HtmlServices;
import oracle.jbo.html.WebBeanImpl;

public final class CalendarWB extends WebBeanImpl
{
   public static final int MILLIS_IN_DAY = 1000 * 60 * 60 * 24;
   private static final long _MIN_TIME = Long.MIN_VALUE + MILLIS_IN_DAY;
   private static final long _MAX_TIME = Long.MAX_VALUE;
   private static final String ENC_PARAM = "enc";

   private Calendar cal;
   private Formatter formatter;
   private Locale locale;
   private long minTime;
   private long maxTime;
   private long selectedTime;
   private long displayedTime;
   private int firstDOM;
   private int lastDOM;
   private long firstDOMTime;
   private long lastDOMTime;
   private String format;
   private String origFormat;
   private String origFormatter;
   private String origValue;
   private String origLocale;
   private String origEnc;
   
   public int firstDOW;
   public int lastDOW;
   public int dowCount;

   public DateFormatSymbols dateSymbols;

   private StringBuffer buffMonthTarget = new StringBuffer(200);

   public CalendarWB()
   {
   }

   public void internalInitialize() throws Exception
   {
      formatter = getFormatter();
      locale = getLocale();
      origEnc = request.getParameter(ENC_PARAM);
      format = getFormat();
      formatter.setLocale(new DefLocaleContext(locale));

      minTime = getMinTime();
      maxTime = getMaxTime();
      selectedTime = getSelectedTime(minTime, maxTime);

      cal = getDisplayedCalendar(selectedTime);
      long displayedTime = cal.getTime().getTime();

      // determine the day of this month that is selected
      int dom = cal.get(Calendar.DAY_OF_MONTH);

      firstDOM = getActualMinimumDayOfMonth(cal);
      lastDOM  = getActualMaximumDayOfMonth(cal);

      // determine the the starting times and ending times of the first and
      // last days of the month
      firstDOMTime = displayedTime + (firstDOM - dom) * MILLIS_IN_DAY;
      lastDOMTime = displayedTime + ((long)(lastDOM + 1 - dom)) * MILLIS_IN_DAY - 1;

      dateSymbols = new DateFormatSymbols(locale);

      firstDOW = cal.getMinimum(Calendar.DAY_OF_WEEK);
      lastDOW = cal.getMaximum(Calendar.DAY_OF_WEEK);
      dowCount = lastDOW - firstDOW + 1;
    
      buffMonthTarget.append(request.getRequestURI());
      buffMonthTarget.append("?value=");
      buffMonthTarget.append(selectedTime);
      buffMonthTarget.append("&minValue=");
      buffMonthTarget.append(minTime);
      buffMonthTarget.append("&maxValue=");
      buffMonthTarget.append(maxTime);
      if (origFormat != null)
      {
         buffMonthTarget.append("&format=");
         buffMonthTarget.append(origFormat);
      }
      if (origFormatter != null)
      {
         buffMonthTarget.append("&formatter=");
         buffMonthTarget.append(origFormatter);
      }
      if (origLocale != null)
      {
         buffMonthTarget.append("&locale=");
         buffMonthTarget.append(origLocale);
      }
      if (origEnc != null)
      {
         buffMonthTarget.append("&");
         buffMonthTarget.append(ENC_PARAM);
         buffMonthTarget.append("=");
         buffMonthTarget.append(origEnc);
      }
      buffMonthTarget.append("&scrolledValue=");
   }

   public Calendar getCalendar()
   {
      return cal;
   }

   private String getMonthUrl(long buttonTime)
   {
      return (buffMonthTarget.toString() + buttonTime);
   }

   public String getPreviousMonthUrl()
   {
      // last day in the previous month
      return getMonthUrl(firstDOMTime - MILLIS_IN_DAY);
   }

   public String getNextMonthUrl()
   {
      // first day in the next month
      return getMonthUrl(lastDOMTime + MILLIS_IN_DAY);
   }

   public boolean isPreviousMonthEnable()
   {
      return (firstDOMTime >= minTime);
   }

   public boolean isNextMonthEnable()
   {
      return (lastDOMTime <= maxTime);
   }

   // only days between the minimum and maximum times can be
   // selected
   public boolean isDayEnable(long currTime)
   {
      return ((currTime >= minTime) && (currTime <= maxTime));
   }

   public boolean isSelectedDay(long currTime, long nextTime)
   {
      return ((selectedTime >= currTime ) && (selectedTime < nextTime));
   }

   public String getMonth()
   {
      return dateSymbols.getMonths()[cal.get(Calendar.MONTH)];
   }

   public int getYear()
   {
      return cal.get(Calendar.YEAR);
   }

   public int getFirstDOM()
   {
       return firstDOM;
   }

   public int getLastDOM()
   {
      return lastDOM;
   }

   public long getFirstDOMTime()
   {
      return firstDOMTime;
   }

   public long getLastDOMTime()
   {
      return lastDOMTime;
   }

   public static long getFirstDayOfMonthTime(long displayedTime)
   {
      return 0;
   }

  public int getActualMinimumDayOfMonth()
  {
     return getActualMinimumDayOfMonth(cal);
  }

  private static int getActualMinimumDayOfMonth(Calendar calendar)
  {
    // if (JDK1.2) return calendar.getActualMinimum(Calendar.DAY_OF_MONTH);
        
    int currMinimum = calendar.getGreatestMinimum(Calendar.DAY_OF_MONTH) - 1;
    int minimum = calendar.getMinimum(Calendar.DAY_OF_MONTH);
    
    if (currMinimum < minimum)
      return minimum;
    
    int savedMonth = calendar.get(Calendar.MONTH);

    int savedDay = calendar.get(Calendar.DAY_OF_MONTH);
    
    //
    // loop through the first days in the month until the month changes
    //
    while (currMinimum >= minimum)
    {
       calendar.set(Calendar.DAY_OF_MONTH, currMinimum);
      
       if (calendar.get(Calendar.MONTH) != savedMonth)
       {
          calendar.set(Calendar.MONTH, savedMonth);
          break;
       }
      
      currMinimum--;
    }
    
    currMinimum++;

    calendar.set(Calendar.DAY_OF_MONTH, savedDay);
    
    return currMinimum;
  }

  public int getActualMaximumDayOfMonth()
  {
     return getActualMaximumDayOfMonth(cal);
  }

  private static int getActualMaximumDayOfMonth(Calendar calendar)
  {
    // if (JDK1.2) return calendar.getActualMaximum(Calendar.DAY_OF_MONTH);
        
    int currMaximum = calendar.getLeastMaximum(Calendar.DAY_OF_MONTH) + 1;
    int maximum = calendar.getMaximum(Calendar.DAY_OF_MONTH);
    
    if (currMaximum > maximum)
      return maximum;
    
    int savedMonth = calendar.get(Calendar.MONTH);

    int savedDay = calendar.get(Calendar.DAY_OF_MONTH);
    
    //
    // loop through the last days in the month until the month changes
    //
    while (currMaximum <= maximum)
    {
      calendar.set(Calendar.DAY_OF_MONTH, currMaximum);
      
      if (calendar.get(Calendar.MONTH) != savedMonth)
      {
        calendar.set(Calendar.MONTH, savedMonth);
        break;
      }
      
      currMaximum++;
    }
    
    currMaximum--;

    calendar.set(Calendar.DAY_OF_MONTH, savedDay);
    
    return currMaximum;
  }

   public long getTimeAttr(String key, long defaultTime)
   {
      String value = request.getParameter(key); 
      long time;

      if (value == null)
      {
         time = defaultTime;
      }
      else
      {
         try
         {
            time = Long.parseLong(value);
            //time = new Date(value).getTime();
            //time = DateFormat.getDateTimeInstance().parse(value).getTime();
         }
         catch (Exception e)
         {
            time = defaultTime;
         }
      }

      return time;
   }

   public Locale getLocale()
   {
      Locale paramLocale;
      
      origLocale = request.getParameter("locale");
      
      if (origLocale != null)
      {
         String language;
         String country = "";
         String variant = "";
         int index = origLocale.indexOf('_');
         if (index == -1)
         {
            language = origLocale;
         }
         else
         {
            language = origLocale.substring(0, index);
            int index2 = origLocale.indexOf('_', index + 1);
            if (index2 == -1)
            {
               country = origLocale.substring(index + 1);
            }
            else
            {
               country = origLocale.substring(index + 1, index2);
               variant = origLocale.substring(index2 + 1);
            }
         }

         paramLocale = new Locale(language, country, variant);
      }
      else
      {
         paramLocale = Locale.getDefault();
      }

      return paramLocale;
   }

   public String getFormat()
   {
      origFormat = request.getParameter("format");

      // Default to database format
      if (origFormat == null || origFormat.length() == 0)
      {
         origFormat = null;
         return "yyyy-MM-dd";
      }

      return origFormat;
   }

   public Formatter getFormatter()
   {
      origFormatter = request.getParameter("formatter");

      // Default to database format
      if (origFormatter == null || origFormatter.length() == 0)
      {
         origFormatter = null;
         return new DefaultDateFormatter();
      }

      try
      {
         Class cls = JBOClass.forName(origFormatter);

         return (Formatter)cls.newInstance();
      }
      catch(Exception ex)
      {
         throw new JboException(ex);
      }
   }

   
   public long getMinTime()
   {
      return getTimeAttr("minValue", _MIN_TIME);
   }

   public long getMaxTime()
   {
      return getTimeAttr("maxValue", _MAX_TIME);
   }

   public long getSelectedTime(long minTime, long maxTime)
   {
      long origSelectedTime = getTimeAttr("value", 0L);

      if (origSelectedTime == 0L)
      {
         origValue = request.getParameter("origValue");
   
         long defaultTime = System.currentTimeMillis();
         if (origValue == null)
         {
            origSelectedTime = defaultTime;
         }
         else
         {
            try
            {
               origSelectedTime = ((Date) formatter.parse(format, origValue)).getTime();
               //time = Long.parseLong(value);
               //time = new Date(value).getTime();
               //time = DateFormat.getDateTimeInstance().parse(value).getTime();
            }
            catch (Exception e)
            {
               origSelectedTime = defaultTime;
            }
         }
      }
                                         
      long selectedTime = origSelectedTime;
    
      if (selectedTime < minTime)
      {
         selectedTime = minTime;
      }
      else if (selectedTime > maxTime)
      {
         selectedTime = maxTime;
      }
    
      return selectedTime;
   }

  /**
   * Returns a calendar initialized to the date specifeid aby the attrName,
   * or the default date if no attribute exists for that name.
   */
   private Calendar getTimeAttrCalendar(String key, long defaultTime)
   {
      // $$$ Should retrieve local information from context here
      Calendar cal = Calendar.getInstance(TimeZone.getDefault(), locale);

      cal.setTime(new Date(getTimeAttr(key, defaultTime)));
    
      // reset to the first moment of this day
      cal.set(Calendar.HOUR_OF_DAY, 0);
      cal.set(Calendar.MINUTE, 0);
      cal.set(Calendar.SECOND, 0);
      cal.set(Calendar.MILLISECOND, 0);

      return cal;
  }

  /**
   * Returns the Calendar to display
   */
   public Calendar getDisplayedCalendar(long selectedTime)
   {
      Calendar displayedCal = getTimeAttrCalendar("scrolledValue", selectedTime);
      displayedCal.set(Calendar.DAY_OF_MONTH, 1);
      return displayedCal;
   }

   public String getFormatedTime(long currTime)
   {
      String ret;

      try
      {
         ret = "'" + HtmlServices.treatInvalidCharacter(formatter.format(format, new Date(currTime))) + "'";
      }
      catch (oracle.jbo.format.FormatErrorException fex)
      {
         ret = "''";
      }

      return ret;
   }
 
}
