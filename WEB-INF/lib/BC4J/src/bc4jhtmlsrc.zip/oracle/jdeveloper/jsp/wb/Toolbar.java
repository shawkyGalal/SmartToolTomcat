/*
 * @(#)Toolbar.java
 *
 * Copyright 1999-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jdeveloper.jsp.wb;

import java.io.PrintWriter;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.PageContext;
import oracle.jdeveloper.html.HTMLToolBar;
import oracle.jdeveloper.html.WebBean;

/**
 * A Web Bean class that provides methods to dynamically generate an
 * HTML toolbar and render it to the output stream of a JavaServer Page
 * response.
 */
public class Toolbar extends HTMLToolBar implements oracle.jbo.html.WebBean
{
   protected oracle.jbo.html.WebBeanImpl   webBean = new oracle.jbo.html.WebBeanImpl();   // Aggregate WebBeanImpl
   String                  leftImage = "/FNDGTBL.gif";
   String                  rightImage = "/FNDGTBR.gif";
   String                  imageBase = WebBean.defaultImageBase;

   public Toolbar()
   {
      setCSSClassName("clsToolBar");
   }

	/**
	*	@return the URL being used as the base for retrieving images needed in order to
	*		implement the rounded corner surrounding the generated HTML toolbar.
	*/
	public String getImageBase()
   {
      return imageBase;
   }

	/**
	*	Sets the image base URL needed to resolve the HTML toolbar's images for the rounded corners.
	*
	*	@param the URL where the images are stored. The default is '/webapp/images'
	*/
	public void setImageBase(String sBase)
   {
      imageBase = sBase;
   }

	/**
	**	Adds a separator using the default separator image name
	**/
	public void addSeparator()
	{
	   super.addSeparator(imageBase + "/FNDIWDVD.gif");
	}
	
	/**
	*	Provides the url that refers to the toolbar's left image. This image serves as an endpoint
	*   that caps off the middle images in the toolbar.
	*/
	public void setLeftImage(String sImage)
   {
      leftImage = sImage;
   }

	/**
	*	@return the current URL being used for the left image of the toolbar
	*/
   public String getLeftImage()
   {
      return leftImage;
   }

	/**
	*	Provides the url that refers to the toolbar's right image. This image serves as an endpoint
	*   that caps off the middle images in the toolbar.
	*/
	public void setRightImage(String sImage)
   {
      rightImage = sImage;
   }

	/**
	*	@return the current URL being used for the right image of the toolbar
	*/
	public String getRightImage()
   {
      return rightImage;
   }

    /**
     * Initializes the Toolbar object to have access to the important objects
     * of the JSP page.
     *
     * @param application  the JSP page's ServletContext
     * @param session      the JSP page's HttpSession
     * @param request      the JSP page's HttpServletRequest
     * @param response     the JSP page's HttpServletResponse
     * @param out          the PrintWriter that receives the render output
     */
   public void initialize(ServletContext application, HttpSession session , HttpServletRequest request,
                                      HttpServletResponse response, PrintWriter out)
      throws Exception
   {
      // Delegate to helper class
      webBean.initialize(application, session, request, response, out);
   }
    
   public void initialize(PageContext page)
      throws Exception
   {
      // Delegate to helper class
      webBean.initialize(page);
   }
 
    /**
     * Initializes the Toolbar object to have access to the important objects
     * of the JSP page.
     *
     * @param application  the JSP page's ServletContext
     * @param session      the JSP page's HttpSession
     * @param request      the JSP page's HttpServletRequest
     * @param response     the JSP page's HttpServletResponse
     * @param out          the JSP page's JspWriter
     */
	public void  initialize(ServletContext application, HttpSession session , HttpServletRequest request, HttpServletResponse response, JspWriter out )
      throws Exception
   {
      // Delegate to helper class
      webBean.initialize(application, session, request,response, out);
   }

   public void internalInitialize()
      throws Exception
   {
      webBean.internalInitialize();
   }
   
   /**
    * Renders the Toolbar to the output stream of the JSP page's response.
    */
   public void render()
      throws Exception
   {
      render(webBean.getOut());
   }

	/**
	*	Renders the container header. This generates the HTML code that precedes the form elements.
	*/
	public void renderContainerHeader(PrintWriter out)
   {
      out.println("<TABLE BORDER=\"0\" CELLPADDING=\"0\" CELLSPACING=\"0\" CLASS=\"" + getCSSClassName() + "\"><TR><TD>");
   }
   
	/**
	*	Renders the container footer that follows the form elements
	*/
	protected void renderContainerFooter(PrintWriter out)
   {
      out.println("</TD></TR></TABLE>");
   }

	/**
	*	This is the main entry point for rendering the HTML content.
	*/
	public void render(PrintWriter out)
      throws Exception
   {
      renderContainerHeader(out);
      
      // render the left side of the toolbar
      out.println("<TD><IMG SRC=\"" + getImageBase() + getLeftImage() + "\" /></TD>");

      int nSize = Elements.size();
      
      for (int i = 0 ; i < nSize ; i++)
      {
         out.print("<TD>");  
         elementAt(i).render(out);
         out.print("</TD>");  		 
      }
      
      // render the left side of the toolbar
      out.println("<TD><IMG SRC=\"" + getImageBase() + getRightImage() + "\" /></TD>");
      
      renderContainerFooter(out);
      
      webBean.render(out);
   }

   public void setUsedInTag(boolean isUsedInTag)
   {
      webBean.setUsedInTag(isUsedInTag);
   }

}

