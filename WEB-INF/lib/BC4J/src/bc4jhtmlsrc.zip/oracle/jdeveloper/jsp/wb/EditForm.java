/*
 * @(#)EditForm.java
 *
 * Copyright 1999-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jdeveloper.jsp.wb;

import java.io.PrintWriter;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.PageContext;
import oracle.jdeveloper.html.HTMLForm;
import oracle.jdeveloper.html.HTMLFormField;
import oracle.jdeveloper.html.HTMLTextElement;
import oracle.jdeveloper.html.WebBean;
import oracle.jdeveloper.html.DHTMLElementContainer;
import oracle.jdeveloper.html.HTMLInputElement;

/**
 * A Web Bean class that provides methods to dynamically generate
 * an HTML form and render it to the output stream of a JSP response.
 *
 * @version PUBLIC
 *
 **/
public class EditForm extends HTMLForm implements oracle.jbo.html.WebBean
{
   protected oracle.jbo.html.WebBeanImpl   webBean = new oracle.jbo.html.WebBeanImpl();  // Aggregate WebBeanImpl
   String                  imageBase = WebBean.defaultImageBase;
   boolean                 useRoundedCorners = true;
   String                  sWidth = "100%";
      
   {
      setCSSClassName("clsEditForm");
   }

   public EditForm()
   {
      this("","");
   }


   public EditForm(String sAction , String sName)
   {
      super(sAction, sName);
   }

   public void setWidth(String sWidth)
   {
      this.sWidth = sWidth;
   }

   public String getWidth()
   {
      return this.sWidth;
   }

   /**
	*	@return the URL being used as the base for retriving images needed in order to
	*		implement the rounded corner surrounding the generated HTML form.
	*/
	public String getImageBase()
   {
      return imageBase;
   }

	/**
	*	Sets the image base URL needed to resolve the HTML FORM's images for the rounded corners.
	*
	*	@param the URL where the images are stored. The default is '/webapp/images'
	*/
   public void setImageBase(String sBase)
   {
      imageBase = sBase;
   }

   public void setUseRoundedCorners(boolean bSet)
   {
      useRoundedCorners = bSet;
   }
    
   public void addDateField(String sLabel, String sName , String sValue, String sWidth, String sClass, String sMaxLength)
   {
      HTMLInputElement input = new HTMLInputElement();
      
      input.setType("TEXT");
      input.setMaxLength(sMaxLength);
      input.setSize(sWidth);
      input.setName(sName);
      input.setValue(sValue);
      input.setClassName(sClass);
      input.setOnFocus("this.select()");
      input.setOnChange("this.value = datecheck(this.value,NLSformat);checkForError(this,distribute)");
      
      DHTMLElementContainer cnt = new DHTMLElementContainer();

      cnt.addElement(input);
      cnt.addElement(new HTMLTextElement("<a href=\"javascript:void opencal(document." + theName + "." + sName + ");\"><img src=" + imageBase + "/FNDICLDR.gif align=absmiddle border=0 alt=\"Calendar for date entry assistance\"></a>"));
      
      if (sLabel != null)
      {
         Fields.addElement(new HTMLFormField(new HTMLTextElement(sLabel) , cnt, bGenerateLabels));
      }
      else
      {
         Fields.addElement(new HTMLFormField(null, cnt));
      }
   }

   public void addLOVField(String sLabel, String sName , String sValue, String sWidth, String sClass, String sMaxLength, String voName, String displayAttributes, String dataAttribute)
   {
      // generate visible field edit
      String lovname = sLabel;

      HTMLInputElement input = new HTMLInputElement();
      
      input.setType("TEXT");
      input.setMaxLength(sMaxLength);
      input.setSize(sWidth);
      input.setName(sName);
      input.setValue(sValue);
      input.setClassName(sClass);
      
      DHTMLElementContainer cnt = new DHTMLElementContainer();

      cnt.addElement(input);
      if (displayAttributes == null)
      {
         displayAttributes = "";
      }
      if (dataAttribute == null)
      {
         dataAttribute = sLabel;
      }
      cnt.addElement(new HTMLTextElement("<a href=\"#\" onClick=\"var lovname='" + lovname + "'; openModal('" + defaultJSPBase + "/lov.jsp?lovvo=" + voName + "&attr=" + dataAttribute + "&dattr=" + displayAttributes + "', 400, 450, '', document." + theName + "." + sName + ", lovname, 'Y')\" >" + 
                                         "<IMG SRC=\"" + imageBase + "/FNDLSTOV.gif\" BORDER=0 align=\"absmiddle\" /></a>"));
      
      if(sLabel != null)
         Fields.addElement(new HTMLFormField(new HTMLTextElement(sLabel) , cnt, bGenerateLabels));
      else
         Fields.addElement(new HTMLFormField(null, cnt));
   }
   
   public void initialize(ServletContext application, HttpSession session , HttpServletRequest request,
                          HttpServletResponse response, PrintWriter out)
      throws Exception
   {
      // Delegate to helper class
      webBean.initialize(application, session, request, response, out);
   }

   public void initialize(PageContext page)
      throws Exception
   {
      // Delegate to helper class
      webBean.initialize(page);
   }

   /**
    * Initializes the EditForm object to have access to the important objects
    * of the JSP.
    *
    * @param application  the JSP page's ServletContext
    * @param session      the JSP page's HttpSession
    * @param request      the JSP page's HttpServletRequest
    * @param response     the JSP page's HttpServletResponse
    * @param out          the JSP page's JspWriter
    */
   public void  initialize(ServletContext application, HttpSession session , HttpServletRequest request, HttpServletResponse response, JspWriter out )
   throws Exception
   {
      // Delegate to helper class
      webBean.initialize(application, session, request,response, out);
   }

   public void internalInitialize()
      throws Exception
   {
      // Delegate to helper class
      webBean.internalInitialize();
   }

   /**
    * Renders the form to the output stream of the JSP page's response.
    */
   public void render()
      throws Exception
   {
      render(webBean.getOut());
   }

	/**
	*	Renders the container header. This generates the HTML code that precedes the form elements.
	*/
   public void renderContainerHeader(PrintWriter out) 
   {
      try
      {  
         super.renderContainerHeader(out);
      }
      catch(Exception ex)
      {
         throw new RuntimeException(ex.getMessage());
      }
     
      if (useRoundedCorners)
      {
         out.println("<div ><table border=\"0\" width=\"" + this.getWidth() + "\" cellpadding=\"5\" cellspacing=\"0\" class=\"panel\">");
         out.println("<tr><td><table cellpadding=\"0\" cellspacing=\"0\" border=\"0\" align=\"center\">");
         out.println("<tr><td rowspan=\"2\"></td><td></td>");
         out.print("<td color=\"black\" width=\"1000\"><IMG height=1 src=\"");
         out.print(getImageBase());
         out.println("/FNDPX1.gif\" width=1></td>");
         out.println("<td></td><td rowspan=\"2\"></td></tr><tr>");
         out.print("<td><IMG height=5 src=\"");
         out.print(getImageBase());
         out.println("/FNDRTCTL.gif\" width=5></td>");
         out.print("<td class=\"vrtableheader\" width=\"1000\"><IMG height=1 src=\"");
         out.print(getImageBase());
         out.println("/FNDPX4.gif\" width=500></td>");
         out.print("<td><IMG height=5 src=\"");
         out.print(getImageBase());
         out.println("/FNDRTCTR.gif\" width=5></td></tr><tr>");
         out.print("<td bgcolor=\"black\"><IMG src=\"");
         out.print(getImageBase());
         out.println("/FNDPX1.gif\"></td>");
         out.println("<td class=\"tablesurround\" colspan=\"3\"><!--content table--> <table cellpadding=\"3\" cellspacing=\"1\" border=\"0\"  width=\"100%\">");
      }
      else
      {
         out.println("<center>");
      }
   }


	/**
	*	Renders the container footer that follows the form elements
	*/
   protected void renderContainerFooter(PrintWriter out)
   {
      if (useRoundedCorners)
      {
         out.print("</tr></table></td><td bgcolor=\"white\"><IMG src=\"");
         out.print(getImageBase());
         out.println("/FNDPX4.gif\"></td></tr>");
         out.print("<tr><td rowspan=\"2\"></td><td><IMG height=5 src=\"");
         out.print(getImageBase());
         out.println("/FNDRTCBL.gif\" width=5></td>");
         out.print("<td class=\"vrtableheader\" width=\"1000\"><IMG src=\"");
         out.print(getImageBase());
         out.println("/FNDPX3.gif\"></td>");
         out.print("<td><IMG height=5 src=\"");
         out.print(getImageBase());
         out.println("/FNDRTCBR.gif\" width=5></td><td rowspan=\"2\"></td>");
         out.print("</tr><tr><td></td><td bgcolor=\"white\" width=\"1000\"><IMG src=\"");
         out.print(getImageBase());
         out.println("/FNDPX6.gif\"></td>");
         out.println("<td></td></tr></table></td></tr></table></div>");
      }
      else
      {
         out.println("</center>");
      }

      try
      {
          super.renderContainerFooter(out);
      }
      catch(Exception ex)
      {
          throw new RuntimeException(ex.getMessage());
      }
   }

	/**
	*	This is where the main entry point for rendering the HTML content.
	*/
   public void render(PrintWriter out)
      throws Exception
   {
      if (useRoundedCorners)
      {
         renderContainerHeader(out);
      
         renderFields(out);
      
         out.println("<TR><TD colspan=\"2\"><CENTER><BR/>");
         
         // this will render the buttons added by a user
         int nSize = Elements.size();
         for(int i = 0 ; i < nSize ; i++)
         {
            elementAt(i).render(out);
         }
         out.println("</CENTER></TD></TR>");

         renderContainerFooter(out);
      }
      else
      {
         super.render(out);
      }
   }

   public void setUsedInTag(boolean isUsedInTag)
   {
      webBean.setUsedInTag(isUsedInTag);
   }

}

