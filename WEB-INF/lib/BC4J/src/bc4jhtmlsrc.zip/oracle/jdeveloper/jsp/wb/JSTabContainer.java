/*
 * @(#)JSTabContainer.java
 *
 * Copyright 2000-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jdeveloper.jsp.wb;

import java.io.PrintWriter;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.PageContext;
import oracle.jdeveloper.html.WebBean;
import oracle.jdeveloper.html.WebBeanImpl;
import oracle.jdeveloper.html.DHTMLTab;
import oracle.jdeveloper.html.DHTMLTabControl;

public class JSTabContainer extends DHTMLTabControl implements WebBean
{
   protected WebBeanImpl   webBean = new WebBeanImpl();  // Aggregate WebBeanImpl
   String                  tabFrameUrl;
   String                  topFrameUrl;
   String                  bottomFrameUrl;
   String                  topFrameSize = "50";
   String                  bottomFrameSize = "50";
   boolean                 useModalPage = false;

   public JSTabContainer()
   {
   }
   
   public JSTabContainer(String name)
   {
      super(name);
   }

   public void setTabFrameURL(String url)
   {
      this.tabFrameUrl = url;
   }

   public String getTabFrameURL()
   {
      if (tabFrameUrl == null)
      {
         return (WebBean.defaultJSPBase + "/container_tabs.jsp?tc=" + getName());
      }
      else
      {
         return tabFrameUrl;
      }
   }
   
   public void setTopFrameURL(String url)
   {
      this.topFrameUrl = url;
   }

   public String getTopFrameURL()
   {
      if (topFrameUrl == null)
      {
         return (WebBean.defaultJSPBase + "/container_top.jsp?tc=" + getName());
      }
      else
      {
         return topFrameUrl;
      }
   }

   public void setTopFrameSize(String frameSize)
   {
      topFrameSize = frameSize;
   }

   public String getTopFrameSize()
   {
      return topFrameSize;
   }
   
   public void setBottomFrameURL(String url)
   {
      this.bottomFrameUrl = url;
   }
   
   public String getBottomFrameURL()
   {
      if (bottomFrameUrl == null)
      {
         return (WebBean.defaultJSPBase + "/container_bottom.jsp?tc=" + getName());
      }
      else
      {
         return bottomFrameUrl;
      }
   }

   public void setBottomFrameSize(String frameSize)
   {
      bottomFrameSize = frameSize;
   }

   public String getBottomFrameSize()
   {
      return bottomFrameSize;
   }

   public void setUseModalPage(boolean useModalPage)
   {
      this.useModalPage = useModalPage;
   }

   
   public void initialize(ServletContext appContext, HttpSession session , HttpServletRequest request, HttpServletResponse response, PrintWriter out)
      throws Exception
   {
      // Delegate to helper class
      webBean.initialize(appContext, session, request, response, out);
   }

   public void initialize(PageContext page)
      throws Exception
   {
      // Delegate to helper class
      webBean.initialize(page);
   }

	public void  initialize(ServletContext application, HttpSession session , HttpServletRequest request, HttpServletResponse response, JspWriter out)
      throws Exception
   {
      // Delegate to helper class
      webBean.initialize(application, session, request,response, out);
   }
   
   public void internalInitialize()
      throws Exception
   {
      webBean.internalInitialize();
   }
   
   /**
    * Renders the Toolbar to the output stream of the JSP page's response.
    */
   public void render()
      throws Exception
   {
      // Delegate to helper class
      render(webBean.getOut());
   }

	/**
	*	This is the main entry point for rendering the HTML content.
	*/
	public void render(PrintWriter out)
      throws Exception
   {
      int libs = WebBean.JSContainerConstructorLib;

      if (useModalPage)
      {
         libs |= WebBean.JSModalPageConstructorLib;
      }
      
      webBean.initBeanForJS(libs);
      super.render(out);

      out.print("<frameset cols=\"6,*,6\" frameborder=no border=0 framespacing=0");
      if (useModalPage)
      {
         out.print(" onUnload=\"cancelModal()\"");
      }
      out.println(">");
      out.println("<frame src=\"javascript:top.blankframe()\" name=\"border1\" marginwidth=0 marginheight=0 scrolling=no>");
      
      // Build the frameset tag
      out.print("<frameset rows=\"");
      out.print(getTopFrameSize());
      out.print(",50,*,");
      out.print(getBottomFrameSize());
      out.println("\">");
      
      // Build the frame tag for the top frame
      out.println("<frame src=\"" + getTopFrameURL() + "\" name=\"_header\" marginwidth=0 marginheight=2 scrolling=no>");

      // Build the frame tag for the tab frame
      out.println("<frame src=\"" + getTabFrameURL() + "\" name=\"_tabs\" marginwidth=0 scrolling=no>");
      
      int initTabIndex = getInitialTab();
      if (initTabIndex <= 0)
      {
         initTabIndex = 1;
      }

      String   src = "";
      if (tabs.size() > 0)
      {
         if (initTabIndex > tabs.size())
         {
            initTabIndex = tabs.size();
         }
   
         DHTMLTab initTab = (DHTMLTab) tabs.elementAt(initTabIndex - 1);
   
         if (initTab != null)
         {
            src = initTab.getUrl();
         }
         else
         {
            src = "";
         }
      }
      
      // Build the frame tag for the content frame
      out.println("<frame src=\"" + src + "\" name=\"" + WebBean.contentFrameName + "\" marginwidth=3 scrolling=auto>");
      
      // Build the frame tag for the bottom frame
      out.println("<frame src=\"" + getBottomFrameURL() + "\" name=\"_bottom\" marginwidth=0 scrolling=no>");
      
      out.println("</frameset>");
      out.println("<frame src=\"javascript:top.blankframe()\" name=\"border2\" marginwidth=0 scrolling=no>");
      out.println("</frameset>");
   }

}

