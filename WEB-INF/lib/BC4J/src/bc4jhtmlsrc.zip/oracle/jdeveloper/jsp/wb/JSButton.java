/*
 * @(#)JSButton.java
 *
 * Copyright 2000-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jdeveloper.jsp.wb;

import java.io.PrintWriter;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.PageContext;
import oracle.jdeveloper.html.WebBean;
import oracle.jdeveloper.html.WebBeanImpl;
import oracle.jdeveloper.html.DHTMLButton;

public class JSButton extends DHTMLButton implements WebBean
{
   protected WebBeanImpl webBean = new WebBeanImpl();   // Aggregate WebBeanImpl

   public JSButton()
   {
   }

   public JSButton(String name)
   {
      super(name);
   }
   
   public void initialize(ServletContext appContext, HttpSession session , HttpServletRequest request, HttpServletResponse response, PrintWriter out)
      throws Exception
   {
      // Delegate to helper class
      webBean.initialize(appContext, session, request, response, out);
   }

   public void initialize(PageContext page)
      throws Exception
   {
      // Delegate to helper class
      webBean.initialize(page);
   }

	public void  initialize(ServletContext application, HttpSession session , HttpServletRequest request, HttpServletResponse response, JspWriter out )
      throws Exception
   {
      // Delegate to helper class
      webBean.initialize(application, session, request,response, out);
   }
   
   public void internalInitialize()
      throws Exception
   {
      // Delegate to helper class
      webBean.internalInitialize();
   }
   
   /**
    * Renders the Toolbar to the output stream of the JSP page's response.
    */
   public void render()
      throws Exception
   {
      // Delegate to helper class
      render(webBean.getOut());
   }

   /**
	*	This is the main entry point for rendering the HTML content.
	*/
   public void render(PrintWriter out)
      throws Exception
   {
      webBean.initBeanForJS(WebBean.JSButtonConstructorLib);
      super.render(out);
   }
}

