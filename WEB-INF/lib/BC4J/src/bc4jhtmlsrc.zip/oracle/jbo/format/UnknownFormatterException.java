/*
 * @(#)UnknownFormatterException.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.format;

import java.lang.Exception;

/**
 ** UnknownFormatterError <P>
 **
 ** @version SDK
 */
/**
 *   Exception used by methods in oracle.dacf.Formatter.FormatManager interface.
 */
public class UnknownFormatterException extends Exception
{
   /**
   ** Constructs an Exception with no specified detail  message.
   **/
   public UnknownFormatterException()
   {
       super();
   }

   /**
   **   Constructs an Exception with the specified detail message.
   **/
   public UnknownFormatterException(String s)
   {
       super(s);
   }
}

