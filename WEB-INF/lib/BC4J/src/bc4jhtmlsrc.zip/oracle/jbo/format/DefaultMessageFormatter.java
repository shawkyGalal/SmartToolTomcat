/*
 * @(#)DefaultMessageFormatter.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.format;

import java.text.FieldPosition;
import java.text.MessageFormat;
import java.text.ParseException;
import java.text.ParsePosition;
import oracle.jbo.LocaleContext;
import oracle.jbo.common.DefLocaleContext;

/**
 **  A generic formatter class. It uses java.text.MessageFormat to 
 **  format.
 **  
 **   
 **  @version SDK
 **/
public class DefaultMessageFormatter extends Formatter
{
   /**
   *  The locale we are currently using
   */
   private LocaleContext _theLocale = new DefLocaleContext();

   /**
   * Default format string
   */
   private String _defaultFormatString = "{0}";
                                         
   /**
   *  Helper object to which we delegate all our work
   */
   private MessageFormat  _theMessageFormatHelper =
                             new MessageFormat(_defaultFormatString);
                             
   /**
   *  Constructor
   */
   public DefaultMessageFormatter()
   {
   }
 
   /**
   ** format raw data according to the format specified. <P>
   **
   ** Data is formatted per the 'format string' passed as an argument to this
   ** function.
   **
   ** @return formatted string
   ** @param formatString code to define how the raw data should be formatted.
   ** @param rawData  data which needs to be formatted.
   ** @exception FormatErrorException if unable to format the data according to
   ** the format specified.
   */

   public String format(String formatString, Object rawData)
             throws FormatErrorException
   {
       _theMessageFormatHelper.applyPattern(formatString);
       return _theMessageFormatHelper.format(new Object[]{rawData});
   }

   /**
   **  parse this string according to the format specified and return an object
   **
   ** @return object which represents the string parsed.
   ** @param formatString code to define how the raw data should be parsed.
   ** @param parseThisString data which needs to be parsed.
   ** @exception java.text.ParseException when unable to parse data according to
   ** the format specified.
   */

	public Object parse(String formatString, String parseThisString)
                throws ParseException
   {
       _theMessageFormatHelper.applyPattern(formatString);

       Object formattedObj[] =   (Object [])_theMessageFormatHelper.parse(
              parseThisString, new ParsePosition(0));
       return formattedObj[0];
   }

   /**
   **  define locale to be used.
   **  Formatter will need to make locale specific formatting if applicable
   **  @param thisLocale locale to be used
   **  @exception UnknownLocaleException if the formatter does'nt support the
   **  specified Locale.
   */

   public void setLocale(LocaleContext thisLocale)
         throws UnknownLocaleException
   {
        if (_theLocale != thisLocale )
        {
           _theMessageFormatHelper.setLocale(thisLocale.getLocale());
           _theLocale = thisLocale;
         }
   }

   /**
   **  @return Locale currently in use
   **/

   public LocaleContext getLocale()
   {
        return _theLocale;
   }

   /**
   **  @return object which represents the string parsed
   **  @param  parseThisString data which needs to be parsed
   **  @param  status parse to start from this position
   **/

   public Object parseObject(String parseThisString, ParsePosition status)
   {
       Object formattedObj[] = (Object []) _theMessageFormatHelper.parseObject
                                  (parseThisString, status );
       return formattedObj[0];
   }

   /**
   ** @return formatted string
   ** @param obj object which needs to be formatted
   ** @param toAppendTo appended formatted string here
   ** @param pos additional information about the formatting performed. see 
   ** java.text.FieldPosition for more information
   **/
   
   public StringBuffer format(Object obj, StringBuffer toAppendTo,
                       FieldPosition pos)
   {
         return _theMessageFormatHelper.format(new Object[]{obj}, toAppendTo, pos);
   }
}
