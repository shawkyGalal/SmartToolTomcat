/*
 * @(#)Formatter.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.format;

import java.text.Format;
import java.text.ParseException;
import oracle.jbo.LocaleContext;

/**
 ** Formatter <P>
 **
 ** Formatter interface defines functions for formatting support
 **
 ** @version SDK
 **/
public abstract class Formatter extends Format
{
   /**
	** format raw data according to the format specified. <P>
   **
   ** Data is formatted per the 'format string' passed as an argument to this
   ** function.
   **
   ** @return formatted string
   ** @param formatString code to define how the raw data should be formatted.
   ** @param rawData  data which needs to be formatted.
   ** @exception FormatErrorException if unable to format the data according to
   ** the format specified.
   */
   
	public abstract String format(String formatString, Object rawData) throws FormatErrorException;

   /**
   **  parse this string according to the format specified and return an object
   **
   ** @return object which represents the string parsed.
   ** @param formatString code to define how the raw data should be parsed.
   ** @param parseThisString data which needs to be parsed.
   **  @exception java.text.ParseException when unable to parse data according to
   ** the format specified.
   */
   
	public abstract Object parse(String formatString, String parseThisString)  throws ParseException;

   // allow users to specify locales

   /**
   **  define locale to be used.
   **  Formatter will need to make locale specific formatting if applicable
   **  @param thisLocale locale to be used
   **  @exception UnknownLocaleException if the formatter does'nt support the
   **  specified Locale.
   */
   
   public abstract void setLocale(LocaleContext thisLocale) throws UnknownLocaleException;

   /**
   **  @return LocaleContext currently in use
   **/

   public abstract LocaleContext getLocale();
                    
}


