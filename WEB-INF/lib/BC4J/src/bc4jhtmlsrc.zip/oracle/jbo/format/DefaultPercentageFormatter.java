/*
 * @(#)DefaultPercentageFormatter.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.format;

import java.math.BigDecimal;
import java.text.FieldPosition;
import java.text.NumberFormat;
import java.text.ParseException;
import java.text.ParsePosition;
import oracle.jbo.LocaleContext;
import oracle.jbo.common.DefLocaleContext;

/**
 **  Helper class used to format  percentage values
 **
 **  @version SDK
 **/
public class DefaultPercentageFormatter extends Formatter
{
   /**
   *  The locale we are currrently using
   */
    private LocaleContext _theLocale = new DefLocaleContext();

    /**
    *  Heleper object to which we delegate all our work
    */
    private NumberFormat _thePercentageFormatHelper =
           NumberFormat.getPercentInstance(_theLocale.getLocale());
   /**
   *  Constructor
   */
   public DefaultPercentageFormatter()
   {
   }
 
   /**
	** format raw data according to the format specified. <P>
   **
   ** Data is formatted per the 'format string' passed as an argument to this
   ** function.
   **
   ** @return formatted string
   ** @param formatString code to define how the raw data should be formatted.
   ** @param rawData  data which needs to be formatted.
   ** @exception FormatErrorException if unable to format the data according to
   ** the format specified.
   */
   
 	public String format(String formatString, Object rawData)
            throws FormatErrorException
   {
        // formatString ignored.
        Double formatThis;
        if (rawData instanceof Double) 
            formatThis = (Double)rawData;
        else if (rawData instanceof BigDecimal)
            formatThis = new Double( ((BigDecimal)rawData).doubleValue());
        else
            formatThis = new Double(rawData.toString());
        return _thePercentageFormatHelper.format(formatThis);
   }

   /**
   **  parse this string according to the format specified and return an object
   **
   ** @return object which represents the string parsed.
   ** @param formatString code to define how the raw data should be parsed.
   ** @param parseThisString data which needs to be parsed.
   **  @exception java.text.ParseException when unable to parse data according to
   ** the format specified.
   */
   
	public Object parse(String formatString, String parseThisString)
                throws ParseException
   {
       // formatString not used
       return _thePercentageFormatHelper.parse(
              parseThisString, new ParsePosition(0));
   }

   /**
   **  define locale to be used.
   **  Formatter will need to make locale specific formatting if applicable
   **  @param thisLocale locale to be used
   **  @exception UnknownLocaleException if the formatter does'nt support the
   **  specified Locale.
   */
   
   public void setLocale(LocaleContext thisLocale)
         throws UnknownLocaleException
   {
       if (_theLocale != thisLocale )
       {
           _thePercentageFormatHelper =
                    NumberFormat.getPercentInstance(thisLocale.getLocale());
           _theLocale = thisLocale;
        }
   }

   /**
   **  @return Locale currently in use
   **/
   
   public LocaleContext getLocale()
   {
        return _theLocale;
   }

   /**
    **  @return object which represents the string parsed
    **  @param  parseThisString data which needs to be parsed
    **  @param  status parse to start from this position
    **/
    
    public Object parseObject(String formatThisString, ParsePosition status)
    {
        return _thePercentageFormatHelper.parseObject(formatThisString, status);
    }

    /**
    ** @return formatted string
    ** @param obj object which needs to be formatted
    ** @param toAppendTo appended formatted string here
    ** @param pos additional information about the formatting performed. see 
    ** java.text.FieldPosition for more information
    **/
   
    public StringBuffer format(Object obj, StringBuffer toAppendTo,
                        FieldPosition pos)
    {
         return _thePercentageFormatHelper.format(obj, toAppendTo, pos);
    }
}
