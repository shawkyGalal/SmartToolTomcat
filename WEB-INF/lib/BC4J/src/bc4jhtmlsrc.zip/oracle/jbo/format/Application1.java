/*
 * @(#)Application1.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.format;

import java.util.Locale;
import oracle.jbo.ApplicationModule;
import oracle.jbo.AttributeDef;
import oracle.jbo.LocaleContext;
import oracle.jbo.Row;
import oracle.jbo.ViewObject;
import oracle.jbo.common.DefLocaleContext;
import oracle.jbo.common.ampool.ApplicationPool;
import oracle.jbo.common.ampool.PoolMgr;

public class Application1 extends Object {

  public Application1() {
  }

  protected void doTest()
  {
    try
    {
      PoolMgr poolMgr = PoolMgr.getInstance();
    
      ApplicationPool pool = poolMgr.createPool("test1", "package1", "Package1ModuleLocal", null);
      
      ApplicationModule am = pool.checkout();
      
      ViewObject emps = am.findViewObject("EmpView");
      LocaleContext locale = new DefLocaleContext(Locale.getDefault());
      AttributeDef aDef = emps.findAttributeDef( "Hiredate");
      
      Row row = emps.first();
      
      String sRet = aDef.getUIHelper().getFormattedAttribute(row, locale);

      System.out.println(sRet);

      Object obj = aDef.getUIHelper().parseFormattedAttribute("1991-12-17 AD at 12:00:00 PST" , locale);

      row.setAttribute(aDef.getIndex(), obj);
      
      sRet = aDef.getUIHelper().getFormattedAttribute(row, locale);

      System.out.println(sRet);
      
    }
    catch(Exception ex)
    {
      ex.printStackTrace();
    }
  }
 
  public static void main(String[] args) 
  {
    Application1 app1 = new Application1();
    
    app1.doTest();
  }
}


