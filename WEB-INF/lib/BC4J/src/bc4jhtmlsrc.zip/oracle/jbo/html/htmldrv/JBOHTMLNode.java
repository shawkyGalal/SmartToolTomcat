/*
 * @(#)JBOHTMLNode.java
 *
 * Copyright 1999-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.html.htmldrv;

import java.awt.*;
import java.io.*;
import java.io.*;
import java.net.*;
import java.util.*;
import javax.swing.*;
import javax.swing.tree.*;
import oracle.jbo.server.*;

/**
 *
 * @version INTERNAL
 */
public class JBOHTMLNode extends HTMLBaseNode
{
   boolean bGenerateComments = false;
   boolean bGenerateForChildNodes = false;

   public JBOHTMLNode(HTMLTokenizer tokens, IHTMLParserNode parent)
   {
      super(tokens, parent);
   }

   public JBOHTMLNode(IHTMLParserNode parent)
   {
      super(null, parent);
   }
   
   public void setGenerateCommentTags(boolean bGen)
   {
      bGenerateComments = bGen;
   }

   public void setGenerateForChildNodes(boolean bGen)
   {
      bGenerateForChildNodes = bGen;
   }

   public void populateWriter(PrintWriter out) throws Exception
   {
      int            nElem = 0;

      if(nodeTag != null && nodeTag.length() > 0)
      {
        if(bGenerateComments)
          out.print("<!--");

        if(nodeTag.equalsIgnoreCase("Presentation Bean"))
          out.print("{%vpbean:");
        else
          out.print("{%" + nodeTag );
        //append attributes
        nElem = tokens.size();
        for(int i  = 0 ; i < nElem ; i++)
        {
            out.print((String)tokens.elementAt(i));
        }

        out.print("%}");

        if(bGenerateComments)
          out.print("-->");
      }

      if(bGenerateForChildNodes)
      {
          nElem = nodes.size();
          IHTMLParserNode  node2;

          for(int i  = 0 ; i < nElem ; i++)
          {
             node2 = (IHTMLParserNode)nodes.elementAt(i);
             node2.populateWriter(out);
          }
      }

      if(nodeTag!= null && nodeTag.equalsIgnoreCase("For"))
      {
         out.print("<!--{%EndFor%}-->");
      }
   }

   public String           getNodeLabel()
   {
      String sTag      = getNodeTag();

             
      int nElem = tokens.size();
      for(int i  = 0 ; i < nElem ; i++)
      {
         sTag += (String)tokens.elementAt(i);
      }
    
      sTag = sTag.replace('\n' , ' ');
      sTag = sTag.trim();
      
      if(sTag.length() > 60)
      {
         sTag = sTag.substring(0, 60) + "...";
      }

      return sTag;
   }   

}