/*
 * @(#)HtmlDriver.java
 *
 * Copyright 1998-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.html.htmldrv;

import java.io.*;
import java.util.*;

public class HtmlDriver
{
   public static final int CMDID_NONE = 0;
   public static final int CMDID_GET = 1;
   public static final int CMDID_POST = 2;

   private HDCmdBlock outerCB = null;
   private String propFileName = null;

   public static void main(String argv[])
   {
      HtmlDriver drv = new HtmlDriver();
      HDCmdBlock inCB;
      
      try
      {
         inCB = drv.procSwitches(argv);
         drv.initProps();
         inCB.run();
         System.exit(0);
      }
      catch(Exception ex)
      {
         ex.printStackTrace();
         System.exit(1);
      }
   }
   
   public void initProps()
   {
      try
      {
         if (propFileName == null)
         {
            propFileName = "props";
         }
         
         FileInputStream in = new FileInputStream(propFileName);
         Properties props = new Properties();

         props.load(in);

         Properties oldProps = System.getProperties();
         Enumeration enum = oldProps.propertyNames();
         
         while (enum.hasMoreElements())
         {
            String propName = (String) enum.nextElement();
            String propVal = oldProps.getProperty(propName);

            if (props.getProperty(propName) == null)
            {
               props.put(propName, propVal);
            }
         }

         System.setProperties(props);
      }
      catch(IOException ex)
      {
      }
   }
   
   public HDCmdBlock procSwitches(String argv[])
   {
      Reader inRead = null;
      boolean isConsole = false;

      for (int j = 0; j < argv.length; j++)
      {
         if (argv[j].equals("-input"))
         {
            if (j + 1 < argv.length)
            {
               j++;

               String inFileName = argv[j];
               
               try
               {
                  inRead = new FileReader(inFileName);
                  isConsole = false;
               }
               catch(FileNotFoundException ex)
               {
                  System.err.println("Input file " + inFileName + " not found");
                  System.exit(1);
               }
            }
            else
            {
               System.err.println("-input switch w/o file name");
               usage();
            }
         }
         else  if (argv[j].equals("-prop"))
         {
            if (j + 1 < argv.length)
            {
               j++;

               String propFileName = argv[j];
            }
            else
            {
               System.err.println("-prop switch w/o file name");
               usage();
            }
         }
         else
         {
            System.err.println("Unrecognized switch: " + argv[j]);
            usage();
         }
      }
      
      boolean printPrompt = false;

      if (inRead == null)
      {
         printPrompt = true;
         inRead = new InputStreamReader(System.in);
         isConsole = true;
      }

      HDCmdBlock inCB = new HDCmdBlock(new LineNumberReader(inRead), isConsole, printPrompt);

      outerCB = inCB;

      return inCB;
   }
   
   public void usage()
   {
      System.err.println("Usage:  java oracle.jbo.htmldrv.HtmlDriver [-input <input-file>] [-prop <prop-file>]");
      System.exit(1);
   }
}
