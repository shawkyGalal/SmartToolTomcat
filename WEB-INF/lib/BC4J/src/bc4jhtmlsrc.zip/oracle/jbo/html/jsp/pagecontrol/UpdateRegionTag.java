package oracle.jbo.html.jsp.pagecontrol;

import javax.servlet.jsp.tagext.BodyTagSupport;
import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.tagext.BodyContent;
import javax.servlet.jsp.JspTagException;

public class UpdateRegionTag extends BodyTagSupport 
{
   String _href;
   String _regionId;
   
   public void setHref(String sValue)
   {
      _href = sValue;
   }

   public void setRegionid(String sValue)
   {
     _regionId = sValue;
   }
   
   public int doStartTag() throws JspException
   {
       String sRegion = pageContext.getRequest().getParameter("updateRegion");
       if(sRegion != null)
        return SKIP_BODY;
        
      return EVAL_BODY_AGAIN;
   }


  /**
   * Method is invoked after every body evaluation to control whether the body will be reevaluated or not.
   * @return SKIP_BODY
   */
  public int doAfterBody() throws JspException
  {
    try
    {
        JspWriter out = getPreviousOut();
        BodyContent bodyContent = getBodyContent(); 
                
        int nIndex = _href.indexOf('?');
        String sUrl;
         
        if(nIndex != -1)
          sUrl = _href + "&";
        else
          sUrl = _href + "?";

        sUrl = "updateRegion('" + _regionId + "', '" + sUrl + "updateRegion="+ _regionId + "');return false";

        out.print("<A HREF=\"about:blank\" onClick=\"" + sUrl + "\">");
        bodyContent.writeOut(out);
        out.print("</A>");
    }
    catch(Exception e)
    {
      throw new JspTagException(e.getMessage());
    }

    return SKIP_BODY;
  }
  
  /**
   * Method called at end of tag.
   * @return SKIP_PAGE
   */
   public int doEndTag()
   {
      return EVAL_PAGE;
   }
}