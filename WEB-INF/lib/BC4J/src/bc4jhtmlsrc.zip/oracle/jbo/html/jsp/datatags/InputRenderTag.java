/*
 * @(#)InputRenderTag.java
 *
 * Copyright 2000-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.html.jsp.datatags;

import oracle.jbo.html.HtmlServices;
import oracle.jbo.JboException;
import oracle.jdeveloper.html.DateField;
import oracle.jdeveloper.html.HTMLFieldRenderer;

public class InputRenderTag extends InputTagBase
{
   protected String sformname;
   
   public void setFormname(String sValue)
   {
      sformname = sValue;
   }
   
   public HTMLFieldRenderer getFieldRenderer()
   {
      HTMLFieldRenderer fldRnd = ds.getEditFieldRenderer(pageContext, row, attrDef);
      if (fldRnd instanceof DateField)
      {
         if (sformname == null)
         {
            if (HtmlServices.isStrutsContext(pageContext))
            {
               sformname = getStrutsFormName();
            }
            else
            {
               throw new JboException(Res.getString(Res.INPUTDATE_NO_FORMNAME));
            }
         }
      }

      return fldRnd;
   }

   public void internalInitialize()
   {
      super.internalInitialize();

      if (sformname != null)
         rndObj.setFormName(sformname);
   }

   public void release()
   {
      sformname = null;
      super.release();
   }
}

 