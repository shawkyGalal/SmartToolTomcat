/*
 * @(#)JboUtil.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.html.jsp.blaf;

import javax.servlet.jsp.PageContext;
import javax.servlet.jsp.tagext.Tag;
import oracle.cabo.ui.beans.nav.NavigationBarBean;
import oracle.cabo.ui.beans.table.TableBean;
import oracle.cabo.ui.data.DataObjectList;
import oracle.jbo.AttributeDef;
import oracle.jbo.Row;
import oracle.jbo.RowSet;
import oracle.jbo.html.DataSource;
import oracle.jbo.html.jsp.datatags.Utils;
import javax.servlet.jsp.tagext.TagSupport;


public class JboUtil 
{
   public JboUtil()
   {
   }

   public static Object getCaboDataSource(PageContext pageContext, String sDataSource)
   {
       DataObjectList dataObjectList = (DataObjectList)pageContext.getAttribute(sDataSource + "uix");

       if(dataObjectList == null)
       {
          DataSource     ds = Utils.getDataSourceFromContext(pageContext, sDataSource);
          dataObjectList = new RowSetDataObjectList(pageContext, ds);
          pageContext.setAttribute(sDataSource + "uix", dataObjectList);
       }
       return dataObjectList;
   }

   public static void configureNavigatorBarFromDataSource(PageContext pageContext, String datasource, NavigationBarBean bean)
   {
      String sEventsource = datasource + "_Nav";

      bean.setName(sEventsource);
      
      // setup from data source parameters
      DataSource ds = Utils.getDataSourceFromContext(pageContext, datasource);
      int nRowIndex = 0;
      
      // handle navigation, if any
      if(pageContext.getRequest().getParameter("source") != null)
      {
         if(sEventsource.equalsIgnoreCase(pageContext.getRequest().getParameter("source")))
         {
            // we have some navigation to do
            String sValue = pageContext.getRequest().getParameter("value");
            nRowIndex = Integer.parseInt(sValue);

            int nMoved = ds.getRowSet().setRangeStart(nRowIndex - 1);
            ds.getRowSet().setCurrentRowAtRangeIndex(nRowIndex - nMoved);
         }
      }

      int nRangeSize = ds.getRowSet().getRangeSize();
      long nTotal = ds.getRowSet().getEstimatedRowCount();

      if(nRangeSize == -1)
      {
         bean.setMinValue(1);
         bean.setMaxValue(nTotal);
         bean.setBlockSize((int)nTotal);
         bean.setValue(nRowIndex);
      }
      else
      {
         bean.setMinValue(1);
         bean.setMaxValue(nTotal);
         bean.setBlockSize(nRangeSize);
         bean.setValue(nRowIndex);
      }
   }

   public static void configureTableFromDataSource(PageContext pageContext, 
               String datasource, TableBean bean)
   {
      String sEventsource = datasource + "_TableNav";

      bean.setName(sEventsource);
      
      // setup from data source parameters
      DataSource ds = Utils.getDataSourceFromContext(pageContext, datasource);

      // handle navigation, if any
      String sEvent = pageContext.getRequest().getParameter("event");
      int nRowIndex = 0;
      
      if(sEvent != null && sEvent.equalsIgnoreCase("goto"))
      {
         if(sEventsource.equalsIgnoreCase(pageContext.getRequest().getParameter("source")))
         {
            // we have some navigation to do
            String sValue = pageContext.getRequest().getParameter("value");

            if(sValue != null)
            {
               nRowIndex = Integer.parseInt(sValue);

               int nMoved = ds.getRowSet().setRangeStart(nRowIndex - 1);
               ds.getRowSet().setCurrentRowAtRangeIndex(nRowIndex - nMoved);
            }
         }
      }
      else
      {
        // make sure the row index is setup properly
        nRowIndex = ds.getRowSet().getCurrentRowIndex();
      }
      
      int nRangeSize = ds.getRowSet().getRangeSize();
      long nTotal = ds.getRowSet().getEstimatedRowCount();
      int nRowsInRange = ds.getRowSet().getRowCountInRange();

       if(nRangeSize == -1)
      {
         bean.setMinValue(1);
         bean.setMaxValue(nTotal);
         bean.setBlockSize((int)nTotal);
         bean.setValue(nRowIndex);
      }
      else
      {
         bean.setMinValue(1);
         bean.setMaxValue(nTotal);
         bean.setBlockSize(nRangeSize);
         bean.setValue(nRowIndex);
      }
   }

   public static void setupHideShowFromRequest(PageContext pageContext, String datasource, RowSet rs)
   {
      String sEvent = pageContext.getRequest().getParameter("event");

      if(sEvent == null || (!sEvent.equalsIgnoreCase("show") && !sEvent.equalsIgnoreCase("hide")))
         return;
         
      String sEventsource = datasource + "_TableNav";
      String sSource = pageContext.getRequest().getParameter("source");

      // handle navigation, if any
      if(pageContext.getRequest().getParameter("source") != null)
      {
         if(sSource.startsWith(sEventsource))
         {
            String sValue = pageContext.getRequest().getParameter("value");
            int nValue = Integer.parseInt(sValue,10);

            Row row = rs.getRowAtRangeIndex(nValue);
            if(row != null)
            {
               AttributeDef aDef = null;

               try
               {
                  aDef = rs.getViewObject().findAttributeDef("UixShowHide");
               }
               catch(oracle.jbo.NoDefException ex)
               {
               }

               if(aDef == null)
               {
                  aDef = rs.getViewObject().addDynamicAttribute("UixShowHide");
               }
               
               String sAttrValue = (String)row.getAttribute(aDef.getIndex());

               if(sAttrValue == null)
               {
                  row.setAttribute(aDef.getIndex(), "true");
               }
               else
               {
                  row.setAttribute(aDef.getIndex(), sAttrValue.equals("true")?"false":"true");
               }
            }
         }
      }
   }

   public static void handleAddRowEvent(PageContext pageContext, String datasource)
   {
      String sEvent = pageContext.getRequest().getParameter("event");

      if(sEvent == null || !sEvent.equalsIgnoreCase("addRows"))
         return;
         
      String sEventsource = datasource + "_TableNav";

      // setup from data source parameters
      DataSource ds = Utils.getDataSourceFromContext(pageContext, datasource);

      // handle navigation, if any
      if(pageContext.getRequest().getParameter("source") != null)
      {
         if(sEventsource.equalsIgnoreCase(pageContext.getRequest().getParameter("source")))
         {
            // we have some navigation to do
            String sSize = pageContext.getRequest().getParameter("size");
            int nValue = Integer.parseInt(sSize);

            for(int i = 0; i < nValue; i++)
            {
               Row row = ds.getRowSet().createRow();

               if (row != null)
               {
                  ds.getRowSet().insertRow(row);
               }
            }
         }
      }
   }

   public static boolean useUixBoundValue(Tag tag, String datasource)
   {
      JboTableTag parent = (JboTableTag)TagSupport.findAncestorWithClass(tag, JboTableTag.class);

      if(parent != null && parent.getDatasource().equals(datasource))
         return true;
      return false;
   }

}

