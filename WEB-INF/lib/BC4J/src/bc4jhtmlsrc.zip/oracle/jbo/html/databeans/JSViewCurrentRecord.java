/*
 * @(#)JSViewCurrentRecord.java
 *
 * Copyright 2000-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.html.databeans;

import oracle.jbo.AttributeDef;
import oracle.jbo.Row;
import oracle.jbo.RowSet;
import oracle.jdeveloper.html.DataWebBeanImpl;
import oracle.jdeveloper.html.WebBean;
import oracle.jdeveloper.html.DHTMLArray;
import oracle.jdeveloper.html.DHTMLData;
import oracle.jdeveloper.html.DHTMLElement;
import oracle.jdeveloper.jsp.wb.JSTable;
import oracle.jdeveloper.jsp.wb.JSTableData;

public class JSViewCurrentRecord extends DataWebBeanImpl
{
   boolean     showRecordNumber = false;
   JSTable     table;
   JSTableData data;

   public void JSViewCurrentRecord()
   {
   }

   /**
   *	Sets whether the control will render the record numbers in the browser.
   * @param bShow <TT>true</TT> to display record number; <TT>false</TT> to
   * suppress record numbers.
   */
   public void setShowRecordNumbers(boolean bShow)
   {
      showRecordNumber = bShow;
   }

   public void internalInitialize()
      throws Exception
   {
      super.internalInitialize();
      
      String tableName = getUniqueName("disprec");
      String dataName = getUniqueName("dsrec");
      String acName = "atcell";
      String rcName = "rtcell";

      // Setup table WebBean
      table = new  oracle.jdeveloper.jsp.wb.JSTable(tableName);
      table.initialize(page);
      table.setRefName(tableName);
      table.setWidthPercent("50");

      table.setDataSource(dataName);
   
      table.createTextCell(acName, "tablerowheader", "false", "left");
      table.createTextCell(rcName, null, "false", "left");
      
      table.addColumn(null, null, acName, null, null);
      table.addColumn(null, null, rcName, null, null);

      // Setup Data WebBean
      data = new oracle.jdeveloper.jsp.wb.JSTableData(dataName);
      data.initialize(page);
   
      RowSet rs = ds.getRowSet();
      Row row = rs.getCurrentRow();
      if (row == null)
      {
         row = rs.first();
      }
      
      AttributeDef[] attrs =  getDisplayAttributeDefs();
      String         sValue;
      String         sAttr;
      
      if (showRecordNumber)
      {
         int rowTag = rs.getRangeStart() + rs.getRangeIndexOf(row) + 1;
         
         if (rowTag == -1)
         {
            sValue = "?";
         }
         else
         {
            sValue = Integer.toString(rowTag);
         }
         
         data.addRow(buildRow("Record #", sValue));
      }

      for (int attrNo = 0; attrNo < attrs.length ; attrNo++)
      {
		   if(!shouldDisplayAttribute(attrs[attrNo]))
					  continue;

         sAttr = ds.getAttributeLabel(attrs[attrNo]);
         sValue = "";

         if (row != null)
         {
            Object obj = row.getAttribute(attrs[attrNo].getIndex());
            if (obj != null)
            {
               sValue = DHTMLElement.filterDataChar(obj.toString());
               sValue.trim();
            }
         }

         data.addRow(buildRow(sAttr, sValue));
      }
   }
   
   private DHTMLArray buildRow(String attrName, String value)
   {
      DHTMLArray dataArray = new DHTMLArray();
      
      dataArray.addElement(new DHTMLData(attrName, null, null));
      dataArray.addElement(new DHTMLData(value, null, null));
      
      return dataArray;
   }

   
   /**
    * Renders an HTML table that contains records from the View Object's RowSet.
    * This is the View Object to which the RowSetBrowser object was initialized.
    */
   public void render()
      throws Exception
   {
      // Specify the library here instead of having the WebBean do it because the order is important
      initBeanForJS(WebBean.JSTableConstructLib|WebBean.JSDataConstructLib);
      data.render();         
      table.render();         
      // Need to reset the bottom
      for (int i=0; i < data.numberOfElements() + 2; i++)
      {
         out.print("<BR>");
      }
      releaseApplicationResources();
   }
}


