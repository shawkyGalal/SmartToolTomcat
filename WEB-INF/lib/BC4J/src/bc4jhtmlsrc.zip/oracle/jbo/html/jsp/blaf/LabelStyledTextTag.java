/*
 * @(#)LabelStyledTextTag.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.html.jsp.blaf;


import oracle.cabo.ui.MutableUINode;


public class LabelStyledTextTag extends JboStyledTextTag 
{
   /**
    * Constructor
    */
   public LabelStyledTextTag() {
   }

    /**
    * initializeProperties
    */
   public void setProperties(MutableUINode node) 
   {
      String sItem = getDataitem();

      //TODO if(getLabeledNodeId() == null)
      {
         setLabeledNodeId(sItem);        
      }

      // add the uihints suffixe to the data item name
      sItem = "UIHINT:LABEL:" + sItem;

      setDataitem(sItem);

      super.setProperties(node);
   }
}

 