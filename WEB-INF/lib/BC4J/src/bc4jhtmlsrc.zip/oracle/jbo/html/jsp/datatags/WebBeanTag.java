/*
 * @(#)WebBeanTag.java
 *
 * Copyright 2000-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.html.jsp.datatags;

import java.io.PrintWriter;
import java.io.StringWriter;
import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspTagException;
import javax.servlet.jsp.tagext.Tag;
import javax.servlet.jsp.tagext.TagSupport;
import oracle.jbo.common.JBOClass;
import oracle.jbo.html.WebBean;

public class WebBeanTag extends TagSupport
{
   protected String sClass;
   protected WebBean wb;

   public WebBeanTag()
   {
      super();
      reset();
   }

   public void setWbclass(String sClass)
   {
      this.sClass = sClass;
   }

   protected void initializeBean()
      throws Exception
   {
      wb.initialize(pageContext);
   }

   public int doStartTag() throws JspException
   {
      try
      {
         final Class wbClass = JBOClass.forName(sClass);
         wb = (WebBean) wbClass.newInstance();
      }
      catch (Exception ex)
      {
         throw new JspTagException(ex.getMessage());
      }
      
      
      ((WebBean)wb).setUsedInTag(true);

      pageContext.setAttribute(id, wb);
      
      return Tag.EVAL_BODY_INCLUDE;
   }

   public int doEndTag() throws JspException
   {
      try
      {
         initializeBean();
      }
      catch (Exception ex)
      {
         StringWriter writer = new StringWriter();
         PrintWriter prn = new PrintWriter(writer);

         ex.printStackTrace(prn);
         prn.flush();

         throw new JspTagException(writer.toString());
      }

      reset();
      return EVAL_PAGE;
   }

   private void reset()
   {
      wb = null;
   }
   
}

