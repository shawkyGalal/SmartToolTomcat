/*
 * @(#)CriteriaTag.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.html.jsp.datatags;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.tagext.Tag;
import javax.servlet.jsp.tagext.TagSupport;
import oracle.jbo.JboException;
import oracle.jbo.ViewCriteriaRow;

public class CriteriaTag extends TagSupport
{
   protected String sDataItem;
   protected String sValue;

   public CriteriaTag()
   {
      super();
      reset();
   }

   public void setDataitem(String sValue)
   {
      this.sDataItem = sValue;
   }

   public void setValue(String sValue)
   {
      if (sValue != null)
      {
         sValue.trim();
         if (sValue.length() == 0)
         {
            sValue = null;
         }
      }
         
      this.sValue = sValue;
   }

   public int doStartTag() throws JspException
   {
      final CriteriaRowTag criteriaRowTag = (CriteriaRowTag) TagSupport.findAncestorWithClass(this, CriteriaRowTag.class);

      if (criteriaRowTag == null)
      {
         throw new JboException(Res.getString(Res.CRITERIA_ONLY_IN_CRITERIAROW));
      }

      final ViewCriteriaRow vr = criteriaRowTag.getViewCriteriaRow();
      if (vr != null)
      {
         vr.setAttribute(sDataItem, sValue);
      }

      return Tag.SKIP_BODY;
   }

   public int doEndTag() throws JspException
   {
      reset();
      return Tag.EVAL_PAGE;
   }
   
   // Use by the constructor and the release method to reset the member variable values
   private void reset()
   {
      sDataItem = null;
      sValue = null;
   }
  
}
