/*
 * @(#)HTMLParser.java
 *
 * Copyright 1999-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.html.htmldrv;

import java.io.*;
import java.io.*;
import java.net.*;
import java.util.*;
import javax.swing.*;
import javax.swing.tree.*;
import oracle.jbo.server.*;

/**
 *
 * @version INTERNAL
 */
public class HTMLParser
{
   IHTMLParserNode         rootNode    = null;
   
/*   public void populateTree(HTMLTree aTree) throws Exception
   {
      //aTree.add(rootNode);
      aTree.setParserRootNode(rootNode);
      
      HTMLTreeNode aNode = new HTMLTreeNode(aTree.getApplication(), null,"Application");
      HTMLTreeNode adsNode = new HTMLTreeNode(aTree.getApplication(),null,"Data Sources");

      aTree.setModel(new DefaultTreeModel(aNode, false));
      
      // add data sources to tree
      aNode.add(adsNode);

      aTree.setDataSourcesNode(adsNode);
      
      rootNode.populateTree(aTree, aNode);
   }
*/
   // compiles the stream and returns the root token group
   public IHTMLParserNode parse(String sdocName , InputStream strm) throws Exception, FileNotFoundException, MalformedURLException
   {
      BufferedReader    htmlFile    = new BufferedReader(new InputStreamReader(strm));
      HTMLTokenizer     tokens      = new HTMLTokenizer(htmlFile);

      rootNode    = new HTMLBaseNode(tokens, null);
      rootNode.setNodeTag(sdocName);

      // traverse all root tokens and create a token handler,
      // the token handler will eat up all the relevant tokens before it returns
      processTokens(tokens , rootNode, "HTML Document");

      return rootNode;

   }


  public int processJboTag(HTMLTokenizer tokens , IHTMLParserNode tkParentGroup)
  {
    try
    {
       JBOHTMLNode jboHTMLNode;// = new HTMLNode(tokens, tkParentGroup);
       String      sTagName;
       
       jboHTMLNode = new JBOHTMLNode(tokens, tkParentGroup);

       int nToken = tokens.nextToken();
       sTagName = tokens.sval;
       
       jboHTMLNode.setNodeTag(tokens.sval);
       nToken = tokens.nextToken();

       while(tokens.ttype != tokens.TT_ENDJBOTAG)
       {
          jboHTMLNode.addToken(tokens);
          nToken = tokens.nextToken();
       }

       if(sTagName.equalsIgnoreCase("EndFor"))
         return tokens.TT_ENDFOR;
       
       return 0;
    }
    catch(Exception ex)
    {
       ex.printStackTrace();
    }
    return 0;
  }
  
  void processTokens(HTMLTokenizer tokens , IHTMLParserNode tkParentGroup, String endTag) throws Exception
   {
      int              nToken      = 0;
      HTMLCharset      tkHTMLNode = null;
      IHTMLParserNode  tagNode =  null;
      String           nodeTag;

      nToken = tokens.nextToken();

      while(nToken != tokens.TT_EOF)
      {
        switch(tokens.ttype)
        {
                case tokens.TT_STARTTAG:
                {
                   tkHTMLNode = null;
                   // get handler for this tag, if we don't have one, use the default
                   IHTMLTagHandler tagHandler = HTMLHandlerFactory.getTagHandler(tokens.TagName);

                   if(tagHandler != null)
                   {
                      tagNode = tagHandler.createTagNode(this , tokens , tkParentGroup);
                   }

                  break;
                }
                case tokens.TT_ENDTAG:
                {
                     if(endTag!= null && tokens.TagName.equalsIgnoreCase(endTag))
                     {
                           return;
                     }
                     tokens.nextToken();
                     break;
                }
                case tokens.TT_STARTJBOTAG:
                {
                     
                     processJboTag(tokens , tkParentGroup);
                     
                     break;
                }
                default:
                {
                   //if(tokens.ttype != tokens.TT_EOL)
                   {
                      if( tkHTMLNode == null)
                        tkHTMLNode = new HTMLCharset(tokens, tkParentGroup);

                      tkHTMLNode.addToken(tokens);
                   }
                }
        }


        nToken = tokens.nextToken();
      }
   }

   void processTokensUntilToken(HTMLTokenizer tokens , IHTMLParserNode tkParentGroup, int nTermintator) throws Exception
   {
      int              nToken      = 0;
      HTMLCharset      tkHTMLNode = null;
      IHTMLParserNode  tagNode =  null;
      String           nodeTag;

      nToken = tokens.nextToken();

      while(nToken != tokens.TT_EOF && nToken != nTermintator)
      {
        switch(tokens.ttype)
        {
                case tokens.TT_STARTTAG:
                {
                   tkHTMLNode = null;
                   // get handler for this tag, if we don't have one, use the default
                   IHTMLTagHandler tagHandler = HTMLHandlerFactory.getTagHandler(tokens.TagName);

                   if(tagHandler != null)
                   {
                      tagNode = tagHandler.createTagNode(this , tokens , tkParentGroup);
                   }

                  break;
                }
                case tokens.TT_STARTJBOTAG:
                {

                     processJboTag(tokens , tkParentGroup);

                     tkHTMLNode = new HTMLCharset(tokens, tkParentGroup);
                     
                     break;
                }
                default:
                {
                   //if(tokens.ttype != tokens.TT_EOL)
                   {
                      if( tkHTMLNode == null)
                        tkHTMLNode = new HTMLCharset(tokens, tkParentGroup);

                      tkHTMLNode.addToken(tokens);
                   }
                }
        }


        nToken = tokens.nextToken();
      }
      if(nToken == nTermintator)
      {
         if( tkHTMLNode == null)
           tkHTMLNode = new HTMLCharset(tokens, tkParentGroup);

         tkHTMLNode.addToken(tokens);
      }
   }

   void processTokensUntilEndFor(HTMLTokenizer tokens , IHTMLParserNode tkParentGroup) throws Exception
   {
      int              nToken      = 0;
      HTMLCharset      tkHTMLNode = null;
      IHTMLParserNode  tagNode =  null;
      String           nodeTag;

      nToken = tokens.nextToken();

      while(nToken != tokens.TT_EOF)
      {
        switch(tokens.ttype)
        {
                case tokens.TT_STARTTAG:
                {
                   tkHTMLNode = null;
                   // get handler for this tag, if we don't have one, use the default
                   IHTMLTagHandler tagHandler = HTMLHandlerFactory.getTagHandler(tokens.TagName);

                   if(tagHandler != null)
                   {
                      tagNode = tagHandler.createTagNode(this , tokens , null);

                      if(tagNode.getNodeTag().equalsIgnoreCase("EndFor"))
                        return;

                      // only parent the node if it's not an {%Endfor%} node  
                      tkParentGroup.addChildNode(tagNode);
                   }

                  break;
                }

                case tokens.TT_STARTJBOTAG:
                {
                     processJboTag(tokens , tkParentGroup);
                     
                     break;
                }
                case tokens.TT_ENDJBOTAG:
                {
                     //throw new Exception("Not Expecting an end tag");

                     break;
                }
                default:
                {
                   //if(tokens.ttype != tokens.TT_EOL)
                   {
                      if( tkHTMLNode == null)
                        tkHTMLNode = new HTMLCharset(tokens, tkParentGroup);

                      tkHTMLNode.addToken(tokens);
                   }
                }
        }


        nToken = tokens.nextToken();
      }
   }

}

