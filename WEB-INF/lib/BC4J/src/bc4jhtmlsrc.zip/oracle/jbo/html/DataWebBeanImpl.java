/*
 * @(#)DataWebBeanImpl.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.html;

import java.io.PrintWriter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.jsp.PageContext;
import oracle.jbo.html.DataSource;

/**
 * Implements the base methods for a Data Web Bean. Extend this class when you
 * define a Web Bean that must access a data source and that does not need to
 * extend another class.
 */
public class DataWebBeanImpl extends oracle.jdeveloper.html.DataWebBeanImpl implements oracle.jbo.html.DataWebBean, oracle.jbo.html.WebBean
{
	public DataWebBeanImpl()
	{
	}

	// This method is used internally when the DataWebBean is use in
   // the context of the DataWebBeanTag. This we already have the datasource in
   // the tag we don't need to create a new instance of it.
   public void initialize(PageContext page, DataSource dsFromTag) throws Exception
   {
      this.page = page;
      this.ds = dsFromTag;
      this.amName = ds.getApplicationModule().getName();
      
      super.initialize(page.getServletContext(), page.getSession(), (HttpServletRequest) page.getRequest(),
            (HttpServletResponse) page.getResponse(), new PrintWriter(page.getOut()));
   }

   public void setUsedInTag(boolean isUsedInTag)
   {
      bUsedInTag = isUsedInTag;
   }

}
