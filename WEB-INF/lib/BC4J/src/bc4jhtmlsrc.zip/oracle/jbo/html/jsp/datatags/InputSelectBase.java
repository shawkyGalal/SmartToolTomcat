/*
 * @(#)InputSelectBase.java
 *
 * Copyright 2000-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.html.jsp.datatags;

import javax.servlet.jsp.JspException;

import oracle.jbo.html.DataSource;
import oracle.jdeveloper.html.HTMLFieldRenderer;
import oracle.jdeveloper.html.LOVFieldContext;
import oracle.jdeveloper.html.PickList;
import oracle.jdeveloper.html.PickListContext;

public class InputSelectBase extends InputTagBase
{
   protected String sDataAttribute;
   protected String sDisplayAttribute;
   protected String sDisplaySource;
   protected String sControlType;
   protected String sFormName;
   protected boolean bUseLineBreaks;
   protected int    showNone;
   
   public InputSelectBase()
   {
      super();
      reset();
   }

   public HTMLFieldRenderer getFieldRenderer()
   {
      final HTMLFieldRenderer rField = new PickList();

      initializeFieldRenderer(rField);

      return rField;
   }

   public void setFormname(String sValue)
   {
      this.sFormName = sValue;
   }

   public void setDisplayvaluedataitem(String sValue)
   {
      this.sDataAttribute = sValue;
   }

   public void setDisplaydataitem(String sValue)
   {
      this.sDisplayAttribute = sValue;
   }

   public void setDisplaydatasource(String sValue)
   {
      this.sDisplaySource = sValue;
   }

   public String getControlType()
   {
      return sControlType;
   }

   public void setLinebreaks(String sValue)
   {
      bUseLineBreaks = Utils.isTrue(sValue);
   }

   public void setShownone(String sValue)
   {
      showNone = Utils.isTrue(sValue) ? 1 : 0;
   }

   public void internalInitialize()
   {
      super.internalInitialize();
   
      // locate the data source
      final DataSource displayDs = Utils.getDataSourceFromContext(pageContext, sDisplaySource);

      if (sFormName != null)
         rndObj.setFormName(sFormName);
      
      if (rndObj instanceof LOVFieldContext)
      {
         LOVFieldContext ctx = (LOVFieldContext)rndObj;
         ctx.setLovVo(displayDs.getViewObjectName());
         ctx.setDataAttributes(sDataAttribute);
         ctx.setDisplayAttributes(sDisplayAttribute);
      }
      
      if (rndObj instanceof PickListContext)
      {
         PickListContext ctx = (PickListContext)rndObj;
         ctx.setControlType(getControlType());
         ctx.setUseLineBreaks(bUseLineBreaks);
         ctx.setDataSourceInfo(displayDs.getRowSet());
         ctx.setDataAttributes(sDataAttribute);
         ctx.setDisplayAttributes(sDisplayAttribute);
         if (showNone != -1)
         {
            ctx.setAllowNulls(showNone > 0);
         }
      }
   }

   public int doEndTag() throws JspException
   {
      reset();
      return super.doEndTag();
   }
   
   private void reset()
   {
      sDataAttribute = null;
      sDisplayAttribute = null;
      sDisplaySource = null;
      sControlType = "RADIOGROUP";
      sFormName = null;
      showNone = -1;
      bUseLineBreaks = true;
   }
   
}

