/*
 * @(#)JboTableTag.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.html.jsp.blaf;

import oracle.cabo.ui.beans.table.TableBean;
import oracle.cabo.ui.data.DataObjectList;
import oracle.jbo.html.DataSource;
import oracle.jbo.html.jsp.datatags.Utils;
import oracle.cabo.ui.jsps.tags.TableTag;
import javax.servlet.jsp.PageContext;
import oracle.cabo.ui.UIConstants;
import java.util.StringTokenizer;
import java.util.Vector;

public class JboTableTag extends TableTag
{
   String      _datasource;
   Vector      _displayAttributes = null;
   
   public JboTableTag() {
   }

   public String getDatasource()
   {
      return _datasource;
   }

   public String getDataSource()
   {
      return _datasource;
   }

   public void setDisplayattributes(String sAttributes)
   {
      if(sAttributes == null)
        _displayAttributes = null;

      StringTokenizer tokens = new StringTokenizer(sAttributes, ",", false);

      _displayAttributes = new Vector();

      while(tokens.hasMoreTokens())
      {
        String sAttribute = tokens.nextToken();
        _displayAttributes.add(sAttribute);
      }
   }
   
   public void setDatasource(String newDatasource)
   {
      _datasource = newDatasource;
   }

   private String getName()
   {
     return (String)getAttributeValue(UIConstants.NAME_ATTR);
   }

   private String getSummary()
   {
     return (String)getAttributeValue(UIConstants.SUMMARY_ATTR);
   }
   
   /**
    * releaseBean
    */
   public void release()
   {
      super.release();

      _datasource = null;
      _displayAttributes = null;
   }

  public int doStartTag()
  {
    int nRet = super.doStartTag();

    if(_datasource == null)
         return nRet;

      TableBean table = (TableBean)this.getUINode();
      
      if(getSummary() == null)
      {
         table.setSummary(_datasource);
      }


      if(getName() == null)
        table.setName(_datasource);      

          
      JboUtil.configureTableFromDataSource(getPageContext(), _datasource, table);

      DataObjectList dataObj = (DataObjectList)JboUtil.getCaboDataSource(getPageContext(), _datasource);
      
      if(dataObj != null)
      {
         table.setTableData(dataObj);

         // setup from data source parameters
         DataSource ds = Utils.getDataSourceFromContext(getPageContext(), _datasource);

         DataObjectList attrDataObj = new RowSetAttributesDataObjectList(ds.getRowSet(), _displayAttributes);

         table.setColumnHeaderData(attrDataObj);
      }
      
    return nRet;
  }

   protected PageContext getPageContext()
   {
      return super.getPageContext();
   }
}

