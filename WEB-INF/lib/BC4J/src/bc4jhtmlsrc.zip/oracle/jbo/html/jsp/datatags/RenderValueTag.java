/*
 * @(#)RenderValueTag.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.html.jsp.datatags;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspTagException;
import javax.servlet.jsp.tagext.Tag;
import oracle.jbo.JboException;
import oracle.jdeveloper.html.HTMLFieldRenderer;

public class RenderValueTag extends ShowValueTag
{
   public int doStartTag() throws JspException
   {
      internalInitialize();
      
      if (attrDef != null)
      {
         final HTMLFieldRenderer rndObj = ds.getDisplayFieldRenderer(pageContext, row, attrDef);
         try
         {
            pageContext.getOut().print(rndObj.renderToString(row));
         }
         catch (java.io.IOException ex)
         {
            pageContext.getServletContext().log(Res.getString(Res.IO_ERROR), ex);
            throw new JspTagException(ex.getMessage());
         }
      }
      else
      {
         throw new JboException(Res.getString(Res.NEED_DATAITEM));
      }
      
      return Tag.SKIP_BODY;
   }
}
