/*
 * @(#)HDIterator.java
 *
 * Copyright 1998-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.html.htmldrv;

import java.io.*;
import java.util.*;
import oracle.jbo.expr.JIException;
import oracle.jbo.html.*;
import oracle.jdeveloper.html.parser.*;

public class HDIterator
{
   private boolean firstFlag = true;
   private HDFile hFile = null;
   private IHTMLParserNode curNode = null;

   public HDIterator(HDFile hf)
   {
      hFile = hf;
      curNode = hFile.getRootNode();
   }
   
   public HDFile getHDFile()
   {
      return hFile;
   }
   
   public IHTMLParserNode getCurNode()
   {
      firstFlag = false;
      return curNode;
   }
   
   public IHTMLParserNode next()
   {
      if (firstFlag)
      {
         return getCurNode();
      }
      
      if (curNode == null)
      {
         return null;
      }
      
      Vector childVec = curNode.getChildNodes();
      
      if (childVec != null && childVec.size() > 0)
      {
         curNode = (IHTMLParserNode) childVec.elementAt(0);
      }
      else
      {
         IHTMLParserNode parNode = curNode.getParent();
         boolean foundNext = false;
         
         while (true)
         {
            if (parNode == null)
            {
               curNode = null;
               break;
            }

            childVec = parNode.getChildNodes();

            if (childVec != null && childVec.size() > 0)
            {
               int indx = childVec.indexOf(curNode);
               
               if (indx >= 0)
               {
                  if (indx + 1 < childVec.size())
                  {
                     curNode = (IHTMLParserNode) childVec.elementAt(indx + 1);
                     break;
                  }
               }
               else
               {
                  throw new JIException("Unexpected error in HDIterator.next()");
               }
            }
            
            curNode = parNode;
            parNode = curNode.getParent();
         }
      }
      
      return curNode;
   }
   
/*******************
   public Object getIdentVal(String varExpr)
   {
      Object retVal = null;
      int indx = varExpr.indexOf('.');
      String firstPart;
      String rest = null;

      if (indx >= 0)
      {
         firstPart = varExpr.substring(0, indx);
         rest = varExpr.substring(indx + 1);
      }
      else
      {
         firstPart = varExpr;
      }

      if (firstPart.equals("current") ||
          firstPart.equals("next"))
      {
         if (firstPart.equals("next"))
         {
            next();
         }
         
         if (rest == null)
         {
            retVal = getCurNode();
         }
         else
         {
            // retVal = getCurNode().getIdentVal(rest);
         }
      }
      
      return retVal;
   }
*******************/

   public String toString()
   {
      return "iterator over " + getHDFile().getFileName();
   }
}
