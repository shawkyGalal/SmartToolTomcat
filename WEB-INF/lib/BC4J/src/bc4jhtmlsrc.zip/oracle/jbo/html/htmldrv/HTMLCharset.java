/*
 * @(#)HTMLCharset.java
 *
 * Copyright 1999-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.html.htmldrv;

import java.awt.*;
import java.io.*;
import java.io.*;
import java.net.*;
import java.util.*;
import javax.swing.*;
import javax.swing.tree.*;
import oracle.jbo.server.*;

public class HTMLCharset extends HTMLBaseNode
{

  public HTMLCharset(HTMLTokenizer tokens, IHTMLParserNode parent)
   {
      super(tokens, parent);
   }

  public HTMLCharset(IHTMLParserNode parent)
   {
      super(null, parent);
   }

  public void populateWriter(PrintWriter out) throws Exception
  {
      int            nElem = tokens.size();
      IHTMLParserNode node;

      //aText.append("<");
      for(int i  = 0 ; i < nElem ; i++)
      {
         out.print((String)tokens.elementAt(i));
      }
      //aText.append(">\n");

      // node render the child nodes
      nElem = nodes.size();

      for(int i  = 0 ; i < nElem ; i++)
      {
         node = (IHTMLParserNode)nodes.elementAt(i);
         node.populateWriter(out);
      }

  }

}