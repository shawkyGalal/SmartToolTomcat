/*
 * @(#)PostChangesTag.java
 *
 * Copyright 2000-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.html.jsp.datatags;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.tagext.Tag;
import javax.servlet.jsp.tagext.TagSupport;
import oracle.jbo.ApplicationModule;
import oracle.jbo.common.ampool.ApplicationModuleRef;

public class PostChangesTag extends TagSupport
{
   protected String amId; // Required attribute

   public void setAppid(String amId)
   {
      this.amId = amId;
   }

   public int doStartTag() throws JspException
   {                               
      final ApplicationModuleRef amRef = Utils.getAMRefFromContext(pageContext, amId);
      final ApplicationModule am = amRef.useApplicationModule();
      am.getTransaction().postChanges();
      
      return Tag.EVAL_BODY_INCLUDE;
   }

}
