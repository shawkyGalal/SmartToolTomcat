/*
 * @(#)SetAttributeTag.java
 *
 * Copyright 2000-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.html.jsp.datatags;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.tagext.Tag;
import oracle.jbo.LocaleContext;
import oracle.jbo.html.HtmlServices;
import oracle.jbo.html.RequestParameters;

public class SetAttributeTag extends DataTagBase
{
   protected String sValue;
   protected boolean useMultipartForm;

   public SetAttributeTag()
   {
      super();
      reset();
   }

   public void setValue(String sValue)
   {
      this.sValue = sValue;
   }

   public void setUsemultipartformat(String sValue)
   {
      useMultipartForm = Utils.isTrue(sValue);
   }

   /**
    * doStartTag
    * @return int
    * @exception javax.servlet.jsp.JspException
    */
   public int doStartTag() throws JspException
   {
      RequestParameters params = null;

      internalInitialize();

      if (!("*".equals(sDataItem)))
      {
         LocaleContext locale = ds.getApplicationModule().getSession().getLocaleContext();

         if (attrList != null)
         {
            // First set the value to the subAttribute
            attrList.setAttribute(sSubAttrName, sValue);

            // Then set the new attribute list
            row.setAttribute(sAttrName, attrList);
         }
         else
         {
            row.setAttribute(attrDef.getIndex(), attrDef.getUIHelper().parseFormattedAttribute(sValue, locale));
         }
      }
      else
      {
         RowTag.updateRowAttributesFromRequestParameters(ds, row, pageContext, HtmlServices.getRequestParameters(pageContext));
      }

      return Tag.SKIP_BODY;
   }

   public int doEndTag() throws JspException
   {
      reset();
      return super.doEndTag();
   }
   
   
   // Use by the constructor and the release method to reset the member variable values
   private void reset()
   {
      sValue = null;
      useMultipartForm = false;
   }

}

