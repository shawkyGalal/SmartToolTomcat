/*
 * @(#)RowSetBrowser.java
 *
 * Copyright 1999-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.html.databeans;

import java.util.Hashtable;
import java.util.Vector;
import oracle.jbo.AttributeDef;
import oracle.jbo.Row;
import oracle.jbo.RowSet;
import oracle.jdeveloper.html.HTMLImageURL;
import oracle.jdeveloper.html.HTMLTableRow;
import oracle.jdeveloper.html.HTMLTextURL;
import oracle.jdeveloper.html.HTMLFieldRenderer;
import oracle.jdeveloper.jsp.wb.TableControl;

/**
 * The RowSetBrowser Data Web Bean class dynamically generates an HTML
 * table that contains records (rows) from a View Object's RowSet.
 * The subset of the rows in the View Object's RowSet that are rendered to
 * the JSP page's output stream is based on the RangeSize and the position of the
 * View Object's current row.
 * <P>
 * JDeveloper's JSP Element wizard instantiates the <TT>RowSetBrowser</TT>
 * class in a <TT>jsp:useBean</TT> tag in a <TT>.jsp</TT> file. Along with the
 * class, the wizard also includes an ID and a scope declaration set to
 * <TT>request</TT>.
 * If you change the scope to any other value, you will have
 * to handle possible multithreading issues.
 * <P>
 * The definition of a
 * RowSet browser provided by the wizard includes these methods:
 * <TT>setUseRoundedCorners</TT>, <TT>setShowCurrentRow</TT>, <TT>setVisibleRows</TT>,
 * <TT>setAlternateColors</TT>,
 * <TT>setShowRecordNumbers</TT>, <TT>setReleaseApplicationResources</TT>,
 * <TT>initialize</TT>, and <TT>render</TT>. For example:
 * <PRE>
 * &lt;jsp:useBean class="oracle.jbo.html.databeans.RowSetBrowser" id="rbDetail"
 *    scope="request" &gt;
 * &lt;%
 *     rbDetail.setUseRoundedCorners(true);
 *     rbDetail.setShowCurrentRow(true);
 *     rbDetail.setVisibleRows(10);
 *     rbDetail.setAlternateColors(true);
 *     rbDetail.setShowRecordNumbers(true);
 *     rbDetail.initialize(application,session, request,response,out,
 *            "DeptToEmp_DeptToEmpModule.EmpView");
 *     rbDetail.render();
 * %&gt;
 * &lt;/jsp:useBean&gt;
 * </PRE>
 * <P>
 * Using the <TT>setDisplayAttributes</TT> method inherited from
 * <TT>DataWebBeanImpl</TT>, you can set the attributes displayed by the HTML table.
 *
 *
 **/
public class RowSetBrowser extends oracle.jbo.html.DataWebBeanImpl
{
   protected int        nVisibleRows = 10;
   protected boolean    bAlternateColors = true;
   protected String     sRowUrl = null;
   protected boolean    bShowCurrentRow = true;
   protected String     sRowUrlTarget = null;
   protected Vector     extraUrlCols = new Vector();
   protected boolean    useRoundedCorners = true;
   protected boolean    showRecordNumber = false;
   protected Hashtable  colTitles = new Hashtable();
   protected String     sRowEditUrl = null;
   protected String     ImageDir = "/webapp/images/";
   protected String     sRowEditTarget = null;
   protected boolean    nVisibleRowsWasChanged = false;
   protected TableControl aTable = null;

   public RowSetBrowser()
   {
   }


   /**
   * Specifies the path of the image root directory where all of the
   * browser's images
   * reside. The Web Bean will prepend this path to all images it tries
   * to retrieve.
   * <p>
   * @param sDir path to the image root directory.
   */
   public void setImageDir(String sDir)
   {
      ImageDir = sDir;
   }

   /**
   * Returns the path of the image root directory where all of the
   * browser's images reside. The Web Bean will prepend this path to all
   * images it tries to retrieve.
   * <p>
   * @return path to the image root directory.
   */
   public String getImageDir()
   {
      return ImageDir;
   }

   /**
   * Sets the row editing URL that is invoked when the user clicks the Edit
   * button. Typically, an "Action" column will be created in the table,
   * containing an Edit icon. Set the URL to the JSP page itself
   * if you want to do in-place editing. If this URL is set
   * to null, the column will not appear.
   * <p>
   * @param sUrl URL where the row can be edited.
   **/
   public void setRowEditUrl(String sUrl)
   {
      sRowEditUrl = sUrl;
   }

   /**
   * Sets the name of the target frame or window where the
   * row-editing URL is displayed. When the user clicks the "Edit" buttom
   * a secondary window will open where the row can be edited.
   * <P>
   * This method is necessary only
   * if you are using HMTL Frames.
   * <p>
   * @param sName name of the target window.
   */
   public void setRowEditTargetWindow(String sName)
   {
      sRowEditTarget = sName;
   }

   /**
   *    Sets the column title of the given attribute.
   * <p>
   *    @param sAttribute       attribute name.
   *    @param sTitle           column title for attribute.
   */
   public void setAttributeTitle(String sAttribute , String sTitle)
   {
      colTitles.put(sAttribute , sTitle);
   }


   /**
   * Sets whether the control will render the record numbers in the browser.
   * <p>
   * @param bShow <TT>true</TT> to display record number; <TT>false</TT> to
   * suppress record numbers.
   */
   public void setShowRecordNumbers(boolean bShow)
   {
      showRecordNumber = bShow;
   }

   /**
   * Enables or disables the use of rounded corners in the HTML table generated
   * by this Web Bean.
   * <p>
   * @param bSet <TT>true</TT> use rounded corners; <TT>false</TT> use squared corners.
   */
   public void setUseRoundedCorners(boolean bSet)
   {
      useRoundedCorners = bSet;
   }

   /**
   * Adds an additional column that contains a line of text that represents a URL.
   * The text will be repeated in each of the column's rows.
   * This column will be appended after all of the
   * columns that represent attributes belonging to the RowSet. The
   * <TT>sTarget</TT> parameter specifies a secondary window or frame
   * that will open when the URL is activated.
   * <p>
   *    @param sTitle   text to use as the column title.
   *    @param sText    text that will be used to represent the URL.
   *    @param sUrl     URL that will be invoked when text is clicked.
   *    @param sTarget  the target for the URL. This is useful when you are using HTML FRAMES.
   */
   public void addTextUrlColumn(String sTitle, String sText, String sUrl , String sTarget)
   {
      extraUrlCols.addElement(new TextColumnUrlInfo(sTitle, sText, sUrl , sTarget));
   }

   /**
   * Adds an additional column that contains a line of text that represents a URL.
   * The text will be repeated in each of the column's rows.
   * This column will be
   * appended after all of the
   * columns that represent attributes belonging to the RowSet.
   * <p>
   *    @param sTitle   text to use as the column title.
   *    @param sText    text that will be used to represent the URL.
   *    @param sUrl     URL that will be invoked when text is clicked.
   */
   public void addTextUrlColumn(String sTitle, String sText, String sUrl)
   {
      addTextUrlColumn(sTitle , sText, sUrl , null);
   }

   /**
   * Adds an additional column with an image-based URL. This image will be
   * repeated in each of the column's rows.
   * This column will be
   * appended after all of the columns that represent attributes belonging to
   * the RowSet. The
   * <TT>sTarget</TT> parameter specifies a secondary window or frame
   * that will open when the URL is activated.
   * <p>
   *    @param sTitle   text to use as the column title.
   *    @param sImageFile   URL for locating the image to be displayed.
   *    @param sUrl     URL that will be invoked when image is clicked.
   *    @param sTarget  the target for the URL. This is useful when you are using HTML FRAMES.
   */
   public void addImageUrlColumn(String sTitle, String sImageFile, String sUrl , String sTarget)
   {
      extraUrlCols.addElement(new ImageUrlInfo(sTitle, sImageFile, sUrl , sTarget));
   }

   /**
   * Adds an additional column with an image-based URL. This image will be
   * repeated in each of the column's rows.
   * This column will be
   * appended after all of the columns that represent attributes belonging to
   * the RowSet.
   * <p>
   *    @param sTitle   text to use as the column title.
   *    @param sImageFile   URL for locating the image to be displayed.
   *    @param sUrl     URL that will be invoked when text is clicked.
   */
   public void addImageUrlColumn(String sTitle, String sImageFile, String sUrl)
   {
      addImageUrlColumn(sTitle, sImageFile, sUrl , null);
   }

   /**
   *  If you enabled the Row URL, this function sets up the target window for
   * the URL when the user activates it.
   */
   public void setRowUrlTargetWindow(String sUrl)
   {
      sRowUrlTarget = sUrl;
   }

   /**
   * Returns the name of the window being used as the Row URL target.
   * <p>
   *    @return name of the window used as the Row URL target.
   */
   public String getRowUrlTargetWindow()
   {
      return sRowUrlTarget;
   }

   /**
   * Sets the Row URL to be invoked when the user clicks the row number to
   * the left of each row.
   * An additonal parameter is appended to your URL to pass the row
   * number of the row
   * that was clicked. The <TT>RowSetNavigator</TT> and <TT>NavigatorBar</TT>
   * Data Web Beans process
   * the extra URL parameter to place the RowSet currency on the
   * row represented by this index.
   * <p>
   * @param sUrl Row URL to be invoked
   */
   public void setRowUrl(String sUrl)
   {
      sRowUrl = sUrl;
   }

   /**
   * Returns the current Row URL setting. The value can be null.
   * <p>
   *    @return current Row URL.
   */
   public String getRowUrl()
   {
      return sRowUrl;
   }

   /**
   *  Enables or disables highlighting of the current RowSet's row when the HTML
   *  table is rendered.
   * <p>
   * @param bSet <TT>true</TT> to highlight the current RowSet row; <TT>false</TT>
   *  to not highlight the row.
   */
   public void setShowCurrentRow(boolean bSet)
   {
      bShowCurrentRow = bSet;
   }

   /**
   * Returns whether the current RowSet row is highlighted when the HTML
   *  table is rendered.
   * <p>
   *   @return <TT>true</TT> if the current row is highlighted;
   * <TT>false</TT> otherwise.
   */
   public boolean getShowCurrentRow()
   {
      return bShowCurrentRow;
   }

   /**
   * Sets both the number of rows to be displayed by
   * the RowSet browser and the RowSet's RangeSize.
   * It is important that this method also sets the RangeSize, because it
   * is the sliding
   * window used to traverse the RowSet. If you set the visible rows to
   * -1 all the rows will be displayed.
   * <p>
   * @param nRows number of rows to display in the RowSet browser and the
   * RowSet's RangeSize.
   *
   *  NOTE:
   *     The setVisibleRows() temporarily changes the display set of rows, but it 
   *     doesn't make this change permanent to the rowset's RangeSize. If you need to make the
   *     change permanent you need to use dwb.getRowSet().setRangeSize(50) prior to rendering.
   *
   */
   public void setVisibleRows(int nRows)
   {
      nVisibleRows = nRows;
      nVisibleRowsWasChanged = true;
   }

   /**
   * Returns the number of rows displayed
   * (that is, "visible rows") in the RowSet
   * browser, which is also the value of the RowSet's RangeSize.
   * <p>
   * @return the number of rows displayed in the RowSet browser, which is also the
   *    value of the RowSet's RangeSize.
   */
   public int getVisibleRows()
   {
      return nVisibleRows;
   }

   /**
   * Displays rows in alternating background colors in the generated HTML table.
   * <p>
   * @param bSet <TT>true</TT> to display rows in alternating background colors;
   * <TT>false</TT> to display rows in a single background color.
   */
   public void setAlternateColors(boolean bSet)
   {
      bAlternateColors = bSet;
   }



   /**
   ** Returns the instance of the table class the is to be used for rendering
   **
   **/
   public TableControl getTableControl()
   {
      if (aTable == null)
         aTable    =  new TableControl();
      return aTable;
   }


   protected void renderTableHeaders() throws Exception
   {
      int                attrNo;
      String             sHeader;
      TableControl       aTable    =  getTableControl();
      AttributeDef[]     dattrs    =  getDisplayAttributeDefs();
      int                RowTag;

      if (showRecordNumber)
         aTable.addHeader("Rec#");

      if (sRowEditUrl != null)
      {
         aTable.addHeader("Action");
      }

      for (attrNo = 0; attrNo < dattrs.length ; attrNo++)
      {
         if (!shouldDisplayAttribute(dattrs[attrNo]))
            continue;

         sHeader = dattrs[attrNo].getName();

         sHeader = ds.getAttributeLabel(dattrs[attrNo]);

         // see if the user wants a different title
         if (colTitles.get(sHeader) != null)
            sHeader = (String)colTitles.get(sHeader);

         aTable.addHeader(sHeader);
      }

      // add headers for extra columns
      for (int nExtra = 0 ; nExtra < extraUrlCols.size() ; nExtra++)
      {
         TextColumnUrlInfo info = (TextColumnUrlInfo)extraUrlCols.elementAt(nExtra);
         aTable.addHeader(info.getTitle());
      }
   }


   protected boolean initializeNewTableRow(HTMLTableRow htmlRow, Row[]   drows, int rowno, boolean isEven)
   {
      String  sRowKey;
      int     RowTag;
      RowSet  rs = ds.getRowSet();
      Row     currentRow = rs.getCurrentRow();

      sRowKey = getRowKey(drows[rowno]);

      if (bAlternateColors)
      {
         if (isEven)
         {
            htmlRow.setCSSClassName("clsEvenTableRow");
            isEven = false;
         }
         else
         {
            htmlRow.setCSSClassName("clsOddTableRow");
            isEven = true;
         }
      }

      if (bShowCurrentRow && currentRow == drows[rowno])
      {
         htmlRow.setCSSClassName("clsCurrentTableRow");
      }

      if (showRecordNumber)
      {
         if (sRowUrl != null)
         {
            RowTag = rs.getRangeStart() + rowno + 1;

            int     nParamIndex = sRowUrl.indexOf('?');
            String  sUrl = sRowUrl;

            sUrl = fixupUrl(sRowUrl, rs.getName() + EditCurrentRecord.ROW_KEY_PARAM + "=" + sRowKey);

            HTMLTextURL txtUrl = new HTMLTextURL("" + RowTag, sUrl);

            if (sRowUrlTarget != null)
            {
               txtUrl.setTarget(sRowUrlTarget);
            }

            htmlRow.addTextURL(txtUrl);
         }
         else
         {
            RowTag = rs.getRangeStart() + rowno + 1;

            htmlRow.addFormattedTextCell("" + RowTag);
         }
      } //if(showRecordNumber)

      if (sRowEditUrl != null)
      {
         String sImage = null;

         if (rs.getViewObject().isReadOnly())
         {
            sImage = ImageDir + "/readonly.gif";
         }
         else
         {
            sImage = ImageDir + "/editrec.gif";
         }

         String sUrl = fixupUrl(sRowEditUrl, rs.getName() + EditCurrentRecord.ROW_KEY_PARAM + "=" + sRowKey);

         HTMLImageURL imgUrl = new HTMLImageURL(sImage, sUrl);

         if (sRowEditTarget != null)
         {
            imgUrl.setTarget(sRowEditTarget);
         }
         htmlRow.addImageURL(imgUrl);
      }
      return isEven;
   }

   /**
    * Renders an HTML table that contains records from the View Object's RowSet.
    * This is the View Object to which the RowSetBrowser object was initialized.
    */
   public void render() throws Exception
   {
      int                attrNo;
      String             sHeader;
      TableControl       aTable    =  getTableControl();
      AttributeDef[]     dattrs    =  getDisplayAttributeDefs();
      int                RowTag;

      aTable.initialize(application, session, request, response, out);
      aTable.setUseRoundedCorners(useRoundedCorners);
      aTable.setImageBase(this.getImageDir());

      renderTableHeaders();

      RowSet rs = ds.getRowSet();
      int nRangeSize = rs.getRangeSize();

      // only override if it has been set by the user
      if (nVisibleRowsWasChanged && rs.getRangeSize() != nVisibleRows)
      {
         rs.setRangeSize(nVisibleRows);
      }

      Row[]   drows = rs.getAllRowsInRange();
      Row     currentRow = rs.getCurrentRow();
      String  sValue = null;
      boolean isEven = true;
      String  sRowKey;


      for (int rowno = 0; rowno < drows.length; rowno++)
      {
         sRowKey = getRowKey(drows[rowno]);

         HTMLTableRow     htmlRow = new HTMLTableRow();

         aTable.addRow(htmlRow);

         isEven = initializeNewTableRow(htmlRow, drows, rowno, isEven);


         for (int j = 0; j < dattrs.length; j++)
         {
            if (!shouldDisplayAttribute(dattrs[j]))
               continue;

            sValue = null;

            if (drows[rowno] != null)
            {
               Object attrObj = drows[rowno].getAttribute( dattrs[j].getIndex());

               if ( attrObj != null)
                  sValue = attrObj.toString();
            }

            //htmlRow.addTextCell(aRenderer.getAttributeHtml(dattrs[j].getName(), sValue));
            HTMLFieldRenderer rField = this.getDisplayFieldRenderer(drows[rowno],dattrs[j]);
            String sOutput = rField.renderToString(drows[rowno]);
            htmlRow.addTextCell(sOutput);

         }

         // add any extra columns
         int RowRangeIndex = rs.getRangeIndexOf(drows[rowno]);

         for (int nExtra = 0 ; nExtra < extraUrlCols.size() ; nExtra++)
         {
            TextColumnUrlInfo info = (TextColumnUrlInfo)extraUrlCols.elementAt(nExtra);
            String sUrl = fixupUrl(info.sUrl, rs.getName() + EditCurrentRecord.ROW_KEY_PARAM + "=" + sRowKey);
            htmlRow.addElement(info.getColumnElement(sUrl));
         }

         htmlRow = new HTMLTableRow();
      }

      aTable.render();

      // restore the previous rangesize
      if (nVisibleRowsWasChanged)
         rs.setRangeSize(nRangeSize);

      releaseApplicationResources();
   }


   /**
   * <B>Internal</B>: <EM>Applications should not use this
   * method.</EM>
   *
   **/
   public String fixupUrl(String sUrl , String sExtra)
   {
      int     nParamIndex = sUrl.indexOf('?');
      String  sNewUrl = sUrl;

      if (nParamIndex != -1)
      {
         sNewUrl = sUrl + "&" + sExtra;
      }
      else
      {
         sNewUrl = sUrl + "?" + sExtra;
      }
      return sNewUrl;
   }
}


