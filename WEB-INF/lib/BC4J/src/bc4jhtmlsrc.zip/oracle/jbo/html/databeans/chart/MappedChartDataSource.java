/*
 * @(#)MappedChartDataSource.java
 *
 * Copyright 2000-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.html.databeans.chart;

import oracle.jbo.AttributeDef;
import oracle.jbo.RowSet;
import tdg.Perspective;

/**
 *  A Data source which provides a mapping support for the chart control.
 *
 *  Some of the columns in the underlying View can be supressed (ex., CHAR
 *  type columns)  using this datasource.
 *
 *  This list of columns to be used in drawing the chart can be specified
 *  <UL>
 *  <LI> As a list of column names
 *  <LI> As a list of column indices
 *  </UL>
 *
 *  A View with 'v' columns can be mapped to a chart data source with 'n'
 *  columns (n <= v).
 *
 *  @see     ChartDataSource
 *  @see     ChartLabelDataSource
 *  @version Internal
 */
abstract public class MappedChartDataSource
      extends ChartDataSource
{
    /**
    * a mapping which indicates which column in the view should be
    * used
    *
    * _map[0]=4., indicates that the first column will map to the 4th
    * column in the underlying view object.
    *
    */
    int _map[];


    /**
    * list of column names to be used in this data source
    */
    String  _columnNamesMap[];

    /**
    *  Constructor
    */
    public MappedChartDataSource(Perspective parent)
    {
        super(parent);
    }

    /**
    * This method should be invoked after the View object
    *  has been set.
    */
    public void initialize()
    {
        _map= new int[super.getColumns()];
        _initMap();
    }

    /**
    * Specify mapping description using columnNames.
    *
    *
    * @param columnNames List of column names in the underlying View object
    *                    The resultant data source will have as column 0, the
    *                    columnNames[0] and so on.
    * @see setColumnList(indices)
    *
    */
    public void setMappingColumnNames(String[] columnNames)
    {
        _columnNamesMap = columnNames;
        _map = new int[_columnNamesMap.length];
        for ( int i=0; i < _columnNamesMap.length ;i++)
        {
             AttributeDef attrDef = super.getRowSet()
                              .getViewObject().findAttributeDef(columnNames[i]);
             _map[i] = ((attrDef != null) ? attrDef.getIndex() : 0);
        }
    }

    /**
    * get the current list of mapped columns
    */
    public String[] getMappingColumnNames()
    {
        return _columnNamesMap;
    }

    /**
    * Specify mapping description using column indices.
    *
    *
    * @param columnNames List of column indices in the underlying View object
    *                    The resultant data source will have as column 0, the
    *                    indices[0] and so on.
    * @see setColumnList(indices)
    *
    */
    public void setMappingColumnIndices(int[] indices)
    {
        _map = indices;
    }

    public int[] getMappingColumnIndices()
    {
        return _map;
    }

    public int getColumns()
    {
        return _map.length;
    }

    public Object getValue(int row, int col)
    {
        return super.getValue(row, _map[col]);
    }

    protected void _initMap()
    {
        for ( int i=0; i < _map.length; i++)
            _map[i] = i;
    }

    protected int _mapColumnIndex(int columnIndex)
    {
        return _map[columnIndex];
    }

    /**
    *  get the index of the given column name
    */
    protected int _getColumnIndex(RowSet rs, String name)
    {
        AttributeDef attrDef = rs.getViewObject().findAttributeDef(name);
        return ((attrDef != null) ? attrDef.getIndex() : 0);
    }

    protected String _getColumnName(RowSet rs, int index)
    {
        AttributeDef attrDef = rs.getViewObject().getAttributeDef(index);
        return ((attrDef != null) ? attrDef.getName() : "");
    }

}

