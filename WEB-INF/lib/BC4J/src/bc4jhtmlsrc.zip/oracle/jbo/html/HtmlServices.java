/*
 * @(#)HtmlServices.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.html;

import java.sql.Types;
import java.util.Hashtable;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.servlet.jsp.PageContext;
import oracle.jbo.AttributeDef;
import oracle.jbo.AttributeHints;
import oracle.jbo.AttributeList;
import oracle.jbo.JboException;
import oracle.jbo.LocaleContext;
import oracle.jbo.ApplicationModule;
import oracle.jbo.ViewObject;
import oracle.jbo.Row;
import oracle.jbo.common.JBOClass;
import oracle.jbo.common.JboEnvUtil;
import oracle.jbo.common.PropertyConstants;
import oracle.jbo.common.ampool.SessionCookie;
import oracle.jdeveloper.html.HTMLFieldRenderer;
import oracle.jdeveloper.html.HTMLElement;
import oracle.ord.im.OrdDomainIOInterface;
import oracle.ord.im.OrdDomainUtil;
import oracle.ord.im.OrdHttpUploadFile;
import oracle.ord.im.OrdHttpUploadRequest;
import oracle.ord.im.OrdImageDomain;
import oracle.ord.im.OrdDomainState;
import oracle.ord.im.OrdFileSource;
import oracle.ord.im.OrdHttpUploadFormData;

/**
 * The HtmlServices class contains several useful class fields and methods. It cannot be instantiated. 
 *
 * @since JDeveloper 9.0.2
 */
public final class HtmlServices
{
   /**
    * The field type value for Display renderer
    */
   static public final String  DISP_RENDERER_KEY = "Renderer";
   /**
    * The field type value for Edit renderer
    */
   static public final String  EDIT_RENDERER_KEY = "EditRenderer";
   
   static private final String ORD_IM_PACKAGE = "oracle_ord_im";

   static private final String ORD_HTTP_UPLOAD_REQUEST_KEY = "_ord_http_upload_request_";
   
   /**
    * Default Intermedia Display renderer class name
    */
   static public final String ORD_DISPLAYRENDERER_CLASSNAME = "oracle.ord.html.OrdBuildURLRenderer";
   /**
    * Default Intermedia Edit renderer class name
    */
   static public final String ORD_EDITRENDERER_CLASSNAME = "oracle.ord.html.OrdUploadFileRenderer";

   static private final String ORDIMAGEDOMAIN_DISP_RENDERER_KEY = ORD_IM_PACKAGE + "_OrdImageDomain_" + DISP_RENDERER_KEY;
   static private final String ORDAUDIODOMAIN_DISP_RENDERER_KEY = ORD_IM_PACKAGE + "_OrdAudioDomain_" + DISP_RENDERER_KEY;
   static private final String ORDVIDEODOMAIN_DISP_RENDERER_KEY = ORD_IM_PACKAGE + "_OrdVideoDomain_" + DISP_RENDERER_KEY;
   static private final String ORDDOCDOMAIN_DISP_RENDERER_KEY =   ORD_IM_PACKAGE + "_OrdDocDomain_" + DISP_RENDERER_KEY;

   static private final String ORDIMAGEDOMAIN_EDIT_RENDERER_KEY = ORD_IM_PACKAGE + "_OrdImageDomain_" + EDIT_RENDERER_KEY;
   static private final String ORDAUDIODOMAIN_EDIT_RENDERER_KEY = ORD_IM_PACKAGE + "_OrdAudioDomain_" + EDIT_RENDERER_KEY;
   static private final String ORDVIDEODOMAIN_EDIT_RENDERER_KEY = ORD_IM_PACKAGE + "_OrdVideoDomain_" + EDIT_RENDERER_KEY;
   static private final String ORDDOCDOMAIN_EDIT_RENDERER_KEY =   ORD_IM_PACKAGE + "_OrdDocDomain_" + EDIT_RENDERER_KEY;

   /**
    * <b>Internal:</b> <em>Applications should not use this field.</em>
    * <br>Key to identify request paramater list in the page context
    */
   static public final String ORD_PARAM = "jboParam";
   /**
    * <b>Internal:</b> <em>Applications should not use this field.</em>
    */
   static public final String NULLSTRING = "null";

   /**
    * <b>Internal:</b> <em>Applications should not use this method.</em>
    * <p>
    * Retrieve the list of request parameters 
    */
   static public RequestParameters getRequestParameters(HttpServletRequest request, ServletResponse response, SessionCookie cookie)
      throws java.io.IOException
   {
      RequestParameters parameters;

      if (isMultipartPost(request) &&
         request.getAttribute(BC4JContext.ContextAttrName) == null) // Make sure that we are not in Struts.
                                                                    // Otherwise there will be double parsing of the request parameters.
                                                                    // When in Struts, the BC4JContext is set in the request
      {
         parameters = (RequestParameters) request.getAttribute(HtmlServices.ORD_PARAM);
         if (parameters == null)
         {

            if (response == null || cookie == null)
            {
               throw new JboException(Res.getString(Res.NEED_AMTAG_FIRST));
            }
            OrdHttpUploadRequest ordRequest = initializeOrdHttpUploadRequest(request, response, cookie);
            request.setAttribute(ORD_HTTP_UPLOAD_REQUEST_KEY, ordRequest);
            parameters = new OrdRequestParameters(ordRequest);
         
            request.setAttribute(HtmlServices.ORD_PARAM, parameters);
         }
      }
      else
      {
         parameters = new HttpRequestParameters(request);
      }

      return parameters;
   }

   /**
    * <b>Internal:</b> <em>Applications should not use this method.</em>
    * <p>
    * Release resources associated with the request parameters list
    */
   static public void releaseRequestParameters(PageContext pageContext)
   {
      //
      // Release the resource associated with the OrdHttpUploadRequest
      //
      RequestParameters params = (RequestParameters) pageContext.getAttribute(HtmlServices.ORD_PARAM, PageContext.REQUEST_SCOPE);

      if (params instanceof OrdRequestParameters)
      {
        OrdRequestParameters ordParams = (OrdRequestParameters)params;
        ordParams.getRequest().release();
      }

      pageContext.removeAttribute(HtmlServices.ORD_PARAM);
   }
   
   /**
    * Retrieve the list of request parameters. This method know how to deal with multipart contentype.<br>
    * Used by the Datatags library and the component tag JSP file.
    * The parameters list is cached in the page context for the duration of the request.
    * <p>
    * @param   pageContext PageContext of the current JSP
    * @return  The list of parameters
    *
    * @see     RequestParameters 
    */
   static public RequestParameters getRequestParameters(PageContext pageContext)
   {
      RequestParameters parameters;
      
      try
      {
         parameters = getRequestParameters((HttpServletRequest)pageContext.getRequest(), null, null);
      
         // Update the pageContext to be able to retrieve the most recent request instance
         parameters.setPageContext(pageContext);
      }
      catch (java.io.IOException ex)
      {
         pageContext.getServletContext().log("Error retrieving request parameters", ex);
         throw new JboException(ex.getMessage());
      }
      
      return parameters;
   }
   
   /**
    * Retrieve a single request parameter from the request parameter list.
    * <p>
    * @param   pageContext PageContext of the current JSP
    * @param   key         name of the request parameter to retrieve
    * @return  The value of the parameter
    */
   static public String getRequestParameter(PageContext pageContext, String key)
   {
      return getRequestParameters(pageContext).getParameter(key);
   }
   
   /**
    * <b>Internal:</b> <em>Applications should not use this method.</em>
    */   
   static public void updateRowAttributesFromRequestParameters(DataSource ds, Row row, RequestParameters params)
      throws java.lang.InstantiationException, java.lang.IllegalAccessException
   {
      updateRowAttributesFromRequestParameters(ds.getRowSet().getViewObject(), row, params);
   }
   
   /**
    * <b>Internal:</b> <em>Applications should not use this method.</em>
    */   
   static public void updateRowAttributesFromRequestParameters(ViewObject vo, Row row, RequestParameters params)
      throws java.lang.InstantiationException, java.lang.IllegalAccessException
   {
      ApplicationModule am = vo.getApplicationModule();
      LocaleContext locale = am.getSession().getLocaleContext();
      AttributeDef[] attrs = vo.getAttributeDefs();

      // get the attribute values and update those that need it
      for (int attrNo = 0; attrNo < attrs.length ; attrNo++)
      {
         AttributeDef attrDef = attrs[attrNo];

         if (!row.isAttributeUpdateable(attrDef.getIndex()))
         {
            continue;
         }

         if (isOrdDomainType(attrDef))
         {
             if(params instanceof OrdRequestParameters)
             {
                 Object value = getOrdObject(attrDef, ((OrdRequestParameters) params).getRequest(), row, am);

                 if (value != null)
                 {
                     row.setAttribute(attrDef.getIndex(), value);
                 }
             }else if(params instanceof HttpRequestParameters)
             {
               // to do: for struts MultipartRequestWrapper
             }
         }
         else
         {
            setAttributeFromRequestParameters(row, attrDef, params, locale);
         }
      }
   }   
   
   /**
    * <b>Internal:</b> <em>Applications should not use this method.</em>
    */   
   static public void internalSetAttribute(String sName, AttributeList attrList, AttributeDef attrDef, RequestParameters params, LocaleContext locale)
   {
      String sNewValue = params.getParameter(sName);

      // If the param does not exist, there is no point to continue
      if (sNewValue == null)
      {
         return;
      }

      sNewValue.trim();

      // empty out value if the string 'null' is used
      if (NULLSTRING.equalsIgnoreCase(sNewValue))
      {
         sNewValue = "";
      }

      AttributeHints hints = attrDef.getUIHelper();
      int index = attrDef.getIndex();

      // compare only with generated value to minimize overwrites of
      // attributes that didn't change.
      Object OldValue = params.getParameter(HtmlServices.getHiddenAttributeName(sName));
      if (OldValue == null)
      {
         if (hints != null)
         {
            OldValue = hints.getFormattedAttribute(attrList, locale);
         }
         else
         {
            OldValue = attrList.getAttribute(index);
         }
      }

      if (OldValue != null)
      {
         if (!sNewValue.equals(OldValue.toString()))
         {
            if (sNewValue.length() > 0)
            {
               if (hints != null)
               {
                  attrList.setAttribute(index, hints.parseFormattedAttribute(sNewValue, locale));
               }
               else
               {
                  attrList.setAttribute(index, sNewValue);
               }
            }
            else
            {
               attrList.setAttribute(index, null);
            }
         }
      }
      else
      {
         if (sNewValue.length() > 0)
         {
            if (hints != null)
            {
               attrList.setAttribute(index, hints.parseFormattedAttribute(sNewValue, locale));
            }
            else
            {
               attrList.setAttribute(index, sNewValue);
            }
         }
      }
   }
   
   static StructAttributesHandler structHandler;
   static ArrayAttributesHandler arrayHandler;

   /**
    * <b>Internal:</b> <em>Applications should not use this method.</em>
    */   
   static public void setAttributeFromRequestParameters(Row row, AttributeDef attrDef, RequestParameters params, LocaleContext locale)
      throws java.lang.IllegalAccessException, java.lang.InstantiationException
   {
      String baseName = attrDef.getName();

      if (Types.STRUCT == attrDef.getSQLType())
      {
         if (structHandler == null)
         {
            try
            {
               structHandler = new StructAttributesHandler();
            }
            catch (Exception ex)
            {
               throw new JboException(ex.getMessage());
            }
         }

         structHandler.setAttributeFromRequestParameters(row, attrDef, params, locale);
      }
      else if (Types.ARRAY == attrDef.getSQLType())
      {
         if (arrayHandler == null)
         {
            try
            {
               arrayHandler = new ArrayAttributesHandler();
            }
            catch (Exception ex)
            {
               throw new JboException(ex.getMessage());
            }
         }

         arrayHandler.setAttributeFromRequestParameters(row, attrDef, params, locale);
      }
      else
      {
         internalSetAttribute(baseName, row, attrDef, params, locale);
      }
   }

   /**
    * <b>Internal:</b> <em>Applications should not use this method.</em>
    */   
   static public void setAttributeFromRequest(Row row, AttributeDef attrDef, HttpServletRequest request, LocaleContext locale)
      throws java.lang.IllegalAccessException, java.lang.InstantiationException
   {
      setAttributeFromRequestParameters(row, attrDef, new HttpRequestParameters(request), locale);
   }

   /**
    * Build the name of the hidden field used to store the original value of an attribute
    * <p>
    *
    * @param   attrName Name of the attribute
    * @return  html hidden field name
    */
   static public String getHiddenAttributeName(String attrName)
   {
      return ("_" + attrName);
   }
   
   static private class OrdRequestParameters extends RequestParameters
   {
      OrdHttpUploadRequest request;

      OrdRequestParameters(OrdHttpUploadRequest ordRequest)
      {
         request = ordRequest;
      }

      protected String getParameterFromRequest(String param)
      {
         return request.getParameter(param);
      }

      public OrdHttpUploadRequest getRequest()
      {
         return request; 
      }
   }

   static private class HttpRequestParameters extends RequestParameters
   {
      HttpServletRequest request;
/* BEGIN: iPlanet 6.5 workaround code
      boolean isIPlanet = false;
   END workaround code */
      HttpRequestParameters(HttpServletRequest httpRequest)
      {
         request = httpRequest;
/* BEGIN: iPlanet 6.5 workaround code
         if ( httpRequest != null )
         {
            String className = httpRequest.getClass().getName();
            if ( className.startsWith("com.netscape") )
            {
              isIPlanet = true;
            }
         }
   END workaround code */      
      }

      protected String getParameterFromRequest(String param)
      {
         String value = request.getParameter(param);
/* BEGIN: iPlanet 6.5 workaround code
         if ( isIPlanet && value != null )
         {
            String result = java.net.URLDecoder.decode( value );
            return result;
         }
   END workaround code */         
         
         return value;
      }
   
      public HttpServletRequest getRequest()
      {
         return request; 
      }
      
      public String getParameter(String param)
      {
         String value = null;
         
         if (pageContext != null)
         {
            value = pageContext.getRequest().getParameter(param);
         }

         if (value == null)
         {
            value = getParameterFromRequest(param);
         }
      
         return value;
      }      
      
   }

   public static Object getOrdObject(AttributeDef attrDef, 
                                     OrdFileSource tempFile,
                                     Row row,
                                     ApplicationModule am,
                                     String mimeType)
     throws java.lang.InstantiationException, java.lang.IllegalAccessException
   {
     OrdDomainIOInterface obj = null;

     if(tempFile != null)
     {
       Object oldValue = row.getAttribute(attrDef.getIndex());
      
       Hashtable env = am.getSession().getEnvironment();
       boolean isRemoteMode = JboEnvUtil.isClient(env);
          
       if(isRemoteMode)
       {
         //
         // In remote mode, I have to reuse the existing domain objects in the row.
         // If I create a new domain to hold the content source, the new domain
         // will be added into am's postClientListener list. However, the old domain
         // will not be removed from am's postClientListener list in the case of 
         // user uploads more than once to the same interMedia object before commit.
         //
         if(oldValue == null)
         {
           obj = (OrdDomainIOInterface)OrdDomainUtil.newInstance(attrDef);
         }else
         {
           obj = (OrdDomainIOInterface)oldValue;
         }

         try
         {
           obj.setContentSource(tempFile);
           //
           // In remote mode, I have to reset some of the attributes that are used to
           // generate the URL by OrdURLBuilder. Otherwise, it's reusing the old attributes
           // such as width and height.
           //
           if(obj instanceof OrdImageDomain)
           {
             ((OrdImageDomain)obj).setWidth(0);
             ((OrdImageDomain)obj).setHeight(0);
           }  
           obj.setMimeType(mimeType);
           
           if(((OrdDomainState)obj).isConnected())
           {
             obj.setUpdateTime(null);
           }
         }catch(Exception e)
         {
           throw new JboException(e);
         }
       }else
       {
         //
         // This is Local mode. There is no postClientListener stuff.
         //
         
         /*
         // 
         // Leave the previous temp files since they might be passivated
         // and need to be activated. Use the clean-up script to remove
         // them.
         //
         // Release the content source stored in old domain
         //
         if(oldValue != null)
         {
         ((OrdDomainIOInterface)oldValue).setContentSource(null);
         }
         */
         
         obj = (OrdDomainIOInterface)OrdDomainUtil.newInstance(attrDef);
         obj.setContentSource(tempFile);
       }

     }

     return obj;
     
   }

   private static Object getOrdObject(AttributeDef attrDef, OrdHttpUploadRequest ordRequest, Row row, ApplicationModule am)
      throws java.lang.InstantiationException, java.lang.IllegalAccessException
   {
      OrdDomainIOInterface obj = null;
      String sName = attrDef.getName();
      
      OrdHttpUploadFile mFile = ordRequest.getFileParameter(sName);
      
      if ((mFile != null) &&
          (! mFile.getOriginalFileName().equals("")) &&
          ( mFile.getContentLength() >= 0 ))
      {
          //
          // When (mFile!=null) && (! mFile.getOriginalFileName().equals(""))
          // && ( mFile.getContentLength() == 0 ), user uploads a valid empty 
          // file. This means nuke out any existing content in the domain.
          //

          //
          // Find the tmp directory to store temp files
          //
          String tmpDir = oracle.jbo.server.xml.JboXMLUtil.getBC4JTempDir(am);

          //
          // Make a copy of the browser uploaded content to a temp file. Use this 
          // temp file for database upload and passivation/activation. The browser
          // uploaded content will be released in the <ReleasePageResources> tag.
          // 
          OrdFileSource tempFile = null;

          try
          {
            tempFile = OrdDomainUtil.
              createTempFile(mFile.getInputStream(), mFile.getMimeType(), tmpDir);
          }
          catch(Exception e)
          {
            throw new RuntimeException("Can not create temp file");
          }

          obj = (OrdDomainIOInterface) 
            getOrdObject(attrDef, tempFile, row, am, mFile.getMimeType());
      }
      else
      {
         // if "attrName_DELETE" was set as ON, this means user
         // wants to delete the interMedia object
         String attrDel = ordRequest.getParameter(sName + "_DELETE");
         if (attrDel != null && attrDel.equalsIgnoreCase("ON"))
         {
            obj = (OrdDomainIOInterface)OrdDomainUtil.newInstance(attrDef);
         }
      }

      return obj;
   }

   
   private static OrdHttpUploadRequest initializeOrdHttpUploadRequest(HttpServletRequest request, ServletResponse response, SessionCookie cookie)
     throws java.io.IOException
   {
      //
      // Changes are made to support more effective resouce usage in the
      // web server side. Two parameters, OrdHttpMaxMemory and OrdHttpTempDir,
      // were read from the properties file to actively control the memory usage.
      // For the uploaded file whose size is larger than the OrdHttpMaxMemory,
      // a temporary file will be created in the OrdHttpTempDir to store the
      // uploaded content.
      //
      // Temp files are created during OrdHttpUploadRequest.parseFormData(). They
      // are removed in OrdHttpUploadRequest.release(). A try-final block has
      // to be added around the code to ensour temporary files deletion in the
      // end. To support JDK1.1.x, we have to use this way. For JDK1.2,
      // File.createTempFile() was added into the standard API.
      //
     
      OrdHttpUploadRequest ordRequest = new OrdHttpUploadRequest(request);
     
      // enable parameter transaltion
      ordRequest.enableParameterTranslation(response.getCharacterEncoding());
     
      if (request.getMethod().equalsIgnoreCase("POST"))
      {
         Hashtable env = cookie.getEnvironment();
         
         String sMaxMemory = (String)env.get(PropertyConstants.ORD_HTTP_MAX_MEMORY);
         if (sMaxMemory == null)
         {
            sMaxMemory = JboEnvUtil.getProperty(PropertyConstants.ORD_HTTP_MAX_MEMORY, "-1");
         }
       
         int maxMemory;
         try
         {
            maxMemory = Integer.parseInt(sMaxMemory);
         }
         catch (java.lang.NumberFormatException e)
         {
            maxMemory = -1;
         }
         
         String tempDir = (String)env.get(PropertyConstants.ORD_HTTP_TEMP_DIR);
         
         if (tempDir == null)
         {
            tempDir = JboEnvUtil.getProperty(PropertyConstants.ORD_HTTP_TEMP_DIR, null);
         }
            
         if (maxMemory >= 0 && tempDir != null)
         {
            ordRequest.setMaxMemory(maxMemory, tempDir);
         }

         ordRequest.parseFormData();
     }

     return ordRequest;
  }

   /**
    * <b>Internal:</b> <em>Applications should not use this method.</em>
    */   
   static public void registerORDrenderer(HttpSession session)
   {
      session.setAttribute(ORDIMAGEDOMAIN_DISP_RENDERER_KEY,  ORD_DISPLAYRENDERER_CLASSNAME);
      session.setAttribute(ORDAUDIODOMAIN_DISP_RENDERER_KEY,  ORD_DISPLAYRENDERER_CLASSNAME);
      session.setAttribute(ORDVIDEODOMAIN_DISP_RENDERER_KEY,  ORD_DISPLAYRENDERER_CLASSNAME);
      session.setAttribute(ORDDOCDOMAIN_DISP_RENDERER_KEY,    ORD_DISPLAYRENDERER_CLASSNAME);

      session.setAttribute(ORDIMAGEDOMAIN_EDIT_RENDERER_KEY,  ORD_EDITRENDERER_CLASSNAME);
      session.setAttribute(ORDAUDIODOMAIN_EDIT_RENDERER_KEY,  ORD_EDITRENDERER_CLASSNAME);
      session.setAttribute(ORDVIDEODOMAIN_EDIT_RENDERER_KEY,  ORD_EDITRENDERER_CLASSNAME);
      session.setAttribute(ORDDOCDOMAIN_EDIT_RENDERER_KEY,    ORD_EDITRENDERER_CLASSNAME);
   }
  
   /**
    * Build a string key from a Domain class name
    * <p>
    * This key is used to identify the renderer associated with a Domain.
    * <p>
    * @param   className Class name of the domain
    * @param   type Renderer type ("DISPLAY" or "EDIT")
    * @return  html hidden field name
    */
   static public String getRendererKeyFromDomainName(String className, String type)
   {
      return className.replace('.','_') + "_" + type;
   }

   /**
    * Load and instanciate a Renderer class
    * <p>
    * Errors are reported to a servlet log file.
    * <p>
    * @param   className Class name of the renderer
    * @param   page pageContext PageContext of the current JSP
    * @return  HTMLFieldRenderer instance
    */
  static public HTMLFieldRenderer getFieldRendererFromClassName(String sClassName, PageContext page)
  {
     HTMLFieldRenderer rField;
     Class cls;

     // Load and instanciate the renderer here for validate purpose
     try
     {
        cls = JBOClass.forName(sClassName);
     }
     catch (java.lang.ClassNotFoundException ex)
     {
        page.getServletContext().log("Field Renderer Error", ex);
        throw new JboException(ex.getMessage());
     }
     
     try
     {
        rField = (HTMLFieldRenderer) cls.newInstance();
     }
     catch (java.lang.IllegalAccessException ex)
     {
        page.getServletContext().log("Field Renderer Error", ex);
        throw new JboException(ex.getMessage());
     }
     catch (java.lang.InstantiationException ex)
     {
        page.getServletContext().log("Field Renderer Error", ex);
        throw new JboException(ex.getMessage());
     }

     return rField;
  }

   /**
    * Build an attribute path for a Struct domain
    * <p>
    * @param   attrDef Attribute definition of the Struct class 
    * @param   subAttrDef Attribute definition of the attribute inside the Struct class
    * @return  a path to identify the sub-attribute
    */
   static public String getStructAttributeName(AttributeDef attrDef, AttributeDef subAttrDef)
   {
      StringBuffer strBuff = new StringBuffer(100);

      strBuff.append(attrDef.getName());
      strBuff.append('.');
      strBuff.append(subAttrDef.getName());

      return strBuff.toString();
   }

   /**
    * Build an attribute path for a Array domain
    * <p>
    * @param   attrDef Attribute definition of the Array class 
    * @param   i index of the current Array element
    * @return  a path to identify the array element
    */
   static public String getArrayAttributeName(AttributeDef attrDef, int i)
   {
      StringBuffer strBuff = new StringBuffer(100);

      strBuff.append(attrDef.getName());
      strBuff.append('[');
      strBuff.append(i);
      strBuff.append(']');

      return strBuff.toString();
   }

  
   /**
    * Format a String to be readable by a JavaScript method
    * <p>
    * Replace \ by \\, ' by \' and " by \".
    * <p>
    * @param   x string to format
    * @return  formatted string
    */
   static public String treatInvalidCharacter(String x)
   {
      if (x == null)
      {
         return null;
      }
      else
      {
         int idx;
         int start = 0;
        
          while ((idx = x.indexOf('\\', start)) >= 0)
          {  
            x = x.substring(0, idx) + "\\\\" + x.substring(idx + 1);
            start = idx + 2;
         }
        
         start = 0;
         while ((idx = x.indexOf('\'', start)) >= 0)
         {
            x = x.substring(0, idx) + "\\'" + x.substring(idx + 1);
            start = idx + 2;
         }

         start = 0;
         while ((idx = x.indexOf('"', start)) >= 0)
         {
            x = x.substring(0, idx) + "\\\"" + x.substring(idx + 1);
            start = idx + 2;
         }

         return x;
      }
   }

   /**
    * Check if the current context is in a Struts application
    * <p>
    * @param   pageContext
    * @return  true if in Struts
    */
   static public boolean isStrutsContext(PageContext pageContext)
   {
      // If the context attribute is found, it mean we are in a Struts application.
      Object contextObject = pageContext.getRequest().getAttribute(BC4JContext.ContextAttrName);
      
      return (contextObject != null);
   }

   public static boolean isOrdDomainType(AttributeDef attrDef)
   {
     Class classObj = attrDef.getJavaType();
     String name = classObj.getName();
     
     if(name.equals(oracle.ord.common.PropertyConstants.ORD_IMAGE_DOMAIN) ||
        name.equals(oracle.ord.common.PropertyConstants.ORD_AUDIO_DOMAIN) ||
        name.equals(oracle.ord.common.PropertyConstants.ORD_VIDEO_DOMAIN) ||
        name.equals(oracle.ord.common.PropertyConstants.ORD_DOC_DOMAIN) ||
        name.equals(oracle.ord.common.PropertyConstants.ORD_IMAGE_SIGNATURE_DOMAIN))
     {
       return true;
     }
     
     return false;
   }

   /**
    * Decides whether the HttpRequest is "multipart/form-data".
    */
   public static boolean isMultipartPost(HttpServletRequest request)
   {
      boolean isMultipart = false;
 
      String contentType = request.getContentType();
      String method = request.getMethod();
     
      if ((contentType != null) &&
          (contentType.startsWith("multipart/form-data")) &&
          (method.equalsIgnoreCase("POST"))) 
      {
         isMultipart = true;
      }
 
      return isMultipart;
   }
 

   public static String getAttributeStringValue(Row row, AttributeDef aDef, LocaleContext localeContext)
   {
      String strValue = aDef.getUIHelper().getFormattedAttribute(row, localeContext);

      if (strValue == null)
      {
         strValue = "";
      }
      else
      {
         strValue = HTMLElement.quote(strValue);
      }
      
      return strValue;
   }

   /**
    * Gets the <code>OrdHttpUploadFormData</code> object stored in <code>
    * HttpServletRequest</code>. This method should only be used after 
    * HtmlServices.getRequestParameters(HttpServletRequest, ServletResponse,
    * SessionCookie); is called.
    *
    * @param request the <code>HttpServletRequest</code> object
    * @return an <code>OrdHttpUploadFormData</code> object if the HTTP request
    *         is a "multipart/form-data" POST request; null otherwise.
    */
   public static OrdHttpUploadFormData getOrdFormData(HttpServletRequest request)
   {
      OrdHttpUploadRequest ordRequest = null;
      if(request != null)
      {
        ordRequest = (OrdHttpUploadRequest) request.getAttribute(ORD_HTTP_UPLOAD_REQUEST_KEY);
      }

      return (OrdHttpUploadFormData)ordRequest;
   }
}
