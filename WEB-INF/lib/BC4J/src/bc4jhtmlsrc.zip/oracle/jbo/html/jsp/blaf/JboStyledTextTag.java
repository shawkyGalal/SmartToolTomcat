/*
 * @(#)JboStyledTextTag.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.html.jsp.blaf;

import oracle.cabo.ui.jsps.tags.StyledTextTag;
import oracle.cabo.ui.beans.StyledTextBean;
import oracle.cabo.ui.data.DataBoundValue;
import oracle.jbo.AttributeDef;
import oracle.jbo.LocaleContext;
import oracle.jbo.Row;
import oracle.jbo.html.DataSource;
import oracle.jbo.html.jsp.datatags.Utils;
import oracle.jbo.html.jsp.datatags.DataTagBase;
import oracle.cabo.ui.MutableUINode;
import javax.servlet.jsp.PageContext;

public class JboStyledTextTag extends StyledTextTag
{
   String datasource;
   String dataitem;

   /**
    * Constructor
    */
   public JboStyledTextTag() {
   }

   public String getDatasource()
   {
      return datasource;
   }

   public void setDatasource(String newDatasource)
   {
      datasource = newDatasource;
   }

   public String getDataitem()
   {
      return dataitem;
   }

   public void setDataitem(String newDataitem)
   {
      dataitem = newDataitem;
   }
   
    /**
    * initializeProperties
    */
    public void setProperties(MutableUINode node) 
    {
      super.setProperties(node);
      
      StyledTextBean bean = (StyledTextBean)node;
      
      if(dataitem != null)
      {
         if(datasource == null)
         {
            bean.setTextBinding(new DataBoundValue(dataitem));
         }
         else
         {
            DataSource     ds = Utils.getDataSourceFromContext(getPageContext(), datasource);
            Row            row = DataTagBase.getRowFromContext(this, datasource, ds);
            LocaleContext  locale = ds.getApplicationModule().getSession().getLocaleContext();
            
            // if we are dealing with a UI hint
            if(dataitem.startsWith("UIHINT:"))
            {
               String sHint = dataitem.substring(dataitem.indexOf(':') + 1);
               int nIndex = sHint.indexOf(':');

               String sName = sHint.substring(nIndex+1);
               sHint = sHint.substring(0, nIndex);

               // format the attribute
               AttributeDef aDef = ds.getRowSet().getViewObject().findAttributeDef(sName);

               String sValue = aDef.getUIHelper().getHint(locale, sHint);

               bean.setText(sValue);
            }
            else
            {
               if(dataitem.equalsIgnoreCase("rowkey"))
               {
                  String sKey = row.getKey().toStringFormat(true);
                  bean.setText(sKey);
               }
               else if(row.getAttribute(dataitem) != null)
               {
                  bean.setText(row.getAttribute(dataitem).toString());
               }
            }
       }
      }
   }

   /**
    * releaseBean
    */
   public void release() {
      super.release();

      datasource = null;
      dataitem = null;
   }

   protected PageContext getPageContext()
   {
      // TODO:  Override this oracle.cabo.ui.jsps.tags.BaseTag method
      return super.getPageContext();
   }
}

