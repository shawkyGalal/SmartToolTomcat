/*
 * @(#)InputSelectLOVTag.java
 *
 * Copyright 2000-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.html.jsp.datatags;

import javax.servlet.jsp.JspException;

import oracle.jbo.JboException;
import oracle.jbo.html.HtmlServices;
import oracle.jdeveloper.html.HTMLFieldRenderer;
import oracle.jdeveloper.html.LOVField;

public class InputSelectLOVTag extends InputSelectBase
{
   protected String sLovUrl;

   public void setLovurl(String sValue)
   {
      sLovUrl = sValue;
   }
   
   public HTMLFieldRenderer getFieldRenderer()
   {
      final HTMLFieldRenderer rField = new LOVField();

      initializeFieldRenderer(rField);

      if (sFormName == null)
      {
         if (HtmlServices.isStrutsContext(pageContext))
         {
            sFormName = getStrutsFormName();
         }
         else
         {
            throw new JboException(Res.getString(Res.INPUTLOV_NO_FORMNAME));
         }
      }

      return rField;
   }

   public void initializeFieldRenderer(HTMLFieldRenderer rField)
   {
      super.initializeFieldRenderer(rField);
      if (sLovUrl != null)
      {
         ((LOVField)rField).setLovUrl(sLovUrl);
      }
   }

   public int doEndTag() throws JspException
   {
      sLovUrl = null;
      return super.doEndTag();
   }
   
}

 