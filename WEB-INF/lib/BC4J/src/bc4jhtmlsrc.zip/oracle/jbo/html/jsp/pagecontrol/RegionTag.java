package oracle.jbo.html.jsp.pagecontrol;

import javax.servlet.jsp.tagext.BodyTagSupport;
import javax.servlet.jsp.tagext.BodyContent;
import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspTagException;
import javax.servlet.jsp.JspWriter;

public class RegionTag extends BodyTagSupport 
{
  /*
  tag attribute: id
  */

  private String id = "";


  /**
   * Method called at start of tag.
   * @return EVAL_BODY_TAG
   */
  public int doStartTag() throws JspException
  {
    try
    {
      String sParameter = pageContext.getRequest().getParameter("updateRegion");
      if(sParameter != null && !sParameter.equals(id))
        return SKIP_BODY;
      
    }
    catch(Exception e)
    {
      e.printStackTrace();
    }

    return EVAL_BODY_AGAIN;
  }


  /**
   * Method called at end of tag.
   * @return EVAL_PAGE
   */
  public int doEndTag()
  {
    return EVAL_PAGE;
  }


  /**
   * Method is invoked after every body evaluation to control whether the body will be reevaluated or not.
   * @return SKIP_BODY
   */
  public int doAfterBody() throws JspException
  {
    try
    {
      
        JspWriter out = getPreviousOut();
        BodyContent bodyContent = getBodyContent();
        out.println("<DIV ID=\"" + id + "\">");
        bodyContent.writeOut(out);
        out.println("</DIV>");
      
    }
    catch(Exception e)
    {
      throw new JspTagException(e.getMessage());
    }

    return SKIP_BODY;
  }


  public void setId(String value)
  {
    id = value;
  }


  public String getId()
  {
    return id;
  }
}