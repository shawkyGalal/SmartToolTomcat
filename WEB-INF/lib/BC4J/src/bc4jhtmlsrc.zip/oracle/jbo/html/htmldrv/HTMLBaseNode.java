/*
 * @(#)HTMLBaseNode.java
 *
 * Copyright 1999-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.html.htmldrv;

import java.awt.*;
import java.io.*;
import java.io.*;
import java.net.*;
import java.util.*;
import javax.swing.*;
import javax.swing.tree.*;
import oracle.jbo.server.*;

/**
 *
 * @version INTERNAL
 */
public class HTMLBaseNode implements IHTMLParserNode
{
   Vector          tokens      = new Vector();
   Hashtable       attributes  = new Hashtable();
   Vector          nodes       = new Vector();
   Hashtable       userObjects = new Hashtable();
   IHTMLParserNode parent      = null;
   String          nodeTag     = null;
   String          nodeEndTag  = null;   
   HTMLTokenizer   tokenizer;
   

   public HTMLBaseNode(HTMLTokenizer tokenizer, IHTMLParserNode parent)
   {
      
      this.tokenizer = tokenizer;
      this.parent = parent;
         
      if(parent != null)
      {
         parent.addChildNode(this);
      }
   }
   

   
   public HTMLBaseNode(IHTMLParserNode parent, String sTag)
   {
      this.nodeTag = sTag;
      this.parent = parent;
      
      if(parent != null)
      {
         parent.addChildNode(this);
      }
   }
   
   public boolean  traverse(IHTMLNodeVisitor visitor)
   {
      return HTMLTraverser.traverse(visitor, this);
   }
   
   public String           getNodeLabel()
   {
      String sTag      = getNodeTag();

      if(sTag == null || sTag.equals("\n"))
      {

         sTag = "";
         
         int nElem = tokens.size();
         for(int i  = 0 ; i < nElem ; i++)
         {
            sTag += (String)tokens.elementAt(i);
         }
      }
/*      else
      {
         String sKeyName;
         
         // concatenate the attributes to the tag to get more context on the node
         for (Enumeration e = attributes.keys() ; e.hasMoreElements() ;)
         {
            sKeyName = (String)e.nextElement();
            sTag += " " + sKeyName + "=" + attributes.get(sKeyName) + " ";
         }

      }
*/      

      sTag = sTag.replace('\n' , ' ');
      sTag = sTag.trim();
      
      if(sTag.equals(""))
         return "";
      

      if(sTag.length() > 60)
      {
         sTag = sTag.substring(0, 60) + "...";
      }

      return sTag;
   }
      
   public Vector           getChildNodes()
   {
      return nodes;
   }
   
   public int              getChildCount()
   {
      return nodes.size();
   }
   
      
   public Hashtable        getAttributes()
   {
      return attributes;
   }
   
   public Vector           getTokens()
   {
      return tokens;
   }
   
   public IHTMLParserNode  getParent()
   {
      return parent;
   }
   
   public void             replaceChild(IHTMLParserNode oldNode, IHTMLParserNode newNode)
   {
      if(nodes == null)
         return;
      
      if(nodes.contains(oldNode))
         nodes.insertElementAt(newNode, nodes.indexOf(oldNode));
      else
         nodes.addElement(newNode);

      newNode.setParent(this);
   }
   
   public void             removeNodeFromParent()
   {
      if(parent == null)
        return;

      parent.getChildNodes().removeElement(this);      
   }
   
   public void             setParent(IHTMLParserNode newparent)
   {
      //remove from current parent
      removeNodeFromParent();
      
      parent = newparent;
   }
   
   public void             addUserObject(String sName, Object obj)
   {
      userObjects.put(sName , obj);
   }
   
   public Object           getUserObject(String sName)
   {
      return userObjects.get(sName);
   }

   public String           getNodeTag()
   {
      return nodeTag;
   }
   
   public void             setNodeTag(String sTag)
   {
      nodeTag = sTag;
   }
   
   public String           getNodeEndTag()
   {
      return nodeEndTag;
   }
   
   public void             setNodeEndTag(String sTag)
   {
      nodeEndTag = sTag;
   }
   
   public void             addChildNode(IHTMLParserNode node)
   {
      node.setParent(this);
      nodes.addElement(node);      
   }
   
   public void             addToken(HTMLTokenizer tokens)
   {
      this.tokens.addElement(tokens.sval);
   }
   
   public void             addToken(String sval)
   {
      tokens.addElement(sval);
   }
   
   public void   addTagAttribute(String sName , String sval)
   {
//      debugout.println("Adding tag attribute:" + sName + "=" + sval);
      attributes.put(sName, sval);
   }


   public void parseTagAttributes(String sval)
   {
      // split up the tag attributes, they should be in
      // the format name=value, a value may or may not be quoted
      String sName;
      String sValue;

      // trim the input
      String sLine = sval.trim() + " ";
      int    nEqualsIndex;
      int    nValueIndex;
      
      while(sLine.length() > 0)
      {
//         debugout.println("Line is:[" + sLine + "]");
         
         // find the next =

         nEqualsIndex = sLine.indexOf('=');

         if(nEqualsIndex == -1)
            return;
         
         sName = sLine.substring(0, nEqualsIndex);
         sValue = "";
         
         // see if we have a quote, read value until the next quote without a preceeding escape
         if(sLine.charAt(nEqualsIndex + 1) == '"')
         {
            // trim the left of the line
            sLine = sLine.substring(nEqualsIndex + 1);
            nValueIndex = 1;
            
            while(sLine.charAt(nValueIndex) != '"')
               nValueIndex++;
            
            // increment to include the quote
            nValueIndex++;
            
            sValue += sLine.substring(0, nValueIndex);

            sLine = sLine.substring(nValueIndex);
            
         }
         else // if we dont have a quote get the value until the next space
         {
            sLine = sLine.substring(nEqualsIndex + 1);
            nValueIndex = 0;
            
            while(sLine.charAt(nValueIndex) != ' ')
               nValueIndex++;
            
            sValue += sLine.substring(0, nValueIndex);
            
            sLine = sLine.substring(nValueIndex);
         }

         addTagAttribute(sName, sValue);
      }
   }
      
   public void populateWriter(PrintWriter out) throws Exception
   {
      int               nElem = 0;
      IHTMLParserNode   node;

      if(nodeTag != null && nodeTag.length() > 0)
      {
        out.print("<" + nodeTag );

        //append attributes
        String sKeyName;
         
        // concatenate the attributes to the tag to get more context on the node
        for (Enumeration e = attributes.keys() ; e.hasMoreElements() ;)
        {
           sKeyName = (String)e.nextElement();
           out.print(" " + sKeyName + "=" + attributes.get(sKeyName) + " ");
        }
         
        //terminate tag
        out.print(">");

      }
      else
      {
         out.print("<");
         nElem = tokens.size();

         for(int i  = 0 ; i < nElem ; i++)
         {
            out.print((String)tokens.elementAt(i));
         }
         out.print(">");
      }
      // node render the child nodes
      nElem = nodes.size();

      for(int i  = 0 ; i < nElem ; i++)
      {
         node = (IHTMLParserNode)nodes.elementAt(i);
         node.populateWriter(out);
      }

       if(nodeEndTag != null && nodeEndTag.length() > 0)
       {
          if(nodeEndTag.equalsIgnoreCase(">"))
             out.print(">");             
          else
             out.print("</" + nodeEndTag + ">");
       }

   }   
}