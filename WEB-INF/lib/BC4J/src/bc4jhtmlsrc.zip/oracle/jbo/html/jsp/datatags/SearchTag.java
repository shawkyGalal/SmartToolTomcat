/*
 * @(#)SearchTag.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.html.jsp.datatags;

import javax.servlet.http.HttpServletRequest;
import oracle.jbo.html.BC4JContext;

/**
 */
public class SearchTag extends DataComponentTag
{
   public static final String defaultUrl = "DataQueryComponent.jsp";
   public static final String paramNames[] = new String[]{ "targetURL" };
   protected String  sTargetUrl;

   public SearchTag()
   {
      super();
   }

   protected void reset()
   {
      super.reset();
      sRelativeUrlPath = defaultUrl;
      sTargetUrl = null;
   }

   public void setTargetURL(String sValue)
   {
      this.sTargetUrl = sValue;
   }
   
   public String getUrl()
   {
      String url = super.getUrl();
      
      // If the target url is not specify, we use self.
      if (sTargetUrl == null)
      {
         // If we are using Struts, the default page is '/query.do'
         BC4JContext bc4jContext = null;
         Object contextObject = pageContext.getRequest().getAttribute(BC4JContext.ContextAttrName);
         // Only do the casting if object is found
         if (contextObject != null)
         {
            bc4jContext = (BC4JContext) contextObject;
         }
         
         if (bc4jContext != null)
         {
            sTargetUrl = "/query.do";
         }
         else
         {
            sTargetUrl = ((HttpServletRequest) pageContext.getRequest()).getRequestURI();
         }
      }

      return buildUrl(url, paramNames, new String[]{ sTargetUrl });
   }
}
