/*
 * @(#)ChartLabelDataSourceImpl.java
 *
 * Copyright 2000-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.html.databeans.chart;

import oracle.jbo.RowSet;

/**
 * Data source for chart label
 *
 * @version Internal
 */
class ChartLabelDataSourceImpl implements ChartLabelDataSource
{
    private Object[]         _labels;
    private ChartDataSource  _parent;
    protected RowSet         _qView;

	private static final String EMPTY_STRING="";

    ChartLabelDataSourceImpl(ChartDataSource parent)
    {
       super();
       _parent = parent;
    }

    public void setRowSet(RowSet qView)
    {
        _qView = qView;
    }

    void setLabels(Object[] labels)
    {
         _labels = labels;
    }

    Object[] getLabels()
    {
        return _labels;
    }

    public String getLabel(int index)
    {
        if ((_labels == null) || (index < 0) || (index > (_labels.length-1) ))
           return EMPTY_STRING;

		Object o = _labels[index];

		if (o == null)
		{
			return EMPTY_STRING;
		}
		else
            return o.toString();
    }

    int getElementCount()
    {
        if ( _labels != null )
           return _labels.length;
        return 0;
    }


    void updateChart()
    {

    }
}
