/*
 * @(#)RefreshDataSourceTag.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.html.jsp.datatags;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.tagext.Tag;
import javax.servlet.jsp.tagext.TagSupport;
import oracle.jbo.html.DataSource;

public class RefreshDataSourceTag extends TagSupport
{
   protected String sDataSource; // Required attribute, no need to initialize.

   public void setDatasource(String sDataSource)
   {
      this.sDataSource = sDataSource;
   }

   public int doStartTag() throws JspException
   {
      final DataSource ds = Utils.getDataSourceFromContext(pageContext, sDataSource);
      
      ds.getRowSet().executeQuery();
      
      return Tag.EVAL_BODY_INCLUDE;
   }
}
