/*
 * @(#)ShowTagBase.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.html.jsp.datatags;

import javax.servlet.jsp.tagext.TagSupport;
import javax.servlet.jsp.JspException;

import oracle.jbo.AttributeDef;
import oracle.jbo.JboException;
import oracle.jbo.html.DataSource;

public class ShowTagBase extends TagSupport
{
   protected String datasource;
   protected String dataitem;
   protected DataSource ds;
   
   public ShowTagBase()
   {
      super();
      reset();
   }
   
   public void setDatasource(String newDatasource)
   {
      datasource = newDatasource;
   }

   public void setDataitem(String newDataitem)
   {
      dataitem = newDataitem;
   }

   protected AttributeDef getAttributeDef()
   {
      AttributeDef  attrDef = null;

      // If the datasource id is defined, used it to retrieve the datasource
      if (datasource != null)
      {
         ds = Utils.getDataSourceFromContext(pageContext, datasource);
      
         if (dataitem == null)
         {
            AttributeIterateTag  attrIterTag = (AttributeIterateTag) Utils.findAncestorWithClassForDataSource(this, datasource, AttributeIterateTag.class);
         
            if (attrIterTag != null)
            {
               attrDef = attrIterTag.getAttributeDef();
            }
            else
            {
               throw new JboException(Res.getString(Res.SHOWVALUE_NO_DATAITEM));
            }
         }
      }
      // Otherwise try to find an attributeIterateTag in the hierachy.
      else
      {
         // Look for the first RowsetIterate tag
         AttributeIterateTag  attrIterTag = (AttributeIterateTag)findAncestorWithClass(this, AttributeIterateTag.class);
         
         if (attrIterTag != null)
         {
            ds = attrIterTag.getDataSource();
            if (dataitem == null)
            {
               attrDef = attrIterTag.getAttributeDef();
            }
         }
         else
         {
            // Look for the first RowsetIterate
            RowsetIterateTag rowSITag = (RowsetIterateTag) findAncestorWithClass(this, RowsetIterateTag.class);

            if (rowSITag != null)
            {
               ds = rowSITag.getDataSource();
            }
            // If RowSetIterate failed, retrieve the datasource from the Row tag if any
            else
            {
               RowTag rowTag = (RowTag) findAncestorWithClass(this, RowTag.class);
               if (rowTag != null)
               {
                  ds = rowTag.getDataSource();
               }
            }
         }
      }

      if (ds == null)
      {
         throw new JboException(Res.getString(Res.NEED_DATASOURCE));
      }
      
      if (attrDef == null)
      {
         if (dataitem == null)
         {
            throw new JboException(Res.getString(Res.SHOWVALUE_NO_DATAITEM));
         }
         else
         {
            attrDef = ds.getRowSet().getViewObject().findAttributeDef(dataitem);
         }
      }
      
      return attrDef;
   }
   
   public int doEndTag() throws JspException
   {
      reset();
      return EVAL_PAGE;
   }

   private final void reset()
   {
      datasource = null;
      dataitem = null;
      ds = null;
   }
}

