/*
 * @(#)ChartRenderer.java
 *
 * Copyright 2000-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.html.databeans;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.StringTokenizer;
import java.util.Vector;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.http.HttpSessionBindingEvent;
import javax.servlet.http.HttpSessionBindingListener;
import javax.servlet.http.HttpUtils;
import javax.servlet.jsp.PageContext;
import oracle.jbo.html.databeans.chart.MethodInvoker;
import oracle.jbo.html.databeans.chart.RowOrderChartDataSource;
import tdg.Perspective;

/**
 *  Chart web bean to render chart as GIF files.
 *  <P>
 *  This bean renders the view as a chart GIF image.
 *  It internally uses Perspective bean to render the
 *  data as GIF. This bean is made is exposed through
 *  getChart() method.
 *  <P>
 *  Usage :
 *  <P>
 *  <PRE>
 *
 *  &ltjsp:useBean   class="oracle.jbo.html.databeans.ChartRenderer id="c"  scope="request" &gt
 *
 *  &lt%
 *
 *     c.setReleaseApplicationResources(false);
 *     c.initialize(application,session, request,response,out,"package23_Package23Module.EmpView");
 *
 *     c.getChart().setTitleString("Leading company Corp.");
 *     c.getChart().setSubtitleString("Employee Sales-Commision chart");
 *     c.getChart().setFootnoteString("Year-1999-2000");
 *     c.setMappingColumnNames("Sal,Comm"); // draw these column's
 *     c.setSeriesLabelColumnName("Ename"); // use this column as series label
 *     c.setImageWidth(600);
 *     c.setImageHeight(600);
 *     c.execute();
 *   %&gt
 *
 *   &lt/jsp:useBean&gt
 *
 *
 *   //ChartCommon.jsp
 *
 *
 *
 *
 *   </PRE>
 *
 *
 *  @see    tdg.Perspective
 *  @version PUBLIC
 *
 */
public class ChartRenderer extends oracle.jbo.html.DataWebBeanImpl
             implements HttpSessionBindingListener
{

    // constants for various chart types

    // Three D charts
    public final static int THREED_BARS = 0;
    public final static int THREED_PYRAMIDS = 1;
    public final static int THREED_OCTAGONS = 2;
    public final static int THREED_FLOATING_CUBES = 4;
    public final static int THREED_FLOATING_PYRAMIDS = 5;
    public final static int THREED_FLOATING_CONNECTED_SERIES_AREA = 6;
    public final static int THREED_FLOATING_CONNECTED_SERIES_RIBBON = 7;
    public final static int THREED_FLOATING_CONNECTED_GROUP_AREA = 9;
    public final static int THREED_FLOATING_CONNECTED_GROUP_RIBBON = 10;
    public final static int THREED_SURFACE = 12;
    public final static int THREED_SURFACE_WITH_SIDES = 13;
    public final static int THREED_HONEYCOMB_SURFACE = 14;


    //Two D charts
    public final static int VERTICAL_CLUSTERED_BARS = 17;
    public final static int VERTICAL_STACKED_BARS = 18;
    public final static int VERTICAL_DUAL_AXIS_CLUSTERED_BARS = 19;
    public final static int VERTICAL_DUAL_AXIS_STACKED_BARS = 20;
    public final static int VERTICAL_BI_POLAR_CLUSTERED_BARS = 21;
    public final static int VERTICAL_BI_POLAR_STACKED_BARS = 22;
    public final static int VERTICAL_PERCENT_BARS = 23;

    // Bar charts - Horizontal
    public final static int HORIZONTAL_CLUSTERED_BARS = 24;
    public final static int HORIZONTAL_STACKED_BARS = 25;
    public final static int HORIZONTAL_DUAL_AXIS_CLUSTERED_BARS = 26;
    public final static int HORIZONTAL_DUAL_AXIS_STACKED_BARS = 27;
    public final static int HORIZONTAL_BI_POLAR_CLUSTERED_BARS = 28;
    public final static int HORIZONTAL_BI_POLAR_STACKED_BARS = 29;
    public final static int HORIZONTAL_PERCENT_BARS = 30;


    // Area charts - Vertical
    public final static int VERTICAL_ABSOLUTE_AREA = 31;
    public final static int VERTICAL_STACKED_AREA = 32;
    public final static int VERTICAL_BI_POLAR_ABSOLUTE_AREA = 33;
    public final static int VERTICAL_BI_POLAR_STACKED_AREA = 34;
    public final static int VERTICAL_PERCENT_AREA = 35;

    // Area charts - Horizontal
    public final static int HORIZONTAL_ABSOLUTE_AREA = 36;
    public final static int HORIZONTAL_STACKED_AREA = 37;
    public final static int HORIZONTAL_BI_POLAR_ABSOLUTE_AREA = 38;
    public final static int HORIZONTAL_BI_POLAR_STACKED_AREA = 39;
    public final static int HORIZONTAL_PERCENT_AREA = 40;

    // Line charts - Vertical
    public final static int VERTICAL_ABSOLUTE_LINE = 41;
    public final static int VERTICAL_STACKED_LINE = 42;
    public final static int VERTICAL_DUAL_AXIS_ABSOLUTE_LINE = 43;
    public final static int VERTICAL_DUAL_AXIS_STACKED_LINE = 44;
    public final static int VERTICAL_BI_POLAR_ABSOLUTE_LINE = 45;
    public final static int VERTICAL_BI_POLAR_STACKED_LINE = 46;
    public final static int VERTICAL_PERCENT_LINE = 47;

    // Line charts - Horizantal
    public final static int HORIZONTAL_ABSOLUTE_LINE = 48;
    public final static int HORIZONTAL_STACKED_LINE = 49;
    public final static int HORIZONTAL_DUAL_AXIS_ABSOLUTE_LINE = 50;
    public final static int HORIZONTAL_DUAL_AXIS_STACKED_LINE = 51;
    public final static int HORIZONTAL_BI_POLAR_ABSOLUTE_LINE = 52;
    public final static int HORIZONTAL_BI_POLAR_STACKED_LINE = 53;
    public final static int HORIZONTAL_PERCENT_LINE = 54;


    //Pie charts
    public final static int PIE = 55;
    public final static int RING_PIE = 56;
    public final static int MULTI_PIE = 57;
    public final static int MULTI_RING_PIE = 58;
    public final static int MULTI_PROPORTIONAL_PIE = 59;
    public final static int MULTI_PROPORTIONAL_RING_PIE = 60;
    public final static int PIE_BAR_CHART = 93;
    public final static int RING_PIE_BAR_CHART = 94;


    // Scatter charts
    public final static int XY_SCATTER = 61;
    public final static int XY_SCATTER_DUAL_AXIS = 62;
    public final static int XY_SCATTER_WITH_LABELS = 63;
    public final static int XY_SCATTER_WITH_LABELS_DUAL_AXIS = 64;


    public final static int POLAR = 65;
    public final static int POLAR_DUAL_AXIS = 66;


    public final static int RADAR_LINE =  67;
    public final static int RADAR_AREA =  68;
    public final static int RADAR_LINE_DUAL_AXIS =  69;

    // HI LO charts
    public final static int OPEN_HI_LO_CLOSE_CANDLE_STOCK_CHART = 70;
    public final static int OPEN_HI_LO_CLOSE_CANDLE_STOCK_CHART_VOLUME = 71;
    public final static int CANDLE_STOCK_HI_LO_OPEN_CLOSE = 72;
    public final static int STOCK_HI_LO = 73;
    public final static int STOCK_HI_LO_DUAL_AXIS = 74;
    public final static int STOCK_HI_LO_BI_POLAR = 75;
    public final static int STOCK_HI_LO_CLOSE = 76;
    public final static int STOCK_HI_LO_CLOSE_DUAL_AXIS = 77;
    public final static int STOCK_HI_LO_OPEN_CLOSE = 79;
    public final static int STOCK_HI_LO_OPEN_CLOSE_DUAL_AXIS = 80;
    public final static int STOCK_HI_LO_OPEN_CLOSE_BI_POLAR = 81;
    public final static int STOCK_HI_LO_VOLUME = 82;
    public final static int STOCK_HI_LO_OPEN_CLOSE_VOLUME = 83;
    public final static int CANDLE_STOCK_HI_LO_OPEN_CLOSE_VOLUME = 84;

    public final static int VERTICAL_HISTOGRAM = 85;
    public final static int HORIZONTAL_HISTOGRAM = 86;

    public final static int SPECTRAL_MAP = 87;

    public final static int BUBBLE_CHART = 89;
    public final static int BUBBLE_CHART_LABELS = 90;
    public final static int BUBBLE_CHART_DUAL_AXIS = 91;
    public final static int BUBBLE_CHART_LABELS_DUAL_AXIS = 92;


    /**
    * Properties file used by MethodInvoker to set properties for Perspective
    */
    private static final String PFJ_PROPERTIES_FILE_NAME=
      "/oracle/jbo/html/databeans/chart/Perspective.properties";

    /**
    * Properties file used by MethodInvoker to set properties on ChartRenderer
    */
    private static final String CHART_RENDERER_PROPERTIES_FILE_NAME=
       "/oracle/jbo/html/databeans/chart/ChartRenderer.properties";


    // image dimensions

    /**
    * image width
    */
    private int width  = 400;

    /**
    * image height
    */
    private int height = 400;

    /**
    * The chart rendering engine.
    */
    private Perspective chart = new Perspective();

    /**
    * The data model for the chart rendering engine. The data model uses the
    * RowSet to serve data for the chart
    */
    private RowOrderChartDataSource chartDataSource  =
                                         new RowOrderChartDataSource(chart);

    /**
    * A helper object to invoker methods on the PFJ bean
    */
    MethodInvoker perspectiveMethodInvoker = null;

    /**
    * A helper object to invoker methods on this bean
    */
    MethodInvoker selfMethodInvoker = null;

    /**
    * register listener to clean up
    */
    protected static boolean cleanupRegistered = false;

    /**
    * unique prefix., used while generating key  for image objects stored
    * in the session. Later used in cleanup when the session expires
    */
    protected static String prefixString = "orachart111";

    /**
    * used in the url to identify the chart id
    */
    protected static final String ID="id";

    /**
    * used in the url to idenfiy the view name
    */
    public static final String VIEWNAME="ViewName";

    /**
    * name of the common jsp file which is shared by all chart objects
    * The common jsp file invokes the render method. All other chart
    * reference invoke the execute method
    */
    protected String commonScriptName = "ChartCommon.jsp";


    /**
    * Constructor
    */
    public ChartRenderer()
    {
    }

	public void init(PageContext pageContext)
	{
		this.application = pageContext.getServletContext();
		this.session = pageContext.getSession();
		this.request = (HttpServletRequest) pageContext.getRequest();
		this.response = (HttpServletResponse) pageContext.getResponse();
		this.out = new PrintWriter(pageContext.getOut());
	}

    public void internalInitialize()
      throws Exception
    {
        super.internalInitialize();

		chartDataSource.setRowSet(getRowSet());

	    registerCleanup();
    }


    /**
    * Specify mapping description using columnNames.
    *
    *
    * @param s   List of column names in the underlying View object
    *            The resultant data source will have as column 0,
    *            column values from the view object whose column name is
    *            columnNames[0] and so on.
    *
    *            A Comma seperated list should be provided
    *            (ex) "comm,deptno,sales"
    *
    * @see setDisplayColumnIndices()
    */
    public void setDisplayAttributes(String s)

    {
        StringTokenizer st  = new StringTokenizer(s,",", false);
        String[] columnNames = new String[st.countTokens()];
        int i = 0;
        while (st.hasMoreTokens())
              columnNames[i++] = st.nextToken();
        chartDataSource.setMappingColumnNames(columnNames);

    }

    /**
    * get the current list of mapped columns
    *
    * @return list of columns from the View which is used to draw chart.
    */
    public Vector getDisplayAttributes()
    {
        String[] colNames = chartDataSource.getMappingColumnNames();
        Vector v = new Vector(colNames.length);

        for( int i=0; i < colNames.length ; i++)
           v.addElement(colNames[i]);
        return v;
    }

    /**
    * Specify mapping description using column indices.
    * This is an alternative way to specify the columns from the ViewObject
    * which are used to draw chart.
    *
    *
    * @param indices  List of column indices in the underlying View object
    *                 The resultant data source will have as column 0,
    *                 column values from the view object whose column index is
    *                 indices[0] and so on.
    *
    *
    *
    */
    public void setDisplayColumnIndices(String indices)
    {
        StringTokenizer st  = new StringTokenizer(indices,",", false);
        int[] columnIndices = new int[st.countTokens()];
        int i = 0;
        while (st.hasMoreTokens())
        {
              String s = st.nextToken();
              columnIndices[i++] = Integer.parseInt(s);
        }
        chartDataSource.setMappingColumnIndices(columnIndices);

    }

    /**
    * get list of column indices from the View object which is used to
    * draw chart.
    *
    * @return list of column indices - comma seperated.
    */
    public String getDisplayColumnIndices()
    {
        int[]  colIndices = chartDataSource.getMappingColumnIndices();
        int len = colIndices.length;

        if ( len == 0 )
            return "";
        else if ( len == 1)
            return Integer.toString(colIndices[0]);
        else
        {
           String s ="";
           for( int i=0; i < colIndices.length - 1 ; i++)
               s += colIndices[i] + ",";
           return (s + colIndices[len-1]);
        }

    }

    /**
    *  Specify the name of the column in the ViewObject which should be
    *  used as series labels
    *
    *  @param name of the column in the viewobject whose values should be
    *         used as series labels.
    */
    public void setSeriesLabelColumnName(String columnName)
    {
        chartDataSource.setRowLabelColumnName(columnName);
    }

    /**
    *  get the name of the column in the view object which is currently
    *  used as series labels.
    */
    public String getSeriesLabelColumnName()
    {
        return chartDataSource.getRowLabelColumnName();
    }

    /**
    *  Generates a IMG tag pointing to the common JSP page
    *  to generate the chart. This object is stored in the
    *  HttpSession and an identifier is passed in the URL.
    *
    *  @see execute()
    */
    public void render()
    {
        String id = generateUniqueId();
        session.setAttribute(id, this);
        String idParam = ID + "=" + id;
        String viewNameParam = VIEWNAME + "=" + getApplicationName()
                    + "." +getViewObjectName() ;
        String url = getCommonScriptName() + "?" + viewNameParam + "&" +
                                                         idParam  ;
        //String encodedUrl = response.encodeURL(url);
        String link = "<IMG SRC=\"" + url + "\" WIDTH= " +
                  getImageWidth() + " HEIGHT=" + getImageHeight() + ">";
        out.println(link);
    }

    /**
    * render chart. This method generates the chart for this object
    * or if a chart is specified in the URL, generates the chart
    * for the specified object.
    * @see render();
    */
    public void execute()
    {
		try
		{
			String id = request.getParameter(ID);
			if ( id == null )
			   this.execute(this);
			else
			{
			   Object val = session.getAttribute(id);
			   this.execute(val);
			}
		}
		catch(Exception exc)
		{
			exc.printStackTrace(); 
		}
        
    }

    protected void execute(Object o)
    {
        if ( o instanceof ChartRenderer)
        {
            response.setContentType("image/gif");
            ChartRenderer c = (ChartRenderer)o;
            generateImage(c);
        }
        else
            out.println("render method + <B> " + o.toString() + "</B>");
    }



    /**
    * set the width of the chart to be generated.
    *
    * @param width of the chart to be generated
    */
    public void setImageWidth(int width)
    {
        this.width = width;
    }

    /**
    * get the width of the chart image to be generated
    *
    * @return current width of the chart.
    */
    public int getImageWidth()
    {
        return width;
    }

    /**
    * set the height of the chart image to be generated
    *
    * @param height Height of the chart image generated
    */
    public void setImageHeight(int height)
    {
        this.height = height;
    }

    /**
    * get the width of the chart image to be generated
    *
    * @return current width of the chart.
    */
    public int getImageHeight()
    {
       return height;
    }

    /**
    *  get the Perspective bean which does the rendering.
    *
    *  @return the chart bean
    */
    public Perspective getChart()
    {
         return chart;
    }

    /**
    * Specify the JSP file which generates the chart.
    * This JSP file instantiates a chart object and invokes the
    * render method.
    */
    public void setCommonScriptName(String name)
    {
       commonScriptName = name;
    }

    public String getCommonScriptName()
    {
        return commonScriptName ;
    }





    /**
    * One or more property values for the ChartRenderer or the Perspective
    * bean can be passed in the URL. The name-value pairs are parsed and
    * the value is set on the bean.
    *
    * The following files contains the list of properties for PFJ bean and
    * the chart bean
    *
    *  PFJ_PROPERTIES_FILE_NAME,
    *  CHART_RENDERER_PROPERTIES_FILE_NAME
    *
    */
    protected void readUrlProperties()
    {
        String queryString = request.getQueryString();
        if ( queryString != null)
        {
           Hashtable h = HttpUtils.parseQueryString(queryString);
           processUrlProperties(h);
        }
    }

    /**
    *  For each property name-value pair speicifed in the URL, invoke
    *  the set method on the bean
    */
    protected void processUrlProperties(Hashtable h)
    {
        Enumeration e = h.keys();

        while (e.hasMoreElements())
        {
            Object k = e.nextElement();
            String[] v = (String[])h.get(k);
            processElement((String)k, v[0]);
        }
    }

    /**
    *  set property for a given name-value pair
    */
    protected void processElement(String k, String val)
    {
      try
      {
           selfMethodInvoker.invokeSetProperty(k, val);
      }
      catch( Exception e)
      {
          try
          {
              if ( perspectiveMethodInvoker != null )
                  perspectiveMethodInvoker.invokeSetProperty(k, val);
          }
          catch( Exception exc)
          {
              throw new RuntimeException(exc.getMessage());
          }
      }
    }

    /**
    *  generate the GIF file and serve the image
    */
    protected void generateImage(ChartRenderer c)
    {

        Perspective p = c.getChart();
        p.setSize(c.getImageWidth(), c.getImageHeight());
        p.setDataFromDataGrid(c.getChartDataSource());
        try
        {
            response.setContentType("image/gif");
            p.sendGIFToStream(response.getOutputStream());
        }
        catch(IOException exc)
        {
            throw new RuntimeException(exc.getMessage());
        }
    }

    /**
    *  get the chart data source
    */
    protected RowOrderChartDataSource getChartDataSource()
    {
        return chartDataSource;
    }

    /**
    * register HTTP Session binding listner to cleanup the
    * chart objects generated in this session
    */
    protected void registerCleanup( )
    {
        synchronized(this)
        {
            if ( cleanupRegistered )
               return;
            if ( session != null )
            {
               session.setAttribute("bindings.listener", this);
               cleanupRegistered = true;
            }
        }
    }

    /**
    * unregister HTTP Session binding listner used to cleanup the
    * chart objects generated in this session
    */
    protected void unregisterCleanup()
    {
        synchronized(this)
        {
            if ( !cleanupRegistered )
               return;
            if ( session != null )
            {
              session.removeAttribute("bindings.listener");
              cleanupRegistered = false;
            }
        }
    }

    /**
    *  generated an unique id to identify chart., used in the url parameter
    */
    protected String generateUniqueId()
    {
        String uid = new java.rmi.server.UID().toString();
        return prefixString + uid;
    }


    // HttpSessionBindingListener interface
    public void valueBound(HttpSessionBindingEvent event)
    {
       // no op
    }

    public void valueUnbound(HttpSessionBindingEvent event)
    {
        HttpSession session = event.getSession();
        try
        {
            Enumeration e = session.getAttributeNames();
            while(e.hasMoreElements())
            {
               String sName = (String)e.nextElement();
                if (sName.startsWith(prefixString))
                   session.removeAttribute(sName);
            }
        }
        catch(Exception e)
        {
        }
    }
}
