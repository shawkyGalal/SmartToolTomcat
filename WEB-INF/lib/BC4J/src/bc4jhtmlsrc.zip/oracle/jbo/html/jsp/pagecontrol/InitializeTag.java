package oracle.jbo.html.jsp.pagecontrol;

import javax.servlet.jsp.tagext.TagSupport;
import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.BufferedReader;
import javax.servlet.http.HttpServletRequest;
import java.io.File;
import java.io.FileOutputStream;

public class InitializeTag extends TagSupport 
{
  private static String sScript = null;

  private void loadScriptSource() throws Exception
  {
      if(sScript == null)
      {
         sScript = "";
         
         InputStream in = getClass().getResourceAsStream("rendering.js");
         BufferedReader reader = new BufferedReader(new InputStreamReader(in));

         String sLine = reader.readLine();

         while(sLine != null)
         {
            sScript += sLine + "\n";
            sLine = reader.readLine();
         }
         in.close();
      }
  }
  /**
   * Method called at start of tag.
   * @return SKIP_BODY
   */
  public int doStartTag() throws JspException
  {
    try
    {
      String sRegion = pageContext.getRequest().getParameter("updateRegion");

      if(sRegion != null)
        return SKIP_BODY;
        
      if(pageContext.getAttribute("pagecontrol_initialized") != null)
        return SKIP_BODY;
        
      JspWriter out = pageContext.getOut();

      loadScriptSource();
      
      String sPath = ((HttpServletRequest)pageContext.getRequest()).getPathTranslated();

      if(sPath == null)
      {
         out.println("<SCRIPT>");
         out.println(sScript);
         out.println("</SCRIPT>");
      }
      else
      {
        File inFile = new File(sPath);
        String sScriptFile = inFile.getParent() + "/rendering.js";
        File scriptFile = new File(sScriptFile);
        
        if(!scriptFile.exists())
        {
          scriptFile.createNewFile();
          FileOutputStream outStrm = new FileOutputStream(scriptFile);

          outStrm.write(sScript.getBytes());
          outStrm.flush();
          outStrm.close();
        }

        out.println("<SCRIPT HREF=\"rendering.js\" />");
      }
      pageContext.setAttribute("pagecontrol_initialized","Y");
    }
    catch(Exception e)
    {
      e.printStackTrace();
    }

    return SKIP_BODY;
  }


  /**
   * Method called at end of tag.
   * @return SKIP_PAGE
   */
  public int doEndTag()
  {
    return EVAL_PAGE;
  }
}