/*
 * @(#)OnEventTag.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.html.jsp.datatags;

import java.util.StringTokenizer;
import javax.servlet.jsp.JspException;
import javax.servlet.jsp.tagext.TagSupport;
import oracle.jbo.JboException;
import oracle.jbo.html.DataSource;
import oracle.jbo.html.HtmlServices;
import oracle.jbo.html.RequestParameters;

public class OnEventTag extends TagSupport
{
   public static final String JBOEVENT = "jboEvent";
   public static final String JBOEVENTVO = JBOEVENT + "Vo";
   
   protected String name;
   protected String list;
   protected String voName;
   protected String dsName;
   protected String eventVoName;
   protected String eventAction;
   private RequestParameters params;
   
   public OnEventTag()
   {
      super();
      reset();
   }

   public void setList(String sValue)
   {
      this.list = sValue;
   }

   public void setName(String sValue)
   {
      name = sValue;
      name.trim();
   }

   public void setViewobject(String sValue)
   {
      this.voName = sValue;
   }

   public void setDatasource(String sValue)
   {
      this.dsName = sValue;
   }

   public String getAction()
   {
      return eventAction;
   }

   public int doStartTag() throws JspException
   {
      initialize();

      // If the user specified a specific target (optionnal) we have to respect it
      if (eventAction != null &&
         (voName == null || (eventVoName != null && voName.equals(eventVoName))))
      {
         if (list != null)
         {
            StringTokenizer st = new StringTokenizer(list, ",");
            while (st.hasMoreTokens())
            {
               if (eventAction.equalsIgnoreCase(st.nextToken().trim()))
               {
                  return EVAL_BODY_INCLUDE;
               }
            }
         }
   
         if (name != null)
         {
            if (name.equals("*") || name.equalsIgnoreCase(eventAction))
            {
               return EVAL_BODY_INCLUDE;
            }
         }
      }
      
      return SKIP_BODY;
   }

   public int doEndTag() throws JspException
   {
      reset();
      return EVAL_PAGE;
   }
   
   protected void initialize()
   {
      params = HtmlServices.getRequestParameters(pageContext);
      
      if (dsName != null)
      {
         if (voName != null)
         {
            throw new JboException(Res.getString(Res.EVENT_ONLY_DS_VO));
         }
         
         final DataSource ds = Utils.getDataSourceFromContext(pageContext, dsName);
         voName = ds.getViewObjectName();
      }
      
      eventAction = params.getParameter(JBOEVENT);
      eventVoName = params.getParameter(JBOEVENTVO);
   }

   private final void reset()
   {
      name = null;
      list = null;
      voName = null;
      dsName = null;
      eventAction = null;
      eventVoName = null;
   }

}
