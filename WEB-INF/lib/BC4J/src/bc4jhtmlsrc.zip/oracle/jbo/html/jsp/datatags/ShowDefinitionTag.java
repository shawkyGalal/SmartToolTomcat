/*
 * @(#)ShowDefinitionTag.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.html.jsp.datatags;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspTagException;
import javax.servlet.jsp.tagext.Tag;
import oracle.jbo.AttributeDef;
import oracle.jbo.html.HtmlServices;

public class ShowDefinitionTag extends ShowTagBase
{
   public static final String NAME_PARAM = "NAME";
   public static final String COLUMNNAME_PARAM = "COLUMNNAME";
   public static final String COLUMNNAMEFORQUERY_PARAM = "COLUMNNAMEFORQUERY";
   public static final String JAVATYPE_PARAM = "JAVATYPE";
   public static final String SQLTYPE_PARAM = "SQLTYPE";
   public static final String SCALE_PARAM = "SCALE";
   public static final String PRECISION_PARAM = "PRECISION";
   public static final String QUERIABLE_PARAM = "QUERIABLE";
   public static final String PRIMARYKEY_PARAM = "PRIMARYKEY";
   public static final String MANDATORY_PARAM = "MANDATORY";
   public static final String UPDATEABLE_PARAM = "UPDATEABLE";
   public static final String KIND_PARAM = "KIND";
   public static final String DISPLAYRENDERER_PARAM = "DISPLAYRENDERER";
   public static final String EDITRENDERER_PARAM = "EDITRENDERER";
   
   protected String sDefItem; // required attribute

   public void setDefinition(String sValue)
   {
      this.sDefItem = sValue;
   }

   public int doStartTag() throws JspException
   {
      AttributeDef   attrDef = getAttributeDef();
      String         output = "&nbsp;";

      if (sDefItem.equalsIgnoreCase(NAME_PARAM))
      {
         output = attrDef.getName();
      }
      else if (sDefItem.equalsIgnoreCase(COLUMNNAME_PARAM))
      {
         output = attrDef.getColumnName();
      }
      else if (sDefItem.equalsIgnoreCase(COLUMNNAMEFORQUERY_PARAM))
      {
         output = attrDef.getColumnNameForQuery();
      }
      else if (sDefItem.equalsIgnoreCase(JAVATYPE_PARAM))
      {
         output = attrDef.getJavaType().getName();
      }
      else if (sDefItem.equalsIgnoreCase(SQLTYPE_PARAM))
      {
         output = Integer.toString(attrDef.getSQLType());
      }
      else if (sDefItem.equalsIgnoreCase(SCALE_PARAM))
      {
         output = Integer.toString(attrDef.getScale());
      }
      else if (sDefItem.equalsIgnoreCase(PRECISION_PARAM))
      {
         output = Integer.toString(attrDef.getPrecision());
      }
      else if (sDefItem.equalsIgnoreCase(QUERIABLE_PARAM))
      {
         output = attrDef.isQueriable()?"True":"False";
      }
      else if (sDefItem.equalsIgnoreCase(PRIMARYKEY_PARAM))
      {
         output = attrDef.isPrimaryKey()?"True":"False";
      }
      else if (sDefItem.equalsIgnoreCase(MANDATORY_PARAM))
      {
         output = attrDef.isMandatory()?"True":"False";
      }
      else if (sDefItem.equalsIgnoreCase(UPDATEABLE_PARAM))
      {
         switch (attrDef.getUpdateableFlag())
         {
            case AttributeDef.READONLY:
               output = "READONLY";
               break;
         
            case AttributeDef.UPDATEABLE_WHILE_NEW:
               output = "UPDATEABLE_WHILE_NEW";
               break;

            case AttributeDef.UPDATEABLE:
               output = "UPDATEABLE";
               break;

            default:
               output = "Undefined";
         }
      }
      else if (sDefItem.equalsIgnoreCase(KIND_PARAM))
      {
         switch (attrDef.getAttributeKind())
         {
            case AttributeDef.ATTR_PERSISTENT:
               output = "PERSISTENT";
               break;

            case AttributeDef.ATTR_SQL_DERIVED:
               output = "SQL_DERIVED";
               break;

            case AttributeDef.ATTR_ASSOCIATED_ROW:
               output = "ASSOCIATED_ROW";
               break;

            case AttributeDef.ATTR_TRANSIENT:
               output = "TRANSIENT";
               break;

            case AttributeDef.ATTR_DYNAMIC:
               output = "DYNAMIC";
               break;

            case AttributeDef.ATTR_ENTITY_DERIVED:
               output = "ENTITY_DERIVED";
               break;

            case AttributeDef.ATTR_ASSOCIATED_ROWITERATOR:
               output = "ASSOCIATED_ROWITERATOR";
               break;

            default:
               output = "Undefined";
         }
      }
      else if (sDefItem.equalsIgnoreCase(DISPLAYRENDERER_PARAM))
      {
         output = ds.getFieldRendererClassName(pageContext, null, attrDef, HtmlServices.DISP_RENDERER_KEY); 
      }
      else if (sDefItem.equalsIgnoreCase(EDITRENDERER_PARAM))
      {
         output = ds.getFieldRendererClassName(pageContext, null, attrDef, HtmlServices.EDIT_RENDERER_KEY); 
      }
      
      try
      {
         pageContext.getOut().print(output);
      }
      catch (java.io.IOException ex)
      {
         pageContext.getServletContext().log(Res.getString(Res.IO_ERROR), ex);
         throw new JspTagException(ex.getMessage());
      }
      
      return Tag.SKIP_BODY;
   }

}

