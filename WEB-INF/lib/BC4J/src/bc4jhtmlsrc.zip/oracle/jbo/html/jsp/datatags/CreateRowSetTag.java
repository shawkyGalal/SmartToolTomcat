/*
 * @(#)DataSourceTag.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.html.jsp.datatags;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.PageContext;
import javax.servlet.jsp.tagext.Tag;
import javax.servlet.jsp.tagext.TagSupport;

import oracle.jbo.JboException;
import oracle.jbo.html.DataSource;

public class CreateRowSetTag extends TagSupport
{
   protected String sViewObject;
   protected String sRowSet;
   protected String sMasterRowSet;

   public CreateRowSetTag()
   {
      super();
      reset();
   }

   public void setName(String sValue)
   {
      this.sRowSet = sValue;
   }

   public void setViewobject(String sValue)
   {
      this.sViewObject = sValue;
   }

   public void setMasterrowset(String sValue)
   {
      this.sMasterRowSet = sValue;
   }
   
   
   public int doStartTag() throws JspException
   {
      int index = sViewObject.indexOf('.');
      
      if (index < 0)
      {
         throw new JboException(Res.getString(Res.INCORRECT_VIEWOBJECT_DEFINITION));
      }
      
      String appName = sViewObject.substring(0, index);
      String voName = sViewObject.substring(index + 1);
         
      DataSource ds = Utils.createDataSource(pageContext, appName, voName, sRowSet, id, true);

      // Set the attribute on the pageContext for the scriptable variable (PAGE_SCOPE because of Orion)
      pageContext.setAttribute(id, ds.getRowSet());
      
      // Set the attribute on the pageContext at REQUEST_SCOPE for DataSourceRef tag
      pageContext.setAttribute(id, ds.getRowSet(), PageContext.REQUEST_SCOPE);
      
      if (sMasterRowSet != null)
      {
         //$$$ Need to set master rowset here
      }

      return Tag.EVAL_BODY_INCLUDE;
   }

   public int doEndTag() throws JspException
   {
      reset();
      return Tag.EVAL_PAGE;
   }
   
   private void reset()
   {
      sMasterRowSet = null;
      sRowSet = null;
      sViewObject = null;
   }
}
