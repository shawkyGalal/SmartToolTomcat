/*
 * @(#)ToolBarButton.java
 *
 * Copyright 2000-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.html.databeans;

public class ToolBarButton extends Object
{
   static final int  TYPE_DIVIDER = 1;
   static final int  TYPE_BUTTON  = 2;

   protected int nType;

   // button state
   protected int nCommand;
   protected String sImageUrl;
   protected String sDisabledImageUrl;
   protected String sRolloverImageUrl;
   protected String sCommandUrl;
   protected String sTooltipText;
   protected String sTargetUrl;
   protected ToolBarButtonContainer container;

	protected boolean isButtonVisible = true;
	
   /**
    * Constructor
    */
   public ToolBarButton(int nType)
   {
      this.nType = nType;
   }

   /**
    * Constructor
    */
   public ToolBarButton()
   {
      // Default button is of type "BUTTON"
      this(TYPE_BUTTON);
   }

   public int getButtonType()
   {
      return nType;
   }

	public void setButtonVisible(boolean bSet)
	{
	  isButtonVisible = bSet;
	}

	public boolean isButtonVisible()
	{
	 return isButtonVisible;
	}
	
	public void setCommandId(int nCommand)
   {
      this.nCommand = nCommand;
   }

   public int getCommandId()
   {
      return this.nCommand;
   }

   public void setImageUrl(String sUrl)
   {
      this.sImageUrl = sUrl;
   }

   public String getImageUrl()
   {
      return this.sImageUrl;
   }

   public void setDisabledImageUrl(String sUrl)
   {
      this.sDisabledImageUrl = sUrl;
   }

   public String getDisabledImageUrl()
   {
      return this.sDisabledImageUrl;
   }
   
   public void setRolloverImageUrl(String sUrl)
   {
      this.sRolloverImageUrl = sUrl;
   }

   public String getRolloverImageUrl()
   {
      return this.sRolloverImageUrl;
   }
   
   public void setCommandUrl(String sUrl)
   {
      this.sCommandUrl = sUrl;
   }

   public String getCommandUrl()
   {
      return this.sCommandUrl;
   }

   public void setTargetUrl(String sUrl)
   {
      this.sTargetUrl = sUrl;
   }

   public String getTargetUrl()
   {
      return this.sTargetUrl;
   }
   
   public void setToolTipText(String sText)
   {
      this.sTooltipText = sText;
   }

   public String getToolTipText()
   {
      return this.sTooltipText;
   }

   public void setContext(ToolBarButtonContainer container)
   {
      this.container = container;
   }

   public boolean isEnabled()
   {
      if(nType == this.TYPE_DIVIDER)
         return true;
         
      return true;
   }
}

 