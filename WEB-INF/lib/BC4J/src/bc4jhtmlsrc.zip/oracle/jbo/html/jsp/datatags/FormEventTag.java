/*
 * @(#)FormEventTag.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.html.jsp.datatags;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.tagext.Tag;
import javax.servlet.jsp.tagext.TagSupport;
import oracle.jbo.JboException;
import oracle.jbo.Row;
import oracle.jbo.html.DataSource;
import oracle.jbo.html.BC4JContext;
import oracle.jdeveloper.html.HTMLInputElement;

public class FormEventTag extends TagSupport
{
   protected String event;
   protected String voName;
   protected String dsName;
   protected boolean addRowkey;

   public FormEventTag()
   {
      super();
      reset();
   }
   
   public void setEvent(String sValue)
   {
      this.event = sValue;
   }

   public void setViewobject(String sValue)
   {
      this.voName = sValue;
   }

   public void setDatasource(String sValue)
   {
      this.dsName = sValue;
   }

   public void setAddrowkey(String sValue)
   {
      this.addRowkey = Utils.isTrue(sValue);
   }

   public int doStartTag() throws JspException
   {
      String amId = null;

      final HTMLInputElement hiddenFieldEvent = HTMLInputElement.getHidden(OnEventTag.JBOEVENT, event);
      
      try
      {
         DataSource ds = null;
         if (dsName != null)
         {
            if (voName != null)
            {
               throw new JboException(Res.getString(Res.NEED_DS_OR_VO));
            }

            ds = Utils.getDataSourceFromContext(pageContext, dsName);
            voName = ds.getViewObjectName();
            amId = ds.getApplicationId();
         }
      
         HTMLInputElement hiddenFieldVoName = HTMLInputElement.getHidden(OnEventTag.JBOEVENTVO, voName);
         HTMLInputElement hiddenFieldAmId = null;
         if (amId != null)
         {
            hiddenFieldAmId = HTMLInputElement.getHidden("amId", amId);
         }
         
         Object bc4jContext = pageContext.getRequest().getAttribute(BC4JContext.ContextAttrName);
         
         HTMLInputElement hiddenFieldRowkey = null;
         String rowkey = null;
         if (addRowkey)
         {
            Row row = DataTagBase.getRowFromContext(this, dsName, ds);
            if (row == null)
            {
               throw new JboException(Res.getString(Res.CANT_FIND_ROW_FOR_ROWKEY));
            }
            rowkey = row.getKey().toStringFormat(true);

            if (rowkey != null)
            {
               hiddenFieldRowkey = HTMLInputElement.getHidden(DataTagBase.ROWKEY_PARAM, rowkey);
            }
         }
      
         pageContext.getOut().print(hiddenFieldEvent.getAsString());
         pageContext.getOut().print(hiddenFieldVoName.getAsString());
         if (hiddenFieldAmId != null)
         {
            pageContext.getOut().print(hiddenFieldAmId.getAsString());
         }
         
         if (hiddenFieldRowkey != null)
         {
            pageContext.getOut().print(hiddenFieldRowkey.getAsString());
         }
      }
      catch (Exception ex)
      {
         throw new JspException(ex.getMessage());
      }
      
      return Tag.SKIP_BODY;
   }

   public int doEndTag() throws JspException
   {
      reset();
      return EVAL_PAGE;
   }

   private final void reset()
   {
      event = null;
      voName = null;
      dsName = null;
      addRowkey = false;
   }

}
