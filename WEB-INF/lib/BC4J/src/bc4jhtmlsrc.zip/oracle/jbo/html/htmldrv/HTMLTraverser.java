/*
 * @(#)HTMLTraverser.java
 *
 * Copyright 1999-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.html.htmldrv;

import java.util.*;

/**
 *
 * @version INTERNAL
 */
class HTMLTraverser
{
   public static boolean traverse(IHTMLNodeVisitor visitor, IHTMLParserNode node)
   {
      boolean  bContinue = true;
      
      // visit the parent if it's not the base container
      if(node.getParent() != null)
      {
         bContinue = visitor.visit(node);
      }
      
      if(bContinue)
      {
         // visit the children
         Vector childnodes = node.getChildNodes();

         // it's not an error when there aren't child nodes, just return true
         if(childnodes == null)
            return true;
      
         int      nNodes = childnodes.size();


         for(int i  = 0 ; i < nNodes && bContinue ; i++)
         {
            bContinue = traverse(visitor , (IHTMLParserNode)childnodes.elementAt(i));
         }
      }
      
      return bContinue;
   }
   
}