/*
 * @(#)RenderValueTag.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.html.jsp.blaf;

import java.sql.Types;
import oracle.jbo.LocaleContext;
import oracle.cabo.ui.beans.StyledTextBean;
import oracle.jbo.AttributeDef;
import oracle.jbo.Row;
import oracle.jbo.ViewObject;
import oracle.jbo.html.DataSource;
import oracle.jbo.html.jsp.datatags.Utils;
import oracle.cabo.ui.beans.ImageBean;
import oracle.cabo.ui.beans.nav.LinkBean;
import oracle.ord.im.OrdDomainUtil;
import oracle.jbo.AttributeHints;
import oracle.cabo.ui.UIConstants;
import oracle.bali.share.util.BooleanUtils;
import oracle.jdeveloper.html.HTMLFieldRenderer;
import oracle.jbo.html.HtmlServices;
import oracle.cabo.ui.beans.RawTextBean;
import oracle.cabo.ui.jsps.tags.FlowLayoutTag;
import javax.servlet.jsp.tagext.TagSupport;
import oracle.cabo.ui.MutableUINode;
import oracle.cabo.ui.beans.layout.FlowLayoutBean;
import javax.servlet.jsp.PageContext;

public class RenderValueTag extends FlowLayoutTag
{
   String datasource;
   String dataitem;
   boolean useContextualBinding = true;

   /**
    * Constructor
    */
   public RenderValueTag() {
   }

   protected boolean hasCustomRenderer(AttributeDef aDef)
   {
      if(aDef.getProperty(HtmlServices.DISP_RENDERER_KEY) != null)
         return true;

      if (aDef.getSQLType() == Types.STRUCT)
      {
         return true; 
      }
      else if (aDef.getSQLType() == Types.ARRAY)
      {
         return true ; 
      }
      return false;
   }
   
   /**
    * initializeProperties
    */
   protected void setProperties(MutableUINode node)
   {
      super.setProperties(node);
      
      MutableUINode container = null;
      
      // determine the binding mode
      JboTableTag parent = (JboTableTag)TagSupport.findAncestorWithClass(this, JboTableTag.class);

      useContextualBinding = JboUtil.useUixBoundValue(this, datasource);

      DataSource     ds = Utils.getDataSourceFromContext(getPageContext(), datasource);
      ViewObject     view = ds.getRowSet().getViewObject();
      AttributeDef   aDef = view.findAttributeDef(dataitem);
      Row            row = Utils.getRowFromAncestor(this, datasource);
      String amConfig = null;

      if(row == null)
       row = ds.getRowSet().getCurrentRow();
          
      Class javaType = aDef.getJavaType();

      if(OrdDomainUtil.isOrdDomainType(aDef))
      {
        if(OrdDomainUtil.isOrdImageType(aDef))
        {
             //
             // If OrdImage, use an ImageBean
             //
             ImageBean imageBean = new ImageBean();
             container = imageBean;

             OrdUixJspUtil.bindJboImageBean(imageBean,
                                            this,
                                            datasource,
                                            dataitem,
                                            amConfig,
                                            getPageContext()
                                            );
    
           }else
           {
             /*
             //
             // If OrdAudio/OrdVideo/OrdDoc, use a MediaBean
             //
             
             MediaBean mediaBean = new MediaBean();
             container = mediaBean;

             OrdDomainUtil.bindJboMediaBean(mediaBean,
                                            this,
                                            datasource,
                                            dataitem,
                                            amConfig,
                                            retrievePath,
                                            pageContext
                                            );
             */

             // rw - I temporarily use LinkBean for MediaBean because
             //      JDev903 do not support UIX211 Taglib yet.
             LinkBean linkBean = new LinkBean();
             container = linkBean;

             OrdUixJspUtil.bindJboLinkBean( linkBean,
                                            this,
                                            datasource,
                                            dataitem,
                                            amConfig,
                                            getPageContext()
                                            );

           }
         }
         else
         {
            if(hasCustomRenderer(aDef))
            {
                container = new RawTextBean();

               if(useContextualBinding)
               {
                  container.setAttributeValue(oracle.cabo.ui.UIConstants.TEXT_ATTR,
                           new DataSourceBoundValue(getPageContext(), datasource, "DISPLAYRENDER:" + dataitem));
               }
               else
               {
                  // get the renderer and insert it's output now
                  HTMLFieldRenderer renderer = ds.getDisplayFieldRenderer(getPageContext(), row, aDef);
                  String sRendering = renderer.renderToString(row);
                  container.setAttributeValue(oracle.cabo.ui.UIConstants.TEXT_ATTR, sRendering);
               }
            }
            else
            {
               StyledTextBean bean = new StyledTextBean();
               container = bean;

               if(useContextualBinding)
                 bean.setTextBinding(new DataSourceBoundValue(getPageContext(), datasource, dataitem));
               else
               {
                 Object obj = null;
                 
                 if(dataitem.equalsIgnoreCase("rowkey"))
                  obj = row.getKey().toStringFormat(true);
                 else
                  obj = row.getAttribute(dataitem);
                  
                 if(obj != null)
                     bean.setText(obj.toString());
               }
            }
         }
         //show\hide the attribute
         if(container != null)
         {
            LocaleContext  locale =  view.getApplicationModule().getSession().getLocaleContext();
            boolean rendered = aDef.getUIHelper().getDisplayHint(locale).equals(AttributeHints.ATTRIBUTE_DISPLAY_HINT_DISPLAY);
            container.setAttributeValue(UIConstants.RENDERED_ATTR,  BooleanUtils.getBoolean(rendered));

            // add control to container
            FlowLayoutBean flowBean = (FlowLayoutBean)node;  
            flowBean.setAttributeValue(UIConstants.RENDERED_ATTR,  BooleanUtils.getBoolean(rendered));
            flowBean.addIndexedChild(container);
         }
      
   }

   public String getDatasource() {
      return datasource;
   }

   public void setDatasource(String newDatasource) {
      datasource = newDatasource;
   }

   public String getDataitem() {
      return dataitem;
   }

   public void setDataitem(String newDataitem) {
      dataitem = newDataitem;
   }

   protected PageContext getPageContext()
   {
      // TODO:  Override this oracle.cabo.ui.jsps.tags.BaseTag method
      return super.getPageContext();
   }

   
}

