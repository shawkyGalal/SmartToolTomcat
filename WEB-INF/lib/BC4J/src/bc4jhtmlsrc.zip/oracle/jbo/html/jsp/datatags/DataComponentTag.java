/*
 * @(#)DataComponentTag.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.html.jsp.datatags;


/**
 */
public class DataComponentTag extends ComponentTag
{
   public static final String DATASOURCE_PARAM = "datasource";
   public static final String paramNames[] = new String[]{ DATASOURCE_PARAM };
   protected String  sDatasource;
   
   public DataComponentTag()
   {
      super();
   }

   protected void reset()
   {
      sRelativeUrlPath = defaultUrl;
      sDatasource = null;
   }

   public void setDatasource(String sValue)
   {
      this.sDatasource = sValue;
   }

   public String getUrl()
   {
      return buildUrl(sRelativeUrlPath, paramNames, new String[]{ sDatasource });
   }
}
