/*
 * @(#)DataWebBean.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.html;

import javax.servlet.jsp.PageContext;

/**
 * Defines the base methods for a Data Web Bean. Implement this interface when
 * you define a Web Bean that must access a data source.
 *
 */
public interface DataWebBean extends oracle.jdeveloper.html.DataWebBean
{
   public void initialize(PageContext page, DataSource dsFromTag) throws Exception;
}
