/*
 * @(#)ChartLabelTableColumnNames.java
 *
 * Copyright 2000-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.html.databeans.chart;

import oracle.jbo.AttributeDef;
import oracle.jbo.RowSet;

/**
 * chart labels derived from column names of the table
 *
 * @version Internal
 */
class ChartLabelTableColumnNames extends ChartLabelDataSourceImpl
{
    ChartLabelTableColumnNames(ChartDataSource parent)
    {
       super(parent);
    }

    public void setRowSet(RowSet qView)
    {
        super.setRowSet(qView);
        _updateLabels();
    }

    private void _updateLabels()
    {
         setLabels(_getColumnNamesFromRowset(_qView));
    }

    private Object[] _getColumnNamesFromRowset(RowSet rs)
    {
         if ( rs != null )
         {
             int colCount = rs.getViewObject().getAttributeCount();
             AttributeDef[]    attrs =  rs.getViewObject().getAttributeDefs();
             Object labels[] = new Object[colCount];
             for ( int i=0 ; i < attrs.length ;i++)
                    labels[i] = attrs[i].getName();
             return labels;
         }
         return null;
    }
 }
