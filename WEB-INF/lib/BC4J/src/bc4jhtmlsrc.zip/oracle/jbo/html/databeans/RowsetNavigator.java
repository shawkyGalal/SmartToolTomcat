/*
 * @(#)RowsetNavigator.java
 *
 * Copyright 1999-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.html.databeans;

import oracle.jbo.ApplicationModule;
import oracle.jbo.DMLException;
import oracle.jbo.JboException;
import oracle.jbo.Key;
import oracle.jbo.Row;
import oracle.jbo.RowNotFoundException;
import oracle.jbo.RowSet;
import oracle.jbo.common.TransPostControl;

/**
 * The RowsetNavigator Data Web Bean changes the current record of a View
 * Object's RowSet to a new record.
 * <P>
 * The <TT>RowsetNavigator</TT> class, which is aggregated by the NavigationBar
 * Data Web Bean, processes any navigation requests passed to the page from the
 * toolbar. These navigation requests are determined by the value of the NAVIGATE
 * parameter from the JSP's request and set the current
 * record of the View Object's RowSet to the appropriate record. The possible
 * values for NAVIGATE and their associated actions are:
 * <p>
 * <ul>
 *     <LI>NEXT - goto the next record</LI>
 *     <LI>PREV - goto the previous record</LI>
 *     <LI>FIRST - goto the first record</LI>
 *     <LI>LAST - goto the last record</LI>
 *     <LI>NEXTSET - goto the next page</LI>
 *     <LI>PREVSET - goto the previous page</LI>
 *     <LI>DELETE - delete the current record</LI>
 *     <LI>COMMIT - commit the current record to the database</LI>
 *     <LI>ROLLBACK - discard changes to the record</LI>
 * </ul>
 * <P>
 * JDeveloper's JSP Element wizard instantiates the <TT>RowsetNavigator</TT>
 * class in a <TT>jsp:useBean</TT> tag in a <TT>.jsp</TT> file. Along with the
 * class, the wizard also includes an ID and a scope declaration set to
 * <TT>request</TT>.
 * If you change the scope to any other value, you will have
 * to handle possible multithreading issues.
 * <P>
 * The definition of the
 * RowSet navigator provided by the wizard includes these methods:
 * <TT>setReleaseApplicationResources</TT>,
 * <TT>initialize</TT>, and <TT>render</TT>. For example,
 * <PRE>
 *  &lt;jsp:useBean   class="oracle.jbo.html.databeans.RowsetNavigator"
 *                  id="navDetail"  scope="request" &gt;
 *  &lt;%
 *
 * 	navDetail.setReleaseApplicationResources(false);
 *	navDetail.initialize(application,session, request,response,out,
 *          "package3_Package3Module.EmpView");
 *	navDetail.render();
 *   %&gt;
 *   &lt;/jsp:useBean&gt;>
 * </PRE>
 * <P>
 * The value assigned to the <TT>setReleaseApplicationResources</TT> method
 * determines whether the Application Module is released after
 * RowsetNavigator Data Web Bean processes it. Typically, the value should
 * not be set to true unless this is the last Web Bean to be processed in
 * the JSP page.
 * <P>
 * Do not include more than one instance of RowsetNavigator bound to
 * the same View Object on a JSP page. If you do, the toolbar action will
 * be performed more than once. For example, if you have two instances of RowsetNavigator
 * bound to the same View Object, and you click the Next Record button on the
 * toolbar bound to the View Object, then the display will skip ahead two
 * records.
 *
 **/
public class RowsetNavigator extends oracle.jbo.html.DataWebBeanImpl
{
   boolean bAutoexecute = false;
   
   public RowsetNavigator()
   {
   }

   /**
    * Reads the NAVIGATE parameter from the JSP's request and sets the current
    * record of the View Object's RowSet to the appropriate record. The possible
    * values for NAVIGATE are:
    * <p>
    * <ul>
    *     <LI>NEXT - goto the next record</LI>
    *     <LI>PREV - goto the previous record</LI>
    *     <LI>FIRST - goto the first record</LI>
    *     <LI>LAST - goto the last record</LI>
    *     <LI>NEXTSET - goto the next page</LI>
    *     <LI>PREVSET - goto the previous page</LI>
    *     <LI>DELETE - delete the current record</LI>
    *     <LI>COMMIT - commit the current record to the database</LI>
    *     <LI>ROLLBACK - discard changes to the record</LI>
    * </ul>
    *
    *
    */
   public void execute() throws Exception
   {
      RowSet rs = ds.getRowSet();
      String sNavigation = request.getParameter(rs.getName() + "_NAVIGATE");
      Row    row = null;

      // see if we have a row index
      String sRowKey = request.getParameter(rs.getName() + EditCurrentRecord.ROW_KEY_PARAM);
      int nRow;

      if (sRowKey != null)
      {
         row = ds.getRowFromKey(sRowKey);
         rs.setCurrentRow(row);
      }

      if (sNavigation == null || sNavigation == "")
      {
         return;
      }

      row = rs.getCurrentRow();

      //make sure there is an active context, bug#1550180
      if(row == null && bAutoexecute)
         row = rs.first();

      if (row != null && sNavigation.equalsIgnoreCase("DELETE"))
      {
         // save the next row
         Row rowNext = null;
         Row focusRow = row;
         Key currKey = row.getKey();

         if (rs.hasNext())
         {
            rowNext = rs.next();
            rs.previous();
         }
         else
         {
            rowNext = rs.previous();
            rs.next();
         }

         row.remove();

         if (rowNext != null)
         {
            row = rowNext;
         }
         else
         {
            row = rs.first();
         }

         try
         {
            handleCommit();
         }
         catch (DMLException ex)
         {
            JboException toThrow = ex;
            
            try
            {
               ((TransPostControl) rs.getApplicationModule()).transPostRevert(ex.getEntityRowHandle());
            }
            catch (RowNotFoundException rnfe)
            {
               rnfe.addToDetails(ex);
               toThrow = rnfe;
            }

            // bring back any deleted rows
            rs.executeQuery();

            Row [] rows = rs.findByKey(currKey, 1);
            if (rows.length > 0)
               rs.setCurrentRow(rows[0]);

            throw toThrow;
         }

      }
      else if (sNavigation.equalsIgnoreCase("COMMIT"))
      {
         rs.getApplicationModule().getTransaction().commit();

         //Charles 5/2/01 no need for 2 executeQuery
         //rs.getViewObject().executeQuery();

         rs.executeQuery();

         row = rs.first();
      }
      else if (sNavigation.equalsIgnoreCase("ROLLBACK"))
      {
         ApplicationModule am = rs.getApplicationModule();

         am.getTransaction().rollback();

         rs.getViewObject().executeQuery();

         row = rs.first();
      }
      else if (sNavigation.equalsIgnoreCase("NEXT"))
      {
         if (!rs.hasNext())
         {
            throw new RuntimeException("Can't navigate past last record");
         }

         row = rs.next();
      }
      else if (sNavigation.equalsIgnoreCase("PREV"))
      {
         if (!rs.hasPrevious())
         {
            throw new RuntimeException("Can't navigate before first record");
         }

         row = rs.previous();
      }
      else if (sNavigation.equalsIgnoreCase("FIRST"))
      {
         row = rs.first();
      }
      else if (sNavigation.equalsIgnoreCase("LAST"))
      {
         row = rs.last();
      }
      else if (sNavigation.equalsIgnoreCase("NEXTSET"))
      {
         int nRet = rs.scrollRange(rs.getRangeSize());

         if (nRet == 0)
         {
            rs.setCurrentRowAtRangeIndex(0);
            throw new RuntimeException("Can't scroll forwards");
         }

         rs.setCurrentRowAtRangeIndex(0);

         row = rs.getCurrentRow();
      }
      else if (sNavigation.equalsIgnoreCase("PREVSET"))
      {
         int nRet = rs.scrollRange(-rs.getRangeSize());

         if (nRet == 0)
         {
            throw new RuntimeException("Could not scroll backwards");
         }

         rs.setCurrentRowAtRangeIndex(0);

         row = rs.getCurrentRow();
      }

      if (row != null)
         rs.setCurrentRow(row);

   }


   /**
    * Renders the Web Bean's contents to the output stream.
    *
    **/

   public void render() throws Exception
   {
      execute();
      releaseApplicationResources();
   }

    /**
   *
   *  set the AutoExecute option to true when you want the
   *  navigation bar to automatically call first() when there isn't
   *  a current row.
   **/
   public void setAutoExecute(boolean bAutoexecute)
   {
      bAutoexecute = bAutoexecute;
   }

   public boolean getAutoExecute()
   {
      return bAutoexecute;
   }

}
