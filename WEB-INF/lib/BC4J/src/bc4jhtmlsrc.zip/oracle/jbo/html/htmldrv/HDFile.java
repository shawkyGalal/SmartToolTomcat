/*
 * @(#)HDFile.java
 *
 * Copyright 1998-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.html.htmldrv;

import java.io.*;
import oracle.jbo.expr.JIException;
import oracle.jdeveloper.html.parser.*;

// import oracle.jbo.test.interp.*;
public class HDFile
{
   public static final String DRV_OUTPUT_FILE = "_out";
   
   private String varName = null;
   private String fileName = null;
   private boolean tempFile = true;
   private HTMLParser parseTree = null;
   private IHTMLParserNode rootNode = null;

   public HDFile()
   {
   }
   
   protected void init()
   {
      if (fileName == null)
      {
         fileName = getTempFileName();
      }
   }
   
   public IHTMLParserNode getRootNode()
   {
      return rootNode;
   }
   
   public boolean isFileTemporary()
   {
      return tempFile;
   }
   
   public String getFileName()
   {
      init();
      
      return fileName;
   }
   
   public String setFileName(String fName)
   {
      fileName = fName;
      
      tempFile = (fileName == null);
      
      init();
      
      return fileName;
   }
   
   public String getVarName()
   {
      return varName;
   }
   
   public void setVarName(String nam)
   {
      varName = nam;
   }
   
   public InputStream getInputStream() throws IOException
   {
      init();

      FileInputStream fInstrm = new FileInputStream(fileName);
      
      return fInstrm;
   }
   
   public void parse() throws IOException
   {
      init();

      InputStream instrm = getInputStream();

      try
      {
         parseTree = new HTMLParser();
         rootNode = parseTree.parse(fileName, instrm);
      }
      catch(Exception ex)
      {
         ex.printStackTrace();
         throw new JIException("HTML parsing error");
      }
      
      instrm.close();
   }

   public void type() throws IOException
   {
      init();

      InputStream instrm = getInputStream();
      InputStreamReader inReader = new InputStreamReader(instrm);
      BufferedReader buff = new BufferedReader(inReader);
      String line = buff.readLine();

      while (line != null)
      {
         System.out.println(line);

         line = buff.readLine();
      }

      instrm.close();
   }

   public void writeFile(InputStream strm, boolean appendFlag, boolean typeFlag)
                  throws IOException
   {
      init();

      FileWriter fw = new FileWriter(fileName, appendFlag);
      InputStreamReader inReader = new InputStreamReader(strm);
      BufferedReader buff = new BufferedReader(inReader);
      String line = buff.readLine();

      while (line != null)
      {
         fw.write(line);
         fw.write("\r\n");
         
         if (typeFlag)
         {
            System.out.println(line);
         }

         line = buff.readLine();
      }

      fw.close();

      buff.close();
      inReader.close();
      strm.close();
   }
   
   public boolean delete()
      throws IOException
   {
      return (new File(fileName)).delete();
   }

   public static String getTempFileName()
   {
      return DRV_OUTPUT_FILE + System.currentTimeMillis() % 10000;
   }

   public String toString()
   {
      return "fn=" + fileName + ", vn=" + varName + ", temp=" + tempFile;
   }
}
