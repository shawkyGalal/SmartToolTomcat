/*
 * @(#)SetHtmlAttributeTag.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.html.jsp.datatags;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.tagext.Tag;
import javax.servlet.jsp.tagext.TagSupport;
import oracle.jbo.JboException;

public class SetHtmlAttributeTag extends TagSupport
{
   protected String sName;
   protected String sValue;

   public SetHtmlAttributeTag()
   {
      super();
      reset();
   }

   public void setName(String sValue)
   {
      this.sName = sValue;
   }

   public void setValue(String sValue)
   {
      this.sValue = sValue;
   }

   public int doStartTag() throws JspException
   {
      final InputTagBase tag = (InputTagBase) findAncestorWithClass(this, InputTagBase.class);
      if (tag == null)
      {
         throw new JboException(Res.getString(Res.SETHTMLATTRIBUTE_ONLY_IN_INPUTTAGBASE));
      }

      tag.addHtmlAttribute(sName, sValue);
      
      return Tag.SKIP_BODY;
   }

   public int doEndTag() throws JspException
   {
      reset();
      return Tag.EVAL_PAGE;
   }
   
   // Use by the constructor and the release method to reset the member variable values
   private void reset()
   {
      sName = null;
      sValue = null;
   }
  
}
