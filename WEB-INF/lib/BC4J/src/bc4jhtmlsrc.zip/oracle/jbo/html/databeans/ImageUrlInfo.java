/*
 * @(#)ImageUrlInfo.java
 *
 * Copyright 2000-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.html.databeans;

import oracle.jdeveloper.html.HTMLElement;
import oracle.jdeveloper.html.HTMLImageURL;

public class ImageUrlInfo extends TextColumnUrlInfo
{
    public ImageUrlInfo(String sTitle, String sImageUrl, String sUrl, String sTarget)
    {
        super(sTitle, sImageUrl , sUrl, sTarget);
    }

    public HTMLElement getColumnElement(String sUrl)
    {
        HTMLImageURL imgUrl = new HTMLImageURL(sText, sUrl);

        if(sTarget != null)
        {
            imgUrl.setTarget(sTarget);
        }

        return imgUrl;
    }
}


