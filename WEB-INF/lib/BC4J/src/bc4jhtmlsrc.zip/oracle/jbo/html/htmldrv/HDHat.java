/*
 * @(#)HDHat.java
 *
 * Copyright 1999-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.html.htmldrv;

import java.io.*;
import java.net.*;
import java.util.*;
import oracle.jbo.common.JboNameUtil;
import oracle.jbo.html.*;
import oracle.jdeveloper.html.parser.*;

public class HDHat extends HDCmdBlock
{
   private Vector packList = new Vector();
   private Vector packClsList = new Vector();

   private String httpBase = "http://sim-pc2:7000/";

   private String limitPackageName = null;
   private boolean dispSpaceFirst = false;
   private boolean dispNumInstsFirst = false;
   private boolean dispSpacePerInstFirst = false;


   public static void main(String argv[])
   {
      try
      {
         HDHat hdHat = new HDHat();

         hdHat.procArgs(argv);
         hdHat.run();
      }
      catch(Exception ex)
      {
         ex.printStackTrace();
         System.exit(1);
      }
   }
   
   
   public void procArgs(String argv[])
      throws Exception
   {
      for (int j = 0; j < argv.length; j++)
      {
         if (argv[j].equals("-package"))
         {
            limitPackageName = argv[++j];
         }
         else  if (argv[j].equals("-http"))
         {
            httpBase = argv[++j];
         }
         else  if (argv[j].equals("-ds"))
         {
            dispSpaceFirst = true;
         }
         else  if (argv[j].equals("-dn"))
         {
            dispNumInstsFirst = true;
         }
         else  if (argv[j].equals("-di"))
         {
            dispSpacePerInstFirst = true;
         }
         else
         {
            throw new Exception("Unkonwn switch: " + argv[j]);
         }
      }
   }
   
   
   public void run() throws IOException
   {
      setLine("quiet");
      parseCommand();

      getPacksAndClasses();
      getClassInfo();
   }
   
   
   public void getPacksAndClasses() throws IOException
   {
      setLine("get \"" + httpBase + "\"");
      parseCommand();
      
      setLine("parse");
      parseCommand();

      setLine("iterate iterPack");
      parseCommand();
      
      HDIterator iterPack = (HDIterator) getVariableVal("iterPack");
      IHTMLParserNode node;
      
      while ((node = iterPack.next()) != null)
      {
         if (node.getNodeTag() != null && node.getNodeTag().equals("a"))
         {
            if (node.getAttributes() != null)
            {
               String str = (String) node.getAttributes().get("href");
               String linkStr = str.substring(1, str.length() - 1);

               // System.out.println("Found: " + linkStr);
               
               if (linkStr.startsWith("class/"))
               {
                  String fullClassName = linkStr.substring("class/".length());
                  String packName = JboNameUtil.getContainerPartOfName(fullClassName);
                  String className = JboNameUtil.getLastPartOfName(fullClassName);
                  
                  // System.out.println("Found: package (" + packName + ") class (" + className + ")");
                  
                  if (className.startsWith("["))
                  {
                     packName = "<Arrays>";
                  }
                  else  if (packName == null)
                  {
                     packName = "<Default Package>";
                  }
                  else  if (packName.startsWith("["))
                  {
                     packName = "<Arrays>";
                  }
                  
                  if (limitPackageName != null &&
                      (!limitPackageName.equals(packName)))
                  {
                     continue;
                  }
                  
                  if (packList.indexOf(packName) < 0)
                  {
                     packList.addElement(packName);
                     packClsList.addElement(null);
                  }
                  
                  int packIndx = packList.indexOf(packName);
                  
                  if (packIndx >= 0)
                  {
                     Vector lst = (Vector) packClsList.elementAt(packIndx);
                     
                     if (lst == null)
                     {
                        lst = new Vector();
                        packClsList.setElementAt(lst, packIndx);
                     }
                     
                     if (lst.indexOf(className) < 0)
                     {
                        lst.addElement(className);
                     }
                  }
               }
            }
         }
      }

      removeVariable("iterPack");

      setLine("delete");
      parseCommand();
   }
   
   
   public String buildDispString(String s, int dispLen, boolean leftJust)
   {
      if (s.length() >= dispLen)
      {
         return s;
      }
      else
      {
         for (int j = s.length(); j < dispLen; j++)
         {
            if (leftJust)
            {
               s = s + " ";
            }
            else
            {
               s = " " + s;
            }
         }
         
         return s;
      }
   }
   
   
   public void printReportLine(String dispClsName, String dispNumInsts,
                               String dispSpace, String dispSpacePerInst,
                               boolean header)
   {
      String indent = (header) ? "$  " : "   ";
      
      dispClsName = buildDispString(dispClsName, 32, true);
      dispNumInsts = buildDispString(dispNumInsts, 8, false);
      dispSpace = buildDispString(dispSpace, 8, false);
      dispSpacePerInst = buildDispString(dispSpacePerInst, 8, false);

      if (dispSpaceFirst)
      {
         System.out.print(indent);
         System.out.print(dispSpace + " ");
         System.out.print(dispNumInsts + " ");
         System.out.print(dispSpacePerInst + " ");
         System.out.println(dispClsName);
      }
      else  if (dispNumInstsFirst)
      {
         System.out.print(indent);
         System.out.print(dispNumInsts + " ");
         System.out.print(dispSpacePerInst + " ");
         System.out.print(dispSpace + " ");
         System.out.println(dispClsName);
      }
      else  if (dispSpacePerInstFirst)
      {
         System.out.print(indent);
         System.out.print(dispSpacePerInst + " ");
         System.out.print(dispNumInsts + " ");
         System.out.print(dispSpace + " ");
         System.out.println(dispClsName);
      }
      else
      {
         System.out.print(indent);
         System.out.print(dispClsName + " ");
         System.out.print(dispSpacePerInst + " ");
         System.out.print(dispNumInsts + " ");
         System.out.println(dispSpace);
      }
   }
   

   public void printNumInstsForClass(String clsName, int numInsts, int space)
      throws IOException
   {
      int spacePerInst = space / numInsts;
      String dispClsName = buildDispString(clsName, 32, true);
      String dispNumInsts = buildDispString("" + numInsts, 8, false);
      String dispSpace = buildDispString("" + space, 8, false);
      String dispSpacePerInst = buildDispString("" + spacePerInst, 8, false);
      
      printReportLine(clsName, "" + numInsts, "" + space, "" + spacePerInst, false);
   }
   
   
   public void getClassInfo() throws IOException
   {
      printReportLine("Class", "# Insts", "Tot Sp", "Sp/Inst", true);
      printReportLine("---------------------", "--------", "--------", "--------", true);

      for (int j = 0; j < packList.size(); j++)
      {
         String packName = (String) packList.elementAt(j);
         
         System.out.println(packName);
         
         if (packName.equals("<Default Package>") ||
             packName.equals("<Arrays>"))
         {
            packName = "";
         }
         else
         {
            packName += ".";
         }
         
         Vector clsList = (Vector) packClsList.elementAt(j);

         for (int k = 0; k < clsList.size(); k++)
         {
            String clsName = (String) clsList.elementAt(k);

            // System.out.println("   get \"" + httpBase + "class/" + packName + clsName + "\"");

            setLine("get \"" + httpBase + "instances/" + packName + clsName + "\"");
            parseCommand();

            setLine("parse");
            parseCommand();

            setLine("iterate iterPack");
            parseCommand();
      
            HDIterator iterPack = (HDIterator) getVariableVal("iterPack");
            IHTMLParserNode node;
      
            while ((node = iterPack.next()) != null)
            {
               // System.out.println(" nodeTag " + node.getNodeTag());
               if (node.getNodeTag() != null && node.getNodeTag().equals("h2"))
               {
                  Vector children = node.getChildNodes();

                  if (children.size() > 0)
                  {
                     IHTMLParserNode chset = (IHTMLParserNode) children.elementAt(0);
                     Vector strToks = chset.getTokens();
                     
                     // for (int jj=0; jj < strToks.size(); jj++)
                     // {
                     //    System.out.print("$"+jj+":" + strToks.elementAt(jj));
                     // }
                     // System.out.println("");

                     if (strToks.size() >= 13)
                     {
                        if (strToks.elementAt(0).equals("Total") &&
                            strToks.elementAt(2).equals("of") &&
                            strToks.elementAt(6).equals("instances") &&
                            strToks.elementAt(8).equals("occupying") &&
                            strToks.elementAt(12).equals("bytes"))
                        {
                           int numInsts = (new Integer((String) strToks.elementAt(4))).intValue();
                           int space = (new Integer((String) strToks.elementAt(10))).intValue();

                           if (numInsts > 0 && space > 0)
                           {
                              printNumInstsForClass(packName + clsName, numInsts, space);
                           }
                        }
                     }
                  }
               }
            }

            removeVariable("iterPack");

            setLine("delete");
            parseCommand();
         }
      }
   }
   
   
   public boolean readLine() throws IOException
   {
      return getLine() != null;
   }
}
