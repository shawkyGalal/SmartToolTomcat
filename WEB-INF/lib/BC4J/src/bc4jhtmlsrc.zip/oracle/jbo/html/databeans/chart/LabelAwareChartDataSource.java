/*
 * @(#)LabelAwareChartDataSource.java
 *
 * Copyright 2000-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.html.databeans.chart;

import oracle.jbo.RowSet;
import tdg.Perspective;

/**
 *  Data source for the chart control which implements
 *  method to return labels.
 *
 *  By default column 0 is used as labels for the row
 *
 *  @see ChartLabelDataSource
 *  @version Internal
 */
public class LabelAwareChartDataSource
      extends MappedChartDataSource
{
    protected boolean _useFirstColumnAsRowLabel = true;
    private ChartLabelDataSource      _rowLabelDataSource =
                                              new ChartLabelTableColumnValues(this);
    private ChartLabelDataSource      _colLabelDataSource =
                                              new ChartLabelTableColumnNames(this);
    /**
    *  Constructor
    */
    public LabelAwareChartDataSource(Perspective parent)
    {
        super(parent);
        setUseFirstColumnAsRowLabel(true);
    }

    public void setUseFirstColumnAsRowLabel(boolean flag)
    {
        _useFirstColumnAsRowLabel = flag;
    }

    public boolean getUseFirstColumnAsRowLabel()
    {
        return _useFirstColumnAsRowLabel;
    }

    public void setRowSet(RowSet qView)
    {
        super.setRowSet(qView);
        ((ChartLabelDataSourceImpl)_colLabelDataSource).setRowSet(qView);
        ((ChartLabelDataSourceImpl)_rowLabelDataSource).setRowSet(qView);
    }

    /**
    * This method should be invoked after the View object
    *  has been set.
    */
    public void initialize()
    {
        super.initialize();
        //_rowLabelDataSource.refreshLabels();
        //_colLabelDataSource.refreshLabels();
    }

    public String columnLabel(int i)
    {
        int index = ((_useFirstColumnAsRowLabel) ? (i+1) : i);
        String columnLabel = _colLabelDataSource.getLabel(_mapColumnIndex(index));
        return ((columnLabel !=null) ? columnLabel : "");

    }

    public int getColumns()
    {
        int count = super.getColumns();
        if ( _useFirstColumnAsRowLabel)
            return (count - 1);
        return count;

    }


    public String rowLabel(int i)
    {
        Object o = null;
        if ( _useFirstColumnAsRowLabel )
            o = super.getValue(i,0);
        else
            o = _rowLabelDataSource.getLabel(i);
        return ((o == null ) ? "" : o.toString());

    }

    public int getRows()
    {
        return super.getRows();
    }

    public Object getValue(int row, int col)
    {
        try
		{
			Object val = null;
			if ( _useFirstColumnAsRowLabel )
				val = super.getValue(row, col+1);
			else
				val = super.getValue(row,col);
			return val;
		}
		catch(Exception exc)
		{
			System.out.println("Chart data source : exc : " + row + " " + col);
		}

		return null;
    }

    /**
    * Specify data source for row labels. The labels could be
    * <UL>
    * <LI> column values of a table
    * <LI> column names (display names) of a table
    * </UL>
    * <P>
    * The dataitem name of the column should be specified to indicate
    * the column values of a table
    *<P> The dataitem name of the rowset should be specified to indicate
    * the column display name of some table
    *
    * @see setRowLabelDataSource(Object)
    * @param dataitemName of the column values or the rowset
    */

    public void setRowLabelDataSource(ChartLabelDataSource labelSource )
    {
        setUseFirstColumnAsRowLabel(false);
        _rowLabelDataSource = labelSource;
        _updateChart();
    }

    public ChartLabelDataSource getRowLabelDataSource()
    {
        return _rowLabelDataSource;
    }

    public void setRowLabelColumnName(String columnName)
    {
        setRowLabelColumnIndex(_getColumnIndex(getRowSet(), columnName));
    }

    public String getRowLabelColumnName()
    {
        return _getColumnName(getRowSet(), getRowLabelColumnIndex());
    }

    /**
    * Specify the column index, whose column values should be used for
    * the row label.
    *
    * Specifying columnIndex 0, means that the
    */
    public void setRowLabelColumnIndex(int columnIndex)
    {
        setUseFirstColumnAsRowLabel(false);
        ((ChartLabelTableColumnValues)
                            _rowLabelDataSource).setLabelIndex(columnIndex);
        _updateChart();
    }

    public int getRowLabelColumnIndex()
    {
        return (((ChartLabelTableColumnValues)_rowLabelDataSource).getLabelIndex());

    }


    /**
    * Specify an arbitary list of labels to be used as row labels
    */
    public void setRowLabel(Object[] labels)
    {
       setUseFirstColumnAsRowLabel(false);
       ((ChartLabelDataSourceImpl)
                             _rowLabelDataSource).setLabels(labels);
       _updateChart();
    }

    /**
    * get row label list
    */
    public Object[] getRowLabel()
    {
       return ((ChartLabelDataSourceImpl)
                                    _rowLabelDataSource).getLabels();
    }

    /**
    * Specify data source for row labels. The labels could be
    * <UL>
    * <LI> column values of a table
    * <LI> column names (display names) of a table
    * </UL>
    * <P>
    * The dataitem name of the column should be specified to indicate
    * the column values of a table
    *<P> The dataitem name of the rowset should be specified to indicate
    * the column display name of some table
    *
    * @see setRowLabelDataSource(Object)
    * @param dataitemName of the column values or the rowset
    */
    public void setColumnLabelDataSource(ChartLabelDataSource labelSource )
    {
        _colLabelDataSource = labelSource;
        _updateChart();
    }

    public ChartLabelDataSource getColumnLabelDataSource()
    {
        return _colLabelDataSource;
    }

    public void setColumnLabel(Object[] labels)
    {
       ((ChartLabelDataSourceImpl)
                             _colLabelDataSource).setLabels(labels);
       _updateChart();
    }

    public Object[] getColumnLabel()
    {
       return ((ChartLabelDataSourceImpl)
                                    _colLabelDataSource).getLabels();
    }

}

