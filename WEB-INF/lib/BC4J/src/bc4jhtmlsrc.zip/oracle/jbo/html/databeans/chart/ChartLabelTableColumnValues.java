/*
 * @(#)ChartLabelTableColumnValues.java
 *
 * Copyright 2000-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.html.databeans.chart;

import oracle.jbo.Row;
import oracle.jbo.RowSet;

/**
 *  chart labels derived from column values of the table
 *
 *  @version Internal
 */
class ChartLabelTableColumnValues extends ChartLabelDataSourceImpl
{
    private int     _colIndex = 0;
    private Row     _rows[];

    ChartLabelTableColumnValues(ChartDataSource parent)
    {
       super(parent);
    }

    public void setRowSet(RowSet qView)
    {
        super.setRowSet(qView);
        _qView.setRangeSize(-1);
        _updateLables();
    }

    public void setLabelIndex(int i)
    {
        _colIndex = i;
        _updateLables();
    }

    public int getLabelIndex()
    {
        return _colIndex;
    }

    /*
    public void refreshLabels()
    {
        _updateLables();
    }
    */


   private void _updateLables()
   {
        setLabels(_getColumnValues(_qView, _colIndex));
        updateChart();
   }

   private Object[] _getColumnValues(RowSet view,  int colIndex)
   {
       if ( view != null )
       {
           Row[] rows = view.getAllRowsInRange();

		   Object[] labels = new Object[rows.length];

		   for (int i=0; i < labels.length; i++)
		   {
			   Object s = rows[i].getAttribute(colIndex);

			   labels[i] = ( (s == null ) ? "" : s.toString());
		   }

		   return labels;

       }
       return null;
   }

   static int count=0;
 }
