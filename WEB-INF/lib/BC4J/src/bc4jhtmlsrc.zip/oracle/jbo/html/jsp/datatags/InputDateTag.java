/*
 * @(#)InputDateTag.java
 *
 * Copyright 2000-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.html.jsp.datatags;

import javax.servlet.jsp.JspException;

import oracle.jbo.JboException;
import oracle.jbo.html.HtmlServices;
import oracle.jdeveloper.html.DateField;
import oracle.jdeveloper.html.HTMLFieldRenderer;

public class InputDateTag extends InputTagBase
{
   protected String sformname;

   public void setFormname(String sValue)
   {
      sformname = sValue;
   }

   public HTMLFieldRenderer getFieldRenderer()
   {
      final HTMLFieldRenderer rField = new DateField();

      initializeFieldRenderer(rField);

      if (sformname == null)
      {
         if (HtmlServices.isStrutsContext(pageContext))
         {
            sformname = getStrutsFormName();
         }
         else
         {
            throw new JboException(Res.getString(Res.INPUTDATE_NO_FORMNAME));
         }
      }

      return rField;
   }

   public int doEndTag() throws JspException
   {
      sformname = null;

      return super.doEndTag();
   }

   public void internalInitialize()
   {
      super.internalInitialize();
      rndObj.setFormName(sformname);
   }
}


