/*
 * @(#)ScrollBarTag.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.html.jsp.datatags;

import javax.servlet.http.HttpServletRequest;
import oracle.jbo.html.BC4JContext;

/**
 */
public class ScrollBarTag extends DataComponentTag
{
   public static final String defaultUrl = "DataScrollerComponent.jsp";
   public static final String paramNames[] = new String[]{ "targetURL"};
   protected String  sTargetUrl;

   public ScrollBarTag()
   {
      super();
   }

   protected void reset()
   {
      super.reset();
      sRelativeUrlPath = defaultUrl;
      sTargetUrl = null;
   }

   public void setTargetURL(String sValue)
   {
      this.sTargetUrl = sValue;
   }

   public String getUrl()
   {
      String url = super.getUrl();
      
      // If the target url is not specify, get default page
      if (sTargetUrl == null)
      {
         final HttpServletRequest request = (HttpServletRequest) pageContext.getRequest();
         
         BC4JContext bc4jContext = BC4JContext.getContext(request);
         // If we are using Struts, the default page is '/navigate.do'
         if (bc4jContext != null)
         {
            sTargetUrl = "/navigate.do";
         }
         else
         {
            // use self.
            sTargetUrl = request.getRequestURI();
         }
      }

      DataScroller scroller = (DataScroller) pageContext.getSession().getAttribute(DataScroller.ATTR_NAME);
      if (scroller == null)
      {
         scroller =  new DataScroller();
         pageContext.getSession().setAttribute(DataScroller.ATTR_NAME, scroller);
      }
       
      scroller.initialize(pageContext, sDatasource);
      
      return buildUrl(url, paramNames, new String[]{ sTargetUrl });
   }
}
