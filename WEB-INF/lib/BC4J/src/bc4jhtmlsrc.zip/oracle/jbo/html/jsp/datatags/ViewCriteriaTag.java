/*
 * @(#)ViewCriteriaTag.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.html.jsp.datatags;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.tagext.TagSupport;
import oracle.jbo.ViewObject;
import oracle.jbo.ViewCriteria;
import oracle.jbo.html.DataSource;

public class ViewCriteriaTag extends TagSupport
{
   public static final String ACTION_CRIT_NEW = "new";
   public static final String ACTION_CRIT_APPEND = "append";
   
   protected String sDataSource;
   protected String sAction;
   protected ViewCriteria vc;
   private ViewObject vo;

   public ViewCriteriaTag()
   {
      reset();
   }

   public void setDatasource(String sValue)
   {
      this.sDataSource = sValue;
   }

   public void setAction(String sValue)
   {
      this.sAction = sValue;
   }

   public ViewCriteria getViewCriteria()
   {
      return vc;
   }
   
   /**
      * Process the start tag for this instance.
      *
      * The doStartTag() method assumes that all setter methods have been
      * invoked before.
      *
      * When this method is invoked, the body has not yet been invoked.
      *
      * @returns EVAL_BODY_INCLUDE if the tag wants to process body, SKIP_BODY if it
      * does ont want to process it.
      */
   public int doStartTag() throws JspException
   {
      DataSource ds = Utils.getDataSourceFromContext(pageContext, sDataSource);
      
      vo = ds.getRowSet().getViewObject();
      vc = vo.getViewCriteria();

      if (sAction.equalsIgnoreCase(ACTION_CRIT_NEW))
      {
         vc = vo.createViewCriteria();
      }
      else if (sAction.equalsIgnoreCase(ACTION_CRIT_APPEND))
      {
         if (vc == null)
         {
            vc = vo.createViewCriteria();
         }
      }

      // Save the vc for the scriptable variable
      pageContext.setAttribute(id, vc);
   
      return EVAL_BODY_INCLUDE;
   }

   public int doEndTag() throws JspException
   {
      vo.applyViewCriteria(vc);
      vo.executeQuery();
   
      return super.doEndTag();
   }

   // Use by the constructor and the release method to reset the member variable values
   private void reset()
   {
      vc = null;
      vo = null;
      sDataSource = null;
      sAction = ACTION_CRIT_APPEND; 
   }
   
   /**
     * release() called after doEndTag() to reset state
     */
   public void release()
   {
      reset();
      super.release();

      pageContext.removeAttribute(id);
   }

}
