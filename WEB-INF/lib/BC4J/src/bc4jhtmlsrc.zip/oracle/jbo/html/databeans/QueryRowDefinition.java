/*
 * @(#)QueryRowDefinition.java
 *
 * Copyright 1999-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.html.databeans;


/**
 * <B>Internal</B>: <EM>Applications should not use this
 * class.</EM>
 *
 **/
public class QueryRowDefinition
{
   public boolean negated = false;		
   public String operator = "AND";
   public String colName;
   public String colPrompt;
   public String condition;
   public String value;
}
