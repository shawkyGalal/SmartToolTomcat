/*
 * @(#)OrdWidthBoundValue.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.html.jsp.blaf;

import javax.servlet.jsp.PageContext;
import oracle.cabo.ui.RenderingContext;
import oracle.cabo.ui.data.DataObject;
import oracle.cabo.ui.data.BoundValue;
import oracle.jbo.Row;
import oracle.ord.common.PropertyConstants;
import oracle.ord.im.OrdImageDomain;
import oracle.ord.im.OrdVideoDomain;

public class OrdWidthBoundValue implements BoundValue
{
  private String m_attrName;
  private String m_dsName;  //DataSource name
  private PageContext m_pageContext;

  public OrdWidthBoundValue(String attrName, 
                            String dsName,
                            PageContext pageContext
                            )
  {
    this.m_attrName = attrName;
    this.m_dsName = dsName;
    this.m_pageContext = pageContext;
  }
  
  public Object getValue(RenderingContext context)
  {
    DataObject source = 
      (DataObject) m_pageContext.getAttribute(m_dsName + "uix");
    Row row = (Row)source.selectValue(context, 
                                      PropertyConstants.ORD_UIX_JSP_SELECT_ROW);
    Object domain = row.getAttribute(m_attrName);

    int width = 0;
    try
    {
      if(domain instanceof OrdImageDomain)
      {
        width = ((OrdImageDomain)domain).getWidth();
      }else if(domain instanceof OrdVideoDomain)
      {
        width = ((OrdVideoDomain)domain).getWidth();
      }
    }catch(Exception e) 
    {
      width = 0;
    }

    if(width <= 0)
    {
      return null;
    }else
    {
      return new Integer(width);
    }
  }
}
