/*
 * @(#)ArrayAttributesHandler.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.html;

import oracle.jbo.AttributeDef;
import oracle.jbo.LocaleContext;
import oracle.jbo.Row;
import oracle.jbo.domain.TypeFactory;

final class ArrayAttributesHandler
{
   ArrayAttributesHandler()
   {
   }

   public void setAttributeFromRequestParameters(Row row, AttributeDef attrDef, RequestParameters params, LocaleContext locale)
      throws java.lang.IllegalAccessException, java.lang.InstantiationException
   {
      String baseName = attrDef.getName();
      
      oracle.jbo.domain.Array array = (oracle.jbo.domain.Array) row.getAttribute(baseName);
      boolean isNew = false;
      boolean isNull = true;
      
      Object[] objArray = null;
      
      if (array != null)
      {
          objArray = array.getArray();
      }
      else
      {
          objArray = new Object[0];
          isNew = true;
      }
      
      
      Object[] newObjArray;

      int size = objArray.length;
      if(size > 0)
      {
        newObjArray = new Object[size];
        System.arraycopy(objArray, 0, newObjArray, 0, size);
        objArray = newObjArray;

        for (int i = 0; i < size; i++)
        {
         isNew = internalSetArrayAttribute(HtmlServices.getArrayAttributeName(attrDef, i), objArray, i, params);
         
         if (isNull)
         {
            isNull = (objArray[i] == null);
         }
        }
      }

      // Handle an extra new element here
      String sName = HtmlServices.getArrayAttributeName(attrDef, size);
      String sNewValue = params.getParameter(sName);

      if (sNewValue != null)
      {
         sNewValue.trim();
   
         // empty out value if the string 'null' is used
         if (!HtmlServices.NULLSTRING.equalsIgnoreCase(sNewValue) && sNewValue.length() > 0)
         {
            newObjArray = new Object[size + 1];
            System.arraycopy(objArray, 0, newObjArray, 0, size);

            newObjArray[size] = TypeFactory.getInstance(attrDef.getElemType(), sNewValue);
            objArray = newObjArray;
            
            isNew = true;
            isNull = false;
         }
      }

      if (isNew)
      {
         if (!isNull)
         {
            array = new oracle.jbo.domain.Array(objArray);
            row.setAttribute(attrDef.getIndex(), array);
         }
      }
      else
      {
         if (isNull)
         {
            row.setAttribute(attrDef.getIndex(), null);
         }
      }
   }

   static private boolean internalSetArrayAttribute(String sName, Object[] objArray, int index, RequestParameters params)
   {
      boolean isNew = false;
      String sNewValue = params.getParameter(sName);

      if (sNewValue == null)
      {
         return false;
      }

      sNewValue.trim();

      // empty out value if the string 'null' is used
      if (HtmlServices.NULLSTRING.equalsIgnoreCase(sNewValue))
      {
         sNewValue = "";
      }

      // compare only with generated value to minimize overwrites of
      // attributes that didn't change.
      Object OldValue = params.getParameter(HtmlServices.getHiddenAttributeName(sName));
      if (OldValue == null)
      {
         OldValue = objArray[index];
      }

      if (OldValue != null)
      {
         if (!sNewValue.equals(OldValue.toString()))
         {
            if (sNewValue.length() > 0)
            {
               objArray[index] = sNewValue;
               isNew = true;
            }
            else
            {
               objArray[index] = null;
               isNew = true;
            }
         }
      }
      else
      {
         if (sNewValue.length() > 0)
         {
            objArray[index] = sNewValue;
            isNew = true;
         }
      }

      return isNew;
   }
   
}
   
