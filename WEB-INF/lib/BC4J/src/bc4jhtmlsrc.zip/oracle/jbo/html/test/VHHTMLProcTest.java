/*
 * @(#)VHHTMLProcTest.java
 *
 * Copyright 1999-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.html.test;

import java.io.*;
import java.util.*;
import oracle.jbo.html.*;

public class VHHTMLProcTest
{
   public static String htmlFileName;
   public static String valFileName;
   public static FileInputStream htmlFile;
   public static FileInputStream valFile;
   
   public static void main(String[] args)
   {
      if (args.length < 2)
      {
         System.err.println("Usage: java VHHTMLProcTest <html-file> <value-file>");
         return;
      }
      
      htmlFileName = args[0];
      valFileName = args[1];
      
      try
      {
         htmlFile = new FileInputStream(htmlFileName);
      }
      catch (IOException e)
      {
         System.err.println("HTML input file " + htmlFileName + " could not be opened");
         e.printStackTrace();
         
         return;
      }

      try
      {
         valFile = new FileInputStream(valFileName);
      }
      catch (IOException e)
      {
         System.err.println("Value file " + valFileName + " could not be opened");
         e.printStackTrace();
         
         return;
      }
      
      try
      {
         Hashtable valTab = VHHTMLProcessor.processValueFile(valFile);

         VHHTMLProcessor.processHTML(htmlFile, valTab, System.out);
      }
      catch (IOException e)
      {
         e.printStackTrace();
      }
      catch (VHInvalidValFileException e)
      {
         e.printStackTrace();
      }
      catch (Exception e)
      {
         e.printStackTrace();
      }
   }
}
