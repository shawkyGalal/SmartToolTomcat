/*
 * @(#)CriteriaRowTag.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.html.jsp.datatags;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.tagext.Tag;
import javax.servlet.jsp.tagext.TagSupport;
import oracle.jbo.JboException;
import oracle.jbo.ViewCriteria;
import oracle.jbo.ViewCriteriaRow;

public class CriteriaRowTag extends TagSupport
{
   protected boolean bClearAll;
   protected int index;     
   protected boolean bUpperColumns;
   protected ViewCriteriaRow vr;
   private ViewCriteria vc;

   public CriteriaRowTag()
   {
      reset();
   }

   public void setClearall(String sValue)
   {
      this.bClearAll = Utils.isTrue(sValue);
   }
   
   public void setIndex(String sValue)
      throws java.lang.NumberFormatException
   {
      index = Integer.parseInt(sValue);
   }

   public void setUppercolumns(String sValue)
   {
      bUpperColumns = Utils.isTrue(sValue);
   }
   
   public ViewCriteriaRow getViewCriteriaRow()
   {
      return vr;
   }
   
   /**
      * Process the start tag for this instance.
      *
      * The doStartTag() method assumes that all setter methods have been
      * invoked before.
      *
      * When this method is invoked, the body has not yet been invoked.
      *
      * @returns EVAL_BODY_INCLUDE if the tag wants to process body, SKIP_BODY if it
      * does ont want to process it.
      */
   public int doStartTag() throws JspException
   {
      final ViewCriteriaTag critTag = (ViewCriteriaTag) TagSupport.findAncestorWithClass(this, ViewCriteriaTag.class);

      if (critTag == null)
      {
         throw new JboException(Res.getString(Res.CRITERIAROW_ONLY_IN_VIEWCRITERIA));
      }

      vc = critTag.getViewCriteria();
      if (vc != null)
      {
         if (index < 0)
         {
            index = vc.size(); // Append the row when no index specified
         }

         if (index == vc.size())
         {
            vr = vc.createViewCriteriaRow();
            vc.addElement(vr);
         }
         else if (index < vc.size())
         {
            vr = (ViewCriteriaRow) vc.elementAt(index);
         }
         else
         {
            throw new JboException(Res.format(Res.CRITERIAROW_INVALID_INDEX, Integer.toString(index)));
         }

         // Pass the upper columns flag to the ViewCriteriaRow
         vr.setUpperColumns(bUpperColumns);

         // Save the vr for the scriptable variable
         pageContext.setAttribute(id, vr);
      }

      return Tag.EVAL_BODY_INCLUDE;
   }

   public int doEndTag() throws JspException
   {
      boolean isEmpty = true;

      if (!bClearAll)
      {
         // Do not leave a row with empty criteria because the query will fail
         for (int a = 0; a < vr.getAttributeCount(); a++)
         {
            Object obj = vr.getAttribute(a);
            if (obj != null)
            {
               isEmpty = false;
               break;
            }
         }
      }

      if (isEmpty)
      {
         vc.removeElementAt(index);
      }
   
      reset();
      
      return EVAL_PAGE;
   }

   // Use by the constructor and the release method to reset the member variable values
   private void reset()
   {
      vc = null;
      vr = null;
      bClearAll = false;
      bUpperColumns = false;
      index = -1;
   }
}
