/*
 * @(#)ViewCriteriaIterateTag.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.html.jsp.datatags;

import java.util.Enumeration;
import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspTagException;
import javax.servlet.jsp.tagext.BodyContent;
import javax.servlet.jsp.tagext.BodyTagSupport;
import oracle.jbo.RowSet;
import oracle.jbo.ViewCriteria;
import oracle.jbo.ViewCriteriaRow;
import oracle.jbo.html.DataSource;

public class ViewCriteriaIterateTag extends BodyTagSupport
{
   String            sDataSource;
   DataSource        ds;
   RowSet            rs;
   Enumeration       rows;
   ViewCriteriaRow   vr;

   public ViewCriteriaIterateTag()
   {
      super();
      reset();
   }

   public void setDatasource(String sDataSource)
   {
      this.sDataSource = sDataSource;
   }

   public String getDatasource()
   {
      return sDataSource;
   }

   public ViewCriteriaRow getCriteriaRow()
   {
      return vr;
   }

   protected void initialize()
   {
      ds = Utils.getDataSourceFromContext(pageContext, sDataSource);
      rs = ds.getRowSet();
   }
   
   public int doStartTag() throws JspException
   {
      initialize();
      
      final ViewCriteria vc = rs.getViewObject().getViewCriteria();
      if (vc == null)
      {
         return SKIP_BODY;
      }
      
      rows = vc.elements();

      if (rows != null && rows.hasMoreElements())
      {
         vr = (ViewCriteriaRow) rows.nextElement();
         return EVAL_BODY_AGAIN;
      }
      else
      {
         return SKIP_BODY;
      }
   }

   public int doAfterBody() throws JspException
   {
      BodyContent body = getBodyContent();
      
      // Flush content and reset
      try
      {
         body.writeOut(getPreviousOut());
         body.clearBody();
      }
      catch (java.io.IOException ex)
      {
         pageContext.getServletContext().log(Res.getString(Res.IO_ERROR), ex);
         throw new JspTagException(ex.getMessage());
      }
      
      if (rows.hasMoreElements())
      {
         vr = (ViewCriteriaRow) rows.nextElement();
      }
      else
      {
         return SKIP_BODY;
      }
      
      return EVAL_BODY_AGAIN;
   }

   public int doEndTag() throws JspException
   {
      reset();
      return EVAL_PAGE;
   }
   
   // Use by the constructor and the release method to reset the member variable values
   private void reset()
   {
      sDataSource = null;
      ds = null;
      rs = null;
      vr = null;
      rows = null;
   }
   
}

