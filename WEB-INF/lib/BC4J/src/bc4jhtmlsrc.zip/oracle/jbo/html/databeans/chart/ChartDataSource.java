/*
 * @(#)ChartDataSource.java
 *
 * Copyright 2000-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.html.databeans.chart;

import oracle.jbo.Row;
import oracle.jbo.RowSet;
import oracle.jbo.domain.DomainInterface;
import tdg.Perspective;
import tdg.data.in.TDGDataGrid;

/**
 *  Data source for the chart control.
 *
 *  @version Internal
 */
abstract public class ChartDataSource
      implements TDGDataGrid
{
    protected  RowSet _qView;
    protected  Row    _rows[];
    protected  Perspective _parent;

    /**
    *  Constructor
    */
    public ChartDataSource(Perspective parent)
    {
        _parent = parent;
    }

    public void setRowSet(RowSet qView)
    {
        _qView = qView;
        _qView.setRangeSize(-1); //(_qView.getEstimatedRowCount());
        _rows = _qView.getAllRowsInRange();
    }

    public RowSet getRowSet()
    {
        return _qView;
    }

    public String getTitle()
    {
       return _parent.getTitleString();
    }

    public String getSubtitle()
    {
       return  _parent.getSubtitleString();
    }

    public String getFootnote()
    {
       return _parent.getFootnoteString();
    }

    public String getX1AxisTitle()
    {
      return _parent.getX1TitleString();
    }

    public String getY1AxisTitle()
    {
       return _parent.getY1TitleString();
    }

    public String getO1AxisTitle()
    {
       return _parent.getO1TitleString();
    }

    public String getO2AxisTitle()
    {
       return _parent.getO2TitleString();
    }

    public String getY2AxisTitle()
    {
      return _parent.getY2TitleString();
    }

    abstract public String columnLabel(int i);


    public int getColumns()
    {
       if  (_qView != null)
           return _qView.getViewObject().getAttributeCount();
       return 0;
    }

    abstract public String rowLabel(int i);

    public int getRows()
    {
        if ( _qView != null )
           return (int)_qView.getEstimatedRowCount();
        return 0;
    }

    public Object getValue(int row, int col)
    {
        Object val = null;
        if ( _rows != null )
        {
            val = _rows[row].getAttribute(col);
            if (val != null && val instanceof DomainInterface)
            {
                val = ((DomainInterface)val).getData();
                return (( val == null) ? "" : val );
            }
        }
        return val;
    }

    public boolean isDirty()
    {
       return false;
    }

    /**
    * Specify data source for row labels. The labels could be
    * <UL>
    * <LI> column values of a table
    * <LI> column names (display names) of a table
    * </UL>
    * <P>
    * The dataitem name of the column should be specified to indicate
    * the column values of a table
    *<P> The dataitem name of the rowset should be specified to indicate
    * the column display name of some table
    *
    * @see setRowLabelDataSource(Object)
    * @param dataitemName of the column values or the rowset
    */
    abstract public void setRowLabelDataSource(ChartLabelDataSource labelSource);

    abstract public ChartLabelDataSource getRowLabelDataSource();

    abstract public void setRowLabel(Object[] labels);

    abstract public Object[] getRowLabel();

    /**
    * Specify data source for row labels. The labels could be
    * <UL>
    * <LI> column values of a table
    * <LI> column names (display names) of a table
    * </UL>
    * <P>
    * The dataitem name of the column should be specified to indicate
    * the column values of a table
    *<P> The dataitem name of the rowset should be specified to indicate
    * the column display name of some table
    *
    * @see setRowLabelDataSource(Object)
    * @param dataitemName of the column values or the rowset
    */
    abstract public void setColumnLabelDataSource(ChartLabelDataSource labelSource);

    abstract public ChartLabelDataSource getColumnLabelDataSource();

    abstract public void setColumnLabel(Object[] labels);

    abstract public Object[] getColumnLabel();

    protected void _updateChart()
    {
    }
}

