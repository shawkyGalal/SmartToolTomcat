/*
 * @(#)MethodInvoker.java
 *
 * Copyright 2000-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.html.databeans.chart;

import java.awt.Color;
import java.awt.Font;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Properties;
import java.util.StringTokenizer;
import tdg.Perspective;

/**
 * A helper class to get/set properties on Perspective bean
 *
 * @version Internal
^
 */
public class MethodInvoker
{
    Object _invokeOn;
    Class  _objectClass;
    PropertyNameList _propertyNameList;

    /**
    * Constructor
    *
    *  @param invokeOn - get/set method's will be invoked on this object
    *  @param propertyFileName - name of the file which contains the list of
    *         properties supported by the object ('invokeOn')
    */
    public MethodInvoker(Object invokeOn, String propertyFileName)
    {
        _invokeOn = invokeOn;
        _objectClass = invokeOn.getClass();
        _propertyNameList = new PropertyNameList(_objectClass,
                                           propertyFileName);

    }

    /**
    *  Invokes set property method on the object. The name of the property
    *  should not include the set prefix. To set, 'GraphType', pass GraphType
    *  as the property name.
    *
    *  @param name name of the property
    *  @arg   new value to set
    */
    public void invokeSetProperty(String name, String arg)
         throws IllegalAccessException, InvocationTargetException,
         ClassNotFoundException, NoSuchMethodException
    {
        Method m = _propertyNameList.getMethod(name, PropertyNameList.SET);
        Class  argType = _propertyNameList.getArgumentType(name);
        Object o[] =  new Object[] { _propertyNameList.toObject(argType, arg)};
        m.invoke(_invokeOn, o );
    }

    /**
    *  Invokes get property method on the object. The name of the property
    *  should not include the get prefix. To get, 'GraphType', pass GraphType
    *  as the property name.
    *
    *  @param name name of the property
    *  @return value of the property returned as a String
    */
    public String invokeGetProperty(String name)
         throws IllegalAccessException, InvocationTargetException,
                ClassNotFoundException, NoSuchMethodException
    {
        Method m = _propertyNameList.getMethod(name, PropertyNameList.GET);
        Class  argType = _propertyNameList.getArgumentType(name);
        Object o = m.invoke(_invokeOn, new Object[] {});
        return _propertyNameList.toString( argType, o);
    }

    /**
    * test this class
    */
    public static void main(String[] arg)
    {
       Perspective p =  new Perspective();
       MethodInvoker pMI = new  MethodInvoker(p, "Perspective.properties");

       try
       {
           System.out.println("get " + pMI.invokeGetProperty("GraphType"));
           pMI.invokeSetProperty("GraphType", "55");
           System.out.println("get " + pMI.invokeGetProperty("GraphType"));

           System.out.println("get " + pMI.invokeGetProperty("ColorMode"));
           pMI.invokeSetProperty("ColorMode", "1");
           System.out.println("get " + pMI.invokeGetProperty("ColorMode"));

           System.out.println("get " + pMI.invokeGetProperty("PropertyDoesNotExist"));
       }
       catch (InvocationTargetException inv)
       {
           System.out.println(inv.getTargetException().toString());
          inv.printStackTrace();
       }
       catch(Exception  e)
       {
          e.printStackTrace();
       }
    }

}

/**
*  A helper class used by MethodInvoker. This class reads a property file which
*  defines a list of property name and their type.
*
*  This class provides helper method to  do the type conversion between string
*  to whatever type the property is.
*
*  @version Internal
*/
class PropertyNameList
{
    /**
    * identifier for a setter method
    */
    static final int SET = 0;

    /**
    * identifier for a getter method
    */
    static final int GET = 1;

    /**
    * of the bean whose property we would be manipulating
    */
    Class  _class;

    /**
    * list of propeties of the bean of type _class
    */
    Properties _list = new Properties();

    /**
    * Constructor
    *
    * @param c Class for the object whose property has to be set/get
    * @param propertyFileName name of the property file which contains a
    *        description of the properties the class 'C' supports and their
    *        types.
    */
    public PropertyNameList(Class c, String propertyFileName)
    {
        _class = c;
        loadPropertiesDescription(propertyFileName);
    }

    /**
    * get argument type of method name
    *
    * @param name of the property
    * @return property's 'type'
    */
    public Class getArgumentType(String name)
        throws ClassNotFoundException
    {
        String argName = (String)_list.get(name);
        if ( argName.equals("int"))
            return Integer.TYPE;
        else if ( argName.equals("boolean"))
            return Boolean.TYPE;
        return (Class.forName(argName));
    }

    /**
    *   get a method object representing the property (actually the corresponding
    *   get/set method)
    *
    *   @param name of the property
    *   @methodType set or get method involved ?
    */
    public Method getMethod(String name, int methodType)
           throws ClassNotFoundException, NoSuchMethodException
    {
         return getMethod(_class, name, methodType, true);
    }


    public Method getMethod(Class clazz, String name, int methodType, boolean checkParent)
           throws ClassNotFoundException, NoSuchMethodException
    {
        String methodName = null;
        Class[] args = null;

        if ( methodType == SET)
        {
            Class  argType = getArgumentType(name);
            methodName = "set" + name;
            args  = new Class[] { argType };
        }
        else
        {
            methodName = "get"+ name;
            args = new Class[]{};
        }

        try
        {
            return clazz.getDeclaredMethod(methodName, args);
        }
        catch(NoSuchMethodException e)
        {
            if ( checkParent)
            {
                Class parent = clazz.getSuperclass();
                if (parent != null )
                     return getMethod(parent, name, methodType, true);
            }
            throw e;
        }
    }

    /**
    *  Parse the string and if possible return an Object of type represented
    *  by Class 'c'.
    *
    *  @param c object type we want the string s to be converted to
    *  @param s string we want to convert to
    */
    public Object toObject(Class c, String s)
    {
       if ( c.equals(String.class))
           return s;
       else if (c.equals(Boolean.TYPE))
           return new Boolean(s);
       else if (c.equals(Integer.TYPE))
           return new Integer(s);
       else if (c.equals(Double.TYPE))
           return new Double(s);
       else if ( c.equals(Color.class))
          return createColor(s);
       else if (c.equals(Font.class))
          return createFont(s);

       return null;
    }

    /**
    * Convert object 'o' of type 'c' to a string
    */
    public String toString(Class c, Object o)
    {
       if (c.equals(Color.class))
       {
           Color clr = (Color)o;
           return clr.getRed() + "," + clr.getGreen() + "," + clr.getBlue();
       }
       else if (c.equals(Font.class))
       {
           Font f = (Font)o;
           return f.getFamily()+ "," + f.getStyle() +"," +f.getSize();
       }
       return o.toString();
    }

    /**
    *  load the list of properties and the arg types
    *
    *   @param filename name of the properties file to load
    */
    protected void loadPropertiesDescription(String filename)
    {
       try
       {
          // find the property file in the classpath
          _list.load(MethodInvoker.class.getResourceAsStream(filename));
          System.out.println("properties loaded successfully");
       }
       catch(Exception exc)
       {
           System.err.println(exc.getMessage());
           exc.printStackTrace();
           throw new RuntimeException(exc.getLocalizedMessage());
       }
    }

    /**
    * color should be a string of the form "r,g,b"
    */
    protected Color createColor(String s)
    {
        StringTokenizer st  = new StringTokenizer(s,",", false);
        int rgb[] = new int[3];
        int i = 0;
        while (st.hasMoreTokens())
        {
              String token = st.nextToken();
              rgb[i++] = Integer.parseInt(token);
        }
        return new Color( rgb[0], rgb[1], rgb[2]);
    }

    /**
    * Font should be a string of form "name,style,size"
    *
    * ex., "Courier, 2, 10"
    */
    protected Font createFont(String s)
    {
        StringTokenizer st  = new StringTokenizer(s,",", false);
        String fontDesc[] = new String[3];
        int i = 0;
        while (st.hasMoreTokens())
           fontDesc[i++] = st.nextToken();
        return new Font( fontDesc[0], Integer.parseInt(fontDesc[1]),
                                         Integer.parseInt(fontDesc[2]));
    }

}


