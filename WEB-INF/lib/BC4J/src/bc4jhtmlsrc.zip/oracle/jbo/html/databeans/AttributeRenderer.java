/*
 * @(#)AttributeRenderer.java
 *
 * Copyright 2000-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.html.databeans;


public interface AttributeRenderer
{
  public String getAttributeHtml(String sName , String sValue);
}