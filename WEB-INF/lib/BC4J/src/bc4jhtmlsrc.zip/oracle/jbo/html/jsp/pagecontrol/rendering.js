var doAll = (document.all!=null)

function getPageElement(id)
{    
 if (doAll)       
    return document.all[id]    
 else
    return document.layers[id]  
}

function findOrCreateTargetFrame(destID)
{
   var iframe =  document.frames[destID+"target"]

   if (iframe==null)
   {
    document.body.insertAdjacentHTML( "beforeEnd",
                                      "<IFRAME  STYLE='width: 0pt; height: 0pt' NAME='"+destID+"target' SRC='' ></IFRAME>")
    iframe = document.frames[destID+"target"]
   }
   return iframe
}

function updateRegionContents(destID, src)
{
 var el = getPageElement(destID)
 if (doAll)
 {
    destFrame = findOrCreateTargetFrame(destID)
    destFrame.location.href = src        
    setTimeout("updateRegionIfFrameLoaded('"+destID+"')", 200)
 }
 else
 {
    el.src = src
 }
}

function updateRegionIfFrameLoaded(destID)
{
   var destFrame = findOrCreateTargetFrame(destID)
   
   if (destFrame.document.readyState =='complete')
   {
      var el = getPageElement(destID);
      el.outerHTML = destFrame.document.body.innerHTML;
   }
   else
   {
      setTimeout("updateRegionIfFrameLoaded('"+destID+"')", 200);
   }
 }

function updateRegion(destID, src)
{
   if (src=="none")
   {
      var el = getPageElement(destID)

      if (doAll)
         el.innerHTML = ""
      else
      {
         el.document.open()
         el.document.write("")
         el.document.close()
      }
   }
   else
      updateRegionContents(destID, src)
}
