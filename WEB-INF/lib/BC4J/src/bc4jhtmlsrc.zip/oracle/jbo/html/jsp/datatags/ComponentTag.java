/*
 * @(#)ComponentTag.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.html.jsp.datatags;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspTagException;
import javax.servlet.jsp.tagext.Tag;
import javax.servlet.jsp.tagext.TagSupport;

/**
 */
public class ComponentTag extends TagSupport
{
   public static final String defaultUrl = "";
   protected String  sRelativeUrlPath;

   public ComponentTag()
   {
      super();
      reset();
   }

   protected void reset()
   {
      sRelativeUrlPath = defaultUrl;
   }

   public void setRelativeUrlPath(String sValue)
   {
      this.sRelativeUrlPath = sValue;
   }

   public final String buildUrl(String url, String[] names, String[] values)
   {
      return Utils.buildUrl(url, names, values);
   }
   
   public String getUrl()
   {
      return buildUrl(sRelativeUrlPath, null, null);
   }

   public int doStartTag() throws JspException
   {
      final String url = getUrl();

      // Include
      try
      {
         pageContext.getOut().flush();
         pageContext.include(url);
      }
      catch (java.io.IOException ex)
      {
         pageContext.getServletContext().log(Res.getString(Res.IO_ERROR), ex);
         throw new JspTagException(ex.getMessage());
      }
      catch (javax.servlet.ServletException ex)
      {
         pageContext.getServletContext().log(Res.getString(Res.INCLUDE_ERROR), ex);
         throw new JspTagException(ex.getMessage());
      }

      return Tag.SKIP_BODY;
   }

   public int doEndTag() throws JspException
   {
      reset();
      return EVAL_PAGE;
   }
}
