/*
 * @(#)SetFieldRendererTag.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.html.jsp.datatags;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.tagext.Tag;
import oracle.jbo.AttributeDef;
import oracle.jbo.html.HtmlServices;
import oracle.jdeveloper.html.HTMLFieldRenderer;

public class SetFieldRendererTag extends ShowTagBase
{
   protected String fieldType; // Required attribute
   protected String sClassRenderer; // Required attribute

   public void setFieldtype(String sType)
   {
      fieldType = sType;
   }

   public void setClassname(String className)
   {
      sClassRenderer = className;
   }

   public int doStartTag() throws JspException
   {
      AttributeDef attrDef = getAttributeDef();

      HTMLFieldRenderer rndField = HtmlServices.getFieldRendererFromClassName(sClassRenderer, pageContext);

      rndField.setDatasource(ds);
      rndField.setAttributeDef(attrDef);
      
      if ("DISPLAY".equalsIgnoreCase(fieldType))
      {
         ds.setDisplayFieldRenderer(attrDef.getIndex(), rndField);
      }
      else if ("EDIT".equalsIgnoreCase(fieldType))
      {
         ds.setEditFieldRenderer(attrDef.getIndex(), rndField);
      }
      
      return Tag.SKIP_BODY;
   }
}

