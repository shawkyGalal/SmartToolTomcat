/*
 * @(#)HDCmdBlock.java
 *
 * Copyright 1998-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.html.htmldrv;

import java.io.*;
import java.net.*;
import java.util.*;
import oracle.jbo.expr.JIException;
import oracle.jbo.expr.JIToken;
import oracle.jbo.html.*;
import oracle.jbo.test.interp.JICmdBlock;
import oracle.jdeveloper.html.parser.*;

public class HDCmdBlock extends JICmdBlock
{
   static HDFile curHtmlFile = null;

   public HDCmdBlock()
   {
      super();
   }


   public HDCmdBlock(LineNumberReader ins, boolean isConsole, boolean printPrompt)
   {
      super(ins, isConsole, printPrompt);
   }

   
   /*----- HTML file management methods -----*/
   
   public HDFile getHDFile()
                    throws IOException, JIException
   {
      HDFile hFile;
      String fileName;

      fileName = findNextWord(true).getTokStr();
      
      if (fileName.length() > 0)
      {
         Object val = getVariableVal(fileName);
         
         if (val instanceof HDFile)
         {
            hFile = (HDFile) val;
         }
         else
         {
            throw new JIException(val + " is not an HTML file");
         }
      }
      else  if (curHtmlFile == null)
      {
         throw new JIException("No HTML file available");
      }
      else
      {
         hFile = curHtmlFile;
      }
      
      return hFile;
   }


   public HDFile setHtmlFile(String nam)
   {
      HDFile hFile = new HDFile();
      String fileName;
      String varName;

      if (nam != null)
      {
         int indx = nam.indexOf(":");
         
         if (indx >= 0)
         {
            fileName = nam.substring(0, indx);
            varName = nam.substring(indx + 1);
         }
         else
         {
            fileName = nam;
            varName = nam;
         }
      }
      else
      {
         fileName = null;
         varName = null;
      }

      fileName = hFile.setFileName(fileName);
      
      if (varName == null)
      {
         varName = fileName;
      }
      
      varName.replace('.', '_');

      setVariableVal(varName, hFile);
      hFile.setVarName(varName);
      
      return hFile;
   }
   

   /*----- Var/value print methods -----*/
   
   public String valToString(String valExpr, Object val, boolean full, int lev)
   {
      String retVal = super.valToString(valExpr, val, full, lev);

      IHTMLParserNode pNode;

      try
      {
         pNode = (IHTMLParserNode) val;
      }
      catch(Exception ex)
      {
         pNode = null;
      }
      
      if (pNode != null)
      {
         retVal += " tag=" + pNode.getNodeTag();
      }

      return retVal;
   }
   

   /*----- Command processing methods -----*/
   
   public boolean processGetOrPost(boolean postFlag) throws IOException
   {
      JIToken word = findNextWord(false);
      boolean appendFlag = false;
      boolean typeFlag = false;
      
      String fileName = null;

      if (word.equals(">"))
      {
         if (findNextWord(false).equals(">"))
         {
            appendFlag = true;
         }
         else
         {
            rewindWord();
         }
         
         if (findNextWord(false).equals("|"))
         {
            typeFlag = true;
         }
         else
         {
            rewindWord();
         }
         
         fileName = findNextWord(true).getTokStr();
      }
      else
      {
         rewindWord();
      }
      
      String urlString = (String) getExprVal(this);

      URL url = new URL(urlString);
      InputStream strm = null;
      
      if (postFlag)
      {
         URLConnection conn = url.openConnection();

         conn.setDoOutput(true);
      
         String val = (String) getExprVal(this);

         NoMoreTokenCheck();

         PrintWriter out = null;
         
         try
         {
            out = new PrintWriter(new OutputStreamWriter(conn.getOutputStream()));
            out.print(val);
            out.flush();
         }
         finally
         {
            if (out != null)
            {
               out.close();
            }
         }
      
         strm = conn.getInputStream();
      }
      else
      {
         NoMoreTokenCheck();

         strm = url.openStream();
      }

      curHtmlFile = setHtmlFile(fileName);
      curHtmlFile.writeFile(strm, appendFlag, typeFlag);

      if (curHtmlFile.isFileTemporary())
      {
         if (verbose)
         {
            System.out.println("Temporary file name is " + curHtmlFile.getFileName());
         }
      }
      
      return true;
   }
   
   public boolean processGet() throws IOException
   {
      return processGetOrPost(false);
   }
   
   public boolean processPost() throws IOException
   {
      return processGetOrPost(true);
   }
   
   public boolean processType()
                     throws IOException, JIException
   {
      HDFile hFile = getHDFile();
      
      NoMoreTokenCheck();

      hFile.type();

      return true;
   }
   
   public boolean processIterate()
                     throws IOException, JIException
   {
      String iterName = findNextWord(false).getTokStr();

      if (iterName == null)
      {
         throw new JIException("Missing iterator name");
      }
      
      JIToken word = findNextWord(false);
      
      if (word.getTokStr() != null && word.getTokStr().length() > 0)
      {
         if (word.equals("over") == false)
         {
            throw new JIException("Expecting 'over <file-name>'");
         }
      }

      HDFile hFile = getHDFile();

      NoMoreTokenCheck();

      HDIterator hIter = new HDIterator(hFile);
      
      setVariableVal(iterName, hIter);
      
      return true;
   }
   
   public boolean processParse()
                     throws IOException, JIException
   {
      HDFile hFile = getHDFile();
      
      NoMoreTokenCheck();

      hFile.parse();

      return true;
   }
   
   public boolean processDelete()
                     throws IOException, JIException
   {
      HDFile hFile = getHDFile();
      
      if (hFile.getVarName() != null)
      {
         removeVariable(hFile.getVarName());
      }
      
      NoMoreTokenCheck();

      hFile.delete();

      return true;
   }


   /*----- Command parsing methods -----*/
   
   public boolean parseCommand() throws IOException
   {
      String cmdStr = findNextWord(false).getTokStr();

      if (cmdStr.equals("get"))
      {
         processGet();
      }
      else  if (cmdStr.equals("iterate"))
      {
         processIterate();
      }
      else  if (cmdStr.equals("parse"))
      {
         processParse();
      }
      else  if (cmdStr.equals("delete"))
      {
         processDelete();
      }
      else  if (cmdStr.equals("post"))
      {
         processPost();
      }
      else  if (cmdStr.equals("type"))
      {
         processType();
      }
      else
      {
         rewindWord();
         return super.parseCommand();
      }
      
      return true;
   }
}
