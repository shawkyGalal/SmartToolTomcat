/*
 * @(#)VHHGTest.java
 *
 * Copyright 1999-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.html.testhg;

import java.io.*;
import java.lang.*;
import java.util.*;
import oracle.jbo.html.*;

public class VHHGTest
{
   public static String htmlFileName;
   public static String outFileName;
   public static FileInputStream htmlFile;
   public static FileInputStream bndDefFile;
   public static PrintWriter outWriter = null;
   
   public static boolean justListBindings = false;
   
   public static void main(String[] args)
   {
      int argsIndx = 0;

      if (args.length > argsIndx && args[argsIndx].equals("-l"))
      {
         justListBindings = true;
         argsIndx++;
      }
      
      if (args.length < argsIndx + 1)
      {
         System.err.println("Usage: java VHDCodeGen [-l] <html-file>");
         return;
      }

      htmlFileName = args[argsIndx++];

      try
      {
         htmlFile = new FileInputStream(htmlFileName);
         bndDefFile = new FileInputStream(htmlFileName);
      }
      catch (IOException e)
      {
         System.err.println("HTML input file " + htmlFileName + " could not be opened");
         e.printStackTrace();

         return;
      }

      FileOutputStream outFile;

      try
      {
         if (!justListBindings)
         {
            outFileName = "codegen.out";
            outFile = new FileOutputStream(outFileName);
            outWriter = new PrintWriter(outFile);
         }
      }
      catch (IOException e)
      {
         System.err.println("Code gen output file " + outFileName + " could not be opened");
         e.printStackTrace();

         return;
      }

      try
      {
         VHHandlerGenerator.genFromHTMLFile(htmlFile, bndDefFile, outWriter,
                                            !justListBindings);

         htmlFile.close();
         
         if (outWriter != null)
         {
            outWriter.flush();
            outWriter.close();
         }
      }
      catch (IOException e)
      {
         e.printStackTrace();
      }
      catch (Exception e)
      {
         e.printStackTrace();
      }
   }
}
