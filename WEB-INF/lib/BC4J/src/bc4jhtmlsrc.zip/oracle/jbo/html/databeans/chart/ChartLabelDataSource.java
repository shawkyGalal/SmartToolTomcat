/*
 * @(#)ChartLabelDataSource.java
 *
 * Copyright 2000-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.html.databeans.chart;

/**
 *  interface to specify chart labels
 *
 *  @version Internal
 */
public interface ChartLabelDataSource
{
    /**
    *  get label for a particular column index
    */
    public String getLabel(int index);

    /**
    *  update the labels - possibly the data source changed.
    *
    */
    //public void refreshLabels();
}
