/*
 * @(#)DataScroller.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.html.jsp.datatags;

import java.io.Serializable;

import javax.servlet.jsp.PageContext;

import oracle.jbo.RowIterator;
import oracle.jbo.RowSet;
import oracle.jbo.html.DataSource;

/**
 */
public class DataScroller implements Serializable
{
   public static final String ATTR_NAME = "jboScroller";
   
   protected transient DataSource ds;
   protected transient long       totalCount;
   protected transient long       rangeStart;
   protected transient int        rangeSize;
   protected transient long       leftOver;
   protected transient int        steps;
   protected transient int        iterMode;

   public DataScroller()
   {
   }
   
   public void initialize(PageContext pageContext, String dsName)
   {
      ds = Utils.getDataSourceFromContext(pageContext, dsName);
      RowSet rs = ds.getRowSet();

      // Initialize the beginning of the range to at least 0      
      if (rs.getRangeStart() < 0)
      {
         rs.setRangeStart(0);
      }

      // Initialize some values used to render the scroller.
      iterMode = rs.getIterMode();
      totalCount = rs.getEstimatedRowCount();
      rangeSize = rs.getRangeSize();
      if (totalCount > 0 && rangeSize > totalCount)
      {
         rangeSize = (int)totalCount;
      }
      rangeStart = rs.getRangeStart() + 1;
      long rangeEnd = rangeStart + rs.getRowCountInRange() - 1;
      if (rangeEnd < 0) rangeEnd = 0;
      leftOver = totalCount - rangeEnd;

      steps = (int) (totalCount/rangeSize);
      if (steps * rangeSize < totalCount)
      {
         steps++;
      }
   }

   public long getRangeStart()
   {
      return rangeStart;
   }

   public long getLeftOver()
   {
      return leftOver;
   }

   public int getSteps()
   {
      return steps;
   }

   public long getStart(int step)
   {
      if (iterMode == RowIterator.ITER_MODE_LAST_PAGE_FULL)
      {
         return (getEnd(step) - rangeSize + 1);
      }
      else
      {
         return (step*rangeSize + 1);
      }
   }

   public long getEnd(int step)
   {
      long end = (step + 1) * rangeSize;
      if (end > totalCount)
      {
         end = totalCount;
      }

      return end;
   }

   public long getValue(int step)
   {
      return getStart(step);
   }

   public String getSelected(int step)
   {
      if (getStart(step) == rangeStart)
      {
         return "selected";
      }

      return "";
   }

   public long getTotalCount()
   {
      return totalCount;
   }

}
