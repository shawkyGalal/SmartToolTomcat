/*
 * @(#)HTMLTokenizer.java
 *
 * Copyright 1999-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.html.htmldrv;

import java.io.*;
import java.io.*;
import java.util.*;

/**
 *
 * @version INTERNAL
 */
class HTMLTokenizer extends StreamTokenizer
{
   public static final int TT_STARTTAG       =  100; //<
   public static final int TT_ENDTAG         =  200; //</
   public static final int TT_STARTJBOTAG    =  300; //{%
   public static final int TT_ENDJBOTAG      =  400; //%}
   public static final int TT_ENDFOR         =  500; //endfor
    
   public String TagName;

   int   nToken;

   public HTMLTokenizer(Reader inp)
   {
      super(inp);

      ordinaryChar('#');
      ordinaryChar(' ');
      ordinaryChar('\'');
      ordinaryChar('!');
      ordinaryChar(',');
      ordinaryChar('/');
      ordinaryChar('.');
      ordinaryChar('=');
      ordinaryChar('"');
      ordinaryChar('@');
      ordinaryChar(';');
      ordinaryChar(')');
      ordinaryChar('(');
      ordinaryChar('.');
      ordinaryChar('"');
      ordinaryChar('&');
      ordinaryChar('%');
      ordinaryChar('!');                          
      ordinaryChars('0', '9');
      wordChars('0', '9');
      wordChars('_', '_');
      wordChars('&', '&');
     // wordChars('<', '<');
     // wordChars('>', '>');                  

      eolIsSignificant(true);
   }
   
   public int currentToken()
   {
      return nToken;
   }
   
   public void skipSpaces() throws Exception
   {
      while(currentToken() == ' ')
         nextToken();
   }
   

   public String getIdentifier(int nEndDelimiter) throws Exception
   {
      String sName = "";

      while(ttype != nEndDelimiter && ttype != TT_EOF)
      {
         sName += sval;
         nextToken();
      }

      return sName;
   }
   
   public String getIdentifierUntilToken(int nEndDelimiter) throws Exception
   {
      String sName = "";

      while(nToken != nEndDelimiter && ttype != TT_EOF)
      {
         sName += sval;
         nextToken();
      }

      return sName;
   }
   
   public int nextToken() throws IOException
   {

      
      nToken = super.nextToken();
      TagName = null;
      
      //System.out.println("------------" + toString());
      
      if(ttype == TT_NUMBER)
      {
         StringBuffer buff = new StringBuffer();
         
         buff.append(nval);
         
         //sval =  String.valueOf((char)nval);
         sval = buff.toString();
      }
      
      if(ttype == TT_EOL)
      {
         sval = "\n";
      }
      
      switch(nToken)
      {
       case '/':
            sval = "/";
            ttype = TT_WORD;
            break;
       case '&':
            sval = "&";
            ttype = TT_WORD;
            break;
       case '>':
            sval = ">";
            ttype = TT_WORD;
            break;
       case '<':
            sval = "<";
            ttype = TT_WORD;
            break;            
       case ' ':
            sval = " ";
            ttype = TT_WORD;
            break;
        case '=':
            sval = "=";
            ttype = TT_WORD;
            break;
        case '"':
            sval = "\"";
            ttype = TT_WORD;
            break;
         case '%':
            sval = "%";
            ttype = TT_WORD;
            break;
          case '.':
            sval = ".";
            ttype = TT_WORD;
            break;
          case ';':
            sval = ";";
            ttype = TT_WORD;
            break;
          case '[':
            sval = "[";
            ttype = TT_WORD;
            break;
          case ']':
            sval = "]";
            ttype = TT_WORD;
            break;
          case '(':
            sval = "(";
            ttype = TT_WORD;
            break;
          case ')':
            sval = ")";
            ttype = TT_WORD;
            break;
          case '!':
            sval = "!";
            ttype = TT_WORD;
            break;
          case ':':
            sval = ":";
            ttype = TT_WORD;
            break;
          case '#':
            sval = "#";
            ttype = TT_WORD;
            break;
          case '@':
            sval = "@";
            ttype = TT_WORD;
            break;
          case '{':
            sval = "{";
            ttype = TT_WORD;
            break;
          case '}':
            sval = "}";
            ttype = TT_WORD;
            break;
          case '-':
            sval = "-";
            ttype = TT_WORD;
            break;
          case '\'':
            sval = "'";
            ttype = TT_WORD;
            break;
          case ',':
            sval = ",";
            ttype = TT_WORD;
            break;
          case '+':
            sval = "+";
            ttype = TT_WORD;
            break;            
         
      }

      if(nToken == '{')
      {
         int nToken2 = super.nextToken();

         if(nToken2 == '%')
         {
            sval = "{%";
            ttype = TT_STARTJBOTAG;
            System.out.println("++Begin Cmd");
            return nToken2;
         }
         else
         {
            pushBack();
            sval = "{";
         }
      }

      if(nToken == '%')
      {

         int nToken2 = super.nextToken();

         if(nToken2 == '}')
         {
            sval = "%}";
            ttype = TT_ENDJBOTAG;
            System.out.println("++End Cmd");
            return nToken2;
         }
         else
         {
            pushBack();
            sval = "%";
         }
      }

      if(nToken == '<')
      {
         int nNext = nextToken();

/*         if(nNext == '!')
         {
           pushBack();
           sval = "<";
           return nToken;
         }
*/
         if(nNext == '/')
         {
            String sTagName;

            //get the tag name
            nNext = nextToken();
            TagName = sval;

            //skip the >
            //nNext = nextToken();

            //setup instance variables
            //sval = sTagName;
            //TagName = sTagName;
            
            ttype = TT_ENDTAG;
            // System.out.println("** End Tag Name [" + TagName + "]");
         }
         else
         {
            TagName = sval;
            ttype = TT_STARTTAG;
            // System.out.println("** Begin Tag Name [" + TagName + "]");
         }


      }

      return nToken;
   }
}