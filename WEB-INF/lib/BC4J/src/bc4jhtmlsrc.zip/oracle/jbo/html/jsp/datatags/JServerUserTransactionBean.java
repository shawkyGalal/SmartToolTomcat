/*
 * @(#)JServerUserTransactionBean.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.html.jsp.datatags;

import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Hashtable;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.transaction.UserTransaction;
import oracle.aurora.jndi.jdbc_access.jdbc_accessURLContextFactory;
import oracle.aurora.jndi.sess_iiop.ServiceCtx;
import oracle.jdbc.driver.OracleDriver;

public class JServerUserTransactionBean 
{
   private String user;
   private String passwd;
   private String namespaceUrl;
   private String userTransactionUrl;
   private UserTransaction ut;


   public String getUser()
   {
      return user;
   }

   public void setUser(String s)
   {
      user = s;
   }

   public String getPasswd()
   {
      return passwd;
   }

   public void setPasswd(String s)
   {
      passwd = s;
   }

   public String getNamespaceUrl()
   {
      return namespaceUrl;
   }

   public void setNamespaceUrl(String s)
   {
      namespaceUrl = s;
   }

   public String getUserTransactionUrl()
   {
      return userTransactionUrl;
   }

   public void setUserTransactionUrl(String url)
   {
      userTransactionUrl = url;
   }

   public void commit()
   {
      try
      {
         getUserTransaction().commit();
      }
      catch (RuntimeException ex)
      {
         throw ex;
      }
      catch (Exception ex)
      {
         throw new RuntimeException("Error committing transaction: "+ ex.getMessage());
      }
   }

   public void rollback()
   {
      try
      {
         getUserTransaction().rollback();
      }
      catch (RuntimeException ex)
      {
         throw ex;
      }
      catch (Exception ex)
      {
         throw new RuntimeException("Error rollingback transaction: " + ex.getMessage());
      }

   }

   public void begin()
   {
      try
      {
         getUserTransaction().begin();
      }
      catch (RuntimeException ex)
      {
         throw ex;
      }
      catch (Exception ex)
      {
         throw new RuntimeException("Error starting transaction: " + ex.getMessage());
      }
   }



   public void lookup()
   {
      registerDriver();
      Hashtable env = createInitialContextEnv();
      try
      {
         Context ctx ;
         if (env == null)
         {
            ctx = new InitialContext();
         }
         else
         {
            ctx = new InitialContext(env);
         }
         ut = (UserTransaction)ctx.lookup(getUserTransactionUrl());
      }
      catch (NamingException ex)
      {
         Throwable t = ex.getRootCause();
         ex.printStackTrace();
         throw new RuntimeException("Error in looking up usertransaction: " +
                                    t.getMessage());
      }
   }

   private UserTransaction getUserTransaction()
   {
      if (ut == null)
      {
         lookup();
      }
      return ut;
   }

   protected Hashtable createInitialContextEnv()
   {
       Hashtable env = new Hashtable();
       env.put(Context.URL_PKG_PREFIXES, "oracle.aurora.jndi");
       env.put(Context.SECURITY_PRINCIPAL, user);
       env.put(Context.SECURITY_CREDENTIALS, passwd);
       env.put(Context.SECURITY_AUTHENTICATION, ServiceCtx.NON_SSL_LOGIN);
       env.put(jdbc_accessURLContextFactory.CONNECTION_URL_PROP, namespaceUrl);
       return env;
   }

   private void registerDriver()
   {
      try
      {
         DriverManager.registerDriver(new OracleDriver());
      }
      catch(SQLException ex)
      {
         throw new RuntimeException("Unable to register driver: " + ex.getMessage()); 
      }
   }
}
