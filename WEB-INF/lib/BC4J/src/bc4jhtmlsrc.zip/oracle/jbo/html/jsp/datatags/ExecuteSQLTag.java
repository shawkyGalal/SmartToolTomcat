/*
 * @(#)ExecuteSQLTag.java
 *
 * Copyright 2000-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.html.jsp.datatags;

import java.io.StringWriter;
import javax.servlet.jsp.JspException;
import javax.servlet.jsp.tagext.BodyTag;
import javax.servlet.jsp.tagext.BodyTagSupport;
import javax.servlet.jsp.tagext.Tag;
import oracle.jbo.ApplicationModule;
import oracle.jbo.common.ampool.ApplicationModuleRef;

public class ExecuteSQLTag extends BodyTagSupport
{
   protected String amId; // Required attribute

   public void setAppid(String amId)
   {
      this.amId = amId;
   }

   /**
   * doEndTag
   * @return int
   * @exception javax.servlet.jsp.JspException
   */
   public int doEndTag() throws JspException
   {
      try
      {
         if (this.bodyContent != null)
         {
            StringWriter strout = new StringWriter();

            bodyContent.writeOut(strout);

            String sQuery = strout.toString();

            final ApplicationModuleRef amRef = Utils.getAMRefFromContext(pageContext, amId);
            final ApplicationModule am = amRef.useApplicationModule();

            am.getTransaction().executeCommand(sQuery);
         }
      }
      catch (Exception ex)
      {
         ex.printStackTrace(System.err);
         throw new JspException(ex.getMessage());
      }
      
      return Tag.EVAL_PAGE;
   }

   /**
    * doStartTag
    * @return int
    * @exception javax.servlet.jsp.JspException
    */
   public int doStartTag() throws JspException
   {
      return BodyTag.EVAL_BODY_AGAIN;
   }
}
