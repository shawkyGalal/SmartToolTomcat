/*
 * @(#)InputRenderTag.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.html.jsp.blaf;

import oracle.cabo.ui.data.BoundValue;
import oracle.cabo.ui.data.DataObject;
import oracle.jbo.html.DataSource;

import oracle.jbo.AttributeDef;
import oracle.jbo.Row;
import oracle.cabo.ui.RenderingContext;
import oracle.ord.html.OrdBuildURLRenderer;

public class OrdBoundValue implements BoundValue
{
    private DataSource ds;
    private AttributeDef aDef;
    private String datasource;

    public OrdBoundValue(DataSource ds, AttributeDef aDef, String datasource)
    {
        this.ds = ds;
        this.aDef = aDef;
        this.datasource = datasource;
    }

    public Object getValue(RenderingContext context)
    {
        DataObject source = context.getDataObject("bc4j:", datasource);
        Row row = (Row)source.selectValue(context, "row");
        OrdBuildURLRenderer obu = new OrdBuildURLRenderer(ds, row, aDef.getName());
        String text = obu.renderToString(row);
        return text;
    }

}
