/*
 * @(#)JSTreeBrowser.java
 *
 * Copyright 2000-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.html.databeans;

import java.util.Vector;
import oracle.jbo.AttributeDef;
import oracle.jbo.Row;
import oracle.jbo.RowSet;
import oracle.jbo.ViewLink;
import oracle.jdeveloper.html.DataWebBeanImpl;
import oracle.jdeveloper.html.WebBean;
import oracle.jdeveloper.html.DHTMLElement;
import oracle.jdeveloper.html.DHTMLRow;
import oracle.jdeveloper.jsp.wb.JSTree;
import oracle.jdeveloper.jsp.wb.JSTreeData;

public class JSTreeBrowser extends DataWebBeanImpl
{
   int         nVisibleRows = 10;
   int         nDepthLevel = 1;
   Vector      nodeLabel;
   JSTree      tree;
   JSTreeData  data;
   
   private String accessorName = null;     

   public void JSTreeBrowser()
   {
   }

   /**
   * @param nRows number of rows to display in the tree browser.
   */
   public void setVisibleRows(int nRows)
   {
      nVisibleRows = nRows;
   }

   /**
   * Returns the number of rows displayed (that is, "visible rows") in the RowSet
   * browser.
   * @return number of rows displayed in the RowSet browser.
   */
   public int getVisibleRows()
   {
      return nVisibleRows;
   }

   public void setDepthLevel(int nLevel)
   {
      nDepthLevel = nLevel;
   }

   public int getDepthLevel()
   {
      return nDepthLevel;
   }

   public void setAttributeForLabel(String attr)
   {
      if (nodeLabel == null)
      {
         nodeLabel = new Vector();
      }
      else
      {
         nodeLabel.removeAllElements();
      }
      
      nodeLabel.addElement(attr);
   }

   public String getAttributeForLabel()
   {
      if (nodeLabel == null)
      {
         return null;
      }
      else
      {
         return (String) nodeLabel.elementAt(0);
      }
   }
   
   public void internalInitialize()
      throws Exception
   {
      super.internalInitialize();

      String treeName = getUniqueName("disptree");
      String dataName = getUniqueName("dstree");

      // Setup tree WebBean
      tree = new  oracle.jdeveloper.jsp.wb.JSTree(treeName);
      tree.initialize(page);
   
      tree.setDataSource(dataName);

      // Setup Data WebBean
      data = new oracle.jdeveloper.jsp.wb.JSTreeData(dataName);
      data.initialize(page);

      String  sValue = null;

      if (nodeLabel == null)
      {
         nodeLabel = new Vector();
      }

      RowSet rs = ds.getRowSet();
      if (nodeLabel.size() == 0)
      {
         AttributeDef[] dattrs =  getDisplayAttributeDefs();
         for (int attrNo = 0; attrNo < dattrs.length ; attrNo++)
         {
            if(!shouldDisplayAttribute(dattrs[attrNo]))
                    continue;

            nodeLabel.addElement(ds.getAttributeLabel(dattrs[attrNo]));
         }
      }

      Row masterRow = null;
      String vlNames[] = rs.getViewObject().getViewLinkNames();
      if (vlNames != null)
      {
         for (int i = 0; i < vlNames.length; i++)
         {
            ViewLink vl = getApplicationFromContext().findViewLink(vlNames[i]);

            if (vl == null)
               continue;

            String defName = vl.getSource().getDefName();

            // Detect if this link use our VO as a source and that it is a self join with an accessor
            if (defName.equals(rs.getViewObject().getDefName()) && defName.equals(vl.getDestination().getDefName()))
            {
               AttributeDef accessorDef = rs.getViewObject().findViewLinkAccessor(vl);
               if (accessorDef != null)
               {
                  accessorName = accessorDef.getName();

                  masterRow = rs.getCurrentRow();
                  if (masterRow == null)
                  {
                     masterRow = rs.first();
                  }
                  break;
               }
            }
         }
      }

      if (masterRow == null)
      {
         DHTMLRow row = new DHTMLRow();

         data.addRow(row);
         row.setText(Res.getString(Res.MSG_VO_NOT_SELF_REF));
      }
      else
      {
         buildChildrenData(masterRow, nDepthLevel);
      }
   }

   private void buildChildrenData(Row voRow, int level)
   {
      DHTMLRow row = new DHTMLRow();

      data.addRow(row);
      
      if (nodeLabel != null)
      {
         StringBuffer label = new StringBuffer();
         for (int i = 0; i < nodeLabel.size(); i++)
         {
            Object obj = voRow.getAttribute((String) nodeLabel.elementAt(i));
            label.append((obj != null) ? DHTMLElement.filterDataChar(obj.toString()) : "");
            label.append(" ");
         }
      
         row.setText(label.toString());
      }
      
      
      if (level == 0)
      {
         return;
      }
      
      RowSet rs = (RowSet) voRow.getAttribute(accessorName);
      if (rs == null)
      {
         return;
      }
      
      rs.setRangeSize(nVisibleRows);
   
      Row[]   drows = rs.getAllRowsInRange();

      if (drows.length > 0)
      {
         row.setChildCount(drows.length);
         row.setPopulated(true);
         row.setState("open");
      
         for (int rowno = 0; rowno < drows.length; rowno++)
         {
            buildChildrenData(drows[rowno], level - 1);
         }
      }
   }
   
   public void render()
      throws Exception
   {
      // Specify the library here instead of having the WebBean do it because the order is important
      initBeanForJS(WebBean.JSTreeConstructLib | WebBean.JSDataConstructLib);
      data.render();         
      tree.render();         
      releaseApplicationResources();
   }
}


