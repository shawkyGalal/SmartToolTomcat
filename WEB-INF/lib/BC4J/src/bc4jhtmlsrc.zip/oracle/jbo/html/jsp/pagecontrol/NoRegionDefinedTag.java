package oracle.jbo.html.jsp.pagecontrol;
import javax.servlet.jsp.tagext.BodyTagSupport;
import javax.servlet.jsp.tagext.BodyContent;
import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspTagException;
import javax.servlet.jsp.JspWriter;

public class NoRegionDefinedTag extends BodyTagSupport 
{

  /**
   * Method called at start of tag.
   * @return EVAL_BODY_TAG
   */
  public int doStartTag() throws JspException
  {
    try
    {
       String sRegion = pageContext.getRequest().getParameter("updateRegion");
       if(sRegion != null)
        return SKIP_BODY;
    }
    catch(Exception e)
    {
      e.printStackTrace();
    }

    return BodyTagSupport.EVAL_BODY_AGAIN;
  }


  /**
   * Method called at end of tag.
   * @return EVAL_PAGE
   */
  public int doEndTag()
  {
    return EVAL_PAGE;
  }


  /**
   * Method is invoked after every body evaluation to control whether the body will be reevaluated or not.
   * @return SKIP_BODY
   */
  public int doAfterBody() throws JspException
  {
    try
    {
        JspWriter out = getPreviousOut();
        BodyContent bodyContent = getBodyContent();
        bodyContent.writeOut(out);
    }
    catch(Exception e)
    {
      throw new JspTagException(e.getMessage());
    }

    return SKIP_BODY;
  }
}