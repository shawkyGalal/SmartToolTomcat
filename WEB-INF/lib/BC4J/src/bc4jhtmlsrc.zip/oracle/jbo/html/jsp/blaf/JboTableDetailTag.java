/*
 * @(#)JboTableDetailTag.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.html.jsp.blaf;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.tagext.TagSupport;
import oracle.cabo.ui.jsps.tags.DetailTag;
import oracle.cabo.ui.beans.table.TableBean;
import oracle.jbo.html.DataSource;
import oracle.jbo.html.jsp.datatags.Utils;
import javax.servlet.jsp.PageContext;
import oracle.cabo.ui.UINode;
import oracle.cabo.ui.beans.layout.FlowLayoutBean;

public class JboTableDetailTag extends DetailTag 
{
  FlowLayoutBean _flowLayout = null;
  
  public JboTableDetailTag()
  {
  }
  
  public int doEndTag() throws JspException
  {
      // find the datasource from the parent table
      // the parent table should allways be a JboTable
      try
      {
         JboTableTag parent = (JboTableTag)TagSupport.findAncestorWithClass(this, JboTableTag.class);

         if(parent != null)
         {
            TableBean table = (TableBean)parent.getUINode();

            // setup the datasource class for the Show/Hide values
            DataSource dataSource = Utils.getDataSourceFromContext(getPageContext(), parent.getDataSource());
            
            table.setDetailDisclosure(new RowSetDataObjectList(getPageContext(), dataSource)); 

            JboUtil.setupHideShowFromRequest(getPageContext(), parent.getDataSource(), dataSource.getRowSet());
         }
      }
      catch(Exception ex)
      {
         throw new JspException(ex.getLocalizedMessage());            
      }
      return  super.doEndTag();//Tag.EVAL_PAGE;
  }

   protected PageContext getPageContext()
   {
      // TODO:  Override this oracle.cabo.ui.jsps.tags.BaseTag method
      return super.getPageContext();
   }

  public void addNode(UINode node) throws JspException
  {
    if(_flowLayout == null)
    {
      _flowLayout = new FlowLayoutBean();  
      super.addNode(_flowLayout);
    }
    
    _flowLayout.addIndexedChild(node);   
  }

  public void release()
  {
    _flowLayout = null;
    super.release();
  }
  
   

}