/*
 * @(#)ShowValueTag.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.html.jsp.datatags;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspTagException;
import javax.servlet.jsp.tagext.Tag;
import oracle.jbo.JboException;

public class ShowValueTag extends DataTagBase
{
   public static final String UI_ROWKEY = "Rowkey";

   protected void initializeAttributeDef()
   {
      // Special handling of ROWKEY as the dataitem
      if (!UI_ROWKEY.equalsIgnoreCase(sDataItem))
      {
         super.initializeAttributeDef();
      }
   }
   
   /**
     * Process the start tag for this instance.
     *
     * The doStartTag() method assumes that all setter methods have been
     * invoked before.
     *
     * When this method is invoked, the body has not yet been invoked.
     *
     * @returns EVAL_BODY_INCLUDE if the tag wants to process body, SKIP_BODY if it
     * does ont want to process it.
     */
   public int doStartTag() throws JspException
   {
      internalInitialize();
      
      if (row != null)
      {
         Object obj = null;
         int nDotIndex;
         
         if (sDataItem == null)
         {
            if (attrDef != null)
            {
               obj = row.getAttribute(attrDef.getIndex());
            }
            else
            {
               throw new JboException(Res.getString(Res.SHOWVALUE_NO_DATAITEM));
            }
         }
         else if (UI_ROWKEY.equalsIgnoreCase(sDataItem))
         {
            obj = row.getKey().toStringFormat(true);
         }
         else if (attrList != null)
         {
            obj = attrList.getAttribute(sSubAttrName);
         }
         else
         {
            obj = row.getAttribute(sDataItem);
         }
         
         try
         {
            if (obj != null)
            {
               pageContext.getOut().print(obj.toString());
            }
         }
         catch (java.io.IOException ex)
         {
            pageContext.getServletContext().log(Res.getString(Res.IO_ERROR), ex);
            throw new JspTagException(ex.getMessage());
         }
      }
      
      return Tag.SKIP_BODY;
   }
}

