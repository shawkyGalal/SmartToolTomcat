/*
 * @(#)HDHatClass.java
 *
 * Copyright 1999-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.html.htmldrv;

import java.io.*;
import java.net.*;
import java.util.*;
import oracle.jbo.common.JboNameUtil;
import oracle.jbo.html.*;
import oracle.jdeveloper.html.parser.*;

public class HDHatClass extends HDCmdBlock
{
   private Vector classNames = new Vector();
   private Vector classInsts = null;

   private String httpBase = "http://sim-pc2:7000/";

   private boolean includeWeak = false;

   public static void main(String argv[])
   {
      try
      {
         HDHatClass hdHatCls = new HDHatClass();

         hdHatCls.procArgs(argv);
         hdHatCls.run();
      }
      catch(Exception ex)
      {
         ex.printStackTrace();
         System.exit(1);
      }
   }
   
   
   public void procArgs(String argv[])
      throws Exception
   {
      for (int j = 0; j < argv.length; j++)
      {
         if (argv[j].equals("-http"))
         {
            httpBase = argv[++j];
         }
         else  if (argv[j].equals("-iw"))
         {
            includeWeak = true;
         }
         else
         {
            classNames.addElement(argv[j]);
         }
      }
   }
   
   
   public void run() throws IOException
   {
      setLine("quiet");
      parseCommand();

      procClasses();
   }
   
   
   public void procClasses() throws IOException
   {
      for (int j = 0; j < classNames.size(); j++)
      {
         procClass((String) classNames.elementAt(j));
      }
   }
   
   
   public void procClass(String clsName) throws IOException
   {
      classInsts = new Vector();
      
      setLine("get \"" + httpBase + "allInstances/" + clsName + "\"");
      parseCommand();
      
      setLine("parse");
      parseCommand();

      setLine("iterate iterInst");
      parseCommand();
      
      HDIterator iterInst = (HDIterator) getVariableVal("iterInst");
      IHTMLParserNode node;
      
      while ((node = iterInst.next()) != null)
      {
         if (node.getNodeTag() != null && node.getNodeTag().equals("a"))
         {
            if (node.getAttributes() != null)
            {
               String str = (String) node.getAttributes().get("href");
               String linkStr = str.substring(1, str.length() - 1);

               // System.out.println("Found: " + linkStr);
               
               String leadPattern = "../object/";
               
               if (linkStr.startsWith(leadPattern))
               {
                  String objId = linkStr.substring(leadPattern.length());

                  classInsts.addElement(objId);
               }
            }
         }
      }

      removeVariable("iterInst");

      setLine("delete");
      parseCommand();

      System.out.println("Class: " + clsName + "  #Inst: " + classInsts.size());
      
      for (int j = 0; j < classInsts.size(); j++)
      {
         procInstance((String) classInsts.elementAt(j));
      }
   }
   
   
   public String getNodeTextRaw(IHTMLParserNode nd)
   {
      if (nd.getNodeTag() != null && nd.getNodeTag().equals("a"))
      {
         if (nd.getAttributes() != null)
         {
            String str = (String) nd.getAttributes().get("href");
            String linkStr = str.substring(1, str.length() - 1);
            
            return linkStr;
         }
         
         return null;
      }
      else
      {
         Vector toks = nd.getTokens();
         String retVal = "";

         for (int j = 0; j < toks.size(); j++)
         {
            retVal += (String) toks.elementAt(j);
         }
      
         return retVal;
      }
   }
   
   
   public String getNodeText(IHTMLParserNode nd)
   {
      String txt = getNodeTextRaw(nd);
      
      if (txt != null)
      {
         txt = txt.replace('\n', ' ');
         txt = txt.replace('\r', ' ');

         if (txt.startsWith("> "))
         {
            txt = txt.substring(2);
         }
         
         if (txt.trim().length() == 0 || txt.equals(">"))
         {
            return null;
         }
      }
      
      return txt;
   }
   
   
   public void endMarker() throws IOException
   {
      System.out.println("      -------------------------------");
   }
   
   
   public void procInstance(String objId) throws IOException
   {
      System.out.println("   Inst " + objId);

      if (!includeWeak)
      {
         setLine("get \"" + httpBase + "roots/" + objId + "\"");
      }
      else
      {
         setLine("get \"" + httpBase + "allRoots/" + objId + "\"");
      }
      
      parseCommand();
      
      setLine("parse");
      parseCommand();

      setLine("iterate iterRoot");
      parseCommand();
      
      HDIterator iterRoot = (HDIterator) getVariableVal("iterRoot");
      IHTMLParserNode node;
      
      boolean foundRootStack = false;
      boolean foundGT = false;
      boolean foundObject = false;
      boolean lookingForField = false;
      
      while ((node = iterRoot.next()) != null)
      {
         String txt = getNodeText(node);
         
         if (txt != null)
         {
            txt = txt.trim();

            // System.out.println("      $$$ [" + txt + "]");
            
            if (txt.startsWith("../rootStack") ||
                txt.startsWith("Static reference from") ||
                txt.equals("System Class Reference :"))
            {
               if (lookingForField)
               {
                  System.out.println("");  // No field
                  endMarker();
               }

               if (txt.startsWith("../rootStack"))
               {
                  System.out.println("      $$$$$ JNI Local Reference $$$$$");
               }
               else  if (txt.startsWith("Static reference from"))
               {
                  System.out.println("      $$$$$ " + txt + " $$$$$");
               }
               else  if (txt.equals("System Class Reference :"))
               {
                  System.out.println("      $$$$$ " + txt + " $$$$$");
               }

               foundRootStack = true;
               foundGT = false;
               foundObject = false;
               lookingForField = false;
            }
            else  if (foundRootStack)
            {
               if (txt.equals("--&gt;"))
               {
                  if (lookingForField)
                  {
                     System.out.println("");  // No field
                     endMarker();
                     lookingForField = false;
                  }

                  foundGT = true;
                  foundObject = false;
               }
               else  if (foundGT)
               {
                  if (!foundObject)
                  {
                     if (txt.startsWith("../object/"))
                     {
                        foundObject = true;
                     }
                  }
                  else
                  {
                     if (lookingForField)
                     {
                        if (txt.startsWith("("))
                        {
                           System.out.println(" " + txt);
                           foundObject = false;
                           lookingForField = false;
                        }
                     }
                     else
                     {
                        System.out.print("      " + txt);
                        lookingForField = true;
                     }
                  }
               }
            }
            
            // System.out.println("rs " + foundRootStack + ", gt " + foundGT +
            //                    ", obj " + foundObject + ", fld " + lookingForField);
            // System.out.print("--"); System.out.flush();
            // System.in.read();
         }
      }
         
      if (lookingForField)
      {
         System.out.println("");  // No field
         endMarker();
      }

      removeVariable("iterRoot");

      setLine("delete");
      parseCommand();
   }
   
   
   public String buildDispString(String s, int dispLen, boolean leftJust)
   {
      if (s.length() >= dispLen)
      {
         return s;
      }
      else
      {
         for (int j = s.length(); j < dispLen; j++)
         {
            if (leftJust)
            {
               s = s + " ";
            }
            else
            {
               s = " " + s;
            }
         }
         
         return s;
      }
   }
   
   
   public boolean readLine() throws IOException
   {
      return getLine() != null;
   }
}
