/*
 * @(#)IHTMLParserNode.java
 *
 * Copyright 1999-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.html.htmldrv;

import java.io.*;
import java.util.*;

/**
 *
 * @version INTERNAL
 */
public interface IHTMLParserNode
{
      public String           getNodeLabel();
      public Vector           getChildNodes();
      public int              getChildCount();      
      public Hashtable        getAttributes();
      public Vector           getTokens();      
      public IHTMLParserNode  getParent();
      public void             replaceChild(IHTMLParserNode oldNode, IHTMLParserNode newNode);
      public void             removeNodeFromParent();
      public void             setParent(IHTMLParserNode newparent);
      public void             addUserObject(String sName, Object obj);
      public Object           getUserObject(String sName);
      public String           getNodeTag();
      public void             setNodeTag(String sTag);
      public String           getNodeEndTag();
      public void             setNodeEndTag(String sTag);      
      public void             addChildNode(IHTMLParserNode grp);
      public void             addToken(HTMLTokenizer tokens);
      public void             addToken(String sval);
      public void             addTagAttribute(String sName , String sval);
      public void             parseTagAttributes(String sval);      
      public void             populateWriter(PrintWriter out) throws Exception;
      public boolean          traverse(IHTMLNodeVisitor visitor);
}