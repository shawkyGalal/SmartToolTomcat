/*
 * @(#)ShowHintTag.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.html.jsp.datatags;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspTagException;
import javax.servlet.jsp.tagext.Tag;
import oracle.jbo.AttributeDef;
import oracle.jbo.AttributeHints;
import oracle.jbo.LocaleContext;

public class ShowHintTag extends ShowTagBase
{
   protected String hintName; // required attribute

   public void setHintname(String newHintName)
   {
      hintName = newHintName;
   }
   
   public int doStartTag() throws JspException
   {
      final AttributeDef   attrDef = getAttributeDef();
      String         output = null;
      final LocaleContext  locale = ds.getApplicationModule().getSession().getLocaleContext();

      // Backward compatible with 3.2. The label can be store on the ViewObject.
      if (hintName.equals(AttributeHints.ATTRIBUTE_LABEL))
      {
         output = attrDef.getUIHelper().getLabel(locale);
      }
      else
      {
         output = attrDef.getUIHelper().getHint(locale, hintName);
      }
      
      try
      {
         pageContext.getOut().print(output);
      }
      catch (java.io.IOException ex)
      {
         pageContext.getServletContext().log(Res.getString(Res.IO_ERROR), ex);
         throw new JspTagException(ex.getMessage());
      }

      return Tag.SKIP_BODY;
   }

}

