/*
 * @(#)BC4JContext.java
 *
 * Copyright 2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.html;

import javax.servlet.ServletRequest;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import java.util.HashMap;

import oracle.jbo.client.JboUtil;
import oracle.jbo.ApplicationModule;
import oracle.jbo.ViewObject;
import oracle.jbo.Row;
import oracle.jbo.common.ampool.SessionCookie;
import oracle.jbo.http.HttpContainer;
import oracle.jbo.html.jsp.datatags.DataTagBase;
import oracle.jbo.html.jsp.datatags.OnEventTag;
import oracle.jbo.JboException;

/**
 * <p><strong>BC4JContext</strong> define a set of method a BC4J Web application use to access attributes
 * of the binding to the current BC4J model.</p>
 * <p>There is one <code>BC4JContext</code> per request and it can be retrieve from the request using
 * the {@link BC4JContext#getContext getContext} method.</p>
 *
 * <p>For a BC4J Web application using Struts, the <code>BC4JContext</code> is initialized
 * by the {@link oracle.jbo.html.struts11.BC4JRequestProcessor BC4JRequestProcessor} and 
 * the {@link oracle.jbo.html.struts11.BC4JActionMapping BC4JActionMapping} classes.</p>
 *
 * @author Charles Gayraud
 * @since JDeveloper 9.0.3
 */

public class BC4JContext 
{
   /**
    * The request attributes key under which our <code>BC4JContext</code> instance
    * will be stored.
    * @see BC4JContext#getContext(ServletRequest request)
    * @see BC4JContext#getContext(HttpServletRequest request)
    */
   public static final String ContextAttrName = "BC4JContext";
   
   private SessionCookie      cookie;
   private String             event;
   private ViewObject         vo;
   private String             rowkey;
   private Row                row;
   private String             previousPath;
   private String             currentPath;
   private HashMap            properties;

   public BC4JContext()
   {
   }

   /**
    * Initialize the content the of the context using a request and response object.
    * This method look for specific request parameters and initialize the <code>BC4JContext</code> given their values.
    * 
    * <ul>
    * <li><strong>event</strong> property is initialized using the {@link oracle.jbo.html.jsp.datatags.OnEventTag#JBOEVENT JBOEVENT} ("jboEvent") parameter key.</li>
    * <li><strong>sessionCookie</strong> property is initialized using "amId" parameter key.</li>
    * <li><strong>viewObject</strong> property is initialized by calling the {@link oracle.jbo.ApplicationModule#findViewObject(String) findViewObject} method
    * using the {@link oracle.jbo.html.jsp.datatags.OnEventTag#JBOEVENTVO JBOEVENTVO} ("jboEventVO") parameter key.</li>
    * <li><strong>rowkey</strong> property is initialized using the {@link oracle.jbo.html.jsp.datatags.DataTagBase#ROWKEY_PARAM ROWKEY_PARAM} ("jboRowKey") parameter key.</li>
    * <li><strong>previousPath</strong> property is initialized using the "currentPath" parameter key.
    * "currentPath" for the previousrequest is the previousPath for this current request.</li>
    * </ul>
    *
    */
   public void initialize(HttpServletRequest request, HttpServletResponse response)
   {
      if (getEvent() == null)
      {
         setEvent(request.getParameter(OnEventTag.JBOEVENT));
      }
      
      if (getSessionCookie() == null)
      {
         String amId = resolve(request.getParameter("amId"));
         if (amId != null)
         {
            HttpContainer container = HttpContainer.getInstanceFromSession(request.getSession());
            setSessionCookie(container.getSessionCookie(amId));
            if (getSessionCookie() == null)
            {
               throw new JboException(Res.format(Res.COOKIE_NOT_FOUND, amId));
            }
         }
      }

      if (getViewObject() == null)
      {
         String sViewObject = resolve(request.getParameter(OnEventTag.JBOEVENTVO));
         if (sViewObject != null)
         {
            setViewObject(getApplicationModule().findViewObject(sViewObject));
         }
      }

      String rk = resolve(request.getParameter(DataTagBase.ROWKEY_PARAM));
      setRowkey(rk);

      // Current path becomes previous path
      setPreviousPath(request.getParameter("currentPath"));

      // and current path is re-initialized
      setCurrentPath(request.getServletPath());
   }

   /**
    * Return our <code>BC4JContext</code> given a ServletRequest
    *
    * @param request the current request
    * @see BC4JContext#ContextAttrName
    */
   public static final BC4JContext getContext(ServletRequest request)
   {
      return (BC4JContext) request.getAttribute(BC4JContext.ContextAttrName);
   }

   /**
    * Return our <code>BC4JContext</code> given a HttpServletRequest
    *
    * @param request the current request
    * @see BC4JContext#ContextAttrName
    */
   public static final BC4JContext getContext(HttpServletRequest request)
   {
      return getContext((ServletRequest)request);
   }
   
   /**
    * Returns an application module instance from the sessionCookie
    * @see oracle.jbo.common.ampool.ApplicationModuleRef.useApplicationModule()
    */
   public ApplicationModule getApplicationModule()
   {
      if (cookie != null)
      {
         return cookie.useApplicationModule();
      }

      return null;
   }

   /**
    * Set the viewObject property value.
    * This will overwrite the value set by the {@link BC4JContext#initialize(HttpServletRequest, HttpServletResponse) initialize} method.
    */
   public void setViewObject(ViewObject vo)
   {
      this.vo = vo;
   }

   /**
    * Returns the viewObject property.
    */
   public ViewObject getViewObject()
   {
      return vo;
   }

   /**
    * Set the event property value.
    * This will overwrite the value set by the {@link BC4JContext#initialize(HttpServletRequest, HttpServletResponse) initialize} method.
    */
   public void setEvent(String event)
   {
      this.event = resolve(event);
   }

   /**
    * Returns the event property.
    */
   public String getEvent()
   {
      return event;
   }

   /**
    * Set the rowkey property value.
    * This will overwrite the value set by the {@link BC4JContext#initialize(HttpServletRequest, HttpServletResponse) initialize} method.
    */
   public void setRowkey(String rowkey)
   {
      this.rowkey = rowkey;
   }

   /**
    * Return the rowkey property.
    */
   public String getRowkey()
   {
      return rowkey;
   }

   /**
    * Return the sessionCookie property.
    */
   public SessionCookie getSessionCookie()
   {
      return cookie;
   }

   /**
    * Set the sessionCookie property value.
    * This will overwrite the value set by the {@link BC4JContext#initialize(HttpServletRequest, HttpServletResponse) initialize} method.
    */
   public void setSessionCookie(SessionCookie cookie)
   {
      this.cookie = cookie;
   }

   /**
    * Set the previous servlet path.
    */
   public void setPreviousPath(String value)
   {
      this.previousPath = resolve(value);
   }

   /**
    * Return the previous servlet path. (servlet path of the previous request)
    */
   public String getPreviousPath()
   {
      return previousPath;
   }

   /**
    * Set the current servlet path.
    */
   public void setCurrentPath(String value)
   {
      this.currentPath = resolve(value);
   }

   /**
    * Return the current servlet path.
    * @see javax.servlet.http.HttpServletRequest#getServletPath()
    */
   public String getCurrentPath()
   {
      return currentPath;
   }
   
   /**
    * Used to store custom properties in the <code>BC4JContext</code>
    */
   public void setProperty(String key, String value)
   {
      value = resolve(value);

      if (properties == null && value != null)
      {
         properties = new HashMap(20);
      }

      properties.put(key, value);
   }

   /**
    * Used to retrieve custom properties from the <code>BC4JContext</code>
    */
   public String getProperty(String key)
   {
      if (properties == null)
      {
         return null;
      }

      return (String) properties.get(key);
   }
   
   /**
    * Set the row property value
    */
   public void setRow(Row row)
   {
      this.row = row;
   }

   /**
    * Retrieve the row property value
    *
    * If the row has not been set explicitly, this method use the rowkey information
    * from this <code>BC4JContext</code> to retrieve the row.
    *
    * @see oracle.jbo.client.JboUtil#getRowFromKey(RowSet, String)
    */
   public Row getRow()
   {
      if (row == null)
      {
         row = JboUtil.getRowFromKey(getViewObject(), getRowkey());
         if (row == null)
         {
            throw new JboException(Res.format(Res.CANT_FIND_ROW_WITH_ROWKEY, getRowkey()));
         }
      }

      return row;
   }
   
   private final String resolve(String value)
   {
      if (value != null)
      {
         value = value.trim();
         if (value.length() == 0)
         {
            return null;
         }
      }

      return value;
   }

}