/*
 * @(#)HTMLHandlerFactory.java
 *
 * Copyright 1999-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.html.htmldrv;

import java.util.*;

/**
 *
 * @version INTERNAL
 */
class HTMLHandlerFactory
{
  static METAHandler  hMeta  = new METAHandler();
  static TABLEHandler hTable = new TABLEHandler();
  static IMGHandler   hImage = new IMGHandler();
  static TDHandler    hTd    = new TDHandler();
  static AHandler     hA     = new AHandler();
  static INPUTHandler hInput = new INPUTHandler();
  static FORMHandler  hForm  = new FORMHandler();
  static DEFAULTHandler hDefault = new DEFAULTHandler();
  static FONTHandler  hFont = new FONTHandler();
  static COMMENTHandler hComment = new COMMENTHandler();
  static SINGLEHandler  hSingle  = new SINGLEHandler();
  
  public HTMLHandlerFactory()
  {
  }

  static IHTMLTagHandler getTagHandler(String sTag)
  {
       IHTMLTagHandler tHandler = null;

       if(sTag.equalsIgnoreCase("META"))
       {
          return hMeta;
       }

       if(sTag.equalsIgnoreCase("TABLE"))
       {
          return hTable;
       }

       if(sTag.equalsIgnoreCase("IMG"))
       {
          return hImage;
       }

       if(sTag.equalsIgnoreCase("TD"))
       {
          return hTd;
       }

       if(sTag.equalsIgnoreCase("A"))
       {
          return hA;
       }

       if(sTag.equalsIgnoreCase("INPUT"))
       {
          return hInput;
       }

       if(sTag.equalsIgnoreCase("FORM"))
       {
          return hForm;
       }

      /* this has an optional terminator */
       if(sTag.equalsIgnoreCase("FONT"))
       {
          return hFont;
       }

       if(sTag.equalsIgnoreCase("BR"))
       {
          hSingle.setTag(sTag);
          return hSingle;
       }       
      
       if(sTag.equalsIgnoreCase("P"))
       {
          hSingle.setTag(sTag);
          return hSingle;
       }
	   
       if(sTag.equalsIgnoreCase("CENTER"))
       {
          hSingle.setTag(sTag);
          return hSingle;
       }
	   
	   if(sTag.equalsIgnoreCase("HR"))
       {
          hSingle.setTag(sTag);          
          return hSingle;
       }
       
       if(sTag.equalsIgnoreCase("!"))
       {
          return hComment;
       }

       sTag.trim();
       
       hDefault.setTag(null);
       
       if(sTag != null && sTag.length() > 0)
               hDefault.setTag(sTag);
       
       tHandler = hDefault;

       return tHandler;
  }
}

class FORMHandler implements  IHTMLTagHandler
{
  public IHTMLParserNode createTagNode(HTMLParser parser, HTMLTokenizer tokens , IHTMLParserNode tkParentGroup)
  {
    try
    {
       int nToken = 0;
       String sAttributes = "";
       
       HTMLBaseNode tkHTMLNode = new HTMLBaseNode(tokens, tkParentGroup);
       
       tkHTMLNode.setNodeTag(tokens.sval);
       tkHTMLNode.setNodeEndTag(tokens.sval);
       
       nToken = tokens.nextToken();

       while(nToken != '>')
       {
         sAttributes += tokens.sval;
         nToken = tokens.nextToken();
       }

       tkHTMLNode.parseTagAttributes(sAttributes);
       
       parser.processTokens(tokens , tkHTMLNode, "FORM");



       return tkHTMLNode;
    }
    catch(Exception ex)
    {
     ex.printStackTrace();
    }
    return null;
  }
}

class INPUTHandler implements  IHTMLTagHandler
{
  public IHTMLParserNode createTagNode(HTMLParser parser, HTMLTokenizer tokens , IHTMLParserNode tkParentGroup)
  {
    try
    {
       int nToken = 0;
       String sAttributes = "";
       
       HTMLBaseNode tkHTMLNode = new HTMLBaseNode(tokens, tkParentGroup);
       tkHTMLNode.setNodeTag("INPUT");
       tkHTMLNode.setNodeEndTag(">");

       nToken = tokens.nextToken();
         
       while(nToken != '>')
       {
         sAttributes += tokens.sval;
         nToken = tokens.nextToken();
       }

       tkHTMLNode.parseTagAttributes(sAttributes);
       
       return tkHTMLNode;
    }
    catch(Exception ex)
    {
     ex.printStackTrace();
    }
    return null;
  }
}

class IMGHandler implements  IHTMLTagHandler
{
  public IHTMLParserNode createTagNode(HTMLParser parser, HTMLTokenizer tokens , IHTMLParserNode tkParentGroup)
  {
    try
    {
       int nToken = 0;
       String sAttributes = "";
       
       HTMLBaseNode tkHTMLNode = new HTMLBaseNode(tokens, tkParentGroup);
       tkHTMLNode.setNodeTag("IMG");
       //tkHTMLNode.setNodeEndTag(">");
       tkHTMLNode.setNodeEndTag(null);

       nToken = tokens.nextToken();
         
       while(nToken != '>')
       {
         sAttributes += tokens.sval;
         nToken = tokens.nextToken();
       }

       tkHTMLNode.parseTagAttributes(sAttributes);
       
       nToken = tokens.nextToken();

       return tkHTMLNode;
    }
    catch(Exception ex)
    {
     ex.printStackTrace();
    }
    return null;
  }
}

class TDHandler implements  IHTMLTagHandler
{
  public IHTMLParserNode createTagNode(HTMLParser parser, HTMLTokenizer tokens , IHTMLParserNode tkParentGroup)
  {
    try
    {
       int     nToken = 0;
       String  sAttributes = "";
       
       HTMLBaseNode tkHTMLNode = new HTMLBaseNode(tokens, tkParentGroup);
       tkHTMLNode.setNodeTag(tokens.sval);
       tkHTMLNode.setNodeEndTag(tokens.sval);
       
       nToken = tokens.nextToken();
       
       while(nToken != '>')
       {
         sAttributes += tokens.sval;
         nToken = tokens.nextToken();
       }

       tkHTMLNode.parseTagAttributes(sAttributes);
       
       parser.processTokens(tokens , tkHTMLNode, "TD");

       tokens.nextToken();

       return tkHTMLNode;
    }
    catch(Exception ex)
    {
     ex.printStackTrace();
    }
    return null;
  }
}

class METAHandler implements  IHTMLTagHandler
{
  public IHTMLParserNode createTagNode(HTMLParser parser, HTMLTokenizer tokens , IHTMLParserNode tkParentGroup)
  {
    try
    {
       int     nToken = tokens.nextToken();
       String  sAttributes = "";
       
       HTMLBaseNode tkHTMLNode = new HTMLBaseNode(tokens, tkParentGroup);
       tkHTMLNode.setNodeTag("META");
       tkHTMLNode.setNodeEndTag(">");

       while(nToken != '>')
       {
         sAttributes += tokens.sval;
         nToken = tokens.nextToken();
       }

       tkHTMLNode.parseTagAttributes(sAttributes);
       
       return tkHTMLNode;
    }
    catch(Exception ex)
    {
     ex.printStackTrace();
    }
    return null;
  }
}

class COMMENTHandler implements  IHTMLTagHandler
{
  public IHTMLParserNode createTagNode(HTMLParser parser, HTMLTokenizer tokens , IHTMLParserNode tkParentGroup)
  {
    try
    {
       //int nToken = tokens.nextToken();
       Vector     tokenlist = new Vector();

       HTMLBaseNode tkHTMLNode;

       // get the comment text line
       int nToken = tokens.nextToken();
       StringBuffer sBuffer = new StringBuffer();

       while(nToken != '>')
       {
         if(tokens.ttype == tokens.TT_STARTJBOTAG)
         {
            String sTagName;
            
            //skip to the tag name
            nToken = tokens.nextToken();
            sTagName = tokens.sval;

            nToken = tokens.nextToken();
            
            // clear the buffer and add the rest of the tag to it
            sBuffer.setLength(0);
            while(tokens.ttype != tokens.TT_ENDJBOTAG)
            {
              sBuffer.append(tokens.sval);
              nToken = tokens.nextToken();
            }
            // dont add the terminating tag sBuffer.append(tokens.sval);

            // create the node for the comment tag
            JBOHTMLNode jboHTMLNode;


            jboHTMLNode = new JBOHTMLNode(tokens, tkParentGroup);
            
            jboHTMLNode.setGenerateCommentTags(true);
            jboHTMLNode.setNodeTag(sTagName);

            jboHTMLNode.addToken(sBuffer.toString());
       //     jboHTMLNode.addTagAttribute(sBuffer.toString());

            //skip until the next >
            while(nToken != '>')
               nToken = tokens.nextToken();

            if(sTagName.equalsIgnoreCase("For"))
            {
               jboHTMLNode.setGenerateForChildNodes(true);
               
               // we need to process the rest of the nodes until we find the
               // matching {%EndFor%}
               parser.processTokensUntilEndFor(tokens , jboHTMLNode);
            }
            return jboHTMLNode;
         }
         else
         {
             sBuffer.append(tokens.sval);
         }
         nToken = tokens.nextToken();
       }

       tkHTMLNode = new HTMLBaseNode(tokens, tkParentGroup);
       tkHTMLNode.setNodeTag("!");
       tkHTMLNode.addToken(sBuffer.toString());
       
       return tkHTMLNode;
    }
    catch(Exception ex)
    {
     ex.printStackTrace();
    }
    return null;
  }
}
class FONTHandler implements  IHTMLTagHandler
{
  public IHTMLParserNode createTagNode(HTMLParser parser, HTMLTokenizer tokens , IHTMLParserNode tkParentGroup)
  {
    try
    {
       int     nToken;
       String  sAttributes = "";
       
       HTMLBaseNode tkHTMLNode = new HTMLBaseNode(tokens, tkParentGroup);
       tkHTMLNode.setNodeTag(tokens.sval);
       tkHTMLNode.setNodeEndTag(tokens.sval);
       
       nToken = tokens.nextToken();

       while(nToken != '>')
       {
         sAttributes += tokens.sval;
         nToken = tokens.nextToken();
       }

       tkHTMLNode.parseTagAttributes(sAttributes);       

       return tkHTMLNode;
    }
    catch(Exception ex)
    {
     ex.printStackTrace();
    }
    return null;
  }
}
class AHandler implements  IHTMLTagHandler
{
  public IHTMLParserNode createTagNode(HTMLParser parser, HTMLTokenizer tokens , IHTMLParserNode tkParentGroup)
  {
    try
    {
       int     nToken = 0;
       String  sAttributes = "";
       
       HTMLBaseNode tkHTMLNode = new HTMLBaseNode(tokens, tkParentGroup);
       tkHTMLNode.setNodeTag(tokens.sval);
       tkHTMLNode.setNodeEndTag(tokens.sval);

       nToken = tokens.nextToken();
       
       while(nToken != '>')
       {
         sAttributes += tokens.sval;
         nToken = tokens.nextToken();
       }

       tkHTMLNode.parseTagAttributes(sAttributes);
       
       // get the anchor text
       HTMLBaseNode tkHTMLNodechild = new HTMLBaseNode(tokens, tkHTMLNode);

       nToken = tokens.nextToken();
       while(tokens.ttype != tokens.TT_ENDTAG)
       {
         tkHTMLNodechild.addToken(tokens);
         nToken = tokens.nextToken();
       }


       return tkHTMLNode;
    }
    catch(Exception ex)
    {
     ex.printStackTrace();
    }
    return null;
  }
}
class TABLEHandler implements  IHTMLTagHandler
{
  public IHTMLParserNode createTagNode(HTMLParser parser, HTMLTokenizer tokens , IHTMLParserNode tkParentGroup)
  {
    try
    {
       int     nToken = 0;
       String  sAttributes = "";
       
       HTMLBaseNode tkHTMLNode = new HTMLBaseNode(tokens, tkParentGroup);
       tkHTMLNode.setNodeTag(tokens.sval);
       tkHTMLNode.setNodeEndTag(tokens.sval);
       
       nToken = tokens.nextToken();

       while(nToken != '>')
       {
         sAttributes += tokens.sval;
         nToken = tokens.nextToken();
       }

       tkHTMLNode.parseTagAttributes(sAttributes);
       
       parser.processTokens(tokens , tkHTMLNode, "TABLE");

       tokens.nextToken();

       return tkHTMLNode;
    }
    catch(Exception ex)
    {
     ex.printStackTrace();
    }
    return null;
  }
}

class SINGLEHandler implements  IHTMLTagHandler
{
  String sTagName;



  public void setTag(String aTag)
  {
     if(aTag != null)
      sTagName = aTag.trim();
     else
      sTagName = null;
  }
  
  public IHTMLParserNode createTagNode(HTMLParser parser, HTMLTokenizer tokens , IHTMLParserNode tkParentGroup)
  {
    try
    {
       int     nToken = tokens.nextToken();
       String  sAttributes = "";
       
       HTMLBaseNode tkHTMLNode = new HTMLBaseNode(tokens, tkParentGroup);
       
       tkHTMLNode.setNodeTag(sTagName);

       tkHTMLNode.setNodeEndTag(null);       

       while(nToken != '>')
       {
         sAttributes += tokens.sval;
         nToken = tokens.nextToken();
       }

       tkHTMLNode.parseTagAttributes(sAttributes);
       
       return tkHTMLNode;
    }
    catch(Exception ex)
    {
     ex.printStackTrace();
    }
    return null;
  }
}

class DEFAULTHandler implements  IHTMLTagHandler
{
  String sTagName;



  public void setTag(String aTag)
  {
     if(aTag != null)
      sTagName = aTag.trim();
     else
      sTagName = null;
  }

  public IHTMLParserNode createTagNode(HTMLParser parser, HTMLTokenizer tokens , IHTMLParserNode tkParentGroup)
  {
    try
    {
       int     nToken = tokens.nextToken();
       String  sAttributes = "";
       
       HTMLBaseNode tkHTMLNode = new HTMLBaseNode(tokens, tkParentGroup);
       //tkHTMLNode.setNodeTag(sTagName);
       if(sTagName != null && sTagName.length() > 0)
       {
         tkHTMLNode.setNodeTag(sTagName);
         tkHTMLNode.setNodeEndTag(sTagName);
       }

       while(nToken != '>')
       {
         sAttributes += tokens.sval;
         nToken = tokens.nextToken();
       }

       tkHTMLNode.parseTagAttributes(sAttributes);
       
       parser.processTokens(tokens , tkHTMLNode, sTagName);

       //skip the terminating >
       tokens.nextToken();

       
       return tkHTMLNode;
    }
    catch(Exception ex)
    {
     ex.printStackTrace();
    }
     return null;
  }
}




