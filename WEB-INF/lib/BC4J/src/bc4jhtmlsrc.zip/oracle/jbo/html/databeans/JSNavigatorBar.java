/*
 * @(#)JSNavigatorBar.java
 *
 * Copyright 2000-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.html.databeans;

import java.util.Enumeration;
import oracle.jdeveloper.html.WebBean;

/**
 *
 *
 **/
public class JSNavigatorBar extends BaseNavigatorBar
{
   oracle.jdeveloper.jsp.wb.JSToolbar toolBar; // Aggregate JSToolbar
   
   public JSNavigatorBar()
   {
      this.setImageDir(WebBean.defaultCaboImageBase);
   }

   public oracle.jdeveloper.jsp.wb.JSToolbar getContainer()
   {
      return this.toolBar;
   }
   
   public void internalInitialize() throws Exception
   {
      super.internalInitialize();
      
      toolBar = new  oracle.jdeveloper.jsp.wb.JSToolbar(getUniqueName("tb"));
      toolBar.initialize(page);
   }
   
   public void populateToolBarFromCommands()
   {
      boolean isDividerButton = false;
      
      // setup the context
      buttons.setContext(this);

      Enumeration e = buttons.elements();

      while (e.hasMoreElements())
      {
         ToolBarButton button = (ToolBarButton) e.nextElement();

         if(!button.isButtonVisible())
               continue;

         if (button.getButtonType() == button.TYPE_DIVIDER)
         {
            if(!isDividerButton)
            {
               isDividerButton = true;
               toolBar.addDivider();
            }
         }
         else
         {
            isDividerButton = false;

            if (button.getCommandId() == this.NAVIGATE_DELETE)
            {
               toolBar.addDivider();
               toolBar.addTitle(ds.getViewObjectName());
               toolBar.addDivider();
            }
            
            toolBar.addButton(button, ImageDir);
         }
      }

   }

   /**
   * Renders the HTML toolbar on the JSP page.
   * This method is the main entry point where the rendering of the toolbar
   * actually happens.
   */
   public void render() throws Exception
   {
      super.render();
	   
      toolBar.render();
      releaseApplicationResources();
   }
}
