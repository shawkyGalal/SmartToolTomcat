/*
 * @(#)InputHiddenTag.java
 *
 * Copyright 2000-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.html.jsp.datatags;

import oracle.jdeveloper.html.HTMLFieldRenderer;
import oracle.jdeveloper.html.HiddenField;

public class InputHiddenTag extends InputTagBase
{
   public HTMLFieldRenderer getFieldRenderer()
   {
      final HTMLFieldRenderer rField = new HiddenField();

      initializeFieldRenderer(rField);

      return rField;
   }
}

