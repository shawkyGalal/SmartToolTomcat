/*
 * @(#)InputTextAreaTag.java
 *
 * Copyright 2000-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.html.jsp.datatags;

import javax.servlet.jsp.JspException;

import oracle.jdeveloper.html.HTMLFieldRenderer;
import oracle.jdeveloper.html.TextArea;

public class InputTextAreaTag extends InputTagBase
{
   protected int nRows = 0;

   public void setRows(String sRows)
      throws java.lang.NumberFormatException
   {
      nRows = Integer.parseInt(sRows);
   }

   public HTMLFieldRenderer getFieldRenderer()
   {
      final HTMLFieldRenderer rField = new TextArea();

      initializeFieldRenderer(rField);

      return rField;
   }

   public void internalInitialize()
   {
      super.internalInitialize();

      if (nRows > 0)
         rndObj.setDisplayHeight(nRows);
   }

   public int doEndTag() throws JspException
   {
      nRows = 0;
      return super.doEndTag();
   }

}

