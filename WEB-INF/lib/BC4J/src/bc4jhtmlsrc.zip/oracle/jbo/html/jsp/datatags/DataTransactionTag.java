/*
 * @(#)DataTransactionTag.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.html.jsp.datatags;

import javax.servlet.http.HttpServletRequest;
import oracle.jbo.html.BC4JContext;

/**
 */
public class DataTransactionTag extends ComponentTag
{
   public static final String defaultUrl = "DataTransactionComponent.jsp";
   public static final String paramNames[] = new String[]{ "amId", "targetURL" };
   protected String  sAppModuleId;
   protected String  sTargetUrl;
   
   public DataTransactionTag()
   {
      super();
   }

   protected void reset()
   {
      sRelativeUrlPath = defaultUrl;
      sTargetUrl = null;
   }

   public void setAppid(String sValue)
   {
      this.sAppModuleId = sValue;
   }

   public void setTargetURL(String sValue)
   {
      this.sTargetUrl = sValue;
   }
   
   public String getUrl()
   {
      // If the target url is not specify, we use self.
      if (sTargetUrl == null)
      {
         // If we are using Struts, the default page is '/transaction.do'
         BC4JContext bc4jContext = null;
         Object contextObject = pageContext.getRequest().getAttribute(BC4JContext.ContextAttrName);
         // Only do the casting if object is found
         if (contextObject != null)
         {
            bc4jContext = (BC4JContext) contextObject;
         }
         
         if (bc4jContext != null)
         {
            sTargetUrl = "/transaction.do";
         }
         else
         {
            HttpServletRequest request = (HttpServletRequest) pageContext.getRequest();
            sTargetUrl = request.getRequestURI();
         }
      }


      return buildUrl(sRelativeUrlPath, paramNames, new String[]{ sAppModuleId, sTargetUrl});
   }
}
