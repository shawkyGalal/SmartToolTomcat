/*
 * @(#)ViewCriteriaTagTEI.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.html.jsp.datatags;

import javax.servlet.jsp.tagext.TagData;
import javax.servlet.jsp.tagext.TagExtraInfo;
import javax.servlet.jsp.tagext.VariableInfo;

public class ViewCriteriaTagTEI extends TagExtraInfo
{

   public ViewCriteriaTagTEI()
   {
   }

   /**
   * information on scripting variables defined by this tag
   *
   * @param data The translation-time TagData instance.
   */
   public VariableInfo[] getVariableInfo(TagData data)
   {
      return new VariableInfo[]
      {
         new VariableInfo(data.getAttributeString("id"), "oracle.jbo.ViewCriteria", true, VariableInfo.NESTED)
      };
   }

}

