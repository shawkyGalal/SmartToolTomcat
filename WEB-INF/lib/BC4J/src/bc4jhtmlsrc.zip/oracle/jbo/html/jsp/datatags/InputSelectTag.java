/*
 * @(#)InputSelectTag.java
 *
 * Copyright 2000-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.html.jsp.datatags;

import javax.servlet.jsp.JspException;

public class InputSelectTag extends InputSelectBase
{
   public InputSelectTag()
   {
      // execute super first because sControlType default value
      // need to be overwritten
      super();
      reset();
   }

   public void setMultiple(String sValue)
   {
      if (Utils.isTrue(sValue))
      {
         sControlType = "LISTBOX";
      }
      else
      {
         sControlType = "COMBOBOX";
      }
   }

   public int doEndTag() throws JspException
   {
      final int ret = super.doEndTag();
      
      reset();
      
      return ret;
   }
   
   private void reset()
   {
      sControlType = "COMBOBOX";
   }
}

 