/*
 * @(#)ApplicationPoolImpl.java
 *
 * Copyright 2000-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.common.ampool;

import oracle.jbo.pool.ResourcePoolStatistics;
import oracle.jbo.pool.AgeHistogram;

/**
 *  A structure for ApplicationPool statistics.
 */
public class Statistics extends ResourcePoolStatistics
{
   // Transactional state statistics
   public long mNumOfStateActivations = 0;
   public long mNumOfStatePassivations = 0;

   // Pool events
   public long mNumOfInstancesReused = 0;
   public long mNumOfReferencedInstancesRecycled = 0;
   public long mNumOfUnreferencedInstancesRecycled = 0;

   // Session statistics
   public int mReferencedApplicationModules = 0;
   public int mNumOfSessions = 0;
   public long mAvgNumOfSessionsReferencingState = 0;

   // Histograms
   public AgeHistogram mSessionAgeHistogram = null;
   public AgeHistogram mRefInstanceAgeHistogram = null;
   public AgeHistogram mUnrefInstanceAgeHistogram = null;

   public Object clone()
   {
      return super.clone();
   }

   public void add(ResourcePoolStatistics statistics)
   {
      super.add(statistics);

      Statistics ampoolStats = (Statistics)statistics;
      mNumOfStateActivations += ampoolStats.mNumOfStateActivations;
      mNumOfStatePassivations += ampoolStats.mNumOfStatePassivations;

      // Pool events
      mNumOfInstancesReused += ampoolStats.mNumOfInstancesReused;
      mNumOfReferencedInstancesRecycled += ampoolStats.mNumOfReferencedInstancesRecycled;
      mNumOfUnreferencedInstancesRecycled += ampoolStats.mNumOfUnreferencedInstancesRecycled;

      // Session statistics
      mReferencedApplicationModules += ampoolStats.mReferencedApplicationModules;
      mNumOfSessions += ampoolStats.mNumOfSessions;
      mAvgNumOfSessionsReferencingState = ((ampoolStats.mNumOfSessions + mNumOfSessions) / 2);

      if (mSessionAgeHistogram != null && ampoolStats.mSessionAgeHistogram != null)
      {
         mSessionAgeHistogram.add(ampoolStats.mSessionAgeHistogram);
      }
      
      if (mRefInstanceAgeHistogram != null && ampoolStats.mRefInstanceAgeHistogram != null)
      {
         mRefInstanceAgeHistogram.add(ampoolStats.mRefInstanceAgeHistogram);
      }

      if (mUnrefInstanceAgeHistogram != null && ampoolStats.mUnrefInstanceAgeHistogram != null)
      {
         mUnrefInstanceAgeHistogram.add(ampoolStats.mUnrefInstanceAgeHistogram);
      }
   }
}
