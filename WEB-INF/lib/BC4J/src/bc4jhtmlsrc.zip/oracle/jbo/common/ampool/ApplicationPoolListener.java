/*
 * @(#)ApplicationPoolListener.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.common.ampool;

import oracle.jbo.pool.ResourcePoolListener;

public interface ApplicationPoolListener extends ResourcePoolListener
{
   public static final byte STATE_ACTIVATED                = 4;
   public static final byte STATE_PASSIVATED               = 5;
   public static final byte REFERENCED_INSTANCE_RECYCLED   = 6;
   public static final byte UNREFERENCED_INSTANCE_RECYCLED = 7;
   public static final byte INSTANCE_REUSED                = 8;
}
