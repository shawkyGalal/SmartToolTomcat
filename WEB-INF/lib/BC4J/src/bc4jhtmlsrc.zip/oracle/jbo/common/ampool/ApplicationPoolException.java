/*
 * @(#)ApplicationPoolException.java
 *
 * Copyright 2000-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.common.ampool;

import oracle.jbo.JboException;

public class ApplicationPoolException extends JboException
{
   static final long serialVersionUID = 4199995304429115537L;

   private SessionCookie mCookie = null;
   
   public ApplicationPoolException(Class resBundleClass,
                                   String errorCode,
                                   Object[] params)
   {
      super(resBundleClass, errorCode, params);
   }

   public ApplicationPoolException(Class resBundleClass,
                                   String errorCode,
                                   Object[] params,
                                   Exception[] excs)
   {
      super(resBundleClass, errorCode, params, excs);
   }

   public void printStackTrace()
   { 
     if (hasPeerExceptions())
     {
        System.out.println(getMessage());   
        getExceptions()[0].printStackTrace();
     }
     else
     {
        super.printStackTrace();
     }
     
   }

   public void printStackTrace(java.io.PrintStream s)
   { 
     if (hasPeerExceptions())
     {
        s.println(getMessage());        
        getExceptions()[0].printStackTrace(s);
     }
     else
     {
        super.printStackTrace(s);
     }
   }

   public void printStackTrace(java.io.PrintWriter s)
   {
     if (hasPeerExceptions())
     {
        s.println(getMessage());        
        getExceptions()[0].printStackTrace(s);
     }
     else
     {
        super.printStackTrace(s);
     }
   }
   
   public void setSessionCookie(SessionCookie cookie)
   {
      mCookie = cookie;
   }

   public SessionCookie getSessionCookie()
   {
      return mCookie;
   }
}
