/*
 * @(#)ApplicationPoolLogger.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.common.ampool;

import java.io.PrintWriter;

import java.util.Date;

import oracle.jbo.pool.ResourcePoolStatistics;
import oracle.jbo.pool.ResourcePoolLogger;
import oracle.jbo.pool.AgeHistogram;

/**
 * Responsible for logging, collecting, and reporting application pool
 * statistics.
 */
public final class ApplicationPoolLogger extends ResourcePoolLogger implements ApplicationPoolListener
{
   private Statistics mStatistics = new Statistics();

   private int mAvgNumOfSessionsReferencingStateAccum = 0;
   private int mAvgCounter                            = 0;

   private final ApplicationPoolImpl mPool;

   public ApplicationPoolLogger(ApplicationPoolImpl pool)
   {
      super(pool);
      mPool = pool;
   }

   public void handleEvent(byte eventType)
   {
      // Synchronized on the pool lock.  This is a little weird, but is
      // probably the safest thing to do in order to prevent deadlock from
      // invoking pool methods in the handler logic.
      synchronized(mPool.getSyncLock())
      {
         super.handleEvent(eventType);

         if (eventType == STATE_ACTIVATED)
         {
            mStatistics.mNumOfStateActivations++;
         }
         else if (eventType == STATE_PASSIVATED)
         {
            mStatistics.mNumOfStatePassivations++;
         }
         else if (eventType == REFERENCED_INSTANCE_RECYCLED)
         {
            mStatistics.mNumOfReferencedInstancesRecycled++;
         }
         else if (eventType == UNREFERENCED_INSTANCE_RECYCLED)
         {
            mStatistics.mNumOfUnreferencedInstancesRecycled++;
         }
         else if (eventType == INSTANCE_REUSED)
         {
            mStatistics.mNumOfInstancesReused++;
         }
      }
   }

   public Statistics getStatistics()
   {
      Statistics statistics = null;
      synchronized(mPool.getSyncLock())
      {
         super.getResourcePoolStatistics();
      
         calculateAverages(true);

         mStatistics.mReferencedApplicationModules = mPool.getReferencedResourceCount();
         mStatistics.mNumOfSessions = mPool.getSessionCount();

         statistics = (Statistics)mStatistics.clone();
      }

      // Compute the Histograms outside of the pool lock.  This can be expensive.
      computeSessionAgeHistogram(statistics);
      computeAppModuleAgeHistograms(statistics);

      return statistics;
   }

   public ResourcePoolStatistics getStatisticsHolder()
   {
      return mStatistics;
   }

   public void computeResourceAgeHistogram(ResourcePoolStatistics statistics)
   {
      // do not compute.  unnecessary since we will compute referenced/unreferenced
      // instance histograms.
   }
   
   protected void computeSessionAgeHistogram(Statistics statistics)
   {
      long current = System.currentTimeMillis();

      Date[] ages = new Date[]{
         new Date(current - 60000) // 1 minute
         , new Date(current - 300000) // 5 minutes
         , new Date(current - 600000)};  // 10 minutes

      statistics.mSessionAgeHistogram = new AgeHistogram(ages);

      mPool.computeSessionAgeHistogram(statistics.mSessionAgeHistogram);
   }

   protected void computeAppModuleAgeHistograms(Statistics statistics)
   {
      long current = System.currentTimeMillis();

      Date[] ages = new Date[]{
         new Date(current - 60000) // 1 minute
         , new Date(current - 300000) // 5 minutes
         , new Date(current - 600000)};  // 10 minutes

      statistics.mRefInstanceAgeHistogram = new AgeHistogram(ages);
      statistics.mUnrefInstanceAgeHistogram = new AgeHistogram(ages);
   
      mPool.computeAppModuleAgeHistograms(statistics.mRefInstanceAgeHistogram
         , statistics.mUnrefInstanceAgeHistogram);
   }

   public void dumpPoolStatistics(PrintWriter pw)
   {
      Statistics stats = getStatistics();
      
      // Collect the pool statistics inside a lock?  Why?  It doesn't
      // really matter that they are precise at this moment in time.
      printHeaderLine(AMPoolMessageBundle.MSG_AMPOOL_INSTANCE_LIFETIME_STATS, AMPoolMessageBundle.class, pw);
      printStatisticLine(AMPoolMessageBundle.MSG_AMPOOL_NUM_OF_INSTANCE_CREATIONS, AMPoolMessageBundle.class, null, stats.mNumOfInstanceCreations, pw);
      printStatisticLine(AMPoolMessageBundle.MSG_AMPOOL_NUM_OF_INSTANCE_REMOVALS, AMPoolMessageBundle.class, null, stats.mNumOfInstanceRemovals, pw);

//      pw.println();
      printHeaderLine(AMPoolMessageBundle.MSG_AMPOOL_STATE_MANAGEMENT_STATS, AMPoolMessageBundle.class, pw);

      printStatisticLine(AMPoolMessageBundle.MSG_AMPOOL_NUM_OF_ACTIVATIONS, AMPoolMessageBundle.class, null, stats.mNumOfStateActivations, pw);
      printStatisticLine(AMPoolMessageBundle.MSG_AMPOOL_NUM_OF_PASSIVATIONS, AMPoolMessageBundle.class, null, stats.mNumOfStatePassivations, pw);

//      pw.println();
      printHeaderLine(AMPoolMessageBundle.MSG_AMPOOL_USE_STATS, AMPoolMessageBundle.class, pw);

      printStatisticLine(AMPoolMessageBundle.MSG_AMPOOL_NUM_OF_CHECK_OUTS, AMPoolMessageBundle.class, null, stats.mNumOfCheckouts, pw);
      printStatisticLine(AMPoolMessageBundle.MSG_AMPOOL_NUM_OF_CHECK_INS, AMPoolMessageBundle.class, null, stats.mNumOfCheckins, pw);
      printStatisticLine(AMPoolMessageBundle.MSG_AMPOOL_NUM_OF_REUSES, AMPoolMessageBundle.class, null, stats.mNumOfInstancesReused, pw);
      printStatisticLine(AMPoolMessageBundle.MSG_AMPOOL_NUM_OF_REF_INSTANCES_RECYCLED, AMPoolMessageBundle.class, null, stats.mNumOfReferencedInstancesRecycled, pw);
      printStatisticLine(AMPoolMessageBundle.MSG_AMPOOL_NUM_OF_UNREF_INSTANCES_RECYCLED, AMPoolMessageBundle.class, null, stats.mNumOfUnreferencedInstancesRecycled, pw);
      printStatisticLine(AMPoolMessageBundle.MSG_AMPOOL_NUM_OF_CHECK_OUT_FAILURES, AMPoolMessageBundle.class, null, stats.mNumOfCheckoutFailures, pw);

//      pw.println();
      printHeaderLine(AMPoolMessageBundle.MSG_AMPOOL_INSTANCE_STATS, AMPoolMessageBundle.class, pw);

      printStatisticLine(AMPoolMessageBundle.MSG_AMPOOL_NUM_OF_INSTANCES, AMPoolMessageBundle.class, null, stats.mResourceCount, pw);
      printStatisticLine(AMPoolMessageBundle.MSG_AMPOOL_MAX_NUM_OF_INSTANCES, AMPoolMessageBundle.class, null, stats.mMaxNumOfInstances, pw);
      printStatisticLine(AMPoolMessageBundle.MSG_AMPOOL_AVG_NUM_OF_INSTANCES, AMPoolMessageBundle.class, null, stats.mAvgNumOfInstances, pw);

//      pw.println();

      printStatisticLine(AMPoolMessageBundle.MSG_AMPOOL_NUM_OF_AVAIL_INSTANCES, AMPoolMessageBundle.class, null, stats.mAvailableResourceCount, pw);
      printStatisticLine(AMPoolMessageBundle.MSG_AMPOOL_AVG_NUM_OF_AVAIL_INSTANCES, AMPoolMessageBundle.class, null, stats.mAvgNumOfAvailableInstances, pw);
      printStatisticLine(AMPoolMessageBundle.MSG_AMPOOL_AVG_NUM_OF_UNAVAIL_INSTANCES, AMPoolMessageBundle.class, null, stats.mAvgNumOfUnavailableInstances, pw);

//      pw.println();

      printStatisticLine(AMPoolMessageBundle.MSG_AMPOOL_NUM_OF_REF_INSTANCES, AMPoolMessageBundle.class, null, stats.mReferencedApplicationModules, pw);

//      pw.println();

      printHeaderLine(AMPoolMessageBundle.MSG_AMPOOL_INSTANCE_AGE_STATS, AMPoolMessageBundle.class, pw);

      printStatisticLine(AMPoolMessageBundle.MSG_AMPOOL_NUM_OF_UNUSED_REF_INSTANCES, AMPoolMessageBundle.class, new String[]{"10"}, stats.mRefInstanceAgeHistogram.mBuckets[3], pw);
      printStatisticLine(AMPoolMessageBundle.MSG_AMPOOL_NUM_OF_UNUSED_REF_INSTANCES, AMPoolMessageBundle.class, new String[]{"5"}, stats.mRefInstanceAgeHistogram.mBuckets[2], pw);
      printStatisticLine(AMPoolMessageBundle.MSG_AMPOOL_NUM_OF_UNUSED_REF_INSTANCES, AMPoolMessageBundle.class, new String[]{"1"}, stats.mRefInstanceAgeHistogram.mBuckets[1], pw);
      printStatisticLine(AMPoolMessageBundle.MSG_AMPOOL_NUM_OF_USED_REF_INSTANCES, AMPoolMessageBundle.class, new String[]{"1"}, stats.mRefInstanceAgeHistogram.mBuckets[0], pw);

//      pw.println();

      printStatisticLine(AMPoolMessageBundle.MSG_AMPOOL_NUM_OF_UNUSED_INSTANCES, AMPoolMessageBundle.class, new String[]{"10"}, stats.mUnrefInstanceAgeHistogram.mBuckets[3], pw);
      printStatisticLine(AMPoolMessageBundle.MSG_AMPOOL_NUM_OF_UNUSED_INSTANCES, AMPoolMessageBundle.class, new String[]{"5"}, stats.mUnrefInstanceAgeHistogram.mBuckets[2], pw);
      printStatisticLine(AMPoolMessageBundle.MSG_AMPOOL_NUM_OF_UNUSED_INSTANCES, AMPoolMessageBundle.class, new String[]{"1"}, stats.mUnrefInstanceAgeHistogram.mBuckets[1], pw);
      printStatisticLine(AMPoolMessageBundle.MSG_AMPOOL_NUM_OF_USED_INSTANCES, AMPoolMessageBundle.class, new String[]{"1"}, stats.mUnrefInstanceAgeHistogram.mBuckets[0], pw);

//      pw.println();

      printHeaderLine(AMPoolMessageBundle.MSG_AMPOOL_SESSION_STATS, AMPoolMessageBundle.class, pw);

      printStatisticLine(AMPoolMessageBundle.MSG_AMPOOL_NUM_OF_SESSIONS, AMPoolMessageBundle.class, null, stats.mNumOfSessions, pw);
      printStatisticLine(AMPoolMessageBundle.MSG_AMPOOL_AVG_NUM_OF_SESSIONS_REF_STATE, AMPoolMessageBundle.class, null, stats.mAvgNumOfSessionsReferencingState, pw);

//      pw.println();

      printHeaderLine(AMPoolMessageBundle.MSG_AMPOOL_SESSION_AGE_STATS, AMPoolMessageBundle.class, pw);


      printStatisticLine(AMPoolMessageBundle.MSG_AMPOOL_NUM_OF_INACTIVE_SESSIONS, AMPoolMessageBundle.class, new String[]{"10"}, stats.mSessionAgeHistogram.mBuckets[3], pw);
      printStatisticLine(AMPoolMessageBundle.MSG_AMPOOL_NUM_OF_INACTIVE_SESSIONS, AMPoolMessageBundle.class, new String[]{"5"}, stats.mSessionAgeHistogram.mBuckets[2], pw);
      printStatisticLine(AMPoolMessageBundle.MSG_AMPOOL_NUM_OF_INACTIVE_SESSIONS, AMPoolMessageBundle.class, new String[]{"1"}, stats.mSessionAgeHistogram.mBuckets[1], pw);
      printStatisticLine(AMPoolMessageBundle.MSG_AMPOOL_NUM_OF_ACTIVE_SESSIONS, AMPoolMessageBundle.class, new String[]{"1"}, stats.mSessionAgeHistogram.mBuckets[0], pw);

//      pw.println();
   }

   protected void calculateAverages(boolean force)
   {
      super.calculateAverages(force);

      // Only do it for every hundred pool checkins/checkouts.  An event driven
      // method was selected instead of a time driven method for two reasons:
      //
      // 1.  The additional thread required for a time driven collection would
      // be intrusive.
      // 2.  The time driven method would not produce reproducible results
      // require for testing.
      //
      // All averages are rounded to floor
      if (force || ((mStatistics.mNumOfCheckouts + mStatistics.mNumOfCheckins) % 100) == 0)
      {
         int numOfSessionsReferencingState = mPool.getReferencingSessionCount();

         mAvgCounter++;
         mStatistics.mAvgNumOfSessionsReferencingState =
            (mAvgNumOfSessionsReferencingStateAccum += numOfSessionsReferencingState)
            / mAvgCounter;
      }
   }
}
