/*
 * @(#)DefaultSessionCookieFactory.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.common.ampool;

import java.util.Properties;

import java.lang.reflect.Constructor;

import oracle.jbo.common.Diagnostic;


/**
 * Factory for SessionCookieImpl instances.
 */
public class DefaultSessionCookieFactory implements SessionCookieFactory
{
   public SessionCookie createSessionCookie(String name, String value, ApplicationPool pool, Properties properties)
   {
      SessionCookie cookie = null;
      Class cookieClass = getSessionCookieClass();
      if ((SessionCookieImpl.class).getName().equals(cookieClass.getName()))
      {
         cookie = new SessionCookieImpl(name, value, pool);
      }
      else
      {
         // must use reflection
         try
         {
            Constructor cons = cookieClass.getConstructor(
               new Class[]{String.class, String.class, ApplicationPool.class});

            cookie = (SessionCookie)cons.newInstance(
               new Object[]{name, value, pool});             
         }
         catch (Exception e)
         {
            if (Diagnostic.isOn())
            {
               Diagnostic.println("Could not create a SessionCookie of the specified class:  " + cookieClass.getName());
               Diagnostic.printStackTrace(e);
            }
               
            cookie = new SessionCookieImpl(name, value, pool);
         }
      }

      return cookie;
   }

   public Class getSessionCookieClass()
   {
      return SessionCookieImpl.class;
   }
}
