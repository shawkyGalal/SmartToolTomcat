/*
 * @(#)ConnectionStrategy.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.common.ampool;

import java.util.Hashtable;
import oracle.jbo.ApplicationModule;
import oracle.jbo.common.ampool.SessionCookie;

/**
 * Declares application module creation and connection operations.
 * <p>
 * This interface declares an application module factory and a set of
 * strategies for complex, property-driven application module operations.
 * <p>
 * @see oracle.jbo.common.ampool.ApplicationPoolImpl
 */
public interface ConnectionStrategy
{
   /**
    * @deprecated use {@link oracle.jbo.client.Configuration.DB_USERNAME_PROPERTY} instead.  Since 9.0.4.
    */
   public static final String DB_USERNAME_PROPERTY                   = "jbo.jdbc.username";

   /**
    * @deprecated use {@link oracle.jbo.client.Configuration.DB_PASSWORD_PROPERTY} instead.  Since 9.0.4.
    */
   public static final String DB_PASSWORD_PROPERTY                   = "jbo.jdbc.password";

   /**
    * @deprecated use {@link oracle.jbo.client.Configuration.DB_CONNECT_STRING_PROPERTY} instead.  Since 9.0.4.
    */
   public static final String DB_CONNECT_STRING_PROPERTY             = "jbo.jdbc.connectstring";

   public static final String APPLICATION_MODULE_CLASS_NAME_PROPERTY = "jbo.applicationmoduleclassname";

   /**
    * Create an application module.  This operation is included in the connection
    * strategy interface because location of an application module's home
    * object may require a connection to another JNDI context.
    *
    * @param environment the environment which is to be used to locate the
    *    application module home.  Typically derived from the application module
    *    configuration.
    */
   ApplicationModule createApplicationModule(Hashtable environment);
   
   /**
    * Create an application module.  This operation is included in the connection
    * strategy interface because location of an application module's home
    * object may require a connection to another JNDI context.
    */
   ApplicationModule createApplicationModule(SessionCookie cookie, EnvInfoProvider envInfo);

   /**
    * Connect an application module.
    */
   void connect(ApplicationModule applicationModule, SessionCookie cookie, EnvInfoProvider envInfo);
   
   /**
    * Reconnect an application module
    */
   void reconnect(ApplicationModule applicationModule, SessionCookie cookie, EnvInfoProvider envInfo);
   
   /**
    * Disconnect an application module
    */
   void disconnect(ApplicationModule applicationModule, boolean retainState, SessionCookie cookie);
}
