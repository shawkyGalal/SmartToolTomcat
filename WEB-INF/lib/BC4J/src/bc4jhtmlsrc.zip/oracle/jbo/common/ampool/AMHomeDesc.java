/*
 * @(#)AMHomeDesc.java
 *
 * Copyright 2000-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.common.ampool;

import java.util.Hashtable;

public class AMHomeDesc
{
   private Hashtable mEnv;
   private String mConnectString;
   private String mUserName;
   private String mPassword;

   private int mMaxNumOfInsts;


   public AMHomeDesc(Hashtable env, String connectString,
                     String userName, String password, int maxNumOfInsts)
   {
      mEnv = env;
      mConnectString = connectString;
      mUserName = userName;
      mPassword = password;
      mMaxNumOfInsts = maxNumOfInsts;
   }


   public Hashtable getEnv()
   {
      return mEnv;
   }


   public String getConnectString()
   {
      return mConnectString;
   }


   public String getUserName()
   {
      return mUserName;
   }


   public String getPassword()
   {
      return mPassword;
   }


   public int getMaxNumOfInsts()
   {
      return mMaxNumOfInsts;
   }


   public void setMaxNumOfInsts(int maxNumOfInsts)
   {
      mMaxNumOfInsts = maxNumOfInsts;
   }
}
