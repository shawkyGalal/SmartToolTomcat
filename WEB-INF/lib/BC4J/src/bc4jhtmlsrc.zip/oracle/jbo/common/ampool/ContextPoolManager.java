/*
 * @(#)ContextPoolManager.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.common.ampool;

import com.sun.java.util.collections.HashMap;
import com.sun.java.util.collections.Collection;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Properties;
import java.util.Timer;
//import oracle.jbo.JboException;
//import oracle.jbo.common.CommonMessageBundle;
import oracle.jbo.common.ContextUtil;

public class ContextPoolManager extends PoolMgr 
{
   private HashMap mContextMap = new HashMap();

   // From ResourcePoolManager
   public Timer getResourcePoolTimer()
   {
      return getCurrentApplicationPoolMgr().getResourcePoolTimer();
   }

   public Object getResourcePool(Object poolKey)
   {
      return getCurrentApplicationPoolMgr().getResourcePool(poolKey);
   }

   public void addResourcePool(Object poolKey, Object pool)
   {
      getCurrentApplicationPoolMgr().addResourcePool(poolKey, pool);
   }

   public void removeResourcePool(Object poolKey)
   {
      getCurrentApplicationPoolMgr().removeResourcePool(poolKey);
   }

   public Enumeration getResourcePools()
   {
      return getCurrentApplicationPoolMgr().getResourcePools();
   }

   public Enumeration getResourcePoolKeys()
   {
      return getCurrentApplicationPoolMgr().getResourcePools();
   }

   // From PoolMgr   
   public boolean isPoolCreated(String poolName)
   {
      return getCurrentApplicationPoolMgr().isPoolCreated(poolName);
   }

   public ApplicationPool getPool(String poolName)
   {
      return getCurrentApplicationPoolMgr().getPool(poolName);
   }

   public void addPool(ApplicationPool pool)
   {
      getCurrentApplicationPoolMgr().addPool(pool);
   }

   public void removePool(String poolName)
   {
      getCurrentApplicationPoolMgr().removePool(poolName);
   }

   public Enumeration getPools()
   {
      return getCurrentApplicationPoolMgr().getPools();
   }

   public Enumeration getPoolNames()
   {
      return getCurrentApplicationPoolMgr().getPoolNames();
   }

   public ApplicationPool createPool(
      String poolName
      , String poolClassName
      , String applicationModuleName
      , String connectString
      , Hashtable environment) throws Exception
   {
      return getCurrentApplicationPoolMgr().createPool(
         poolName
         , poolClassName
         , applicationModuleName
         , connectString
         , environment);
   }

   public ApplicationPool createPool(
      String poolName
      , String applicationModuleName
      , String connectString
      , Hashtable environment) throws Exception
   {
      return getCurrentApplicationPoolMgr().createPool(
         poolName
         , applicationModuleName
         , connectString
         , environment);
   }

   public ApplicationPool createPool(
      String poolName
      , String packageName
      , String configName
      , Properties props) throws Exception
   {
      return getCurrentApplicationPoolMgr().createPool(
         poolName
         , packageName
         , configName
         , props);
   }

   public ApplicationPool findPool(
      String poolName
      , String poolClassName
      , String applicationModuleName
      , String connectString
      , Hashtable environment)
   {
      return getCurrentApplicationPoolMgr().findPool(
         poolName
         , poolClassName
         , applicationModuleName
         , connectString
         , environment);

   }

   public ApplicationPool findPool(
      String poolName
      , String applicationModuleName
      , String connectString
      , Hashtable environment)
   {
      return getCurrentApplicationPoolMgr().findPool(
         poolName
         , applicationModuleName
         , connectString
         , environment);
   }

   public ApplicationPool findPool(
      String poolName
      , String packageName
      , String configName
      , Properties props)
   {
      return getCurrentApplicationPoolMgr().findPool(
         poolName
         , packageName
         , configName
         , props);
   }

   private PoolMgr getCurrentApplicationPoolMgr()
   {
      Object app = ContextUtil.getInstance().findCurrentContext();
      synchronized(mContextMap)
      {
         PoolMgr m = (PoolMgr)mContextMap.get(app);
         if(m == null)
         {
            m = new PoolMgr();
            mContextMap.put(app, m);
         }
         return m;
      }
   }   
   public Object[] getAllPoolMgrs()
   {
      synchronized(mContextMap)
      {
         Collection collection = mContextMap.values();
         return collection.toArray();
      }
   }
}
