/*
 * @(#)SessionCookieFactory.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.common.ampool;

import java.util.Properties;

/**
 * Interface for session cookie factories.
 * <p>
 * The session cookie factory is used by the application pool to instantiate
 * session cookie instances.
 * <p>
 * Application developers may create their own SessionCookieFactory
 * implementations to return custom SessionCookie implementations.
 * <p>
 * @see oracle.jbo.common.ampool.ApplicationPool#setSessionCookieFactory(SessionCookieFactory)
 */
public interface SessionCookieFactory
{
   /**
    * Creates a SessionCookie instance.
    * <p>
    * @param applicationId an identifier which may be used to uniquely
    *    identify this cookie within the context of a session
    * <p>
    * @param sessionId an option identifier which may be used to uniquely
    *    identify this cookie across sessions.
    * <p>
    * @param pool the applicationPool instance which will be used to acquire
    *    ApplicationModule instances for this SessionCookie.
    * <p>
    * @param properties an optional properties object which may be used
    *    to pass additional creation properties to the SessionCookieFactory.
    *
    */
   public SessionCookie createSessionCookie(
      String applicationId
      , String sessionId
      , ApplicationPool pool
      , Properties properties);
}
