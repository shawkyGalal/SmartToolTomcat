/*
 * @(#)HttpUtil.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.http;

import java.io.UnsupportedEncodingException;
import java.lang.reflect.Method;
import java.util.Hashtable;
import java.util.Locale;
import java.util.StringTokenizer;
import javax.servlet.ServletRequest;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Utilities for working with HTTP.
 *  NOTE: This source code copies the original implementation in the
 *  class : oracle.cabo.share.util.CaboHttpUtils. The reason for the
 *  copy is to avoid Cabo dependencies in the Core BC4J code.
 */
public class HttpUtil
{
  /**
   * Returns the full servlet path: <code>getRequestURI() - getPathInfo()
   * </code>.  In the Servlet 2.1 API, this is just <code>getServletPath()
   * </code>, but in Servlet 2.2, it's <code>getContextPath() + 
   * getServletPath()</code>, hence the need for a utility method that
   * works in both versions.
   */
    static public String getFullServletPath(HttpServletRequest httpRequest)
    {
    // The 2.2 API changed the meaning of getServletPath().
    // So getServletPath() doesn't
    // return the value we want... that'd be getContextPath() +
    // getServletPath().  Only we don't have getContextPath() at all
    // in 2.1.  So, use introspection to add in the context path
    // where needed.
        String servletPath = httpRequest.getServletPath();

        if (!_sLookedForContextPath)
        {
            try
            {
                _sGetContextPath =
                                  HttpServletRequest.class.getMethod("getContextPath", null);
            }
            catch (Exception e)
            { 
        // pre 2.2 Servlet API (or something even weirder)
            }

            _sLookedForContextPath = true;
        }

        Method method = _sGetContextPath;

        if (method != null)
        {
            try
            {
                String contextPath = (String)method.invoke(httpRequest, null);
        // =-=AEW getContextPath() is encoded, getServletPath() isn't!
        // So we have to decode the context path before we use it.
                servletPath = contextPath + servletPath;
            }
      // No exceptions should occur.  It'd be nice to be able
      // to log errors, but we don't have the log here.
            catch (Exception e)
            {
            }
        }

        return servletPath;
    }


  /**
   * Sets headers on a servlet reponse to completely block caching for
   * even the most poorly written browsers.
   */
    static public void setNoCacheHeaders(HttpServletResponse response)
    {
        response.setHeader("Cache-Control", "no-cache");
        response.setHeader("Pragma", "no-cache");
        response.setHeader("Expires", "-1");
    }


  /**
   * Returns the locale to be used for a request, based on
   * <code>Accept-Language</code> and <code>Accept-Charset</code> HTTP
   * headers.  Returns null if the locale cannot be determined.
   */
    static public Locale determineLocale(ServletRequest request)
    {
        Locale locale = null;

        if (request instanceof HttpServletRequest)
        {
            HttpServletRequest httpRequest = (HttpServletRequest)request;

            locale = _getAcceptLanguagesLocale(
                                               httpRequest.getHeader("Accept-Language"));

            if (locale == null)
            {
                locale = _getAcceptCharSetsLocale(
                    httpRequest.getHeader("Accept-Charset"));
            }

            if ((locale != null) && "".equals(locale.getCountry()))
            {
                Locale defaultLocale = Locale.getDefault();
                if (locale.getLanguage().equals(defaultLocale.getLanguage()))
                    locale = defaultLocale;
            }
        }

        return locale;
    }



  /**
   * Throws an UnsupportedEncodingException if the
   * provided encoding is not supported.
   * @param encoding the name of a character encoding
   */
    static public void validateEncoding(String encoding)
            throws UnsupportedEncodingException
    {
        if (encoding != null)
        {
      // Try creating a string off of the default encoding
            new String(_sTestBytes, encoding);
        }
    }

  /**
   * Given a parameter string and the name of a character encoding,
   * fixes the string.  The Servlet API builds Strings for all submitted
   * data as if they were ISO-8859-1 encoded;  this function undoes
   * the damage.  Clients should pass in the same encoding that they
   * used for generating the page that the submission comes from.
   * <p>
   * @param string the string
   * @param encoding the name of a character encoding
   * @param buffer an optional byte buffer, for reuse;  pass null
   *    if you're not calling this function repeatedly
   */
    static public final String decodeRequestParameter(
        String string,
        String encoding,
        byte[] buffer) throws UnsupportedEncodingException
    {
        if (encoding == null)
            return string;
        if (string == null)
            return null;

        int stringLength = string.length();

        if ((buffer == null) || (stringLength > buffer.length))
            buffer = new byte[stringLength];

    // As documented, this function doesn't convert "properly"
    // from characters to bytes.  But it happens to do
    // exactly the conversion we want
        string.getBytes(0, stringLength, buffer, 0);

        return new String(buffer, 0, stringLength, encoding);
    }


    static private Locale _getAcceptLanguagesLocale(
        String acceptLanguages
        )
    {
        if (acceptLanguages != null)
        {
            float  highestWeight = 0.0f;
            String highestLang = null;

            StringTokenizer langs = new StringTokenizer(acceptLanguages, ",");

            while (langs.hasMoreTokens() && (highestWeight < 1.0f))
            {
        // get the current language token
                String currToken = langs.nextToken();
                float currQ = 1.0f;

        //
        // separate the language from the q-value, if any
        //
                String currLang = currToken;

                int qSepIndex = currToken.indexOf(';');

                if (qSepIndex != -1)
                {
                    currLang = currLang.substring(0, qSepIndex);

                    int tokenLength = currToken.length();

                    qSepIndex++;

                    if (qSepIndex < tokenLength)
                    {
                        String qString = currToken.substring(qSepIndex, tokenLength);
                        qString.trim();

                        if (qString.length() > 0)
                        {
                            try
                            {
                                currQ = Float.valueOf(qString).floatValue();
                            }
                            catch (NumberFormatException e)
                            {
                // ignore
                            }
                        }
                    }
                }

                if (currQ > highestWeight)
                {
                    highestWeight = currQ;
                    highestLang   = currLang.trim();
                }
            }

            if (highestLang != null)
            {
                return _createLocale(highestLang);
            }
        }

        return null;
    }


  /**
   * Parses a hyphen-separated locale String into a Locale object.
   */
    static private Locale _createLocale(
                                        String localeString
                                       )
    {
        String language  = localeString;
        String territory = "";
        String variant   = "";

        int territoryIndex = language.indexOf('-');

        if (territoryIndex != -1)
        {      
            language = language.substring(0, territoryIndex);

            territoryIndex++;

            territory = localeString.substring(territoryIndex);

            int variantIndex = territory.indexOf('-');

            if (variantIndex != -1)
            {                
                variant = territory.substring(variantIndex + 1);
                territory = territory.substring(0, variantIndex);
            }
        }

        return new Locale(language, territory, variant);
    }


  /**
   * Given a comma-separated list of charsets, return the best guess at
   * a locale.
   */
    static private Locale _getAcceptCharSetsLocale(
        String acceptCharsets
        )
    {
        Locale currLocale = null;

        if ((acceptCharsets != null) && !"*".equals(acceptCharsets))
        {      
            StringTokenizer charsets = new StringTokenizer(acceptCharsets, ",");

            while ((currLocale == null) && charsets.hasMoreTokens())
            {
        // get the current charset token
                String currCharset = charsets.nextToken();

                currLocale = (Locale)CHARSET_TO_LOCALE_MAP.get(currCharset);
            }
        }

        return currLocale;
    }

    static private final Hashtable CHARSET_TO_LOCALE_MAP = new Hashtable();

  /**
   * Create bogus mapping of character sets to likely locales.
   */
    static
    {
        CHARSET_TO_LOCALE_MAP.put("ISO-8859-1", Locale.US);
    }


    static private boolean _sLookedForContextPath = false;
    static private Method  _sGetContextPath;

    static private final byte[] _sTestBytes = new byte[]{(byte) 65};

    private HttpUtil()
    {
    }
}
