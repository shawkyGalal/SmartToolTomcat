/*
 * @(#)BindingEvent.java
 *
 * Copyright 2000-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.http;

import java.util.Properties;

class BindingEvent extends Object
{
   private Properties  mUserProperties = null;
   private Object      mContextRef     = null;

   /**
    * Constructor
    */
   BindingEvent(Object contextRef)
   {
      mContextRef = contextRef;
   }

   void setUserProperties(Properties properties)
   {
      mUserProperties = properties;
   }

   Properties getUserProperties()
   {
      return mUserProperties;
   }

   Object getParentContext()
   {
      return mContextRef;
   }
}

 