/*
 * @(#)HttpSessionCookieHelperImpl.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.http;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import oracle.jbo.common.JboEnvUtil;
import oracle.jbo.common.PropertyMetadata;
import oracle.jbo.common.ampool.SessionCookie;

/**
 * Default HttpSessionCookieHelper implementation.
 */
public class HttpSessionCookieHelperImpl extends Object
   implements HttpSessionCookieHelper
{
   /**
    * Constructor
    */
   public HttpSessionCookieHelperImpl()
   {
   }

   public String readCookieValue(
      HttpServletRequest request
      , String applicationName)
   {
      String cookieName = HttpContainer.APPLICATION_COOKIE_PREFIX + applicationName;
      String cookieValue = null;

      Cookie[] cookies = request.getCookies();
      Cookie cookie = null;

      if (cookies != null)
      {
         for (int i=0; i < cookies.length; i++)
         {
            if (cookies[i].getName().equals(cookieName))
            {
               cookie = cookies[i];
               break;
            }
         }
      }

      // Finally, check to see if the cookie has been stored in the session.
      // This may occur if browser cookies have been disabled.
      if (cookie == null)
      {
         cookie = (Cookie)request.getSession(true).getValue(cookieName);
      }

      if (cookie != null)
      {
         cookieValue = cookie.getValue();
      }
      // Try to read the cookie value from the request parameters
      else
      {
         cookieValue = request.getParameter(cookieName);
      }

      return cookieValue;
   }

   public void writeCookieValue(
      HttpServletResponse response
      , String applicationName
      , String cookieValue)
   {
      Cookie cookie = new Cookie(
         HttpContainer.APPLICATION_COOKIE_PREFIX + applicationName
         , cookieValue);

      int cookieAge = JboEnvUtil.getPropertyAsInt(
         PropertyMetadata.ENV_MAX_POOL_COOKIE_AGE.getName()
         , Integer.valueOf(PropertyMetadata.ENV_MAX_POOL_COOKIE_AGE.getDefault())
            .intValue());

      if (cookieAge >= 0)
      {
         cookie.setMaxAge(cookieAge);
      }

      response.addCookie(cookie);
   }

   public String generateSessionId(HttpServletRequest request)
   {
      return request.getSession(true).getId();
   }

   public String encodeURL(String url, SessionCookie[] cookies)
   {
      String path = null;
      String query = "";
      String amp = "";
      

      int question = url.indexOf('?');
      if (question < 0)
      {
         amp = "?";
      }
      else
      {
         amp = "&";
      }

      StringBuffer sb = new StringBuffer(url);
      for (int i = 0; i < cookies.length; i++)
      {
         sb.append(amp);
         sb.append(HttpContainer.APPLICATION_COOKIE_PREFIX);
         sb.append(cookies[i].getApplicationId());
         sb.append('=');
         sb.append(cookies[i].getValue());
         amp = "&";
      }

	    return sb.toString();
   }
}

