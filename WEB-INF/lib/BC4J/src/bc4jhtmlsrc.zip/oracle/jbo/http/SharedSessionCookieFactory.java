/*
 * @(#)SharedSessionCookieFactory.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.http;

import java.util.Properties;
import oracle.jbo.common.ampool.ApplicationPool;
import oracle.jbo.common.ampool.SessionCookie;
import oracle.jbo.common.ampool.SessionCookieFactory;

import oracle.jbo.common.Diagnostic;

import java.lang.reflect.Constructor;

/**
 * Factory for shared session cookies.  By default, the factory will return
 * a singleton shared session cookie instance for shared access to a "semi-static"
 * application module.  The factory may also be configured with a pool
 * of shared session cookies.  This may be desirable to reduce lock contention
 * amongst sessions.  When a pool of shared session cookies is used the pool
 * will return shared session cookies in a round-robin fashion.
 * <p>
 * Please see {@link oracle.jbo.http.SharedSessionCookieImpl} for more information
 * regarding the shared session cookie implementation.
 */
public class SharedSessionCookieFactory implements SessionCookieFactory
{
   private int mPoolSize;
   private SharedSessionCookieImpl[] mSharedCookies;
   private int mIndex = 0;
   private Object mSyncLock = new Object();

   public SharedSessionCookieFactory(int poolSize)
   {
      super();
      mPoolSize = poolSize;
      mSharedCookies = new SharedSessionCookieImpl[mPoolSize];
   }

   public SharedSessionCookieFactory()
   {
      this(1);
   }

   public int getPoolSize()
   {
      return mPoolSize;
   }
   
   public void setPoolSize(int poolSize)
   {
      synchronized(mSyncLock)
      {
         int grow = (poolSize - mPoolSize);
         if (grow > 0)
         {
            SharedSessionCookieImpl[] sharedCookies = new SharedSessionCookieImpl[poolSize];
            System.arraycopy(mSharedCookies,0,sharedCookies,0,mPoolSize);

            // Do not initialize the new array elements yet.
            mPoolSize = poolSize;
         }
      }
   }

   public SessionCookie createSessionCookie(String applicationId, String sessionId, ApplicationPool pool, Properties properties)
   {
      synchronized(mSyncLock)
      {
         SharedSessionCookieImpl cookie = mSharedCookies[mIndex];
         
         if (cookie == null)
         {
            Class cookieClass = getSessionCookieClass();
            if ((SharedSessionCookieImpl.class).getName().equals(cookieClass.getName()))
            {
               cookie = new SharedSessionCookieImpl(applicationId, Integer.toString(mIndex), pool);
            }
            else
            {
               // must use reflection
               try
               {
                  Constructor cons = cookieClass.getConstructor(
                     new Class[]{String.class, String.class, ApplicationPool.class});

                  cookie = (SharedSessionCookieImpl)cons.newInstance(
                     new Object[]{applicationId, Integer.toString(mIndex), pool});             
               }
               catch (Exception e)
               {
                  if (Diagnostic.isOn())
                  {
                     Diagnostic.println("Could not create a SessionCookie of the specified class:  " + cookieClass.getName());
                     Diagnostic.printStackTrace(e);
                  }
               
                  cookie = new SharedSessionCookieImpl(applicationId, Integer.toString(mIndex), pool);
               }
            }
            mSharedCookies[mIndex] = cookie;
         }

         if (mIndex < (mPoolSize - 1))
         {
            mIndex++;
         }
         else
         {
            mIndex = 0;
         }
         return cookie;
      }
   }

   public Class getSessionCookieClass()
   {
      return SharedSessionCookieImpl.class;
   }
   
}
