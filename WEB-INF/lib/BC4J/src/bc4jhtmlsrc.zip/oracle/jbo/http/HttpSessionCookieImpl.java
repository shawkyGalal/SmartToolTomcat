/*
 * @(#)HttpSessionCookieImpl.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.http;

import java.io.Serializable;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import oracle.jbo.common.PropertyMetadata;
import oracle.jbo.common.PropertyConstants;
import oracle.jbo.common.ampool.ApplicationPool;
import oracle.jbo.common.ampool.SessionCookieImpl;
import oracle.jbo.common.TransactionControl;
import oracle.jbo.common.ContextUtil;

import oracle.jbo.JboContext;
import oracle.jbo.ApplicationModule;
import java.security.Principal;
/**
 * Default HttpSessionCookie implementation.
 * <p>
 * The implementation uses a pluggable helper interface, {@link oracle.jbo.http.HttpSessionCookieHelper},
 * to generate unique session identifiers for browser sessions, to read browser
 * cookie values, and to write browser cookie values.
 * <p>
 * Implements the {@link oracle.jbo.http.BindingListener} interface.  When
 * a session {@link oracle.jbo.http.HttpContainer} instance is unbound from
 * an HttpSession context the BindingListeners will be notified that a timeout
 * event occured.  The timeout implementation releases the application module
 * resource to the application pool.  The release is unmanaged since the
 * request is assumed to have already ended.
 * <p>
 * The HttpSessionCookieImpl also implements additional support for
 * BC4J based authentication.  If a single sign on module like mod_osso is not
 * being used then an application developer can set a security principal and
 * security credential in the HttpSession context for later authentication
 * by the BC4J security login module.  In order to enable this mode the
 * application developer must have configured the <tt>jbo.security.enforce</tt>
 * property.  The principal and credentials should be cached in the session as
 * follows:
 * <p>
 * <tt>
 *    session.setAttribute(
 *        JboContext.SECURITY_PRINCIPAL, (String)<principal name>); 
 *    session.setAttribute(
 *        JboContext.SECURITY_CREDENTIALS, (String)<credential>);
 * </tt>
 * <p>
 * Finally, the HttpSessionCookie implementation uses composition to implement
 * the SessionCookie interface.  All SessionCookie methods are delegated to
 * an instance of the default SessionCookie implementation.  Please see
 * {@link oracle.jbo.common.ampool.SessionCookieImpl} for more infomartion
 * regarding the default session cookie implementation.
 */
public class HttpSessionCookieImpl
   extends SessionCookieImpl
   implements HttpSessionCookie, BindingListener, Serializable
{
   static final long serialVersionUID = -5336195329607336406L;
   private boolean mInSuspend = false;
   
   /**
    * This constructor may be used if the sessionId is already known.
    */
   public HttpSessionCookieImpl(
      String applicationId
      , String sessionId
      , ApplicationPool pool)
   {
      this(
         applicationId
         , sessionId
         , pool
         , null // userPrincipal
         , null); // request
   }

   public HttpSessionCookieImpl(
      String applicationId
      , String sessionId
      , ApplicationPool pool
      , Principal userPrincipal
      , HttpServletRequest request)
   {
      super(applicationId, sessionId, pool, userPrincipal);

      HttpSession session =
         (request != null ? request.getSession(false) : null);

      // if the session is not null and if the cookie has not already been
      // authorized then check if the SECURITY_PRINCIPAL and
      // SECURITY_CREDENTIALS have been cached in the session context.  If so,
      // initialize the cookie environment so that BC4J can perform
      // authentication
      if ((session != null)
         && (!PropertyConstants.TRUE.equals(
            getEnvironment(PropertyConstants.ENV_SECURITY_AUTHORIZED))))
      {
         Object principal = session.getValue(JboContext.SECURITY_PRINCIPAL);

         if (principal != null)
         {
            setEnvironment(JboContext.SECURITY_PRINCIPAL, principal);

            Object credentials = session.getValue(
               JboContext.SECURITY_CREDENTIALS);

            if (credentials != null)
            {
               setEnvironment(JboContext.SECURITY_CREDENTIALS, credentials);
            }
         }
      }

      setSingleThreaded(false);

      String value = readValue(request);

      if (value != null)
      {
         setPassivationId((new Integer(value)).intValue());
      }
   }

   public void valueBound(BindingEvent ev)
   {
      // Do nothing.
   }

   public void valueUnbound(BindingEvent ev)
   {
      // Release the application module just in case.  Otherwise the
      // session cookie reference may be lost for ever.
      StringBuffer sb = new StringBuffer(128);
      sb.append("The session cookie for the application, ");
      sb.append(getApplicationId());
      sb.append(", was removed from the session context");
      System.err.println(sb.toString());

      timeout();
   }

   public void timeout(BindingEvent ev)
   {
      StringBuffer sb = new StringBuffer(128);
      sb.append("The session cookie for the application, ");
      sb.append(getApplicationId());
      sb.append(", was timed out");
      System.err.println(sb.toString());

      timeout();
   }

   public void writeValue(Object sink)
   {
      // No use in writing the value if failover is not enabled.  Don't bother.
      if ((sink instanceof HttpServletResponse) && isFailoverEnabled())
      {
         synchronized(sink)
         {
            HttpServletResponse response = (HttpServletResponse)sink;

            HttpSessionCookieHelper helper = HttpSessionCookieHelperManager.getHttpSessionCookieHelper();
            helper.writeCookieValue(response, getApplicationId(), getValue());
         }
      }
   }

   public String readValue(Object source)
   {
      String value = null;
      if ((source != null) && (source instanceof HttpServletRequest))
      {
         synchronized(source)
         {
            HttpServletRequest request = (HttpServletRequest)source;
            HttpSessionCookieHelper helper = HttpSessionCookieHelperManager.getHttpSessionCookieHelper();
            value = helper.readCookieValue(request, getApplicationId());
         }
      }

      return value;
   }

   public boolean isFailoverEnabled()
   {
      return getProperty(
         PropertyMetadata.ENV_DO_FAILOVER.getName()
         , getEnvironment()
         , Boolean.valueOf(PropertyMetadata.ENV_DO_FAILOVER.getDefault())
            .booleanValue());
   }

   protected void beforeApplicationModuleRelease(ApplicationModule am)
   {
      // invoked immediately before the ApplicationModule will physically
      // be released to the pool.  Care should be taken here to not mutate
      // the state of the releasing cookie.  The use call here
      mInSuspend = true;
      if(am instanceof oracle.jbo.common.TransactionControl)
      {
         ((TransactionControl)am).suspend();
      }
   }

   protected void afterApplicationModuleRelease()
   {
      mInSuspend = false;  
      ContextUtil.getInstance().resetCurrentContext();
   }

   public ApplicationModule useApplicationModule(boolean lock, long waitTimeout)
   {
      synchronized(getSyncLock())
      {
         ContextUtil.getInstance().setCurrentContext(
            Thread.currentThread().getContextClassLoader());

         ApplicationModule am = super.useApplicationModule(lock, waitTimeout);
         if(!mInSuspend && (am instanceof oracle.jbo.common.TransactionControl))
         {
            ((TransactionControl)am).resume();
         }
         return am;
      }
   }
}
