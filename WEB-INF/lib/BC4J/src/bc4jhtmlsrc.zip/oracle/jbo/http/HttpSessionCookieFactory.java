/*
 * @(#)HttpSessionCookieFactory.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.http;

import java.util.Properties;
import javax.servlet.http.HttpServletRequest;
import oracle.jbo.common.ampool.ApplicationPool;
import oracle.jbo.common.ampool.SessionCookie;
import oracle.jbo.common.ampool.SessionCookieFactory;

import java.lang.reflect.Constructor;

import oracle.jbo.common.Diagnostic;

import java.security.Principal;

/**
 * Factory for HttpSessionCookieImpl instances.
 */
public class HttpSessionCookieFactory implements SessionCookieFactory
{
   public static final String HTTP_SERVLET_REQUEST = "jbo.HttpServletRequest";

   /**
    * Creates a HttpSessionCookieImpl instance.
    * <p>
    * The properties object may contain an entry with an instance of an
    * HttpServletRequest.  The public static final, HTTP_SERVLET_REQUEST,
    * should be used to add the request object to the properties.
    * <p>
    * The request object is used to retrieve the cookie value.
    * <p>
    * @param applicationId an identifier which may be used to uniquely
    *    identify this cookie within the context of a session
    * <p>
    * @param sessionId an option identifier which may be used to uniquely
    *    identify this cookie across sessions.  If a sessionId is not specified
    *    then the HttpServletRequest above will be used to acquire the
    *    sessionId from the servlet request's session.
    * <p>
    * @param pool the applicationPool instance which will be used to acquire
    *    ApplicationModule instances for this SessionCookie.
    * <p>
    * @param properties an optional properties object which may be used
    *    to pass additional creation properties to the SessionCookieFactory.
    * 
    */
   public SessionCookie createSessionCookie(
      String applicationId
      , String sessionId
      , ApplicationPool pool
      , Properties properties)
   {
      HttpServletRequest request = null;
      SessionCookie cookie = null;

      if (properties != null)
      {
         request = (HttpServletRequest)properties.get(HTTP_SERVLET_REQUEST);
      }

      if (request != null)
      {
         HttpSessionCookieHelper helper =
            HttpSessionCookieHelperManager.getHttpSessionCookieHelper();

         sessionId = helper.generateSessionId(request);

         Principal userPrincipal = null;

         try
         {
            userPrincipal =
               (request == null ? null : request.getUserPrincipal());
         }
         catch (NoSuchMethodError e)
         {
            // ignore.  servlet 2.0 compatibility issue.
         }

         Class cookieClass = getSessionCookieClass();
         if ((HttpSessionCookieImpl.class).getName().equals(
            cookieClass.getName()))
         {
            cookie = new HttpSessionCookieImpl(
               applicationId
               , sessionId
               , pool
               , userPrincipal
               , request);
         }
         else
         {
            // must use reflection
            try
            {
               Constructor cons = cookieClass.getConstructor(
                  new Class[]{
                     String.class
                     , String.class
                     , ApplicationPool.class
                     , Principal.class
                     , HttpServletRequest.class});

               cookie = (SessionCookie)cons.newInstance(
                  new Object[]{
                     applicationId, sessionId, pool, userPrincipal, request});             
            }
            catch (Exception e)
            {
               if (Diagnostic.isOn())
               {
                  Diagnostic.println("Could not create a SessionCookie of the specified class:  " + cookieClass.getName());
                  Diagnostic.printStackTrace(e);
               }
               
               cookie = new HttpSessionCookieImpl(
                  applicationId
                  , sessionId
                  , pool
                  , userPrincipal
                  , request);
            }
         }
      }
      else
      {
         Class cookieClass = getSessionCookieClass();
         if ((HttpSessionCookieImpl.class).getName().equals(cookieClass.getName()))
         {
            cookie = new HttpSessionCookieImpl(applicationId, sessionId, pool);
         }
         else
         {
            // must use reflection
            try
            {
               Constructor cons = cookieClass.getConstructor(
                  new Class[]{String.class, String.class, ApplicationPool.class});
               cookie = (SessionCookie)cons.newInstance(
                  new Object[]{applicationId, sessionId, pool});             
            }
            catch (Exception e)
            {
               if (Diagnostic.isOn())
               {
                  Diagnostic.println("Could not create a SessionCookie of the specified class:  " + cookieClass.getName());
                  Diagnostic.printStackTrace(e);
               }
               
               cookie = new HttpSessionCookieImpl(applicationId, sessionId, pool);
            }
         }
      }

      return cookie;
   }

   public Class getSessionCookieClass()
   {
      return HttpSessionCookieImpl.class;
   }
}
