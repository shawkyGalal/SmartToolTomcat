/*
 * @(#)SharedSessionCookieImpl.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.http;

import oracle.jbo.common.ampool.ApplicationPool;

/**
 * A shared application module handle.
 * <p>
 * Some enterprise applications may define static data that is required across
 * sessions and does not change very frequently.  An example of this type of
 * data might be application metadata that is used to render the application UI.
 * If BC4J is used to access the static data then an unnecessary overhead is
 * incurred if the static data caches are repopulated from the database for
 * each application session on every request.  In order to optimize performance
 * common practice is to cache the shared static data for reuse across sessions
 * and requests.
 * <p>
 * This class supports shared, static data caches by allowing requests from 
 * multiple sessions to share a single application module instance
 * which is managed by an application pool for the lifetime of the web server
 * VM.  
 * <p>
 * The SharedSessionCookieImpl extends the HttpSessionCookieImpl with the 
 * following logic for managing access to a shared application module instance:
 * <p>
 * <li>Prevents unnecessary state passivation at the end of a request</li>
 * <li>Manages shared, transactional application module state across sessions and requests</li>
 * <p>
 * The {@link oracle.jbo.http.SharedSessionCookieFactory} may be used to
 * instantiate SharedSessionCookieImpl sessions for an application pool.  The
 * application developer may use the SharedSessionCookieImpl with an
 * application pool by specifying the following BC4J property in the
 * configuration of the application module that will be used to cache static
 * data:
 * <p>
 * <tt>jbo.ampool.sessioncookiefactoryclass=oracle.jbo.http.SharedSessionCookieFactory</tt>
 * <p>
 * After having declared the property above the application developer may access
 * the shared application module instance with any application pooling client
 * like the BC4J data tags and the BC4J data web beans.
 * <p>
 * Finally, the application developer should be careful about mutating the
 * shared transactional state after a shared session cookie has been used.  Most
 * shared state should be "built and cached" only once after an application
 * module is created or connected and before it has become available for use.
 * One recommended place to initialize shared ApplicationModule state is
 * the prepareSession method which is invoked after an ApplicationModule
 * has been connected and is also threadsafe.
 * <p>
 * A session may use the locking mode when acquiring an ApplicationModule
 * to synchronize access to the shared ApplicationModule instance.  However,
 * if locking is used extra care should be taken to ensure that the locking
 * request releases the lock by including the useApplicationModule and
 * releaseApplicationModule invocations in a try...finally block.
 * <p>
 * Please see {@link oracle.jbo.http.HttpSessionCookieImpl} for more infomartion
 * regarding the http session cookie implementation.
 */
public class SharedSessionCookieImpl
   extends HttpSessionCookieImpl
{
   /**
    * This constructor may be used if the sessionId is already known.
    */
   public SharedSessionCookieImpl(
      String applicationId, String sessionId, ApplicationPool pool)
   {
      super(applicationId, sessionId, pool);
   }

   public void releaseApplicationModule(int releaseFlags, long waitTimeout) 
   {
      // jrs - release the SessionCookie lock
      super.releaseApplicationModule(
         RESERVED_MANAGED_RELEASE_MODE, waitTimeout);
   }

   protected void removeFromPool()
   {
      // don't remove the shared cookie from the pool, it is a "static"
      // pool session
   }

   public boolean isFailoverEnabled()
   {
      // Never failover.
      return false;
   }
}
