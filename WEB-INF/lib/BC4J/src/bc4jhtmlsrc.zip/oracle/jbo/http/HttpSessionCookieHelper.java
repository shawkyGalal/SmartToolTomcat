/*
 * @(#)HttpSessionCookieHelper.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.http;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import oracle.jbo.common.ampool.SessionCookie;

/**
 * Defines a set of HttpSessionCookie services.
 * <p>
 * Application developers may implement this interface in order to support
 * custom cookie requirements.
 * <p>
 * @see oracle.jbo.http.HttpSessionCookie
 */
public interface HttpSessionCookieHelper
{
   /**
    * Read the session id from the HttpServletRequest.  By default this method
    * uses Http cookies to store the unique session identifier for a
    * stateful application module.
    *
    * @param applicationName the name of the application that has session state
    */
   public String readCookieValue(
      HttpServletRequest request
      , String applicationName);

   /**
    * Write the session id to the HttpServletResponse.  By default this method
    * uses Http cookies to store a unique session identifier for a
    * stateful application module.
    *
    * @param applicationName the name of the application that has session state
    */
   public void writeCookieValue(
      HttpServletResponse response
      , String applicationName
      , String cookieValue);

   /**
    * Return a unique identifier for this session.  The session identifer
    * will be used by the application pool to identify client sessions and to
    * activate application state from previous requests.
    * <p>
    * The session identifier should be unique across virtual machines for each
    * application client.  Conflicting session identifiers may result in one
    * application client reading and changing the application state of another
    * application client.
    * <p>
    * The session identifer should also be consistent across requests for each
    * client.  If a given application client requests all generate different
    * session identifiers the application pool will not be able to track
    * the application state for that application client between those requests
    * and will treat each individual request as having originated from a
    * different application client.
    * <p>
    * The default implementation is using the client IP address to generate
    * session identifiers.  Application developers may override this
    * implementation to use a different technique to generate session
    * identifiers.
    */
   public String generateSessionId(HttpServletRequest request);

   /**
    * Encode the specified url with the specified HttpSessionCookies.  The
    * session cookies will be read from the URL if a browser cookie is not
    * when the application HttpSessionCookie is re-instantiated.
    * <p>
    * This method should be invoked from {@link oracle.jbo.http.HttpContainer#encodeURL(String)}
    */
   public String encodeURL(String url, SessionCookie[] cookies);
}

 