/*
 * @(#)JUControlBinding.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.uicli.binding;

import oracle.jbo.ApplicationModule;
import oracle.jbo.JboException;
import oracle.jbo.Row;
import oracle.jbo.RowIterator;
import oracle.jbo.Transaction;
import oracle.jbo.ViewObject;

/**
 * The base class for all binding objects in the JClient framework that bind
 * a Swing control/model to a BC4J attribute(s). This class manages:
 * <ul>
 * <li>The references to the Swing control
 * <li>The IteratorBinding with which the binding object is in association
 * <li>The form binding that this binding belongs to
 * <li>The internal-state for findMode
 * </ul>
 * <p>
 * This class also implements helper methods to access BC4J objects like the Transaction,
 * the current Application Module, the ViewObject that this control binding is working with,
 * the current RowIterator, the current Row in the iterator that this control binding
 * is associated with. It also provides methods to execute the ViewObject behind this again (optionally).
 */
abstract public class JUControlBinding
{
   private String mName;
   private Object mControl;
   private JUIteratorBinding mIterBinding;
   private JUFormBinding mFormBinding;
   private JUControlDef mControlDef;
   private transient boolean mWasEnabledBeforeFindMode;

   // For debugging
   private int mId = mIdCounter++;

   private static int mIdCounter = 0;


   protected JUControlBinding()
   {
   }

   /**
   * Constructor used in the framework to pass in the Swing control and the Iterator Binding
   * with which this binding object works to get it's data.
   */
   public JUControlBinding(Object control, JUIteratorBinding iterBinding)
   {
      mControl = control;
      mIterBinding = iterBinding;

      if (iterBinding != null)
      {
         setFormBinding(iterBinding.getFormBinding());
      }
   }

   
   /**
   * *** For internal framework use only ***
   */
   abstract public void addControlToPanel(Object panel, Object layoutObject, Object layoutCons);

   
   /**
   * *** For internal framework use only ***
   */
   public final String getName()
   {
      return mName;
   }


   /**
   * *** For internal framework use only ***
   */
   public void setName(String name)
   {
      if (mName == null && name == null)
      {
         return;
      }
      
      if (mName != null)
      {
         if (mName.equals(name))
         {
            return;
         }

         if (mFormBinding != null)
         {
            mFormBinding.removeControlBinding(this);
         }
      }

      mName = name;
      
      if (mFormBinding != null)
      {
         mFormBinding.addControlBinding(this);
      }
   }

   
   /**
   * Report the given exception via the containing FormBinding object.
   */
   public void reportException(Exception ex)
   {
      mFormBinding.reportException(ex);
   }


   public void reportException(Exception ex, boolean grabFocus)
   {
      if (grabFocus && mControl instanceof javax.swing.JComponent) 
      {
         ((javax.swing.JComponent)mControl).grabFocus();
         //show exception dialog after focus as in some jdks this leads
         //to another focus out event turning into two simultaneous error
         //dialogs.
         mFormBinding.reportException(ex);
      }
      else
      {
         mFormBinding.reportException(ex);
         throw (ex instanceof JboException) ? (JboException)ex : new JboException(ex);
      }
   }
   
   /**
   * Returns the form binding object that this control binding is part of.
   */
   public final JUFormBinding getFormBinding()
   {
      return mFormBinding;
   }

   
   /**
   * *** For internal framework use only ***
   */
   public void setFormBinding(JUFormBinding formBnd)
   {
      if (mFormBinding != null)
      {
         mFormBinding.removeControlBinding(this);
      }
      
      mFormBinding = formBnd;

      if (mFormBinding != null)
      {
         mFormBinding.addControlBinding(this);
      }
   }

   
   /**
   * *** For internal framework use only ***
   */
   public final JUControlDef getDef()
   {
      return mControlDef;
   }
   
   /**
   * *** For internal framework use only ***
   */
   void setDef(JUControlDef controlDef)
   {
      mControlDef = controlDef;
   }
   
   
   /**
   * Returns the iterator binding with which this control binding is associated to get it's data.
   */
   public final JUIteratorBinding getIteratorBinding()
   {
      return mIterBinding;
   }

   
   /**
   * Returns the Transaction object for the current BC4J session.
   */
   public Transaction getTransaction()
   {
      if (getIteratorBinding() == null)
      {
         return null;
      }
      
      synchronized(getIteratorBinding().getSyncLock())
      {
         ApplicationModule am = getApplicationModule();

         if (am != null)
         {
            return getApplicationModule().getTransaction();
         }
         else
         {
            return null;
         }
      }
   }

   
   /**
   * Returns the Application Module to which this control's ViewObject belongs. 
   */
   public ApplicationModule getApplicationModule()
   {
      if (getIteratorBinding() == null)
      {
         return null;
      }
      
      synchronized(getIteratorBinding().getSyncLock())
      {
         ViewObject vo = getViewObject();

         if (vo != null)
         {
            return getViewObject().getApplicationModule();
         }
         else
         {
            return null;
         }
      }
   }

   
   /**
   * Returns the ViewObject for which this control is displaying data.
   */
   public ViewObject getViewObject()
   {
      return getIteratorBinding().getViewObject();
   }


   /**
   * Returns the current RowIterator with which this control binding is working. 
   * This will return an instance of ViewCriteria object if the associated IteratorBinding
   * is in find mode. Otherwise, it returns an instance of RowSetIterator.
   */
   public RowIterator getRowIterator()
   {
      return (mIterBinding != null) ? getIteratorBinding().getNavigatableRowIterator() : null;
   }

   
   /**
   * Calls JUIteratorBinding.executeQuery which in turn executes the query to repopulate
   * the rows for the RowSet with which this control is working.
   */
   public void executeQuery()
   {
      getIteratorBinding().executeQuery();
   }

   /**
   * Calls JUIteratorBinding.executeQueryIfNeeded which in turn executes the query to repopulate
   * the rows for the RowSet with which this control is working, if it is not already executed.
   */
   public void executeQueryIfNeeded()
   {
      getIteratorBinding().executeQueryIfNeeded();
   }

   
   /**
   * Returns the current row for which this control is displaying data. In find mode, this will
   * return an instance of ViewCriteriaRow, whereas in data mode it returns a Row object.
   * This method should be used to get the current Row to which this control is bound in order
   * to perform any validations on the control-value or data stored in the row.
   */
   public Row getCurrentRow()
   {
      return getIteratorBinding().getCurrentRow();
   }

   
   /**
   * Returns the row of given range index.
   *
   * @param rangeIndex range index of the row.
   */
   public Row getRowAtRangeIndex(int rangeIndex)
   {
      return getIteratorBinding().getRowAtRangeIndex(rangeIndex);
   }

   
   /**
   * Returns the rows in current range in the RowIterator with which this control binding is working.
   */
   public Row[] getAllRowsInRange()
   {
      return getIteratorBinding().getAllRowsInRange();
   }

   
   /**
   * Gets the associated Swing control.
   */
   public Object getControl()
   {
      return mControl;
   }


   /**
   * *** For internal framework use only ***
   * <p>
   * Sets the associated Swing control.
   */
   void setControl(Object control)
   {
      mControl = control;
   }


   /**
   * *** For internal framework use only ***
   */
   public Object getLayoutObject()
   {
      return mControl;
   }

   /**
   * *** For internal framework use only ***
   * <p>
   * Returns true if this control can participate in find form. Note that some controls
   * like ProgressBar cannot participate in a find form as they do no accept user inputs.
   * By default this method returns false and it's up to the individual control bindings
   * to determine whether they can participate in a find mode.
   */
   protected boolean isControlQueriable()
   {
      return false;
   }

   /**
   * *** For internal framework use only ***
   * <p>
   * Updates the values in a control that is bound using an Iterator already in use.
   * (a valid row iterator)
   * If you do not call this method, your control won't update unless you refresh the Iterator.
   */
   public abstract void refreshControl();

   //not public as we don't anticipate individual controls to unbind from BC4J. It should
   //be done at the "Iterator" or "Panel" binding levels.
   void release()
   {
      //no need to disassociate from Control, as this is simply unbinding the JClient object
      //from BC4J. 
      setFormBinding(null);
      if (mIterBinding != null) 
      {
         mIterBinding = null;
      }
   }
}
