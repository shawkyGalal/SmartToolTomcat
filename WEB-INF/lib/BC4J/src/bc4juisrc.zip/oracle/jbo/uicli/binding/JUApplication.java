/*
 * @(#)JUApplication.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.uicli.binding;

import java.util.ArrayList;
import java.util.Locale;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Properties;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import oracle.jbo.ApplicationModule;
import oracle.jbo.ApplicationModuleCreateException;
import oracle.jbo.ApplicationModuleHome;
import oracle.jbo.InvalidObjNameException;
import oracle.jbo.NameClashException;
import oracle.jbo.Transaction;
import oracle.jbo.TransactionStateEvent;
import oracle.jbo.TransactionStateListener;
import oracle.jbo.JboException;
import oracle.jbo.JboExceptionHandler;
import oracle.jbo.JboWarning;
import oracle.jbo.common.JboNameUtil;
import oracle.jbo.uicli.mom.JUApplicationDefImpl;
import oracle.jbo.uicli.mom.JUMetaObjectBase;
import oracle.jbo.uicli.UIMessageBundle;

/**
 * The application class that manages connection to a 
 * BC4J Application Module. The JUApplication class provides:<p>
 * <ul>
 * <li>Methods to connect to a BC4J Application Module, if this application
 * is the root JUApplication object. JUApplications could be nested in other
 * JUApplication objects to mirror BC4J Nested Application Modules.
 * <li>Handles exceptions raised by the framework and passes it on
 * to registered Error handler. The error handler is same as registered
 * with the BC4J application module (if any). 
 * <li>Manages form bindings that contain iterator-bindings that 
 * bind iterators of the ViewObjects in the associated Application Module.
 * <li>If this JUApplication is the root, manages TransactionStateListeners
 * so that the BC4J Transaction's state events are passed on to the listeners.
 * <li>Routes all status bar messages to all status bars registered with 
 * this application. Framework uses this class to route all status bar messages.
 * </ul>
 * @version  PUBLIC
 * @see oracle.jbo.ApplicationModule
 * @see oracle.jbo.Transaction
 * @see JUTransactionStateListener
 * @see JUErrorHandler
 * 
 */
public class JUApplication
       implements TransactionStateListener
{
   private JUApplicationDefImpl mAppDef;
   private Hashtable mContext;
   private String mRootAMDefName;
   private String mDBConnectionURL;
   private Properties mDBConnectionProps;
   private String mPackageName;
   private ApplicationModule mAM;
   private boolean mIsRoot;
   private JUApplication mParent;
   private JUApplication mRootApplication;
   private Object mUserData;
   private String mName;

   private HashMap mFormBindings = new HashMap(2);
   private ArrayList mFormBindingList = new ArrayList(2);
   private JUErrorHandler mErrorHandler;
   private JUErrorHandler mErrorHandlerThrow;
   private boolean mErrorHandlerActive = true;
   
   /**
   * JUStatusBarInterface objects that are notified with status bar messages.
   **/
   protected ArrayList mStatusBarList;

   /**
   * JUTransactionStateListener objects that are notified of commit or rollback events
   * when generated from BC4J Application Module
   */
   protected ArrayList mTxnListeners;
   
   boolean mTxnModified = false;

   //todo:sung to doc the userdata stuff, package stuff - does this have to be public?

   // only added for design time.
   public JUApplication()
   {
   }

   /**
   * Constructs a root JUApplication object that connects to a BC4J Application Module
   * of the given name.
   * @param context Context to pass on to the BC4J Application Module on creation.
   * @param rootAMDefName Name that identifies the root BC4J Application Module.
   * @param userData Data to store with the JUApplication object.
   */
   public JUApplication(Hashtable context, String rootAMDefName, Object userData)
   {
      mContext = context;
      mRootAMDefName = rootAMDefName;
      
      mIsRoot = true;

      mParent = null;
      mRootApplication = this;

      mErrorHandlerThrow = new JUErrorHandlerThrow();
      mErrorHandler = mErrorHandlerThrow;
      mUserData = userData;
   }
   
   
   /**
   * Constructor used internally by the framework to associate an application module
   * with a JClient application object.
   */
   public JUApplication(ApplicationModule am)
   {
      this(null, am, null);
   }
   
   
   /**
   * Constructor to be used to create a nested JUApplication inside another JUApplication object.
   */
   public JUApplication(JUApplication parent, ApplicationModule am, Object userData)
   {
      mAM = am;

      mParent = parent;
      mIsRoot = (mParent == null);

      if (mIsRoot)
      {
         mRootAMDefName = mAM.getDefFullName();
         mRootApplication = this;

         //why do an extra roundtrip to check connectivity?
         //if (mAM.getTransaction().isConnected()) 
         {
            mAM.getTransaction().addTransactionStateListener(this);
         }
      }
      else
      {
         mRootApplication = mParent.getRootApplication();
      }

      mErrorHandlerThrow = new JUErrorHandlerThrow();
      mErrorHandler = mErrorHandlerThrow;
      mUserData = userData;
   }

   
   /**
   * *** For internal framework use only ***
   * Returns the instance name of this JUApplication object.
   */
   public final String getName()
   {
      return mName;
   }


   /**
   * *** For internal framework use only ***
   * <p>
   * Sets the instance name of this JUApplication Object
   */
   public final void setName(String name)
   {
      mName = name;
   }

   
   /**
   * *** For internal framework use only ***
   * <p>
   * Returns the definition object for this JUApplication
   */
   public final JUApplicationDefImpl getDef()
   {
      return mAppDef;
   }

   
   /**
   * *** For internal framework use only ***
   * <p>
   * Sets the definition object of this JUApplication Object
   */
   public final void setDef(JUApplicationDefImpl appDef)
   {
      mAppDef = appDef;
   }

   
   /**
   * *** Advanced method ***
   * <p>
   * Creates a connection to the BC4J application module. 
   */
   public void initialize()
   {
      if (mIsRoot)
      {
         createRootApplicationModule();
         loadPackage();
         connect();
      }
   }

   
   /**
   * This method is used by all framework binding objects to report
   * exceptions. If this JUApplication is not the root, it calls the
   * equivalent method on the root.
   * <p>
   * If the error handler is set to active state, then this method
   * calls the registered error handler's reportException method.
   * Othewise, it simply throws the given exception as a JboException.
   * @see JUErrorHandler
   * @see oracle.jbo.JboException
   */
   public final void reportException(JUFormBinding formBnd, Exception ex)
   {
      if (!mIsRoot)
      {
         getRootApplication().reportException(formBnd, ex);
      }
      else
      {
         if (mErrorHandlerActive)
         {
            if (mErrorHandler != null)
            {
               mErrorHandler.reportException(formBnd, ex);
            }
         }
         else
         {
            mErrorHandlerThrow.reportException(formBnd, ex);
         }
      }
   }
   

   /**
   * Returns the JUErrorHandler registered with the root JUApplication.
   * By default a JClient application has an instance of JUErrorHandlerDialog
   * registered as the default JUErrorHandler. 
   * @see oracle.jbo.uicli.jui.JUErrorHandlerDialog
   */
   public final JUErrorHandler getErrorHandler()
   {
      return getRootApplication().mErrorHandler;
   }

   
   /**
   * Registers a JUErrorHandler with the root JUApplication.
   * By default a JClient application has an instance of JUErrorHandlerDialog
   * registered as the default JUErrorHandler. 
   * Applications should use this method to register custom error handling
   * object so that all errors raised in the framework goes through the Application's
   * error handling object. Custom error handlers need to implement the JUErrorHandler
   * interface.
   * <p>
   * Custom error handlers may also implement oracle.jbo.JboExceptionHandler
   * to handle batched Exceptions raised during client-side processing
   * of Exceptions thrown in the Business Components tier. Alteratively
   * an application can register it's own JboExceptionHandler with the
   * Business Components ApplicationModule for this Application.
   * after the JUErrorHandler is set with JUApplication in this method.
   * <p>
   * Note that errors are sent to the registered error handler only when
   * the error handler state is marked active (which is true by default)
   * using the setErrorHandlerActive method.
   * @param errHandler An implementation of JUErrorHandler interface
   * that may optionally implement JboExceptionHandler interface too.
   * If errHandler implements the JboExceptionHandler, this method sets
   * it as the ExceptionHandler on the root ApplicationModule that this
   * client Application is connected with. Else, method sets a default 
   * ExceptionHandler which will collect all Exceptions
   * and throw a new JboException with these Exceptions set as in the new 
   * JboException's details list, for the errHandler to display
   * as one JboException with a bag of Exceptions.
   *
   * @see oracle.jbo.uicli.binding.JUErrorHandler
   * @see oracle.jbo.uicli.jui.JUErrorHandlerDialog
   * @see oracle.jbo.JboExceptionHanlder
   * @see oracle.jbo.ApplicationModule
   */
   public final void setErrorHandler(JUErrorHandler errHandler)
   {
      getRootApplication().mErrorHandler = errHandler;
      ApplicationModule am = getRootApplication().getApplicationModule();
      //if (am.getExceptionHandler() == null) 
      {
         if (errHandler instanceof JboExceptionHandler) 
         {
            am.setExceptionHandler((JboExceptionHandler)errHandler);
         }
         else
         {
            am.setExceptionHandler(new JboExceptionHandler()
            {
               ArrayList al = null;
               public void handleException(Exception ex, boolean lastEntryInPiggyback)
               {
                  if (al == null) 
                  {
                     al = new ArrayList(5);
                  }

                  al.add(ex);
               }

               public void handleWarning(JboWarning warn)
               {
                  if (oracle.jbo.common.Diagnostic.isOn()) 
                  {
                     oracle.jbo.common.Diagnostic.println(warn.getMessage());
                  }
               }

               public void finishedProcessingPiggyback(Exception[] exArray)
               {
                  if (al != null && al.size() > 0)
                  {
                     JboException ex = new JboException(UIMessageBundle.class,
                                                        UIMessageBundle.EXC_SYNC_ERROR,
                                                        null,
                                                        (Exception[])al.toArray(new Exception[al.size()]));
                     al = null;
                     throw ex;  //so that JUI can catch and call reportException.
                  }
               }
            }
            );
         }
      }
   }

   
   /**
   * Returns the error-handler active state of the root JUApplication object.
   * This is used to control whether to throw an exception raised by the framework
   * (which is used by automated regression tests to trap exceptions and log them).
   * By default the state is set to true - meaning raise all exceptions via the 
   * registered error handler.
   */
   public final boolean getErrorHandlerActive()
   {
      return getRootApplication().mErrorHandlerActive;
   }

   
   
   /**
   * *** Advanced method ***
   * <p>
   * Sets the error-handler active state of the root JUApplication object.
   * This is used to control whether to throw an exception raised by the framework
   * (which is used by automated regression tests to trap exceptions and log them).
   * By default the state is set to true - meaning raise all exceptions via the 
   * registered error handler.
   */
   public final void setErrorHandlerActive(boolean b)
   {
      getRootApplication().mErrorHandlerActive = b;
   }

   
   /**
   * *** Advanced method ***
   * <p>
   * If this JUAppication is root, and the root's application module is not created,
   * this method creates a root BC4J Application Module using the root application module
   * def name and the context information (both passed to the constructor of the root JUApplication).
   * @see oracle.jbo.ApplicationModule
   * @see oracle.jbo.ApplicationModuleHome#create
   * @throws oracle.jbo.ApplicationModuleCreateException if the application module is not
   * created, perhaps due to an improper root application module name.
   */
   public final void createRootApplicationModule()
   {
      if (!mIsRoot)
      {
         return;
      }

      if (mAM == null) 
      {
      
         if (mRootAMDefName == null || mRootAMDefName.length() == 0)
         {
            mRootAMDefName = ApplicationModule.DEFAULT_DEF_FULL_NAME;
         }
   
         try
         {
            Context ic = new InitialContext(mContext);
            ApplicationModuleHome home = (ApplicationModuleHome) ic.lookup(mRootAMDefName);
   
            mAM = home.create();
         }
         catch(NamingException ex)
         {
            throw new ApplicationModuleCreateException(ex);
         }
      }
   }


   /**
   * If this JUApplication is the root, and it has a BC4J package, it needs to preload.
   * This method could be used to load the BC4J package object by name. Use setPackageName() method
   * to set the package name to be loaded in this method. This method should be used
   * to preload the BC4J package metadata with which this application may work. 
   */
   final void loadPackage()
   {
      if (mIsRoot && mPackageName != null && mPackageName.length() != 0)
      {
         mAM.getSession().loadPackage(mPackageName);
      }
   }

   
   /**
   * If this application is root, this method invokes the corresponding BC4J Transaction's
   * connect() method to create a database connection. Also this method is used
   * to register the application as a TransactionStateListener on the BC4J Transaction object.
   */
   void connect()
   {
      if (mIsRoot)
      {
         mAM.getTransaction().connect(mDBConnectionURL, mDBConnectionProps);   
         mAM.getTransaction().addTransactionStateListener(this);
      }
   }

   
   /**
   * Returns the context object with which the root JUApplication was created.
   */
   public final Hashtable getContext()
   {
      return getRootApplication().mContext;
   }
   
   
   /**
   * Returns root JUApplication's ApplicationModule definition name.
   */
   public final String getRootAMDefName()
   {
      return getRootApplication().mRootAMDefName;
   }

   
   /**
   * *** For internal framework use only ***
   */
   public final String getDBConnectionURL()
   {
      return mDBConnectionURL;
   }

   
   /**
   * *** For internal framework use only ***
   */
   public final Properties getDBConnectionProps()
   {
      return mDBConnectionProps;
   }

   
   /**
   * *** For internal framework use only ***
   */
   public final void setConnectionInfo(String dbConnectionURL, Properties dbConnectionProps)
   {
      mDBConnectionURL = dbConnectionURL;
      mDBConnectionProps = dbConnectionProps;
   }
   
   
   /**
   * *** For internal framework use only ***
   */
   public final String getPackageName()
   {
      return mPackageName;
   }


   /**
   * *** For internal framework use only ***
   */
   public final void setPackageName(String packageName)
   {
      mPackageName = packageName;
   }
   
   
   /**
   * Returns the locale for this Application
   */
   public final Locale getLocale()
   {
      ApplicationModule am = getApplicationModule();
      if (am != null) 
      {
         return am.getSession().getLocaleContext().getLocale();
      }
      return null;
   }
   
   /**
   * Helper method that sets the locale in the current Application Module's session.
   */
   public final void setLocale(Locale locale)
   {
      ApplicationModule am = getApplicationModule();
      if (am != null) 
      {
         am.getSession().setLocale(locale);
         return;
      }
      oracle.jbo.common.Diagnostic.println("Warning : No Application Module to set the locale!");
   }

   /**
   * Returns the associated oracle.jbo.ApplicationModule object
   */
   public final ApplicationModule getApplicationModule()
   {
      return mAM;
   }

   
   /**
   * Returns true if this JUApplication is the root JUApplication. Root JUApplication
   * is responsible for establishing connection to a BC4J root Application Module and Transaction
   * objects.
   */
   public final boolean isRoot()
   {
      return mIsRoot;
   }

   
   /**
   * Returns the container JUApplication object if any. This should be null in case this
   * application object is the root.
   */
   public final JUApplication getParent()
   {
      return mParent;
   }

   
   /**
   * Returns the root JUApplication object.
   */
   public final JUApplication getRootApplication()
   {
      return mRootApplication;
   }

   
   /**
   * *** For internal framework use only ***
   */
   public final Object getUserData()
   {
      return mUserData;
   }

   
   /**
   * Remove the JUFormBinding object of the given name (if any).
   */
   public final void removeFormBinding(JUFormBinding formBnd)
   {
      String name = formBnd.getName();
      Object obj = mFormBindings.get(name);
      if (obj != null) 
      {
         mFormBindings.remove(name);
         mFormBindingList.remove(obj);
      }

      //remove this stuff from HashMap
      //todo:sung shouldn't this method also disassociate/disconnect
      //all the iterators in the form from their VOs?
   }

   /**
   * Register the given form binding object with this application. If this
   * form binding object has no name or null name, framework generates a unique
   * name for the object (in the context of this application module).
   * @ throw oracle.jbo.NameClasException If there is another object of the same name already registered, this 
   * method will throw this exception.
   */
   public final void addFormBinding(JUFormBinding formBnd)
   {
      addFormBinding(formBnd.getName(), formBnd);
   }
   
   
   /**
   * Register the given form binding object with this application with the given name.
   * @ throw oracle.jbo.InvalidObjNameException If the given name does not follow the BC4J component or Java Identifier
   * naming rules.
   * @ throw oracle.jbo.NameClasException If there is another object of the same name already registered, this 
   * method will throw this exception.
   * @ see oracle.jbo.common.JboNameUtil#isNameValid
   */
   public final void addFormBinding(String name, JUFormBinding formBnd)
   {
      addOrCreateFormBinding(name, formBnd, null, false);
   }
   

   JUFormBinding addOrCreateFormBinding(String name, JUFormBinding formBnd,
                                        JUFormDef formDef, boolean initialize)
   {
      boolean genFormName = (name == null);

      while (true)
      {
         if (genFormName)
         {
            name = JUUtil.generateFormName(formBnd);
         }
         else  if (!JboNameUtil.isNameValid(name))
         {
            throw new InvalidObjNameException(JUMetaObjectBase.TYP_FORM_BINDING,
                                              name);
         }

         if (mFormBindings.get(name) != null)
         {
            if (!genFormName)
            {
               throw new NameClashException(JUMetaObjectBase.TYP_FORM_BINDING,
                                            name);
            }
         }
         else
         {
            break;
         }
      }

      if (formBnd == null)
      {
         formBnd = formDef.createFormBinding();
         formBnd.assignApplication(this);

         if (initialize)
         {
            formBnd.initializeFromDef(getApplicationModule());
         }
      }
      else
      {
         formBnd.assignApplication(this);
      }
      
      if (formBnd.getName() == null)
      {
         formBnd.setName(name);
      }

      mFormBindingList.add(formBnd);
      mFormBindings.put(name, formBnd);

      return formBnd;
   }


   /**
   * Return the JUFormBinding instance registered with this JUAppication with the given name.
   * If the name does not match, return null.
   */
   public final JUFormBinding findFormBinding(String name)
   {
      return (JUFormBinding) mFormBindings.get(name);
   }


   /**
   * *** For internal framework use only ***
   * <p>
   * Create a JUFormBinding instance using the given name and form definition.
   */
   public final JUFormBinding createFormBinding(String name, String formDefName, boolean initialize)
   {
      return addOrCreateFormBinding(name, null, JUFormDef.findDefObject(formDefName), initialize);
   }

   
   /**
   * *** For internal framework use only ***
   */
   public final void initializeFormFromDef(String name)
   {
      findFormBinding(name).initializeFromDef(getApplicationModule());
   }

   /**
   * Add the given status bar object to this application's list.
   * Messages sent via displayMessage method will be given out to all 
   * registered status bar instances.
   */
   public final void addStatusBarInterface(JUStatusBarInterface statusBar)
   {
      if (mStatusBarList == null) 
      {
         mStatusBarList = new ArrayList(5);
      }
      mStatusBarList.add(statusBar);
   }

   /**
   * Remove the given instance of status bar interface if found.
   */
   public final void removeStatusBarInterface(JUStatusBarInterface statusBar)
   {
      if (mStatusBarList != null) 
      {
         mStatusBarList.remove(statusBar);
      }
   }

   /**
   * Send the given message Id and parameter list along with the current iterator binding object
   * to all status bar instances registered with this Application. This method is used by the
   * framework to display status bar messages from the oracle.jbo.uicli.UIMessageBundle
   */
   public final void displayStatus(JUIteratorBinding iterBinding, String msgId, Object[] params)
   {
      if (mStatusBarList != null) 
      {
         ArrayList al = mStatusBarList;
         for (int i = 0; i < al.size(); i++) 
         {
            ((JUStatusBarInterface)al.get(i)).displayStatus(iterBinding, msgId, params); 
         }
      }
   }

   /**
   * Send the given message to all status bar interface objects registered with this application.
   */
   public final void displayStatus(String msg)
   {
      if (mStatusBarList != null) 
      {
         ArrayList al = mStatusBarList;
         for (int i = 0; i < al.size(); i++) 
         {
            ((JUStatusBarInterface)al.get(i)).displayStatus(msg); 
         }
      }
   }

   /**
   * *** For internal framework use only ***
   * This method is used by the framework to display currency information in the status bars.
   * When a control bound to a given attribute for a given iterator binding gets focus, this
   * method is invoked to update all status bars.
   */
   public final void focusGained(JUIteratorBinding iterBinding, JUControlBinding binding, int attrIndex)
   {
      if (mStatusBarList != null) 
      {
         ArrayList al = mStatusBarList;
         for (int i = 0; i < al.size(); i++) 
         {
            ((JUStatusBarInterface)al.get(i)).focusGained(iterBinding, binding, attrIndex);
         }
      }
   }

   /**
   * Helper method that invokes beforeSaveTransaction event on all JUPanelBinding
   * objects and then invokes the BC4J transaction's commit() method to save 
   * all changes to the database.
   */
   public final void commitTransaction()
   {
      oracle.jbo.Transaction txn = getApplicationModule().getTransaction();

      for (int i = 0; i < mFormBindingList.size(); i++) 
      {
         ((JUFormBinding)mFormBindingList.get(i)).callBeforeSaveTransaction(txn);
      }

      txn.commit();
   }  

   /**
   * Helper method that invokes rollback on the current Transaction.
   */
   public final void rollbackTransaction()
   {
      getApplicationModule().getTransaction().rollback();
   }

   /**
   * Returns true if this JUApplication has modified attribute values.
   */
   public final boolean isTransactionModified()
   {
      return mTxnModified;
   }

   /**
   * If this transaction is not in modified state, this method sets it to
   * a modified state. This method is invoked in the framework to set the
   * transaction state to modified status. Also all JUTransactionStateListeners
   * are notified of this state-change so that status bars and navigation bars
   * could update their display.
   */
   public final void setTransactionModified()
   {
      if (!mTxnModified) 
      {
         //set the transaction to modified state and let listeners know about that.
         //this is dirtying the listeners from the client side without consulting
         //the middle tier transaction state as one may not have gone to the 
         //middle tier but have changes in the clientside cache.
         mTxnModified = true;
         if (mTxnListeners != null) 
         {
            ArrayList al = mTxnListeners;
            for (int i = 0; i < al.size(); i++) 
            {
               ((JUTransactionStateListener)al.get(i)).transactionStateChanged(true);
            }
         }
      }
   }

   /**
   * Use this method to notify all transaction state change listeners of the change
   */
   public final void transactionStateChanged(boolean state)
   {
      if (state != mTxnModified) 
      {
         mTxnModified = state;
         if (mTxnListeners != null) 
         {
            ArrayList al = mTxnListeners;
            for (int i = 0; i < al.size(); i++) 
            {
               ((JUTransactionStateListener)al.get(i)).transactionStateChanged(state);
            }
         }
      }
   }
   
   /**
   * Adds listeners like StatusBar and NavigationBars that have to listen and react
   * to transaction's modified state. 
   */
   public final void addTransactionStateListener(JUTransactionStateListener statusBar)
   {
      if (mTxnListeners == null) 
      {
         mTxnListeners = new ArrayList(5);
      }
      mTxnListeners.add(statusBar);
   }

   /**
   * Remove the given object from JUTransactionStateListener list.
   */
   public final void removeTransactionStateListener(JUTransactionStateListener statusBar)
   {
      if (mTxnListeners != null) 
      {
         mTxnListeners.remove(statusBar);
      }
   }

   /**
    * Implementation of oracle.jbo.TransactionStateListener interface.
    * Sends the transactionStateChanged event to all JUTransactionStateListeners
    * registered with this application.
    * @param event A description of the event.
    */
   public final void doneCommit(TransactionStateEvent event)
   {
      transactionStateChanged(false); //txn clean so, send in false
   }

   /**
    * Implementation of oracle.jbo.TransactionStateListener interface.
    * Sends the transactionStateChanged event to all JUTransactionStateListeners
    * registered with this application.
    * @param event A description of the event.
    */
   public final void doneRollback(TransactionStateEvent event)
   {
      transactionStateChanged(false); //txn clean so, send in false
   }

   public void release()
   {
      ArrayList al;
      if (mStatusBarList != null) 
      {
         al = (ArrayList)mStatusBarList.clone();
         JUStatusBarInterface sb;
         for (int i = 0; i < al.size(); i++)
         {
            sb = (JUStatusBarInterface)al.get(i);
            sb.release();
         }
         mStatusBarList = null;
      }

      if (mTxnListeners != null) 
      {
         al = (ArrayList)mTxnListeners.clone();
         JUTransactionStateListener sb;
         for (int i = 0; i < al.size(); i++)
         {
            sb = (JUTransactionStateListener)al.get(i);
            sb.release();
         }
         mTxnListeners = null;
      }

      JUFormBinding form;
      al = (ArrayList)mFormBindingList.clone();
      for (int i = 0; i < al.size(); i++)
      {
         form = (JUFormBinding)al.get(i);
         form.release();
      }

      mFormBindings = new HashMap(2);
      mFormBindingList = new ArrayList(2);


      if (mIsRoot)
      {
         if (mAM != null) 
         {
            if (mAM.getTransaction().isConnected()) 
            {
               mAM.getTransaction().removeTransactionStateListener(this);
            }
            oracle.jbo.uicli.mom.JUMetaObjectManager.releaseApplicationObject(this);
         }
      }
   }

}       
