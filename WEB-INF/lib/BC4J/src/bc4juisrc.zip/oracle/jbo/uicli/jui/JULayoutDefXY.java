/*
 * @(#)JULayoutDefXY.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.uicli.jui;

import java.util.HashMap;
import oracle.jbo.mom.xml.DefElementImpl;
import oracle.jbo.mom.xml.DefPersistenceException;
import oracle.jbo.mom.xml.DefWriter;
import oracle.jbo.uicli.layout.JULayoutDef;
import oracle.jdeveloper.layout.XYConstraints;
import oracle.jdeveloper.layout.XYLayout;

public class JULayoutDefXY extends JULayoutDef
{
   private int mWidth = 0;
   private int mHeight = 0;
   // private boolean mIsWidthSet = false;
   // private boolean mIsHeightSet = false;

   private static final String PNAME_Width = "Width";
   private static final String PNAME_Height = "Height";
   
   
   public JULayoutDefXY()
   {
      super(XYLayout.class.getName(), XYConstraints.class.getName());
   }


   public JULayoutDefXY(String layoutClassName, String layoutConsClassName)
   {
      super(layoutClassName, layoutConsClassName);
   }


   public void init(HashMap initValues)
   {
      super.init(initValues);
      
      Object val;
      
      if ((val = initValues.get(PNAME_Width)) != null)
      {
         mWidth = convertToInt(val);
         // mIsWidthSet = true;
      }
      
      if ((val = initValues.get(PNAME_Height)) != null)
      {
         mHeight = convertToInt(val);
         // mIsHeightSet = true;
      }
   }
   
   
   public int getWidth()
   {
      return mWidth;
   }

   
   public void setWidth(int width)
   {
      mWidth = width;
      // mIsWidthSet = true;
   }

   
   public int getHeight()
   {
      return mHeight;
   }

   
   public void setHeight(int height)
   {
      mHeight = height;
      // mIsHeightSet = true;
   }

   
   public Object createLayout()
   {
      XYLayout layout = new XYLayout();

      // int w = layout.getWidth();
      // int h = layout.getHeight();

      if (mWidth > 0)
      {
         layout.setWidth(mWidth);
      }
      if (mHeight > 0)
      {
         layout.setHeight(mHeight);
      }

      return layout;
   }

   
   protected void retrieveFromXML(DefElementImpl xmlElement, HashMap valueTab)
   {
      super.retrieveFromXML(xmlElement, valueTab);

      readXMLString(xmlElement, PNAME_Width, valueTab);
      readXMLString(xmlElement, PNAME_Height, valueTab);
   }

   
   public void writeContents(DefWriter jos)
      throws DefPersistenceException
   {
      super.writeContents(jos);
      
      // if (mIsWidthSet)
      if (mWidth > 0)
      {
         jos.writeInt(PNAME_Width, getWidth());
      }
      // if (mIsHeightSet)
      if (mHeight > 0)
      {
         jos.writeInt(PNAME_Height, getHeight());
      }
   }
}
