/*
 * @(#)JUSpinnerBinding.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.uicli.jui;

import java.awt.Component;

import java.lang.reflect.Constructor;


import java.util.Arrays;
import java.util.ArrayList;
import java.util.Date;
import java.util.Calendar;
import java.sql.Timestamp;

import java.text.SimpleDateFormat;
import java.text.DecimalFormat;

import javax.swing.JPanel;
import javax.swing.JSpinner;
import javax.swing.SpinnerModel;
import javax.swing.SpinnerListModel;
import javax.swing.SpinnerNumberModel;
import javax.swing.SpinnerDateModel;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;


import oracle.jbo.AttributeDef;
import oracle.jbo.AttributeHints;
import oracle.jbo.LocaleContext;
import oracle.jbo.Row;
import oracle.jbo.RowIterator;
import oracle.jbo.ViewObject;
import oracle.jbo.NavigationEvent;

import oracle.jbo.uicli.binding.JUFormBinding;
import oracle.jbo.uicli.binding.JUIteratorBinding;
import oracle.jbo.uicli.binding.JUCtrlListBinding;

/**
* Implements binding for JSpinner control.
* 
* JSpinner can be bound in the following ways:
* <ul>
* <li>Display a single attribute for rows in a RowSet and iterate the rowset currency</li>
* <li>Display a single attribute from rows in a RowSet and update another attribute
* in the same ViewObject</li>
* <li>Display single attribute from rows in a RowSet and update another attribute in a different ViewObject (similar to an LOV).
* <li>Display a static LOV and update an attribute in a BC4J row.</li>
* </ul>
* <p>
*/
public class JUSpinnerBinding extends JUCtrlListBinding
{
    protected SpinnerModel modelImpl;

    protected boolean mValueUpdating = false;

    static private String DEFAULT_DATE_FORMAT_STR = "MM-dd-yyyy";
    static private String DEFAULT_NUMERIC_FORMAT_STR = "#0.##"; 

    /**
    * Use this binding when the JSpinner control is used as a navigation control to 
    * iterate through a range of rows in a RowSet.
    *
    * <p>
    * @param formBinding The containing JUPanelBinding in which the given iterator binding
    * would be found/created.
    * @param control The control instance which should be bound to a ViewObject's attribute.
    * @param voInstanceName Name of the instance of the ViewObject in a BC4J ApplicationModule.
    * @param voIterName Runtime instance name of the iterator in the ViewObject (optional).
    * @param voIterBindingName Instance name of the iterator binding that uniquely identifies an
    * iterator binding object used to read data in this given JUPanelBinding instance.
    * @param attrName The name of the attribute of this ViewObject rows that contain data
    * to display/edit in the associated text control.
    * @return JUSpinnerBinding An instance of control binding that works with the given JSpinner.
    */
    public static SpinnerModel createNavigationBinding(  
                JUFormBinding    formBinding, 
                JSpinner         control,
                String           voInstanceName,
                String           voIterName, // temporarily taking nulls for this
                String           voIterBindingName,
                String[]         voAttrNames
            )
    {

        if (!JUIUtil.inDesignTime())
        {

            JUIteratorBinding iterBinding = 
                formBinding.getRowIterBinding(voInstanceName, voIterName, voIterBindingName);


            JUSpinnerBinding binding = new JUSpinnerBinding(control, iterBinding, voAttrNames, 
                                                        LIST_OPER_NAVIGATE);

            
            SpinnerModel m = binding.getModelImpl();

            control.setModel(m);

            binding.refreshNow();

            return m;
        }
        else
        {
            try
            {
                Class clazz = Class.forName("oracle.jbo.dt.ui.jui.propertyeditors.dtmodels.DTJSpinnerNavigationBinding");
                Constructor constructor = clazz.getConstructors()[0];
    
                String firstAttribute = "";

                if (voAttrNames != null && voAttrNames.length != 0)
                   firstAttribute = voAttrNames[0];

                int size = (voAttrNames == null) ? 0 : voAttrNames.length;

                StringBuffer stbuf = new StringBuffer(firstAttribute);

                for (int i=1; i<size; i++)
                {
                   stbuf.append(",");
                   stbuf.append(voAttrNames[i]);
                }
    
                Object [] args = { voInstanceName + "." + stbuf.toString() };

                Object object = constructor.newInstance(args);

                return (SpinnerModel)object; 
            }
            catch (Exception e)
            {
                return null;
            }
        }
    }

    /**
    * Use this binding when the JSpinner control is used in LOV mode to update another 
    * attribute in a BC4J View Object.
    *
    * <p>
    * @param formBinding The containing JUPanelBinding in which the given iterator binding
    * would be found/created.
    * @param control The control instance which should be bound to a ViewObject's attribute.
    * @param voInstanceName Name of the instance of the ViewObject in a BC4J ApplicationModule.
    * @param voIterName Runtime instance name of the iterator in the ViewObject (optional).
    * @param voIterBindingName Instance name of the iterator binding that uniquely identifies an
    * iterator binding object used to read/write data in this given JUPanelBinding instance.
    * @param attrNames The name of the attribute of this ViewObject rows that contain data
    * to display/edit in the associated control.
    * @param listVOInstanceName list View Object instance name
    * @return JUSpinnerBinding An instance of control binding that works with the given JSpinner.
    */
    public static SpinnerModel createLovBinding(
                JUFormBinding formBinding, 
                JSpinner      control,
                String        voInstanceName,
                String        voIterName, // temporarily taking nulls for this
                String        voIterBindingName,
                String[]      attrNames,
                String        listVOInstanceName )
    {
         return createLovBinding(
                 formBinding, control, voInstanceName, voIterName, 
                 voIterBindingName, attrNames, listVOInstanceName, attrNames, null);
        
    }

    /**
    * Use this binding when two ViewObjects are to be used in this Spinner control: one for displaying 
    * of values and the other ViewObject whose rows are updated.
    */
    public static SpinnerModel createLovBinding(
            JUFormBinding    formBinding, 
            JSpinner         control,
            String           voInstanceName,
            String           voIterName, // temporarily taking nulls for this
            String           voIterBindingName,
            String[]         voAttrNames, //target vo attribute names 
            String           lovVOInstanceName,
            String[]         lovVOAttrNames, //source vo attribute names
            String[]         lovVODisplayedAttrNames)
    {
        
    	if (!JUIUtil.inDesignTime())
        {
    	    JUIteratorBinding binding = (voInstanceName != null)
    				       ? formBinding.getRowIterBinding(voInstanceName, voIterName, voIterBindingName)
    				       : null;
        
    	    JUIteratorBinding listValuesBinding = (lovVOInstanceName != null) 
    				       ? formBinding.getRangeIterBinding(lovVOInstanceName, null, null, -1)
    				       : null;
        
    	    
    	    AttributeDef ad;
    	    ArrayList adList = null;
    	    int i = 0;
    	     
    	    AttributeDef ads[] = (listValuesBinding != null) 
    				   ? listValuesBinding.getViewObject().getAttributeDefs() 
    				   : new AttributeDef[0]; 
        
    	    int count = ads.length;
    	    adList = new ArrayList(count);
    		
    	    if (lovVODisplayedAttrNames == null)
    	    {
    		    int kind;
    		    ArrayList al = null;
    		    al = new ArrayList(count); 
    		    for (i = 0; i < count; i++)
    		    {
    		        ad = ads[i];
    		        kind = ad.getAttributeKind();
    		        if (kind == ad.ATTR_ASSOCIATED_ROWITERATOR
    		            || kind == ad.ATTR_ASSOCIATED_ROW)
    		        {
    		            continue;
    		        }
    		        al.add(ad.getName());
    		        adList.add(ad);
    		    }
        
    		    lovVODisplayedAttrNames = (String[])al.toArray(new String[al.size()]);
    	     }
    	     else if (listValuesBinding != null)
    	     {
    		    ViewObject vo = listValuesBinding.getViewObject();
    		    for (i = 0; i < lovVODisplayedAttrNames.length; i++)
    		    {
    		        ad = vo.findAttributeDef(lovVODisplayedAttrNames[i]) ;
    		        if (ad != null)
    		        {
    		            adList.add(ad);
    		        }
    		    }
    	     }
    	     
    	    
    	    JUSpinnerBinding spBinding = new JUSpinnerBinding(
        		control, binding, voAttrNames, 
        		listValuesBinding, lovVOAttrNames, 
        		lovVODisplayedAttrNames);
        
            SpinnerModel m = spBinding.getModelImpl();
    
            spBinding.refreshNow();
    
    	    return m;
            
    	}// if (!JUIUtil.inDesignTime())
        else
    	{
    	     try
    	     {
    	           String defClassName = "oracle.jbo.dt.ui.jui.propertyeditors.dtmodels.DTJLovBindingDef";
    
    		       Class defClazz = Class.forName(defClassName); 
    
    		       java.lang.reflect.Constructor defConstructor = defClazz.getConstructors()[0];
    
    		       Object [] defArgs = { lovVOInstanceName, lovVODisplayedAttrNames, 
    			     voInstanceName, lovVOAttrNames, voAttrNames };
        
    		       String bndClassName = "oracle.jbo.dt.ui.jui.propertyeditors.dtmodels.DTJSpinnerLovBinding";
    
    		       Class clazz = Class.forName(bndClassName);
    
    		       java.lang.reflect.Constructor constructor = clazz.getConstructors()[0];
    
            	   Object [] args = { defConstructor.newInstance(defArgs) };
    
           		   Object object = constructor.newInstance(args);
    
    		       return (SpinnerModel)object;
    	     }
    	     catch (Exception e)
    	     {
    		       return null;
    	     }
    	}
    }

   /**
   * Use this method to bind a JSpinner control to a ViewObject/RowSet, identified by voInstanceName.
   * The values for the spinner is specified as a static list of values. The control is used to 
   * display/update a particular attribute in a ViewObject.
   *<p/>
   * @param formBinding The containing JUPanelBinding in which the given iterator binding
   * would be found/created.
   * @param control The control instance which should be bound to a ViewObject's attribute.
   * @param voInstanceName Name of the instance of the ViewObject in a BC4J ApplicationModule.
   * @param voIterName Runtime instance name of the iterator in the ViewObject (optional).
   * @param voIterBindingName Instance name of the iterator binding that uniquely identifies an
   * iterator binding object used to read data in this given JUPanelBinding instance.
   * @param attrName The name of the attribute of this ViewObject to update
   * @param values   static list of values for the spinner
   *
   * @return Object that can be used as model for JSpinner and can display/update
   *         attribute in BC4J ViewOject.
   */
   public static SpinnerModel createEnumerationBinding(
            JUFormBinding formBinding, 
            JSpinner      control,
            String        voInstanceName,
            String        voIterName, // temporarily taking nulls for this
            String        voIterBindingName,
            String        attrName,
            Object        values[] )
    {

       if (!JUIUtil.inDesignTime())
       {

    	 JUIteratorBinding iterBinding = formBinding.getRowIterBinding(
                       voInstanceName, voIterName, voIterBindingName);
    
    
    	 JUSpinnerBinding binding = new JUSpinnerBinding(
                control, iterBinding, new String[]{attrName},values);

         SpinnerModel m = binding.getModelImpl();

         binding.refreshNow();

         return m;
       }
       else
       {
         try
         {
            StringBuffer buf = new StringBuffer(voInstanceName).append(".").append(attrName);

            Object [] args = { buf.toString(), values };

	        String bndClassName = 
		        "oracle.jbo.dt.ui.jui.propertyeditors.dtmodels.DTJSpinnerEnumBinding";

            Class clazz = Class.forName(bndClassName);

            java.lang.reflect.Constructor constructor = clazz.getConstructors()[0];

            Object object = constructor.newInstance(args);

            return (SpinnerModel)object;
         }
         catch (Exception e)
         {
            return null;
         }
       }

    }

   /**
   * Use this method to bind a JSpinner control to a ViewObject/RowSet, identified by voInstanceName.
   * The model object returned extends SpinnerListModel. The list of values for the JSpinner 
   * is specified through an instance of SpinnerListModel.
   * <p/>
   * @param formBinding The containing JUPanelBinding in which the given iterator binding
   * would be found/created.
   * @param control The control instance which should be bound to a ViewObject's attribute.
   * @param voInstanceName Name of the instance of the ViewObject in a BC4J ApplicationModule.
   * @param voIterName Runtime instance name of the iterator in the ViewObject (optional).
   * @param voIterBindingName Instance name of the iterator binding that uniquely identifies an
   * iterator binding object used to read data in this given JUPanelBinding instance.
   * @param attrName The name of the attribute of this ViewObject to update
   * @param slm instance of SpinnerNumberModel which provides the range of value
   * for the spinner as well as the step size.
   *
   * @return Object that can be used as model for JSpinner and can display/update
   *         attribute in BC4J ViewOject.
   */
   public static SpinnerModel createEnumerationBinding(
            JUFormBinding formBinding, 
            JSpinner      control,
            String        voInstanceName,
            String        voIterName, // temporarily taking nulls for this
            String        voIterBindingName,
            String        attrName,
            SpinnerListModel slm )
    {
        JUIteratorBinding iterBinding = formBinding.getRowIterBinding(
             voInstanceName, voIterName, voIterBindingName);
 
 
        JUSpinnerBinding binding = new JUSpinnerBinding(control, iterBinding, 
                                                 new String[]{ attrName}, 
                                                 slm);
        SpinnerModel m = binding.getModelImpl();

        control.setModel(m);

        binding.refreshNow();

 
        return m; 
    }

    /**
   * Use this method to bind a JSpinner control to a ViewObject/RowSet, identified by voInstanceName.
   * The model object returned extends SpinnerDateModel. This method also sets an instance of  
   * JSpinner.DateEditor as the editor for the control. The format string UI hint defined in the 
   * middle tier is used as default format for the editor. The range of values for the JSpinner and 
   * the step size is specified through an instance of SpinnerDateModel.
   *<p/>
   * @param formBinding The containing JUPanelBinding in which the given iterator binding
   * would be found/created.
   * @param control The control instance which should be bound to a ViewObject's attribute.
   * @param voInstanceName Name of the instance of the ViewObject in a BC4J ApplicationModule.
   * @param voIterName Runtime instance name of the iterator in the ViewObject (optional).
   * @param voIterBindingName Instance name of the iterator binding that uniquely identifies an
   * iterator binding object used to read data in this given JUPanelBinding instance.
   * @param attrName The name of the attribute of this ViewObject to update
   * @param sdm instance of SpinnerDateModel which provides the range of value
   * for the spinner as well as the step size.
   *
   * @return Object that can be used as model for JSpinner and can display/update
   *         attribute in BC4J ViewOject.
   */

    public static SpinnerModel createEnumerationBinding(
            JUFormBinding    formBinding, 
            JSpinner      control,
            String        voInstanceName,
            String        voIterName, // temporarily taking nulls for this
            String        voIterBindingName,
            String        attrName,
            SpinnerDateModel sdm )
    {
        JUIteratorBinding iterBinding = formBinding.getRowIterBinding(
                                   voInstanceName, voIterName, voIterBindingName);


        JUSpinnerBinding binding = new JUSpinnerBinding(control, iterBinding, 
                                                        new String[]{ attrName}, 
                                                        sdm);

        String fmt = binding.getDateFormatString(attrName);

        SpinnerModel m = binding.getModelImpl();

        control.setModel(m);

        control.setEditor( new JSpinner.DateEditor(control, fmt));

        binding.refreshNow();

        return m;
    }

    
   /**
   * Use this method to bind a JSpinner control to a ViewObject/RowSet, identified by voInstanceName.
   * The model object returned extends SpinnerNumberModel. This method also sets an instance of  
   * JSpinner.NumberEditor as the editor for the control. The format string UI hint defined in the 
   * middle tier is used as default format for the editor. The range of values for the JSpinner and 
   * the step size is specified through an instance of SpinnerNumberModel.
   *<p/>
   * @param formBinding The containing JUPanelBinding in which the given iterator binding
   * would be found/created.
   * @param control The control instance which should be bound to a ViewObject's attribute.
   * @param voInstanceName Name of the instance of the ViewObject in a BC4J ApplicationModule.
   * @param voIterName Runtime instance name of the iterator in the ViewObject (optional).
   * @param voIterBindingName Instance name of the iterator binding that uniquely identifies an
   * iterator binding object used to read data in this given JUPanelBinding instance.
   * @param attrName The name of the attribute of this ViewObject to update
   * @param slm instance of SpinnerNumberModel which provides the range of value
   * for the spinner as well as the step size.
   *
   * @return Object that can be used as model for JSpinner and can display/update
   *         attribute in BC4J ViewOject.
   */
   public static SpinnerModel createEnumerationBinding
        (
            JUFormBinding formBinding, 
            JSpinner      control,
            String        voInstanceName,
            String        voIterName, // temporarily taking nulls for this
            String        voIterBindingName,
            String        attrName,
            SpinnerNumberModel snm)
    {
        JUIteratorBinding iterBinding = formBinding.getRowIterBinding(
                   voInstanceName, voIterName, voIterBindingName);


        JUSpinnerBinding binding = new JUSpinnerBinding(control, iterBinding, 
                                                        new String[]{ attrName}, 
                                                        snm);
        
        String fmt = binding.getNumericFormatString(attrName);

        SpinnerModel m = binding.getModelImpl();

        control.setModel(m);

        control.setEditor( new JSpinner.NumberEditor(control, fmt));
        
        binding.refreshNow();

        return binding.getModelImpl();
    }
    

    /**
    * JUSpinnerBinding to be used in Navigation mode.
    *
    * <p>
    * @param control The control instance which should be bound to a ViewObject's attribute.
    * @param iterBinding iterator binding to use
    * @param attrName The name of the attribute of this ViewObject to display
    */
    public JUSpinnerBinding(JSpinner control, 
            JUIteratorBinding iterBinding,
            String[] attrNames, 
            int listOperMode )
    {
        super(control, iterBinding, attrNames,  listOperMode);

        modelImpl = new JUNavigableSpinnerModel();

        control.addChangeListener( new SpinnerChangeListener());
    }

    public JUSpinnerBinding(JSpinner control, 
            JUIteratorBinding iterBinding,
            String[] attrNames, 
            Object[] valueList )
    {
        super(control, iterBinding, attrNames, valueList);

        modelImpl = new JUStaticUpdateableSpinnerModel(valueList);
    }

    public JUSpinnerBinding(JSpinner control, 
            JUIteratorBinding iterBinding,
            String[] attrNames, 
            SpinnerListModel slm )
    {
        super(control, iterBinding, attrNames, (slm.getList()).toArray());

        modelImpl = new JUStaticUpdateableSpinnerModel(slm);
    }

    public JUSpinnerBinding(JSpinner  control, 
            JUIteratorBinding iterBinding,
            String[] attrNames, 
            SpinnerDateModel sdm )
    {
        super(control, iterBinding, attrNames, LIST_OPER_SET_ATTRIBUTE);

        modelImpl = new JUSpinnerDateModel(sdm);
    }

    public JUSpinnerBinding(
            JSpinner control, 
            JUIteratorBinding iterBinding,
            String[] attrNames, 
            SpinnerNumberModel snm)
    {
        super(control, iterBinding, attrNames, LIST_OPER_SET_ATTRIBUTE);

        modelImpl = new JUSpinnerNumberModel(snm);
    }

    void refreshNow()
    {
        if (getIteratorBinding() != null) 
        {
            Row r = getCurrentRow();

            if (r != null) 
            {
               updateValuesFromRow(r);
            }
       }
    }
   
    /**
    * Binds separate ViewObject/RowSets for display and updates to the same listbox.
    * Use this binding constructor to provide a separate iterator binding for update
    * and a separate iterator binding which provides rows for display in the listbox.
    * Optionally, the attributes displayed can be different from the attributes that 
    * should be used to update a corresponding set of attributes in the target/updateable 
    * ViewObject.
    * <p>
    * @param list JList control instance to associate this binding with.
    * @param iterBinding Provides the RowSet in which the current row is updated
    * based on selection in the listbox.
    * @param attrNames An ordered array of attribute names to update
    * in a ViewObject. This list should have the same number of attributes as
    * in listAttrNames which provides the corresponding attribute names from the 
    * display ViewObject/RowSet.
    * @param listIterBinding Provides the RowSet that is used to display data in the
    * listbox.
    * @param listAttrNames An ordered list of attribute names which are used to 
    * get the values to update into the attributes from the attrNames list in the
    * target ViewObject. If this list is null, the attribute names for display 
    * are set to the same as attrNames.
    * @param listDisplayAttrNames An ordered list of attribute names that specify
    * the attributes to display from rows in the display ViewObject/RowSet.
    * If this list is null, attribute names are assumed to be same as in attrNames. 
    * @param shouldScroll When true, indicates scroll the selected item into view
    * if it is not being displayed in the current viewport.
    */

    public JUSpinnerBinding(
           JSpinner control, 
           JUIteratorBinding iterBinding,
           String[] attrNames, 
           JUIteratorBinding listRSI,
           String[] listAttrNames, 
           String[] listDisplayedAttrNames )
    {
        super(control, iterBinding, attrNames, listRSI, listAttrNames, 
                        listDisplayedAttrNames);

        modelImpl = new JUDynamicUpdateableSpinnerModel();

        control.setEditor( new JUSpinnerEditor(control, listDisplayedAttrNames));
    }

    
    protected SpinnerModel getModelImpl()
    {
        return modelImpl;
    }


    /**
    * *** For internal framework use only ***
    */
    public void addControlToPanel(Object panel, Object layoutObject, 
                                  Object layoutCons)
    {
      ((JPanel) panel).add((Component) layoutObject, layoutCons);
    }



    /**
   * Gets the value from the control for the attribute at the given index.
   * (The index is calculated from the list of attributes this control binding is
   * bound to as passed in the constructor).
   * Framework uses this method to get the attribute value from the control
   * and pass it on to the Row object on the BC4J side.
   */
    public Object getValueAt(int attrIndex)
    {
        Object value = modelImpl.getValue();

        if (value == null)
        {
            value =  super.getAttribute(0);
        }

        return value;
    }

    /**
    * Updates the control/control-binding with the latest value of the
    * attribute at the given index with the given value. This method is used
    * by the framework to update the control with attribute values from a BC4J row.
    */
    public void setValueAt(Object value, int attrIndex)
    {
        Object val = findMatchingListValue(value);
        
        try
        {
            mValueUpdating = true;

            if (val != null) //
            {
                modelImpl.setValue(val); 
            }
        }
        finally
        {
           mValueUpdating = false;
        }
    }

    
    public Object findMatchingListValue(Object value)
    {
        Object bnd = getModelImpl();

        if ((bnd instanceof JUSpinnerDateModel) || 
                (bnd instanceof JUSpinnerNumberModel))
        {
            // no enumerated list for these models
            return value;
        }
        else
            return super.findMatchingListValue(value);
    }



    public void setDataValueAt(Object value, int attrIndex)
    {
        // no op.
    }

    /**
    * *** For internal framework use only ***
    */
    public void navigated(NavigationEvent event)
    {
        setupListItems(true, true);
    }

    protected void setupListItems(boolean clean, boolean keepSelectedIndex)
    {
        super.setupListItems(clean, keepSelectedIndex);

        ((ModelHelper)modelImpl).setListInternal(super.getValueList());
    }

    protected void updateAttributeValue(Object value)
    {
        if (!mValueUpdating)
        {
            super.setAttribute(0, value); 
        }
    }

    // update from lov list
    protected void updateTargetFromSelectedValue(Object val)
    {
        if (!mValueUpdating)
        {
            super.updateTargetFromSelectedValue(val);
        }
    }

    
    protected void navigateTo(ChangeEvent e)
    {
        Object value = null;

        Object source = e.getSource();                                  

        if (source instanceof SpinnerModel)
        {
            value = ((SpinnerModel)source).getValue();
        }
        else if (source instanceof JSpinner)
        {
            value = ((JSpinner)source).getValue();
        }

        int index = findListIndex(value);

        if (index != -1)
        {
            navigateTo(index);
        }
    }

    protected void navigateTo(int rangeIndex)
    {
        RowIterator rsi = getRowIterator();

        if (rsi != null)
        {
           JUPanelBinding panelBinding = ((JUPanelBinding)getFormBinding());

           panelBinding.callBeforeRowNavigated(getIteratorBinding());

           rsi.setCurrentRowAtRangeIndex(rangeIndex);
        }
    }

    String getNumericFormatString(String attrName)
    {
        return getNumericFormatString(attrName, true);
    }

    String getDateFormatString(String attrName)
    {
        return getDateFormatString(attrName, true);
    }

    protected String getDateFormatString(String attrName, 
                               boolean useDefaultIfNull)
    {
        String fmt = getFormatString(attrName);

        if (fmt == null) 
        {
            if (useDefaultIfNull) 
                return this.DEFAULT_DATE_FORMAT_STR;
        }
        
        return fmt;
    }

    protected String getNumericFormatString(String attrName, 
                                               boolean useDefaultIfNull)
    {
        String fmt = getFormatString(attrName);

        if (fmt == null) 
        {
            if (useDefaultIfNull) 
                return this.DEFAULT_NUMERIC_FORMAT_STR;
        }
        
        return fmt;
    }

    String getFormatString(String attrName)
    {
        AttributeDef def = findAttributeDef(attrName);

        String fmt = null;

        if (def != null)
        {
            AttributeHints hints = def.getUIHelper();

            LocaleContext locale = getApplicationModule().getSession().getLocaleContext();

            if (hints.hasFormatInformation(locale))
            {
                fmt = hints.getFormat(locale);
            }
        }
        
        return fmt;
    }

    protected String getDefaultDateFormatString()
    {
        return DEFAULT_DATE_FORMAT_STR;
    }

    protected String getDefaultNumericFormatString()
    {
        return DEFAULT_NUMERIC_FORMAT_STR;
    }

    interface ModelHelper
    {
        void setListInternal(Object[] l);
    }

    class JUNavigableSpinnerModel 
        extends SpinnerListModel
            implements ModelHelper
    {
        JUNavigableSpinnerModel()
        {
            super();
        }

        public void setListInternal(Object[]  l)
        {
            java.util.List list = Arrays.asList(l);

            setList(list);
        }

        public void setValue(Object value)
        {
            super.setValue(value);
        }

    }

    class JUSpinnerDateModel
        extends SpinnerDateModel
            implements ModelHelper
    {
        JUSpinnerDateModel()
        {
            super();
        }

        JUSpinnerDateModel(SpinnerDateModel sdm)
        {
            super.setStart(sdm.getStart());

            super.setEnd(sdm.getEnd());

            super.setCalendarField(sdm.getCalendarField());

            super.setValue(sdm.getValue());
        }

        // implement  ModelHelper
        public void setListInternal(Object[]  l)
        {
            // no op
        }

        public void setValue(Object value)
        {
            
            if (!mValueUpdating)
            {
               if (value instanceof Date) 
               {
                   updateAttributeValue(toTimeStamp((Date)value));
               }
               else
               {
                   updateAttributeValue(value);
               }
            }
            else
            {
                // from setValueAt(..)
                Date date = toDate(value);
           
                if (date != null)
                {
                    super.setValue(date);
                }
            }
        }

        private Date toDate(Object value)
        {
            if (value instanceof Date)
            {
                return (Date)value;
            }

            if (value instanceof oracle.jbo.domain.Date)
            {
                Date date = ((oracle.jbo.domain.Date)value).dateValue();

                return date;
            }

            
            if (value instanceof String)
            {
                return getDateValue((String)value);
            }
            
            return null;
        }

        private Date getDateValue(String s)
        {
            String attrName = getAttributeNames()[0];

            String fmtString = getDateFormatString(attrName);

            try
            {
               SimpleDateFormat sdf = new SimpleDateFormat(fmtString);

               return (Date)sdf.parse(s);
            }
            catch(java.text.ParseException pe)
            {
                return null;
            }
        }

        Timestamp toTimeStamp(java.util.Date dateObj)
        {
            if ( dateObj != null )
            {
                Calendar calendar = Calendar.getInstance();

                calendar.setTime(dateObj);

                Timestamp timeStampObject =  new Timestamp(dateObj.getTime());

                return  timeStampObject;
            }
            return null;
        }
    }

    class JUSpinnerNumberModel
        extends SpinnerNumberModel
            implements ModelHelper
    {
        Class valueClass;

        JUSpinnerNumberModel()
        {
            super();
        }

        JUSpinnerNumberModel(SpinnerNumberModel snm)
        {
            super();

            super.setMaximum(snm.getMaximum());

            super.setMinimum(snm.getMinimum());

            super.setStepSize(snm.getStepSize());

            super.setValue(snm.getValue());

            valueClass = snm.getValue().getClass();
        }

        // implement  ModelHelper
        public void setListInternal(Object[]  l)
        {
            // no op
        }

        public void setValue(Object value)
        {
            if (!mValueUpdating)
            {
                updateAttributeValue(value);
            }
            else
            {
                // from setValueAt(..)
                Number number  = toNumber(value);
           
                if (number != null)
                {
                    super.setValue(number);
                }
            }
        }

        Number toNumber(Object value)
        {
            if (value instanceof Number)
            {
                return (Number)value;
            }

            if (value instanceof oracle.jbo.domain.Number)
            {
                Object datum = ((oracle.jbo.domain.Number)value).getData();
                
                if (datum instanceof Number) 
                    return (Number)datum;

                return null;
            }

            if (value instanceof String)
            {
                return getNumericValue((String)value);
            }
            
            return null;
        }

        Number getNumericValue(String s)
        {
            String attrName = getAttributeNames()[0];

            String fmtString = getNumericFormatString(attrName);

            try
            {
               
               DecimalFormat df = new DecimalFormat();

               if (fmtString != null) 
               {
                   df.applyPattern(fmtString);
               }

               // returns Long or Double., see javadoc
               Number number = df.parse(s); 

               if (valueClass.isAssignableFrom(Float.class))
               {
                   return new Float(number.floatValue());
               }

               if (valueClass.isAssignableFrom(Double.class))
               {
                   return new Double(number.doubleValue());
               }

               if (valueClass.isAssignableFrom(Integer.class))
               {
                    return new Integer(number.intValue());
               }

               if (valueClass.isAssignableFrom(Long.class))
               {
                    return new Long(number.longValue());
               }
               
               return number;

            }
            catch(java.text.ParseException pe)
            {
                return null;
            }
        }
    }

    class JUUpdateableSpinnerModel 
        extends SpinnerListModel
    {
        JUUpdateableSpinnerModel()
        {
            super();
        }

        JUUpdateableSpinnerModel(Object[] values)
        {
            super();

            setList(Arrays.asList(values));
        }

        JUUpdateableSpinnerModel(SpinnerListModel slm)
        {
            super();

            setList(slm.getList());
        }

        // implement  ModelHelper
        
        public void setValue(Object value)
        {
            if (value != null)
            {
                super.setValue(value);
            }
        }
    }

    class JUStaticUpdateableSpinnerModel 
        extends JUUpdateableSpinnerModel
            implements ModelHelper
    {
        JUStaticUpdateableSpinnerModel(Object[] values)
        {
            super(values);
        }

        JUStaticUpdateableSpinnerModel(SpinnerListModel slm)
        {
            super(slm);
        }

        public void setListInternal(Object[]  l)
        {
            //no op
        }

        public void setValue(Object value)
        {
            updateAttributeValue(value);

            super.setValue(value);
        }
    }

    class JUDynamicUpdateableSpinnerModel 
        extends JUUpdateableSpinnerModel
            implements ModelHelper
    {

        JUDynamicUpdateableSpinnerModel()
        {
            super();
        }

        public void setListInternal(Object[]  l)
        {
            super.setList(Arrays.asList(l));
        }

        public void setValue(Object value)
        {
            updateTargetFromSelectedValue(value);

            super.setValue(value);
        }
    }

    //public static class JUSpinnerEditor extends JSpinner.DefaultEditor
    public static class JUSpinnerEditor extends javax.swing.JLabel
            implements ChangeListener
    {
        String[] displayAttrNames = null;

        JUSpinnerEditor(JSpinner spinner, String[] displayAttrNames)
        {
            spinner.addChangeListener(this);

            this.displayAttrNames = displayAttrNames;

            this.setPreferredSize( new java.awt.Dimension(100,25));
        }

        public void stateChanged(ChangeEvent e) 
        {
	        JSpinner spinner = (JSpinner)(e.getSource());

            Object value = spinner.getValue();

            if (value instanceof Row)
            {
                Row row = (Row)value;

                StringBuffer display = new StringBuffer();

                for (int i=0; i < displayAttrNames.length; i++)
                {
                    Object attrValue  = row.getAttribute(displayAttrNames[i]);

                    if (attrValue != null)
                    {
                        display.append(attrValue);
                    }
                }
                setText(display.toString());
            }
            else
            {
                setText(spinner.getValue().toString());
            }
        }
    }

    /**
    * Spinner list used to navigate
    */
    class SpinnerChangeListener implements ChangeListener
    {
        public void stateChanged(ChangeEvent e) 
        {
            if (!mValueUpdating)
                navigateTo(e);     
        }
    }
}

