/*
 * @(#)JUDefBase.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.uicli.binding;

import java.util.HashMap;
import oracle.jbo.PersistenceException;
import oracle.jbo.common.JboNameUtil;
import oracle.jbo.common.NamedObjectImpl;
import oracle.jbo.mom.DefinitionObject;
import oracle.jbo.mom.xml.DefElementImpl;
import oracle.jbo.mom.xml.DefPersistable;
import oracle.jbo.mom.xml.DefPersistenceException;
import oracle.jbo.mom.xml.DefWriter;
import oracle.jbo.uicli.UIMessageBundle;

abstract public class JUDefBase extends DefinitionObject implements DefPersistable
{
   // private String mName;
   private String mDefClassName;
   private String mSubType;
   private boolean mIsDirty;

   private static final String PNAME_DefClass = "DefClass";
   private static final String PNAME_Name = "Name";
   private static final String PNAME_SubType = "SubType";
   

   public JUDefBase()
   {
      setDefClassName(getClass().getName());

      initSubType();
   }
  
   
   public JUDefBase(String name)
   {
      setDefClassName(getClass().getName());
      
      setName(name);

      initSubType();
   }


   public void init(HashMap initValues)
   {
      Object val;

      if ((val = initValues.get(PNAME_DefClass)) != null)
      {
         setDefClassName(mDefClassName);
      }

      if ((val = initValues.get(PNAME_Name)) != null)
      {
         setName(val.toString());
      }

      if ((val = initValues.get(PNAME_SubType)) != null)
      {
         setSubType(val.toString());
      }
   }


/****************
   public String getName()
   {
      return mName;
   }
****************/


   public void setName(String name)
   {
      super.setName(name);
   }
   
     
   public void setParent(NamedObjectImpl parent)
   {
      super.setParent(parent);
   }

   
   void initSubType()
   {
      mSubType = JboNameUtil.getLastPartOfName(getClass().getName());

      if (mSubType.endsWith("Def"))
      {
         mSubType = mSubType.substring(0, mSubType.length() - "Def".length());
      }
   }

   
   public String getSubType()
   {
      return mSubType;
   }


   public void setSubType(String subType)
   {
      mSubType = subType;
   }
   
   
   public String getDefClassName()
   {
      return mDefClassName;
   }

   
   public void setDefClassName(String defClassName)
   {
      mDefClassName = defClassName;
   }

   
   public boolean isDirty()
   {
      return mIsDirty;
   }
   

   public void setDirty(boolean isDirty)
   {
      mIsDirty = isDirty;
   }


   public boolean isNew()
   {
      return false;
   }

   
   public void setNew(boolean isNew)
   {
   }
   

/**************
   public String  getFullName()
   {
      return getName();
   }
**************/

   
   static public void readXMLString(DefElementImpl xmlElement, String name, HashMap valueTab)
   {
      String str = xmlElement.readString(name);

      if (str != null)
      {
         valueTab.put(name, str);
      }
   }
   
   
   static public void readXMLInt(DefElementImpl xmlElement, String name, HashMap valueTab)
   {
      String str = xmlElement.readString(name);

      if (str != null)
      {
         valueTab.put(name, new Integer(str));
      }
   }
   
   
   static public void readXMLBoolean(DefElementImpl xmlElement, String name, HashMap valueTab)
   {
      String str = xmlElement.readString(name);

      if (str != null)
      {
         valueTab.put(name, new Boolean(str));
      }
   }
   
   
   static public void readXMLStringArray(DefElementImpl xmlElement, String name, HashMap valueTab)
   {
      com.sun.java.util.collections.ArrayList arrList = xmlElement.readStringArrayList(name);

      if (arrList != null && arrList.size() > 0)
      {
         String[] arr = new String[arrList.size()];
         
         arrList.toArray(arr);

         valueTab.put(name, arr);
      }
   }
   
   
   protected void retrieveFromXML(DefElementImpl xmlElement, HashMap valueTab)
   {
      readXMLString(xmlElement, PNAME_Name, valueTab);
      readXMLString(xmlElement, PNAME_SubType, valueTab);
   }

   
   protected void loadChildrenFromXML(DefElementImpl xmlElement)
   {
   }
   
   
   public void loadFromXML(DefElementImpl xmlElement)
   {
      HashMap initValues = new HashMap(20);

      retrieveFromXML(xmlElement, initValues);

      init(initValues);

      loadChildrenFromXML(xmlElement);
   }

   
   static public JUDefBase createAndLoadFromXML(DefElementImpl xmlElement)
   {
      String defClassName = xmlElement.readString(PNAME_DefClass);

      if (JUUtil.isEmptyString(defClassName))
      {
         throw new PersistenceException(UIMessageBundle.EXC_DEF_CLASS_NAME_MISSING,
                                        new String[] { xmlElement.getTagName() });
      }

      JUDefBase defObj = (JUDefBase) JUUtil.createNewInstance(defClassName);

      defObj.setDefClassName(defClassName);
      
      if (defObj != null)
      {
         defObj.loadFromXML(xmlElement);
      }

      return defObj;
   }

   
   public void writeObject(DefWriter jos)
      throws DefPersistenceException
   {
      jos.writeObject(this);
   }
   

   public void writeContents(DefWriter jos)
      throws DefPersistenceException
   {
      // jos.writeString(PNAME_Name, getName());  // name written in prologue
      jos.writeString(PNAME_DefClass, getDefClassName());
      jos.writeString(PNAME_SubType, getSubType());
   }
   

   public void writeChildren(DefWriter jos)
      throws DefPersistenceException
   {
   }


   abstract public String getXMLElementTag();


   static public void writeXMLIntArray(DefWriter jos, String attrName, int[] valList)
   {
      if (valList != null)
      {
         com.sun.java.util.collections.ArrayList arr = new com.sun.java.util.collections.ArrayList();

         for (int j = 0; j < valList.length; j++)
         {
            arr.add(new Integer(valList[j]).toString());
         }
      
         jos.writeStringArray(attrName, arr.iterator());
      }
   }


   static public void writeXMLStringArray(DefWriter jos, String attrName, Object[] valList)
   {
      if (valList != null)
      {
         com.sun.java.util.collections.ArrayList arr = new com.sun.java.util.collections.ArrayList();

         for (int j = 0; j < valList.length; j++)
         {
            arr.add(valList[j]);
         }
      
         jos.writeStringArray(attrName, arr.iterator());
      }
   }

   
   static public int convertToInt(Object val)
   {
      if (val instanceof Integer)
      {
         return ((Integer) val).intValue();
      }
      else
      {
         return new Integer((String) val).intValue();
      }
   }

   
   static public boolean convertToBoolean(Object val)
   {
      if (val instanceof Boolean)
      {
         return ((Boolean) val).booleanValue();
      }
      else
      {
         return new Boolean((String) val).booleanValue();
      }
   }


   static public int[] convertToIntArray(Object[] arr)
   {
      int[] retVal = new int[arr.length];

      for (int j = 0; j < arr.length; j++)
      {
         Object elm = arr[j];

         if (elm instanceof Integer)
         {
            retVal[j] = ((Integer) elm).intValue();
         }
         else
         {
            retVal[j] = new Integer(elm.toString()).intValue();
         }
      }

      return retVal;
   }
}
