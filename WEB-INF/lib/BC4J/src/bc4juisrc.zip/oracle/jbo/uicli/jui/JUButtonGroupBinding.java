/*
 * @(#)JUButtonGroupBinding.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.uicli.jui;

import java.awt.Component;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.AbstractButton;
import javax.swing.ButtonGroup;
import javax.swing.JRadioButton;
import javax.swing.JPanel;
import oracle.jbo.Row;
import oracle.jbo.common.Diagnostic;
import oracle.jbo.uicli.binding.JUCtrlListBinding;
import oracle.jbo.uicli.binding.JUFormBinding;
import oracle.jbo.uicli.binding.JUIteratorBinding;

/**
 * Binds a group of buttons in a panel to an attribute in a ViewObject such that
 * on selection of a given button, this binding works like a LOV binding or used 
 * to display an enumerated list for update. When used like an LOV, it will update
 * selected attributes in the target ViewObject's current row with values from 
 * the row that is represented by the selected button.
 * <p>
 * When the binding is used to display an enumerated list of
 * values in a set of buttons grouped together, it will update a value in one of the
 * attributes of the current row in a target ViewObject. This behaves like the attribute
 * binding in a list control with a static list of values.
 */
public class JUButtonGroupBinding extends JUCtrlListBinding implements ActionListener
{
   private AbstractButton[] mButtons;
   private JRadioButton mOffButton = new JRadioButton();
   //private String mListVOAttrName;
   //private String mListVOName;
   private JUButtonGroupControlInterface mButtonGroupControl;

   private ButtonGroup mButtonGroup = new ButtonGroup();

   /**
   * This method should be used to create a JUButtonGroupBinding and bind it to a control.
   * <p>
   * @param formBinding The containing JUPanelBinding in which the given iterator binding
   * would be found/created.
   * @param control The control instance to bind to a ViewObject's attribute.
   * @param voInstanceName Name of the instance of the ViewObject in a BC4J ApplicationModule.
   * @param voIterName Runtime instance name of the iterator in the ViewObject (optional).
   * @param voIterBindingName Instance name of the iterator binding that uniquely identifies an
   * iterator binding object used to read/write data in this given JUPanelBinding instance.
   * @param voAttrNames The names of the attributes of the target ViewObject rows that are updated
   * when a Lov row is selected.
   * @param lovVOInstanceName Name of the instance of the ViewObject in BC4J application module to 
   * use for LOV display and selection.
   * @param lovVOAttrNames Names of the attributes that are used to update the target ViewObject
   * attributes.
   * @param lovDisplayedAttrName Name of the attributes used to create the display of
   * each row in the Lov ViewObject. This attribute in the LOV Iterator provides the text for
   * the buttons in the given ButtonGroupControl.
   */
   public static JUButtonGroupBinding createLovBinding(JUFormBinding    formBinding,  
                                                  JUButtonGroupControlInterface control, 
                                                  String        voInstanceName,
                                                  String        voIterName, /*temporarily taking nulls for this*/
                                                  String        voIterBindingName,
                                                  String[]      voAttrNames,
                                                  String        lovVOInstanceName,
                                                  String[]      lovVOAttrNames,
                                                  String        lovVODisplayedAttrName)
   {
      
      if (!JUIUtil.inDesignTime())
      {
         JUIteratorBinding listValuesBinding = formBinding.getRangeIterBinding(lovVOInstanceName, null, null, -1);

         JUButtonGroupBinding bind = new JUButtonGroupBinding(control,
                            formBinding.getRowIterBinding(voInstanceName, voIterName, voIterBindingName),
                            voAttrNames, //attrName, 
                            listValuesBinding, //listVOInstanceName,
                            lovVOAttrNames, //listVOAttrName
                            lovVODisplayedAttrName
                           );
         bind.refreshControl();
         return bind;
      }
      else
      {
         try
         {
            Class defClazz = Class.forName("oracle.jbo.dt.ui.jui.propertyeditors.dtmodels.DTJLovSingleBinding"); 
            java.lang.reflect.Constructor constructor = defClazz.getConstructors()[0];
            Object [] args = { lovVOInstanceName, lovVODisplayedAttrName, voInstanceName, lovVOAttrNames, voAttrNames };

            return (JUButtonGroupBinding)constructor.newInstance(args);
         }
         catch (Exception e)
         {
            Diagnostic.printStackTrace(e);
            return null;
         }
      }
     

   }

   /**
   * @deprecated since 9.0.2 use createLovBinding() or createEnumerationBinding instead
   */
   public static JUButtonGroupBinding getInstance(JUFormBinding    formBinding,  
                                                  JUButtonGroupControlInterface control, 
                                                  String        voInstanceName,
                                                  String        voIterName, /*temporarily taking nulls for this*/
                                                  String        voIterBindingName,
                                                  String        attrName,
                                                  String        listVOInstanceName,
                                                  String        listVOAttrName)
   {
      return createLovBinding(formBinding, control, voInstanceName, voIterName, voIterBindingName, 
                              new String[]{attrName}, listVOInstanceName, new String[] {listVOAttrName}, listVOAttrName);
   }


   /**
   * Given a list of buttons (that display the values for the given valueList) bind to an 
   * attribute of a ViewObject, such that on selection of one of the buttons in the list, 
   * the value of the selected attribute in the current row of the ViewObject is updated
   * with the equivalent value in the valueList array.
   */
   public static JUButtonGroupBinding createEnumerationBinding(JUFormBinding    formBinding,  
                                                  AbstractButton[] buttons, 
                                                  String        voInstanceName,
                                                  String        voIterName, /*temporarily taking nulls for this*/
                                                  String        voIterBindingName,
                                                  String        attrName,
                                                  Object[]      valueList)
   {
      JUButtonGroupBinding bind = new JUButtonGroupBinding(buttons, 
                                      formBinding.getRowIterBinding(voInstanceName, voIterName, voIterBindingName),
                                      attrName, valueList);
      bind.refreshControl();
      return bind;
   }

   /**
   * @deprecated since 9.0.2 use createLovBinding() or createEnumerationBinding instead
   */
   public static JUButtonGroupBinding getInstance(JUFormBinding    formBinding,  
                                                  AbstractButton[] buttons, 
                                                  String        voInstanceName,
                                                  String        voIterName, /*temporarily taking nulls for this*/
                                                  String        voIterBindingName,
                                                  String        attrName,
                                                  Object[]      valueList) 
   {
      return createEnumerationBinding(formBinding, buttons, voInstanceName, voIterName, voIterBindingName, attrName, valueList);
   }

   /**
   * Use this constructor to setup an enumerated list of values and bind them to an attribute
   * in a ViewObject (like a static list of values bound to an attribute in a ListBox or a ComboBox).
   * For example, say an attriute may contain only two values M/F. RadioButtons grouped together
   * could be used to display Male/Female in the UI, while upon selection of either, the corresponding
   * attribute value is updated with M/F. This kind of usage can be bound via this constructor.
   */
   public JUButtonGroupBinding(AbstractButton[] buttons, JUIteratorBinding iterBinding,
                               String attrName, Object[] valueList)
   {
      super(buttons, iterBinding, new String[]{attrName}, valueList);

      init(buttons);
   }

   /**
   * Use this constructor to bind a set of group buttons (created by the given control in createButtons method)
   * based on values as returned from the given LOV viewobject. This constructor creates an LOV
   * binding.
   */
   public JUButtonGroupBinding(JUButtonGroupControlInterface control, JUIteratorBinding iterBinding,
                            String[] attrNames, JUIteratorBinding listIterBinding,
                            String[] listAttrNames, String listDisplayAttrName)
   {
      super(control, iterBinding, attrNames, listIterBinding, listAttrNames, new String[] {listDisplayAttrName});
      mButtonGroupControl = control;
   }


   private void init(AbstractButton[] buttons)
   {
      mButtons = buttons;

      if (mButtons != null)
      {
         for (int j = 0; j < mButtons.length; j++)
         {
            mButtons[j].addActionListener(this);
            mButtonGroup.add(mButtons[j]);
         }
      }
      mButtonGroup.add(mOffButton);
   }

   /**
   * Sets up the list of values that are displayed by the associated control.
   * This method creates the list of buttons by calling the control's createButtons() method
   * passing it the list of Strings to be used for display.
   */
   protected void setupListItems(boolean clean, boolean keepSelectedIndex)
   {
      int index = 0; 
      
      if (mButtons != null)
      {
         int size = mButtons.length;
         {
            for (int i = 0; i < size; i++) 
            {
               if (keepSelectedIndex) 
               {
                  if (mButtons[i].isSelected()) 
                  {
                     index = i;
                  }
               }
               
               mButtonGroup.remove(mButtons[i]);
               mButtons[i].removeActionListener(this);
            }
         }
      }


      if (mValueList == null || clean) 
      {
         super.setupListItems(clean, keepSelectedIndex);
         
      }
      
      mButtons = null;

      Object[] arr = mValueList;
      int size = arr.length;

      if (size > 0 && !isSingleAttrList()) 
      {
         arr = new String[size];
         String attrName = (mListDisplayAttrNames != null && mListDisplayAttrNames.length > 0)
                           ? mListDisplayAttrNames[0]
                           : mListAttrNames[0];
   
         Object val;
         Row row = (Row)mValueList[0];
         int attrIdx = row.getAttributeIndexOf(attrName);
         for (int i = 0; i < size; i++) 
         {
            row = (Row)mValueList[i];
            val = row.getAttribute(attrIdx);
            arr[i] = (val != null) ? val.toString() : null;
         }
      }
      
      mButtons = mButtonGroupControl.createButtons(arr);

      if (mButtons == null || mButtons.length != size)
      {
         throw new oracle.jbo.JboException("Controls for button-group not created properly");
      }
      
      init(mButtons);

      if (keepSelectedIndex && index >= 0 && index < mButtons.length) 
      {
         mButtons[index].setSelected(true);
      }
      else
      {
         Row row = getCurrentRow();
         if (row != null) 
         {
            updateValuesFromRow(row);
         }
      }
   }


   
   /**
   * *** For internal framework use only ***
   */
   public void addControlToPanel(Object panel, Object layoutObject, Object layoutCons)
   {
      Object[] layoutConsArr = (Object[]) layoutCons;
      Component[] layoutObjectArr = (Component[]) layoutObject;
      
      for (int j = 0; j < layoutObjectArr.length; j++)
      {
         ((JPanel) panel).add(layoutObjectArr[j], layoutConsArr[j]);
      }
   }

   
   /**
   * Matches the given value to a button in the associated control and
   * sets it as selected.
   */
   public void setValueAt(Object value, int attrIndex)
   {
      int listIndex = findListIndex(value);

      if (mButtons != null)
      {
         //boolean flag = (value == null) || (listIndex >= 0);
         for (int j = 0; j < mButtons.length; j++)
         {
            //mButtons[j].setEnabled(true);
         }

         if (listIndex >= 0) 
         {
            mButtons[listIndex].setSelected(true);
         }
         else
         {
            mOffButton.setSelected(true);
         }
      }
   }


   /**
   * Sets the button at the given index as selected in the control as well as
   * update the target attribute with the selected value.
   */
   public void setSelectedIndex(int indx)
   {
      setDataValueAt(getValueFromList(indx), 0);
   }

   
   /**
   * Sets the button with the given value as selected in the control as well as
   * update the target attribute with the selected value.
   */
   public void setDataValueAt(Object value, int attrIndex)
   {
      setValueAt(value, attrIndex);

      setAttribute(0, value);
   }

   
   public void actionPerformed(ActionEvent e) 
   {
      AbstractButton btn = (AbstractButton) e.getSource();

      for (int j = 0; j < mButtons.length; j++)
      {
         if (btn == mButtons[j])
         {
            setAttributeFromValueList(j);
         }
      }
   }
}
