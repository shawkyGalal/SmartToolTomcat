/*
 * @(#)JULovButtonBinding.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.uicli.jui;

import java.awt.Component;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Frame;
import java.awt.BorderLayout;
import java.awt.Point;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemListener;
import java.util.ArrayList;
import javax.swing.AbstractButton;
import javax.swing.ButtonGroup;
import javax.swing.ButtonModel;
import javax.swing.DefaultButtonModel;
import javax.swing.JComponent;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.event.ChangeListener;
import oracle.jbo.AttributeDef;
import oracle.jbo.Row;
import oracle.jbo.RowNotFoundException;
import oracle.jbo.RowSetIterator;
import oracle.jbo.ViewObject;
import oracle.jbo.common.StringManager;
import oracle.jbo.uicli.UIMessageBundle;
import oracle.jbo.uicli.binding.JUCtrlListBinding;
import oracle.jbo.uicli.binding.JUFormBinding;
import oracle.jbo.uicli.binding.JUIteratorBinding;
import oracle.jbo.uicli.controls.JULovDialog;
import oracle.jbo.uicli.controls.JUNavigationBar;

/**
 * Binds a JButton with an iterator such that on button action, an LOV dialog (either a framework
 * default dialog or an application-specific one) is displayed; upon the dialog close, the current
 * row from the associated iterator is used to update values of bound attributes in a target row of a
 * target RowIterator. This behavior is similar to JUComboBoxBinding or JUListSingleSelBinding in their LOV Mode.
 * This kind of control/binding is used when the LOV row count is large enough to make navigation in
 * a ListBox or ComboBox difficult. Also this binding allows easier application customization as
 * the display of LOV data is completely delegated to the LOV dialog/LOV panel.
 * <p>
 * @see JUComboBoxBinding
 * @see JUListSingleSelBinding
 */
public class JULovButtonBinding extends JUCtrlListBinding implements ActionListener, ButtonModel
{
   /**
   * RowSet which contains data that is to be displayed in the LOV.
   */
   protected RowSetIterator mLovRSI;

   /**
   * Attribute names that are being displayed by this LOV.
   */
   protected String mLovAttrs[];

   /**
   * Panel that displays LOV data.
   */
   protected JULovPanelInterface mLovPanel;

   private ButtonModel mButtonModel;
   private String[] mLovVODisplayedAttrNames = null;
   private static final String MSG_BUNDLE = "oracle.jbo.uicli.UIMessageBundle";
   private ActionListener mHelpActionListener;
   //private boolean mNavigate = false;


   /**
   * This method should be used to create a JULovButtonBinding and bind it to a JButton control.
   * It returns the model associated with JButton that can be used in setModel() calls to the JButton.
   * <p>
   * @param formBinding The containing JUPanelBinding in which the given iterator binding
   * would be found/created.
   * @param control The control instance to bind to a ViewObject's attribute.
   * @param voInstanceName Name of the instance of the ViewObject in a BC4J ApplicationModule.
   * @param voIterName Runtime instance name of the iterator in the ViewObject (optional).
   * @param voIterBindingName Instance name of the iterator binding that uniquely identifies an
   * iterator binding object used to read/write data in this given JUPanelBinding instance.
   * @param voAttrNames The names of the attributes of the target ViewObject rows that are updated
   * when a LOV row is selected.
   * @param lovVOInstanceName Name of the instance of the ViewObject in BC4J application module to 
   * use for LOV display and selection.
   * @param lovVOAttrNames Names of the attributes that are used to update the target ViewObject
   * attributes.
   * @param lovDisplayedAttrNames Names of the attribytes that are used to create the display of
   * each row in the Lov ViewObject.
   */
   public static ButtonModel createLovBinding(JUFormBinding    formBinding, 
                                                  AbstractButton  control,
                                                  String        voInstanceName,
                                                  String        voIterName, /*temporarily taking nulls for this*/
                                                  String        voIterBindingName,
                                                  String[]      voAttrNames,
                                                  String        lovVOInstanceName,
                                                  String[]      lovVOAttrNames,
                                                  String[]      lovVODisplayedAttrNames)
   {
      String lovIterName = (new StringBuffer(lovVOInstanceName).append("LovIter")).toString();
      return createLovBinding(formBinding, control, voInstanceName,
                              voIterName, voIterBindingName, voAttrNames, lovVOInstanceName,
                              lovIterName, lovIterName,
                              lovVOAttrNames, lovVODisplayedAttrNames, false, null, null);

   }
   
   /**
   * This method should be used to create a JULovButtonBinding and bind it to a JButton control.
   * It returns the model associated with JButton that can be used in setModel() calls to the JButton.
   * <p>
   * @param formBinding The containing JUPanelBinding in which the given iterator binding
   * would be found/created.
   * @param control The control instance to bind to a ViewObject's attribute.
   * @param voInstanceName Name of the instance of the ViewObject in a BC4J ApplicationModule.
   * @param voIterName Runtime instance name of the iterator in the ViewObject (optional).
   * @param voIterBindingName Instance name of the iterator binding that uniquely identifies an
   * iterator binding object used to read/write data in this given JUPanelBinding instance.
   * @param voAttrNames The names of the attributes of the target ViewObject rows that are updated
   * when a LOV row is selected.
   * @param lovVOInstanceName Name of the instance of the ViewObject in BC4J application module to 
   * use for LOV display and selection.
   * @param lovVOIterName Runtime instance name of the iterator in the LOV ViewObject 
   * @param lovVOIterBindingName Instance name of the iterator binding that uniquely identifies an
   * iterator binding object used to get Lov rows.
   * @param lovVOAttrNames Names of the attributes that are used to update the target ViewObject
   * attributes.
   * @param lovDisplayedAttrNames Names of the attribytes that are used to create the display of
   * each row in the Lov ViewObject.
   * @param searchability true if this binding is to allow search mode in the Lov Dialog.
   * @param title String that should be displayed as the title of the Lov Dialog.
   * @param location Where the Lov dialog should be anchored.
   */
   public static ButtonModel createLovBinding(JUFormBinding    formBinding, 
                                                  AbstractButton  control,
                                                  String        voInstanceName,
                                                  String        voIterName, /*temporarily taking nulls for this*/
                                                  String        voIterBindingName,
                                                  String[]      voAttrNames,
                                                  String        lovVOInstanceName,
                                                  String        lovVOIterName, 
                                                  String        lovVOIterBindingName,
                                                  String[]      lovVOAttrNames,
                                                  String[]      lovVODisplayedAttrNames,
                                                  boolean       searchability,
                                                  String        title,
                                                  Point         location)
   {
      if (!JUIUtil.inDesignTime())
      {
         JUIteratorBinding binding = formBinding.getRowIterBinding(voInstanceName, voIterName, voIterBindingName);
         JUIteratorBinding lovValuesBinding = formBinding.getRowIterBinding(lovVOInstanceName, lovVOIterName, lovVOIterBindingName);
         
         JULovButtonBinding bind = new JULovButtonBinding(control, 
                                       binding,
                                       voAttrNames,
                                       lovValuesBinding.getRowSetIterator(),
                                       lovVOAttrNames,
                                       lovVODisplayedAttrNames,
                                       searchability, title, location);
         bind.refreshControl();
         if (voInstanceName.equals(lovVOInstanceName)) 
         {
            bind.setNavigationMode(true);
         }
         bind.getModelImpl(null);
         return bind;
      }
      else
      {
         try
         {
            Class defClazz = Class.forName("oracle.jbo.dt.ui.jui.propertyeditors.dtmodels.DTJLovBindingDef"); 

            java.lang.reflect.Constructor defConstructor = defClazz.getConstructors()[0];
            Object [] defArgs = { lovVOInstanceName, lovVODisplayedAttrNames, voInstanceName, lovVOAttrNames, voAttrNames };

            Class clazz = Class.forName("oracle.jbo.dt.ui.jui.propertyeditors.dtmodels.DTJLovButtonBinding");

            java.lang.reflect.Constructor [] constructors = clazz.getConstructors();

            java.lang.reflect.Constructor constructor = clazz.getConstructors()[0];
            Object [] args = { defConstructor.newInstance(defArgs), new Boolean(searchability), title, location };
            Object object = constructor.newInstance(args);
            return (ButtonModel)object;
         }
         catch (Exception e)
         {
            return null;
         }
      }
   }

   /**
   * This method should be used to create a JULovButtonBinding and bind it to a JButton control.
   * It returns the model associated with JButton that can be used in setModel() calls to the JButton.
   * <p>
   * @param formBinding The containing JUPanelBinding in which the given iterator binding
   * would be found/created.
   * @param control The control instance to bind to a ViewObject's attribute.
   * @param voInstanceName Name of the instance of the ViewObject in a BC4J ApplicationModule.
   * @param voIterName Runtime instance name of the iterator in the ViewObject (optional).
   * @param voIterBindingName Instance name of the iterator binding that uniquely identifies an
   * iterator binding object used to read/write data in this given JUPanelBinding instance.
   * @param voAttrNames The names of the attributes of the target ViewObject rows that are updated
   * when a LOV row is selected.
   * @param lovVOInstanceName Name of the instance of the ViewObject in BC4J application module to 
   * use for LOV display and selection.
   * @param lovVOAttrNames Names of the attributes that are used to update the target ViewObject
   * attributes.
   * @param lovDisplayedAttrNames Names of the attribytes that are used to create the display of
   * each row in the Lov ViewObject.
   * @param lovPanel the JULovPanelInterface interface
   * default constructor so that it can be instantiated by this binding method.
   */
   public static ButtonModel createLovBinding(JUFormBinding    formBinding, 
                                                AbstractButton  control,
                                                String        voInstanceName,
                                                String        voIterName, 
                                                String        voIterBindingName,
                                                String[]      voAttrNames,
                                                String        lovVOInstanceName,
                                                String        lovVOIterName, 
                                                String        lovVOIterBindingName,
                                                String[]      lovVOAttrNames,
                                                String[]      lovVODisplayedAttrNames,
                                                JULovPanelInterface        lovPanel)
   {

      if (!JUIUtil.inDesignTime())
      {
         JUIteratorBinding binding = formBinding.getRowIterBinding(voInstanceName, voIterName, voIterBindingName);
         JUIteratorBinding lovValuesBinding = formBinding.getRowIterBinding(lovVOInstanceName, lovVOIterName, lovVOIterBindingName);

         JULovButtonBinding bind = new JULovButtonBinding(control, 
                                     binding,
                                     voAttrNames,
                                     lovValuesBinding.getLovRowSetIterator(),
                                     lovVOAttrNames,
                                     lovVODisplayedAttrNames,
                                     null);
         bind.refreshControl();
         if (voInstanceName.equals(lovVOInstanceName)) 
         {
            bind.setNavigationMode(true);
         }
         bind.getModelImpl(null);
         if (lovPanel != null) 
         {
            bind.mLovPanel = lovPanel;
         }
         return bind;
      }
      else
      {
         try
         {
            Class defClazz = Class.forName("oracle.jbo.dt.ui.jui.propertyeditors.dtmodels.DTJLovBindingDef"); 
            java.lang.reflect.Constructor defConstructor = defClazz.getConstructors()[0];
            Object [] defArgs = { lovVOInstanceName, lovVODisplayedAttrNames, voInstanceName, lovVOAttrNames, voAttrNames };

            Class clazz = Class.forName("oracle.jbo.dt.ui.jui.propertyeditors.dtmodels.DTJLovButtonBinding");
            java.lang.reflect.Constructor constructor = clazz.getConstructors()[0];
            Object [] args = { defConstructor.newInstance(defArgs), new Boolean(false), null, null };
            Object object = constructor.newInstance(args);
            return (ButtonModel)object;
         }
         catch (Exception e)
         {
            return null;
         }
      }
   }

   /**
   * @deprecated since 9.0.2 use createLovBinding()
   */
   public static ButtonModel getInstance(JUFormBinding    formBinding, 
                                                  AbstractButton  control,
                                                  String        voInstanceName,
                                                  String        voIterName, 
                                                  String        voIterBindingName,
                                                  String[]      voAttrNames,
                                                  String        lovVOInstanceName,
                                                  String[]      lovVOAttrNames,
                                                  String[]      lovVODisplayedAttrNames)
   {
      return createLovBinding( formBinding, control, voInstanceName, voIterName, voIterBindingName, voAttrNames, 
                            lovVOInstanceName, lovVOAttrNames, lovVODisplayedAttrNames);
   }

   public JULovButtonBinding(Object control, 
                             JUIteratorBinding iterBinding, 
                             String targetAttrs[], 
                             RowSetIterator lovRsi, 
                             String[] lovVOAttrNames, 
                             String[] lovVODisplayedAttrNames)
   {
      this(control, iterBinding, targetAttrs, lovRsi, lovVOAttrNames, lovVODisplayedAttrNames, false, null, null);
   }            

   public JULovButtonBinding(Object control, 
                             JUIteratorBinding iterBinding, 
                             String targetAttrs[], 
                             RowSetIterator lovRsi, 
                             String[] listAttrNames,
                             String[] lovVODisplayedAttrNames,
                             JULovPanelInterface lovPanel)
   {
      super(control, iterBinding, targetAttrs, new JUIteratorBinding(lovRsi), listAttrNames, lovVODisplayedAttrNames);
      
      oracle.jbo.common.Diagnostic.ASSERT(listAttrNames.length == targetAttrs.length);
      mSingleAttrList = false;  //as LOV depends on Rows rather than list-display attr values.
      init(control);

      mListAttrNames = listAttrNames;
      mLovPanel = lovPanel;
      mLovRSI = lovRsi;
      mLovVODisplayedAttrNames = lovVODisplayedAttrNames;
   }

   public JULovButtonBinding(Object control, 
                             JUIteratorBinding iterBinding, 
                             String targetAttrs[], 
                             RowSetIterator lovRsi, 
                             String[] listAttrNames,
                             String[] lovVODisplayedAttrNames,
                             boolean searchability, 
                             String  title,
                             Point   location)
   {
      super(control, iterBinding, targetAttrs, new JUIteratorBinding(lovRsi), listAttrNames, lovVODisplayedAttrNames);
      
      mSingleAttrList = false;  //as LOV depends on Rows rather than list-display attr values.
      oracle.jbo.common.Diagnostic.ASSERT(listAttrNames.length == targetAttrs.length);
      init(control);

      mListAttrNames = listAttrNames;
      
         
      ///MyLovPanel
      class MyLovPanel extends JPanel implements JULovPanelInterface
      {
         Point     mLocation = null;
         String    mTitle    = null;
         boolean   mAddSearch = false;
         boolean   mDoInit    = true;
         JUNavigationBar mNavBar = null;
   
         JTable mTable = new JTable()
         {
            //make the table readonly.
            public boolean isCellEditable(int row, int column) 
            {
                return (mNavBar != null) ? mNavBar.getHasInsertButton() : false;
            }
         };
   
         String mBindVOName;
         MyLovPanel() 
         {
         }
   
         /**
         * Sets display using data from this RowSet Iterator.
         * Note that on LOV action, this RowSet Iterator's current Row will
         * be used to set the target Row's attributes.
         */
         public void bindRowSetIterator(RowSetIterator rsi, String[] lovVODisplayedAttrNames)
         {
            if (mDoInit) 
            {
               mDoInit = false;
               this.setLayout(new BorderLayout());
               this.add(new JScrollPane(mTable), BorderLayout.CENTER);
               if (mAddSearch) 
               {
                  mNavBar = new JUNavigationBar(true, false, false, true);
                  this.add(mNavBar, BorderLayout.NORTH);
               }
               setupListItems(true, false);
            }

            AttributeDef ads[] = rsi.getRowSet().getViewObject().getAttributeDefs();
            int size = ads.length;
            ArrayList al = new ArrayList();
            
            if (lovVODisplayedAttrNames == null)
            {   
               int kind;
               for (int i = 0; i < size; i++) 
               {
                  kind = ads[i].getAttributeKind();
                  if (kind == AttributeDef.ATTR_ASSOCIATED_ROW
                      || kind == AttributeDef.ATTR_ASSOCIATED_ROWITERATOR) 
                  {
                     continue;
                  }
                  al.add(ads[i]);
               }
            }
            else {
               ViewObject vo = rsi.getRowSet().getViewObject();
               AttributeDef ad; 
               for (int i = 0; i < lovVODisplayedAttrNames.length; i++)
               {
                  ad = vo.findAttributeDef(mLovVODisplayedAttrNames[i]) ;
                  if (ad != null)
                  {
                      al.add(ad);
                  }
               }
            
            }   
            size = al.size();
            String names[] = new String[size];
            for (int i=0; i < size; i++)
            {
   
               names[i] = ((AttributeDef)al.get(i)).getName();
            }
   
            mBindVOName = rsi.getRowSet().getViewObject().getName();

            JUPanelBinding lovPanelBinding = new JUPanelBinding()
            {
               public void setFindMode(boolean mode)
               {
                  super.setFindMode(mode);
                  mNavBar.setHasInsertButton(mode);
                  mNavBar.setHasDeleteButton(mode);
               }
            };

            JUIteratorBinding iterBind = new JUIteratorBinding(rsi);
            iterBind.setFormBinding(lovPanelBinding);
            lovPanelBinding.addIterBinding(null, iterBind) ;
            lovPanelBinding.setApplicationModule(rsi.getRowSet().getApplicationModule()) ;

            lovPanelBinding.addBindingWithCellEditor(new JUTableBinding(mTable, iterBind, names));

            if (mNavBar != null) 
            {
               mNavBar.setModel(iterBind);
               lovPanelBinding.addNavigationBar(mNavBar);
            }
            
            iterBind.rangeRefreshed(null);

         }
   
         public String getPanelTitle()
         {
            return (mTitle != null) ? mTitle
                                   : (new StringBuffer(
                                     StringManager.getString(MSG_BUNDLE, UIMessageBundle.STR_LOV_TITLE_PREFIX, "", null)
                                    ).append(mBindVOName)).toString();
         }
      
         /*
         * Returns an instance of JPanel to add into an LOV dialog.
         */
         public JPanel getPanel()
         {
            return this;
         }
   
         public void helpAction(ActionEvent ev)
         {
            if (mHelpActionListener != null) 
            {
               mHelpActionListener.actionPerformed(ev);
            }
            else
            {
               reportException(new oracle.jbo.JboException(
                         StringManager.getString(MSG_BUNDLE, UIMessageBundle.STR_LOV_NO_HELP, "", null)));
            }
         }
   
         public JULovDialogInterface createLovDialog(JComponent control)
         {
            Frame frame = null;
            if (control != null) 
            {
               Container parent = control.getParent();
               while (parent != null && !(parent instanceof Frame)) 
               {
                  parent = parent.getParent();
               }
               frame = (Frame)parent;
            }
   
            JULovDialog lovDlg = new JULovDialog(frame, getPanelTitle(), true);
            if (mLocation == null) 
            {
               lovDlg.setLocationRelativeTo(control);
            }
            else
            {
               lovDlg.setLocation(mLocation);
            }
            return lovDlg;
         }

         public Row getSelectedRow()
         {
            return mLovRSI.getCurrentRow();
         }
      }
      ///MyLovPanel
   
      MyLovPanel lovPanel = new MyLovPanel();
      lovPanel.mAddSearch = searchability;
      lovPanel.mTitle      = title;
      lovPanel.mLocation  = location;
      mLovPanel = lovPanel;
      mLovRSI = lovRsi;
      mLovVODisplayedAttrNames = lovVODisplayedAttrNames;
   }
   
   private void init(Object control)
   {
      if (control instanceof AbstractButton)
      {
         AbstractButton button = (AbstractButton) control;

         mButtonModel = getModelImpl(button);

         if (mButtonModel != button.getModel())
         {
            button.setModel(mButtonModel);
         }
         
         button.addActionListener(this);
      }
   }

   protected void setupListItems(boolean clean, boolean keepSelectedIndex)
   {
      //donothing, as LovButton brings up the grid that wires up with the list iterator directly
   }

   public Object getValueAt(int attrIndex)
   {
      throw new oracle.jbo.JboException(
                                        StringManager.getString(MSG_BUNDLE, UIMessageBundle.STR_INVALID_METHOD_CALL, "", null)
                                        );
   }

   public void setDataValueAt(Object value, int attrIndex)
   {
   }


   public void setValueAt(Object value, int attrIndex)
   {
   }

   public boolean isNavigationMode()
   {
      return false;
      //return mNavigate;
   }
   
   public void setNavigationMode(boolean flag)
   {
      //mNavigate = flag;
   }

   public JULovPanelInterface getLovPanelInterface()
   {
      return mLovPanel;
   }

   /**
   * If the default LOV dialog is being used to display LOV Data, this method should be
   * used by applications to set the ActionListener that is triggered on activating the
   * help button in the LOV Dialog. This allows applications to display custom help
   * for the LOV dialog.
   */
   public void setHelpAction(ActionListener al)
   {
      mHelpActionListener = al;
   }

   
   /**
   * *** For internal framework use only ***
   */
   protected ButtonModel getModelImpl(Object control)
   {
      ButtonModel buttonModel = mButtonModel;

      if (buttonModel == null) 
      {
         if (control instanceof AbstractButton)
         {
            AbstractButton button = (AbstractButton) control;
   
            if (button != null)
            {
               buttonModel = button.getModel();
            }
   
            if (buttonModel == null)
            {
               buttonModel = new DefaultButtonModel();
            }
         }
         mButtonModel = buttonModel;
      }
      return buttonModel;
   }

   
   /**
   * *** For internal framework use only ***
   */
   public void addControlToPanel(Object panel, Object layoutObject, Object layoutCons)
   {
      ((JPanel) panel).add((Component) layoutObject, layoutCons);
   }

   
   public void actionPerformed(ActionEvent evt)
   {
      //run the Lov Dialog in a frame
      //when the dialog is done, on ok,
      //set the values from the Dialog's current
      //row into this iterator's attributes 
      JULovDialogInterface lovDialog;
      if ((lovDialog = mLovPanel.createLovDialog((JComponent)getControl())) != null) 
      {
         mLovPanel.bindRowSetIterator(mLovRSI, mLovVODisplayedAttrNames );
         lovDialog.setLov(this);
         
         Row matchingRow = (Row)findMatchingListValue(getCurrentRow());
         if (matchingRow != null) 
         {
            mLovRSI.setCurrentRow(matchingRow);
         }

         lovDialog.show();
   
         if (lovDialog.isOKSelected())
         {
            performLOVAction();
         }
      }
   }

   Point locateDialog(Frame frame, JDialog lovDialog)
   {
      //if (frame == null) 
      {
         //center to screen.
         Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
         Dimension frameSize = lovDialog.getSize();
         if (frameSize.height > screenSize.height) 
         {
           frameSize.height = screenSize.height;
         }
         if (frameSize.width > screenSize.width) 
         {
           frameSize.width = screenSize.width;
         }
         return new Point((screenSize.width - frameSize.width)/2, (screenSize.height - frameSize.height)/2);
      }
      //else
      //{
         //try and locate on top of this button or center within this button's frame.
      //}
   }


   /**
   * This method is invoked when action is to be performed on the associated button.
   * It gets the current row from the LOV RowSet Iterator and update the values from this
   * row in to the current row of the target RowSet Iterator by mapping each element
   * in the lovAttributeNames[] in the source/LOV Row with each element in the attributeNames[]
   * in the target Row.
   */
   public void performLOVAction()
   {
      Row row = mLovPanel.getSelectedRow();
      synchronized(getIteratorBinding().getSyncLock())
      {
         try
         {
            /*
            if (mNavigate) 
            {
               getRowIterator().setCurrentRow(row);
            }
            else
            */
            {
               Row targetRow = getCurrentRow();
               if (targetRow == null)
               {
                  throw new RowNotFoundException((RowSetIterator)getRowIterator());
               }
               setTargetAttrsFromLovRow(targetRow, row);
            }
         }
         catch(Exception ex)
         {
            reportException(ex);
         }
      }
   }

   //
   // ButtonModel implementation
   //

   public boolean isArmed()
   {
      return mButtonModel.isArmed();
   }


   public boolean isSelected()
   {
      return mButtonModel.isSelected();
   }


   public boolean isEnabled()
   {
      return mButtonModel.isEnabled();
   }


   public boolean isPressed()
   {
      return mButtonModel.isPressed();
   }


   public boolean isRollover()
   {
      return mButtonModel.isRollover();
   }


   public void setArmed(boolean b)
   {
      mButtonModel.setArmed(b);
   }


   public void setSelected(boolean b)
   {
      mButtonModel.setSelected(b);
   }


   public void setEnabled(boolean b)
   {
      mButtonModel.setEnabled(b);
   }


   public void setPressed(boolean b)
   {
      mButtonModel.setPressed(b);
   }


   public void setRollover(boolean b)
   {
      mButtonModel.setRollover(b);
   }


   public void setMnemonic(int key)
   {
      mButtonModel.setMnemonic(key);
   }


   public int getMnemonic()
   {
      return mButtonModel.getMnemonic();
   }


   public void setActionCommand(String s)
   {
      mButtonModel.setActionCommand(s);
   }


   public String getActionCommand()
   {
      return mButtonModel.getActionCommand();
   }


   public void setGroup(ButtonGroup group)
   {
      mButtonModel.setGroup(group);
   }


   public void addActionListener(ActionListener l)
   {
      mButtonModel.addActionListener(l);
   }


   public void removeActionListener(ActionListener l)
   {
      mButtonModel.removeActionListener(l);
   }


   public void addItemListener(ItemListener l)
   {
      mButtonModel.addItemListener(l);
   }


   public void removeItemListener(ItemListener l)
   {
      mButtonModel.removeItemListener(l);
   }


   public void addChangeListener(ChangeListener l)
   {
      mButtonModel.addChangeListener(l);
   }


   public void removeChangeListener(ChangeListener l)
   {
      mButtonModel.removeChangeListener(l);
   }

   
   public Object[] getSelectedObjects()
   {
      return mButtonModel.getSelectedObjects();
   }

   /**
   * Returns the RowSet Iterator used to display LOV data. This could
   * be used to programmatically set a current selection in the LOV RowSet Iterator.
   */
   public RowSetIterator getLOVRowSetIterator()
   {
      return mLovRSI;
   }
}
