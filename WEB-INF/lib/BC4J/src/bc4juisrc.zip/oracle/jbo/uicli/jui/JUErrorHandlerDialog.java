/*
 * @(#)JUErrorHandlerDialog.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.uicli.jui;

/**
 * Dialog that implements JUErrorHandler interface in the framework.
 * This is the dialog that displays by default on an exception in the framework.
 * Applications should provide their own implementation of JUErrorHandler to 
 * customize error displays.
 * @deprecated since 9.0.3 use oracle.jbo.uicli.controls.JUErrorHandlerDlg instead.
 */
public class JUErrorHandlerDialog 
       extends oracle.jbo.uicli.controls.JUErrorHandlerDlg
{
}
