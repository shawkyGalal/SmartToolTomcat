/*
 * @(#)JUMetaObjectManager.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.uicli.mom;

import java.io.InputStream;
import java.io.Reader;

import java.util.HashMap;

import oracle.jbo.ApplicationModule;
import oracle.jbo.CSMessageBundle;
import oracle.jbo.InvalidDefNameException;
import oracle.jbo.JboException;
import oracle.jbo.NoDefException;
import oracle.jbo.client.Configuration;
import oracle.jbo.common.Diagnostic;
import oracle.jbo.common.JboNameUtil;
import oracle.jbo.common.ampool.ApplicationPool;
import oracle.jbo.common.ampool.EnvInfoProvider;
import oracle.jbo.mom.ContainerDefImpl;
import oracle.jbo.mom.DefinitionManager;
import oracle.jbo.mom.DefinitionObject;
import oracle.jbo.mom.xml.DefElementImpl;
import oracle.jbo.mom.xml.DefXMLParser;
import oracle.jbo.mom.xml.JTXMLTags;
import oracle.jbo.uicli.binding.JUApplication;
import oracle.jbo.uicli.binding.JUDefBase;
import oracle.jbo.uicli.binding.JUErrorHandler;
import oracle.jbo.uicli.binding.JUErrorHandlerThrow;
import oracle.jbo.uicli.binding.JUFormBinding;
import oracle.jbo.uicli.binding.JUFormDef;

// import oracle.dacf.xml.GenericFactory;
// import oracle.dacf.dataset.SessionInfo;
public class JUMetaObjectManager extends DefinitionManager implements JUMetaObjectBase
{
   private static boolean _loaded = false;
   public static JUMetaObjectManager mom = null;
   private static JUErrorHandler mBaseErrorHandler = null;


   protected JUMetaObjectManager()
   {
      super();
      mom = this;

      JUObjectTypeHelper.register();

      initManager();
   }

   public static void setBaseErrorHandler(JUErrorHandler baseErrorHandler)
   {
      mBaseErrorHandler = baseErrorHandler;
   }
   
   public static void reportException(JUFormBinding formBnd, Exception ex)
   {
      if (mBaseErrorHandler == null)
      {
         new JUErrorHandlerThrow().reportException(formBnd, ex);
      }
      else
      {
         mBaseErrorHandler.reportException(formBnd, ex);
      }
   }
   
   public static JUApplicationDefImpl setApplicationDefinition(InputStream is, String appDefName)
   {
      JUApplicationDefImpl def = null;
      try
      {
         findApplicationDefImpl(appDefName) ;
      }
      catch (NoDefException nde)
      {
         //ignore.
      }
      if (def == null) 
      {
         def = (JUApplicationDefImpl)getJUMom().loadProjectDefinition(is, appDefName);
      }
      return def;
   }

   public static JUApplicationDefImpl setApplicationDefinition(Reader reader, String appDefName)
   {
      JUApplicationDefImpl def = null;
      try
      {
         findApplicationDefImpl(appDefName) ;
      }
      catch (NoDefException nde)
      {
         //ignore.
      }
      if (def == null) 
      {
         def = (JUApplicationDefImpl)getJUMom().loadProjectDefinition(reader, appDefName);
      }
      return def;
   }
   public static JUApplicationDefImpl setApplicationDefinition(String appDefName)
   {
      JUApplicationDefImpl def = null;
      try
      {
         findApplicationDefImpl(appDefName) ;
      }
      catch (NoDefException nde)
      {
         //ignore.
      }
      if (def == null) 
      {
         def = (JUApplicationDefImpl)getJUMom().loadProjectDefinition(appDefName);
      }
      return def;
   }

   void insertMetaObject(String metaObjectName, Object metaObject)
   {
      getDefinitionObjectsMap().put(metaObjectName, metaObject);
   }
   
   public JUApplicationDefImpl createApplicationDefinition(String name)
   {
      JUApplicationDefImpl def = new JUApplicationDefImpl(name); 

      insertMetaObject(name, def);

      return def;
   }

   static public JUMetaObjectManager getJUMom()
   {
      if (mom == null)
      {
         mom = new JUMetaObjectManager();
      }
      return mom;
   }

   /**
     * Gets the XML parser.
     * @return the XMLParser.
   */
   public static DefXMLParser getParser()
   {
      return mom.xmlDoc;
   }

   /**
    * Loads the XML metadata stream and returns a Def Object
    * @param tmpXMLFileName name of the temporary XML file.
    * @param elem an XML Stream as a DefElementImpl object.
    * @param objType Object type Tag.
    * @return a defObject, which is a JBO Object extending DefObject
    */

   public DefinitionObject loadFromXML(String tmpXMLFileName, DefElementImpl elem, String objType)
   {
      DefinitionObject childObject = null;

      try
      {
         // Call the loadFromXML on the right object type
         if (objType.equalsIgnoreCase(JUApplicationDefImpl.PNAME_TYPE_APPLICATION))
         {
            childObject = JUApplicationDefImpl.createAndLoadFromXML(elem);
         }
         else  if (objType.equalsIgnoreCase(JUFormDef.PNAME_TYPE))
         {
            childObject = JUDefBase.createAndLoadFromXML(elem);
         }
      }
      catch(JboException jboEx) // JBOException
      {
         // If JBO Exception is already Thrown , Re Throw it again
         throw jboEx;
      }
      catch(Exception e) // Generic exception
      {
         Diagnostic.println("Error trying to lookup XML File '" + tmpXMLFileName + ".xml'");
         JboException rtEx = new JboException(
                                    CSMessageBundle.class,
                                    CSMessageBundle.EXC_GENERIC_PERSISTENCE,
                                    null);
         rtEx.addToDetails(e);
         throw rtEx;
      }

      return childObject;
   }

   static JUApplicationDefImpl findApplicationDefImpl(String name)
   {
      return (JUApplicationDefImpl)mom.findDefinitionObject(name, TYP_DEF_APPLICATION, JUApplicationDefImpl.class, true);
   }
   
   /*
   static JUSessionDefImpl findSessionDefImpl(String name)
   {
      return (JUSessionDefImpl)mom.findDefinitionObject(name, TYP_DEF_SESSION, JUSessionDefImpl.class, true);
   }
   */

   static boolean defExists(String name)
   {
      try
      {
         return (mom.findDefinitionObject(name, TYP_DEF_ANY, oracle.jbo.mom.DefinitionObject.class, true, false) != null);
      }
      catch (oracle.jbo.NoDefException nde)
      {
      }
      return false;
   }

   /*
   public static HashMap findRowSetEventMap(String sessionName)
   {
      JUSessionDefImpl def = (JUSessionDefImpl)mom.findDefinitionObject(sessionName, TYP_DEF_SESSION, JUSessionDefImpl.class, true);
      return def.getRowSetEventsMap();
   }
   */

   public String[] getXMLVersionArray()
   {
      return new String[] {"jbo_03_01.dtd"};
   }

   //.jpx or .addf
   protected String getProjectFileExtension()
   {
      return ".cpx";
   }

   //for project/dynamic-package def
   protected ContainerDefImpl createContainerDefObject(boolean topLevel)
   {
      return new JUApplicationDefImpl();
   }

   protected Object loadSpecialObjects(DefElementImpl elem, String metaObjectName, String objType)
   {
      // We treat these two object separately since they are different from the
      // rest of the objects, for example : ValidationBeanLoader != DefObject
      if (objType.equalsIgnoreCase(JTXMLTags.PACKAGE))
      {
         JUPackageDefImpl pInfo = new JUPackageDefImpl();

         pInfo.loadFromXMLFile(elem);
         pInfo.setIsProject(false);
         insertMetaObject(metaObjectName, pInfo);
         return pInfo;
      }
/***********
      else if ( objType.equalsIgnoreCase(JTXMLTags.DOMAIN) ) // IF DOMAIN
      {
         HashMap ht = elem.loadPropertiesMap();
         if( ht != null )
         {
            insertMetaObject(metaObjectName, ht);
         }
         Object val = ValidationBeanLoader.loadFromXML(elem);
         return val;
      }
***********/
      return null;
   }
   
   protected Object loadLazyFromSharedObject(String metaObjectName,
                                                       ContainerDefImpl parent,
                                                       boolean loadParent,
                                                       boolean sub)
   {
      //do nothing as this is an JServer type load method.
      return null;
   }

   HashMap mJUApplications = null;

   public static JUApplication findApplicationObject(String qualifiedAMName)
   {
      HashMap map = getJUMom().mJUApplications;
      if (map != null) 
      {
         return (JUApplication)map.get(qualifiedAMName);
      }
      return null;
   }

   //for old dacs to set their am that they get from SessionInfo and call this
   //method instead of the generated boot-strap code in the main frame.
   public static void setApplicationObject(String qualifiedName, ApplicationModule am)
   {
      HashMap juapps = getJUMom().mJUApplications;
      
      if (juapps == null) 
      {
         juapps  = new HashMap(5);
         getJUMom().mJUApplications = juapps;
      }

      if (juapps.get(qualifiedName) != null) 
      {
         Diagnostic.println("WOOPS! I already have one with this name.");
         return;
      }

      JUApplication app = new JUApplication(am);

      if (mBaseErrorHandler != null)
      {
         app.setErrorHandler(mBaseErrorHandler);
      }

      juapps.put(qualifiedName, app);
   }

   public static void releaseApplicationObject(JUApplication app)
   {
      Configuration.releaseRootApplicationModule(app.getApplicationModule(), true);
      getJUMom().mJUApplications.remove(app.getName());
      app.setName(null);
   }

   public static JUApplication createApplicationObject(String qualifiedAMName)
   {
      return createApplicationObject(qualifiedAMName, null);
   }

   public static JUApplication createApplicationObject(String qualifiedAMName, java.util.Properties env)
   {
      return createApplicationObject(qualifiedAMName, new java.util.Properties(), null);
   }

   /**
    * Returns the configuration name for a qualifiedAMName of the form
    * <appDefName>.<sessDefName>.
    *
    * @return null if the appDef or the sessDef are not found
    */
   public static String getConfigName(String qualifiedAMName)
   {
      // note that if the application definition has already been loaded
      // then it will not be loaded again.
      JUSessionDefImpl sessDef = null;
      try
      {
         sessDef = getSessionDef(qualifiedAMName);
      }
      catch (JboException e)
      {
      }

      return sessDef.getConfiguration();
   }

   private static JUSessionDefImpl getSessionDef(String qualifiedAMName)
   {
      //bootstrap application
      int dotIndex = qualifiedAMName.indexOf('.');
      String appDefName = null;
      String sessDefName = null;

      // bug 2474883.  if the cpx file name is not included in the
      // qualifiedAMName then do not parse the qualifiedAMName.  the
      // loadProject call will fail below with a proper application definition
      // not found exception
      if (dotIndex >= 0)
      {
         appDefName = qualifiedAMName.substring(0, dotIndex);
         sessDefName = qualifiedAMName.substring(dotIndex+1);
      }

      JUApplicationDefImpl appDef =
         (JUApplicationDefImpl)getJUMom().loadProjectDefinition(appDefName);

      if (appDef == null)
      {
           throw new JboException(CSMessageBundle.class,
                                  CSMessageBundle.EXC_NULL_APPDEF,
                                  new Object[]{appDefName});
      }

      JUSessionDefImpl sessDef    = appDef.findSession(sessDefName);
      if (sessDef == null)
      {
         throw new JboException(CSMessageBundle.class,
                                CSMessageBundle.EXC_NULL_SESSDEF,
                                new Object[]{sessDefName});
      }

      return sessDef;
   }

   public static JUApplication createApplicationObject(
      String qualifiedAMName
      , java.util.Properties env
      , EnvInfoProvider envInfo)
   {
      //bootstrap application
      try
      {
         
         //Get the pool with the given name and create a session cookie
         //from that name (the cookie gets a unique id from it's context 
         //which should be retrievable form the rootAm at runtime by a client)
//         ApplicationPool pool = createPool(qualifiedAMName, env);
         
         //dac has only one obj in pool for now.

         /*
         SessionCookie sess = null;
         try
         {
            sess = pool.createSessionCookie(pool.getName(), pool.getName(), null);
         }
         catch (ApplicationPoolException apex)
         {
            // If the session cookie already exists ignore the exception.  Assign
            // the local cookie to the existing cookie.
            sess = apex.getSessionCookie();
         }

         sess.setEnvInfoProvider(envInfo);
         */

         JUSessionDefImpl sessDef = getSessionDef(qualifiedAMName);

         // Use find pool.  Find pool is properly synchronized and will prevent
         // multiple pools from being created with the same pool name.
         Configuration configuration = new Configuration();
         configuration.loadFromClassPath(
            Configuration.buildConfigurationFileNameFromClassPath(
               sessDef.getPackageName()));
               
         JUApplication app = new JUApplication(
            configuration.createRootApplicationModuleFromConfig(
               sessDef.getConfiguration(), envInfo));

         if (mBaseErrorHandler != null)
         {
            app.setErrorHandler(mBaseErrorHandler);
         }

         HashMap juapps = getJUMom().mJUApplications;

         if (juapps == null) 
         {
            juapps  = new HashMap(5);
            getJUMom().mJUApplications = juapps;
         }

         int i = 0;
         String baseName = qualifiedAMName;
         while (juapps.get(baseName) != null) 
         {
            baseName = qualifiedAMName + (i++);
         }
         juapps.put(baseName, app);
         app.setName(baseName);
         return app;

      }
      catch(JboException jboEx)
      {
         jboEx.printStackTrace();
         throw jboEx;
      }
      catch (Exception e)
      {
         e.printStackTrace();
         throw new JboException(e);
      }
   }

   /**
    * @deprecated  applications should use <tt>oracle.jbo.common.ampool.PoolMgr.findPool</tt>
    * directly or should rely upon <tt>createApplicationObject</tt> to create
    * a pool using the fully qualified ApplicationModule definition name.
    */
   public static ApplicationPool createPool(String qualifiedAMName)
   {
      return createPool(qualifiedAMName, new java.util.Properties());
   }

   /**
    * @deprecated  applications should use <tt>oracle.jbo.common.ampool.PoolMgr.findPool</tt>
    * directly or should rely upon <tt>createApplicationObject</tt> to create
    * a pool using the fully qualified ApplicationModule definition name.
    */
   public static ApplicationPool createPool(
      String qualifiedAMName, java.util.Properties env)
   {
      //bootstrap application
      JUSessionDefImpl sessDef = getSessionDef(qualifiedAMName);

      try
      {
         String configPackageName = sessDef.getPackageName();
         String configName = sessDef.getConfiguration();

         // Use find pool.  Find pool is properly synchronized and will prevent
         // multiple pools from being created with the same pool name.
         return oracle.jbo.common.ampool.PoolMgr.getInstance().findPool(
            configPackageName + "." + configName
            , configPackageName
            , configName
            , env);
      }
      catch(JboException jboEx)
      {
         jboEx.printStackTrace();
         throw jboEx;
      }
      catch (Exception e)
      {
         e.printStackTrace();
         throw new JboException(e);
      }
   }

   JUPackageDefImpl findPackage(String packageName)
   {
      // Try to find the object in the cache
      Object obj = findLoadedObject(packageName);

      if (obj == null)  // Check for lazyloading removed to bug :
      {
         if (mbValidateName && !JboNameUtil.isFullNameValid(packageName))
         {
            throw new InvalidDefNameException(TYP_PACKAGE, packageName);
         }

         // Package not found in cache, so call loadLazyObject
         obj = loadLazyDefinitionObject(packageName, null, false /*loadParent*/, true /*sub*/);
      }

      if (obj instanceof JUPackageDefImpl)
      {
         return (JUPackageDefImpl) obj;
      }

      return null;
   }
}
