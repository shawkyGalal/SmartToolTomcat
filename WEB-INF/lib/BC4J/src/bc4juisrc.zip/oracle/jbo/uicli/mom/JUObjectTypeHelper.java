/*
 * @(#)JUObjectTypeHelper.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.uicli.mom;

import oracle.jbo.common.ObjectTypeHelper;
import oracle.jbo.common.StringManager;
import oracle.jbo.uicli.UIMessageBundle;

/**
 * <b>Internal:</b> <em>Applications should not use this class.</em>
 * <p>
 */
public class JUObjectTypeHelper extends ObjectTypeHelper implements JUMetaObjectBase
{
   static void register()
   {
      setExtension(new JUObjectTypeHelper());
   }
   

   protected String getInstTypeNameFromId(int id)
   {
      String strCode = null;
      
      switch(id)
      {
         case TYP_DEF_APPLICATION:
            strCode = UIMessageBundle.STR_DEF_APPLICATION;
            break;
         case TYP_DEF_SESSION:
            strCode = UIMessageBundle.STR_DEF_SESSION;
            break;
         case TYP_DEF_FORM_BINDING:
            strCode = UIMessageBundle.STR_DEF_FORM_BINDING;
            break;
         case TYP_DEF_ITER_BINDING:
            strCode = UIMessageBundle.STR_DEF_ITER_BINDING;
            break;
         case TYP_DEF_CONTROL_BINDING:
            strCode = UIMessageBundle.STR_DEF_CONTROL_BINDING;
            break;

         case TYP_APPLICATION:
            strCode = UIMessageBundle.STR_DEF_APPLICATION;
            break;
         case TYP_SESSION:
            strCode = UIMessageBundle.STR_DEF_SESSION;
            break;
         case TYP_FORM_BINDING:
            strCode = UIMessageBundle.STR_DEF_FORM_BINDING;
            break;
         case TYP_ITER_BINDING:
            strCode = UIMessageBundle.STR_DEF_ITER_BINDING;
            break;
         case TYP_CONTROL_BINDING:
            strCode = UIMessageBundle.STR_DEF_CONTROL_BINDING;
            break;
         default:
            return null;
      }

      return StringManager.getString(UIMessageBundle.class.getName(), strCode, null, null);
   }
}
