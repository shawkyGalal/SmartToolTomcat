/*
 * @(#)JUSingleTableGraphBinding.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.uicli.jui;

import java.awt.Component;
import javax.swing.JPanel;
import oracle.dss.graph.Graph;
import oracle.dss.util.CubeDataDirector;
import oracle.dss.util.DataSource;
import oracle.dss.util.DefaultErrorHandler;
import oracle.dss.util.RelationalDataDirector;
import oracle.jbo.uicli.binding.JUFormBinding;
import oracle.jbo.uicli.binding.JUIteratorBinding;

/**
 *  Data source for the BI Graph bean. This binding may be used
 *  for Graph which requires one value per marker. A Pie chart 
 *  for example requires one value per marker. Each column in the 
 *  table (ViewObject) represents a Group in the Graph. Each row in
 *  table (ViewObject) represents a series in the Graph.
 * 
 *  @see JUMasterDetailGraphBinding
 */
public class JUSingleTableGraphBinding
      extends GraphDataFromRow
      implements DataSource
{
    protected BIBeanDataAccessAdapter mAdapter;

    public static JUSingleTableGraphBinding getInstance(
                                        JUFormBinding formBinding, 
                                        Graph         control,
										int           graphType,
                                        String        voInstanceName,
                                        String        voIterName, 
                                        String        voIterBindingName,
                                        String[]      dataValueAttrNames,
                                        String        seriesLabelAttrName)
	{

		JUSingleTableGraphBinding bind =
			    getInstance(formBinding, control, graphType, voInstanceName, voIterName, 
				voIterBindingName, dataValueAttrNames, seriesLabelAttrName,
						   dataValueAttrNames);

        return bind;
	}

	public static JUSingleTableGraphBinding  getInstance(
                                        JUFormBinding formBinding, 
                                        Graph         control,
										int           graphType,
                                        String        voInstanceName,
                                        String        voIterName, 
                                        String        voIterBindingName,
                                        String[]      dataValueAttrNames,
                                        String        seriesLabelAttrName,
										String[]        colLabels)
   {
	    control.setGraphType( graphType );

        String attrNames[] =  buildAttributeListWithLabel(dataValueAttrNames, 
                                      seriesLabelAttrName);

        JUIteratorBinding iterBinding = formBinding.getRangeIterBinding(
               voInstanceName, voIterName, voIterBindingName, -1);
        
        JUSingleTableGraphBinding bind = new JUSingleTableGraphBinding(control, 
                                    iterBinding, attrNames, colLabels);

        return bind;
   }

    public JUSingleTableGraphBinding(Graph control, 
            JUIteratorBinding iterBinding, 
            String[] dataValueAttrNames,
			String[] colLabels)
    {
        super(control, iterBinding, dataValueAttrNames, colLabels);
                
        init(control);
    } 
    
    private void init(Graph control)
    {
         mAdapter = new BIBeanDataAccessAdapter(this);

		 Object errHandler = control.getErrorHandler();

		 if ( (errHandler != null) && (errHandler instanceof DefaultErrorHandler))
		 {
			 DefaultErrorHandler defErrHandler = (DefaultErrorHandler) errHandler;

			 defErrHandler.setDebugMode(DefaultErrorHandler.SHOW_ERROR);

		 }
    }
    
    
    public void addControlToPanel(Object panel, Object layoutObject, Object layoutCons)
    {
        ((JPanel) panel).add((Component) layoutObject, layoutCons);
    }

	protected void notifyView()
	{
		super.refreshBIBeanAdapter(mAdapter);
	}

    // Implement DataSource interface
    public RelationalDataDirector createRelationalDataDirector() 
    {
        return mAdapter;
    }
    
    public CubeDataDirector createCubeDataDirector() 
    {
        return mAdapter;
    }
}

