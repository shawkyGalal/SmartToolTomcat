/*
 * @(#)JUCtrlListBinding.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.uicli.binding;

import java.lang.reflect.Array;
import oracle.jbo.AttributeDef;
import oracle.jbo.DeleteEvent;
import oracle.jbo.InsertEvent;
import oracle.jbo.NavigationEvent;
import oracle.jbo.RangeRefreshEvent;
import oracle.jbo.Row;
import oracle.jbo.RowNotFoundException;
import oracle.jbo.RowSetIterator;
import oracle.jbo.RowSetListener;
import oracle.jbo.ScrollEvent;
import oracle.jbo.UpdateEvent;
import oracle.jbo.domain.TypeFactory;
import oracle.jbo.common.JboEnvUtil;
import oracle.jbo.uicli.UIMessageBundle;

/**
 * A JUCtrlAttrsBinding class responsible displaying a list of values
 * from a static list or a list calculated at runtime using another BC4J ViewObject/RowIterator.
 * This binding operates in two ways:
 * <ul>
 * <LI>To update attributes (default - LIST_OPER_SET_ATTRIBUTE)
 * <LI>To navigate a set of rows (LIST_OPER_NAVIGATE)
 * </ul>
 * <p>
 * The operating mode is to be setup in the constructor of this binding.
 * <p>
 * This binding works in two updateable modes:
 * <ul>
 * <li>Single attribute mode, where only one attribute from the display ViewObject/RowIterator
 * is used to display and only one attribute in the target ViewObject is updated based on the
 * selected item in the list.
 * <li>Row selection mode, where one or more than one attributes in the target ViewObject
 * is updated based on the currently selected item which identifies the current row in
 * the displayed list (display ViewObject/RowIterator).
 * </ul>
 * <p>
 * This binding can also be used to iterator through a RowIterator object and display 
 * single or multiple attributes from the rows.
 */
abstract public class JUCtrlListBinding extends JUCtrlAttrsBinding implements RowSetListener 
{
   /**
   * Indicates this list binding will be used to update attributes in a target ViewObject.
   * This is the default mode 
   */
   public static int LIST_OPER_SET_ATTRIBUTE = 0;

   /**
   * Indicates that list binding will be used to navigate Rows in a RowIterator.
   */
   public static int LIST_OPER_NAVIGATE = 1;
   
   
   private int mListOperMode = LIST_OPER_SET_ATTRIBUTE;
   protected boolean mSingleAttrList = true;
   //boolean mInSetupList = false;

   /**
   * List of values displayed in the bound control. This could be a list of single
   * attribute values or a list of BC4J Rows.
   */
   protected Object[] mValueList = null;
   private int mSelectedIndex = -1;

   /**
   * Ordered list of attribute names that this control binding should use
   * to update the target ViewObject's attributes. 
   */
   protected String[] mListAttrNames;

   /**
   * Ordered list of attributes that this control binding should use
   * to display the Rows from the LOV ViewObject.
   */
   protected String[] mListDisplayAttrNames;

   /**
   * Iterator Binding object that this binding uses to get the LOV data.
   */
   protected JUIteratorBinding mListIterBinding = null;

   /**
   * Controls whether the list of values should be fetched once or should this list update
   * itself when the ViewObject for the LOV changes.
   */
   protected boolean mStaticList = false;

      
   protected AttributeDef mFirstDisplayAttr;

   /**
   * **For Testing purposes only***
   * Uses the same Iterator Binding to update as well as display values.
   */
   public JUCtrlListBinding(Object control, JUIteratorBinding iterBinding,
                            String[] attrNames, int listOperMode)
   {
      super(control, iterBinding, attrNames);
      mListAttrNames = attrNames;
      mListDisplayAttrNames = attrNames;
      mListOperMode = listOperMode;
      if (listOperMode == LIST_OPER_NAVIGATE) 
      {
         //make the iteratorbinding for display be same as the one for update
         //so that refresh of the list happens when this lists' master navigates.
         mListIterBinding = iterBinding;
      }
      mSingleAttrList = ((attrNames == null) || (attrNames.length == 1));

   }


   /**
   * Uses the given static list of value objects to display data in the control.
   */
   public JUCtrlListBinding(Object control, JUIteratorBinding iterBinding, String[] attrNames,
                            Object[] valueList)
   {
      super(control, iterBinding, attrNames);
      mListAttrNames = attrNames;
      mListDisplayAttrNames = attrNames;
      mStaticList = true;

      setValueList(valueList);
      mSingleAttrList = ((attrNames == null) || (attrNames.length == 1));
   }

   /**
   * Uses the listIterBinding object to get the iterator and attribute names from
   * listDisplayAttrNames to display attributes from the BC4J Rows in the iterator.
   * Also maps values from listAttrNames attributes to the set of attributes (attrNames)
   * in the current row of the target iterator referred by iterBinding object 
   */
   protected JUCtrlListBinding(Object control, JUIteratorBinding iterBinding,
                            String[] attrNames, JUIteratorBinding listIterBinding,
                            String[] listAttrNames, String[] listDisplayAttrNames)
   {
      super(control, iterBinding, attrNames);

      if (listAttrNames.length != attrNames.length) 
      {
         oracle.jbo.common.Diagnostic.println("JUCtrlListBinding: Target and LOV attribute count mismatch");
      }

      if (listDisplayAttrNames == null)
      {
         listDisplayAttrNames = listAttrNames;
      }

      if (listDisplayAttrNames == null)
      {
         listAttrNames = listDisplayAttrNames = getAttributeNames();
      }

      mListAttrNames = listAttrNames;
      mListDisplayAttrNames = listDisplayAttrNames;

      mListIterBinding = listIterBinding;

      mSingleAttrList = ((listDisplayAttrNames != null) 
                          && (listDisplayAttrNames.length == 1)
                          && (attrNames.length == 1 && listDisplayAttrNames[0].equals(attrNames[0]))
                          && (listAttrNames.length == 1 && listDisplayAttrNames[0].equals(listAttrNames[0])));

   }

   /**
   * If this list is displaying a single attribute and updates a single attribute,
   * then this method fetches the attribute value from all the rows in the given LOV list
   * iterator and sets that as the list of values to display in the bound control.
   *
   <p>
   * If this list is displaying multiple attributes and/or is used in navigation mode,
   * then the valueList is set with the list of all rows from the LOV Iterator binding.
   * In this case, this binding also listens to events from the RowSetIterator 
   * for row currency changes, new rows, etc.
   */
   protected void setupListItems(boolean clean, boolean keepSelectedIndex)
   {

      //mInSetupList = true;
      try
      {
         RowSetIterator listRSI = (mListIterBinding != null) ? mListIterBinding.getRowSetIterator() : null;
         if (mSingleAttrList) 
         {
            //only does one value as of now.
            setValueList(getAttrValuesFromRSI(getIteratorBinding(), listRSI, mListDisplayAttrNames, this));
            convertValueList();
         }
         else
         {
            boolean listRSIOpen = false;
            try
            {
               //default the listRSI to this target VO's rsi only when there are valid
               //list attribute names! infact this whole setup stuff may not be required at all
               //for cases where listRSI was not provided.
               if (listRSI == null && mListAttrNames.length > 0) 
               {
                  RowSetIterator bndRSI = getIteratorBinding().getRowSetIterator();
                  if (bndRSI != null)
                  {
                     listRSI = bndRSI.getRowSet().createRowSetIterator(null);
                     listRSIOpen = true;
                  }
               }

               if (listRSI != null) 
               {
                  //addListener guarentees that a listener is not added more than once.
                  listRSI.setRangeSize(-1);
                  setValueList(listRSI.getAllRowsInRange());

                  //listener mgt. keeps track of unique listener.
                  listRSI.addListener(this);
               }
               else
               {
                  setValueList(new Object[0]);
               }

            }
            catch(Exception ex)
            {
               getFormBinding().reportException(ex);
            }
            finally
            {
               if (listRSIOpen)
               {
                  listRSI.closeRowSetIterator();
               }
            }
         }
      }
      finally
      {
         //mInSetupList = false;
      }
   }


   /**
   * Returns whether this list binding is used for Row Navigation or updating attributes on a target ViewObject (default).
   * The possible values are:
   * <ul>
   * <li>LIST_OPER_SET_ATTRIBUTE
   * <li>LIST_OPER_NAVIGATE
   * </ul>
   */
   public int getListOperMode()
   {
      return mListOperMode;
   }

   
   /**
   * *** For internal framework use only ***
   * <p>
   * Sets the operating mode for this list binding.
   */
   public void setListOperMode(int listOperMode)
   {
      mListOperMode = listOperMode;
   }

   
   /**
   * *** For internal framework use only ***
   * <p>
   */
   protected void setSingleAttrList(boolean flag)
   {
      mSingleAttrList = flag;
   }
   
   
   /**
   * *** For internal framework use only ***
   * <p>
   */
   public boolean isSingleAttrList()
   {
      return mSingleAttrList;
   }
   
   
   /**
   * *** For internal framework use only ***
   * <p>
   */
   public void setValueList(Object[] valueList)
   {
      mValueList = valueList;
   }
   
   
   /**
   * *** For internal framework use only ***
   * <p>
   */
   public void convertValueList()
   {
      if (mSingleAttrList) 
      {
         AttributeDef[] attrDefs = getAttributeDefs();

         if (attrDefs != null && attrDefs.length > 0)
         {
            Class listValClass = attrDefs[0].getJavaType();

            if (listValClass != null && mValueList != null)
            {
               Object[] newList = (Object[]) Array.newInstance(listValClass, mValueList.length);

               for (int j = 0; j < mValueList.length; j++)
               {
                  Object listVal = mValueList[j];
   
                  if (listVal != null && !listValClass.isInstance(listVal))
                  {
                     newList[j] = TypeFactory.getInstance(listValClass, listVal);
                  }
                  else
                  {
                     newList[j] = listVal;
                  }
               }

               mValueList = newList;
            }
         }
      }
   }

   
   public int getSelectedIndex()
   {
      return mSelectedIndex;
   }

   
   public void setSelectedIndex(int indx)
   {
      mSelectedIndex = indx;
   }
   
   
   public Object getValueAt(int attrIndex)
   {
      return getSelectedValue();
   }

   
   public Object[] getValueList()
   {
      return mValueList;
   }

   
   public Object getSelectedValue()
   {
      return getValueFromList(mSelectedIndex);
   }


   /**
   * *** For internal framework use only ***
   * <p>
   */
   protected boolean matchTargetWithLov(Row targetRow, Row lovRow)
   {
      AttributeDef ads[] = getAttributeDefs();
      {
         //mapping attribute names of the target row with the lov row.
         //this mapping could be provided by a user in some metadata in the future.
         Object targetVal;
         Object lovVal;
         boolean matched = true;
         for (int i = 0; i < ads.length; i++) 
         {
            targetVal = targetRow.getAttribute(ads[i].getIndex());
            lovVal = lovRow.getAttribute(mListAttrNames[i]);
            if (targetVal == null)
            {
               if (lovVal == null)
               {
                  continue;
               }
            }
            else  if (targetVal.equals(lovVal))
            {
               continue;
            }
            else if (lovVal != null && targetVal.getClass() != lovVal.getClass()) 
            {
               //try converting both to the same java type and compare.
               //this will handle cases where say PK is of different type than FK and
               //LOV displays all PKs but need to update an FK.
               if (targetVal.equals(TypeFactory.getInstance(ads[i].getJavaType(), lovVal))) 
               {
                  continue;
               }
            }
            //no attributes matched, get out.
            matched = false;
            break;
         }
         return matched;
      }
   }

   
   public Object findMatchingListValue(Object val)
   {
      int selIndex = findListIndex(val);
      Object matchVal = null;

      if (selIndex >= 0)
      {
         matchVal = mValueList[selIndex];
      }
      
      return matchVal;
   }
   
   
   public int findListIndex(Object val)
   {
      if (mValueList == null)
      {
         return -1;
      }
      
      int listIndex = -1;

      if (mSingleAttrList) 
      {
         AttributeDef[] attrDefs = getAttributeDefs();
         Class listValClass = null;
         Class valClass = null;

         if (attrDefs != null && attrDefs.length > 0)
         {
            listValClass = attrDefs[0].getJavaType();
         }

         if (val != null)
         {
            valClass = val.getClass();
         }
         
         for (int j = 0; j < mValueList.length; j++)
         {
            Object listVal = mValueList[j];
   
            if (val == null)
            {
               if (listVal == null)
               {
                  listIndex = j;
                  break;
               }
            }
            else  if (valClass.isInstance(listVal))
            {
               if (val.equals(listVal))
               {
                  listIndex = j;
                  break;
               }
            }
            else  if (listValClass != null)
            {
               Object convVal = TypeFactory.getInstance(listValClass, val);

               if (convVal.equals(listVal))
               {
                  listIndex = j;
                  break;
               }
            }
            else  if (val.equals(listVal))
            {
               listIndex = j;
               break;
            }
         }
      }
      else
      {
         if (mListIterBinding != null) 
         {
            RowSetIterator rsi = mListIterBinding.getRowSetIterator();
            if (rsi == null || rsi.getCurrentRowSlot() != RowSetIterator.SLOT_VALID)
            {
               //clearClientSideCache resets the rowset on client side rsi.
               if (rsi == null || rsi.getRowSet() == null || !rsi.getRowSet().isExecuted())
               {
                  //setupListItems(true, false);
                  rsi.getRowSet().executeQuery();
               }
            }
         }
         Row lovRow;
         if (val instanceof Row) 
         {
            Row row = (Row)val;
            for (int j = 0; j < mValueList.length; j++)
            {
               lovRow = (Row)mValueList[j];
      
               if (val == null)
               {
                  if (lovRow == null)
                  {
                     listIndex = j;
                     break;
                  }
               }
               else  if (matchTargetWithLov(row, lovRow))
               {
                  listIndex = j;
                  break;
               }
            }
         }
         else
         {
            
            //check if first attribute value matches in any row. Ultimately
            //this should be the first in the LOVAttributesList as that's what
            //should be edited in the celleditor
            if (mFirstDisplayAttr == null)
            {
               RowSetIterator listRSI = (mListIterBinding != null) ? mListIterBinding.getRowSetIterator() : null;
               oracle.jbo.ViewObject vo = listRSI.getRowSet().getViewObject();
               if (mListDisplayAttrNames.length > 0)
               {
                  mFirstDisplayAttr = vo.lookupAttributeDef(mListDisplayAttrNames[0]);
               }
               if (mFirstDisplayAttr == null)
               {
                  mFirstDisplayAttr = getAttributeDef(0);
               }
            }
            Class adClass = mFirstDisplayAttr.getJavaType();
            for (int j = 0; j < mValueList.length; j++)
            {
               lovRow = (Row)mValueList[j];
      
               if (val == null)
               {
                  if (lovRow == null)
                  {
                     listIndex = j;
                     break;
                  }
                  else
                  {
                     if (lovRow.getAttribute(0) == null) 
                     {
                        listIndex = j;
                        break;
                     }
                  }

               }
               else
               {
                  Object convVal = TypeFactory.getInstance(adClass, val);
                  //do we have to worry about null values here? only if getAttribute(0) returns null
                  //which we assume is unlikely for lists!
                  if (convVal != null && convVal.equals(lovRow.getAttribute(mFirstDisplayAttr.getIndex())))
                  {
                     listIndex = j;
                     break;
                  }
               }
            }
         }
      }

      mSelectedIndex = listIndex;
      
      return mSelectedIndex;
   }

   
   public Object findValue(Object val)
   {
      if (mValueList == null || mValueList.length == 0)
      {
         return null;
      }

      return getValueFromList(findListIndex(val));
   }


   public Object getValueFromList(int listIndex)
   {
      if (listIndex >= 0 && listIndex < mValueList.length)
      {
         return mValueList[listIndex];
      }
      else
      {
         return null;
      }
   }

   public void updateValuesFromRow(Row row)
   {
      if (mValueList == null) 
      {
         setupListItems(true, false);
      }

      if (mSingleAttrList) 
      {
         Object ctrl = getControl();
         boolean enabled = false;
         if (ctrl instanceof java.awt.Component) 
         {
            enabled = (mListOperMode == LIST_OPER_NAVIGATE) && ((java.awt.Component)ctrl).isEnabled();
         }

         super.updateValuesFromRow(row);

         if (enabled)
         {
            ((java.awt.Component)ctrl).setEnabled(enabled);
         }
      }
      else
      {
         //update the list with the current row.
         setValueAt(row, -1);

         //do not set control disabled if in navigation mode
         //as that'd disable the control and make is unusable in the UI.
         if (mListOperMode != LIST_OPER_NAVIGATE)
         {
            //setup readonly stuff for controls mapped to one target attribute
            Object ctrl = getControl();
            if (ctrl instanceof java.awt.Component) 
            {
               boolean attrEnabled = true;
               int ct = getAttributeCount();
               for (--ct; attrEnabled && ct >= 0; --ct) 
               {
                  attrEnabled &= isAttributeUpdateable(ct);
               }

               //forcing enabled here without check leads to a Locked state
               //while drawing up UIs for scrolbars etc. some guava tests block
               java.awt.Component comp = (java.awt.Component) ctrl;
               boolean compEnabled = comp.isEnabled();
               if (compEnabled != attrEnabled) 
               {
                  comp.setEnabled(attrEnabled);
               }

            }
         }
      }
   }

   /**
   * *** For internal framework use only ***
   * <p>
   */
   protected void setTargetAttrsFromLovRow(Row targetRow, Row lovRow)
   {
      AttributeDef ads[] = getAttributeDefs();

      int size = mListAttrNames.length;
      for (int i = 0; i < size; i++) 
      {
         setAttributeInRow(targetRow, ads[i], (lovRow != null) ? lovRow.getAttribute(mListAttrNames[i]) : null);
      }
      //for 3tier, after the dialog comes out, we need to sync with MT as 
      //setAttributes in the above needs to be brought back so that other
      //controls listening on the updated-data redisplay themselves.

      if (JboEnvUtil.isClient(getFormBinding().getApplicationModule().getSession().getEnvironment()))
      {
         //we could do a sync but that'd cause a network roundtrip which may be too much
         //for cases like a listbox/combobox LOV. Instead, just update this iterator binding
         //or may be throw an update notification from the RSI?

         //What if there are more than one iteratorbinding's working on the same iterator?
         //If that's the case (which I think would be 20 side of the 80/20 rule), I'd leave
         //it for the app to workaround this issue by calling a sync or a rangeRefresh() event
         //individually on the iteratorBindings rather than penalizing most apps with a roundtrip.

         //getFormBinding().getApplicationModule().sync();

         JUIteratorBinding iter = getIteratorBinding();
         int[] attrIndices = new int[size];
         for (size--; size >= 0; size--) 
         {
            attrIndices[size] = ads[size].getIndex();
         }
         iter.rowUpdated(new oracle.jbo.UpdateEvent(iter.getRowSetIterator(), targetRow, -1, attrIndices));
      }
   }

   public void setAttributeFromValueList(int listIndex)
   {
      try
      {
         updateTargetFromSelectedValue(getValueFromList(listIndex));
      }
      catch(Exception ex)
      {
         reportException(ex);
      }
   }

   protected void updateTargetFromSelectedValue(Object val)
   {
      if (!isSingleAttrList()) 
      {
         if (!(val instanceof Row)) 
         {
            if (val != null)
            {
               //val is first attribute of this row.
               val = findMatchingListValue(val);

               if (val == null) 
               {
                  if (!getIteratorBinding().isFindMode()) 
                  {
                     reportException(new oracle.jbo.JboException(UIMessageBundle.EXC_NO_MATCHING_ROW_IN_LOV));
                  }
               }
            }
            //if val is null, then null will be set for the target attrs.
         }
         if (getIteratorBinding() != null) 
         {
            Row row = getCurrentRow();
   
            if (row == null)
            {
               throw new RowNotFoundException(getRowIterator());
            }
            setTargetAttrsFromLovRow(row, (Row)val);
         }

      }
      else
      {
         setAttribute(0, val);
      }
   }

   
   public static Object[] getAttrValuesFromRSI(JUIteratorBinding iterBinding, RowSetIterator listRSI, String[] listAttrNames, RowSetListener listener)
   {
      boolean listRSIOpen = false;

      try
      {
         if (listRSI == null)
         {
            if (iterBinding == null)
            {
               return new Object[0];
            }
            
            RowSetIterator bndRSI = iterBinding.getRowSetIterator();
            
            if (bndRSI == null)
            {
               return new Object[0];
            }
            
            listRSI = bndRSI.getRowSet().createRowSetIterator(null);
            listRSIOpen = true;
         }
         listRSI.setRangeSize(-1);

         Row[] rows = listRSI.getAllRowsInRange();

         int index = (listAttrNames != null)
                      ? listRSI.getRowSet().getViewObject().findAttributeDef(listAttrNames[0]).getIndex()
                      : 0;

         Object[] valueList = new Object[rows.length];
         for (int j = 0; j < valueList.length; j++)
         {
            valueList[j] = rows[j].getAttribute(index);
         }


         if (listener != null) 
         {
            //addListener guarentees that a listener is not added more than once.
            listRSI.addListener(listener);
         }
         return (valueList);
      }
      catch(Exception ex)
      {
         iterBinding.getFormBinding().reportException(ex);
      }
      finally
      {
         if (listRSIOpen)
         {
            listRSI.closeRowSetIterator();
         }
      }
      
      return null;
   }


   /**
   * *** For internal framework use only ***
   * <p>
   */
   public void rangeRefreshed(RangeRefreshEvent event)
   {
      //otherwise, find->to-execute-> won't refresh the UI if LOVVO is executed after the targetVO.
      //if (!mInSetupList) 
      {
         setupListItems(true, true);
      }
   }

   /**
   * *** For internal framework use only ***
   * <p>
   */
   public void rowInserted(InsertEvent event)
   {
      setupListItems(true, true);
   }
   
   /**
   * *** For internal framework use only ***
   * <p>
   */
   public void rowDeleted(DeleteEvent event)
   {
      setupListItems(true, true);
   }
   
   /**
   * *** For internal framework use only ***
   * <p>
   */
   public void rowUpdated(UpdateEvent event)
   {
      setupListItems(true, true);
   }
   
   /**
   * *** For internal framework use only ***
   */
   public void navigated(NavigationEvent event)
   {
   }

   /**
   * *** For internal framework use only ***
   */
   public void rangeScrolled(ScrollEvent event)
   {
   }
   
   void release()
   {
      RowSetIterator listRSI = (mListIterBinding != null) ? mListIterBinding.getRowSetIterator() : null;
      if (listRSI != null) 
      {
         listRSI.removeListener(this);
      }
      super.release();
   }
}
