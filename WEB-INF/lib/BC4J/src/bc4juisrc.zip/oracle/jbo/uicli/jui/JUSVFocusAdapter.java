/*
 * @(#)JUSVFocusAdapter.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.uicli.jui;

import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import oracle.jbo.uicli.binding.JUControlBinding;
import oracle.jbo.uicli.binding.JUIteratorBinding;

/**
 * All JClient bindings create an instance of this adapter to notify the panel which
 * control and hence which binding is currently in focus.
 */
public class JUSVFocusAdapter extends FocusAdapter
{
   public static final int MULTI_ATTRIBUTE = -1;
   protected JUControlBinding mControlBinding;
   protected JUIteratorBinding mIterBinding;
   protected int mAttrIndex = MULTI_ATTRIBUTE;
   protected JUPanelBinding panelBinding;
   
   /**
   * Creates a focus adapter for the control associated with the given control binding.
   */
   public JUSVFocusAdapter(JUControlBinding controlBinding)
   {
      mControlBinding = controlBinding;
      mIterBinding = controlBinding.getIteratorBinding();
   }
   
   /**
   * Creates a focus adapter for the control associated with the given control binding and
   * registers interest in the attribute at the given index in the control binding.
   */
   public JUSVFocusAdapter(JUControlBinding controlBinding, int attrIndex)
   {
      mIterBinding = controlBinding.getIteratorBinding();
      mControlBinding = controlBinding;
      mAttrIndex = attrIndex;
   }
   
   /**
   * Notifies the containing panelBinding of the gain in focus by this adapter's control binding.
   */
   public void focusGained(FocusEvent e)
   {
      if (!e.isTemporary())
      {
         if (mIterBinding == null) 
         {
            mIterBinding = mControlBinding.getIteratorBinding();
         }
         if (panelBinding == null && mIterBinding != null) 
         {
            panelBinding = (JUPanelBinding)mIterBinding.getFormBinding();
         }
         if (panelBinding != null) 
         {
            panelBinding.focusGained(mIterBinding, mControlBinding, mAttrIndex);
         }
      }
   }


   /** 
   * A no-op
   */
   public void focusLost(FocusEvent e)
   {
   }
}
