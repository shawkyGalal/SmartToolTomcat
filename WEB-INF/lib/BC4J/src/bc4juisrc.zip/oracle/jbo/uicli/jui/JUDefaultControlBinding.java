/*
 * @(#)JUDefaultControlBinding.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.uicli.jui;

import java.awt.Component;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.lang.reflect.Constructor;
import javax.swing.JPanel;
import oracle.jbo.uicli.binding.JUCtrlAttrsBinding;
import oracle.jbo.uicli.binding.JUFormBinding;
import oracle.jbo.uicli.binding.JUIteratorBinding;

/**
 * Implements a generic binding for any Swing control (custom or not) to bind to a BC4J attribute. 
 * JClient custom controls like JUImageControl use this binding. Applications that use controls
 * other than the ones for which JClient binding is provided, may use this binding to get BC4J data from
 * the JClient framework and work with it in the control. Using this binding lets the panel, 
 * panelBinding, Status Bar, Navigation Bar, etc. be aware of data being displayed/edited in the 
 * custom control and update their status/display accordingly.
 * <p>
 * @see oracle.jbo.uicli.controls.JUImageControl
 */
public class JUDefaultControlBinding extends JUCtrlAttrsBinding implements ActionListener
{

   private Object mControlData;
   private JUDefaultControlInterface mChangeListener;

   /**
   * Default constructor for subclassing.
   */
   protected JUDefaultControlBinding()
   {
   }

   /**
   * This constructor should be used in controls/subclasses to pass the binding
   * information.
   * <p>
   * @param control Control which should be bound to an attribute of a BC4J row.
   * @param iterBinding JUIteratorBinding object that contains a reference to the RowSet Iterator that contains Rows to display.
   * @param attrName Name of the attribute in the BC4J Row object to display.
   */
   public JUDefaultControlBinding(JUDefaultControlInterface control, JUIteratorBinding iterBinding, String attrName)
   {
      super(control, iterBinding, new String[] { attrName });

      control.addFocusListener(new JUSVFocusAdapter(this));
      mChangeListener = control;
   }


   /**
   * *** For internal framework use only ***
   */
   public void addControlToPanel(Object panel, Object layoutObject, Object layoutCons)
   {
      ((JPanel) panel).add((Component) layoutObject, layoutCons);
   }

   
   /**
   * Returns the data that the bound control is displaying. This may be used to compare the
   * existing value in the control to decide if there has been a change in control's data.
   */
   public Object getValueAt(int attrIndex)
   {
      return mControlData;
   }


   /**
   * Updates the data that this binding holds. Note that this does not update the
   * BC4J attribute value, but simply updates the data in the binding.
   */
   public void setValueAt(Object value, int attrIndex)
   {
      mControlData = value;
      if (mChangeListener != null) 
      {
         mChangeListener.dataChanged(value);
      }
   }


   /**
   * This method updates the value this binding holds, as well as 
   * updates the BC4J attribute (hence marking the ensuing transaction dirty).
   */
   public void setDataValueAt(Object value, int attrIndex)
   {
      //setValueAt(value, attrIndex);

       // Richard Wang:
       // setValueAt() invokes mChangeListener.dataChanged();
       // setAttribute() eventually calls setValueAt() so it invokes
       // mChangeListener.dataChanged() again. Since dataChanged()
       // takes long time to initialize JMF player, there is
       // no need to call dataChanged() twice.
       //
       mControlData = value;

      setAttribute(0, value);
   }


   /**
   * Updates the BC4J attribute with the current data value in this binding.
   */
   public void actionPerformed(ActionEvent e)
   {
      try
      {
         setAttribute(0, getValueAt(0));
      }
      catch (Exception ex)
      {
         reportException(ex, true);
      }
   }


   /**
   * Creates an instance of this binding based on the given binding information.
   * <p>
   * @param formBinding The containing JUPanelBinding in which the given iterator binding
   * would be found/created.
   * @param control The control instance to bind to a ViewObject's attribute.
   * @param voInstanceName Name of the instance of the ViewObject in a BC4J ApplicationModule.
   * @param voIterName Runtime instance name of the iterator in the ViewObject (optional).
   * @param voIterBindingName Instance name of the iterator binding that uniquely identifies an
   * iterator binding object used to read/write data in this given JUPanelBinding instance.
   * @param attrName The name of the attribute of this ViewObject rows that contains data
   * to display/edit in the associated control.
   */
   public static JUDefaultControlBinding createAttributeBinding(JUFormBinding formBinding, 
                                                  JUDefaultControlInterface control,
                                                  String        voInstanceName,
                                                  String        voIterName, /*temporarily taking nulls for this*/
                                                  String        voIterBindingName,
                                                  String        attrName)
   {
      if (!JUIUtil.inDesignTime())
      {
         JUDefaultControlBinding bind = new JUDefaultControlBinding(control, 
                                    formBinding.getRowIterBinding(voInstanceName, voIterName, voIterBindingName),
                                    attrName);
         bind.refreshControl();
         return bind;
      }
      else
      {
         try
         {
            Class clazz = Class.forName("oracle.jbo.dt.ui.jui.propertyeditors.dtmodels.DTDefaultControlBinding");
            Constructor constructor = clazz.getConstructors()[0];
            Object [] args = { voInstanceName + "." + attrName };
            Object object = constructor.newInstance(args);
            return (JUDefaultControlBinding)object;
         }
         catch (Exception e)
         {
            return null;
         }
      }
   }

   /**
   * @deprecated since 9.0.2 use createAttributeBinding() instead.
   */
   public static JUDefaultControlBinding getInstance(JUFormBinding formBinding, 
                                                  JUDefaultControlInterface control,
                                                  String        voInstanceName,
                                                  String        voIterName, /*temporarily taking nulls for this*/
                                                  String        voIterBindingName,
                                                  String        attrName)
   {
      return createAttributeBinding(formBinding, control, voInstanceName, voIterName, voIterBindingName, attrName);
   }
}
