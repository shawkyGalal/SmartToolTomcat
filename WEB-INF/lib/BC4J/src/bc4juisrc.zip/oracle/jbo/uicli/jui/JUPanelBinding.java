/*
 * @(#)JUPanelBinding.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.uicli.jui;

import java.awt.LayoutManager;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.awt.Component;
import java.util.ArrayList;
import javax.swing.JPanel;
import oracle.jbo.ApplicationModule;
import oracle.jbo.AttributeDef;
import oracle.jbo.InvalidObjNameException;
import oracle.jbo.JboException;
import oracle.jbo.NavigatableRowIterator;
import oracle.jbo.NoObjException;
import oracle.jbo.Row;
import oracle.jbo.RowSetIterator;
import oracle.jbo.RangeRefreshEvent;
import oracle.jbo.ScrollEvent;
import oracle.jbo.InsertEvent;
import oracle.jbo.DeleteEvent;
import oracle.jbo.UpdateEvent;
import oracle.jbo.NavigationEvent;
import oracle.jbo.ViewObject;
import oracle.jbo.common.JboEnvUtil;
import oracle.jbo.uicli.UIMessageBundle;
import oracle.jbo.uicli.binding.JUApplication;
import oracle.jbo.uicli.binding.JUControlBinding;
import oracle.jbo.uicli.binding.JUFormBinding;
import oracle.jbo.uicli.binding.JUIteratorBinding;
import oracle.jbo.uicli.layout.JULayoutConsDef;
import oracle.jbo.uicli.mom.JUMetaObjectBase;
import oracle.jbo.uicli.mom.JUMetaObjectManager;

/**
 * A container class that manages JUIteratorBindings, etc.
 * by extending the JUFormBinding class. It provides:
 * <ul>
 * <li> Management of JUNavigationBarInterfaces bound to the iterators behind the iterator binding objects.
 * <li> Management of JUIteratorChangedListeners like NavigationBars, StatusBars and Menus.
 * <li> Management of JUPanelValidationListeners that perform attribute, panel and 
 * transaction level validations.
 * <li> Switching of iterators behind iterator-binding objects so that all relevant controls in this
 * form are updated with new data from the new iterator.
 * </ul>
 */
public class JUPanelBinding extends JUFormBinding
{
   protected String mAppName = "";
   String mAMName = null;

   protected ArrayList mNavigationBarList;
   protected ArrayList mIteratorChangedListeners;
   ArrayList mRowSetListeners;
   ArrayList mValidationListeners;
   ArrayList mBindingsWithCellEditor;
   JUControlBinding mBindingInFocus;

   private boolean mNavBarInit = false;

   /**
   * *** For internal framework use only ***
   */
   public JUPanelBinding()
   {
   }
   
   /**
   * Applications should use this constructor to create a panel binding and associate it
   * with a swing JPanel object. The binding thus created needs to be added to a JUApplication
   * object and is not completely usable until then.
   */
   public JUPanelBinding(JPanel panel)
   {
      super(panel);
   }

   /**
   * Creates an instance of this class, associating it with a JPanel object and a JUApplication
   * identified by appName. This constructor is used in the JClient design time generated code
   * to pass in the name of the Application Model definition name that identifies the middle-tier
   * (BC4J) connection and configuration information.
   */
   public JUPanelBinding(String appName, JPanel panel)
   {
      this(appName, null, panel);
   }

   /**
   * Creates an instance of this class, associating it with a JPanel object and a JUApplication
   * identified by appName. This constructor is used in the JClient design time generated code
   * to pass in the name of the Application Model definition name that identifies the middle-tier
   * (BC4J) connection and configuration information. This constructor also takes in the application
   * module name in case the BC4J application module for this panel is a nested application module.
   */
   public JUPanelBinding(String appName, String amName, JPanel panel)
   {
      super(panel);
      mAppName = appName;
      mAMName = amName;
   }

   /**
   * Sets up the JUApplication and Application Module references based on name passed to 
   * this object via the constructors or various setter methods.
   */
   protected void initializeApplicationModule()
   {
      if (mAM == null) 
      {
         JUApplication juApp = mApplication;
         
         if (juApp == null)
         {
            if (JboEnvUtil.isEmptyString(mAppName))
            {
               throw new InvalidObjNameException(JUMetaObjectBase.TYP_APPLICATION, mAppName);
            }
         
            juApp = JUMetaObjectManager.findApplicationObject(mAppName);
            if (juApp == null)
            {
               throw new NoObjException(JUMetaObjectBase.TYP_APPLICATION, mAppName);
            }

            juApp.addFormBinding(this);
            //setApplication(juApp);
         }

         ApplicationModule am = juApp.getApplicationModule();

         if (!JboEnvUtil.isEmptyString(mAMName))
         {
            am = am.findApplicationModule(mAMName);
            if (am == null)
            {
               throw new NoObjException(NoObjException.TYP_APP_MODULE, mAMName);
            }
         }

         setApplicationModule(am);
      }
      else if (mApplication == null) 
      {
         mApplication = new JUApplication(mAM);
      }
   }

   /**
   * *** For internal framework use only ***
   */
   public void initializePanel(ArrayList controls)
   {
      JPanel jPanel = (JPanel) getPanel();
      LayoutManager layout = (LayoutManager) getDef().getLayoutDef().createLayout();

      jPanel.setLayout(layout);

      for (int j = 0; j < controls.size(); j++)
      {
         JUControlBinding controlBnd = (JUControlBinding) controls.get(j);
         Object layoutObj = controlBnd.getLayoutObject();
         JULayoutConsDef layoutConsDef = controlBnd.getDef().getLayoutCons();
         Object layoutCons = null;

         if (layoutConsDef != null)
         {
            layoutCons = layoutConsDef.createLayoutCons();
         }

         controlBnd.addControlToPanel(jPanel, layoutObj, layoutCons);
      }
   }

   /**
   * Binds the iterator identified by iterBindingName in this panel with another ViewObject
   * in the current application module identified by the given voInstanceName.
   */
   public void bindRowSetIterator(String iterBindingName, String voInstanceName)
   {
      //do we need another flavor that binds a rowset name as well?
      bindRowSetIterator(iterBindingName, getApplicationModule().findViewObject(voInstanceName));
   }

   /**
   * Binds the iterator identified by iterBindingName in this panel with another iterator.
   * This method notifies all JUIteratorChangeListeners in this panel of the change
   * so that various NavigationBars, Menus, and Status bars can adjust their displays.
   * Applications could register their own JUIteratorChangeListeners so that they 
   * get notified of data changes resulting from a change in iterator, thus allowing them to update
   * the displays (like change button enabled state).
   */
   public void bindRowSetIterator(String iterBindingName, RowSetIterator rsi)
   {
      JUIteratorBinding iterBnd = findIterBinding(iterBindingName);
      if (iterBnd == null) 
      {
         reportException(new JboException(UIMessageBundle.class, 
                                          UIMessageBundle.EXC_INVALID_ITER_BINDING_NAME, 
                                          new String[] {iterBindingName}));  

      }
      else
      {
         //force the rangeSize from the binding on this iterator, so that
         //grid/other-controls display proper number of rows instead of
         //whatever the setting is on the rsi itself.
         iterBnd.bindRowSetIterator(rsi, true);
         notifyIteratorChanged(iterBnd, true);
      }
   }  

   /**
   * Notifies all JUIteratorChangedListeners and JUNavigationBarInterface objects registered
   * with this panel of the change in iterator binding. If refresh parameter is true,
   * like when there is a change in the iterator behind the iterator binding instance or a
   * change in data/find mode of the panel, then this method raises a rangeRefreshed event
   * on the iteratorBinding object so that all controls also adjust/udpate their displays.
   */
   protected final void notifyIteratorChanged(JUIteratorBinding iterBnd, boolean refresh)
   {
      //force an event so that all controls are tickled to 
      //redisplay their data.
      if (refresh) 
      {
         iterBnd.rangeRefreshed(null);
      }
      
      ArrayList al = mIteratorChangedListeners;
      
      NavigatableRowIterator rsi = iterBnd.getNavigatableRowIterator();
      String rsiBindingName = iterBnd.getName();
      if (al != null)
      {
         JUIteratorChangedListener l;
         for (int i = 0; i < al.size(); i++) 
         {
            l = ((JUIteratorChangedListener)al.get(i));
            l.iteratorChanged(rsiBindingName, rsi);
         }
      }

      //notify navigationbar of the iterator change.
      al = mNavigationBarList;
      if (al != null)
      {
         JUNavigationBarInterface l;
         for (int i = 0; i < al.size(); i++) 
         {
            l = ((JUNavigationBarInterface)al.get(i));
            l.iteratorBindingChanged(iterBnd);
         }
      }
   }

   /**
   * Adds a listener that should be notified when the iterator behind an iterator
   * binding object changes or the display mode changes from find to data mode or
   * the reverse.
   */
   public final void addIteratorChangedListener(JUIteratorChangedListener l)
   {
      if (mIteratorChangedListeners == null) 
      {
         mIteratorChangedListeners = new ArrayList(5);
      }
      mIteratorChangedListeners.add(l);
   }

   /**
   * Remove a listener from this list.
   */
   public final void removeIteratorChangedListener(JUIteratorChangedListener l)
   {
      if (mIteratorChangedListeners != null) 
      {
         mIteratorChangedListeners.remove(l);
      }
   }



   /**
   * Adds a NavigationBar (or like object) that needs to listen into changes
   * in an iterator, and focus events, etc. By default the framework adds
   * all Navigation Bars bound to the Panel Binding object into this list, so
   * that these Navigation bars adjust their display based on current iterator
   * in focus/use.
   */
   public final void addNavigationBar(JUNavigationBarInterface navBar)
   {
      if (mNavigationBarList == null) 
      {
         mNavigationBarList = new ArrayList(5);
      }
      mNavigationBarList.add(navBar);
      mNavBarInit = false;
   }

   /**
   * Removes a JUNavigationBarInterface listener object from the list.
   */
   public final void removeNavigationBar(JUNavigationBarInterface navBar)
   {
      if (mNavigationBarList != null) 
      {
         mNavigationBarList.remove(navBar);
      }
   }

   /**
   * Notifies the JUApplication object of focusGained event so that it could pass it on to
   * its StatusBarInterface listeners (like JUStatusBar to update status message).
   * Then this method notifies each JUNavigationBarInterface object in this object's list of
   * the change in focus, so that the NavigationBars can adjust their display based on 
   * the current iterator binding.
   */
   public void focusGained(JUIteratorBinding iterBinding, JUControlBinding binding, int attrIndex)
   {
      //pass this on to navigation bar, status bar.
      if (mApplication != null)
      {
         //once JClient App takes over the control of creating PanelBindings,
         //this if check should go away.
         mApplication.focusGained(iterBinding, binding, attrIndex); 
      }

      if (mNavigationBarList != null)
      {
         JUIteratorBinding currentIter = null;
         ArrayList al = getIterBindingList();
         int size = al.size();
         if (size > 1)
         {
            //this could be optimized by keeping track of current iterator.
            currentIter = iterBinding;
         }
         else if (!mNavBarInit && size > 0) 
         {
            mNavBarInit = true;
            currentIter = (JUIteratorBinding)al.get(0);
         }

         if (currentIter != null) 
         {
            al = mNavigationBarList;
            for (int i = 0; i < al.size(); i++) 
            {
               ((JUNavigationBarInterface)al.get(i)).iteratorBindingChanged(currentIter);
            }
         }
      }

      mBindingInFocus = binding;
   }

   /**
   * Returns the name of the JUApplication object in which this Panel binding was created.
   */
   public final String getApplicationName()
   {
      return mAppName;
   }

   /**
   * Returns the Application Module instance name to which this Panel binding is connected.
   */
   public final String getAppModuleName()
   {
      return mAMName;
   }

   /**
   * Returns true, if the Transaction behind the associated ApplicationModule has pending changes
   * In three-tier, this method will go across the tier boundary to get the actual middle-tier transaction
   * status.
   */
   public final boolean isTransactionDirty()
   {
      return getApplicationModule().getTransaction().isDirty();
   }

   /**
   * Sets the given object as the JPanel object associated with this panel binding.
   */
   public final void setPanel(Object panel)
   {
      super.setPanelInternal(panel);
   }

   /**
   * Returns a list of JUPanelValidationListeners (returns an empty list if no such listener was registered).
   */
   public final ArrayList getValidationListeners()
   {
      return (mValidationListeners != null) ? (ArrayList)mValidationListeners.clone() : new ArrayList(0);
   }
   
   /**
   * Adds the given listener to this panel's validation listeners list.
   */
   public final void addValidationListener(JUPanelValidationListener l)
   {
      if (mValidationListeners == null) 
      {
         mValidationListeners = new ArrayList(4);
      }
      if (!mValidationListeners.contains(l)) 
      {
         mValidationListeners.add(l);
      }
   }
   
   /**
   * Removes the given listener from this panel's validation listeners list.
   */
   public final void removeValidationListener(JUPanelValidationListener l)
   {
      if (mValidationListeners != null) 
      {
         mValidationListeners.remove(l);
      }
   }

   /**
   * Returns a list of JUPanelRowSetListeners (returns an empty list if no such listener was registered).
   */
   public final ArrayList getRowSetListeners()
   {
      return (mRowSetListeners != null) ? (ArrayList)mRowSetListeners.clone() : new ArrayList(0);
   }
   
   /**
   * Adds the given listener to this panel's RowSet listeners list.
   */
   public final void addRowSetListener(JUPanelRowSetListener l)
   {
      if (mRowSetListeners == null) 
      {
         mRowSetListeners = new ArrayList(4);
      }
      if (!mRowSetListeners.contains(l)) 
      {
         mRowSetListeners.add(l);
      }
   }
   
   /**
   * Removes the given listener from this panel's RowSet listeners list.
   */
   public final void removeRowSetListener(JUPanelRowSetListener l)
   {
      if (mRowSetListeners != null) 
      {
         mRowSetListeners.remove(l);
      }
   }

   
   /**
   * Calls beforeSetAttribute() method to notify all validation listeners.
   */
   protected void callBeforeSetAttribute(JUControlBinding ctrl,
                                   Row row,
                                   AttributeDef ad,
                                   Object value)
   {
      if (mApplication != null) 
      {
         //for the first case when transaction is clean and on setAttr, the txn has
         //to be set to modified state (even though the middletier is not in modified
         //state yet as no sync has occured thus far.
         
         //check if in find mode. in that case do not set the txnmodified state to true.
         if (!ctrl.getIteratorBinding().isFindMode()) 
         {
            mApplication.setTransactionModified();
         }
      }
      beforeSetAttribute(new JUPanelValidationEvent(ctrl, this, ctrl.getIteratorBinding(), row, ad.getName(), value));
   }

   /**
   * Forces the current control to stop its editing mode (if used, like in JTable).
   * Calls beforeRowNavigated() method to notify all validation listeners.
   */
   protected void callBeforeRowNavigated(JUIteratorBinding iter)
   {
      stopEditing();
      Row row = iter.getCurrentRow();
      if (row != null) 
      {
         beforeCurrencyChange(new JUPanelValidationEvent(this, iter, row));
      }
   }
   
   /**
   * Forces the current control to stop its editing mode (if used, like in JTable).
   * Calls beforeSaveTransaction() method to notify all validation listeners.
   */
   protected void callBeforeSaveTransaction(oracle.jbo.Transaction txn)
   {
      stopEditing();
      beforeSaveTransaction(new JUPanelValidationEvent(this, txn));
   }

   /**
   * Notifies all JUPanelValidationListeners with the beforeSetAttribute event.
   * This event is raised before a control binding sets the value from a control
   * into the corresponding BC4J row's attribute.
   */
   public void beforeSetAttribute(JUPanelValidationEvent ev)
   {
      if (mValidationListeners != null) 
      {
         ArrayList al = mValidationListeners;
         for (int i = 0; i < al.size(); i++) 
         {
            ((JUPanelValidationListener)al.get(i)).beforeSetAttribute(ev);
         }
      }
   }
   
   /**
   * Notifies all JUPanelValidationListeners with the beforeCurrencyChange event.
   * This event is raised before an iterator-binding object moves the current row
   * to another row.
   */
   public void beforeCurrencyChange(JUPanelValidationEvent ev)
   {
      if (mValidationListeners != null) 
      {
         ArrayList al = mValidationListeners;
         for (int i = 0; i < al.size(); i++) 
         {
            ((JUPanelValidationListener)al.get(i)).beforeCurrencyChange(ev);
         }
      }
   }
   
   /**
   * Notifies all JUPanelValidationListeners with the beforeSaveTransaction event.
   * The JClient framework calls this method before invoking commit() on the BC4J transaction.
   */
   public void beforeSaveTransaction(JUPanelValidationEvent ev)
   {
      if (mValidationListeners != null) 
      {
         ArrayList al = mValidationListeners;
         for (int i = 0; i < al.size(); i++) 
         {
            ((JUPanelValidationListener)al.get(i)).beforeSaveTransaction(ev);
         }
      }
   }

   /**
    * Invoked when a JUIteratorBinding receives a rangeRefreshed Event from BC4J RowSetIterator
    * @param JUIteratorBinding that received the rangeRefreshed event.
    * @param event a description of the new ranges.
    */
   protected void rangeRefreshed(JUIteratorBinding iter, RangeRefreshEvent event)
   {
      if (mRowSetListeners != null) 
      {
         ArrayList al = (ArrayList)mRowSetListeners.clone();
         int count = al.size();
         for (int i = 0; i < count; i++) 
         {
            ((JUPanelRowSetListener)al.get(i)).rangeRefreshed(iter, event);
         }
      }
   }

   /**
    * Invoked when a JUIteratorBinding receives a rangeScrolled Event from BC4J RowSetIterator
    * @param JUIteratorBinding that received the rangeScrolled event.
    * @param event a description of the new range.
    */
   protected void rangeScrolled(JUIteratorBinding iter, ScrollEvent event)
   {
      if (mRowSetListeners != null) 
      {
         ArrayList al = (ArrayList)mRowSetListeners.clone();
         int count = al.size();
         for (int i = 0; i < count; i++) 
         {
            ((JUPanelRowSetListener)al.get(i)).rangeScrolled(iter, event);
         }
      }
   }

   /**
    * Invoked when a JUIteratorBinding receives a rowInserted Event from BC4J RowSetIterator
    * @param JUIteratorBinding that received the rowInserted event.
    * @param event a description of the new Row object.
    */
   protected void rowInserted(JUIteratorBinding iter, InsertEvent event)
   {
      if (mRowSetListeners != null) 
      {
         ArrayList al = (ArrayList)mRowSetListeners.clone();
         int count = al.size();
         for (int i = 0; i < count; i++) 
         {
            ((JUPanelRowSetListener)al.get(i)).rowInserted(iter, event);
         }
      }
   }

   /**
    * Invoked when a JUIteratorBinding receives a rowDeleted Event from BC4J RowSetIterator
    * @param JUIteratorBinding that received the rowDeleted event.
    * @param event a description of the deleted Row object.
    */
   protected void rowDeleted(JUIteratorBinding iter, DeleteEvent event)
   {
      if (mRowSetListeners != null) 
      {
         ArrayList al = (ArrayList)mRowSetListeners.clone();
         int count = al.size();
         for (int i = 0; i < count; i++) 
         {
            ((JUPanelRowSetListener)al.get(i)).rowDeleted(iter, event);
         }
      }
   }

   /**
    * Invoked when a JUIteratorBinding receives a rowUpdated Event from BC4J RowSetIterator
    * @param JUIteratorBinding that received the rowUpdated event.
    * @param event a description of the modified Row object.
    */
   protected void rowUpdated(JUIteratorBinding iter, UpdateEvent event)
   {
      if (mRowSetListeners != null) 
      {
         ArrayList al = (ArrayList)mRowSetListeners.clone();
         int count = al.size();
         for (int i = 0; i < count; i++) 
         {
            ((JUPanelRowSetListener)al.get(i)).rowUpdated(iter, event);
         }
      }
   }

   /**
    * Invoked when a JUIteratorBinding receives a navigated Event from BC4J RowSetIterator
    * @param JUIteratorBinding that received the navigated event.
    * @param event a description of the new and previous current rows.
    */
   protected void navigated(JUIteratorBinding iter, NavigationEvent event)
   {
      if (mRowSetListeners != null) 
      {
         ArrayList al = (ArrayList)mRowSetListeners.clone();
         int count = al.size();
         for (int i = 0; i < count; i++) 
         {
            ((JUPanelRowSetListener)al.get(i)).navigated(iter, event);
         }
      }
   }

   
   /**
   * Sets this panel and all its associated iterators into find mode.
   */
   public void setFindMode(boolean mode)
   {
      stopEditing();
      super.setFindMode(mode);
   }
   
   
   /**
   * Adds a listener that is interested in notification such that it stops its control's edit process
   * before the panel is moved to a different set of data.
   */
   public void addBindingWithCellEditor(JUPanelStopEditingListener binding)
   {
      if (mBindingsWithCellEditor == null) 
      {
         mBindingsWithCellEditor = new ArrayList(6);
      }
      mBindingsWithCellEditor.add(binding);
   }
   
   
   /**
   * Removes a listener from the list.
   */
   public void removeBindingWithCellEditor(JUPanelStopEditingListener binding)
   {
      if (mBindingsWithCellEditor != null) 
      {
         mBindingsWithCellEditor.remove(binding);
      }
   }
   
   /**
   * Notifies all JUPanelStopEditingListeners to stop editing, so that their values
   * can be updated with new set of data. This method is invoked before changing
   * the find/data mode, or switching iterators behind an iterator binding, or
   * before committing/rolling back the database transaction.
   */
   public void stopEditing()
   {
      if (mBindingsWithCellEditor != null) 
      {
         ArrayList bndList = mBindingsWithCellEditor;
         int size = bndList.size();
         for (int j = 0; j < bndList.size(); j++)
         {
            JUPanelStopEditingListener bnd = (JUPanelStopEditingListener) bndList.get(j);
            bnd.stopEditing();
         }
      }

      if (mBindingInFocus != null && mBindingInFocus.getControl() != null)
      {
         Component comp = (Component)mBindingInFocus.getControl();
         {
            FocusListener[] l = comp.getFocusListeners();
            if (l != null)
            {
               for (int i = 0; i < l.length; i++)
               {
                  if (l[i] instanceof JUSVUpdateableFocusAdapter)
                  {
                     oracle.jbo.common.Diagnostic.println("Force tranfer of focus for applying last focused control changes!");
                     FocusEvent ev = new FocusEvent(comp, FocusEvent.FOCUS_LOST);
                     ((JUSVUpdateableFocusAdapter)l[i]).focusLost(ev);
                  }
               }
            }
         }
      }
   }

   public ViewObject[] getOrderedVOUsageList()
   {
      /*if (mPanel instanceof JUPanelInterface) 
      {
      }
      */
      return super.getOrderedVOUsageList();
   }
}
