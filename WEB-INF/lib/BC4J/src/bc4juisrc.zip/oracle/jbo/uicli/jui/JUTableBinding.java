/*
 * @(#)JUTableBinding.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.uicli.jui;

import java.awt.Component;
import java.awt.event.HierarchyEvent;
import java.awt.event.HierarchyListener;
import java.lang.reflect.Constructor;
import javax.swing.BoundedRangeModel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.ListSelectionModel;
import javax.swing.SwingConstants;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.event.TableModelListener;
import javax.swing.table.AbstractTableModel;
import javax.swing.table.TableCellEditor;
import javax.swing.table.TableModel;
import oracle.jbo.AttributeDef;
import oracle.jbo.DeleteEvent;
import oracle.jbo.InsertEvent;
import oracle.jbo.JboException;
import oracle.jbo.NavigationEvent;
import oracle.jbo.Row;
import oracle.jbo.RowIterator;
import oracle.jbo.RowSetIterator;
import oracle.jbo.ScrollEvent;
import oracle.jbo.common.DebugDiagnostic;
import oracle.jbo.uicli.binding.JUCtrlRangeBinding;
import oracle.jbo.uicli.binding.JUIteratorBinding;

/**
 * A lightweight TableModel that implements
 * binding a <code>javax.swing.JTable</code> to a RowIterator for a BC4J ViewObject.
 * <p>
 * Applications should subclass this binding and return a subclass of 
 * JUTableModel that can:
 * <ul>
 * <li>Perform application-specific sorting of rows displayed in a JTable.</li>
 * <li>Dynamically display/hide certain columns based on user preferences or application logic.</li>
 * </ul>
 * <p> 
 * This class creates a runtime instance of JUTableModel to interact with
 * a JTable instance. It is responsible for:
 * <ul>
 * <li>Managing Row and iterator events from BC4J layer and calls appropriate JTableModel
 * methods to update JTable display.</li>
 * <li>Manages edits using the current Cell Editor by cancelling/accepting edits from the
 * current cell editor.</li>
 * </ul>
 * <p>
 * 
 * 
 * @see oracle.jbo.RowIterator
 * @see oracle.jbo.ViewObject
 * @see javax.swing.JTable
 * @see javax.swing.table.TableModel
 * @see javax.swing.table.AbstractTableModel
 */
public class JUTableBinding extends JUCtrlRangeBinding
   implements TableModel, JUPanelStopEditingListener, HierarchyListener
{
   private JUTableModel mTableModel;
   private JScrollPane mScrollPane;
   private JUTableScrollBarListener mScrollBarListener;
   private int mScrollUnit;
   private int mNumVisRows = 0;
   
   JUPanelBinding mPanelBinding;


   /**
   * Creates an instance of JUTableBinding to return. Registers this binding as a binding that
   * has its own cell-editor that needs to be notified for stopping/cancelling edits when
   * the panel needs to invoke a panel-level operation like changing find/data mode and so forth.
   */
   public static TableModel createAttributeListBinding(JUPanelBinding formBinding, 
                                                  JTable        control,
                                                  String        voInstanceName,
                                                  String        voIterName, /*temporarily taking nulls for this*/
                                                  String        voIterBindingName,
                                                  String[]      attrNames)
   {
      return createAttributeListBinding(formBinding, control,
                                        voInstanceName, voIterName, 
                                        voIterBindingName, attrNames,
                                        false, null);
   }

   /**
   * Creates an instance of JUTableBinding to return. Registers this binding as a binding that
   * has it's own cell-editor that needs to be notified for stopping/cancelling edits when
   * the panel needs to invoke a panel-level operation like change find/datamode etc.
   */
   public static TableModel createAttributeListBinding(JUPanelBinding formBinding, 
                                                  JTable        control,
                                                  String        voInstanceName,
                                                  String        voIterName, /*temporarily taking nulls for this*/
                                                  String        voIterBindingName,
                                                  String[]      attrNames,
                                                  boolean       columnSort,
                                                  JUTableSortModel        sorter 
                                                  )
   {
      if (!JUIUtil.inDesignTime())
      {
         JUTableBinding bind = new JUTableBinding(control, 
                                       formBinding.getRowIterBinding(voInstanceName, voIterName, voIterBindingName),
                                       attrNames);
         bind.refreshControl();
         bind.mPanelBinding = formBinding;
         formBinding.addBindingWithCellEditor(bind);
         
         bind.findParent();

         JUTableModel model = bind.getModel();
         if (columnSort) 
         {
            return JUTableSortModel.enableColumnSorting(control, bind, sorter);
         }
         return model;
      }
      else
      {
         try
         {
            Class clazz = Class.forName("oracle.jbo.dt.ui.jui.propertyeditors.dtmodels.DTJTableBinding");
            Constructor [] cons = clazz.getConstructors();
            Constructor constructor = null;
            for (int i=0; i < cons.length; i++)
            {
               if (cons[i].getParameterTypes().length == 2)
               {
                  constructor = cons[i];
                  continue;
               }
            }

            String firstAttribute = "";
            if (attrNames != null && attrNames.length != 0)
               firstAttribute = attrNames[0];
            int size = attrNames == null ? 0 : attrNames.length;
            StringBuffer stbuf = new StringBuffer(firstAttribute);
            for (int i=1; i<size; i++)
            {
               stbuf.append(",");
               stbuf.append(attrNames[i]);
            }
      

            Object [] args = { voInstanceName + "." + stbuf.toString(), new Boolean(columnSort) };
            Object object = constructor.newInstance(args);
            return (TableModel)object;
         }
         catch (Exception e)
         {
            return null;
         }
      }
   }

   
   /**
   * @deprecated since 9.0.2
   */
   public static TableModel getInstance(JUPanelBinding formBinding, 
                                                  JTable        control,
                                                  String        voInstanceName,
                                                  String        voIterName, /*temporarily taking nulls for this*/
                                                  String        voIterBindingName,
                                                  String[]      attrNames)
   {
      return createAttributeListBinding(formBinding, control, voInstanceName, voIterName, voIterBindingName, attrNames);
   }

   
   /**
   * Creates an instance of JUTableModel that performs the binding of a BC4J ViewObject with
   * a JTable. This binding class performs the role of an intermediary between the JUTableModel
   * which implements a TableModel to work with the JTable object and the BC4J framework.
   * <p>
   * This class is responsible for:
   * <ul>
   * <li>Calculating how many rows to display in a JTable (based on JTable size).</li>
   * <li>Reacting to the BC4J row and iterator events to update display and currency.</li>
   * </ul>
   */
   public JUTableBinding(JTable control, JUIteratorBinding iterBinding, String[] attrNames)
   {
      super(control, iterBinding, attrNames);

      init(control);
   }

   private void init(JTable control)
   {
      if (control != null)
      {
         if (mTableModel != control.getModel())
         {
            mTableModel = getModelImpl(control);
         }

         control.addHierarchyListener(this);
      }
   }
   
   
   /**
   * Notified by NavigationBar to stop any edits on the current control.
   * Primarily for grid and tree to notify their cell editors to stop
   * editing.
   */
   boolean inStopEditing = false;   //to break event cycles.
   public void stopEditing() 
   {
      if (inStopEditing) 
      {
         return;
      }

      JTable table = (JTable)getControl();
      TableCellEditor editor = table.getCellEditor();
      if (editor != null) 
      {
         try
         {
            inStopEditing = true;
            editor.stopCellEditing();
         }
         finally
         {
            inStopEditing = false;
         }
      }
   }
   
   public JUTableModel getModel()
   {
      return mTableModel;
   }

   /**
   * Returns an instance of JUTableModel that this binding works with and is
   * applied as the JTableModel to the given JTable control. 
   * <p>
   * Override this method to return a subclass of JUTableModel to perform
   * customizations on the table model like:
   * <ul>
   * <li>Implementing client-side sorting of rows in the grid.</li>
   * <li>Relay out the column order based on some user-preference.</li>
   * <li>Hide some columns from the display.</li>
   * <li>Provide custom renderers or change default renderers.</li>
   * </ul>
   */
   protected JUTableModel getModelImpl(JTable control)
   {
      JUTableModel model = mTableModel;
      if (model == null)
      {
         model = new JUTableModel(control);
      }
      return model;
   }

   /**
   * Returns true by default to imply that this binding supports Find mode.
   * Subclasses can override this method to return false if this binding should
   * not display ViewCriteria rows in Find mode.
   */
   protected boolean isControlQueriable()
   {
      return true;
   }
   
   /**
   * *** For internal framework use only ***
   */
   public void addControlToPanel(Object panel, Object layoutObject, Object layoutCons)
   {
      ((JPanel) panel).add((Component) layoutObject, layoutCons);
   }


   /**
   * *** For internal framework use only ***
   * <p>
   * Returns the scrollpane object in which the JTable control is displayed. If
   * JTable is not displayed in a scrollpane, then this method returns the JTable
   * control instance.
   */
   public Object getLayoutObject()
   {
      if (mScrollPane == null)
      {
         return getControl();
      }
      else
      {
         return mScrollPane;
      }
   }

   
   /**
   * *** For internal framework use only ***
   */
   void findParent()
   {
      if (mScrollPane == null)
      {
         JTable control = (JTable) getControl();

         if (control != null)
         {
            Component parent = control.getParent();
   
            while (parent != null)
            {
               if (parent instanceof JScrollPane)
               {
                  break;
               }
      
               parent = parent.getParent();
            }
      
            if (parent != null)
            {
               setLayoutObject((JScrollPane) parent);
            }
         }
      }
   }
   
   
   /**
   * *** For internal framework use only ***
   */
   public void setLayoutObject(JScrollPane scrollPane)
   {
      if (mScrollPane != null)
      {
         mScrollPane.getViewport().removeChangeListener(mTableModel);

         if (mScrollBarListener != null)
         {
            mScrollPane.getVerticalScrollBar().getModel().removeChangeListener(mScrollBarListener);
            mScrollBarListener = null;
         }
      }
      
      mScrollPane = scrollPane;
      mNumVisRows = 0;

      if (mScrollPane != null)
      {
         mScrollPane.getViewport().addChangeListener(mTableModel);

         mScrollBarListener = new JUTableScrollBarListener();
         mScrollPane.getVerticalScrollBar().getModel().addChangeListener(mScrollBarListener);
      }
   }


   int getScrollUnit()
   {
      return mScrollUnit;
   }

      
   /**
   * Updates the JTable's display with the given set of rows after optionally
   * clearing out the current rows (if clear is true).
   */
   public void updateValuesFromRows(Row[] rows, boolean clear)
   {
      //calling super starts setting value back into rows which
      //is not desirable as this method is for updating values
      //in the control.

      //super.updateValuesFromRows(rows, clear);
      //this leads to double - painting in the beginning - one from paint processing
      //and one from RowIterator event. We need to solve this problem post-beta.

      //handling of rangeRefreshed event turns 

/*
      // sim 12/17/01 -- Commenting out the hack.  The problem was caused
      //                 by the fact that setRangeSize() causes rangeRefreshed
      //                 event.  This event in 3 tier reset the RSI pos (by
      //                 calling resetCrack()) even when MT didn't reset pos.
      //                 Fixed the problem by adding an additional piggyback info
      //                 on PiggybackEventEntry.  Don't need this block any more.

      if (clear) 
      {
         //testcases basic\si17-18-19
         //this is a pure hack. this has to be looked into post 902 to 
         //fix by sending in the currency in refreshRange event itself.
         //as of now it's being sent in the next piggyback entry but
         //that's a bit late.

         //rangeRefreshed event in 3tier resets the currency to -1, so
         //try if there's a current row and if not set the first row as current.
         RowIterator iter = getRowIterator();
         Row r = iter.getCurrentRow();
         if (r == null) 
         {
            iter.first();
         }
      }
*/

      mTableModel.refresh(clear); //if clear reselect the current row.

   }


   /**
   * Adjusts the scrollbar of the associated JTable and also refreshes the display
   * with the current set of rows in range in the associated RowIterator. This method
   * does not change the currency of the iterator.
   */
   public void updateRangeScrolled(ScrollEvent event)
   {
      mTableModel.updateRangeScrolled(event);
   }

   /**
   * When a new row is inserted into the associated Iterator, this method gets invoked
   * by the framework. This binding stops the current cell editing (if there is a current
   * cell being edited) and then refreshes the JTable's display to accommodate the new row.
   */
   public void updateRowInserted(InsertEvent event)
   {
      JTable jTab = (JTable) getControl();

      if (jTab.isEditing())
      {
         jTab.getCellEditor().stopCellEditing();
      }

      super.updateRowInserted(event);

      mTableModel.refresh(true /*selectRow*/);
   }
   
   
   /**
   * When a row is deleted in the associated iterator, this method gets invoked by
   * the framework, so that this binding can update the displayed rows in the JTable
   * after stopping the edit function on the current cell (if a cell was being edited).
   */
   public void updateRowDeleted(DeleteEvent event)
   {
      JTable jTab = (JTable) getControl();

      //remove and not stop as this stopping will call setAttribute again
      //leading to cycles in case of master/detail and details's FK change
      //see bug 2383961 for example.
      if (jTab.isEditing())
      {
         jTab.removeEditor();
      }

      mTableModel.refresh(true /*selectRow*/);
   }

   
   /**
   * Adjusts the display to move the current row selection to the new current row.
   * This method removes/cancels the current cell being edited (if any) before moving
   * the row selection to the new current row.
   */
   public void updateNavigated(NavigationEvent event)
   {
      JTable jTab = (JTable) getControl();

      if (jTab.isEditing())
      {
         jTab.removeEditor();
      }

      mTableModel.updateNavigated(event);
   }

   
   //
   // HierarchyListener implementation
   //
   
   public void hierarchyChanged(HierarchyEvent e)
   {
      findParent();
      
      if (mNumVisRows == 0 && mTableModel != null)
      {
         mTableModel.stateChanged(null);
      }
   }
   
   
   //
   // TableModel implementation
   //

   public int getRowCount()
   {
      return mTableModel.getRowCount();
   }


   public int getColumnCount()
   {
      return mTableModel.getColumnCount();
   }


   public String getColumnName(int columnIndex)
   {
      return mTableModel.getColumnName(columnIndex);
   }


   public Class getColumnClass(int columnIndex)
   {
      return mTableModel.getColumnClass(columnIndex);
   }


   public boolean isCellEditable(int rowIndex, int columnIndex)
   {
      return mTableModel.isCellEditable(rowIndex, columnIndex);
   }
   

   public Object getValueAt(int rowIndex, int columnIndex)
   {
      return mTableModel.getValueAt(rowIndex, columnIndex);
   }


   public void setValueAt(Object aValue, int rowIndex, int columnIndex)
   {
      mTableModel.setValueAt(aValue, rowIndex, columnIndex);
   }


   public void addTableModelListener(TableModelListener l)
   {
      mTableModel.addTableModelListener(l);
   }

   public void removeTableModelListener(TableModelListener l)
   {
      mTableModel.removeTableModelListener(l);
   }

   
   JUTableBinding getMyBinding()
   {
      return this;
   }

   
   /**
   * This TableModel is used by JUTableBinding to perform updates of the JTable
   * control to which it is bound. This class is responsible for:
   * <ul>
   * <li>Updating the displayed data in JTable.</li>
   * <li>Accepting edits from the JTable and passing it to the appropriate Row in the BC4J layer.</li>
   * <li>Managing the scrollbar associated with the associated JTable's display.</li>
   * <li>Passing the class of the data in each column thats displayed to the JTable
   * so that it can use an appropriate display renderer or cell editor.</li>
   * <li>Editability of cells based on whether the current attribute in the current row 
   * is editable or not.</li>
   * </ul>
   */
   protected class JUTableModel extends AbstractTableModel
                                implements ListSelectionListener, ChangeListener
   {
      private boolean mSelRowInProg = false;
      private boolean mPartialRowVisible = false;

      JUTableModel(JTable control)
      {
         mScrollUnit = control.getScrollableUnitIncrement(null, SwingConstants.VERTICAL, 0);

         TableModel oldModel = (TableModel)control.getModel();
         
         if (oldModel instanceof JUTableBinding) 
         {
            //we set the model to be JUTableBinding after returning from this method
            //so the old model should be of that type.
            ListSelectionModel oldListSelectModel = control.getSelectionModel();
            oldListSelectModel.removeListSelectionListener(((JUTableBinding)oldModel).mTableModel);
         }
         if (oldModel instanceof JUTableModel) 
         {
            //oldModel is never an instanceof JUTableModel, but I'm still checking
            //to be sure. -sjv
            ListSelectionModel oldListSelectModel = control.getSelectionModel();
            oldListSelectModel.removeListSelectionListener((JUTableModel)oldModel);
         }
         control.setModel(this);

         ListSelectionModel selectModel = control.getSelectionModel();

         selectModel.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
         selectModel.addListSelectionListener(this);
      }


      void fireTableDataChangedRestoreSelection(boolean restoreSelection)
      {
         JTable jTable = (JTable) getControl();
         int rowSel = jTable.getSelectedRow();

         mSelRowInProg = true;

         try
         {
            fireTableDataChanged();

            if (restoreSelection && rowSel >= 0 && getEstimatedRowCount() > 0) 
            {
               if (jTable.getSelectedRow() < 0 && rowSel >= 0)
               {
                  //si21 -M3 needs this to be inside SelRowInProg loop.
                  selectRowOfIndex(rowSel);
               }
            }
         }
         finally
         {
            mSelRowInProg = false;
         }
      }

      
      void updateRangeScrolled(ScrollEvent event)
      {
         if (mScrollBarListener != null && mScrollBarListener.isInScrollBarStateChange() == false)
         {
            mScrollPane.getVerticalScrollBar().setValue(event.getRangeStart() * mScrollUnit);
         }

         fireTableDataChangedRestoreSelection(true /*restoreSelection*/);
      }


      void updateNavigated(NavigationEvent event)
      {
         DebugDiagnostic.println("Navigated to " + event.getRowIndex());
         // This is to go through the case the navigation event arrive first.
         // Since we are navigating there is at least one row.
         // if (rowCount == 0)
         // {
         //    rowCount++;
         // }
         int index = event.getRowIndex();
         RowIterator iter = getRowIterator();
         if (iter != null)
         {
            int rowIndex = (index < 0) ? -1 : index + iter.getRangeStart();

            JTable jTable = (JTable) getControl();
            if (rowIndex >= 0 && jTable.getSelectedRow() != rowIndex) 
            {
               if (jTable.getAutoscrolls()) 
               {
                  oracle.jbo.common.Diagnostic.println("Navigating to "+rowIndex);
                  java.awt.Rectangle cellRect = jTable.getCellRect(rowIndex, 0, false);
                  if (cellRect != null) 
                  {
                     jTable.scrollRectToVisible(cellRect);
                  }
               }
            }

            //donot call setCurrentRowAtRangeIndex since navigation should
            //have resulted in current row already. Table should simply
            //highlight it's row.
            mSelRowInProg = true;
            try
            {
               selectRowOfIndex(rowIndex);
            }
            finally
            {
               mSelRowInProg = false;
            }
         }
      }


      private void selectRowOfIndex(int rowIndex)
      {
         //if this is set to true here, then, when a scrollbar is moved using arrow keys,
         //then list-selection moves but fails to set focus to currently selected row
         //mSelRowInProg = true;
         //try
         //{
            JTable jTable = (JTable) getControl();

            if (rowIndex >= 0) // && (tableRow = rangeRow + iter.getRangeStart()) < rowCount) // -1 if null or out of range
            {
               DebugDiagnostic.println("Selecting " + rowIndex);
               jTable.getSelectionModel().setSelectionInterval(rowIndex, rowIndex);
            }
            else
            {
               jTable.getSelectionModel().clearSelection();
            }
         //}
         //finally
         //{
            //mSelRowInProg = false;
         //}
      }

      
      private void refresh(boolean selectRow)
      {
         RowIterator iter = getRowIterator();

         if (iter != null)
         {
            fireTableDataChangedRestoreSelection(!selectRow);
         
            if (selectRow && iter.getCurrentRowSlot() != RowSetIterator.SLOT_DELETED)
            {
               int selectIndex = -1;
               int rowIndex = iter.getCurrentRowIndex();
               //int rangeSize = iter.getRangeSize();
               int rangeStart = iter.getRangeStart();

               if (rangeStart < 0)
               {
                  rangeStart = 0;
               }
               
               /*
               if (rangeSize < 0 ||
                   (rowIndex >= rangeStart && rowIndex < rangeStart + rangeSize))
               {
                  selectIndex = rowIndex - rangeStart;
               }
               */
               selectIndex = (rowIndex > 0) ? rowIndex : rangeStart; 
               mSelRowInProg = true;
               try
               {
                  selectRowOfIndex(selectIndex);
               }
               finally
               {
                  mSelRowInProg = false;
               }
            }
         }
      }

      
      //
      // TableModel overrides
      //
      
      public String getColumnName(int attrIndex)
      {
         return getAttributeDef(attrIndex).getUIHelper().getLabel(null);
      }

      
      public Class getColumnClass(int attrIndex)
      {
         if (!getIteratorBinding().isFindMode()) 
         {
            AttributeDef ad = getAttributeDef(attrIndex);

            //if format information is available, use default text editor
            //as format service will worry about proper casting.
            if (!ad.getUIHelper().hasFormatInformation(null)) 
            {
               return ad.getJavaType();
            }
         }
         return java.lang.String.class;
      }
   
      
      public int getColumnCount()
      {
         return getAttributeCount();
      }
   
      
      public int getRowCount()
      {
         JUIteratorBinding iter  = getIteratorBinding();
         if ((iter != null) && (iter.isIteratorMadeVisible() || iter.isFindMode()))
         {
            return (int)getEstimatedRowCount();
         }
         return 0;
      }


      private int rowIndexToRangeIndex(int rowIndex)
      {
         RowIterator iter = getRowIterator();

         if (iter != null)
         {
            int rangeStart = iter.getRangeStart();

            if (rangeStart <= 0)
            {
               return rowIndex;
            }
         
            return rowIndex - rangeStart;
         }
         else
         {
            return rowIndex;
         }
      }

      
      public boolean isCellEditable(int rowIndex, int attrIndex)
      {
         //where else can we notify which cell has focus
         if (mPanelBinding != null) 
         {
            //this is getting called more than once. However, we could keep
            //track of current cell and in that case NOT notify.
            //that may lead to bugs where row # is also displayed as one could
            //change (programmatically) what's displayed and effect the data
            //while keeping the same physical cell editable :)
            mPanelBinding.focusGained(getIteratorBinding(), getMyBinding(), JUSVFocusAdapter.MULTI_ATTRIBUTE);
         }

         int rangeIndex = rowIndexToRangeIndex(rowIndex);
         synchronized(getIteratorBinding().getSyncLock())
         {
            try
            {
               Row[] rows = getAllRowsInRange();

               //if (!(rowIndexInRange < 0 || rowIndexInRange >= rows.length))
               if (rangeIndex >= 0 && rangeIndex < rows.length)
               {
                  return rows[rangeIndex].isAttributeUpdateable(getAttributeDef(attrIndex).getIndex());
               }
            }
            catch(Exception ex)
            {
               reportException(ex);
            }
         }
         
         return true;
      }

   
      public Object getValueAt(int rowIndex, int attrIndex)
      {
         JUIteratorBinding iter  = getIteratorBinding();
         RowSetIterator rsi = iter.getRowSetIterator();
         if (((rsi != null) && (rsi.getRowSet().isExecuted()))
              || iter.isFindMode()) 
         {
            int rangeIndex = rowIndexToRangeIndex(rowIndex);
            
            if (rangeIndex >= 0)
            {
               return getAttributeFromRow(rangeIndex, attrIndex);
            }
   
         }
         return null;
      }


      public void setValueAt(Object value, int rowIndex, int attrIndex)
      {
         int rangeIndex = rowIndexToRangeIndex(rowIndex);
         
         try
         {
            setAttributeInRow(rangeIndex, attrIndex, value, false);
         }
         catch (JboException e)
         {
            //JTable table = (JTable)getControl();
            reportException(e, true);
            //table.grabFocus();
            throw e;
         }
      }


      //
      // ListSelectionListener implementation
      //
   
      public void valueChanged(ListSelectionEvent event)
      {
         try
         {
            ListSelectionModel listSelModel = (ListSelectionModel) event.getSource();
   
            if (mSelRowInProg || listSelModel.getValueIsAdjusting())
            {
               return;
            }
   
            RowIterator iter = getRowIterator();
   
            if (!listSelModel.isSelectionEmpty())
            {
               if (iter == null)
               {
                  return;
               }
            
               int selectTabRowIndex = listSelModel.getMinSelectionIndex();
               
               if (getFormBinding() != null) 
               {
                  ((JUPanelBinding)getFormBinding()).callBeforeRowNavigated(getIteratorBinding());
               }

               int idx = selectTabRowIndex - iter.getRangeStart();
               if (idx >= iter.getRangeSize()) 
               {
                  idx = idx - iter.getRangeSize() + 1;
                  iter.scrollRange(idx);
                  idx = selectTabRowIndex - iter.getRangeStart();
               }
               else if (idx < 0)
               {
                  iter.scrollRange(idx);
                  idx = 0;
               }
               iter.setCurrentRowAtRangeIndex(idx);
            }
         }
         catch(Exception ex)
         {
            reportException(ex);
            refresh(true /*selectRow*/);
         }
      }
      
      
      //
      // ChangeListener implementation
      //    (of the scroll pane's viewport changes, 'mScrollPane.getViewport()'
      //
   
      public void stateChanged(ChangeEvent event)
      {
         RowIterator iter = getRowIterator();
         int numVisRows = -1;
         int height = 0;
         
         if (mScrollPane != null)
         {
            height = mScrollPane.getViewport().getHeight();
         }
         else
         {
            getIteratorBinding().resolveRangeSize(numVisRows);
            mNumVisRows = numVisRows;

            return;
         }
         
         JTable jTable = (JTable) getControl();

         int rowHeight = mScrollUnit;

         // Check to see if the view port shows partial row.
         mPartialRowVisible = ((height % rowHeight) != 0);
         numVisRows = height / rowHeight;

         if (mPartialRowVisible)
         {
            numVisRows++;
         }
         
         if (iter != null && numVisRows != 0 && numVisRows != iter.getRangeSize())
         {
            getIteratorBinding().resolveRangeSize(numVisRows);
            mNumVisRows = numVisRows;
         }
      }
   }


   //
   // JUTableScrollBarListener inner class
   //
   
   class JUTableScrollBarListener implements ChangeListener
   {
      // private int mPrevScrollPos = 0;
      private boolean mInScrollBarStateChange = false;

      
      boolean isInScrollBarStateChange()
      {
         return mInScrollBarStateChange;
      }

      
      public void stateChanged(ChangeEvent event)
      {
         BoundedRangeModel model = (BoundedRangeModel) event.getSource();
         /*
         if (model.getValueIsAdjusting())
         {
           return;
         }
         */
         int value = model.getValue();
         int extent = model.getExtent();
         int newRangeStart = value / mScrollUnit;
         RowIterator iter = getRowIterator();

         if (iter == null)
         {
            return;
         }

         int rangeStart = iter.getRangeStart();
         int scrollAmount = newRangeStart - rangeStart;

         if (scrollAmount == 0)
         {
            return;
         }

         if (mInScrollBarStateChange)
         {
            return;
         }
         
         //isExecuted check.
         if (iter.getCurrentRowSlot() == oracle.jbo.RowIterator.SLOT_BEFORE_FIRST)
         {
            return;
         }

         mInScrollBarStateChange = true;
         
         try
         {
            iter.scrollRange(scrollAmount);
         }
         finally
         {
            mInScrollBarStateChange = false;
         }

      }
   }
}
