/*
 * @(#)JUArrayComboBoxBeanInfo.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.uicli.controls;

import java.awt.Image;
import java.beans.BeanDescriptor;
import java.beans.BeanInfo;
import java.beans.EventSetDescriptor;
import java.beans.Introspector;
import java.beans.MethodDescriptor;
import java.beans.PropertyDescriptor;
import java.beans.SimpleBeanInfo;

public class JUArrayComboBoxBeanInfo extends SimpleBeanInfo
{
   private BeanInfo mBeanInfo = null;

   public JUArrayComboBoxBeanInfo()
   {
      try
      {
         mBeanInfo = Introspector.getBeanInfo(oracle.jbo.uicli.controls.JUArrayComboBox.class,
                                              Introspector.IGNORE_IMMEDIATE_BEANINFO);
      }
      catch (Exception e)
      {
         mBeanInfo = new SimpleBeanInfo();
      }
   }

   public BeanInfo[] getAdditionalBeanInfo() 
   {
      return mBeanInfo.getAdditionalBeanInfo();
   }
       
   public BeanDescriptor getBeanDescriptor() 
   {
      return mBeanInfo.getBeanDescriptor();
   }

   public int getDefaultEventIndex() 
   {
      return mBeanInfo.getDefaultEventIndex();
   }

   public int getDefaultPropertyIndex() 
   {
      return mBeanInfo.getDefaultPropertyIndex();
   }

   public EventSetDescriptor[] getEventSetDescriptors() 
   {
       return mBeanInfo.getEventSetDescriptors();
   }

   public Image getIcon(int iconKind) 
   {
      return mBeanInfo.getIcon(iconKind);
   }

   public MethodDescriptor[] getMethodDescriptors() 
   {
      return mBeanInfo.getMethodDescriptors();
   }

   public PropertyDescriptor[] getPropertyDescriptors() 
   {
      PropertyDescriptor[] descs = mBeanInfo.getPropertyDescriptors(); 
     
      // hide 2 properties
      PropertyDescriptor[] retvalue = new PropertyDescriptor[descs.length-2]; 
      try
      {
         int j = 0;
         for(int i = 0; i < descs.length; i++)
         {
            // hide the arrayBinding attribute and arrayElementEditor
            if (descs[i].getName().equals("arrayBinding") || descs[i].getName().equals("arrayElementEditor"))
               continue;

            retvalue[j++] = descs[i];
         }
      }
      catch (Exception exp)
      {
         return descs;
      }

      return retvalue;
   }
}
