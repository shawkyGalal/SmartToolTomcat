/*
 * @(#)JUPanelValidationAdapter.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.uicli.jui;
import oracle.jbo.uicli.binding.JUIteratorBinding;
import oracle.jbo.RangeRefreshEvent;
import oracle.jbo.ScrollEvent;
import oracle.jbo.InsertEvent;
import oracle.jbo.DeleteEvent;
import oracle.jbo.UpdateEvent;
import oracle.jbo.NavigationEvent;

/**
 * Default implementation for JUPanelValidationListener interface.
 * This implementation simply prints a diagnostic message for each
 * event it receives. JClient design time creates a subclass of this
 * adapter with overridden methods as per an application's choice
 * when the Event Inspector is used to generate JUPanelValidationEvent
 * listener code.
 */
public class JUPanelRowSetAdapter implements JUPanelRowSetListener
{
   /**
    * Invoked when the range changes.
    * @param event a description of the new ranges.
    */
   public void rangeRefreshed(JUIteratorBinding iter, RangeRefreshEvent event){}

   /**
    * Invoked when the range is scrolled.
    * @param event a description of the new range.
    */
   public void rangeScrolled(JUIteratorBinding iter, ScrollEvent event){}

   /**
    * Invoked when a row has been inserted.
    * @param event a description of the new Row object.
    */
   public void rowInserted(JUIteratorBinding iter, InsertEvent event){}

   /**
    * Invoked when a row has been deleted.
    * @param event a description of the deleted Row object.
    */
   public void rowDeleted(JUIteratorBinding iter, DeleteEvent event){}

   /**
    * Invoked when an attribute of the row has been changed.
    * @param event a description of the modified Row object.
    */
   public void rowUpdated(JUIteratorBinding iter, UpdateEvent event){}

   /**
    * Invoked when the current-row designation changes.
    * @param event a description of the new and previous current rows.
    */
   public void navigated(JUIteratorBinding iter, NavigationEvent event){}
}
