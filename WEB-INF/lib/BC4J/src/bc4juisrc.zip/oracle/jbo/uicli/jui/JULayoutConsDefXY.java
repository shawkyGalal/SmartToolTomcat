/*
 * @(#)JULayoutConsDefXY.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.uicli.jui;

import java.util.HashMap;
import oracle.jbo.mom.xml.DefElementImpl;
import oracle.jbo.mom.xml.DefPersistenceException;
import oracle.jbo.mom.xml.DefWriter;
import oracle.jbo.uicli.layout.JULayoutConsDef;
import oracle.jdeveloper.layout.XYConstraints;

public class JULayoutConsDefXY extends JULayoutConsDef
{
   private int mX;
   private int mY;
   private int mWidth;
   private int mHeight;

   private static final String PNAME_X = "X";
   private static final String PNAME_Y = "Y";
   private static final String PNAME_Width = "Width";
   private static final String PNAME_Height = "Height";

   
   public JULayoutConsDefXY()
   {
   }


   public JULayoutConsDefXY(int x, int y, int width, int height)
   {
      mX = x;
      mY = y;
      mWidth = width;
      mHeight = height;
   }

   
   public void init(HashMap initValues)
   {
      super.init(initValues);
      
      Object val;
      
      if ((val = initValues.get(PNAME_X)) != null)
      {
         mX = convertToInt(val);
      }
      
      if ((val = initValues.get(PNAME_Y)) != null)
      {
         mY = convertToInt(val);
      }
      
      if ((val = initValues.get(PNAME_Width)) != null)
      {
         mWidth = convertToInt(val);
      }
      
      if ((val = initValues.get(PNAME_Height)) != null)
      {
         mHeight = convertToInt(val);
      }
   }
   
   
   public int getX()
   {
      return mX;
   }

   
   public int getY()
   {
      return mY;
   }

   
   public int getWidth()
   {
      return mWidth;
   }

   
   public int getHeight()
   {
      return mHeight;
   }

   
   public Object createLayoutCons()
   {
      return new XYConstraints(mX, mY, mWidth, mHeight);
   }

   
   protected void retrieveFromXML(DefElementImpl xmlElement, HashMap valueTab)
   {
      super.retrieveFromXML(xmlElement, valueTab);

      readXMLInt(xmlElement, PNAME_X, valueTab);
      readXMLInt(xmlElement, PNAME_Y, valueTab);
      readXMLInt(xmlElement, PNAME_Width, valueTab);
      readXMLInt(xmlElement, PNAME_Height, valueTab);
   }

   
   public void writeContents(DefWriter jos)
      throws DefPersistenceException
   {
      super.writeContents(jos);
      
      jos.writeInt(PNAME_X, getX());
      jos.writeInt(PNAME_Y, getY());
      jos.writeInt(PNAME_Width, getWidth());
      jos.writeInt(PNAME_Height, getHeight());
   }
}
