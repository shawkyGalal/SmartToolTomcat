/*
 * @(#)JUCtrlAttrsBinding.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.uicli.binding;

import oracle.jbo.NavigationEvent;
import oracle.jbo.Row;
import oracle.jbo.RowSetIterator;
import oracle.jbo.ScrollEvent;

/**
 * A JUControlBinding class responsible for binding controls/models
 * that are bound to a single Row object in the BC4J layer.
 * This class is responsible for:
 * <ul>
 * <li>Updating the Control Bindings with attribute values
 * from the BC4J Row object for all attributes that this Control Binding is bound to.
 * <li>Enabling/disabling the control based on whether the corresponding Row's attribute
 * is updateable.
 * </ul>
 * <p>
 * This class defines the abstract APIs for subclasses to implement, so that
 * Row's attributes can be passed to the Binding object for appropriate display/update.
 */
abstract public class JUCtrlAttrsBinding extends JUCtrlValueBinding
{
   /**
   * Gets the value from the control for the attribute at the given index.
   * (The index is calculated from the list of attributes this control binding is
   * bound to as passed in the constructor).
   * Framework uses this method to get the attribute value from the control
   * and pass it on to the Row object on the BC4J side.
   */
   abstract public Object getValueAt(int attrIndex);

   /**
   * Updates the control/control-binding with the latest value of the
   * attribute at the given index with the given value. This method is used
   * by the framework to update the control with attribute values from a BC4J row.
   */
   abstract public void setValueAt(Object value, int attrIndex);

   /*
   * Applications should use this method to update the value for an attribute 
   * at the given index on both a control as well as a BC4J row, where the index
   * is calculated from the list of attributes to which control is bound
   * in its constructor). For controls that are bound to one attribute,
   * pass in 0 for attrIndex.
   */
   abstract public void setDataValueAt(Object value, int attrIndex);


   /**
   * *** For internal framework use only ***
   */
   protected JUCtrlAttrsBinding()
   {
   }

   /**
   * Creates a binding between the given control and attributes in the Rows returned
   * by the passed in Iterator Binding.
   */
   public JUCtrlAttrsBinding(Object control, JUIteratorBinding iterBinding, String[] attrNames)
   {
      super(control, iterBinding, attrNames);
   }


   /**
   * Updates the control-binding and hence the control with attribute values from
   * the attributes of this Row. Invokes setValueAt() with the attribute value
   * and attribute index with respect to attributes for which this binding is interested.
   * <p>
   * This method also enables/disables the Swing control based on the updateability
   * of the first (Default) attribute to which this control is bound.
   */
   public void updateValuesFromRow(Row row)
   {
      super.updateValuesFromRow(row);
      int ct = getAttributeCount();

      for (int j = 0; j < ct; j++)
      {
         Object value = getAttributeFromRow(row, j);
         setValueAt(value, j);
      }

      if (ct == 1) 
      {
         //setup readonly stuff for controls mapped to one target attribute
         Object ctrl = getControl();
         if (ctrl instanceof java.awt.Component) 
         {
            //forcing enabled here without check leads to a Locked state
            //while drawing up UIs for scrolbars etc. some guava tests block
            java.awt.Component comp = (java.awt.Component) ctrl;
            boolean compEnabled = comp.isEnabled();
            boolean attrEnabled = isAttributeUpdateable(0);
            if (compEnabled != attrEnabled) 
            {
               comp.setEnabled(attrEnabled);
            }

         }
      }
   }

   
   
   /**
   * Passes on the first row from the given array of rows to 
   * updateValuesFromRow() method to update the bound control's display.
   */
   public void updateValuesFromRows(Row[] rows, boolean clear)
   {
      updateValuesFromRow((rows.length > 0) ? rows[0] : null);
   }

   
   /**
   * Overridden as a no-op. Since this control is bound to only one row,
   * when that row becomes current the framework uses updateValuesFromRow to
   * update the display
   */
   public void updateRangeScrolled(ScrollEvent event)
   {
   }


   /**
   * Overridden as a no-op. Since this control is bound to only one row,
   * when that row becomes current the framework uses updateValuesFromRow to
   * update the display
   */
   public void updateNavigated(NavigationEvent event)
   {
   }

   /**
   * *** For internal framework use only ***
   * <p>
   * Updates the values in a control that is bound using an Iterator already in use.
   * (a valid row iterator)
   * If you do not call this method, your control won't update unless you refresh the Iterator.
   */
   public void refreshControl()
   {   
      RowSetIterator rsi = (RowSetIterator) getRowIterator();

      if (rsi == null)
      {
         return;
      }

      if (rsi.getRowSet().isExecuted() &&
          rsi.getCurrentRowSlot() == oracle.jbo.RowIterator.SLOT_VALID)
      {
         updateValuesFromRow(getCurrentRow());
      }
   }
}
