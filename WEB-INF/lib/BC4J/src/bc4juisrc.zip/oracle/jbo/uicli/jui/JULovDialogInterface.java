/*
 * @(#)JULovDialogInterface.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.uicli.jui;

/**
 * JULovButtonBinding works with a JULovDialogInterface to display LOV
 * data. An application can pass its own implementation of JULovDialogInterface
 * in a JULovPanelInterface in order to display an application-specific dialog
 * instead of the default JULovDialog, which also implements this interface.
 * @see oracle.jbo.uicli.controls.JULovDialog
 * @see oracle.jbo.uicli.jui.JULovButtonBinding
 */
public interface JULovDialogInterface
{
   /**
   * Display the Lov Dialog. This method may control the model nature of
   * the Lov Dialog as well.
   */
   void show();

   /**
   * Add the LOV binding object to the dialog.
   * Note that LOV can call helpAction on the LOV binding object.
   * Add the LOV Panel to dialog display
   */
   void setLov(JULovButtonBinding lov);

   /**
   * Return true if the LOV binding should perform
   * updates of the target row based on this LOV RSI's currentRow.
   * This method is true by default in JULovDialog, if OK button is pressed.
   */
   boolean isOKSelected();
}
