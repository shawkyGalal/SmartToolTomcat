/*
 * @(#)JUCtrlActionBinding.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.uicli.binding;

import java.awt.Component;
import java.awt.Cursor;
import java.awt.Frame;
import oracle.jbo.Row;
import oracle.jbo.RowIterator;
import oracle.jbo.RowSetIterator;
import oracle.jbo.uicli.UIMessageBundle;

class JUActionDef
{
   int mId;
   String mStr;


   JUActionDef(int id, String str)
   {
      mId = id;
      mStr = str;
   }
}

/**
* Implements actions on BC4J RowIterator to which this control is bound. 
* This class supports the following actions:
* <ul>
* <li><code>ACTION_EXECUTE</code> Executes the ViewObject query.
* <li><code>ACTION_NEXT</code> Moves the currency to the next row.
* <li><code>ACTION_PREVIOUS</code> Moves the currency to the previous row.
* <li><code>ACTION_FIRST</code> Moves the currency to the first row.
* <li><code>ACTION_LAST</code> Moves the currency to the last row.
* <li><code>ACTION_RESET</code> Resets the currency to the beginning of the RowIterator.
* <li><code>ACTION_REMOVE_CURRENT_ROW</code> Removes the current row in this iterator.
* <li><code>ACTION_CREATE_INSERT_ROW</code> Creates a new row and insert it into this iterator before the current row.
* <li><code>ACTION_COMMIT_TRANSACTION</code> Commits all changes in the current BC4J application module session into database.
* <li><code>ACTION_ROLLBACK_TRANSACTION</code> Rolls back any changes in the current BC4J application module session.
* </ul>
* <p>
* If a button is bound to this binding class, then, on button press, the action event on the 
* button binding should call <code>doIt()</code> method on this object to perform the desired action.
*/

abstract public class JUCtrlActionBinding extends JUControlBinding 
{
   public static final int ACTION_EXECUTE = 0;

   public static final int ACTION_NEXT = 10;
   public static final int ACTION_PREVIOUS = 11;
   public static final int ACTION_FIRST = 12;
   public static final int ACTION_LAST = 13;

   public static final int ACTION_RESET = 20;
   
   public static final int ACTION_REMOVE_CURRENT_ROW = 30;
   public static final int ACTION_CREATE_INSERT_ROW = 40;

   public static final int ACTION_COMMIT_TRANSACTION = 100;
   public static final int ACTION_ROLLBACK_TRANSACTION = 101;

   private int mAction;

   final byte TYPE_ROW_ITERATOR = 0;
   final byte TYPE_ARRAY_ITERATOR = 1;
   byte mIteratorBindingType = TYPE_ROW_ITERATOR;

   static final JUActionDef[] mActionDefs =
   {
      new JUActionDef(ACTION_EXECUTE, "execute"),
      new JUActionDef(ACTION_NEXT, "next"),
      new JUActionDef(ACTION_PREVIOUS, "previous"),
      new JUActionDef(ACTION_FIRST, "first"),
      new JUActionDef(ACTION_LAST, "last"),
      new JUActionDef(ACTION_RESET, "reset"),
      new JUActionDef(ACTION_REMOVE_CURRENT_ROW, "removeCurrentRow"),
      new JUActionDef(ACTION_CREATE_INSERT_ROW, "createInsertRow"),
      new JUActionDef(ACTION_COMMIT_TRANSACTION, "commitTransaction"),
      new JUActionDef(ACTION_ROLLBACK_TRANSACTION, "rollbackTransaction")
   }  ;

   
   /**
   * Creates an ActionBinding instance that works with the given control and
   * on control's ActionEvent, call the doIt() method.
   * @param control The control that this binding works with.
   * @param iterBinding JUIteratorBinding instance that this binding works with.
   * @param action Indicates the selected action from the list of actions this class implements.
   */
   public JUCtrlActionBinding(Object control, JUIteratorBinding iterBinding, int action)
   {
      super(control, iterBinding);
      
      mAction = action;

      iterBinding.addActionBinding(this);
   }


   /**
   * *** For internal framework use only ***
   */
   static public int actionNameToId(String actionName)
   {
      for (int j = 0; j < mActionDefs.length; j++)
      {
         if (mActionDefs[j].mStr.equals(actionName))
         {
            return mActionDefs[j].mId;
         }
      }

      return -1;
   }

   
   /**
   * *** For internal framework use only ***
   */
   static public String actionIdToName(int id)
   {
      for (int j = 0; j < mActionDefs.length; j++)
      {
         if (mActionDefs[j].mId == id)
         {
            return mActionDefs[j].mStr;
         }
      }

      return null;
   }

   Component getParentFrame()
   {
      Object control = getControl();
      if (control instanceof Component) 
      {
         Component ctrl = (Component)control;
         while (ctrl != null && !(ctrl instanceof Frame)) 
         {
            ctrl = ctrl.getParent();
         }
         if (ctrl instanceof Frame) 
         {
            return ctrl;
         }
      }
      return null;
   }
   
   /**
   * Invokes the action that this binding is selected to perform.
   * This method gets the RowIterator from the associated Iterator binding
   * and then calls an equivalent method on the RowIterator. 
   * BC4J runtime then sends appropriate events to various binding objects
   * based on the action to update their display with the latest currency,
   * data, etc.
   * <p>
   * Here's a list of actions and corresponding method calls on the BC4J side.
   * <p>
   * <ul>
   * <li><code>ACTION_EXECUTE</code> Calls ViewObject.executeQuery()
   * on the corresponding ViewObject to which this binding's RowIterator belongs to.
   * <li><code>ACTION_NEXT</code> Calls RowIterator.next() after generating 
   * beforeRowNavigated event on the associated JUFormBinding (if currency is 
   * moved from an existing current row to another one.)
   * <li><code>ACTION_PREVIOUS</code> Calls RowIterator.previous() after generating 
   * beforeRowNavigated event on the associated JUFormBinding (if currency is 
   * moved from an existing current row to another one.)
   * <li><code>ACTION_FIRST</code> Calls RowIterator.first() after generating 
   * beforeRowNavigated event on the associated JUFormBinding (if currency is 
   * moved from an existing current row to the first row.)
   * <li><code>ACTION_LAST</code> Calls RowIterator.last() after generating 
   * beforeRowNavigated event on the associated JUFormBinding (if currency is 
   * moved from an existing current row to the last row.)
   * <li><code>ACTION_RESET</code> Reset the currency to the beginning of the RowIterator
   * by calling RowIterator.reset() after generating beforeRowNavigated event if
   * currency is taken away from an existing current row.
   * <li><code>ACTION_REMOVE_CURRENT_ROW</code> Remove the current row in this iterator by 
   * calling RowIterator.removeCurrentRow()
   * <li><code>ACTION_CREATE_INSERT_ROW</code> Create a new row and insert it into this iterator before the current row
   * after generating beforeRowNavigated event on the containing JUFormBinding.
   * <li><code>ACTION_COMMIT_TRANSACTION</code> Commit all changes in the current BC4J application module session into database
   * by calling commit() method on the related BC4J Transaction object.
   * <li><code>ACTION_ROLLBACK_TRANSACTION</code> Rollback any changes in the current BC4J application module session by 
   * calling rollback() method on the related BC4J Transaction object. This method also re-executes the Form (all VOs
   * in the JUFormBinding) after a successful rollback.
   * </ul>
   */
   public void doIt()
   {
      // System.out.println("JUCtrlActionBinding.doIt() " + mAction);
      JUIteratorBinding iterBinding = getIteratorBinding();

      if (iterBinding == null)
      {
         return;
      }
      
      synchronized(iterBinding.getSyncLock())
      {
         RowIterator rsi = getRowIterator();

         if (rsi == null)
         {
            return;
         }
         
         Component frame = getParentFrame();
         try
         {
            if (frame != null) 
            {
               frame.setCursor(Cursor.getPredefinedCursor(Cursor.WAIT_CURSOR));
            }

            JUFormBinding form = getFormBinding();
            switch(mAction)
            {
               case ACTION_EXECUTE:
                  executeQuery();
                  return;
      
               case ACTION_NEXT:
                  if (form != null) 
                  {
                     form.displayStatus(iterBinding, UIMessageBundle.STR_NAVIGATING, new Object[] {iterBinding.getViewObject().getName()});
                  }

                  if (rsi.getCurrentRowSlot() == RowSetIterator.SLOT_BEFORE_FIRST)
                  {
                     rsi.first();
                  }
                  else
                  {
                     if (form != null) 
                     {
                        form.callBeforeRowNavigated(iterBinding);
                     }
                     //check for next to avoid setting rsi into no-row slot leading to 
                     //other controls being in disabled state as they have no rows.
                     if (rsi.hasNext()) 
                     {
                        rsi.next();
                     }
                  }
                  break;
      
               case ACTION_PREVIOUS:
                  if (form != null) 
                  {
                     form.displayStatus(iterBinding, UIMessageBundle.STR_NAVIGATING, new Object[] {iterBinding.getViewObject().getName()});
                     form.callBeforeRowNavigated(iterBinding);
                  }
                  //check for hasPrevious to avoid setting rsi into no-row slot leading to 
                  //other controls being in disabled state as they have no rows.
                  if (rsi.hasPrevious()) 
                  {
                     rsi.previous();
                  }
                  break;
      
               case ACTION_FIRST:
                  if (form != null) 
                  {
                     form.displayStatus(iterBinding, UIMessageBundle.STR_NAVIGATING, new Object[] {iterBinding.getViewObject().getName()});
                     form.callBeforeRowNavigated(iterBinding);
                  }rsi.first();
                  break;
      
               case ACTION_LAST:
                  if (form != null) 
                  {
                     form.displayStatus(iterBinding, UIMessageBundle.STR_NAVIGATING, new Object[] {iterBinding.getViewObject().getName()});
                     form.callBeforeRowNavigated(iterBinding);
                  }
                  rsi.last();
                  break;
      
               case ACTION_RESET:
                  if (form != null) 
                  {
                     form.callBeforeRowNavigated(iterBinding);
                  }rsi.reset();
                  break;
      
               case ACTION_REMOVE_CURRENT_ROW:
               {
                  rsi.removeCurrentRow();
                  /*
                  if (form != null) 
                  {
                     JUApplication app = form.getApplication();
                     if (!app.mTxnModified)
                     {
                        app.transactionStateChanged(true);
                     }
                  }
                  */
                  break;
               }

               case ACTION_CREATE_INSERT_ROW:
               {
                  Row row = rsi.createRow();

                  if (row != null)
                  {
                     //just incase there's a navigation
                     if (form != null)
                     {
                        form.callBeforeRowNavigated(iterBinding);
                     }

                     rsi.insertRow(row);
                     
                     /*
                     if (form != null)
                     {
                        JUApplication app = form.getApplication();

                        if (!app.mTxnModified)
                        {
                           app.transactionStateChanged(true);
                        }
                     }
                     */
                  }
                  break;
               }
                  
               case ACTION_COMMIT_TRANSACTION:
               {
                  if (form != null) 
                  {
                     form.displayStatus(iterBinding, UIMessageBundle.STR_BEFORE_COMMIT, null);
                     JUApplication app = form.getApplication();
                     if (app != null)
                     {
                        app.commitTransaction();
                     }
                     else
                     {
                        getApplicationModule().getTransaction().commit();
                     }
                     form.displayStatus(iterBinding, UIMessageBundle.STR_DONE_COMMIT, null);
                  }

                  return;
               }
      
               case ACTION_ROLLBACK_TRANSACTION:
               {
                  if (form != null) 
                  {
                     form.displayStatus(iterBinding, UIMessageBundle.STR_BEFORE_ROLLBACK, null);
                     JUApplication app = form.getApplication();
                     if (app != null)
                     {
                        app.rollbackTransaction();
                        if (form.isExecuteOnRollback()) 
                        {
                           form.execute();
                        }
                     }
                     else
                     {
                        getApplicationModule().getTransaction().rollback();
                        form.execute();
                     }
                     form.displayStatus(iterBinding, UIMessageBundle.STR_DONE_ROLLBACK, null);
                  }
                  
                  return;
               }
   
               default:
                  oracle.jbo.common.Diagnostic.println("Action " + mAction + " not recognized");
                  break;
            }
         }
         catch(Exception ex)
         {
            reportException(ex);
         }
         finally
         {
            if (frame != null) 
            {
               frame.setCursor(Cursor.getPredefinedCursor(Cursor.DEFAULT_CURSOR));
            }
         }
      }
   }
   
   public void setArrayIteratorType()
   {
      mIteratorBindingType = TYPE_ARRAY_ITERATOR;
   }

   public boolean isArrayIteratorType()
   {
      return (mIteratorBindingType == TYPE_ARRAY_ITERATOR);
   }

   /**
   * *** For internal framework use only ***
   * <p>
   * Updates the values in a control that is bound using an Iterator already in use.
   * (a valid row iterator)
   * If you do not call this method, your control won't update unless you refresh the Iterator.
   */
   public void refreshControl()
   {
      // NOOP
   }
 
}
