/*
 * @(#)JUCtrlHierNodeBinding.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.uicli.binding;

import java.util.ArrayList;

abstract public class JUCtrlHierNodeBinding extends JUCtrlRangeBinding
{
   private JUCtrlHierBinding mHierBinding;
   private JUCtrlHierNodeBinding mParent;
   protected ArrayList mChildren = null;
   
   
   public JUCtrlHierNodeBinding(Object control, JUCtrlHierBinding hierBinding, JUCtrlHierNodeBinding parent,
                                JUIteratorBinding iterBinding, String[] attrNames)
   {
      super(control, iterBinding, attrNames);

      mHierBinding = hierBinding;
      mParent = parent;

      if (parent != null)
      {
         parent.addChild(this);
      }
   }


   public JUCtrlHierBinding getHierBinding()
   {
      return mHierBinding;
   }

   
   public JUCtrlHierNodeBinding getParent()
   {
      return mParent;
   }

   
   public ArrayList getChildren()
   {
      return mChildren;
   }

   
   public void addChild(JUCtrlHierNodeBinding child)
   {
      if (mChildren == null)
      {
         mChildren = new ArrayList(2);
      }

      mChildren.add(child);
   }
   
   
   public boolean removeChild(JUCtrlHierNodeBinding child)
   {
      if (mChildren != null)
      {
         return mChildren.remove(child);
      }

      return false;
   }
}
