/*
 * @(#)JUNavigationBar.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.uicli.controls;

import java.awt.Container;
import java.awt.Cursor;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.lang.reflect.Constructor;
import java.net.URL;
import javax.swing.BorderFactory;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JToolBar;
import javax.swing.SwingUtilities;
import oracle.jbo.DeleteEvent;
import oracle.jbo.InsertEvent;
import oracle.jbo.JboException;
import oracle.jbo.NavigatableRowIterator;
import oracle.jbo.NavigationEvent;
import oracle.jbo.RangeRefreshEvent;
import oracle.jbo.RowSetIterator;
import oracle.jbo.RowSetListener;
import oracle.jbo.ScrollEvent;
import oracle.jbo.UpdateEvent;
import oracle.jbo.ViewObject;
import oracle.jbo.uicli.UIMessageBundle;
import oracle.jbo.uicli.binding.JUApplication;
import oracle.jbo.uicli.binding.JUIteratorBinding;
import oracle.jbo.uicli.binding.JUTransactionStateListener;
import oracle.jbo.uicli.jui.JUActionBinding;
import oracle.jbo.uicli.jui.JUIUtil;
import oracle.jbo.uicli.jui.JUNavigationBarInterface;
import oracle.jbo.uicli.jui.JUPanelBinding;
import oracle.jbo.uicli.jui.JUSVFocusAdapter;

/**
 * Implements a data-aware toolbar. Can be bound to a RowSetIterator
 * and can be used:
 * to: <P>
 * <UL>
 * <LI>Iterate back and forth over the bound dataitem.</LI>
 * <LI>Insert a new row in the bound dataitem. </LI>
 * <LI>Delete an existing row from the bound item. </LI>
 * <LI>Commmit/Rollback changes made to the bound item. </LI>
 * </UL>
 *
 * @version  PUBLIC
 *
 * @see      #setHasNavigationButtons()
 * @see      #setHasInsertButton()
 * @see      #setHasDeleteButton()
 * @see      #setHasTransactionButtons()
 */
public class JUNavigationBar 
    extends JToolBar
    implements ActionListener, RowSetListener, JUNavigationBarInterface, JUTransactionStateListener
{
   public static final int BUTTON_FIRST    = 0;
   public static final int BUTTON_PREV     = 1;
   public static final int BUTTON_NEXT     = 2;
   public static final int BUTTON_LAST     = 3;
   public static final int BUTTON_INSERT   = 4;
   public static final int BUTTON_DELETE   = 5;
   public static final int BUTTON_COMMIT   = 6;
   public static final int BUTTON_ROLLBACK = 7;
   public static final int BUTTON_FIND     = 8;
   public static final int BUTTON_EXECUTE  = 9;
   
   public static final int BUTTON_NORMAL   = 0;
   public static final int BUTTON_PRESSED  = 1;
   public static final int BUTTON_DISABLED = 2;
   public static final int BUTTON_ROLLOVER = 3;
   
   private FocusAdapter mFocusAdapter;
   private JButton _buttons[];
   
   private ImageIcon _buttonCancelIcon = null;
   private ImageIcon _buttonIcons[] = null;
   private ImageIcon _onButtonIcons[] = null;
   private ImageIcon _disButtonIcons[] = null;
   private ImageIcon _rollButtonIcons[] = null;
   private static final String MSG_BUNDLE = "oracle.jbo.uicli.UIMessageBundle";
   
   static final String _IMAGES_DIR = "images/";
   static final String _IMAGES[] =
   {
     "first", "prev", "next", "last",
     "insert", "delete", "commit", "rollback", "find", "execute"
   };
   private static final String _TOOLTIP[] =
   {
     UIMessageBundle.getResString(UIMessageBundle.STR_NAV_FIRST)
     ,UIMessageBundle.getResString(UIMessageBundle.STR_NAV_PREV)
     ,UIMessageBundle.getResString(UIMessageBundle.STR_NAV_NEXT)
     ,UIMessageBundle.getResString(UIMessageBundle.STR_NAV_LAST)
     ,UIMessageBundle.getResString(UIMessageBundle.STR_NAV_INSERT)
     ,UIMessageBundle.getResString(UIMessageBundle.STR_NAV_DELETE)
     ,UIMessageBundle.getResString(UIMessageBundle.STR_NAV_COMMIT)
     ,UIMessageBundle.getResString(UIMessageBundle.STR_NAV_ROLLBACK)
     ,UIMessageBundle.getResString(UIMessageBundle.STR_NAV_FIND)
     ,UIMessageBundle.getResString(UIMessageBundle.STR_NAV_EXECUTE)
   };
   
   static String _tooltipCancelFind = UIMessageBundle.getResString(UIMessageBundle.STR_NAV_CANCELFIND);
   
   
   private static final boolean _DEBUG = true;
   
   private boolean _hasFindButton = true;
   private boolean _hasExecuteButton = true;
   
   private boolean mViewBound = false;
   private boolean mTxnBound = false;
   private boolean mDirty = false;
   private boolean mFindMode = false;
   private Cursor _busyCursor= Cursor.getPredefinedCursor(Cursor.WAIT_CURSOR);
   private Cursor _defaultCursor= Cursor.getDefaultCursor();
   private boolean _isShowingBusyCursor = false;
   JUIteratorBinding _iterBinding;
   JUActionBinding _bindings[] = new JUActionBinding[BUTTON_EXECUTE+1];
   
   /**
   * Creates a default instance.
   */
   public JUNavigationBar()
   {
      this(true, true, true, true, true);
   }
   
   /**
   * @deperecated since 9.0.3 use the constructor that also takes execute flag.
   */
   public JUNavigationBar(boolean navigation, boolean modify, boolean txn, boolean find)
   {
      this(navigation, modify, txn, find, true);
   }

   /**
   * This constructor takes flags to indicate which buttons to show or hide in the navigationbar.
   */
   public JUNavigationBar(boolean navigation, boolean modify, boolean txn, boolean find, boolean execute)
   {
      _loadImages();
      
      //same adapter used by buttons on this toolbar.
      mFocusAdapter = new FocusAdapter()
         {
            public void focusGained(FocusEvent e)
            {
               if (!e.isTemporary())
               {
                  //so that status bar reflects which iterator is in focus
                  JUIteratorBinding iterBinding = getModel();
                  if (iterBinding != null) 
                  {
                     JUPanelBinding panelBinding = (JUPanelBinding)iterBinding.getFormBinding();
                     if (panelBinding != null) 
                     {
                        panelBinding.focusGained(iterBinding, null, JUSVFocusAdapter.MULTI_ATTRIBUTE);
                     }
                  }
               }
            }
            
            public void focusLost(FocusEvent e) {}
         };
      
      _buttons = new JButton[_buttonIcons.length];
      for (int i = 0; (i < _buttonIcons.length); i++)
      {
        JButton b = new JButton(_buttonIcons[i]);
        b.setRolloverEnabled(true);
        b.setPressedIcon(_onButtonIcons[i]);
        b.setRolloverIcon(_rollButtonIcons[i]);
        b.setDisabledIcon(_disButtonIcons[i]);
        b.setToolTipText(_TOOLTIP[i]);
        b.setBorderPainted(false);
        b.setFocusPainted(false);
        b.setMargin(new Insets(0, 0, 0, 0));
        b.setBorder(BorderFactory.createLineBorder(java.awt.Color.lightGray, 0));
        b.setEnabled(false);
        _buttons[i] = b;

        b.addActionListener(this);
      }
      
      setHasInsertButton(modify);
      setHasDeleteButton(modify);
      setHasNavigationButtons(navigation);
      setHasTransactionButtons(txn);
      setHasFindButton(find);
      setHasExecuteButton(execute);
      
   }

   /**
    * Applications should override this method to perform custom Action based on a button click/press.
    * Calling super will perform the default button actions.
    * <p>
    * For example, if an application needs to override commit and rollback operations so that they
    * can hold on to some application state before commit/rollback occurs, this method could be
    * overriden to cache the application state, call the super.actionPerformed() to do the
    * button action and then restore the application state.
   **/
   public void actionPerformed(ActionEvent ev)
   {
      Object source = ev.getSource();

      for (int i = 0; i <= BUTTON_EXECUTE; i++) 
      {
         if (source == _buttons[i]) 
         {
            doAction(i);
            return;
         }
      }
   }

   /**
   *  public method to call the NavigationBar button actions programmatically
   *
   *  expected values are BUTTON_FIRST, BUTTON_PREV, BUTTON_NEXT, BUTTON_LAST,
   *  BUTTON_INSERT, BUTTON_DELETE, BUTTON_COMMIT, BUTTON_ROLLBACK, BUTTON_FIND, BUTTON_EXECUTE 
   *
   *  @param the action value, see expected values mentioned above
   */
   public void doAction(int action)
   {
      switch (action) 
      {
      case BUTTON_FIND:
         doFindButtonAction();
         break;

      case BUTTON_EXECUTE:
         doExecuteButtonAction();
         break;

      default:
         if (action < BUTTON_FIND && _bindings[action] != null)
         {
            _bindings[action].doIt();
         }
      }
   }

   /**
    * Override this method to perform any application logic before or after the panel is set to Find Mode
    * or cancelling out of find mode.
    **/
   public void doFindButtonAction()
   {
      if (_iterBinding != null) 
      {
         JUPanelBinding panelBinding = (JUPanelBinding)_iterBinding.getFormBinding();
         boolean findMode = !mFindMode;
         panelBinding.displayStatus(_iterBinding, (findMode) ? UIMessageBundle.STR_FIND_MODE : UIMessageBundle.STR_CANCEL_FIND_MODE, null);
         panelBinding.setFindMode(findMode); 
         mFindMode = findMode;
         _updateButtonStatesLater();
      }
   }

   /**
    * Override this method to perform any application logic before or after the ViewObjects referenced in 
    * this panel are executed.
    **/
   public void doExecuteButtonAction()
   {
      JUPanelBinding panelBinding = (JUPanelBinding)_iterBinding.getFormBinding();
      panelBinding.displayStatus(_iterBinding, UIMessageBundle.STR_EXECUTING_QUERY, null);
      panelBinding.setFindMode(false);
      mFindMode = false;
      panelBinding.execute();
      panelBinding.displayStatus(_iterBinding, UIMessageBundle.STR_DONE_EXECUTING, null);
      _updateButtonStatesLater();
   }
   
   public static JUIteratorBinding createViewBinding(JUPanelBinding formBinding, JUNavigationBar control,  
                                             String voInstanceName, String voRSIName, String voRSIBindingName)
   {
      if (!JUIUtil.inDesignTime())
      {
         if (control != null) 
         {
            formBinding.addNavigationBar(control);
            control.mViewBound = true;
         }
         return formBinding.getRowIterBinding(voInstanceName, voRSIName, voRSIBindingName);
      }
      else
      {
         try
         {
            Class clazz = Class.forName("oracle.jbo.dt.ui.jui.propertyeditors.dtmodels.DTIteratorBinding");
            Constructor constructor = clazz.getConstructors()[0];
            Object [] args = { voInstanceName };
            Object object = constructor.newInstance(args);
            return (JUIteratorBinding)object;
         }
         catch (Exception e)
         {
            return null;
         }
      }
   }
   
   // deprecated
   public static JUIteratorBinding getModelInstance(JUPanelBinding formBinding,  
                                             String voInstanceName, String voRSIName, String voRSIBindingName)
   {
      return createViewBinding(formBinding, null, voInstanceName, voRSIName, voRSIBindingName);
   }
   
   public static JUIteratorBinding createPanelBinding(JUPanelBinding formBinding, JUNavigationBar control)
   {
      if (!JUIUtil.inDesignTime())
      {
         formBinding.addNavigationBar(control);
         return null;
      }
      else
      {
         try
         {
            Class clazz = Class.forName("oracle.jbo.dt.ui.jui.propertyeditors.dtmodels.DTIteratorPanelBinding");
            Object object = clazz.newInstance(); 
            return (JUIteratorBinding)object;
         }
         catch (Exception e)
         {
            return null;
         }
      }
   }
   
   public static JUIteratorBinding getModelInstance(JUPanelBinding formBinding, JUNavigationBar control)
   {
      return createPanelBinding(formBinding, control);
   }
   
   public void setModel(JUIteratorBinding bind)
   {
      if (JUIUtil.inDesignTime())
      {
        _iterBinding = bind;
        return;
      }
                           
      iteratorBindingChanged(bind);
      addFocusListener(mFocusAdapter);
   }
   
   public void transactionStateChanged(boolean state)
   {
      mDirty = state;
      _updateButtonStatesLater();
   }
   
   public void iteratorBindingChanged(JUIteratorBinding bind)
   {
      if (bind == _iterBinding && bind != null)
      {
         boolean iterFindMode = bind.isFindMode();
         if (mFindMode != iterFindMode) 
         {
            //move listener from ViewCriteria to RowSet or vice-versa.
            NavigatableRowIterator rsi = (iterFindMode) ? bind.getRowSetIterator() : bind.getNavigatableRowIterator() ;
            if (rsi != null) 
            {
               rsi.removeListener(this);
            }
            
            rsi = (iterFindMode) ? bind.getNavigatableRowIterator() : bind.getRowSetIterator() ;
            
            if (rsi != null) 
            {
               rsi.addListener(this);
            }
         
         }
         mFindMode = iterFindMode;
         _updateButtonStatesLater();
         return;
      }
      
      
      if (mViewBound) 
      {
         //IF this navbar is bound via a ViewBinding - each navbar is bound to one view/iterator
         //then, see if the new binding has the same name as my old one and if so, there
         //must be an RSI switch that led to this call or when the iterator binding is initially set.
         //This should simply bail out if other binding comes in due to change in focus from panel
         //binding, to avoid tracking current iterator in focus for navbars bound as a ViewBinding.
         if (_iterBinding != null) 
         {
            if (bind != null) 
            {
               if (!_iterBinding.getName().equals(bind.getName()))
               {
                  _updateButtonStatesLater();
                  return;
               }
            }
         }
      }
      
      if (_iterBinding != null) 
      {
         for (int i = 0;  i <= BUTTON_ROLLBACK; i++) 
         {
            //_buttons[i].removeActionListener(_bindings[i]);
            _iterBinding.removeActionBinding(_bindings[i]);
         }
         
         NavigatableRowIterator rsi = _iterBinding.getRowSetIterator();
         
         if (rsi != null) 
         {
            rsi.removeListener(this);
         }
      }
      
      if (bind != null) 
      {
         //only when current iter binding is null, we could be in a state
         //when there's no transactionlistening going on.
         if (!mTxnBound) 
         {
            oracle.jbo.uicli.binding.JUApplication app = bind.getApplication();
            if (app != null) 
            {
               app.addTransactionStateListener(this);
            }
            mTxnBound = true;
         }
         
         _bindings[BUTTON_FIRST]     = new JUActionBinding(_buttons[BUTTON_FIRST]   , bind, JUActionBinding.ACTION_FIRST, false);
         _bindings[BUTTON_PREV]      = new JUActionBinding(_buttons[BUTTON_PREV]    , bind, JUActionBinding.ACTION_PREVIOUS, false); 
         _bindings[BUTTON_NEXT]      = new JUActionBinding(_buttons[BUTTON_NEXT]    , bind, JUActionBinding.ACTION_NEXT, false); 
         _bindings[BUTTON_LAST]      = new JUActionBinding(_buttons[BUTTON_LAST]    , bind, JUActionBinding.ACTION_LAST, false); 
         _bindings[BUTTON_INSERT]    = new JUActionBinding(_buttons[BUTTON_INSERT]  , bind, JUActionBinding.ACTION_CREATE_INSERT_ROW, false);   
         _bindings[BUTTON_DELETE]    = new JUActionBinding(_buttons[BUTTON_DELETE]  , bind, JUActionBinding.ACTION_REMOVE_CURRENT_ROW, false);   
         _bindings[BUTTON_COMMIT]    = new JUActionBinding(_buttons[BUTTON_COMMIT]  , bind, JUActionBinding.ACTION_COMMIT_TRANSACTION, false);   
         _bindings[BUTTON_ROLLBACK]  = new JUActionBinding(_buttons[BUTTON_ROLLBACK], bind, JUActionBinding.ACTION_ROLLBACK_TRANSACTION, false);     
         
         NavigatableRowIterator rsi = bind.getNavigatableRowIterator();
         if (rsi != null) 
         {
            rsi.addListener(this);
         }
         mFindMode = bind.isFindMode();
      }
      else
      {
         for (int j = 0; j < _bindings.length; j++)
         {
            _bindings[j] = null;
         }
      }
      
      _iterBinding = bind;
      _updateButtonStatesLater();
   }
   
   
   public JUIteratorBinding getModel()
   {
      return _iterBinding;
   }
   
   /**
   *  Sets the icon to be used for a button. <P>
   *  @param  button The button whose icon should be changed.
   *           Allowed values should be one of defined by the BUTTON_XXX
   *           constants.
   *  @param  icon The new icon.
   *  @deprecated
   */
   public void setButtonIcon(int button, Icon icon)
   {
      if (button < BUTTON_FIRST || button > BUTTON_EXECUTE)
      {
         throw new JboException(UIMessageBundle.getResString(UIMessageBundle.STR_NAV_INVALID_BUTTON_INDEX));
      }
      _buttons[button].setPressedIcon(null);
      _buttons[button].setDisabledIcon(null);
      _buttons[button].setRolloverEnabled(false);
      _buttons[button].setRolloverIcon(null);
      _buttons[button].setIcon(icon);
      revalidate();
   }
   
   /**
   *  Gets the icon being used for a button. <P>
   *  @param  button The button whose icon is being requested.
   *           Allowed values should be one of defined by the BUTTON_XXX
   *           constants.
   *  @return The icon being used by button.
   *  @deprecated
   */
   
   public Icon getButtonIcon(int button)
   {
      if (button < BUTTON_FIRST || button > BUTTON_EXECUTE)
      {
         throw new JboException(UIMessageBundle.getResString(UIMessageBundle.STR_NAV_INVALID_BUTTON_INDEX));
      }
      return _buttons[button].getIcon();
   }
   
   /**
   *  Sets the icon to be used for a button. <P>
   *  @param  button The button whose icon should be changed.
   *           Allowed values should be one of defined by the BUTTON_XXX
   *           constants.
   *  @param  icon The new button icon.
   *  @param  pressedIcon The new button pressed icon.
   *  @param  disabledIcon The new button disabled icon.
   *  @param  rolloverIcon The new button rollover icon.
   */
   public void setButtonIcons(int button, Icon icon, Icon pressedIcon,
                            Icon disabledIcon, Icon rolloverIcon)
   {
      if (button < BUTTON_FIRST || button > BUTTON_EXECUTE)
      {
         throw new JboException(UIMessageBundle.getResString(UIMessageBundle.STR_NAV_INVALID_BUTTON_INDEX));
      }
      _buttons[button].setIcon(icon);
      _buttons[button].setPressedIcon(pressedIcon);
      _buttons[button].setDisabledIcon(disabledIcon);
      if (rolloverIcon != null)
      {
         _buttons[button].setRolloverEnabled(true);
      }
      else
      {
         _buttons[button].setRolloverEnabled(false);
      }
      _buttons[button].setRolloverIcon(rolloverIcon);
      revalidate();
   }
   
   /**
   *  Gets the icon being used for a button. <P>
   *  @param  button The button whose icon is being requested.
   *           Allowed values should be one of defined by the BUTTON_XXX
   *           constants.
   *  @param  type The icon type. Allowed values are BUTTON_NORMAL, BUTTON_PRESSED,
   *          BUTTON_DISABLED, and BUTTON_ROLLOVER.
   *  @return The icon being used by button.
   */
   
   public Icon getButtonIcons(int button, int type)
   {
      if (button < BUTTON_FIRST || button > BUTTON_EXECUTE)
      {
         throw new JboException(UIMessageBundle.getResString(UIMessageBundle.STR_NAV_INVALID_BUTTON_INDEX));
      }
      switch (type)
      {
      case BUTTON_NORMAL:
         return _buttons[button].getIcon();
      case BUTTON_PRESSED:
         return _buttons[button].getPressedIcon();
      case BUTTON_DISABLED:
         return _buttons[button].getDisabledIcon();
      case BUTTON_ROLLOVER:
         return _buttons[button].getRolloverIcon();
      default:
         throw new JboException(UIMessageBundle.getResString(UIMessageBundle.STR_NAV_INVALID_BUTTON_INDEX));
      }
   }
   
   /**
   *  Sets the icon to be used when a button is pressed. <P>
   *  @param  button The button whose icon should be changed.
   *           Allowed values should be one of defined by the BUTTON_XXX
   *           constants.
   *  @param  icon The new icon.
   *  @deprecated
   */
   
   public void setButtonPressedIcon(int button, Icon icon)
   {
      if (button < BUTTON_FIRST || button > BUTTON_EXECUTE)
      {
         throw new JboException(UIMessageBundle.getResString(UIMessageBundle.STR_NAV_INVALID_BUTTON_INDEX));
      }
      _buttons[button].setDisabledIcon(null);
      _buttons[button].setPressedIcon(icon);
      revalidate();
   }
   
   /**
   *  Gets the icon displayed when a navigation bar button is pressed. <P>
   *  @param  button The button whose icon is being requested.
   *           Allowed values should be one of defined by the BUTTON_XXX
   *           constants.
   *  @return The icon being used by the button in the pressed button.
   *  @deprecated
   */
   
   public Icon getButtonPressedIcon(int button)
   {
      if (button < BUTTON_FIRST || button > BUTTON_EXECUTE)
      {
         throw new JboException(UIMessageBundle.getResString(UIMessageBundle.STR_NAV_INVALID_BUTTON_INDEX));
      }
   
      return _buttons[button].getPressedIcon();
   }
   
   /**
   * displays a busy cursor
   */
   public void showBusyCursor()
   {
      if (!_isShowingBusyCursor)
      {
         Container p = getTopLevelAncestor();
         if ( p != null )
         {
             _defaultCursor = p.getCursor();
             _isShowingBusyCursor = true;
             p.setCursor(getBusyCursor());
         }
      }
   }
   
   /**
   * Shows default cursor.
   *
   */
   public void restoreDefaultCursor()
   {
      if (_isShowingBusyCursor)
      {
         Container p = getTopLevelAncestor();
         if ( p != null )
         {
             _isShowingBusyCursor = false;
             p.setCursor(_defaultCursor);
         }
      }
   }
   
   /**
   * Changes the cursor used to indicate busy status.
   *
   * @param busyCursor Cursor used to indicate busy status.
   */
   public void setBusyCursor(Cursor busyCursor)
   {
      _busyCursor = busyCursor;
   }
   
   /**
   * Gets the cursor currently used to indicate busy status.
   *
   * @return get The busy cursor.
   */
   public Cursor getBusyCursor()
   {
      return _busyCursor;
   }
   
   /**
   *  Gets the button object used in the toolbar.
   *
   *  @param  whichButton A constant indicating which button is requested.
   *          Allowed values should be one of defined by the BUTTON_XXX
   *          constants.
   *  @return The button object.
   
   */
   public JButton getButton(int button)
   {
      if (button < BUTTON_FIRST || button > BUTTON_EXECUTE)
      {
         throw new JboException(UIMessageBundle.getResString(UIMessageBundle.STR_NAV_INVALID_BUTTON_INDEX));
      }
      return _buttons[button];
   }
   
   /**
   *  Checks if the button both exists and is enabled.
   *  if it does not existe, because the appropriate setHas... method is set to false, or if the
   *  button is disabled, this method returns false, otherwise it returns true.
   *
   *  @param buttonid  A constant indicating which button is requested.
   *          Allowed values should be one of defined by the BUTTON_XXX
   *          constants.
   *  @return true or false to indicate if this button can be used
   */
   public boolean isButtonActive(int buttonid)
   {
      try
      {
         if (buttonid == BUTTON_FIRST || buttonid == BUTTON_PREV || buttonid == BUTTON_NEXT || buttonid == BUTTON_LAST)
            return (getHasNavigationButtons() && getButton(buttonid).isEnabled());
         if (buttonid == BUTTON_INSERT)
            return (getHasInsertButton() && getButton(buttonid).isEnabled());
         if (buttonid == BUTTON_DELETE)
            return (getHasDeleteButton() && getButton(buttonid).isEnabled());
         if (buttonid == BUTTON_COMMIT || buttonid == BUTTON_ROLLBACK)
            return (getHasTransactionButtons() && getButton(buttonid).isEnabled());
         if (buttonid == BUTTON_FIND)
            return (getHasFindButton() && getButton(buttonid).isEnabled());
         if (buttonid == BUTTON_EXECUTE)
            return (getHasExecuteButton() && getButton(buttonid).isEnabled());

         return false;
      }
      catch(Exception exp)
      {
         return false;
      }
   }
   // Attributes
   
   /**
   * Determines if the toolbar has the buttons that are used to change the
   * current row of the bound ViewObject.
   * @return True if the currency can be changed, otherwise returns false.
   */
   public boolean getHasNavigationButtons()
   {
      return(getComponentIndex(_buttons[BUTTON_FIRST]) != -1);
   }
   
   /**
   * Tells the toolbar whether to include the navigation buttons or not.
   *
   * @param b If true, the navigation buttons are included in the bar,
   *          else the navigation buttons are not included.
   */
   public void setHasNavigationButtons(boolean b)
   {
      if (b)
      {
         _addButton(BUTTON_FIRST);
         _addButton(BUTTON_PREV);
         _addButton(BUTTON_NEXT);
         _addButton(BUTTON_LAST);
      
      }
      else
      {
         _removeButton(BUTTON_FIRST);
         _removeButton(BUTTON_PREV);
         _removeButton(BUTTON_NEXT);
         _removeButton(BUTTON_LAST);
      
      }
   }
   
   /**
   * Determines if the toolbar has the button that can be used to
   * insert a new row in the bound ViewObject.
   * @return True if the button is included, otherwise returns false.
   */
   public boolean getHasInsertButton()
   {
      return(getComponentIndex(_buttons[BUTTON_INSERT]) != -1);
   }
   
   /**
   * Tells the toolbar whether to include the insert button or not.
   * @param b If true, the insert button is be included, else the button is
   * removed.
   */
   public void setHasInsertButton(boolean b)
   {
   
      if (b)
      {
         _addButton(BUTTON_INSERT);
      }
      else
      {
         _removeButton(BUTTON_INSERT);
      }
   }
   
   /**
   * Determines if the toolbar has the button that can be used to
   * delete an existing row from the bound ViewObject.
   * @return True if the button is included, otherwise returns false.
   */
   
   public boolean getHasDeleteButton()
   {
      return(getComponentIndex(_buttons[BUTTON_DELETE]) != -1);
   }
   
   /**
   * Tells the toolbar whether to include the delete button or not.
   * @param b If true, the delete button is be included, otherwise the button is
   * removed.
   */
   
   public void setHasDeleteButton(boolean b)
   {
      if (b)
      {
         _addButton(BUTTON_DELETE);
      }
      else
      {
         _removeButton(BUTTON_DELETE);
      }
   }
   
   /**
   * Determines if the toolbar has the buttons that can be used to
   * commit/rollback the changes made to the bound Transaction.
   * @return True if the buttons are included, otherwise returns false.
   */
   public boolean getHasTransactionButtons()
   {
      return(getComponentIndex(_buttons[BUTTON_COMMIT]) != -1);
   }
   
   /**
   * Tells the toolbar whether to include the commit/rollback buttons or not.
   * @param b If true the buttons are included, otherwise the buttons are removed.
   */
   public void setHasTransactionButtons(boolean b)
   {
      if (b)
      {
         _addButton(BUTTON_COMMIT);
         _addButton(BUTTON_ROLLBACK);
      }
      else
      {
         _removeButton(BUTTON_COMMIT);
         _removeButton(BUTTON_ROLLBACK);
      }
   }
   
   
   
   /**
   * Determines if the toolbar has the button that can be used to
   * run a restricted query (using ViewCriteria) on the bound ViewObject.
   * @return True if the button is included, otherwise returns false.
   */
   
   public boolean getHasFindButton()
   {
      return _hasFindButton;
   }
   
   /**
   * Tells the toolbar whether to include the 'Find' button or not.
   * @param b If true, the 'Find' button is included, otherwise the button is
   * removed.
   */
   public void setHasFindButton(boolean b)
   {
      _hasFindButton = b; 
      if (b)
      {
         _addButton(BUTTON_FIND);
      }
      else
      {
         _removeButton(BUTTON_FIND);
      }
   }
   
   
   
   /**
   * Determines if the toolbar has the button that can be used to
   * execute the viewobject query on the bound ViewObject.
   * @return True if the button is included, otherwise returns false.
   */
   
   public boolean getHasExecuteButton()
   {
      return _hasExecuteButton;
   }
   
   /**
   * Tells the toolbar whether to include the 'Execute' button or not.
   * @param b If true, the 'Execute' button is included, otherwise the button is
   * removed.
   */
   public void setHasExecuteButton(boolean b)
   {
      _hasExecuteButton = b; 
      if (b)
      {
         _addButton(BUTTON_EXECUTE);
      }
      else
      {
         _removeButton(BUTTON_EXECUTE);
      }
   }
   
   // Private Methods
   
   private boolean _addButton(int buttonPosition)
   {
   
     if (getComponentIndex(_buttons[buttonPosition]) == -1)
     {
         int pos ;
         if ((buttonPosition + 1) <= getComponentCount())
         {
            pos = buttonPosition;
         }
         else
         {
            pos = -1;
         }
         
         _buttons[buttonPosition].addFocusListener(mFocusAdapter);
         _buttons[buttonPosition].setVisible(true);
         _buttons[buttonPosition].setEnabled(false);
         _buttons[buttonPosition].setOpaque(false);
         add(_buttons[buttonPosition],pos);
         
         revalidate();
         return true;
     }
     return false;
   }
   
   private boolean _removeButton(int buttonPosition)
   {
     _buttons[buttonPosition].removeFocusListener(mFocusAdapter);
     if (getComponentIndex(_buttons[buttonPosition]) != -1)
     {
         remove(_buttons[buttonPosition]);
         revalidate();
         return true;
     }
     return false;
   }
   
   protected void _updateButtonStatesLater()
   {
     SwingUtilities.invokeLater(new Runnable() {
         public void run() {
             //this leads to other deadlocks. 
             //synchronized(getTreeLock())
             {
                _updateButtonStates();
             }
         }
     });
   }
   
   protected void _updateButtonStates()
   {
      JButton btn = _buttons[BUTTON_FIND];
      if (mFindMode) 
      {
         btn.setIcon(_buttonCancelIcon);
         btn.setRolloverIcon(_buttonCancelIcon);
         btn.setToolTipText(_tooltipCancelFind);
      }
      else
      {
         btn.setIcon(_buttonIcons[BUTTON_FIND]);
         btn.setRolloverIcon(_buttonIcons[BUTTON_FIND]);
         btn.setToolTipText(_TOOLTIP[BUTTON_FIND]);
      }
      
      if (_iterBinding == null) 
      {

         return;
      }
      boolean buttonStates[] = new boolean[_buttons.length];
      
      buttonStates[BUTTON_INSERT]  = getHasInsertButton();
      buttonStates[BUTTON_DELETE]  = getHasDeleteButton();
      buttonStates[BUTTON_FIND]    = getHasFindButton();
      buttonStates[BUTTON_EXECUTE] = getHasExecuteButton();
      
      ViewObject vo = (_iterBinding != null) ? _iterBinding.getViewObject() : null;
      if (vo == null || !isVisible()) 
      {
         for (int i = 0; i < BUTTON_EXECUTE; i++) 
         {
            buttonStates[i] = false;
         }
         return;
      }
      if (getHasNavigationButtons() && _iterBinding != null)
      {
         synchronized(getTreeLock())
         //synchronized(_iterBinding.getSyncLock())
         {
            NavigatableRowIterator iter =  _iterBinding.getNavigatableRowIterator();
            
            //if (iter != null && iter.getRowSet().isExecuted())  
            //sjv - do we really need to know if the rowset is executed.
         
            //as a workaround, asking RowSet whether it's at a row. If not, then
            //assume whoever does execute will set me to proper row.
            if (iter != null && (_iterBinding.isFindMode() || iter.getCurrentRowSlot() == RowSetIterator.SLOT_VALID))
            {
               buttonStates[BUTTON_FIRST] = buttonStates[BUTTON_PREV] = iter.hasPrevious();
               buttonStates[BUTTON_LAST] = buttonStates[BUTTON_NEXT] = iter.hasNext();
            }
            else
            {
               buttonStates[BUTTON_FIRST] = buttonStates[BUTTON_PREV] = false;
               buttonStates[BUTTON_LAST] = buttonStates[BUTTON_NEXT] = false;
               buttonStates[BUTTON_DELETE] = false;
            }
         }
      }
      else
      {
         buttonStates[BUTTON_FIRST] = buttonStates[BUTTON_PREV] = 
         buttonStates[BUTTON_LAST] = buttonStates[BUTTON_NEXT] = false;
      }
      
      if (getHasTransactionButtons())
      {
         boolean dirty = _isDirty();
         buttonStates[BUTTON_COMMIT] = dirty;
         //_buttons[BUTTON_ROLLBACK].setToolTipText(Res.getString(dirty ? Res.NBAR_TOOLTIP_ROLLBACK : Res.NBAR_TOOLTIP_REQUERY));
         buttonStates[BUTTON_ROLLBACK] = dirty;
      }
      
      if (_iterBinding != null)
      {
         if (vo == null || vo.isReadOnly() ) 
         {
            buttonStates[BUTTON_INSERT] = false;
            buttonStates[BUTTON_DELETE] = false;
         }
      }
      
      
      for (int i = 0; (i < buttonStates.length); i++)
      {
         _buttons[i].setEnabled(buttonStates[i]);
         _buttons[i].setBorderPainted(false);
         _buttons[i].setRolloverEnabled(buttonStates[i]);
      }
   }
   
   
   private int _findButton(JButton button)
   {
     for(int i = 0 ; i < _buttons.length ; i++)
     {
         if (_buttons[i] == button)
             return i;
     }
     return -1;
   }
   
   private synchronized void _loadImages()
   {
      if (_buttonIcons != null)
      {
         return;
      }
      
      _buttonIcons = new ImageIcon[_IMAGES.length];
      _onButtonIcons = new ImageIcon[_IMAGES.length];
      _disButtonIcons = new ImageIcon[_IMAGES.length];
      _rollButtonIcons = new ImageIcon[_IMAGES.length];
      
      Class cl = JUNavigationBar.class;
      for (int i = 0; (i < _IMAGES.length); i++)
      {
         URL img, onimg, disimg, rollimg;
         img = cl.getResource(_IMAGES_DIR + _IMAGES[i] + ".gif");
         if (img != null)
             _buttonIcons[i] = new ImageIcon(img);
      
         onimg = cl.getResource(_IMAGES_DIR + _IMAGES[i] + "on.gif");
         if (onimg != null)
             _onButtonIcons[i] = new ImageIcon(onimg);
      
         disimg = cl.getResource(_IMAGES_DIR + _IMAGES[i] + "dis.gif");
         if (disimg != null)
             _disButtonIcons[i] = new ImageIcon(disimg);
      
         rollimg = cl.getResource(_IMAGES_DIR + _IMAGES[i] + "roll.gif");
         if (rollimg != null)
             _rollButtonIcons[i] = new ImageIcon(rollimg);
      }
      
      _buttonCancelIcon = new ImageIcon(cl.getResource(_IMAGES_DIR + "findcancel.gif"));
   }
   
   /**
   *  check if the transaction is dirty
   */
   private boolean _isDirty()
   {
      JUApplication app = (_iterBinding != null) ? _iterBinding.getApplication() : null;
      return (app != null) ? app.isTransactionModified() : false;
   }
   
   //
   // RowSet listener
   //
   public void navigated(NavigationEvent event)
   {
      _updateButtonStatesLater();
   }
   
   public void rangeRefreshed(RangeRefreshEvent event)
   {
      // On first refresh or after a roolback, set the currency to the first row available
      if (event.getRowCountInRange() > 0)
      {
      
         RowSetIterator rsi = _iterBinding.getRowSetIterator();
         if (rsi != null && rsi.getCurrentRow() == null) 
         {
            //try and get a row to be the first.
            if (_iterBinding != null && isVisible()) 
            {
               javax.swing.JComponent panel = ((javax.swing.JComponent)_iterBinding.getFormBinding().getPanel());
               if (panel != null && panel.isVisible())
               {
                  rsi.first();
               }
            }
            return;
         }
      }
      _updateButtonStatesLater();
   }
   
   public void rangeScrolled(ScrollEvent event)
   {
   }
   
   public void rowDeleted(DeleteEvent event)
   {
      if (!mDirty) 
      {
         _internalUpdateState();
      }
      else
      {
         //bug 2510912 NavBar delete button not disabled when
         //no more rows. This should force delete button to get repainted.
         if (_iterBinding != null) 
         {
            _updateButtonStatesLater();
         }
      }

   }
   
   public void rowInserted(InsertEvent event)
   {
      _internalUpdateState();
   }
   
   public void rowUpdated(UpdateEvent event)
   {
      _internalUpdateState();
   }

   void _internalUpdateState()
   {
      //DO NOT SEND DIRTY EVENT IF THE CURRENT ITERATOR IS IN FIND MODE.
      if (!mDirty && (_iterBinding != null && !_iterBinding.isFindMode()))
      {
         _iterBinding.getApplication().transactionStateChanged(true);
         _updateButtonStatesLater();
      }
   }
   
   public FocusListener getDefaultFocusListener()
   {
      return mFocusAdapter;
   }
   
   /**
   *  Get the button binding for a given button. <P>
   */
   
   public JUActionBinding getButtonActionBinding(int button)
   {
      if (button < BUTTON_FIRST || button > BUTTON_EXECUTE)
      {
         throw new JboException(UIMessageBundle.getResString(UIMessageBundle.STR_NAV_INVALID_BUTTON_INDEX));
      }
      return _bindings[button];
   }

   public void release()
   {
      if (_iterBinding != null) 
      {
         JUApplication app = _iterBinding.getApplication();
         if (app != null) 
         {
            app.removeTransactionStateListener(this);
         }
         for (int i = 0; i < _buttons.length; i++) 
         {
            if (_buttons[i] != null) 
            {
               _buttons[i].setEnabled(false);
            }
         }
         iteratorBindingChanged(null);
      }
   }
}


