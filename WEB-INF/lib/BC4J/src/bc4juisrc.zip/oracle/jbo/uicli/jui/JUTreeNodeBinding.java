/*
 * @(#)JUTreeNodeBinding.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.uicli.jui;

import java.util.ArrayList;
import javax.swing.JTree;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.TreeModel;
import javax.swing.tree.TreePath;
import oracle.jbo.DeleteEvent;
import oracle.jbo.InsertEvent;
import oracle.jbo.Key;
import oracle.jbo.Row;
import oracle.jbo.RowSetIterator;
import oracle.jbo.uicli.binding.JUCtrlHierNodeBinding;
import oracle.jbo.uicli.binding.JUCtrlHierTypeBinding;
import oracle.jbo.uicli.binding.JUIteratorBinding;

/**
 * This class implements rules that govern display of each node in a JTree
 * that is bound to a JUTreeBinding. It also governs what to display when the associated
 * node is expanded. The framework creates instances of this class for each
 * node in the tree.
 *
 * @see oracle.jbo.Row
 * @see oracle.jbo.RowIterator
 * @see oracle.jbo.uicli.jui.JUTreeBinding
 * @see javax.swing.JTree
 */
public class JUTreeNodeBinding extends JUCtrlHierNodeBinding
{
   private DefaultMutableTreeNode mTreeNode;
   private Object mNodeValue;
   private boolean mExpandable;
   private static String PLACE_HOLDER="$place-holder$";
   transient JUCtrlHierTypeBinding mTypeBinding;
   
   RowSetIterator mParentIter;
   Key mRowKey;

   /**
   * *** For internal framework use only ***
   */
   protected JUTreeNodeBinding(JTree tr, JUTreeBinding treeBinding, JUTreeNodeBinding parent,
                            JUIteratorBinding iterBinding, String attrName, Object nodeVal,
                            boolean expandable)
   {
      super(tr, treeBinding, parent, iterBinding, (attrName != null) ? (new String[]{attrName}) : (new String[] {}) );

      mTreeNode = new DefaultMutableTreeNode(this);
      mNodeValue = nodeVal;
      mExpandable = expandable;

      if (parent != null)
      {
         if (expandable) 
         {
            mTreeNode.add(new DefaultMutableTreeNode(PLACE_HOLDER));
         }
         DefaultMutableTreeNode parentNode = parent.getTreeNode();
         //treeBinding.getModelImpl(tr).insertNodeInto(mTreeNode, parentNode, count);
         parentNode.insert(mTreeNode, parentNode.getChildCount());
         if (mTreeNode.getParent() != parentNode) 
         {
            mTreeNode.setParent(parentNode);
         }
      }
      setFormBinding(treeBinding.getFormBinding());
   }


   /**
   * *** For internal framework use only ***
   */
   protected JUTreeNodeBinding(JTree tr, 
                            JUTreeBinding treeBinding, 
                            JUTreeNodeBinding parent,
                            JUIteratorBinding iterBinding, 
                            JUCtrlHierTypeBinding typeBinding, 
                            RowSetIterator parentRSI, 
                            Row row,
                            boolean expandable)
   {
      super(tr, treeBinding, parent, iterBinding, 
               (typeBinding != null && typeBinding.getAttributeName() != null) ? (new String[]{typeBinding.getAttributeName()}) : (new String[] {}) );
      mTreeNode = new DefaultMutableTreeNode(this);
      mNodeValue = row.getAttribute(typeBinding.getAttributeName());
      mExpandable = expandable;

      if (parent != null)
      {
         if (expandable) 
         {
            mTreeNode.add(new DefaultMutableTreeNode(PLACE_HOLDER));
         }
         DefaultMutableTreeNode parentNode = parent.getTreeNode();
         //treeBinding.getModelImpl(tr).insertNodeInto(mTreeNode, parentNode, count);
         parentNode.insert(mTreeNode, parentNode.getChildCount());
         if (mTreeNode.getParent() != parentNode) 
         {
            mTreeNode.setParent(parentNode);
         }
      }

      setFormBinding(treeBinding.getFormBinding());
      mParentIter = parentRSI;
      mRowKey = row.getKey();
      mTypeBinding = typeBinding;
   }

   
   /**
   * Finds the row that this node represents in the associated iterator by asking this
   * node's parent node for the iterator and then sets that row as current row in the
   * RowIterator.
   */
   public void nodeSelected()
   {
      if (mParentIter != null)
      {
         DefaultMutableTreeNode parentTreeNode = (DefaultMutableTreeNode)mTreeNode.getParent();

         if (parentTreeNode != null) 
         {
            JUTreeNodeBinding parentNode = (JUTreeNodeBinding)parentTreeNode.getUserObject();

            if (parentNode != null && mRowKey != null)
            {
               Row[] rows = mParentIter.findByKey(mRowKey, -1);

               if (rows.length > 0)
               {
                  ((JUPanelBinding)getFormBinding()).callBeforeRowNavigated(parentNode.getIteratorBinding());
                  mParentIter.setCurrentRow(rows[0]);
               }
            }
         }
      }
   }

   
   /**
   * Execute the query for the RowIterator that this row is associated with if it is not already executed.
   */
   public void executeQueryIfNeeded()
   {
      //how do I set my key into the iterator?
      /*
      if (mParentIter != null)
      {
         DefaultMutableTreeNode parentTreeNode = (DefaultMutableTreeNode)mTreeNode.getParent();

         if (parentTreeNode != null) 
         {
            JUTreeNodeBinding parentNode = (JUTreeNodeBinding)parentTreeNode.getUserObject();

            if (parentNode != null && mRowKey != null)
            {
               Row[] rows = mParentIter.findByKey(mRowKey, -1);

               if (rows.length > 0)
               {
//                  ((JUPanelBinding)getFormBinding()).callBeforeRowNavigated(parentNode.getIteratorBinding());
//                   mParentIter.setCurrentRow(rows[0]);
               }
            }
         }
      }
      */

      getIteratorBinding().executeQueryIfNeeded();
   }

   
   /**
   * *** For internal framework use only ***
   */
   public void addControlToPanel(Object panel, Object layoutObject, Object layoutCons)
   {
   }

   
   /**
   * Collapses the detail nodes of this node and closes this node.
   */
   public void collapse()
   {
      ((JTree) getControl()).collapsePath(new TreePath(mTreeNode));
   }

   
   /**
   * Expands this node if this node has child-rows to display.
   */
   public void expand()
   {
      JTree jTree = (JTree) getControl();
      TreePath path = getTreePath();
      jTree.collapsePath(path);
      
      ArrayList children = getChildren();

      //sjv-shouldn't we run thru and expand the last child?
      if (children != null)
      {
         for (int j = 0; j < children.size(); j++)
         {
            JUTreeNodeBinding child = (JUTreeNodeBinding) children.get(j);

            jTree.expandPath(child.getTreePath());
         }
      }
   }

   /**
   * Returns the RowSetIterator that this node's row is part of. 
   */
   public RowSetIterator getParentRowSetIterator()
   {
      return mParentIter;
   }

   /**
   * Returns the Key object that identifies the row that this node is displaying.
   */
   public Key getRowKey()
   {
      return mRowKey;
   }
   
   /**
   * Returns the value that this node displays.
   */
   public Object getValueAt(int rowIndex, int attrIndex)
   {
      return mNodeValue;
   }

   
   /**
   * Sets the value that this node is displaying. Note that this method only changes
   * the display and does not actually update the value of the attribute that this
   * row is displaying.
   */
   public void setValueAt(Object value, int rowIndex, int attrIndex)
   {
      mNodeValue = value;
   }
   
   
   /**
   * Returns the Swing TreeNode object to which this node is associated.
   */
   public DefaultMutableTreeNode getTreeNode()
   {
      return mTreeNode;
   }

   
   /**
   * Returns the TreePath that represents this node in the containing JTree hierarchy.
   * This treepath can be used to work with the JTree/TreeModel APIs that expect a
   * tree path for a node.
   */
   public TreePath getTreePath()
   {
      JUTreeNodeBinding parent = (JUTreeNodeBinding) getParent();

      if (parent == null)
      {
         return new TreePath(mTreeNode);
      }
      else
      {
         Object[] pathComp = parent.getTreePath().getPath();
         Object[] newPathComp = new Object[pathComp.length + 1];

         System.arraycopy(pathComp, 0, newPathComp, 0, pathComp.length);
         
         newPathComp[newPathComp.length - 1] = mTreeNode;

         return new TreePath(newPathComp);
      }
   }


   JUTreeNodeBinding findMatchingNode(Key key)
   {
      JUTreeNodeBinding node = null;
      ArrayList children = getChildren();
      if (children != null)
      {
         int size = children.size();
         for (int j = 0; (j < size); j++)
         {
            node = ((JUTreeNodeBinding) children.get(j));
            if (key.equals(node.mRowKey))
            {
               return node;
            }
         }
      }
      return null;
   }
   
   /**
   * Update the display by adding a node to render the inserted row as this node's child.
   */
   public void updateRowInserted(InsertEvent event)
   {
      updateValuesFromRows(new Row[]{event.getRow()}, false);
   }
   
   
   /**
   * Removes a child node that displays the deleted row from amongst this node's children.
   */
   public void updateRowDeleted(DeleteEvent event)
   {
      Row row = event.getRow();
      JUTreeNodeBinding node = findMatchingNode(row.getKey());
      if (node != null) 
      {
         node.mTreeNode.removeFromParent();
         ((JUTreeBinding)getHierBinding()).getModelImpl((JTree)getControl()).nodeStructureChanged(mTreeNode);
      }
   }

   /**
   * Finds the child node that displays this row and updates its display.
   */
   public void updateValuesFromRow(Row row)
   {
      JUTreeNodeBinding node = findMatchingNode(row.getKey());
      if (node != null) 
      {
         JTree tree = ((JTree)getControl());
         node.mNodeValue = row.getAttribute(node.getAttributeNames()[0]);
         TreePath path = node.getTreePath();
         TreeModel model = tree.getModel();
         
         if (node.mTreeNode.getParent() != mTreeNode) 
         {
            System.out.println("***************how can this be true**********");
            node.mTreeNode.setParent(mTreeNode);
         }
         
         model.valueForPathChanged(path, node);
         tree.updateUI();
      }
   }

   
   /**
   * Updates the child nodes that this node contains after optionally clearing out all
   * the currently displayed children based on the clear flag.
   * <p>
   * This method determines the rules to associate with each row in the given array of rows.
   */
   public void updateValuesFromRows(Row[] rows, boolean clear)
   {
      // if (!mChildrenInit)
      JTree tree = ((JTree) getControl());
      if (clear)
      {
         mTreeNode.removeAllChildren();
         mChildren = null;
      }
      
      JUTreeBinding treeBinding = (JUTreeBinding)getHierBinding();
      JUCtrlHierTypeBinding[] typeBindings = treeBinding.getTypeBindings();

      String thisVOType = getViewObject().getDefFullName();

      int typeBindingSize = (typeBindings != null) ? typeBindings.length : 0;
      JUCtrlHierTypeBinding typeBinding = null;

      for (int k = 0; k < typeBindingSize; k++)
      {
         if (typeBindings[k].matchViewObjectType(thisVOType))
         {
            typeBinding = typeBindings[k];
            break;
         }
      }

      Row row;
      JUIteratorBinding iterBnd;
      String childAccessorName;
      String childAttrName = null;
      boolean expandable;
      RowSetIterator rsi = getIteratorBinding().getRowSetIterator();
      ArrayList al = new ArrayList(rows.length);

      if (typeBinding != null)
      {
         for (int j = 0; j < rows.length; j++)
         {
            row = rows[j];
            if (row != null) 
            {
               expandable = false;
               iterBnd = null;
               childAttrName = typeBinding.getAttributeName();
               if ((childAccessorName = typeBinding.getAccessorName()) != null)
               {
                  iterBnd = new JUIteratorBinding((RowSetIterator) row.getAttribute(childAccessorName));
                  expandable = true;
               }
      
               al.add(new JUTreeNodeBinding( tree, treeBinding,
                                                               this, iterBnd, 
                                                               typeBinding, rsi, row, expandable));
            }
         }
      }
      else
      {
         //for each row, figure out the discriminant type and match the node-binding.
         ArrayList discrBindings = new ArrayList(typeBindingSize);
         for (int k = 0; k < typeBindingSize; k++)
         {
            //could have done instanceof Instead using methods
            //as supposedly methods are faster.
            if (typeBindings[k].isDiscrColumnType())
            {
               discrBindings.add(typeBindings[k]);
            }
         }

         JUTreeDiscrAttrTypeBinding discrBinding;
         java.util.Iterator iter;

         for (int j = 0; j < rows.length; j++)
         {
            row = rows[j];
            if (row != null) 
            {
               expandable = false;
               iterBnd = null;
               typeBinding = null;
               
               iter = discrBindings.iterator();
               while (iter.hasNext())
               {
                  discrBinding = (JUTreeDiscrAttrTypeBinding)iter.next();
                  if (discrBinding.matchRowDiscrColumn(row))
                  {
                     typeBinding = discrBinding;
                     break;
                  }
   
               }
   
               if (typeBinding != null)
               {
                  childAttrName = typeBinding.getAttributeName();
   
                  if ((childAccessorName = typeBinding.getAccessorName()) != null)
                  {
                     iterBnd = new JUIteratorBinding((RowSetIterator) row.getAttribute(childAccessorName));
                     expandable = true;
                  }
      
                  al.add(new JUTreeNodeBinding( tree, treeBinding,
                                                                  this, iterBnd, 
                                                                  typeBinding, rsi, row, expandable));
               }
            }
         }
      }

      //if (al.size() > 0) 
      {
         TreePath path = getTreePath();
         
         ((JUTreeBinding)getHierBinding()).getModelImpl(tree).nodeStructureChanged(mTreeNode);

         tree.expandPath(path);
      }

   }

   /**
   * Renders the attribute value that this node is supposed to show. This method is used
   * by JTree to display the String for a node in the tree.
   */
   public String toString()
   {
      if (mNodeValue == null)
      {
         return "";
      }

      return mNodeValue.toString();
   }

   /**
   * Returns the type binding that governs the display of this node. The returned object
   * can be used to find out the name of the attribute that this node displays and the
   * accessor that this row will expand (if any).
   */
   public final JUCtrlHierTypeBinding getHierTypeBinding()
   {
      return mTypeBinding;
   }
}
