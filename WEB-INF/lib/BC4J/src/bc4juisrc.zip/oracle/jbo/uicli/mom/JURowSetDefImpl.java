/*
 * @(#)JURowSetDefImpl.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.uicli.mom;

import java.util.ArrayList;
import java.util.Iterator;
import oracle.jbo.mom.DefinitionObject;
import oracle.jbo.mom.xml.DefElementImpl;
import oracle.jbo.mom.xml.DefPersistable;
import oracle.jbo.mom.xml.DefPersistenceException;
import oracle.jbo.mom.xml.DefWriter;

public class JURowSetDefImpl extends DefinitionObject implements DefPersistable   
{
   ArrayList evImplNames;
   
   JURowSetDefImpl () {}

   JURowSetDefImpl (String name, String className)
   {
      setName(name);
      evImplNames = new ArrayList(3);
      evImplNames.add(className);
   }

   /**
    * Creates the EntityDefImpl from the XML metadata stream.
    * @param xmlElement  the name of the XML node from which to load.
    * @exception oracle.jbo.PersistenceException is thrown if an error occurs
    * while loading the XML node.
   */
   static JURowSetDefImpl loadFromXML(DefElementImpl xmlElement, String sessionName)
   {
      JURowSetDefImpl eInfo = new JURowSetDefImpl();
      String name =xmlElement.readString(JUTags.Name);
      eInfo.setName(name);

      com.sun.java.util.collections.ArrayList children = xmlElement.readStringArrayList(JUTags.EventClass);
      ArrayList al = new ArrayList(children.size());
      for ( int i = 0; i < children.size(); i++ )
      {
         al.add(children.get(i));
      }

      eInfo.evImplNames = al;
      eInfo.setFullName((new StringBuffer(sessionName).append(".").append(name)).toString());
      return eInfo;
   }

   ArrayList getEventArrayList()
   {
      return (evImplNames != null) ? (ArrayList)evImplNames.clone() : new ArrayList(1);
   }

   boolean mDirty = false;
   boolean mIsNew = false;
   /**
    * This method returns if an Object is modified from last save/load
    * @return Returns true if the Object is dirty. Returns false otherwise.
    **/
   public boolean isDirty()
   {
      return mDirty;
   }

   /**
    * This method marks the Object dirty
    * @param isDirty If true the Object is marked Dirty.
    **/
   public void    setDirty(boolean isDirty)
   {
      mDirty = true;
   }

   /**
    * This method returns if this object is previously persisted.
    * @return true if the Object is previously persisted. Returns false otherwise.
    **/
   public boolean isNew()
   {
      return mIsNew;
   }

   /**
    * This method marks the as previously persisted. By default all objects
    * are new objects. When the object is persisted first time, that object is
    * marked as 'not new' object
    * @param isNew If true the Object is marked as new object.
    **/
   public void    setNew(boolean isNew)
   {
      mIsNew = isNew;
   }


   /**
    * Objects should write their persistence output in this method
    * @param jos the Output storage for persistence
    **/
   public void writeObject(DefWriter jos) throws DefPersistenceException
   {
      jos.writeObject(this);
   }

   /**
    * Objects should write their persistence output in this method
    * @param jos the Output storage for persistence
    * @DefPersistable parent Parent Object that's calling the writeChildren
    * @return Number of Contents returned
    * @Exception Error in writing the Object's contents to Persistent Storage
    **/
   public void writeContents(DefWriter jos) throws DefPersistenceException
   {
      //jos.writeString(JUTags.EventClass, evImplName);
   }

   /**
    * Writes the Object's children to the Persistent storage
    * @param jos the Output storage for persistence
    * @Exception Error in writing the Object's Children to the storage
    **/
   public void writeChildren(DefWriter jos) throws DefPersistenceException
   {
      if (evImplNames != null) 
      {
         com.sun.java.util.collections.ArrayList children = new com.sun.java.util.collections.ArrayList(evImplNames.size());
         
         Iterator iter = evImplNames.iterator();
         while(iter.hasNext())
         {
            children.add(iter.next());
         }
   
         jos.writeStringArray(JUTags.EventClass, children.iterator());
      }
   }


   /**
    * Returns a piece of static info for the type of object this is invoked
    * upon.  Examples are PreparedStatements for insert, update, delete,
    * and String containing a base the select statement for retrieving
    * instances of this type through the SQLInputStream
    * @param type Type of the Persistence Statement requested. The type
    *             can be any of the Statement types defined in this interface.
    * @return returns the Statement required to store in Persitent Storage.
    *         Incase of XML, it just returns the String. In the case of SQL
    *         a JDBC PreparedStatement is returned.
    **/
   public String getXMLElementTag()
   {
      return JUTags.RowSet;
   }

}

