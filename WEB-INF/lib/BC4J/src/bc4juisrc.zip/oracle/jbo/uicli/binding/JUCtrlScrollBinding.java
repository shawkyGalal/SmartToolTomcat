/*
 * @(#)JUCtrlScrollBinding.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.uicli.binding;

import oracle.jbo.DeleteEvent;
import oracle.jbo.InsertEvent;
import oracle.jbo.NavigatableRowIterator;
import oracle.jbo.NavigationEvent;
import oracle.jbo.RangeRefreshEvent;
import oracle.jbo.RowIterator;
import oracle.jbo.RowSetIterator;
import oracle.jbo.RowSetListener;
import oracle.jbo.ScrollEvent;
import oracle.jbo.UpdateEvent;

/**
 * Implements binding of controls like Scrollbar, Slider, etc to a ViewObject.
 * This class listens to the RowSet events from the associated BC4J RowSet and 
 * resets/updates the control/model with appropriate currency and range.
 */
abstract public class JUCtrlScrollBinding extends JUControlBinding implements RowSetListener
{
   protected int mMin;
   protected int mMax;
   protected int mVal;
   protected int mExt;
   protected boolean mScrollCurrRow;
   protected boolean mUseEstRC;
   
   
   /**
   * Reflects the current iterator state by setting the given set of values
   * on the associated control.
   * @param val The current value which indicates the row index of the current row in the 
   * current range.
   * @param ext The extent value which is used by a control to scroll that many rows
   * up or down.
   * @param minVal The minimum value that this control allows.
   * @param maxVal The maximum value that this control allows.
   */
   abstract protected void setValues(int val, int ext, int minVal, int maxVal);

   /**
   * Sets the current iterator state by setting the given set of values
   * on the iterator.
   * @param val The current value which indicates the row index of the current row in the 
   * current range.
   * @param ext The extent value which is used by a control to scroll that many rows
   * up or down.
   * @param minVal The minimum value that this control allows.
   * @param maxVal The maximum value that this control allows.
   */
   abstract protected void setRangeScrollValues(int val, int ext, int minVal, int maxVal);
   

   /**
   * Creates an instance of this class bound to the given control and iterator Binding object.
   * @param scrollCurrRow Not used.
   * @param deferAssignValues If true, indicates that the iterator's current settings
   * should be immediately applied to the bound control.
   * @param useEstRC If true, indicates that the binding should use getEstimatedRowCount()
   * on the associated iterator to figure out the maximum number of rows in the associated
   * iterator. Otherwise, in-memory row count of the iterator is used.
   */
   public JUCtrlScrollBinding(Object control, JUIteratorBinding iterBinding,
                              boolean scrollCurrRow, boolean deferAssignValues, boolean useEstRC)
   {
      super(control, iterBinding);

      RowSetIterator rsi = iterBinding.getRowSetIterator();

      mScrollCurrRow = scrollCurrRow;
      mUseEstRC = useEstRC;
      
      if (deferAssignValues && !rsi.getRowSet().isExecuted())
      {
         mMin = -1;
         mMax = -1;
         mVal = -1;
         mExt = -1;
      }
      else
      {
         assignValues();
      }

      try
      {
         rsi.addListener(this);
      }
      catch(Exception ex)
      {
         reportException(ex);
      }
   }


   private void setValues()
   {
      setValues(mVal, mExt, mMin, mMax);
   }
   
   /**
   * Uses the current RowSetIterator to calculate the current values from the
   * associated RowSetIterator.
   */
   protected void initFromRSI()
   {
      RowIterator rsi = getRowIterator();

      if (rsi == null)
      {
         return;
      }
      
      mMin = 0;

      if (mUseEstRC && !getIteratorBinding().isFindMode())
      {
         mMax = (int) ((RowSetIterator)rsi).getRowSet().getEstimatedRowCount();
      }
      else
      {
         mMax = rsi.getRowCount();
      }

      mExt = rsi.getRangeSize();

      if (mExt < 0)
      {
         mExt = mMax;
      }
      
      mVal = 0;
   }
   
   /**
   * Initializes the binding member variables from the current settings in the
   * associated RowSetIterator. Then sets these values into the model/control
   * using setValues() method.
   */
   protected void assignValues()
   {
      try
      {
         initFromRSI();

         setValues();
      }
      catch(Exception ex)
      {
         reportException(ex);
      }
   }

   
   /**
   * Sets the currency to the given row index in the current range of rows
   * that the associated iterator is working with. This method scrolls the
   * current row in the current range, if it falls out of the current range.
   */
   public void setRangeScrollValue(int newVal)
   {
      try
      {
         RowIterator rsi = getRowIterator();
         
         int rangeSize = rsi.getRangeSize();
         if (rangeSize >= 0)
         {
            int rangeStart = rsi.getRangeStart();
            if (rangeStart < 0)
            {
               rangeStart = 0;
            }


            int currRowIndex = rsi.getCurrentRowIndex();
            JUFormBinding form = getFormBinding();
            

            int scroll = newVal - rangeStart;

            //we may look for current row and if the new val is same as current row before
            //sending out navigation event.
            form.callBeforeRowNavigated(getIteratorBinding());

            if (scroll < rangeSize && scroll >= 0)
            {
               //in scroll range. >=0 check for slider/scroll bar moving backwards.
               rsi.setCurrentRowAtRangeIndex(scroll);
            }
            else
            {
               //out of current range, bring the row in.
               rsi.scrollRange(scroll);
               if (scroll > 0) 
               {
                  rsi.setCurrentRowAtRangeIndex(rangeSize-1);
               }
               else
               {
                  rsi.setCurrentRowAtRangeIndex(0);
               }
            }
         }
         else
         {
            //if all rows are fetched in the range, set the currency to the
            //indicated row.
            getFormBinding().callBeforeRowNavigated(getIteratorBinding());
            rsi.setCurrentRowAtRangeIndex(newVal);
         }

      }
      catch(Exception ex)
      {
         reportException(ex);
      }
   }


   //
   // RowSetListener implementation
   //
   
   public void rangeRefreshed(RangeRefreshEvent event)
   {
      assignValues();
   }

   
   public void rangeScrolled(ScrollEvent event)
   {
      RowSetIterator rsi = (RowSetIterator) event.getSource();

      mVal += event.getScrollAmount();

      setValues();
   }

   
   public void rowInserted(InsertEvent event)
   {
      mMax++;

      setValues();
   }

   
   public void rowDeleted(DeleteEvent event)
   {
      mMax--;

      setValues();
   }

   
   public void rowUpdated(UpdateEvent event)
   {
   }
   
   
   public void navigated(NavigationEvent event)
   {
      RowSetIterator rsi = (RowSetIterator) event.getSource();
      mVal = rsi.getCurrentRowIndex();
      setValues();
   }

   /**
   * Associates the given RowSet iterator with this Binding object. If this object
   * was working with another RowSet, removes it from the RowSetListener's list of
   * the first RowSet. Adds this object as a RowSetListener in the given RowSet, so
   * that this binding can track rowset scroll and navigation events.
   */
   protected  void bindRowSetIterator(RowSetIterator rsi)
   {
      NavigatableRowIterator origRsi = getIteratorBinding().getNavigatableRowIterator();
      if (origRsi != null) 
      {
         origRsi.removeListener(this);
      }

      if (rsi != null) 
      {
         rsi.addListener(this);
      }
   }

   /**
   * *** For internal framework use only ***
   * <p>
   * Updates the values in a control that is bound using an Iterator already in use.
   * (a valid row iterator)
   * If you do not call this method, your control won't update unless you refresh the Iterator.
   */
   public void refreshControl()
   {
      assignValues();
   }

   void release()
   {
      bindRowSetIterator(null);
      super.release();
   }

}                                            
