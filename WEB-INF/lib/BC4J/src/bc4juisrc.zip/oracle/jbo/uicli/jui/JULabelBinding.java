/*
 * @(#)JULabelBinding.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.uicli.jui;

import java.awt.Component;
import javax.swing.JLabel;
import javax.swing.JPanel;
import oracle.jbo.Row;
import oracle.jbo.uicli.binding.JUCtrlAttrsBinding;
import oracle.jbo.uicli.binding.JUFormBinding;
import oracle.jbo.uicli.binding.JUIteratorBinding;

/**
 * Binds a label control as a control binding so that the text for the label is derived
 * from an attribute of a ViewObject row. This binding can be used to create dynamic UIs with
 * labels read from the database using ViewObjects. JULabel is an example of a control that 
 * works with this binding.
 */
public class JULabelBinding extends JUCtrlAttrsBinding
{
   protected JULabelBinding()
   {
   }

   public JULabelBinding(JLabel control, JUIteratorBinding iterBinding, String attrName)
   {
      super(control, iterBinding, new String[] { attrName });

      init(control);
   }


   private void init(JLabel control)
   {
   }

   
   /**
   * *** For internal framework use only ***
   */
   public void addControlToPanel(Object panel, Object layoutObject, Object layoutCons)
   {
      ((JPanel) panel).add((Component) layoutObject, layoutCons);
   }

   
   public Object getValueAt(int attrIndex)
   {
      JLabel control = (JLabel) getControl();
      
      if (control != null)
      {
         return control.getText();
      }
      else
      {
         return null;
      }
   }


   public void setValueAt(Object value, int attrIndex)
   {
      JLabel control = (JLabel) getControl();
      
      if (control != null)
      {
         control.setText(value == null ? "" : value.toString());
      }
   }


   public void setDataValueAt(Object value, int attrIndex)
   {
      setValueAt(value, attrIndex);

      setAttribute(0, value);
   }


   /**
    * Makes sure that labels are not turned into disabled if the
    * attribute is marked readonly. This method resets the control
    * to it's existing enabled state.
   */
   public void updateValuesFromRow(Row row)
   {
      JLabel label = (JLabel)getControl();
      boolean enabled = label.isEnabled();
      
      super.updateValuesFromRow(row);
      
      label.setEnabled(enabled);
   }



   /**
   * This method is used by the JDeveloper design time wizards for binding a label
   * with an attribute of rows of a ViewObject/RowIterator.
   * This method calls JUFormBinding.getRowIterBinding to get the iterator binding using
   * the given parameters and then registers a new JUTextFieldBinding with the iterator
   * binding object so as to display/edit the current row's attribute of the given name.
   * <p>
   * @param formBinding The containing JUPanelBinding in which the given iterator binding
   * would be found/created.
   * @param control The control instance to bind to a ViewObject's attribute.
   * @param voInstanceName Name of the instance of the ViewObject in a BC4J ApplicationModule.
   * @param voIterName Runtime instance name of the iterator in the ViewObject (optional).
   * @param voIterBindingName Instance name of the iterator binding that uniquely identifies an
   * iterator binding object used to read/write data in this given JUPanelBinding instance.
   * @param attrName The name of the attribute of this ViewObject rows that contain data
   * to display/edit in the associated text control.
   * @return JULabelBinding An instance of control binding that works with the given label.
   */
   public static JULabelBinding createAttributeBinding(JUFormBinding formBinding, 
                                            JLabel control,
                                            String        voInstanceName,
                                            String        voIterName, /*temporarily taking nulls for this*/
                                            String        voIterBindingName,
                                            String        attrName)
   {
      if (!JUIUtil.inDesignTime())
      {
         JULabelBinding bind = new JULabelBinding(control, 
                                   formBinding.getRowIterBinding(voInstanceName, voIterName, voIterBindingName),
                                   attrName);
         bind.refreshControl();
         return bind;
      }
      else
      {
         try
         {
            Class clazz = Class.forName("oracle.jbo.dt.ui.jui.propertyeditors.dtmodels.DTJULabelBinding");
            java.lang.reflect.Constructor constructor = clazz.getConstructors()[0];
            Object [] args = { voInstanceName + "." + attrName };
            Object object = constructor.newInstance(args);
            return (JULabelBinding)object;
         }
         catch (Exception e)
         {
            return null;
         }
      }
   }

   /**
   * @deprecated since JDeveloper 9.0.2, use createAttributeBinding instead
   */
   public static JULabelBinding getInstance(JUFormBinding formBinding, 
                                            JLabel control,
                                            String        voInstanceName,
                                            String        voIterName, /*temporarily taking nulls for this*/
                                            String        voIterBindingName,
                                            String        attrName)
   {
      return createAttributeBinding(formBinding, control, voInstanceName, voIterName, voIterBindingName, attrName);
   }
}
