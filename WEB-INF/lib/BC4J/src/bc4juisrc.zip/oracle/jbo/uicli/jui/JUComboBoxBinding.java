/*
 * @(#)JUComboBoxBinding.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.uicli.jui;

import java.awt.Component;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import javax.swing.ComboBoxEditor;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JComboBox;
import javax.swing.JPanel;
import javax.swing.ListCellRenderer;
import javax.swing.MutableComboBoxModel;
import javax.swing.event.ListDataListener;
import oracle.jbo.AttributeDef;
import oracle.jbo.Row;
import oracle.jbo.RowIterator;
import oracle.jbo.ViewObject;
import oracle.jbo.uicli.binding.JUCtrlListBinding;
import oracle.jbo.uicli.binding.JUFormBinding;
import oracle.jbo.uicli.binding.JUIteratorBinding;
import oracle.jbo.uicli.controls.JUMultiAttrListCellRenderer;
import oracle.jbo.uicli.controls.JUMultiAttrListEditor;

/**
 * Implements binding a Swing JComboBox to a BC4J Attribute or ViewObject or as an LOV (list of values).
 * <p>
 * A combobox can be bound in the following ways:
 * <ul>
 * <li>Display single or multiple attributes for rows in a RowSet and
 * iterate the rowset currency.</li>
 * <li>Display single attribute from rows in a RowSet and update another attribute
 * in a different ViewObject.</li>
 * <li>Display single or multiple attributes from rows in a RowSet and update one or
 * multiple attributes in a different ViewObject (similar to an LOV).</li>
 * <li>Display a static LOV and update one attribute in a BC4J row.</li>
 * </ul>
 * <p>
 * This class also implements ActionListener interface and listens to ActionEvents from
 * the bound combobox. On an action event, it either performs an update of the target
 * ViewObject attributes, or iterates a target ViewObject as per the list operation mode
 * set in the constructor.
 */
public class JUComboBoxBinding extends JUCtrlListBinding implements ActionListener, MutableComboBoxModel
{
   private MutableComboBoxModel mComboModel = null;
   private boolean mSettingValue = true;


   /**
   * Binds a ComboBox to a RowSet associated with the given iterator binding and 
   * based on listOperMode setting, either iterates the currency on the target iterator
   * or updates the attribute value for the given attribute (in attrNames) in the current
   * row in the target RowSet. Note that the combobox will display and (optionally)update 
   * the same attribute from a RowSet.
   * @param cb ComboBox with which to associate this binding.
   * @param iterBinding Provides the RowSet from which this binding accesses data
   * to display in the combobox and optionally the current row for which attribute(s)
   * are to be updated.
   * @param attrNames An ordered array of attribute names to display and optionally update
   * in a ViewObject.
   * @param listOperMode Can be one of two values:
   * <ul>
   * <li>LIST_OPER_SET_ATTRIBUTE (the default) to indicate that this combobox
   * is to be used to update attributes in the current row of the associated RowSet.</LI>
   * <li>LIST_OPER_NAVIGATE to indicate that this combobox should be used to 
   * iterate currency in the associated RowSet.</LI>
   * </ul>
   */
   public JUComboBoxBinding(JComboBox cb, JUIteratorBinding iterBinding,
                            String[] attrNames, int listOperMode /*, boolean shouldScroll*/)
   {
      super(cb, iterBinding, attrNames, listOperMode);

      init(cb);
   }

   
   /**
   * Binds a combobox to an attribute in the associated RowSet. The values displayed in combobox
   * are provided by the valueList objects.
   * @param cb ComboBox with which to associate this binding.
   * @param iterBinding Provides the RowSet that is used to update current selection 
   * from the combobox into the current row in the rowset.
   * @param attrNames Provides the name of an attribute (only one attribute is updateable in 
   * this mode).
   * @param valueList A static list of values displayed as options in the combobox from which
   * to select.
   */
   public JUComboBoxBinding(JComboBox cb, JUIteratorBinding iterBinding,
                            String[] attrNames, Object[] valueList /*, boolean shouldScroll*/)
   {
      super(cb, iterBinding, attrNames, valueList);

      init(cb);
   }


   /**
   * Binds separate ViewObject/RowSets for display and update to the same ComboBox.
   * Use this binding constructor to provide a separate iterator binding for update
   * and a separate iterator binding which provides rows for display in the combobox.
   * Optionally, the attributes displayed can be different from the attributes that 
   * should be used to update a corresponding set of attributes in the target/updateable 
   * ViewObject.
   * <p>
   * @param cb ComboBox to associate this binding with.
   * @param iterBinding Provides the RowSet in which the current row is updated
   * based on selection in the combobox.
   * @param attrNames An ordered array of attribute names to update
   * in a ViewObject. This list should have the same number of attributes as
   * in listAttrNames, which provides the corresponding attribute names from the 
   * display ViewObject/RowSet.
   * @param listIterBinding Provides the RowSet which is used to display data in the
   * combobox.
   * @param listAttrNames An ordered list of attribute names, which are used to 
   * get the values to update into the attributes from the attrNames list in the
   * target ViewObject. If this list is null, then the attribute names for display 
   * are set the same as attrNames.
   * @param listDisplayAttrNames An ordered list of attribute names that specify
   * the attributes to display from rows in the display ViewObject/RowSet.
   * If this list is null, then attribute names are assumed to be same as in attrNames.
   */
   public JUComboBoxBinding(JComboBox cb, JUIteratorBinding iterBinding,
                            String[] attrNames, JUIteratorBinding listIterBinding,
                            String[] listAttrNames, String[] listDisplayAttrNames
                            /*, boolean shouldScroll*/)
   {
      super(cb, iterBinding, attrNames, listIterBinding, listAttrNames, listDisplayAttrNames);

      init(cb);
   }


   private void init(JComboBox cb)
   {
      mComboModel = getModelImpl(cb);

      if (cb != null)
      {
         if (mComboModel != cb.getModel())
         {
            cb.setModel(mComboModel);
         }

         if (mValueList != null && mStaticList) 
         {
            setupListItems(false, false);
         }
         cb.addFocusListener(new JUSVFocusAdapter(this, 0));
      }
   }

   /**
   * Sets the model reference in this binding class by using the current
   * model in the combobox. Returns the same model reference. If there is
   * no model in the combobox, creates a DefaultComboBoxModel and returns that.
   */
   protected MutableComboBoxModel getModelImpl(JComboBox control)
   {
      MutableComboBoxModel comboModel = mComboModel;
      if (comboModel == null)
      {
         if (control != null)
         {
            comboModel = (MutableComboBoxModel) control.getModel();
         }

         if (comboModel == null)
         {
            comboModel = new DefaultComboBoxModel();
         }
      }
      return comboModel;
   }

   
   /**
   * *** For internal framework use only ***
   */
   public void addControlToPanel(Object panel, Object layoutObject, Object layoutCons)
   {
      ((JPanel) panel).add((Component) layoutObject, layoutCons);
   }

   
   /**
   * This method is used by the framwork to setup the list of values (LOV) that will be displayed in
   * this combobox.
   * @param clean Controls whether to clean the existing entries in the combobox.
   * @param keepSelectedIndex Controls whether to maintain current index as the selected index 
   * after the display data is updated. If this value is true, the current index is maintained.
   * However if the current index is more than the number of items in the combobox, then the selection
   * is reset to the first item.
   */
   protected void setupListItems(boolean clean, boolean keepSelectedIndex)
   {
      JComboBox combo = (JComboBox)getControl();
      int index = (keepSelectedIndex) ? combo.getSelectedIndex() : 0;
      if (combo != null) 
      {
         combo.removeActionListener(this);
         if (clean && combo.getItemCount() > 0)
         {
            combo.removeAllItems();
         }
      }

      if (mValueList == null || clean) 
      {
         super.setupListItems(clean, keepSelectedIndex);
      }

      Object[] valueList = getValueList();
      int size = valueList.length;

      for (int j = 0; j < size; j++)
      {
         Object val = valueList[j];

         if (val != null)
         {
            mComboModel.addElement(valueList[j]);
         }
      }

      if (combo != null) 
      {
        
         if (size > 0)
         {
           if (index >= size) 
           {
              index = 0;
           }
           
           if (index >= 0)
           {
              combo.setSelectedIndex(index);
           }
           else if (getIteratorBinding() != null)
           {
              Row curRow = getCurrentRow();
              if (curRow != null)
              {
                 updateValuesFromRow(curRow);
              }
           }
         }
        combo.addActionListener(this);
      }
   }

   /**
   * Returns the currently selected item from the list model. This is used by the framework
   * to update the values into the target rowset.
   * @param attrIndex This argument is ignored by this method.
   */
   public Object getValueAt(int attrIndex)
   {
      return mComboModel.getSelectedItem();
   }

   
   /**
   * Finds the item in the combobox that matches the given value and sets it as the current item.
   * @param value This value is used in findMatchingListValue method to find out the item in
   * the combobox that represents the given value. If the value is not found, then no item is selected
   * in the list.
   * @param attrIndex This argument is ignored by this method.
   */
   public void setValueAt(Object value, int attrIndex)
   {
      //if (getListOperMode() == LIST_OPER_NAVIGATE) 
      {
         if (attrIndex > 0) 
         {
            //only look up by first attribute.
            return;
         }
      }
      Object val = findMatchingListValue(value);

      try
      {
         mSettingValue = true;
         
         if (mComboModel != null)
         {
            if (val != null) 
            {
               mComboModel.setSelectedItem(val);
               //((JComboBox) getControl()).setSelectedItem(val);
            }
            else
            {
               //if this guy is a row, set nothing as selected.

               //in case value is not in list, reset selection and set the input value into combo editor.

               //also in case of lov if the matching attribute values are of different type, they wont
               //pass the equality test. In that case we should try and display the first Lov attribute value
               //from the target row somehow.
               if (value instanceof Row)
               {
                  ((JComboBox) getControl()).setSelectedItem(null);
               }
               else
               {
                  ((JComboBox) getControl()).setSelectedItem(value);
               }
            }
         }
      }
      finally
      {
         mSettingValue = false;
      }
   }


   /**
   * Should be used by applications to update both the combobox selection and the
   * correpsonding attributes in the current row of the target viewobject.
   * @param value This value is used in findMatchingListValue method to find out the item in
   * the combobox that represents the given value. If the value is not found, then no item is selected
   * in the list.
   * @param attrIndex This argument is ignored by this method.
   */
   public void setDataValueAt(Object value, int attrIndex)
   {
      Object val = findMatchingListValue(value);
      mComboModel.setSelectedItem(val);
   }

   
   /**
   * Sets the item at the given index as current selection in the listbox.
   */
   public void setSelectedIndex(int listIndex)
   {
      super.setSelectedIndex(listIndex);

      if (listIndex >= 0)
      {
         setDataValueAt(getValueFromList(listIndex), 0);
      }
      else
      {
         setDataValueAt(null, 0);
      }
   }

   /**
   * A Helper method that sets the attribute at the index (into the attrNames array
   * as provided in the constructor) with the given value.
   */
   /*
   no need for this overloaded method. the base does the same thing.
   public void setAttribute(int index, Object value)
   {
      synchronized(getIteratorBinding().getSyncLock())
      {
         try
         {
            oracle.jbo.Row row = getCurrentRow();
      
            //row is null to start with for combobox selections.
            if (row != null)
            {
               setAttributeInRow(row, getAttributeDef(index), value);
            }
         }
         catch(Exception ex)
         {
            reportException(ex);
         }
      }
   }
   */


   /**
   * Returns true, so that JTextComponents can participate in a query in the Find Mode of the
   * containing panel. When the containing panel Binding object is set to Find mode, it queries
   * all control-bindings in it and disables those controls whose bindings return false
   * for this method during the Find mode. The return value from this method indicates 
   * whether to consult an attribute definition for queriability.
   * <p>
   * An application could create a subclass of this binding object and return false from this
   * method to prevent the associated control from participating in find mode. Additionally, a
   * BC4J attribute itself can control whether that attribute can participate in Query or
   * not. That property takes precedence over this method's return, if this method returns true.
   * In other words, if this binding is bound to a CLOB attribute type and the attribute
   * definition for that attribute indicates that it is not queriable, then the default behavior
   * of JUPanelBinding in Find mode will be to disable this binding's control, even though
   * this method returns true.
   */
   protected boolean isControlQueriable()
   {
      return true;
   }
   
   /**
   * Based on listOperMode, this binding either navigates the target rowset to the selected
   * row or sets the attribute/attributes as based on the settings in the constructor.
   */
   public void actionPerformed(ActionEvent e) 
   {
      if (!mSettingValue)
      {
         try
         {
            if (getListOperMode() == LIST_OPER_NAVIGATE)
            {
               int selIndex = ((JComboBox) getControl()).getSelectedIndex();
   
               if (selIndex >= 0)
               {
                  RowIterator rsi = getRowIterator();

                  if (rsi != null)
                  {
                     ((JUPanelBinding)getFormBinding()).callBeforeRowNavigated(getIteratorBinding());
                     rsi.setCurrentRowAtRangeIndex(selIndex);
                  }
               }
            }
            else
            {
               updateTargetFromSelectedValue(mComboModel.getSelectedItem());
            }        
         }
         catch(Exception ex)
         {
            reportException(ex, true);
         }
      }
   }


   //
   // MutableComboBoxModel implementation
   //

   public void setSelectedItem(Object anItem)
   {
      mComboModel.setSelectedItem(anItem);
   }


   public Object getSelectedItem()
   {
      return mComboModel.getSelectedItem();
   }

   
   public int getSize()
   {
      return mComboModel.getSize();
   }


   public Object getElementAt(int index)
   {
      return mComboModel.getElementAt(index);
   }
   

   public void addListDataListener(ListDataListener l)
   {
      mComboModel.addListDataListener(l);
      mSettingValue = false;
      //this gets called when combobox is wired up with this model.
   }
   

   public void removeListDataListener(ListDataListener l)
   {
      mComboModel.removeListDataListener(l);
   }


   public void addElement(Object obj)
   {
      if (obj != null)
      {
         mComboModel.addElement(obj);
      }
   }


   public void removeElement(Object obj)
   {
      if (obj != null)
      {
         mComboModel.removeElement(obj);
      }
   }


   public void insertElementAt(Object obj, int index)
   {
      if (obj != null)
      {
         mComboModel.insertElementAt(obj, index);
      }
   }
   

   public void removeElementAt(int index)
   {
      mComboModel.removeElementAt(index);
   }
   

   /**
   * Use this method to bind a combobox control to a ViewObject/RowSet identified by voInstanceName
   * when a static list of values are displayed in the combobox, and the combobox is used to display/update
   * the same attribute in the same viewobject.
   */
   public static MutableComboBoxModel createEnumerationBinding(JUFormBinding    formBinding, 
                                                  JComboBox     control,
                                                  String        voInstanceName,
                                                  String        voIterName, /*temporarily taking nulls for this*/
                                                  String        voIterBindingName,
                                                  String        attrName,
                                                  Object        values[])
   {
      if (!JUIUtil.inDesignTime())
      {
         JUComboBoxBinding bind = new JUComboBoxBinding(control, 
                                       formBinding.getRowIterBinding(voInstanceName, voIterName, voIterBindingName),
                                       new String[] { attrName },
                                       values);
         bind.refreshControl();
         return bind.getModelImpl(null);
      }
      else
      {
         try
         {
            StringBuffer buf = new StringBuffer(voInstanceName).append(".").append(attrName);
            Object [] args = { buf.toString(), values };

            Class clazz = Class.forName("oracle.jbo.dt.ui.jui.propertyeditors.dtmodels.DTJEnumComboBoxBinding");
            java.lang.reflect.Constructor constructor = clazz.getConstructors()[0];
            Object object = constructor.newInstance(args);
            return (MutableComboBoxModel)object;
         }
         catch (Exception e)
         {
            return null;
         }
      }
   }

   /**
   * @deprecated since 9.0.2 use createEnumerationBinding, createNavigationBinding or createLovBinding instead
   */
   public static MutableComboBoxModel getInstance(JUFormBinding    formBinding, 
                                                  JComboBox     control,
                                                  String        voInstanceName,
                                                  String        voIterName, /*temporarily taking nulls for this*/
                                                  String        voIterBindingName,
                                                  String        attrName,
                                                  Object        values[])
   {
      return createEnumerationBinding(formBinding, control, voInstanceName, voIterName, voIterBindingName, attrName, values);
   }

   /**
   * Use this binding when two ViewObjects are to be used in this combobox: one for displaying the list
   * of values and the other ViewObject the rows of which are updated.
   * Optionally, a UI can provide a cell renderer for the list and a editor which can
   * be used to implement ComboBox customization.
   * By default, if this binding method creates an instance of JUMultiAttrListCellRenderer
   * and JUMultiAttrListCellEditor to display and edit LOVs.
   */
   public static MutableComboBoxModel createLovBinding(JUFormBinding    formBinding, 
                                                  JComboBox     control,
                                                  String        voInstanceName,
                                                  String        voIterName, /*temporarily taking nulls for this*/
                                                  String        voIterBindingName,
                                                  String[]      voAttrNames,
                                                  String        lovVOInstanceName,
                                                  String[]      lovVOAttrNames,
                                                  String[]      lovVODisplayedAttrNames,
                                                  ListCellRenderer cellRenderer,
                                                  ComboBoxEditor   editor
                                                  )
   {
      if (!JUIUtil.inDesignTime())
      {
         JUIteratorBinding binding = (voInstanceName != null)
                                   ? formBinding.getRowIterBinding(voInstanceName, voIterName, voIterBindingName)
                                   : null;
         
         JUIteratorBinding listValuesBinding = (lovVOInstanceName != null) ?
                                     formBinding.getRangeIterBinding(lovVOInstanceName, null, null, -1)
                                     : null;
   
         AttributeDef ad;
         ArrayList adList = null;
         int i = 0;
         AttributeDef ads[] = (listValuesBinding != null) 
                               ? listValuesBinding.getViewObject().getAttributeDefs() 
                               : new AttributeDef[0]; 
         int count = ads.length;
         adList = new ArrayList(count);
         
         if (lovVODisplayedAttrNames == null)
         {
            int kind;
            ArrayList al = null;
            al = new ArrayList(count); 
            for (i = 0; i < count; i++)
            {
               ad = ads[i];
               kind = ad.getAttributeKind();
               if (kind == ad.ATTR_ASSOCIATED_ROWITERATOR
                   || kind == ad.ATTR_ASSOCIATED_ROW)
               {
                  continue;
               }
               al.add(ad.getName());
               adList.add(ad);
            }
   
            lovVODisplayedAttrNames = (String[])al.toArray(new String[al.size()]);
         }
         else if (listValuesBinding != null)
         {
            ViewObject vo = listValuesBinding.getViewObject();
            for (i = 0; i < lovVODisplayedAttrNames.length; i++)
            {
               ad = vo.findAttributeDef(lovVODisplayedAttrNames[i]) ;
               if (ad != null)
               {
                  adList.add(ad);
               }
            }
         }
         
         //this executes the inner query which we shouldn't do on init. One should execute this only 
         //when getValueList() is invoked.
         JUComboBoxBinding bind = new JUComboBoxBinding(control, 
                                       binding,
                                       voAttrNames,
                                       listValuesBinding,
                                       lovVOAttrNames, lovVODisplayedAttrNames);
         
         bind.refreshControl();

         if (!bind.isSingleAttrList() && adList.size() > 0)
         {
            if (cellRenderer == null)
            {
               cellRenderer = new JUMultiAttrListCellRenderer((AttributeDef[])adList.toArray(new AttributeDef[adList.size()]));
            }
            if (editor == null) 
            {
               editor = new JUMultiAttrListEditor(bind, ((AttributeDef)adList.get(0)).getIndex());
            }
         }
   
         if (cellRenderer != null)
         {
            control.setRenderer(cellRenderer);
         }
         if (editor != null) 
         {
            control.setEditor(editor);
            //control.setEditable(true);
         }

         if (binding == null && listValuesBinding != null) 
         {
            //if binding is null but LOV is not, we need to register interest
            //in the LOV binding's RSI to get notified when it's data gets populated.
            listValuesBinding.getRowSetIterator().addListener(bind);
         }
   
         return bind.getModelImpl(null);
      }
      else
      {
         try
         {
            Class defClazz = Class.forName("oracle.jbo.dt.ui.jui.propertyeditors.dtmodels.DTJLovBindingDef"); 
            java.lang.reflect.Constructor defConstructor = defClazz.getConstructors()[0];
            Object [] defArgs = { lovVOInstanceName, lovVODisplayedAttrNames, voInstanceName, lovVOAttrNames, voAttrNames };

            Class clazz = Class.forName("oracle.jbo.dt.ui.jui.propertyeditors.dtmodels.DTJComboBoxBinding");
            java.lang.reflect.Constructor constructor = clazz.getConstructors()[0];
            Object [] args = { defConstructor.newInstance(defArgs) };
            Object object = constructor.newInstance(args);
            return (MutableComboBoxModel)object;

         }
         catch (Exception e)
         {
            return null;
         }
      }
   }

   /**
   * Use this binding when the given combobox is used as a navigation control to 
   * iterate through a range or rows in a RowSet.
   * Optionally, a UI can provide a cell renderer for the list and an editor which can
   * be used to implement ComboBox customization.
   * By default, if this binding method creates an instance of JUMultiAttrListCellRenderer
   * and JUMultiAttrListCellEditor to display and edit LOVs.
   */
   public static MutableComboBoxModel createNavigationBinding(JUFormBinding    formBinding, 
                                                  JComboBox     control,
                                                  String        voInstanceName,
                                                  String        voIterName, /*temporarily taking nulls for this*/
                                                  String        voIterBindingName,
                                                  String[]      voAttrNames,
                                                  ListCellRenderer cellRenderer,
                                                  ComboBoxEditor   editor
                                                  )
   {
      if (!JUIUtil.inDesignTime())
      {
         JUIteratorBinding binding = formBinding.getRowIterBinding(voInstanceName, voIterName, voIterBindingName);
         
         //this executes the inner query which we shouldn't do on init. One should execute this only 
         //when getValueList() is invoked.
         JUComboBoxBinding bind = new JUComboBoxBinding(control, 
                                       binding,
                                       voAttrNames, LIST_OPER_NAVIGATE);
         bind.refreshControl();

         if (!bind.isSingleAttrList())
         {
            if (cellRenderer == null)
            {
               cellRenderer = new JUMultiAttrListCellRenderer(bind.getAttributeDefs());
            }
            if (editor == null) 
            {
               editor = new JUMultiAttrListEditor(bind, bind.getAttributeDef(0).getIndex());
            }
         }
   
         if (cellRenderer != null)
         {
            control.setRenderer(cellRenderer);
         }
         if (editor != null) 
         {
            control.setEditor(editor);
            control.setEditable(false);
         }
   
         return bind.getModelImpl(null);
      }
      else
      {
         try
         {
            Class clazz = Class.forName("oracle.jbo.dt.ui.jui.propertyeditors.dtmodels.DTJComboBoxNavigationBinding");
            java.lang.reflect.Constructor constructor = clazz.getConstructors()[0];

            String firstAttribute = "";
            if (voAttrNames != null && voAttrNames.length != 0)
               firstAttribute = voAttrNames[0];
            int size = voAttrNames == null ? 0 : voAttrNames.length;
            StringBuffer stbuf = new StringBuffer(firstAttribute);
            for (int i=1; i<size; i++)
            {
               stbuf.append(",");
               stbuf.append(voAttrNames[i]);
            }

            Object [] args = { voInstanceName + "." + stbuf.toString() };
            Object object = constructor.newInstance(args);
            return (MutableComboBoxModel)object; 
         }
         catch (Exception e)
         {
            return null;
         }
      }
   }




   /**
   * @deprecated since 9.0.2 use createEnumerationBinding, createNavigationBinding or createLovBinding instead
   */
   public static MutableComboBoxModel getInstance(JUFormBinding    formBinding, 
                                                  JComboBox     control,
                                                  String        voInstanceName,
                                                  String        voIterName, /*temporarily taking nulls for this*/
                                                  String        voIterBindingName,
                                                  String[]      voAttrNames,
                                                  String        lovVOInstanceName,
                                                  String[]      lovVOAttrNames,
                                                  String[]      lovVODisplayedAttrNames,
                                                  ListCellRenderer cellRenderer,
                                                  ComboBoxEditor   editor
                                                  )
   {
      return createLovBinding( formBinding, control, voInstanceName, voIterName, voIterBindingName, voAttrNames,
                           lovVOInstanceName, lovVOAttrNames, lovVODisplayedAttrNames, cellRenderer, editor );
   }
}
