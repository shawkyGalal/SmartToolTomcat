/*
 * @(#)JUApplicationDefImpl.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.uicli.mom;

import java.lang.reflect.Constructor;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Properties;
import oracle.jbo.CustomClassNotFoundException;
import oracle.jbo.common.DebugDiagnostic;
import oracle.jbo.mom.ContainerDefImpl;
import oracle.jbo.mom.xml.DefElementImpl;
import oracle.jbo.mom.xml.DefPersistable;
import oracle.jbo.mom.xml.DefPersistenceException;
import oracle.jbo.mom.xml.DefWriter;
import oracle.jbo.mom.xml.JTXMLTags;
import oracle.jbo.mom.xml.XMLOutputStream;
import oracle.jbo.uicli.binding.JUApplication;
import oracle.jbo.uicli.binding.JUUtil;

public class JUApplicationDefImpl extends ContainerDefImpl implements DefPersistable 
{
   private String mRootAMDefName = null;
   private boolean mAsProject = true;
   private String mApplicationClassName = null;
   private String mActualAppDefName = null;
   private ArrayList mSessionDefs = new ArrayList();
   private HashMap   mSessionDefsMap = new HashMap(15);

   
   public static final String PNAME_TYPE_PROJ = "JboProject";
   public static final String PNAME_TYPE_APPLICATION = "JUApplication";
   
   public static final String PNAME_BindingClass = "BindingClass";
   public static final String PNAME_RootAMDefName = "RootAMDefName";
   public static final String PNAME_CliApplication = "CliApplication";
   
   private String mIanaEncoding = null;
   private String mJdkEncoding = null;

   public JUApplicationDefImpl(String name)
   {
      super(JUMetaObjectManager.getJUMom());
      setName(name);

      mApplicationClassName = JUApplication.class.getName();
   }
   

   public JUApplicationDefImpl()
   {
      super(JUMetaObjectManager.getJUMom());

      mApplicationClassName = JUApplication.class.getName();
   }
   

   static public JUApplicationDefImpl findDefObjectNoSub(String name)
   {
      return (JUApplicationDefImpl) JUMetaObjectManager.getJUMom().findDefinitionObject(name,
                                           JUMetaObjectBase.TYP_DEF_APPLICATION,
                                           JUApplicationDefImpl.class,
                                           false /*sub*/);
   }


   static public JUApplicationDefImpl findDefObject(String name)
   {
      return (JUApplicationDefImpl) JUMetaObjectManager.getJUMom().findDefinitionObject(name,
                                           JUMetaObjectBase.TYP_DEF_APPLICATION,
                                           JUApplicationDefImpl.class,
                                           true /*sub*/);
   }


   protected com.sun.java.util.collections.ArrayList getContainerDefNames(boolean recursive)
   {
      return new com.sun.java.util.collections.ArrayList(1);
   }

   
   public String getRootAMDefName()
   {
      return mRootAMDefName;
   }
   
   
   public void setRootAMDefName(String rootAMDefName)
   {
      mRootAMDefName = rootAMDefName;
   }
   
   
   public String getApplicationClassName()
   {
      return mApplicationClassName;
   }
   
   
   public void setApplicationClassName(String applicationClassName)
   {
      mApplicationClassName = applicationClassName;
   }
   
   
   /**
    * Name this object.
    * @param name  the name to be given to this object.
    **/

   public void setName(String name)
   {
      // sim 4/19/01 -- setName is declared here to be public
      super.setName(name);
   }

   
   public boolean getAsProject()
   {
      return mAsProject;
   }

   
   public void setAsProject(boolean asProject)
   {
      mAsProject = asProject;
   }
   
   
   public ArrayList getSessionDefNames()
   {
      int count = mSessionDefs.size();
      ArrayList retAl = new ArrayList(count);
      for (int i = 0; i < count; i++)
      {
         retAl.add(((JUSessionDefImpl)mSessionDefs.get(i)).getName());
      }
      return retAl;
   }

   
   public void loadPackages()
   {
      com.sun.java.util.collections.ArrayList al = new com.sun.java.util.collections.ArrayList(5);
      
      getChildObjectNames(false /*recursive*/, JTXMLTags.PACKAGE, al);

      for (int j = 0; j < al.size(); j++)
      {
         String packageName = (String) al.get(j);

         JUMetaObjectManager.getJUMom().findPackage(packageName);
      }
   }
   
   
   protected void loadContainees(DefElementImpl xmlElement, boolean sepXMLFiles)
   {
      boolean juiProject = xmlElement.readBoolean("JUIProject");

      if (juiProject)
      {
         loadContainees(xmlElement);
      }
      else
      {
         loadSessions(xmlElement);
      }
   }
   

   protected ContainerDefImpl createContainerType(String typeName)
   {
      return null;
   }

   
   public JUApplication createRootApplication(Hashtable context, String name, Object userData,
                                              String dbConnectionURL, Properties dbConnectionProps)
   {
      if (mActualAppDefName != null)
      {
         JUApplicationDefImpl appDefImpl = findDefObject(mActualAppDefName);

         setRootAMDefName(appDefImpl.getRootAMDefName());
         setApplicationClassName(appDefImpl.getApplicationClassName());

         mActualAppDefName = null;
      }

      Class cls = JUUtil.findClass(mApplicationClassName);
      JUApplication app;

      try
      {
         Constructor cons = cls.getConstructor(new Class[] { Hashtable.class, String.class, Object.class });
      
         app = (JUApplication) cons.newInstance(new Object[] { context, mRootAMDefName, userData });
      }
      catch(Exception e)
      {
         throw new CustomClassNotFoundException(mApplicationClassName, e);
      }
      
      app.setConnectionInfo(dbConnectionURL, dbConnectionProps);
      app.setDef(this);

      if (name == null)
      {
         name = getName();
      }
      
      app.setName(name);
      app.initialize();

      return app;
   }

   
   static public JUApplicationDefImpl createAndLoadFromXML(DefElementImpl xmlElement)
   {
/**********
      String defClassName = xmlElement.readString(PNAME_DefClass);

      if (JUUtil.isEmptyString(defClassName))
      {
         throw new JboException("Definition class name missing in XML");
      }
**********/

      JUApplicationDefImpl defObj = new JUApplicationDefImpl();
      
      if (defObj != null)
      {
         defObj.loadFromXMLFile(xmlElement);
      }

      return defObj;
   }

   
   protected void loadChildrenFromXML(DefElementImpl xmlElement)
   {
   }

   
   protected void loadFromXMLFile(DefElementImpl xmlElement) 
   {
      super.loadFromXMLFile(xmlElement);
      
      String strVal;
      
      mAsProject = (xmlElement.getTagName().equals(PNAME_TYPE_PROJ));
      mRootAMDefName = xmlElement.readString(PNAME_RootAMDefName);
      strVal = xmlElement.readString(PNAME_BindingClass);

      if (strVal != null)
      {
         mApplicationClassName = strVal;
      }
      
      mActualAppDefName = xmlElement.readString(PNAME_CliApplication);

      loadChildrenFromXML(xmlElement);
   }

   
   private void loadSessions(DefElementImpl xmlElement)
   {
      DebugDiagnostic.println("Loading JUSessions for JUApplication '" + getFullName() + "'.");

      com.sun.java.util.collections.ArrayList children = xmlElement.getChildrenList(JUTags.Session);
      if ( (children != null) && (children.size() > 0) )
      {
         JUSessionDefImpl eInfo = null;
         String myFullName = getFullName();
         for ( int i=0; i < children.size(); i++ )
         {
            DefElementImpl elem = (DefElementImpl)children.get(i);
            eInfo = JUSessionDefImpl.loadFromXML(elem, myFullName);
            
            mSessionDefs.add(eInfo);
            mSessionDefsMap.put(eInfo.getName(), eInfo);

            DebugDiagnostic.println("Successfully loaded JUSession '" + eInfo.getFullName() + "'.");
         }
      }
   }

   
   public JUSessionDefImpl findSession(String name)
   {
      return (JUSessionDefImpl)mSessionDefsMap.get(name);
   }

   
   public void removeSession(String name)
   {
      Object obj = mSessionDefsMap.get(name);
      if (obj != null) 
      {
         mSessionDefs.remove(obj);
         mSessionDefsMap.remove(name);
      }
   }

   
   public void addSession(String name)
   {
      JUSessionDefImpl def = new JUSessionDefImpl(name);
      
      //how about package/configuration.
      def.setFullName(new StringBuffer(getFullName()).append(".").append(name).toString());

      if (mSessionDefsMap.get(name) != null) 
      {
         throw new oracle.jbo.NameClashException(JUTags.Session, name);
      }
      mSessionDefs.add(def);
      mSessionDefsMap.put(name, def);
   }

  

   boolean mDirty = false;
   boolean mIsNew = false;

   
   /**
    * This method returns if an Object is modified from last save/load
    * @return Returns true if the Object is dirty. Returns false otherwise.
    **/
   public boolean isDirty()
   {
      return mDirty;
   }

   
   /**
    * This method marks the Object dirty
    * @param isDirty If true the Object is marked Dirty.
    **/
   public void setDirty(boolean isDirty)
   {
      mDirty = true;
   }

   
   /**
    * This method returns if this object is previously persisted.
    * @return true if the Object is previously persisted. Returns false otherwise.
    **/
   public boolean isNew()
   {
      return mIsNew;
   }

   
   /**
    * This method marks the as previously persisted. By default all objects
    * are new objects. When the object is persisted first time, that object is
    * marked as 'not new' object
    * @param isNew If true the Object is marked as new object.
    **/
   public void setNew(boolean isNew)
   {
      mIsNew = isNew;
   }


   /**
    * Objects should write their persistence output in this method
    * @param jos the Output storage for persistence
    **/
   public void writeObject(DefWriter jos) throws DefPersistenceException
   {
      jos.writeObject(this);
   }

   
   /**
    * Objects should write their persistence output in this method
    * @param jos the Output storage for persistence
    * @DefPersistable parent Parent Object that's calling the writeChildren
    * @return Number of Contents returned
    * @Exception Error in writing the Object's contents to Persistent Storage
    **/
   public void writeContents(DefWriter jos) throws DefPersistenceException
   {
      if (getAsProject())
      {
         jos.writeBoolean("SeparateXMLFiles", false);
         jos.writeString(JUTags.Package, "");
      }

      if (mRootAMDefName != null)
      {
         jos.writeString(PNAME_RootAMDefName, mRootAMDefName);
      }
   }

   
   /**
    * Writes the Object's children to the Persistent storage
    * @param jos the Output storage for persistence
    * @Exception Error in writing the Object's Children to the storage
    **/
   public void writeChildren(DefWriter jos) throws DefPersistenceException
   {
      for (int i = 0; i < mSessionDefs.size(); i++) 
      {
         ((JUSessionDefImpl)mSessionDefs.get(i)).writeObject(jos);
      }
   }


   /**
    * Returns a piece of static info for the type of object this is invoked
    * upon.  Examples are PreparedStatements for insert, update, delete,
    * and String containing a base the select statement for retrieving
    * instances of this type through the SQLInputStream
    * @param type Type of the Persistence Statement requested. The type
    *             can be any of the Statement types defined in this interface.
    * @return returns the Statement required to store in Persitent Storage.
    *         Incase of XML, it just returns the String. In the case of SQL
    *         a JDBC PreparedStatement is returned.
    **/
   public String getXMLElementTag()
   {
      if (getAsProject())
      {
         return PNAME_TYPE_PROJ; //JUTags.Project;
      }
      else
      {
         return PNAME_TYPE_APPLICATION;
      }
   }

   public String getIanaEncoding()
   {
       return mIanaEncoding;
   }

   public void setIanaEncoding(String iana)
   {
      mIanaEncoding = iana;
   }

   public String getJdkEncoding()
   {
       return mJdkEncoding;
   }

   public void setJdkEncoding(String jdkEnc)
   {
      mJdkEncoding = jdkEnc;
   }

   public void writeToXMLFile(java.io.OutputStream os) throws Exception
   {
      {
         XMLOutputStream xmlOut = new XMLOutputStream(JUMetaObjectManager.getJUMom());
         
         if (mIanaEncoding != null)
            xmlOut.setIanaEncoding(mIanaEncoding);
         if (mJdkEncoding != null)
            xmlOut.setJdkEncoding(mJdkEncoding);

         // BEGIN - Save Directly to Screen Buffer - BEGIN
         xmlOut.openConnection(getXMLElementTag());
         xmlOut.writeComment("BC4J Client Data Model");
         xmlOut.writeObject(this);

         try
         {
            xmlOut.saveToOutputStream(os);
            os.flush();
         }
         finally
         {
            os.close();  // Jdeveloper Expects us to close this outputStream
         }
         // END - Save Directly to Screen Buffer - END

         //setXMLDirty(false);
      }
   }

}
