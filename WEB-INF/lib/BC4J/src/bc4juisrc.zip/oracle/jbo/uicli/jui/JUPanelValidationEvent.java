/*
 * @(#)JUPanelValidationEvent.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.uicli.jui;

import oracle.jbo.Row;
import oracle.jbo.RowIterator;
import oracle.jbo.Transaction;
import oracle.jbo.uicli.binding.JUControlBinding;
import oracle.jbo.uicli.binding.JUFormBinding;
import oracle.jbo.uicli.binding.JUIteratorBinding;

/**
 * Implements EventObject that is passed to the JUPanelValidationListeners
 * in the various event methods. This class provides access to the current iterator binding,
 * panel binding, current row, attribute being edited, and its new value, etc as the
 * case may be for a particular event method.
 */
public class JUPanelValidationEvent extends java.util.EventObject
{
   JUFormBinding mPanelBinding;
   JUIteratorBinding mIter;
   Row         mRow;
   String      mAttrName;
   Object      mNewValue;
   Transaction mTxn;

   public JUPanelValidationEvent(JUControlBinding source,
                                 JUFormBinding panel,
                                 JUIteratorBinding iterBinding,
                                 Row         row,
                                 String      attrName,
                                 Object      value)
   {
      super(source);
      mPanelBinding = panel;
      mIter = iterBinding;
      mRow  = row;
      mAttrName = attrName;
      mNewValue = value;
   }

   public JUPanelValidationEvent(JUFormBinding source,
                                 JUIteratorBinding iterBinding,
                                 Row         row)
   {
      super(source);
      mPanelBinding = source;
      mIter = iterBinding;
      mRow  = row;
   }

   public JUPanelValidationEvent(JUFormBinding source, Transaction txn)
   {
      super(source.getApplication());
      mPanelBinding = source;
      mTxn = txn;
   }

   public final JUIteratorBinding getIteratorBinding()
   {
      return mIter;
   }

   public final RowIterator getRowIterator()
   {
      return (mIter != null) ? mIter.getNavigatableRowIterator() : null;
   }

   public final Row getRow()
   {
      return mRow;
   }

   public final String getAttributeName()
   {
      return mAttrName;
   }

   public final Object getNewValue()
   {
      return mNewValue;
   }

   public final Transaction getTransaction()
   {
      if (mTxn == null) 
      {
         if (mPanelBinding != null) 
         {
            mTxn = mPanelBinding.getApplication().getApplicationModule().getTransaction();
         }
      }
      return mTxn;
   }

   public final JUPanelBinding getPanelBinding()
   {
      return (mPanelBinding instanceof JUPanelBinding) ? (JUPanelBinding)mPanelBinding : null;
   }

   public final boolean isFindMode()
   {
      return mPanelBinding.isFindMode();
   }
}
