/*
 * @(#)JUMetaObjectBase.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.uicli.mom;

/**
 * <b>Internal:</b> <em>Applications should not use this class.</em>
 * <p>
 */
public interface JUMetaObjectBase
{
   public static final int TYP_DEF_APPLICATION = 501;
   public static final int TYP_DEF_SESSION = 502;
   public static final int TYP_DEF_FORM_BINDING = 511;
   public static final int TYP_DEF_ITER_BINDING = 512;
   public static final int TYP_DEF_CONTROL_BINDING = 513;

   public static final int TYP_APPLICATION = 601;
   public static final int TYP_SESSION = 602;
   public static final int TYP_FORM_BINDING = 611;
   public static final int TYP_ITER_BINDING = 612;
   public static final int TYP_CONTROL_BINDING = 613;
}
