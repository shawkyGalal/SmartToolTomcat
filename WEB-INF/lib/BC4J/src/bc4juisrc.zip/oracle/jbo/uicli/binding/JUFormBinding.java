/*
 * @(#)JUFormBinding.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.uicli.binding;

import java.util.ArrayList;
import java.util.HashMap;
import oracle.jbo.ApplicationModule;
import oracle.jbo.AttributeDef;
import oracle.jbo.AttributeHints;
import oracle.jbo.InvalidObjNameException;
import oracle.jbo.InvalidOperException;
import oracle.jbo.JboException;
import oracle.jbo.LocaleContext;
import oracle.jbo.NameClashException;
import oracle.jbo.Row;
import oracle.jbo.RowSetIterator;
import oracle.jbo.RangeRefreshEvent;
import oracle.jbo.ScrollEvent;
import oracle.jbo.InsertEvent;
import oracle.jbo.DeleteEvent;
import oracle.jbo.UpdateEvent;
import oracle.jbo.NavigationEvent;
import oracle.jbo.ViewObject;
import oracle.jbo.common.JboNameUtil;
import oracle.jbo.uicli.UIMessageBundle;
import oracle.jbo.uicli.jui.JUIUtil;
import oracle.jbo.uicli.mom.JUMetaObjectBase;

/**
 *
 * Corresponds to a Swing JFrame instance and manages bindings used in a 
 * frame. The JUFormBinding class provides:
 * <ul>
 * <li>Management of iterator binding instances. 
 * <li>Management of control bindings for declarative forms (**for internal framework use only**).
 * <li>Manages the findMode status and switches the iterator bindings into approrpriate mode.
 * <li>Helper methods for displaying messages in status bar.
 * <li>Helper methods for retrieving UIHints from BC4J ViewObject and attribute definitions.
 * </ul>
 * <p>
 * In the JClient Framework, JUPanelBinding extends this class and provides a home
 * to various iterator bindings and control bindings.
 * @see oracle.jbo.uicli.jui.JUPanelBinding
 */
abstract public class JUFormBinding
{
   private String mName;
   protected ApplicationModule mAM;
   protected JUApplication mApplication;
   private JUFormDef mFormDef;
   private Object mPanel;
   private HashMap mIterBindings = new HashMap(2);
   private ArrayList mIterBindingList = new ArrayList(2);
   private HashMap mControls = new HashMap(2);
   private ArrayList mControlList = new ArrayList(10);
   boolean mFindMode = false;
   private LocaleContext mLocaleContext;
   boolean mExecuteOnRollback = true;

   static private int mCtrlIdCounter = 0;
   

   /**
   * Default constrcutor.
   */
   protected JUFormBinding()
   {
   }


   /**
   * Constructor used by JUPanelBinding, which passes in a reference to the JPanel object.
   */
   protected JUFormBinding(Object panel)
   {
      // minimalize the impact of the design time panel binding definition
      if (panel != null)
      {
         setPanel(panel);
      }
   }


   /**
   * *** For internal framework use only ***
   */
   abstract public void initializePanel(ArrayList controls);

   /**
   * *** For internal framework use only ***
   * Used to setup reference to JUApplication and oracle.jbo.Application objects.
   */
   abstract protected void initializeApplicationModule();

   /**
   * If JUApplication is setup, then invoke JUApplication.reportException
   * to report any exceptions. Otherwise, throw a JboException (wrapping
   * non-JboExceptions if required)
   */
   public void reportException(Exception ex)
   {
      JUApplication app = getApplication();

      if (app != null)
      {
         app.reportException(this, ex);
      }
      else
      {
         if (ex instanceof JboException)
         {
            throw (JboException) ex;
         }
         else
         {
            throw new JboException(ex);
         }
      }
   }

   
   /**
   * Returns the JUApplciation object to which this form binding belongs.
   */
   public JUApplication getApplication()
   {
      if (mApplication == null && !JUIUtil.inDesignTime())
      {
         initializeApplicationModule();
      }
      return mApplication;
   }

   
   /**
   * Sets the JUApplication instance in this form binding and adds it to the
   * JUApplication. If this form binding is already registered with a JUApplication,
   * then it throws an InvalidOperException.
   * @throws InvalidOperException
   */
   public void setApplication(JUApplication app)
   {
      if (mApplication != null)
      {
         throw new InvalidOperException(UIMessageBundle.class,
                                        UIMessageBundle.EXC_APP_ALREADY_SET_FOR_FORM_BND,
                                        new Object[] { getName() } );
      }

      if (app != null)
      {
         app.addFormBinding(this);
      }
   }


   final void assignApplication(JUApplication app)
   {
      mApplication = app;
   }

   
   /**
   * Returns the instance name of this JUFormBinding object.
   */
   public final String getName()
   {
      return mName;
   }


   /**
   * *** For internal framework use only ***
   * <p>
   * Sets the instance name of this JUFormBinding object.
   */
   public final void setName(String name)
   {
      mName = name;
   }

   
   /**
   * *** For internal framework use only ***
   */
   public final JUFormDef getDef()
   {
      return mFormDef;
   }

   
   /**
   * *** For internal framework use only ***
   */
   final void setDef(JUFormDef formDef)
   {
      mFormDef = formDef;
   }

   
   /**
   * *** For internal framework use only ***
   */
   public void initializeFromDef(ApplicationModule am)
   {
      mFormDef.initializeFormBinding(this, am);
   }

   
   /**
   * *** For internal framework use only ***
   */
   public void initializeFromDef(RowSetIterator[] rsis)
   {
      mFormDef.initializeFormBinding(this, rsis);
   }

   
   /**
   * Returns the associated JPanel object.
   */
   public final Object getPanel()
   {
      return mPanel;
   }

   /**
   * Associates this form binding object with a JPanel object.
   */
   public abstract void setPanel(Object panel);

   /**
   * Sets internal member variable with the given panel instance.
   */
   protected void setPanelInternal(Object panel)
   {
      mPanel = panel;
   }

   
   /**
   * Return oracle.jbo.ApplicationModule instance which provides the BC4J context to
   * this form binding object.
   */
   public final ApplicationModule getApplicationModule()
   {
      if (mAM == null) 
      {
         initializeApplicationModule();
      }
      return mAM;
   }

   
   /**
   * *** For internal framework use only ***
   * 
   * Sets the ApplicationModule reference
   */
   public void setApplicationModule(ApplicationModule am)
   {
      mAM = am;
   }

   
   /**
   * Return the hashmap containing iterator bindings.
   */
   public final HashMap getIterBindings()
   {
      return mIterBindings;
   }


   /**
   * Return an ordered set of iterator bindings.
   */
   public final ArrayList getIterBindingList()
   {
      return mIterBindingList;
   }

   
   /**
   * Returns the iterator binding object of the given name.
   */
   public final JUIteratorBinding findIterBinding(String name)
   {
      return (JUIteratorBinding) mIterBindings.get(name);
   }

   
   /**
   * Adds the given iterator binding name with a framework generated name.
   */
   public final void addIterBinding(JUIteratorBinding iterBinding)
   {
      addIterBinding(null, iterBinding);
   }


   /**
   * Adds this iterator binding with this form with the given name.
   * @throws InvalidObjNameException if an invalid name is passed in.
   * @throws NameClashException if given a duplicate name.
   */
   public final void addIterBinding(String name, JUIteratorBinding iterBinding)
   {
      boolean genIterName = (name == null);

      while (true)
      {
         if (genIterName)
         {
            name = JUUtil.generateIteratorName(iterBinding);
         }
         else  if (!JboNameUtil.isNameValid(name))
         {
            throw new InvalidObjNameException(JUMetaObjectBase.TYP_ITER_BINDING,
                                              name);
         }

         if (mIterBindings.get(name) != null)
         {
            if (!genIterName)
            {
               throw new NameClashException(JUMetaObjectBase.TYP_ITER_BINDING,
                                            name);
            }
         }
         else
         {
            break;
         }
      }

      iterBinding.setName(name);
      iterBinding.setFormBinding(this);
      
      mIterBindingList.add(iterBinding);
      mIterBindings.put(name, iterBinding);
   }


   /**
   * If an iterator binding exists with the given name, remove it from the internal
   * members.
   */
   public final boolean removeIterBinding(String name)
   {
      boolean retVal = false;
      JUIteratorBinding bnd = (JUIteratorBinding) mIterBindings.get(name);
      
      if (bnd != null)
      {
         retVal = mIterBindingList.remove(bnd);
         mIterBindings.remove(name);
      }

      return retVal;
   }


   /**
   * Clean all iterator bindings registered with this form.
   */
   public final void clearIterBindings()
   {
      mIterBindingList.clear();
      mIterBindings.clear();
   }


   /**
   * *** For internal framework use only ***
   */
   public final void addControlBinding(JUControlBinding control)
   {
      String name = control.getName();

      if (name != null && !JboNameUtil.isNameValid(name))
      {
         throw new InvalidObjNameException(JUMetaObjectBase.TYP_CONTROL_BINDING,
                                           name);
      }

      if (mControls.get(name) != null)
      {
         throw new NameClashException(JUMetaObjectBase.TYP_CONTROL_BINDING,
                                      name);
      }

      if (!mControlList.contains(control))
      {
         mControlList.add(control);
      }

      if (name != null)
      {
         mControls.put(name, control);
      }
   }


   /**
   * *** For internal framework use only ***
   */
   public final void addControlBinding(String name, JUControlBinding control)
   {
      // control.setName() calls addControlBinding(JUControlBinding).
      control.setName(name);
   }

   
   public final ArrayList getControlBindingList()
   {
      return (ArrayList)mControlList.clone();
   }

   
   /**
   * *** For internal framework use only ***
   */
   public final JUControlBinding getControlBinding(int index)
   {
      return (JUControlBinding) mControlList.get(index);
   }


   /**
   * *** For internal framework use only ***
   */
   public final JUControlBinding findControlBinding(String name)
   {
      return (JUControlBinding) mControls.get(name);
   }
   
   public final JUControlBinding getControlBinding(Object control)
   {
      int size = mControlList.size();
      Object bind;
      for (int i = 0; i < size; i++) 
      {
         bind = mControlList.get(i);
         if (bind instanceof JUControlBinding) 
         {
            if (((JUControlBinding)bind).getControl() == control)
            {
               return ((JUControlBinding)bind);
            }
         }
      }
      return null;
   }


   
   /**
   * *** For internal framework use only ***
   */
   public final boolean removeControlBinding(JUControlBinding control)
   {
      String ctrlName = control.getName();

      mControls.remove(ctrlName);

      return mControlList.remove(control);
   }


   /**
   * *** For internal framework use only ***
   */
   public final boolean removeControlBinding(String name)
   {
      boolean retVal = false;
      JUControlBinding bnd = (JUControlBinding) mControls.get(name);
      
      if (bnd != null)
      {
         mControls.remove(name);

         retVal = mControlList.remove(bnd);
      }

      return retVal;
   }


   /**
   * Execute the query behind each iterator binding that is contained in this form binding.
   * Applications could invoke this method to re-execute all the ViewObjects associated with
   * this form.
   */
   public void execute()
   {
      ArrayList al = (ArrayList)mIterBindingList.clone();
      for (int j = 0; j < al.size(); j++)
      {
         JUIteratorBinding iterBnd = (JUIteratorBinding) al.get(j);
         
         iterBnd.executeQuery();
      }
   }

   
   /**
   * Excecute the query for each iterator binding, if not already executed.
   * Applications should invoke this method to verify and execute all the ViewObjects
   * associated with this form. This method is used by the generated applications
   * by default.
   */
   public void executeIfNeeded()
   {
      for (int j = 0; j < mIterBindingList.size(); j++)
      {
         JUIteratorBinding iterBnd = (JUIteratorBinding) mIterBindingList.get(j);
         
         iterBnd.executeQueryIfNeeded();
      }
   }

   /**
   * Return an Iterator Binding of the given "voIterBindingName" if one already exists by that name.
   * If not, create an IteratorBinding object that references a default iterator of the ViewObject
   * instance named voInstanceName (and optionally the iterator named voIterName). Return this created
   * iterator binding after adding it to internal lists.
   * <p>
   * Various control bindings that display just one row's attribute invoke this method to find
   * or create the iterator binding for which they display an attribute data.
   */
   public JUIteratorBinding getRowIterBinding(String        voInstanceName,
                                             String        voIterName, /**temporarily taking nulls for this*/
                                             String        voIterBindingName)
   {
      JUIteratorBinding rowBnd = findIterBinding(voIterBindingName);

      if (rowBnd == null) 
      {
         rowBnd =  new JUIteratorBinding(getApplicationModule(),
                                        voInstanceName,
                                        voIterName);
         addIterBinding(voIterBindingName, rowBnd);
      }
      
      return (JUIteratorBinding) rowBnd;
   }

   /**
   * Return an Iterator Binding of the given "voIterBindingName", if one already exists by that name,
   * after setting up the iterator binding's range Size to the greater of existing range size and
   * the given range size. If range size is -1, that indicates all rows in the range and hence
   * takes precedence in the above comparison.
   * <p>
   * If not, create an IteratorBinding object that references a default iterator of the ViewObject
   * instance named voInstanceName (and optionally the iterator named voIterName). Return this created
   * iterator binding after adding it to internal lists.
   * <p>
   * Various control bindings that are capable of displaying more than one row of data invoke this
   * method to create their iterator binding with a preferred range size.
   */
   public JUIteratorBinding getRangeIterBinding(String       voInstanceName,
                                                 String       voIterName, /**temporarily taking nulls for this*/
                                                 String       voIterBindingName, 
                                                 int          rangeSize)
   {
      JUIteratorBinding bnd = findIterBinding(voIterBindingName);

      if (bnd == null) 
      {
         bnd =  new JUIteratorBinding(getApplicationModule(),
                                       voInstanceName,
                                       voIterName, rangeSize);
         addIterBinding(voIterBindingName, bnd);
      }
      else
      {
         //validate that the rangeSize passed in is greater than 1.
         bnd.resolveRangeSize(rangeSize);
      }
      
      return (JUIteratorBinding) bnd;
   }

   /**
   * Sets this form into findMode. All iterator bindings with this form are set to find mode.
   * Also, notify each iteratorChanged listener registered with this form of the change
   * in the iterator (due to change in mode so that they update the displays with 
   * the find or data mode's data).
   */
   public void setFindMode(boolean mode)
   {
      if (mode != mFindMode) 
      {
         mFindMode = mode;
         for (int j = 0; j < mIterBindingList.size(); j++)
         {
            JUIteratorBinding iterBnd = (JUIteratorBinding) mIterBindingList.get(j);
            iterBnd.setFindMode(mode);
            notifyIteratorChanged(iterBnd, !mode); //do not refresh incase of changing back to data mode.
         }
      }
   }

   /**
   * Returns true if this form is in find mode.
   */
   public boolean isFindMode()
   {
      return mFindMode;
   }

   /**
   * Invoked by the framework to notify various status bars of which control has gained the focus.
   */
   protected abstract void focusGained(JUIteratorBinding iterBinding, JUControlBinding binding, int attrIndex) ;

   /**
   * Notify each listener of the iteratorChanged event when an iterator changes its data due to execute, 
   * re-execute, or change in display mode (find mode or data mode).
   */
   protected abstract void notifyIteratorChanged(JUIteratorBinding iterBnd, boolean refresh);

   /**
   * Helper method to add the given object to the JUApplication's StatusBars.
   */
   public void addStatusBarInterface(JUStatusBarInterface statusBar)
   {
      if (getApplication() != null) 
      {
         mApplication.addStatusBarInterface(statusBar);
      }
   }

   /**
   * Helper method to remove the given object to the JUApplication's StatusBars.
   */
   public void removeStatusBarInterface(JUStatusBarInterface statusBar)
   {
      if (mApplication != null) 
      {
         mApplication.removeStatusBarInterface(statusBar);
      }
   }

   /**
   * Helper method to display the given message and params via the JUApplication's displayStatus method.
   * This method becomes a no-op if this form is not registered with a JUApplication
   */
   public void displayStatus(JUIteratorBinding iterBinding, String msgId, Object[] params)
   {
      if (mApplication != null) 
      {
         mApplication.displayStatus(iterBinding, msgId, params);
      }
   }

   /**
   * Helper method to display the given message string via the JUApplication's displayStatus method.
   * This method becomes a no-op if this form is not registered with a JUApplication
   */
   public void displayStatus(String msg)
   {
      if (mApplication != null) 
      {
         mApplication.displayStatus(msg);
      }
   }

   /**
    * Invoked when a JUIteratorBinding receives a rangeRefreshed Event from BC4J RowSetIterator
    * @param JUIteratorBinding that received the rangeRefreshed event.
    * @param event a description of the new ranges.
    */
   abstract protected void rangeRefreshed(JUIteratorBinding iter, RangeRefreshEvent event);

   /**
    * Invoked when a JUIteratorBinding receives a rangeScrolled Event from BC4J RowSetIterator
    * @param JUIteratorBinding that received the rangeScrolled event.
    * @param event a description of the new range.
    */
   abstract protected void rangeScrolled(JUIteratorBinding iter, ScrollEvent event);

   /**
    * Invoked when a JUIteratorBinding receives a rowInserted Event from BC4J RowSetIterator
    * @param JUIteratorBinding that received the rowInserted event.
    * @param event a description of the new Row object.
    */
   abstract protected void rowInserted(JUIteratorBinding iter, InsertEvent event);

   /**
    * Invoked when a JUIteratorBinding receives a rowDeleted Event from BC4J RowSetIterator
    * @param JUIteratorBinding that received the rowDeleted event.
    * @param event a description of the deleted Row object.
    */
   abstract protected void rowDeleted(JUIteratorBinding iter, DeleteEvent event);

   /**
    * Invoked when a JUIteratorBinding receives a rowUpdated Event from BC4J RowSetIterator
    * @param JUIteratorBinding that received the rowUpdated event.
    * @param event a description of the modified Row object.
    */
   abstract protected void rowUpdated(JUIteratorBinding iter, UpdateEvent event);

   /**
    * Invoked when a JUIteratorBinding receives a navigated Event from BC4J RowSetIterator
    * @param JUIteratorBinding that received the navigated event.
    * @param event a description of the new and previous current rows.
    */
   abstract protected void navigated(JUIteratorBinding iter, NavigationEvent event);


   /**
   * Invoked before any control binding performs a setAttribute call on a BC4J row.
   * This is used by JUPanelBinding to generate validation events to validate attribute values
   * before they are set.
   */
   abstract protected void callBeforeSetAttribute(JUControlBinding ctrl,
                                     Row row,
                                     AttributeDef ad,
                                     Object value);

   /**
   * Invoked before any iterator binding performs a navigation call on a BC4J iterator.
   * This is used by JUPanelBinding to generate validation events to validate the current row of
   * data before allowing navigation.
   */
   abstract protected void callBeforeRowNavigated(JUIteratorBinding iter);
   
   /**
   * Invoked before the ensuing transaction's commit method is invoked by the framework.
   * This is used by JUPanelBinding to generate validation events to validate all changes
   * before they are finally committed to the database.
   */
   abstract protected void callBeforeSaveTransaction(oracle.jbo.Transaction txn);

   //UI Hint support methods.

   AttributeHints getAttributeUIHelper(String voName, String attrName)
   {
      return getApplicationModule().findViewObject(voName).findAttributeDef(attrName).getUIHelper();
   }

   /***
   ** Retrieves the label to be used in any attribute prompts
   **/
   public String getLabel(String voName, String attrName, LocaleContext locale)
   {
      return getAttributeUIHelper(voName, attrName).getLabel((locale == null) ? getLocaleContext() : locale);
   }

   /***
   **  Retrives the tooltip text to be used for this attribute.
   **/
   public String getTooltip(String voName, String attrName, LocaleContext locale)
   {
      return getAttributeUIHelper(voName, attrName).getTooltip((locale == null) ? getLocaleContext() : locale);
   }

   /***
   **  Retrieves the display hint that dictates whether this
   **  attribute should be visible or not. The two possible values
   **  are:
   **  <ul>
   **  <li>ATTRIBUTE_DISPLAY_HINT_DISPLAY  = "Display";
   **  <li>ATTRIBUTE_DISPLAY_HINT_HIDE     = "Hide";
   **  </ul>
   **/
   public String getDisplayHint(String voName, String attrName, LocaleContext locale)
   {
      return getAttributeUIHelper(voName, attrName).getDisplayHint((locale == null) ? getLocaleContext() : locale);
   }

   /***
   **    Returns the preferred control type for this attribute.
   **/
   public int getControlType(String voName, String attrName, LocaleContext locale)
   {
      return getAttributeUIHelper(voName, attrName).getControlType((locale == null) ? getLocaleContext() : locale);
   }

   /**
   **    Returns the display width for this attribute.
   **/
   public int getDisplayWidth(String voName, String attrName, LocaleContext locale)
   {
      return getAttributeUIHelper(voName, attrName).getDisplayWidth((locale == null) ? getLocaleContext() : locale);
   }

   /**
   **    Returns the display width for this attribute.
   **/
   public int getDisplayHeight(String voName, String attrName, LocaleContext locale)
   {
      return getAttributeUIHelper(voName, attrName).getDisplayHeight((locale == null) ? getLocaleContext() : locale);
   }

  /**
   ** Returns the hint value based on the hint name.
   **/

   public String getHint(String voName, String attrName, LocaleContext locale, String sHintName)
   {
      return getAttributeUIHelper(voName, attrName).getHint((locale == null) ? getLocaleContext() : locale, sHintName);
   }

   /**
    **   Returns true if any format hints have been defined for this
    **   attribute. This function should be used to bracket any calls
    **   to the formatting API.
    **/
   public boolean hasFormatInformation(String voName, String attrName, LocaleContext locale)
   {
      return getAttributeUIHelper(voName, attrName).hasFormatInformation((locale == null) ? getLocaleContext() : locale);
   }
   
   /**
    **   Returns true if the attribute is to displayed in the short(summary) form.
    **/
   public boolean displayInShortForm(String voName, String attrName, LocaleContext locale)
   {
      return getAttributeUIHelper(voName, attrName).displayInShortForm((locale == null) ? getLocaleContext() : locale);
   }

   //Overridden Control Hint methods to get Object Attribute hints as well.

   /***
   ** Retrieves the label to be used in any attribute prompts
   **/
   public String getLabel(String voName, String voAttrName, String objectAttrName, LocaleContext locale)
   {
      String str = getHint(voName, voAttrName, objectAttrName, locale, AttributeHints.ATTRIBUTE_LABEL);
      if (str == null) 
      {
         int index = objectAttrName.lastIndexOf('.');
         if (index > -1) 
         {
            str = objectAttrName.substring(index+1);
         }
         else
         {
            str = objectAttrName;
         }
      }
      return str;
   }

   /***
   **  Retrives the tooltip text to be used for this attribute.
   **/
   public String getTooltip(String voName, String voAttrName, String objectAttrName, LocaleContext locale)
   {
      return getHint(voName, voAttrName, objectAttrName, locale, AttributeHints.ATTRIBUTE_TOOLTIP);
   }

  /**
   ** Returns the hint value based on the hint name.
   **/
   public String getHint(String voName, String voAttrName, String objectAttrName, LocaleContext locale, String sHintName)
   {
      StringBuffer hintBuf = new StringBuffer();
      if (objectAttrName != null && objectAttrName.length() > 0) 
      {
         hintBuf.append(objectAttrName.replace('.','_')).append('_');
      }

      hintBuf.append(sHintName);
      return getAttributeUIHelper(voName, voAttrName).getHint((locale == null) ? getLocaleContext() : locale, hintBuf.toString());
   }

   public LocaleContext getLocaleContext()
   {
      if (mLocaleContext == null) 
      {
         mLocaleContext = getApplicationModule().getSession().getLocaleContext();
      }
      return mLocaleContext;
   }

   
   /**
    * Returns true if this form binding executes all the ViewObjects it's associated with after rollback
    * is called on the application via JUCtrlActionBinding's rollback action.
    **/
   public boolean isExecuteOnRollback()
   {
      return mExecuteOnRollback;
   }

   /**
    * Set false if this form binding should not execute all the ViewObjects it's associated with after rollback
    * is called on the application via JUCtrlActionBinding's rollback action. The default is to execute all
    * the ViewObjects on rollback.
    **/
   public void setExecuteOnRollback(boolean flag)
   {
      mExecuteOnRollback = flag;
   }

   public void release()
   {
      ArrayList al;
      al = (ArrayList)mControlList.clone();
      JUControlBinding ctrl;
      for (int i = 0; i < al.size(); i++)
      {
         ctrl = (JUControlBinding)al.get(i);
         ctrl.release();
      }

      mControls = new HashMap(2);
      mControlList = new ArrayList(10);
      
      al = (ArrayList)mIterBindingList.clone();
      JUIteratorBinding iter;
      for (int i = 0; i < al.size(); i++)
      {
         iter = (JUIteratorBinding)al.get(i);
         iter.release();
      }
      
      mIterBindings = new HashMap(2);
      mIterBindingList = new ArrayList(2);

      //this is the only place where a UI control is set to null in JU bindings.
      //code-gen needs this to be null for applets to restart properly after release.
      setPanel(null);

      mApplication.removeFormBinding(this);
      mApplication = null;

   }

   /**
    * Returns an ordered list of ViewObject usages in this panel so that a JboException parameters
    * can be transformed from Entity-layer names and exception parameters to ViewObject names and parameters.
    */
   public ViewObject[] getOrderedVOUsageList()
   {
      int size = mIterBindingList.size();
      ArrayList al = new ArrayList(size);
      ViewObject vo;
      for (int i = 0; i < size; i++) 
      {
         vo = ((JUIteratorBinding)mIterBindingList.get(i)).getViewObject();
         if (vo != null && !al.contains(vo)) 
         {
            al.add(vo);
         }
      }
      return (ViewObject[])al.toArray(new ViewObject[al.size()]);
   }
}
