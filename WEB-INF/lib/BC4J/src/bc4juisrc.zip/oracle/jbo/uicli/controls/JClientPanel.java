/*
 * @(#)JClientPanel.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.uicli.controls;

import oracle.jbo.uicli.jui.JUPanelBinding;

/**
 * This interface identifies a JClient Panel for JDeveloper designtime, so that 
 * the JDeveloper UI Designer can allow JClient Data Model editors to be part of
 * the Property Inspector for the control's model property.
 */
public interface JClientPanel extends JUPanel
{
   /**
   * Sets the PanelBinding that this Panel is bound to.
   * Applications should use this method on a JPanel object to implement late panel binding
   */
   void setPanelBinding(JUPanelBinding binding);
}