/*
 * @(#)GraphDataFromCol.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.uicli.jui;

import oracle.dss.graph.Graph;
import oracle.jbo.RowSetIterator;
import oracle.jbo.uicli.binding.JUCtrlRangeBinding;
import oracle.jbo.uicli.binding.JUIteratorBinding;

public class GraphDataFromCol
       extends JUCtrlRangeBinding
{
    protected int  mNumberOfColumnValuesPerMarker;
    
    protected String mSeriesLabel;
    
    private int mLabelColumnIndex = -1;

	private final String  emptyString = "";
    
    public GraphDataFromCol(Graph control, 
            JUIteratorBinding iterBinding, 
            String[] dataValueAttrNames,
            int numberOfColumnValuesPerMarker,
            String seriesLabel)
    {
        super(control, iterBinding, dataValueAttrNames);


        init(control, numberOfColumnValuesPerMarker, 
             dataValueAttrNames.length -1 /* last attr treated as label*/,
             seriesLabel);
    } 

    private void init(Graph control, int numberOfColumnValuesPerMarker, 
                          int labelColumnIndex, String seriesLabel)
    {
         mNumberOfColumnValuesPerMarker = numberOfColumnValuesPerMarker;
         
         mLabelColumnIndex = labelColumnIndex;
         
         mSeriesLabel = seriesLabel;
         
    }

    protected String getSeriesLabel()
    {
        return mSeriesLabel;
    }

    
    protected String getColumnLabel(int i)
    {
        int rowNumber = i/mNumberOfColumnValuesPerMarker;
        
        int rangeIndex = rowIndexToRangeIndex(rowNumber);

        Object val =  getAttributeFromRow(rangeIndex, mLabelColumnIndex);

        return ((val == null) ? emptyString : val.toString());
    }

    protected int getColumnCount()
    {
        int rc = mNumberOfColumnValuesPerMarker * (int) getEstimatedRowCount();

        return rc;
    }


    protected Object getColumnValue(int col)
    {
        int modifiedRowNumber = col / mNumberOfColumnValuesPerMarker;
        
        int modifiedColNumber = col % mNumberOfColumnValuesPerMarker;

        int rangeIndex = rowIndexToRangeIndex(modifiedRowNumber);
        
        Object val =  getAttributeFromRow(rangeIndex, modifiedColNumber);
        
        if (val == null)
            val = emptyString;
            
        if ( val instanceof oracle.jbo.domain.Number)
            val = ((oracle.jbo.domain.Number)val).getData();

        return val;
    }

	protected int rowIndexToRangeIndex(int rowIndex)
    {
         RowSetIterator iter = (RowSetIterator)getRowIterator();

         if (iter != null)
         {
            int rangeStart = iter.getRangeStart();

            if (rangeStart <= 0)
            {
               return rowIndex;
            }
         
            return rowIndex - rangeStart;
         }
         else
         {
            return rowIndex;
         }
    }


	// implement JUCtrlRange
	public Object getValueAt(int rowIndex, int columnIndex)
    {
        return null;
    }


    public void setValueAt(Object aValue, int rowIndex, int columnIndex)
    {

    }


    public void addControlToPanel(Object panel, Object layoutObject, Object layoutCons)
    {

    }
          
}



