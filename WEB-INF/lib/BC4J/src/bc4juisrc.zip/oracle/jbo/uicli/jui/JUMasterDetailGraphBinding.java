/*
 * @(#)JUMasterDetailGraphBinding.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.uicli.jui;

import java.awt.Component;
import java.util.ArrayList;
import javax.swing.JPanel;
import oracle.dss.graph.Graph;
import oracle.dss.util.CubeDataDirector;
import oracle.dss.util.DataSource;
import oracle.dss.util.DefaultErrorHandler;
import oracle.dss.util.RelationalDataDirector;
import oracle.jbo.DeleteEvent;
import oracle.jbo.InsertEvent;
import oracle.jbo.JboException;
import oracle.jbo.Row;
import oracle.jbo.RowSetIterator;
import oracle.jbo.uicli.binding.JUFormBinding;
import oracle.jbo.uicli.binding.JUIteratorBinding;

/**
 * Data source for the BI Graph bean. This binding should be used for
 * Graphs which require multiple values per marker. High-Low-Close stock
 * chart is one example, which needs three values per marker. 
 *
 * The detail table contains series data for the Graph. Each row represents one 
 * marker. The number of columns in the detail should match the number of 
 * values required for a marker. The detail table represents one 'series' 
 * of data in the Graph. 
 *
 * @see JUSingleTableGraphBinding
 */
public class JUMasterDetailGraphBinding
	extends JUGraphBinding
	implements DataSource
{
	protected BIBeanDataAccessAdapter mAdapter;

	protected String mChildAccessorName;

	protected String[] mDataValueAttrNames;

	protected int mNumberOfColumnValuesPerMarker;

	protected String mSeriesLabelAttributeName;

	protected ArrayList mChildSeries = new ArrayList(10);

	public static JUMasterDetailGraphBinding  getInstance(
						JUFormBinding formBinding, 
						Graph         control,
						int           graphType,
						String        voInstanceName,
						String        voIterName, 
						String        voIterBindingName,
						String        seriesLabelAttributeName,
						String        childAccessorAttributeName,
						String[]      dataValueAttrNames,
						String        groupLabelAttrName)
	{
		control.setGraphType(graphType);

		return getInstance(formBinding, control, voInstanceName, voIterName, 
						   voIterBindingName, seriesLabelAttributeName,
						   childAccessorAttributeName,dataValueAttrNames,
						   groupLabelAttrName, getNumberOfColumnPerMarker(graphType));
	}

	public static JUMasterDetailGraphBinding  getInstance(
						JUFormBinding formBinding, 
						Graph         control,
						String        voInstanceName,
						String        voIterName, 
						String        voIterBindingName,
						String        seriesLabelAttributeName,
						String        childAccessorAttributeName,
						String[]      dataValueAttrNames,
						String        groupLabelAttrName,
						int numberOfColumnValuesPerMarker)
	{
		String attrNames[] = buildAttributeListWithLabel(dataValueAttrNames, 
														 groupLabelAttrName);

		JUIteratorBinding iterBinding = formBinding.getRangeIterBinding(
										  voInstanceName, 
										  voIterName, 
										  voIterBindingName, -1);

		JUMasterDetailGraphBinding bind = new JUMasterDetailGraphBinding(control, 
											iterBinding,
											seriesLabelAttributeName,
											childAccessorAttributeName,
											attrNames,
											numberOfColumnValuesPerMarker );
		return bind;
	}


	public JUMasterDetailGraphBinding(Graph control, 
									  /* master dataset supplies series values*/
									  JUIteratorBinding seriesBinding, 
									  String  seriesLabelAttributeName,
									  String childAccessorName,
									  String[] dataValueAttrNames,
									  int numberOfColumnValuesPerMarker)
	{
		super(control, seriesBinding, 
			  new String[] { seriesLabelAttributeName, childAccessorName});
			  

		init(control, childAccessorName, dataValueAttrNames,
			 numberOfColumnValuesPerMarker,
			 seriesLabelAttributeName );
	} 

	private void init(Graph control, String childAccessorName,
					  String[] dataValueAttrNames,
					  int numberOfColumnValuesPerMarker,
					  String seriesLabelAttributeName)
	{
		mAdapter = new BIBeanDataAccessAdapter(this);

		mChildAccessorName = childAccessorName;

		mDataValueAttrNames = dataValueAttrNames;

		mNumberOfColumnValuesPerMarker = numberOfColumnValuesPerMarker;

		mSeriesLabelAttributeName = seriesLabelAttributeName;

		Object errHandler = control.getErrorHandler();

		if ( (errHandler != null) && (errHandler instanceof DefaultErrorHandler))
		{
			 DefaultErrorHandler defErrHandler = (DefaultErrorHandler) errHandler;

			 defErrHandler.setDebugMode(DefaultErrorHandler.SHOW_ERROR);

		}
	}


	protected GraphDataFromCol getSeries(int whichSeries)
	{
		GraphDataFromCol childSeries = (GraphDataFromCol)mChildSeries.get(whichSeries);

		if ( childSeries == null )
		{
			throw new JboException("Graph : Child series missing "); 
		}

		return childSeries;
	}

	// implement JUGraphBinding abstract methods.

	protected String getColumnLabel(int i)
	{
        GraphDataFromCol series = getSeries(0);

        return series.getColumnLabel(i);
	}

	protected int getColumnCount()
	{

	    GraphDataFromCol series = getSeries(0);

        int rc = series.getColumnCount(); 
		 
        return rc;
	}


	protected String getRowLabel(int i)
	{
		GraphDataFromCol series = getSeries(i);

        return series.getSeriesLabel();

	}

	protected long getRowCount()
	{
		return getEstimatedRowCount(); 
	}


	protected Object getValue(int row, int col)
	{
		GraphDataFromCol series = getSeries(row);
    
        return series.getColumnValue(col);

    }

	public void addControlToPanel(Object panel, Object layoutObject, Object layoutCons)
	{
		((JPanel) panel).add((Component) layoutObject, layoutCons);
	}

	public void updateRowInserted(InsertEvent event)
	{
		notifyView();
	}


	public void updateRowDeleted(DeleteEvent event)
	{
		notifyView();
	}

	public void updateValuesFromRows(Row[] rows, boolean clear)
	{
		super.updateValuesFromRows(rows, clear);

		for ( int i=0; i < rows.length; i++)
		{
			Object child = rows[i].getAttribute(mChildAccessorName);

			if (child instanceof RowSetIterator)
			{
				RowSetIterator childIter = (RowSetIterator)child;

				Object seriesLabel = rows[i].getAttribute(mSeriesLabelAttributeName);

				JUIteratorBinding childIterBind = new JUIteratorBinding(childIter);

				GraphDataFromCol childData = createGraphDataFromCol((Graph)getControl(), 
															  childIterBind,
															  mDataValueAttrNames,
															  mNumberOfColumnValuesPerMarker, 
															  seriesLabel.toString());
				mChildSeries.add(i, childData);
			}
			else
			{
				throw new JboException("RowSetIterator expected. Check the cardinality for the ViewLink accesor " + mChildAccessorName);
			}
		}

		notifyView();
	}


	protected GraphDataFromCol createGraphDataFromCol(Graph control, 
							JUIteratorBinding iterBinding, 
							String[] dataValueAttrNames,
							int numberOfColumnValuesPerMarker,
							String seriesLabel)
	{
		return new GraphDataFromCol(control, iterBinding, 
                         dataValueAttrNames,
						 numberOfColumnValuesPerMarker, 
					     seriesLabel);

	}


	protected void notifyView()
	{
		super.refreshBIBeanAdapter(mAdapter);
	}


	// Implement DataSource interface
	public RelationalDataDirector createRelationalDataDirector() 
	{
		return mAdapter;
	}

	public CubeDataDirector createCubeDataDirector() 
	{
		return mAdapter;
	}

}

