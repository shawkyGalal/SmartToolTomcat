/*
 * @(#)JUArrayComboBox.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.uicli.controls;

import javax.swing.ComboBoxModel;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.FocusListener;
import java.awt.event.FocusEvent;
import java.awt.event.FocusAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

import oracle.jbo.uicli.jui.JUDefaultControlBinding;
import oracle.jbo.uicli.jui.JUDefaultControlInterface;
import oracle.jbo.uicli.binding.JUFormBinding;
import oracle.jbo.uicli.jui.JUIUtil;
import oracle.jbo.uicli.UIMessageBundle;

import oracle.jbo.domain.Array;
import oracle.jbo.domain.TypeFactory;
import oracle.jbo.common.Diagnostic;
import oracle.jbo.common.StringManager;


import oracle.jbo.AttributeDef;

/**
 * Extends a JComboBox to display data from a BC4J Array domain. This class implements
 * all editing needs for Array objects that contain scalar values. This class also has
 * allows extensions to allow editing of element that are non-scalar Oracle Object types 
 * and Arrays.
 * <p>
 */
public class JUArrayComboBox extends javax.swing.JComboBox 
                             implements ActionListener, 
                                        FocusListener, 
                                        JUDefaultControlInterface
{
   JUDefaultControlBinding mBinding;
   int mMaxCount = -1;
   boolean mNullArray;

   FocusAdapter mFocusAdapter;
   Class mElemType;
   boolean modified = false;
   JUArrayElementEditorInterface mElemEditor;
   private static final String MSG_BUNDLE = "oracle.jbo.uicli.UIMessageBundle";

   /**
   * Creates a <code>JComboBox</code> with a default data model.
   * The default data model is an empty list of objects.
   * Use <code>addItem</code> to add items.  By default the first item
   * in the data model becomes selected.
   *
   * @see DefaultComboBoxModel
   */
   public JUArrayComboBox() 
   {
     super();
     init();
   }

   void init()
   {
      getEditor().getEditorComponent().addFocusListener(this);
      setEditable(true);
   }

   /**
   * Sets the editor whose edit() method will be invoked when the selected
   * item in this combobox is to be edited. The key strokes that invokes this
   * editor is configurable by the editor itself. If no custom key strokes
   * are provided, the default Ctrl+Enter key is used to invoke this editor.
   * <p>
   * For Oracle Objects, Arrays and other types that cannot be edited as
   * string in the default ComboBoxEditor, this method should be used to
   * set a custom editor that is invoked when the user types Ctrl+Enter
   * (or any custom Key combination as per the editor).
   */
   public void setArrayElementEditor(JUArrayElementEditorInterface editor)
   {
      mElemEditor        = editor;
   }

   /**
   * Returns the custom element editor (if any) that this combobox works with.
   */
   public JUArrayElementEditorInterface getArrayElementEditor()
   {
      return mElemEditor;
   }
   
   
   /**
   * Binds this combobox control with an attribute of Array type in a ViewObject. 
   * When the ViewObject/RowSet behind the iterator to which the given binding
   * belongs is executed, the binding object updates this combobox's display 
   * with data from the ViewObject.
   */
   public void setArrayBinding(JUDefaultControlBinding binding)
   {
      mBinding = binding;
   }
   
   /**
   * Returns the attribute-binding model that this control is bound to.
   */
   public JUDefaultControlBinding getArrayBinding()
   {
     return mBinding;
   }

   /**
   * Updates the display of elements with the new Array object that is passed in 
   * into this method. The first time this method is called for this Combobox instance
   * this method also sets up the element-type that this Array's elements are of.
   */
   public void dataChanged(Object dataItem)
   {
      if (mMaxCount == -1) 
      {
         AttributeDef ad = mBinding.getAttributeDef(0);
         mMaxCount = ad.getPrecision();
         mElemType = ad.getElemType();

         if (mElemEditor != null) 
         {
            getEditor().getEditorComponent().addKeyListener(
               new KeyListener()
               {
                  public void keyTyped(KeyEvent e){}
                  public void keyPressed(KeyEvent e){}
                  
                  /**
                  * If the key pressed is Ctrl+Enter (or if an editor is installed
                  * with this ComboBox, then if the key is the Editor specified Key
                  * combination), then use the Editor's edit() method to edit/update
                  * the selected Array element.
                  */
                  public void keyReleased(KeyEvent e)
                  {
                     boolean editKey = (mElemEditor.hasCustomEditKey()) 
                                          ? mElemEditor.isEditKey(e)
                                          : (e.getKeyCode() == KeyEvent.VK_ENTER
                                             && e.isControlDown());
                     if (editKey) 
                     {
                        int sel = getSelectedIndex();
                        Object curObj = getSelectedItem();
                        if (curObj instanceof String) 
                        {
                           String strObj = (String)curObj;
                           curObj = null;
                           if (strObj.trim().length() != 0) 
                           {
                              if (Diagnostic.isOn()) 
                              {
                                 Diagnostic.println(StringManager.getString(MSG_BUNDLE, 
                                                    UIMessageBundle.STR_AR_IMPROPER_EDIT, 
                                                    "Found String instead of Struct", null)); //NORES

                              }
                           }
                        }
                        Object obj = mElemEditor.edit(curObj, mBinding, e.getComponent());
                        if (obj == null)
                        {
                           if (sel >= 0) 
                           {
                              //remove the selected element
                              modified = true;
                              removeItemAt(sel);
                           }
                        }
                        else 
                        {
                           if (sel >= 0) 
                           {
                              if (obj != curObj)
                              {
                                 //if not the same string  (we get Action event no matter what).
                                 try
                                 {
                                    insertItemAt(TypeFactory.getInstance(mElemType, obj), sel);
                                    modified = true;
                                    removeItemAt(sel+1);
                                    grabFocus();
                                    setSelectedIndex(sel);
                                 }
                                 catch (Exception ex)
                                 {
                                    mBinding.reportException(ex);
                                    getEditor().setItem(getItemAt(sel));
                                    setSelectedIndex(sel);
                                 }
                              }
                           }
                           else
                           {
                              //cannot handle null strings/null values in array.
                              modified = true;
                              try
                              {
                                 addItem(TypeFactory.getInstance(mElemType, obj));
                                 grabFocus();
                                 setSelectedIndex(getItemCount()-1);
                              }
                              catch (Exception ex)
                              {
                                 mBinding.reportException(ex);
                                 sel = getItemCount() - 1;
                                 getEditor().setItem(getItemAt(sel));
                                 setSelectedIndex(sel);
                              }
                           }
                        }
                        if (modified)
                        {
                           updateArray();
                        }
                     }
                  }
               }
            );
         }
      }

      removeAllItems();             
      mNullArray = (dataItem == null);
      if (!mNullArray) 
      {
         Array arr = (Array)dataItem;
         Object[] objs = arr.getArray();
         for (int i = 0; i < objs.length; i++) 
         {
            addItem(objs[i]);
         }
      }
   }

   /**
   * Sets up the FocusAdapter that this combobox works with to update status bar information.
   */
   public void addFocusListener(FocusAdapter f)
   {
      this.mFocusAdapter = f;
   }

   public void focusLost(FocusEvent event)
   {
   }
   
   /**
   * Sends this event to the installed FocusAdapter which in JClient case is used
   * to update the statusbar of a containing frame/JUPanelBinding.
   */
   public void focusGained(FocusEvent event)
   {
      if (!event.isTemporary()) 
      {
         if (mFocusAdapter != null) 
         {
            mFocusAdapter.focusGained(event);
         }
      }
   }

   /**
   * Updates the array with the edits done in the combobox editor.
   * <p>
   * If the combobox-editor entry is completely removed (deleted), and this method gets
   * called, this method "removes" nulls out the element at the selected index (if any).
   * <p>
   * If there's no selected item in the combobox and the editor is used to type in
   * a new value, then that value is accepted as a "new element" for the array and
   * appeneded to the array elements.
   * <p>
   * If there is a selected item and combobox editor provides another value then
   * this method replaces the current entry in the array with the new value.
   *
   */
   public void actionPerformed(ActionEvent e)
   {
      int sel = getSelectedIndex();
      
      String str = getEditor().getItem().toString();
      if (str.trim().length() == 0)
      {
         if (sel >= 0) 
         {
            //remove the selected element
            modified = true;
            removeItemAt(sel);
         }
      }
      else 
      {
         if (mElemEditor == null) 
         {
            if (sel >= 0) 
            {
               if (!str.equals(getItemAt(sel).toString()))
               {
                  //if not the same string  (we get Action event no matter what).
                  try
                  {
                     insertItemAt(TypeFactory.getInstance(mElemType, str), sel);
                     modified = true;
                     removeItemAt(sel+1);
                     setSelectedIndex(sel);
                  }
                  catch (Exception ex)
                  {
                     mBinding.reportException(ex);
                     getEditor().setItem(getItemAt(sel));
                     setSelectedIndex(sel);
                  }
               }
            }
            else
            {
               //cannot handle null strings/null values in array.
               try
               {
                  addItem(TypeFactory.getInstance(mElemType, str));
                  modified = true;
                  setSelectedIndex(getItemCount()-1);
               }
               catch (Exception ex)
               {
                  mBinding.reportException(ex);
                  sel = getItemCount() - 1;
                  getEditor().setItem(getItemAt(sel));
                  setSelectedIndex(sel);
               }
            }
         }
      }
      if (modified)
      {
         updateArray();
      }
      super.actionPerformed(e);
   }

   //this method performs the actual update of the BC4J array.
   void updateArray()
   {
      if (modified) 
      {
         modified = false;
         int size = getItemCount();
         if (size > 0) 
         {
            Object[] objs = new Object[size];
            ComboBoxModel model = getModel();
            for (int i = 0; i < size; i++) 
            {
               objs[i] = model.getElementAt(i);
            }
            mBinding.setAttribute(0, new Array(objs));
         }
         else
         {
            mBinding.setAttribute(0, null);
         }
      }
   }



   /**
   * This method is used by the JDeveloper designtime wizards for binding a JComboBox component
   * with an attribute of type Array in rows of a ViewObject/RowIterator.
   * This method calls JUFormBinding.getRowIterBinding to get the iterator binding using
   * the given parameters and then registers a new JUTextFieldBinding with the iterator
   * binding object so as to display/edit the current row's attribute of the given name.
   * <p>
   * @param formBinding The containing JUPanelBinding in which the given iterator binding
   * would be found/created.
   * @param control The control instance to bind to a ViewObject's attribute.
   * @param voInstanceName Name of the instance of the ViewObject in a BC4J ApplicationModule.
   * @param voIterName Runtime instance name of the iterator in the ViewObject (optional).
   * @param voIterBindingName Instance name of the iterator binding that uniquely identifies an
   * iterator binding object used to read/write data in this given JUPanelBinding instance.
   * @param attrName The name of the attribute of this ViewObject rows that contains data
   * to display/edit in the associated text control.
   * @param editor A custom editor that performs editing of elements in this array
   * /combobox. This editor needs to implement the interface: JUArrayElementEditorInterface
   * and is invoked when a user types the editor-specified key (or Ctrl+Enter by default)
   * on the combobox editor to edit an element in the array.
   * @return JUControlBinding object bound to the given JUArrayComboBox.
   */
   public static ComboBoxModel createAttributeBinding(JUFormBinding formBinding, 
                                            JUArrayComboBox control,
                                            String        voInstanceName,
                                            String        voIterName, /*temporarily taking nulls for this*/
                                            String        voIterBindingName,
                                            String        attrName,
                                            JUArrayElementEditorInterface editor)
   {
      if (!JUIUtil.inDesignTime())
      {

         control.setArrayElementEditor(editor);
         JUDefaultControlBinding bind = new JUDefaultControlBinding(control, 
                                   formBinding.getRowIterBinding(voInstanceName, voIterName, voIterBindingName),
                                   attrName);
         control.setArrayBinding(bind);

         bind.refreshControl();
         //return bind;
         return control.getModel();
      }
      else
      {
         try
         {
            Class clazz = Class.forName("oracle.jbo.dt.ui.jui.propertyeditors.dtmodels.DTJUArrayComboBoxBinding");
            java.lang.reflect.Constructor constructor = clazz.getConstructors()[0];
            Object [] args = { voInstanceName + "." + attrName };
            Object object = constructor.newInstance(args);
            return (ComboBoxModel)object;
         }
         catch (Exception e)
         {
            return null;
         }
      }
   }

}