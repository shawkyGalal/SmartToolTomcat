/*
 * @(#)JUButtonBinding.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.uicli.jui;

import java.awt.Component;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import javax.swing.AbstractButton;
import javax.swing.ButtonGroup;
import javax.swing.ButtonModel;
import javax.swing.DefaultButtonModel;
import javax.swing.JPanel;
import javax.swing.event.ChangeListener;
import oracle.jbo.uicli.binding.JUCtrlBoolBinding;
import oracle.jbo.uicli.binding.JUFormBinding;
import oracle.jbo.uicli.binding.JUIteratorBinding;

/**
 * Implements binding a Swing AbstractButton object with a BC4J attribute.
 * <p>
 * Swing Classes like JCheckBox, JRadioButton, JButton can be bound using this
 * class to display/update boolean values for an attribute. Applications can
 * customize the boolean values to any two desired values that a particular
 * attribute can accept like Y/N for checkbox states of True/False or Checked/Unchecked.
 * <p>
 * By default the binding sends a java.lang.Boolean.TRUE for checked or selected state
 * of a button to the BC4J attribute.
 */
public class JUButtonBinding extends JUCtrlBoolBinding
   implements ButtonModel, ActionListener, ItemListener
{
   private ButtonModel mButtonModel = null;
   private int mSettingValue = 0;
  

   /**
   * Use this method to bind an AbstractButton to a BC4J Attribute when the default settings
   * for true and false states are to be used to set the attribute values.
   * <p>
   * @param formBinding The containing JUPanelBinding in which the given iterator binding
   * would be found/created.
   * @param control The control instance to bind to a ViewObject's attribute.
   * @param voInstanceName Name of the instance of the ViewObject in a BC4J ApplicationModule.
   * @param voIterName Runtime instance name of the iterator in the ViewObject (optional).
   * @param voIterBindingName Instance name of the iterator binding that uniquely identifies an
   * iterator binding object used to read/write data in this given JUPanelBinding instance.
   * @param attrName The name of the attribute of this ViewObject rows that contains data
   * to display/edit in the associated button.
   * @return Model Object bound to the given button. This method simply returns the existing
   * model object in the button and does not create a new one. This method simply wires up
   * the Button's model object with a new JClient button binding object and then returns
   * the button's model object.
   */
   public static ButtonModel getAttributeBinding(JUFormBinding formBinding, 
                                                  AbstractButton control,
                                                  String        voInstanceName,
                                                  String        voIterName, // temporarily taking nulls for this
                                                  String        voIterBindingName,
                                                  String        attrName)
   {
      if (!JUIUtil.inDesignTime())
      {
         JUButtonBinding bind = new JUButtonBinding(control, 
                                       formBinding.getRowIterBinding(voInstanceName, voIterName, voIterBindingName),
                                       attrName);
         return bind.getModelImpl(null);
      }
      else
      {
         try
         {
            Class clazz = Class.forName("oracle.jbo.dt.ui.dac.propertyeditors.dtmodels.DTJButtonBinding");
            java.lang.reflect.Constructor constructor = clazz.getConstructors()[0];
            Object [] args = { voInstanceName + "." + attrName };
            Object object = constructor.newInstance(args);
            return (ButtonModel)object;
         }
         catch (Exception e)
         {
            return null;
         }
      }
   }
    
   /**
   * @deprecated since 9.0.2 use createAttributeBinding or createBooleanBinding methods instead.
   */
   public static ButtonModel getInstance(JUFormBinding formBinding, 
                                                  AbstractButton control,
                                                  String        voInstanceName,
                                                  String        voIterName, // temporarily taking nulls for this
                                                  String        voIterBindingName,
                                                  String        attrName)
   {
      return getAttributeBinding(formBinding, control, voInstanceName, voIterName, voIterBindingName, attrName);
   }
   
   
   /**
   * Use this method to bind an AbstractButton to a BC4J Attribute when the Application usage
   * determines the attribute values for true and false states to be used to set the attribute values.
   * The two values for true and false states are passed in valueList object array and the
   * next argument 'boolVal' detmerines whether the first value in the list means true or false.
   * <p>
   * @param formBinding The containing JUPanelBinding in which the given iterator binding
   * would be found/created.
   * @param control The control instance to bind to a ViewObject's attribute.
   * @param voInstanceName Name of the instance of the ViewObject in a BC4J ApplicationModule.
   * @param voIterName Runtime instance name of the iterator in the ViewObject (optional).
   * @param voIterBindingName Instance name of the iterator binding that uniquely identifies an
   * iterator binding object used to read/write data in this given JUPanelBinding instance.
   * @param attrName The name of the attribute of this ViewObject rows that contains data
   * to display/edit in the associated button.
   * @param valueList A list of two values that are used by this binding to set into
   * the BC4J attribute when this button updates an attribute.
   * @param boolVal When true, the first value in the above list valueList means 'true'.
   * @return Model Object bound to the given button. This method simply returns the existing
   * model object in the button and does not create a new one. This method simply wires up
   * the Button's model object with a new JClient button binding object and then returns
   * the button's model object.
   */
   public static ButtonModel createBooleanBinding(JUFormBinding formBinding, 
                                                  AbstractButton control,
                                                  String        voInstanceName,
                                                  String        voIterName, // temporarily taking nulls for this
                                                  String        voIterBindingName,
                                                  String        attrName,
                                                  Object[]      valueList, //list of two values that goes into the db.
                                                  boolean       boolVal) //what does 0th element mean true/false?
   {
      if (!JUIUtil.inDesignTime())
      {
         JUButtonBinding bind = new JUButtonBinding(control, 
                                       formBinding.getRowIterBinding(voInstanceName, voIterName, voIterBindingName),
                                       attrName, valueList, boolVal);
         bind.convertValueList();
         bind.refreshControl();
         return bind.getModelImpl(null);
      }
      else
      {
         try
         {
            Class clazz = Class.forName("oracle.jbo.dt.ui.jui.propertyeditors.dtmodels.DTJBoolButtonBinding");
            java.lang.reflect.Constructor constructor = clazz.getConstructors()[0];
            Object [] args = { voInstanceName + "." + attrName , valueList[0], valueList[1]};
            Object object = constructor.newInstance(args);
            return (ButtonModel)object;
         }
         catch (Exception e)
         {
            return null;
         }
      }
   }

   /**
   * @deprecated since 9.0.2 use createAttributeBinding or createBooleanBinding methods instead.
   */
   public static ButtonModel getInstance(JUFormBinding formBinding, 
                                                  AbstractButton control,
                                                  String        voInstanceName,
                                                  String        voIterName, // temporarily taking nulls for this
                                                  String        voIterBindingName,
                                                  String        attrName,
                                                  Object[]      valueList, //list of two values that goes into the db.
                                                  boolean       boolVal) //what does 0th element mean true/false?
   {
      return createBooleanBinding(formBinding, control, voInstanceName, voIterName, voIterBindingName, attrName, 
                               valueList, boolVal);
   }

   /**
   * Use this method to bind an AbstractButton to a BC4J ViewObject and assign one of the
   * enumerated set of actions to this Button, so that when this button is pressed (on actionPerformed)
   * the desired action(method) is invoked on the associated RowSet. See JUCtrlActionBinding
   * for details on the list of valid actions.
   * <p>
   * @param formBinding The containing JUPanelBinding in which the given iterator binding
   * would be found/created.
   * @param control The control instance to bind to a ViewObject's attribute.
   * @param voInstanceName Name of the instance of the ViewObject in a BC4J ApplicationModule.
   * @param voIterName Runtime instance name of the iterator in the ViewObject (optional).
   * @param voIterBindingName Instance name of the iterator binding that uniquely identifies an
   * iterator binding object used to read/write data in this given JUPanelBinding instance.
   * @param action An enumerated action-id which determines which method to invoke
   * on the associated RowSet when this button is pressed.
   * @return Model Object bound to the given button. This method simply returns the existing
   * model object in the button and does not create a new one. This method simply wires up
   * the Button's model object with a new JClient button binding object and then returns
   * the button's model object.
   */
   public static ButtonModel createActionBinding(JUPanelBinding formBinding,
                                                  Component     control,
                                                  String        voInstanceName,
                                                  String        voIterName, // temporarily taking nulls for this
                                                  String        voIterBindingName,
                                                  int           action)
   {
      if (!JUIUtil.inDesignTime())
      {
         return new JUActionBinding(control, formBinding.getRangeIterBinding(voInstanceName, voIterName, voIterBindingName, -1), action);
      }
      else
      {
         try
         {
            Class clazz = Class.forName("oracle.jbo.dt.ui.jui.propertyeditors.dtmodels.DTJUButtonActionBinding");
            java.lang.reflect.Constructor constructor = clazz.getConstructors()[0];

            Class [] clsss = constructor.getParameterTypes();

            Object [] args = { voInstanceName, new Integer(action) };
            Object object = constructor.newInstance(args);
            return (ButtonModel)object;
         }
         catch (Exception e)
         {
            return null;
         }
      }
   }

   /**
   * @deprecated since 9.0.2 use createActionBinding method instead.
   */
   public static ButtonModel getInstance(JUPanelBinding formBinding,
                                                  Component     control,
                                                  String        voInstanceName,
                                                  String        voIterName, // temporarily taking nulls for this
                                                  String        voIterBindingName,
                                                  int           action)
   {
      return createActionBinding(formBinding, control, voInstanceName, voIterName, voIterBindingName, action);
   }

   /*
   * Creates a Button binding object that binds the given button to a BC4J attribute
   * and uses default Boolean values to set into the attribute based on Button's selection
   * state. If the button is selected, then the attribute value is set to Boolean.TRUE.
   * <p>
   * @param control Abstract button which should be bound to an attribute of a BC4J row.
   * @param iterBinding JUIteratorBinding object that contains a reference to the RowIterator that contains Rows to display.
   * @param attrName Name of the attribute in the BC4J Row object to display/edit using this button.
   */
   public JUButtonBinding(AbstractButton control, JUIteratorBinding iterBinding, String attrName)
   {
      super(control, iterBinding, attrName);
      
      init(control);
   }


   /*
   * Creates a Button binding object that binds the given button to a BC4J attribute
   * and uses the values passed in to set into the attribute based on Button's selection
   * state. If the button is selected, then the attribute value is set to the first value
   * in the valueList array if boolVal is true, else the second value is used.
   * <p>
   * @param control Abstract button which should be bound to an attribute of a BC4J row.
   * @param iterBinding JUIteratorBinding object that contains a reference to the RowIterator that contains Rows to display
   * @param attrName Name of the attribute in the BC4J Row object to display/edit using this button.
   * @param valueList List of valid values to represent button's states.
   * @param boolVal Controls whether the first value in the list above represents the button's state: true or false.
   */
   public JUButtonBinding(AbstractButton control, JUIteratorBinding iterBinding, String attrName,
                          Object[] valueList, boolean boolVal)
   {
      super(control, iterBinding, attrName, valueList, boolVal);
      
      init(control);
   }

   
   private void init(AbstractButton control)
   {
      mButtonModel = getModelImpl(control);

      if (control != null && mButtonModel != control.getModel())
      {
         control.setModel(mButtonModel);
      }
   }

   
   /**
   * Returns the button model that to which the binding is bound. 
   * The first time this method gets called (from the constructor), this method
   * gets the ButtonModel from the given control, and if it is null, then creates
   * a DefaultButtonModel and returns that.
   * Also this method adds this binding object as ActionListener and ItemListener
   * on the button so that it can react to change in button states and set the
   * BC4J attribute value appropriately.
   */
   protected ButtonModel getModelImpl(AbstractButton control)
   {
      ButtonModel buttonModel = mButtonModel;

      if (buttonModel == null)
      {
         if (control != null)
         {
            buttonModel = control.getModel();
         }
   
         if (buttonModel == null)
         {
            buttonModel = new DefaultButtonModel();
         }
         // buttonModel.addChangeListener(this);
         buttonModel.addActionListener(this);
         buttonModel.addItemListener(this);
      }

      return buttonModel;
   }

   
   /**
   * *** For internal framework use only ***
   */
   public void addControlToPanel(Object panel, Object layoutObject, Object layoutCons)
   {
      ((JPanel) panel).add((Component) layoutObject, layoutCons);
   }


   /**
   * Returns true, so that JTextComponents can participate in a query in the Find Mode of the
   * containing panel. When the containing panel Binding object is set to Find mode, it queries
   * all control-bindings in it and disables those controls whose bindings return false
   * for this method during the Find mode. The return value from this method indicates 
   * whether to consult an attribute definition for queriability.
   * <p>
   * An application could create a subclass of this binding object and return false from this
   * method to prevent the associated control from participating in find mode. Additionally, a
   * BC4J attribute itself can control whether that attribute can participate in Query or
   * not. That property takes precedence over this method's return, if this method returns true.
   * In other words, if this binding is bound to a CLOB attribute type and the attribute
   * definition for that attribute indicates that it is not queriable, then the default behavior
   * of JUPanelBinding in Find mode will be to disable this binding's control, even though
   * this method returns true.
   */
   protected boolean isControlQueriable()
   {
      return true;
   }
   
   /**
   * Returns the current boolean value that the associated button represents.
   * This value is used by the framework to get the appropriate attribute value
   * to set into a BC4J attribute.
   * @param attrIndex This argument is ignored for this binding.
   */
   public Object getValueAt(int attrIndex)
   {
      return new Boolean(mButtonModel.isSelected());
   }


   /**
   * Matches the given value with one of the values given in the constructor
   * or to Boolean.TRUE or Boolean.FALSE and then sets the associated button to
   * matching boolean state. This method is used by the framework to set
   * the button state based on attribute value.
   * @param value Should either be Boolean.TRUE or Boolean.FALSE or
   * one of the two values provided in the constructor or create binding
   * method. If the values do not match, then this method sets the button
   * state to false.
   * @param attrIndex This argument is ignored for this binding.
   */
   public void setValueAt(Object value, int attrIndex)
   {
      if (mSettingValue > 0)
      {
         return;
      }
      
      Boolean foundVal = (Boolean) findValue(value);
      boolean bVal;

      if (foundVal == null)
      {
         bVal = false;
      }
      else
      {
         bVal = foundVal.booleanValue();
      }

      try
      {
         mSettingValue++;
         mButtonModel.setSelected(bVal);
      }
      finally
      {
         mSettingValue--;
      }
      // ((AbstractButton) getControl()).setSelected(bVal);
   }


   /**
   * This method is overridden to be a no-op for Button Binding.
   */
   public void setDataValueAt(Object value, int attrIndex)
   {
   }


   //
   // ButtonModel implementation
   //

   public boolean isArmed()
   {
      return mButtonModel.isArmed();
   }


   public boolean isSelected()
   {
      return mButtonModel.isSelected();
   }


   public boolean isEnabled()
   {
      return mButtonModel.isEnabled();
   }


   public boolean isPressed()
   {
      return mButtonModel.isPressed();
   }


   public boolean isRollover()
   {
      return mButtonModel.isRollover();
   }


   public void setArmed(boolean b)
   {
      mButtonModel.setArmed(b);
   }


   public void setSelected(boolean b)
   {
      mButtonModel.setSelected(b);
   }


   public void setEnabled(boolean b)
   {
      mButtonModel.setEnabled(b);
   }


   public void setPressed(boolean b)
   {
      mButtonModel.setPressed(b);
   }


   public void setRollover(boolean b)
   {
      mButtonModel.setRollover(b);
   }


   public void setMnemonic(int key)
   {
      mButtonModel.setMnemonic(key);
   }


   public int getMnemonic()
   {
      return mButtonModel.getMnemonic();
   }


   public void setActionCommand(String s)
   {
      mButtonModel.setActionCommand(s);
   }


   public String getActionCommand()
   {
      return mButtonModel.getActionCommand();
   }


   public void setGroup(ButtonGroup group)
   {
      mButtonModel.setGroup(group);
   }


   public void addActionListener(ActionListener l)
   {
      mButtonModel.addActionListener(l);
   }


   public void removeActionListener(ActionListener l)
   {
      mButtonModel.removeActionListener(l);
   }


   public void addItemListener(ItemListener l)
   {
      mButtonModel.addItemListener(l);
   }


   public void removeItemListener(ItemListener l)
   {
      mButtonModel.removeItemListener(l);
   }


   public void addChangeListener(ChangeListener l)
   {
      mButtonModel.addChangeListener(l);
   }


   public void removeChangeListener(ChangeListener l)
   {
      mButtonModel.removeChangeListener(l);
   }

   
   public Object[] getSelectedObjects()
   {
      return mButtonModel.getSelectedObjects();
   }

   
   //ChangeListener
/**********
   public void stateChanged(ChangeEvent e)
   {
      if (mSettingValue == 0)
      {
         setAttribute(0, getValueAt(0));
      }
   }
**********/


   // ActionListener
   /**
   * Binding subclasses can override this method to implement custom action 
   * for actionPerformed event without having to add this binding as an 
   * ActionListener in the Application. Framework adds this object as
   * an ActionListener by default.
   */
   public void actionPerformed(ActionEvent e)
   {
   }


   // ItemListener
   /**
   * Updates the BC4J attribute based on the current setting of the 
   * button. If the button state is checked/selected/true, this method
   * sets the equivalent TRUE value into the attribute (as derived
   * from the valueList and boolVal combination).
   */                                           
   public void itemStateChanged(ItemEvent e)
   {
      if (mSettingValue == 0)
      {
         try
         {
            mSettingValue++;
            setAttribute(0, getValueFromBoolean(mButtonModel.isSelected()));
         }
         catch (Exception ex)
         {
            reportException(ex, true);
         }
         finally
         {
            mSettingValue--;
         }
      }
   }
}
