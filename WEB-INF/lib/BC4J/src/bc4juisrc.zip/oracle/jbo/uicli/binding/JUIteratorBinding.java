/*
 * @(#)JUIteratorBinding.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.uicli.binding;

import java.util.ArrayList;
import oracle.jbo.ApplicationModule;
import oracle.jbo.DeleteEvent;
import oracle.jbo.InsertEvent;
import oracle.jbo.NavigatableRowIterator;
import oracle.jbo.NavigationEvent;
import oracle.jbo.NoObjException;
import oracle.jbo.RangeRefreshEvent;
import oracle.jbo.Row;
import oracle.jbo.RowIterator;
import oracle.jbo.RowSet;
import oracle.jbo.RowSetIterator;
import oracle.jbo.RowSetListener;
import oracle.jbo.RowSetManagementEvent;
import oracle.jbo.RowSetManagementListener;
import oracle.jbo.ScrollEvent;
import oracle.jbo.UpdateEvent;
import oracle.jbo.ViewCriteria;
import oracle.jbo.ViewObject;

/**
 * JUIteratorBinding is the binding class that interacts with BC4J RowIterator objects
 * to iterate over rows and provide the current row(s) to display to various control
 * bindings. JUIteratorBinding objects are named and uniquely identified by name in a 
 * JUFormBinding which acts as a container of iterator bindings. This class handles the 
 * events generated from the associated BC4J RowIterator and sends the current Row (rows 
 * in range) over to individual control bindings to display current data. This class also 
 * manages the findMode data for the associated BC4J iterator and ViewObject.
 * <p>
 * At runtime, an application can bind an instance of oracle.jbo.NavigatableRowIterator
 * to a JUIteratorBinding object using the <code>bindRowSetIterator</code> method.
 */
public class JUIteratorBinding implements RowSetListener, RowSetManagementListener
{
   private String mName;
   private ApplicationModule mAM;
   private String mVOName;
   private String mRSIName;
   private ViewObject mVO;
   private ViewCriteria mVC;
   private String mViewDefName;
   private NavigatableRowIterator mRSI;
   private NavigatableRowIterator mOldRSI;
   private JUFormBinding mFormBinding;
   private ArrayList mValueBindingList;
   private ArrayList mActionBindingList;
   private boolean mIsBound = true;
   private boolean mIsAlive = true;
   private boolean mFindMode = false;
   private boolean mRowSetEventsEnabled = true;
   private int mRangeSize = 1;
   private boolean mInitVisible = false;

   protected JUIteratorBinding()
   {
      mName = "";
   }

   protected JUIteratorBinding(JUIteratorBinding iterBinding)
   {
      mAM = iterBinding.mAM;
      mVOName = iterBinding.mVOName;
      mRSIName = iterBinding.mRSIName;
      mRangeSize = iterBinding.mRangeSize;
   }

   /**
   * Use this constructor if a usage needs a specific range size on the associated iterator.
   * Objects of type JUCtrlRangeBinding may use this constructor to specify a default
   * range size for the iterator. 
   */
   public JUIteratorBinding(ApplicationModule am, String voName, String rsiName, int rangeSize)
   {
      mAM = am;
      mVOName = voName;
      mRSIName = rsiName;
      mRangeSize = rangeSize;
   }

   /**
   * When the usage only needs one row at a time, use this constructor to create
   * an iterator binding.
   */
   public JUIteratorBinding(ApplicationModule am, String voName, String rsiName)
   {
      this (am, voName, rsiName, 1);
   }


   /**
   * When an application has a BC4J RowSet it should use this constructor.
   */
   public JUIteratorBinding(RowSetIterator rsi)
   {
      if (rsi != null) 
      {
         bindRowSetIterator(rsi, false);
         mAM = mVO.getApplicationModule();
         mRangeSize = rsi.getRangeSize();
      }
   }


   /**
   * Returns the name of this iterator binding. Iterator Binding objects are uniquely
   * identified by name in a JUFormBinding.
   */
   public final String getName()
   {
      return mName;
   }


   /**
   * *** For internal framework use only ***
   */
   public void setName(String name)
   {
      mName = name;
   }

   
   /**
   * Returns the name of the ViewObject instance of the iterator to which this iterator binding is associated.
   */
   public final String getVOName()
   {
      return mVOName;
   }

   
   /**
   * *** For internal framework use only ***
   * Returns the name of the ViewDefinition object. 
   */
   public final String getViewDefName()

   {
      return mViewDefName;
   }


   /**
   * *** For internal framework use only ***
   */
   void setViewDefName(String viewDefName)
   {
      mViewDefName = viewDefName;
   }
   
   
   /**
   * Utility method to report exceptions via the containing Form binding object.
   */
   public void reportException(boolean markDead, Exception ex)
   {
      if (markDead)
      {
         mIsAlive = false;
      }
      
      mFormBinding.reportException(ex);
   }

   //* So that I can reuse the binding object to bind to a new RSI.
   //* which is bound onto a form with controls. 
   //* - instead of dropping iterator bindings from all controls
   //* - reinstatiating a new one for each control etc.
   //*
   /**
   * Use this method to bind a new instance of RowIterator from a BC4J ViewObject
   * to this iterator. This method should be used to display data from a different
   * RowIterator of the same ViewObject type in a given form. For example, if
   * a tree is used to navigate Departments and their employees, upon selecting
   * an employee node, an application can pass the Employee node's RowIterator
   * over to this iterator binding, to update the display in another panel of Employee
   * data with the currently selected Employee. 
   * <p>
   * This method will not directly update the controls. The caller can 
   * optionally call <code>navigated(null)</code> method, with null for the Event parameter
   * to notify each control bound to this iterator binding to update it's displayed
   * value with the new iterator's current row.
   * @param iter RowIterator instance from which to display data in bound controls.
   * @param initRangeSize determines whether this iterator's range size should be 
   * adjusted to this binding's range size. This should be used to extend the range size
   * from the default in the RowIterator to whatever is required by this iterator
   * binding. For example, if a RowIterator whose range size is 1 is passed to this 
   * method and a grid control is bound to this iterator binding, then the grid
   * may need more than one row to display from the current range. So, this 
   * flag should be true in that case to allow the grid to get the full range
   * of rows to display, rather than updating its display one row at a time.
   */
   public void bindRowSetIterator(NavigatableRowIterator iter, boolean initRangeSize)
   {
      if (mRSI != null) 
      {
         if (mRSI instanceof RowSetIterator) 
         {
            ((RowSetIterator)mRSI).removeManagementListener(this);
         }
         mRSI.removeListener(this);
      }

      mRSI = iter;

      if ((mIsBound = (iter != null))) 
      {
         if (!mFindMode) 
         {
            RowSetIterator rsi = (RowSetIterator)iter;
            
            mVO = rsi.getRowSet().getViewObject();
            mRSIName = rsi.getName();
            mVOName = mVO.getName();
            rsi.addManagementListener(this);
         }
   
         mRSI.addListener(this);

         if (initRangeSize)
         {
            mRSI.setRangeSize(mRangeSize);
         }
      }
   }

   //
   // abstract RowSetListener implementation
   //
   //
   // RowSetListener implementation
   //
   
   public final boolean isIteratorMadeVisible()
   {
      return mInitVisible;
   }

   /**
    * Returns true if this IteratorBinding should notify the containing PanelBinding's RowSetListeners of RowSet events.
    **/
   public final boolean isRowSetEventsEnabled()
   {
      return mRowSetEventsEnabled;
   }

   /**
    * Set this flag if this IteratorBinding should pass on the rowset events to containing PanelBinding's RowSetListeners.
    * Applications should turn off this flag for IteratorBindings used for readonly purposes like LOVs, etc which do not
    * need any UI overrides like enabling/disabling a control etc.
    **/
   public final void setRowSetEventsEnabled(boolean flag)
   {
      mRowSetEventsEnabled = flag;
   }

   /**
   * *** For internal framework use only ***
   * <p>
   * Handles the rangeRefereshed event generated by the current RowIterator.
   * If the range size of this binding is 1, then calls updateValuesFromRow() 
   * with the current row as the argument to notify all control bindings
   * associated with this iterator binding of the change in current row.
   * If the range size is not 1, then this method calls updateValuesFromRows()
   * passing in the current range of rows to all JUCtrlRangeBinding control bindings.
   */
   public void rangeRefreshed(RangeRefreshEvent event)
   {
      JUFormBinding formBinding = getFormBinding();
      synchronized(getSyncLock())
      {
         RowIterator rsi = getNavigatableRowIterator();
         if (rsi != null)
         {
            //simply notify to update from the current row.
            boolean setToFirst = false;
            if (rsi.getCurrentRowSlot() != RowSetIterator.SLOT_VALID)
            {
               setToFirst = mInitVisible;
               if (formBinding != null) 
               {
                  javax.swing.JComponent panel = ((javax.swing.JComponent)formBinding.getPanel());
                  setToFirst =  (setToFirst || (panel != null && panel.isVisible()));
               }
            }
            Row row = null;

            if (setToFirst)
            {                   
               row = rsi.first();

            }
            else
            {
               row = getCurrentRow();
            }

            mInitVisible = true;
            //for setToFirst case, in case of Rangesize = 1, we've already sent navigation
            //event via rsi.first() call which should update the "controls" with the current
            //row.
            if (!setToFirst || mRangeSize != 1) 
            {
               updateValuesFromRows(getAllRowsInRange(), row, true);
            }
            /*
            if (mRangeSize != 1) 
            {
               mInitVisible = true;
               updateValuesFromRows(getAllRowsInRange(), row, true );
               if (setToFirst)
               {
                  rsi.first();
               }
            }
            else
            {
               if (row != null) 
               {
                  mInitVisible = true;
                  updateValuesFromRow(row);
               }
            }
            */
         }
      }

      if (mRowSetEventsEnabled) 
      {
         if (formBinding != null)
         {
            formBinding.rangeRefreshed(this, event);
         }
      }
   }

   
   /**
   * *** For internal framework use only ***
   * <p>
   * This method invokes updateRangeScrolled method on all instances of
   * JUCtrlRangeBinding objects associated with this iterator binding,
   * to notify them of the change in current range of rows.
   */
   public void rangeScrolled(ScrollEvent event)
   {
      if (mRangeSize != 1) 
      {
         synchronized(getSyncLock())
         {
            ArrayList bndList = getValueBindingList();
      
            if (bndList != null) 
            {
               for (int j = 0; j < bndList.size(); j++)
               {
                  JUCtrlValueBinding bnd = (JUCtrlValueBinding) bndList.get(j);
         
                  if (bnd instanceof JUCtrlRangeBinding)
                  {
                     bnd.updateRangeScrolled(event);
                  }
               }
            }
         }
      }

      if (mRowSetEventsEnabled) 
      {
         JUFormBinding formBinding = getFormBinding();
         if (formBinding != null)
         {
            formBinding.rangeScrolled(this, event);
         }
      }
   }

   
   /**
   * *** For internal framework use only ***
   * <p>
   * If range size of this iterator binding is not 1, 
   * this method invokes updateRowInserted method on all instances of
   * JUCtrlValueBinding objects associated with this iterator binding,
   * to notify them of the newly inserted row.
   */
   public void rowInserted(InsertEvent event)
   {
      if (mRangeSize != 1) 
      {
         synchronized(getSyncLock())
         {
            ArrayList bndList = getValueBindingList();
      
            if (bndList != null) 
            {
               for (int j = 0; j < bndList.size(); j++)
               {
                  JUCtrlValueBinding bnd = (JUCtrlValueBinding) bndList.get(j);
         
                  bnd.updateRowInserted(event);
               }
            }
         }
      }
      if (mRowSetEventsEnabled) 
      {
         JUFormBinding formBinding = getFormBinding();
         if (formBinding != null)
         {
            formBinding.rowInserted(this, event);
         }
      }
   }

   
   /**
   * *** For internal framework use only ***
   * <p>
   * If range size of this iterator binding is not 1, 
   * this method invokes updateRowDeleted method on all instances of
   * JUCtrlValueBinding objects associated with this iterator binding,
   * to notify them of the newly inserted row.
   * <p>
   * This method also sets the currency on the RowIterator to 
   * the next row (if available) or previous row (if available)
   * or simply a NO row by calling navigated() with no current row.
   */
   public void rowDeleted(DeleteEvent event)
   {
      NavigatableRowIterator iter = getNavigatableRowIterator();

      if (mRangeSize != 1) 
      {
         synchronized(getSyncLock())
         {
            ArrayList bndList = getValueBindingList();
      
            if (bndList != null) 
            {
               for (int j = 0; j < bndList.size(); j++)
               {
                  JUCtrlValueBinding bnd = (JUCtrlValueBinding) bndList.get(j);
         
                  bnd.updateRowDeleted(event);
               }
            }
         }
      }
      
      if (iter.getCurrentRowSlot() == RowSetIterator.SLOT_DELETED)
      {
         if (iter.hasNext())
         {
            iter.next();
         }
         else if (iter.hasPrevious())
         {
            iter.previous();
         }
         else
         {
            if (mRowSetEventsEnabled) 
            {
               JUFormBinding formBinding = getFormBinding();
               if (formBinding != null)
               {
                  formBinding.rowDeleted(this, event);
               }
            }
            //try to handle no row situation.
            navigated(new NavigationEvent(iter, null, null));
            return;
         }
      }
      
      if (mRowSetEventsEnabled) 
      {
         JUFormBinding formBinding = getFormBinding();
         if (formBinding != null)
         {
            formBinding.rowDeleted(this, event);
         }
      }
   }

   /**
   * *** For internal framework use only ***
   * <p>
   * Invokes updateValuesFromRow() to notify all control bindings of
   * a change in an attribute in the row.
   */
   public void rowUpdated(UpdateEvent event)
   {
      synchronized(getSyncLock())
      {
         updateValuesFromRow(event.getRow());
      }
      if (mRowSetEventsEnabled) 
      {
         JUFormBinding formBinding = getFormBinding();
         if (formBinding != null)
         {
            formBinding.rowUpdated(this, event);
         }
      }
   }
   
   /**
   * *** For internal framework use only ***
   * <p>
   * Calls updateNavigated() for all JUCtrlRangeBinding instances associated
   * with this iterator binding object, or calls updateValuesFromRow() on 
   * all other control binding instances, passing in the current row instance
   * from the RowIterator.
   */
   public void navigated(NavigationEvent event)
   {
      synchronized(getSyncLock())
      {
         ArrayList bndList = getValueBindingList();
         if (bndList != null) 
         {
            Row r = getCurrentRow();
            for (int j = 0; j < bndList.size(); j++)
            {
               JUCtrlValueBinding bnd = (JUCtrlValueBinding) bndList.get(j);
      
               if (bnd instanceof JUCtrlRangeBinding)
               {
                  ((JUCtrlRangeBinding)bnd).updateNavigated(event);
               }
               else 
               {
                  bnd.updateValuesFromRow(r);
               }
            }
         }
      }
      if (mRowSetEventsEnabled) 
      {
         JUFormBinding formBinding = getFormBinding();
         if (formBinding != null)
         {
            formBinding.navigated(this, event);
         }
      }
   }


   /**
   * Calls updateValuesFromRows() on each instance of JUCtrlRangeBinding object
   * associated with this iterator binding object. These objects are then responsible for
   * updating their display with the latest set of rows.
   */
   void updateValuesFromRows(Row[] rows, Row row, boolean clear)
   {
      ArrayList bndList = getValueBindingList();

      if (bndList != null) 
      {
         Object bnd;
         for (int j = 0; j < bndList.size(); j++)
         {
            bnd = bndList.get(j);
   
            if (bnd instanceof JUCtrlRangeBinding)
            {
               ((JUCtrlRangeBinding)bnd).updateValuesFromRows(rows, clear);
            }
            else if (row != null) 
            {
               ((JUCtrlValueBinding)bnd).updateValuesFromRow(row);
            }
         }
      }
   }


   /**
   * Calls updateValueFromRow() on each instance of JUCtrlValueBinding objects
   * associated with this iterator binding object. These control binding objects are
   * responsible for updating their display with values from the given Row.
   */
   void updateValuesFromRow(Row row)
   {
      ArrayList bndList = getValueBindingList();

      if (bndList != null) 
      {
         for (int j = 0; j < bndList.size(); j++)
         {
            ((JUCtrlValueBinding)bndList.get(j)).updateValuesFromRow(row);
         }
      }
   }
   
   /**
   * *** For internal framework use only ***
   */
   public final Object getSyncLock()
   {
      return mAM.getSyncLock();
   }
   
   
   //
   // RowSetManagementListener implementation
   //

   /**
   * *** For internal framework use only ***
   * Notifies all control bindings that the BC4J iterator has been reset and there
   * is no current row at this time.
   */
   public void iteratorReset(RowSetManagementEvent event)
   {
      // show no row
      navigated(new NavigationEvent(getRowSetIterator(), null, null));
   }


   /**
   * *** For internal framework use only ***
   * Resets the internal state of this binding object and marks it as unusable.
   */
   public void iteratorClosed(RowSetManagementEvent event)
   {
      synchronized(getSyncLock())
      {
         // mAM = null;
         mVO = null;
         mRSI = null;
   
         mIsAlive = false;
      }
   }


   //
   // Accessors
   //

   /**
   * Returns the instance of ApplicationModule in which this iterator binding has an associated iterator.
   */
   public ApplicationModule getApplicationModule()
   {
      return mAM;
   }

   
   /**
   * Returns the instance of ViewObject of the RowIterator to which this iterator binding is associated.
   */
   public ViewObject getViewObject()
   {
      synchronized(getSyncLock())
      {
         //if the rsi was killed, or 
         //if this iterator's rsi (by name) was bound to null rsi, then
         //return null.
         if (!mIsAlive)
         {
            return null;
         }
      
         if (mVO == null)
         {
            try
            {
               mVO = mAM.findViewObject(mVOName);
   
               if (mVO == null)
               {
                  if (mViewDefName == null)
                  {
                     throw new NoObjException(NoObjException.TYP_VIEW_OBJECT, mVOName);
                  }
                  
                  mVO = mAM.createViewObject(mVOName, mViewDefName);
               }
            }   
            catch(Exception ex)
            {
               reportException(true /*markDead*/, ex);
            }
         }

         return mVO;
      }
   }

   /**
   * Sets this iterator binding and it's associated RowIterator's range size to the
   * greater of this either the iterator's range size and the given range size. If either is -1,
   * then that takes precedence, so that range size = all rows.
   */
   public void resolveRangeSize(int rangeSize)
   {
      int myRange = mRangeSize;
      if (myRange != -1 && myRange != rangeSize) 
      {
         if (rangeSize == -1) 
         {
            myRange = -1;
         }
         else
         if (rangeSize > myRange) 
         {
            myRange = rangeSize;
         }

         if (myRange != mRangeSize) 
         {
            RowSetIterator rsi = getRowSetIterator();
            if (rsi != null) 
            {
               mRangeSize = myRange;
               rsi.setRangeSize(myRange);
            }
         }
      }
   }

   
   /**
   * Returns the current data RowSetIterator that holds rows with which this iterator binding
   * object and its associated control-bindings are working.
   */
   public RowSetIterator getRowSetIterator()
   {
      RowSetIterator rsi = (RowSetIterator)((mFindMode) ? mOldRSI : mRSI);
      
      if (rsi != null) 
      {
         return rsi;
      }

      synchronized(getSyncLock())
      {
         if (!(mIsAlive && mIsBound))
         {
            return null;
         }
         
         if (rsi == null)
         {
            try
            {
               ViewObject vo = getViewObject();

               if (vo == null)
               {
                  return null;
               }
   
               if (mRSIName == null)
               {
                  rsi = vo;
               }
               else
               {
                  rsi = vo.findRowSetIterator(mRSIName);
      
                  if (rsi == null)
                  {
                     rsi= vo.createRowSetIterator(mRSIName);
                  }
               }
      
               if (mFindMode) 
               {
                  mOldRSI = rsi;
               }
               else
               {
                  mRSI = rsi;
                  rsi.addListener(this);
                  ((RowSetIterator)rsi).addManagementListener(this);
                  //doing this here means the last iterator binding get's it settings
                  //into the RSI. This is a problem if more-than-one bindings talk to the same
                  //rsi - like if a grid and a navigationbar are looking at the same rsi, both
                  //need to share this iterator, otherwise, whichever iterator-binding is
                  //created last will have it's settings forced onto the RSI.
                  int rangeSize = rsi.getRangeSize();
                  if (rangeSize > mRangeSize) 
                  {
                     //only narrow the rangeset. Do not try to restrict rangeSize if MT gives a larger RangeSize.
                     //also if MT is set to -1, honor that.
                     rsi.setRangeSize(mRangeSize);
                  }
                  //initRowSetIterator(mRSI);
               }
            }
            catch(Exception ex)
            {
               reportException(true /*markDead*/, ex);
            }

         }
   
         return (RowSetIterator)rsi;
      }
   }

   /**
   * Returns the current RowIterator, which can be a data RowSetIterator or a find mode ViewCriteria
   * based on the find mode.
   */
   public NavigatableRowIterator getNavigatableRowIterator()
   {
      if (mFindMode) 
      {
         if (mVC == null) 
         {
            ViewCriteria vc = getViewObject().getViewCriteria();
            if (vc == null) 
            {
               vc = new ViewCriteria(mVO);
            }
            mVC = vc;
         }
         return mVC;
      }
      return getRowSetIterator();
   }

   /**
   * Sets this iterator to findMode or not. If mode = false, then it applies the
   * current ViewCriteria to this binding's ViewObject to execute the criteria.
   */
   final void setFindMode(boolean mode)
   {
      if (mode != mFindMode) 
      {
         mFindMode = mode;
         NavigatableRowIterator iter;
         if (mode) 
         {
            iter = getNavigatableRowIterator();
            mOldRSI = mRSI;
         }
         else
         {
            //was true before. now turning to false to execute, so set criteria
            if (mVC != null) 
            {
               mVC.trimNoDataRows();
            }
            getViewObject().applyViewCriteria(mVC);
            mVC = null; //get it from VO next time.
            iter = mOldRSI;

            ArrayList bndList = getValueBindingList();
            if (bndList != null) 
            {
               JUControlBinding bnd;
               for (int j = 0; j < bndList.size(); j++)
               {
                  bnd = (JUControlBinding) bndList.get(j);
         
                  if (!bnd.isControlQueriable()) 
                  {
                     //bnd.enableControlForFindMode();
                  }
               }
            }
         }
         
         bindRowSetIterator(iter, false);

         if (mode) 
         {
            if (iter.getRowCount() == 0) 
            {
               Row newRow = iter.createRow();

               if (newRow != null)
               {
                  iter.insertRow(newRow);
               }
            }
            else
            {
               iter.first();
            }

            ArrayList bndList = getValueBindingList();
            if (bndList != null) 
            {
               JUControlBinding bnd;
               for (int j = 0; j < bndList.size(); j++)
               {
                  bnd = (JUControlBinding) bndList.get(j);
         
                  if (!bnd.isControlQueriable()) 
                  {
                     //bnd.disableControlForFindMode();
                  }
               }
            }
            rangeRefreshed(null); //force a repaint of rows.
         }
      }
   }

   /**
   * Returns true if this iterator binding is in find mode.
   */
   public final boolean isFindMode()
   {
      return mFindMode;
   }


   /**
   * Executes the query or the RowSet behind this iterator binding object.
   */
   public void executeQuery()
   {
      synchronized(getSyncLock())
      {
         if (mIsAlive && mIsBound)
         {
            try
            {
               getRowSetIterator().getRowSet().executeQuery();
            }
            catch(Exception ex)
            {
               reportException(false /*markDead*/, ex);
            }
         }
      }
   }

   
   /**
   * Executes the query or the RowSet behind this iterator binding object if not already executed.
   */
   public void executeQueryIfNeeded()
   {
      synchronized(getSyncLock())
      {
         if (mIsAlive && mIsBound)
         {
            RowSetIterator rsi = getRowSetIterator();
            if (rsi != null)
            {
               RowSet rs = rsi.getRowSet();
      
               if (!rs.isExecuted())
               {
                  rs.executeQuery();
               }
            }
         }
      }
   }

   
   /**
   * Returns the current row of the iterator with which this binding object is associated. In find mode,
   * this returns an instance of ViewCriteriaRow.
   */
   public Row getCurrentRow()
   {
      synchronized(getSyncLock())
      {
         if (mIsAlive && mIsBound)
         {
            try
            {
               return getNavigatableRowIterator().getCurrentRow();
            }
            catch(Exception ex)
            {
               reportException(false /*markDead*/, ex);
            }
         }

         return null;
      }
   }

   
   /**
   * Returns the row of given range index.
   *
   * @param rangeIndex The range index of the row.
   */
   public Row getRowAtRangeIndex(int rangeIndex)
   {
      synchronized(getSyncLock())
      {
         if (mIsAlive && mIsBound)
         {
            try
            {
               return getNavigatableRowIterator().getRowAtRangeIndex(rangeIndex);
            }
            catch(Exception ex)
            {
               reportException(false /*markDead*/, ex);
            }
         }

         return null;
      }
   }

   
   /**
   * Returns an array of rows in the current range of the current RowIterator.
   */
   public Row[] getAllRowsInRange()
   {
      synchronized(getSyncLock())
      {
         if (mIsAlive && mIsBound)
         {
            try
            {
               return getNavigatableRowIterator().getAllRowsInRange();
            }
            catch(Exception ex)
            {
               reportException(false /*markDead*/, ex);
            }
         }

         return null;
      }
   }

   
   /**
   * Return form binding object of this iterator binding's container.
   */
   public JUFormBinding getFormBinding()
   {
      return mFormBinding;
   }


   /**
   * *** For internal framework use only ***
   */
   public void setFormBinding(JUFormBinding formBnd)
   {
      mFormBinding = formBnd;
   }

   /**
   * Helper method to return the JUApplication from this binding's FormBinding.
   */
   public final JUApplication getApplication()
   {
      return (mFormBinding != null) ? mFormBinding.getApplication() : null;
   }

   
   //
   // VALUE binding mgmt
   //
   
   /**
   * Returns a list of JUCtrlValueBinding objects that are associated with this iterator binding.
   * Returns null if no control binding is registered with this object.
   */
   public ArrayList getValueBindingList()
   {
      return (ArrayList)((mValueBindingList != null) ? mValueBindingList.clone() : null);
   }

   /**
   * Adds the given control binding object to its list.
   */
   public void addValueBinding(JUCtrlValueBinding bnd)
   {
      synchronized(getSyncLock())
      {
         if (mValueBindingList == null)
         {
            mValueBindingList = new ArrayList(4);
         }
   
         mValueBindingList.add(bnd);
      }
   }

   /**
   * Removes the given control binding object from its list. Returns
   * true if remove was successful.
   */
   public boolean removeValueBinding(JUCtrlValueBinding bnd)
   {
      synchronized(getSyncLock())
      {
         if (mValueBindingList == null)
         {
            return false;
         }
   
         return mValueBindingList.remove(bnd);
      }
   }

   
   
   //
   // ACTION binding mgmt
   //
   
   /**
   * Returns a list of JUCtrlActionBinding objects that are associated with this iterator binding.
   * Returns null if no action control binding is registered with this object.
   */
   public ArrayList getActionBindingList()
   {
      return (ArrayList)((mActionBindingList != null) ? mActionBindingList.clone() : null);
   }

   
   /**
   * Adds the given action control binding object to its list.
   */               
   public void addActionBinding(JUCtrlActionBinding bnd)
   {
      synchronized(getSyncLock())
      {
         if (mActionBindingList == null)
         {
            mActionBindingList = new ArrayList(4);
         }
   
         mActionBindingList.add(bnd);
      }
   }
   
   /**
   * Removes the given action control binding object from its list. Returns
   * true if remove was successful.
   */
   public boolean removeActionBinding(JUCtrlActionBinding bnd)
   {
      synchronized(getSyncLock())
      {
         if (mActionBindingList == null)
         {
            return false;
         }
   
         return mActionBindingList.remove(bnd);
      }
   }

   /**
   * *** For internal framework use only ***
   */
   public RowSetIterator getLovRowSetIterator()
   {
      if (mRSIName == null)
      {
         mRSIName = mName;
      }   
      return getRowSetIterator();
   }

   //do we need another version of release that will also "remove" the ViewObjet/RSIs?
   public void release()
   {
      ArrayList al;
      if (mValueBindingList != null) 
      {
         al = (ArrayList)mValueBindingList.clone();
         JUCtrlValueBinding ctrl;
         for (int i = 0; i < al.size(); i++)
         {
            ctrl = (JUCtrlValueBinding)al.get(i);
            ctrl.release();
         }
         mValueBindingList = null;
      }

      if (mActionBindingList != null) 
      {
         al = (ArrayList)mActionBindingList.clone();
         JUCtrlActionBinding actBind;
         for (int i = 0; i < al.size(); i++)
         {
            actBind = (JUCtrlActionBinding)al.get(i);
            actBind.release();
         }
         mActionBindingList = null;
      }

      bindRowSetIterator(null, false);
      mFormBinding.removeIterBinding(getName());
      mFormBinding = null;
   }

}
