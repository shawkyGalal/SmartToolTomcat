/*
 * @(#)GraphDataFromRow.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.uicli.jui;

import oracle.dss.graph.Graph;
import oracle.jbo.uicli.binding.JUIteratorBinding;

public class GraphDataFromRow
      extends JUGraphBinding
{
    
    private int mSeriesLabelColumnIndex = -1;

	private int numberOfColumnValuesPerMarker = 1;

	private String[] colLabels;
    
    public GraphDataFromRow(Graph control, 
            JUIteratorBinding iterBinding, 
            String[] dataValueAttrNames, String[] colLabels)
    {
        super(control, iterBinding, dataValueAttrNames);

		// last column used as series label
		mSeriesLabelColumnIndex = dataValueAttrNames.length -1; 

		setColumnLabels(colLabels);
    } 

	public void setColumnLabels(String[] labels)
	{
		this.colLabels = labels;
	}

	public String[] getColumnLabels()
	{
		return this.colLabels;
	}

    
    // implement JUGraphBinding abstract methods.
    protected String getColumnLabel(int i)
    {
		return colLabels[i]; 
    }

    protected int getColumnCount()
    {
        
        String[] s = super.getAttributeNames();

		return s.length - 1; // last column is series label
    }


	protected String getRowLabel(int i)
    {
		int rangeIndex = rowIndexToRangeIndex(i);

		Object val =  getAttributeFromRow(rangeIndex, mSeriesLabelColumnIndex);
        
        if (val == null)
            val = emptyString;
            
        return val.toString();
    }

    protected long getRowCount()
    {
        return getEstimatedRowCount(); 
    }


    protected Object getValue(int row, int col)
    {
		int rangeIndex = rowIndexToRangeIndex(row);

		Object val =  getAttributeFromRow(rangeIndex, col);
        
        if (val == null)
            val = emptyString;
            
        if ( val instanceof oracle.jbo.domain.Number)
            val = ((oracle.jbo.domain.Number)val).getData();

        return val;
    }

	// implement JUGraphBinding
    protected void notifyView()
	{
	}

}




