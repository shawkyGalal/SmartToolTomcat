/*
 * @(#)JUTreeDefaultMouseListener.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.uicli.jui;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import javax.swing.JTree;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.TreePath;
import oracle.jbo.RowSetIterator;
import oracle.jbo.uicli.binding.JUIteratorBinding;
//import oracle.jbo.uicli.UIMessageBundle;

/**
 * A sample mouse adapter that could be wired up with a JUTreeBinding to
 * handle double-click on the tree nodes: The selected row is made current
 * in the associated row iterator. This is used to allow JTree to be used
 * as a row-navigation control.
 */
public class JUTreeDefaultMouseListener extends MouseAdapter 
{
  // the panelBinding containing the iterators you need to sync with
  JUPanelBinding panelBinding;
  // hashmap used to store node information and target iterator names
  HashMap hm = new HashMap(10);
  // a list of keys already being used, necessary to avoid recursion in a tree containing selfreference joins.
  ArrayList usedKeys = null;
  // by default only double click enforces navigation
  int clickCount = 2;

  RowSetIterator origrsi = null;
//  String iterName = null;
  JUIteratorBinding iter = null;
  
  /**
  *
  *  Constructor.
  *  
  *  @param panelBinding The panelBinding containing the iterators for which the tree needs to sync.
  *  @param rulesactions defines an target iterator per rule.<B>
  *  example : new String [][] { { "NodeRule1", "DeptViewIter" }, { "NodeRule2", "EmpView1Iter" } } });
  */                    
  public JUTreeDefaultMouseListener(JUPanelBinding panelBinding, String [][] rulesactions)
  {  
     this.panelBinding = panelBinding;
     for (int i=0; i < rulesactions.length; i++)
     {
        hm.put(rulesactions[i][0], rulesactions[i][1]);
     }
  }

  /**
  *
  *  Constructor
  *  
  *  @param panelBinding The panelBinding containing the iterators for which the tree needs to sync.
  *  @param rulesactions defines an target iterator per rule.<B>
  *  example : new String [][] { { "NodeRule1", "DeptViewIter" }, { "NodeRule2", "EmpView1Iter" } } });
  *  @param boolean defining doubleclick or not (true is  the default)
  */   
  public JUTreeDefaultMouseListener(JUPanelBinding panelBinding, String [][] rulesactions, boolean doubleClick)
  {
    this(panelBinding, rulesactions);
    setDoubleClick(doubleClick);
  }

  /**
  *
  *  Sets the panelBinding containing the iterators for which the tree needs to sync.
  *
  *  @param panelBinding The panelBinding.
  *
  *  @see getPanelBinding
  */
  public void setPanelBinding(JUPanelBinding panelBinding)
  {
     this.panelBinding = panelBinding;
  }

  /**
  *
  *  Gets the panelBinding containing the  iterators for which tree needs to sync.
  *
  *  @return panelBinding The panelBinding.
  *  
  *  @see setPanelBinding
  */
  public JUPanelBinding getPanelBinding()
  {
     return panelBinding;
  }

  /**
  *  Defines one target iterator per rule.
  *
  *  @param rulesactions Defines an target iterator per rule.
  *  example : new String [][] { { "NodeRule1", "DeptViewIter" }, { "NodeRule2", "EmpView1Iter" } } });
  *
  *  @see getRulesActions
  */  
  public void setRulesActions(String [][] rulesactions)
  {  
     hm.clear();
  }

  /**
  *  Defines the target iterator per rule definition.
  *
  *  @return rulesactions Defines an target iterator per rule.<B>
  *
  *  @see setRulesActions
  */  
  public String [][] getRulesActions()
  {
    Iterator it  = hm.keySet().iterator();
    String [][] retvalue = new String [hm.size()][2];
    
    for (int i=0; it.hasNext(); i++)
    {
       Object o = it.next();
       retvalue[i][0] = o.toString();
       retvalue[i][1] = hm.get(o).toString();
    }

    return retvalue;
  }

  /**
  * 
  *  Controls whether a double-click will activate the events (true is the default).
  *
  *  @param doubleClick Specifies whether double-clicking is required.
  *
  *  @see isDoubleClick
  */
  public void setDoubleClick(boolean doubleClick)
  {
     clickCount = doubleClick ? 2 : 1;
  }

  /**
  * 
  *   will a double click activate the events ? 
  *
  *  @return doubleClick Specifies whether double-clicking is required.
  * 
  *  @see setDoubleClick
  */
  public boolean isDoubleClick()
  {
     return (clickCount == 2);
  }

  /*
  *
  *  Invoked when a mouse button has been pressed on a component.
  *
  *  @param An event which indicates that a mouse action occurred in a component. 
  *
  *  @see java.awt.event.MouseListener
  */
  public void mousePressed(MouseEvent e) 
  {
     JTree tree = (JTree)e.getComponent();
        
     int selRow = tree.getRowForLocation(e.getX(), e.getY());
     TreePath selPath = tree.getPathForLocation(e.getX(), e.getY());
     if(selRow != -1) 
     {
         if(e.getClickCount() == clickCount) 
         {
            usedKeys = new ArrayList(5);
            for(int i=0; i < selPath.getPathCount(); i++)
            {
               JUTreeNodeBinding tnb = (JUTreeNodeBinding)((DefaultMutableTreeNode)selPath.getPathComponent(i)).getUserObject();

               if (tnb != null)
               {
                  if (origrsi != null && iter != null)
                  {
                    iter.bindRowSetIterator(origrsi, false);
                    iter.rangeRefreshed(null);
                  }
                  
                  //RowSetIterator rsi = tnb.getParentRowSetIterator();
                  RowSetIterator rsi = tnb.getParentRowSetIterator();
                  if (rsi == null)
                     continue;
  
                 if (rsi != null)
                 {
                   Object obj = tnb.getHierTypeBinding().getName() ;
                   if (obj != null && hm.containsKey(obj) && !usedKeys.contains(obj))
                   {
                     usedKeys.add(obj);
                     String iterName = (String)hm.get(obj);

                     iter = panelBinding.findIterBinding(iterName);
                     origrsi = iter.getRowSetIterator();
                     
                     if (iter == null) 
                        continue;
                  
                     panelBinding.bindRowSetIterator(iterName, rsi);
                    // panelBinding.displayStatus(iter, UIMessageBundle.STR_EXECUTING_QUERY, null);
                   }
                 }
               }         
            }
          }     
      }
  }
}
  
