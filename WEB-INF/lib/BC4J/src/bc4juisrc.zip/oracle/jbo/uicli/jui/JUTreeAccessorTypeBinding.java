/*
 * @(#)JUTreeAccessorTypeBinding.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.uicli.jui;

import java.util.HashMap;
import javax.swing.Icon;
import oracle.jbo.uicli.binding.JUCtrlHierTypeBinding;

/**
 * Implements rules that govern display of rows of a given ViewObject type in a JTree.
 * This class determines the attribute to display for each row and which accessor (if any)
 * to expand when the coresponding node is expanded.
 *
 * @see oracle.jbo.RowIterator
 * @see oracle.jbo.uicli.jui.JUTreeBinding
 * @see javax.swing.JTree
 */
public class JUTreeAccessorTypeBinding
       extends JUCtrlHierTypeBinding
{
   public JUTreeAccessorTypeBinding()
   {
   }
   
   /*
   * Constructor without any custom icons.
   * @param voTypeName Fully qualified name of the definition/type of the ViewObject for this node.
   * @param childAttrName Name of the attribute of this viewobject to display in the tree node.
   * @param childAccessorName Name of the Accessor attribute of this viewobject to execute to display child nodes of this node.
   */
   public JUTreeAccessorTypeBinding(String typeBindingName, String voType, String childAttrName, String childAccessorName)
   {
      this(typeBindingName, voType, childAttrName, childAccessorName, null, null, null);
   }

   /*
   * @deprecate since 5.0 use the constructor with typeBindingName instead
   */
   public JUTreeAccessorTypeBinding(String voType, String childAttrName, String childAccessorName)
   {
      this(null, voType, childAttrName, childAccessorName, null, null, null);
   }

   /*
   * Constructor with any custom icons. Use this method to create an instance of this node-type
   * if custom-icons are to be displayed when rendering nodes of this node type.
   *
   * @param voTypeName Fully qualified name of the definition/type of the ViewObject for this node.
   * @param childAttrName Name of the attribute of this viewobject to display in the tree node.
   * @param childAccessorName Name of the Accessor attribute of this viewobject to execute to display child nodes of this node.
   * @param leafIcon Used to display nodes when it is the leaf node.
   * @param openIcon Used to display nodes when they are in expanded state
   * @param closedIcon Used to display nodes when they are in closed state.
   */
   public JUTreeAccessorTypeBinding(String typeBindingName,
                                    String voType, String childAttrName, String childAccessorName, 
                                    Icon leafIcon, Icon openIcon, Icon closedIcon)
   {
      super(voType, null, voType, childAccessorName, childAttrName, leafIcon, openIcon, closedIcon);
      setName(typeBindingName);
   }

   
   /**
   * *** For internal framework use only ***
   */
   public void init(HashMap initValues)
   {
      super.init(initValues);

      mDiscrColumnValue = mVODefName;
   }
   
   /**
   * Returns true if the given string matches the fully-qualified ViewObject definition name
   * that this node-type is supposed to display.
   */
   public boolean matchViewObjectType(String str)
   {
      return mDiscrColumnValue.equals(str);
   }

   /**
   * Returns false as this type of node does not support discriminator columns.
   */
   public boolean isDiscrColumnType()
   {
      return false;
   }
}
