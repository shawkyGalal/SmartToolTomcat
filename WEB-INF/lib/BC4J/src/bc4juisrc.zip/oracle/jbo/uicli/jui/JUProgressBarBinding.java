/*
 * @(#)JUProgressBarBinding.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.uicli.jui;

import javax.swing.BoundedRangeModel;
import javax.swing.DefaultBoundedRangeModel;
import javax.swing.JProgressBar;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import oracle.jbo.RowSetIterator;
import oracle.jbo.common.DebugDiagnostic;
import oracle.jbo.uicli.binding.JUIteratorBinding;

/**
 * Implements binding a JProgressBar control with a BC4J RowSetIterator/ViewObject. Use this binding to
 * use JProgressBar to navigate the current row in a RowSetIterator/ViewObject.
 */
public class JUProgressBarBinding extends JUBoundedRangeBinding  implements ChangeListener
{

   /**
   * Binds a JProgressBar control to a BC4J ViewObject such that JProgressBar can be used to 
   * navigate rows in the ViewObject. Optionally an application can control the
   * scrolling of the current row into the current range of rows and use estimated
   * row count APIs to calculate the maximum row count for the display.
   * @param formBinding The containing JUPanelBinding in which the given iterator binding
   * would be found/created.
   * @param control JProgressBar control with which to bind a BC4J ViewObject.
   * @param voInstanceName Name of the instance of the ViewObject in a BC4J ApplicationModule.
   * @param voIterName Runtime instance name of the iterator in the ViewObject (optional).
   * @param voIterBindingName Instance name of the iterator binding that uniquely identifies an
   * iterator binding object used to read/write data in this given JUPanelBinding instance.
   * @param scrollCurrentRow When true, scrolls the current row into the current range of the ViewObject.
   * @param useEstRC When true, uses getEstimatedRowCount() to calculate the max value for the control.
   */
   public static BoundedRangeModel createViewBinding(JUPanelBinding formBinding, 
                                               JProgressBar       control,
                                               String        voInstanceName,
                                               String        voIterName, /*temporarily taking nulls for this*/
                                               String        voIterBindingName,
                                               boolean       scrollCurrentRow,
                                               boolean       useEstRC)
   {
      if (!JUIUtil.inDesignTime())
      {
         JUProgressBarBinding bind = new JUProgressBarBinding(control, 
                                       formBinding.getRowIterBinding(voInstanceName, voIterName, voIterBindingName),
                                       scrollCurrentRow, true /*deferAssignValues*/, useEstRC);
         formBinding.addIteratorChangedListener(bind);
         bind.refreshControl();
         return bind.getModelImpl(control);
      }
      else
      {
         try
         {
            Class clazz = Class.forName("oracle.jbo.dt.ui.jui.propertyeditors.dtmodels.DTJProgressBarBinding");
            java.lang.reflect.Constructor constructor = clazz.getConstructors()[0];
            Object [] args = { voInstanceName, new Boolean(scrollCurrentRow), new Boolean(useEstRC) };
            Object object = constructor.newInstance(args);
            return (BoundedRangeModel)object;
         }
         catch (Exception e)
         {
            DebugDiagnostic.printStackTrace(e);
            return null;
         }
      }
   }
   
   /**
   * @deprecated since 9.0.2 use createViewBinding method instead.
   */
   public static BoundedRangeModel getInstance(JUPanelBinding formBinding, 
                                               JProgressBar       control,
                                               String        voInstanceName,
                                               String        voIterName, /*temporarily taking nulls for this*/
                                               String        voIterBindingName,
                                               boolean       scrollCurrentRow,
                                               boolean       useEstRC)
   {
      return createViewBinding(formBinding, control, voInstanceName, voIterName, voIterBindingName, scrollCurrentRow, useEstRC);
   }

   /**
   * Binds a JProgressBar control to a BC4J ViewObject such that JProgressBar can be used to 
   * navigate rows in the ViewObject. Optionally an application can control the
   * scrolling of current row into the current range of rows and use estimated
   * row count APIs to calculate the maximum row count for the display.
   * @param formBinding The containing JUPanelBinding in which the given iterator binding
   * would be found/created.
   * @param sb JProgressBar control with which to bind a BC4J ViewObject.
   * @param iterBinding An iterator Binding with which this control is associated.
   * @param scrollCurrentRow When true, scrolls the current row into the current range of the ViewObject.
   * @param deferAssignValues When true, defers the assignement of JProgressBar values till the ViewObject query is executed
   * @param useEstRC When true, uses getEstimatedRowCount() to calculate the max value for the control.
   */
   public JUProgressBarBinding(JProgressBar sb, JUIteratorBinding iterBinding, boolean scrollCurrRow, 
                          boolean deferAssignValues, boolean useEstRC)
   {
      super(sb, iterBinding, scrollCurrRow, deferAssignValues, useEstRC);

      init(sb);
      if (deferAssignValues && ((RowSetIterator)getRowIterator()).getRowSet().isExecuted())
      {
         assignValues();
      }
   }


   private void init(JProgressBar sb)
   {
      mSBModel = getModelImpl(sb);

      if (sb != null)
      {
         if (mSBModel != sb.getModel())
         {
            sb.setModel(mSBModel);
         }
         sb.addChangeListener(this);
         sb.addFocusListener(new JUSVFocusAdapter(this));
      }
   }

   
   /**
   * Registers the BoundedRangeModel that this binding works with. If the ProgressBar
   * has a model, this method registers that with this binding and returns the model.
   * If the control or model is null, then this method creates a DefaultBoundedRangeModel
   * and returns that.
   */
   protected BoundedRangeModel getModelImpl(JProgressBar sb)
   {
      BoundedRangeModel sbModel = null;

      if (sb != null)
      {
         sbModel = sb.getModel();
      }

      if (sbModel == null)
      {
         sbModel = new DefaultBoundedRangeModel();
      }

      return sbModel;
   }

   
   /**
   * Sets the current value, extent, minimum, and maximum values for the ProgressBar. 
   */
   public void setValues(int val, int ext, int minVal, int maxVal)
   {
      if (mSBModel != null) 
      {
         try
         {
            mSettingValue = true;
            mSBModel.setRangeProperties(val, ext, minVal, maxVal, false);
         }
         finally
         {
            mSettingValue = false;
         }
      }
   }

   /**
   * Sets the control values from the RowSetIterator to which it is bound. This method
   * sets the minor tick spacing to 1 and snap-to ticks boolean flag to True in the
   * associated JProgressBar control.
   */
   protected void initFromRSI()
   {
      super.initFromRSI();

      //adjust mMax for JProgressBar as they need the last row number as max.
      mMin--;
      mMax--;
   }

   
   
   /**
   * Sets the current value in the ProgressBar to the given value 'val'.
   */
   public void setRangeScrollValue(int val)
   {
      ((JProgressBar) getControl()).setValue(val);
      //mSBModel.setValue(val);
   }

   
   /**
   * Sets the current values for this ProgressBar.
   */
   public void setRangeScrollValues(int val, int ext, int minVal, int maxVal)
   {
      //setRangeScrollValue(val);
      setValues(val, ext, minVal, maxVal);
   }

   
   /**
   * When th current value changes in the ProgressBar, this event handler method updates
   * the associated ViewObject's currency.
   */
   public void stateChanged(ChangeEvent e) 
   {
      if (!mSettingValue && !mSBModel.getValueIsAdjusting())
      {
         super.setRangeScrollValue(((JProgressBar)getControl()).getValue());
      }
   }

}

