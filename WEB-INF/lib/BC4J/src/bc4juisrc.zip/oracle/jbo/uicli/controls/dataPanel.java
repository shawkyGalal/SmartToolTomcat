
/*
 * @(#)dataPanel.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

/**
*   This is a dummy implementation, to support design time support for drag and drop
*   This class is being used when you drop in a dataPanel
*/
package oracle.jbo.uicli.controls;

import javax.swing.JPanel;
import javax.swing.border.EtchedBorder;
import oracle.jbo.uicli.jui.JUPanelBinding;

public class dataPanel extends JPanel implements JClientPanel 
{
  private JUPanelBinding panelBinding = null;

  /**
   * 
   * The default constructor for panel
   */
  public dataPanel()
  {
     setBorder(new EtchedBorder());
  }

  /**
   * 
   * Constructor that takes a shared panel binding
   */
  public dataPanel(JUPanelBinding binding)
  {
    setPanelBinding(binding);
  }

  /**
   * 
   * JUPanel implementation
   */
  public JUPanelBinding getPanelBinding()
  {
    return panelBinding;
  }

  public void setPanelBinding(JUPanelBinding binding)
  {
     panelBinding = binding;
  }
}

