/*
 * @(#)JUPanelValidationListener.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.uicli.jui;

/**
 * Implemented by classes that are interested in performing 
 * typically lightweight, client-side validation for an attribute,
 * a row, or the whole transaction. 
 * <p>
 * When the Event Inspector is used to generate PanelValidationEvent code on a 
 * PanelBinding object, it adds this interface to the list of interfaces the
 * concerned class implements and also implements the three event methods.
 */
public interface JUPanelValidationListener extends java.util.EventListener
{
   /**
   * Invoked before a JClient Binding object calls Row.setAttribute()
   * to update a value from a binding object into the corresponding
   * Row object. 
   * <p>
   * Applications should perform lightweight, attribute-data validation (for 
   * example, matching a value with a small set of values or uppercasing all entries
   * etc.) at this level before the value is passed on to BC4J. Note that  
   * such a validation should be duplicated on the BC4J side too as other clients
   * or APIs may modify the same attribute. This duplication is usually necessary
   * when a client needs immediate feedback of an error rather than going over
   * to the middle-tier (in a multi-tier platform) and get any errors.
   */
   void beforeSetAttribute(JUPanelValidationEvent ev);

   /**
   * Invoked before a JClient binding object calls a navigation event
   * to display the next row data in the JClient controls.
   * <p>
   * Applications should perform lightweight, row-data validation (for example,                              
   * inter-attribute validation etc.) at this level before the value is passed on to BC4J. 
   * Note that such a validation should be duplicated on the BC4J side to allow other clients
   * or APIs to modify the same attribute. This duplication is usually necessary
   * when a client needs immediate feedback of an error rather than going over
   * to the middle-tier (in a multi-tier platform) and get any errors.
   */
   void beforeCurrencyChange(JUPanelValidationEvent ev);

   /**
   * Invoked before a JClient binding object calls commit() on
   * the transaction to save any pending changes into the database.
   * <p>
   * Applications should perform lightweight, panel-level validation (for example,                              
   * validating that all desired values are filled in etc.) at this level before 
   * the values are passed on to BC4J. Note that 
   * such a validation should be duplicated on the BC4J side to allow other clients
   * or APIs to modify the same attribute. This duplication is usually necessary
   * when a client needs immediate feedback of an error rather than going over
   * to the middle-tier (in a multi-tier platform) and get any errors.
   */
   void beforeSaveTransaction(JUPanelValidationEvent ev);
}
