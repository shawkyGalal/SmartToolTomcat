/*
 * @(#)JUMultiAttrListCellRenderer.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.uicli.controls;

import java.awt.Component;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.Rectangle;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.ListCellRenderer;
import javax.swing.border.Border;
import oracle.jbo.AttributeDef;
import oracle.jbo.Row;
import java.awt.FontMetrics;


public class JUMultiAttrListCellRenderer //extends DefaultListCellRenderer
implements ListCellRenderer 
{

  AttributeDef mAttrDefs[];
  int          mAttrCount = -1;
  int          mAttrIndices[];
  Dimension    mAttrSizes[];
  JLabel       mLabels[];
  JPanel       mLabelPane;

  protected static Border emptyBorder = new javax.swing.border.EmptyBorder(0,0,0,0);
  protected static Border emptyBorderx = new javax.swing.border.EmptyBorder(2,2,2,2);

  public JUMultiAttrListCellRenderer(AttributeDef[] defs) 
  {
    mAttrDefs = defs;
  }


  public Component getListCellRendererComponent(
                                               JList list,
                                               Object value,
                                               int modelIndex,
                                               boolean isSelected,
                                               boolean cellHasFocus)
  {
    class CellLabel extends JLabel   //DefaultListCellRenderer
    {
      private Dimension preferredSize;

      CellLabel(JList list, Object value, boolean isSelected, boolean cellHasFocus, int modelIndex)
      {
        if (list != null)
        {
          setFont( list.getFont() );
          setComponentOrientation(list.getComponentOrientation());
        }

        if (value != null)
        {
          setText(value.toString()); 
        }
      }

      // REST OF THESE METHODS ARE COPIED AS IS FROM LIST/TABLE CELL RENDERERS AS APPROPRIATE.

      /**
      * Notification from the <code>UIManager</code> that the look and feel
      * [L&F] has changed.
      * Replaces the current UI object with the latest version from the 
      * <code>UIManager</code>.
      *
      * @see JComponent#updateUI
      */
      public void updateUI() 
      {
        super.updateUI(); 
        //setForeground(null);
        //setBackground(null);
      }

      /**
      * Overridden for performance reasons.
      * See the <a href="#override">Implementation Note</a> 
      * for more information.
      */
      //public void validate() {}

      /**
      * Overridden for performance reasons.
      * See the <a href="#override">Implementation Note</a> 
      * for more information.
      */
      public void revalidate() {}

      /**
      * Overridden for performance reasons.
      * See the <a href="#override">Implementation Note</a> 
      * for more information.
      */
      public void repaint(long tm, int x, int y, int width, int height) {}

      /**
      * Overridden for performance reasons.
      * See the <a href="#override">Implementation Note</a> 
      * for more information.
      */
      public void repaint(Rectangle r) {}

      /**
      * Overridden for performance reasons.
      * See the <a href="#override">Implementation Note</a> 
      * for more information.
      */
      protected void firePropertyChange(String propertyName, Object oldValue, Object newValue) 
      {  
        if (propertyName=="text")
        {
          super.firePropertyChange(propertyName, oldValue, newValue);
        }
      }

      /**
      * Overridden for performance reasons.
      * See the <a href="#override">Implementation Note</a> 
      * for more information.
      */
      public void firePropertyChange(String propertyName, boolean oldValue, boolean newValue) {}


      /**
      * Sets the string for the cell being rendered to <code>value</code>.
      * 
      * @param value  The string value for this cell. If value is
      *     <code>null</code>, it sets the text value to an empty string.
      * @see JLabel#setText
      * 
      */
      protected void setValue(Object value) 
      {
        setText((value == null) ? "" : value.toString());
      }
    }

    if (mLabelPane == null)
    {
      JPanel pane = new JPanel()
      {
        public void setFont(java.awt.Font font)
        {
          java.awt.Component c[] = getComponents();
          for (int i = 0; i < c.length; i++)
          {
            c[i].setFont(font);
          }
        }
        public void setForeground (java.awt.Color color)
        {
          java.awt.Component c[] = getComponents();
          for (int i = 0; i < c.length; i++)
          {
            c[i].setForeground(color);
          }
        }
      };
      pane.setOpaque(true);
      mLabelPane = pane;
    }

    if ( isSelected )
    {
      mLabelPane.setBackground( list.getSelectionBackground() );
      mLabelPane.setForeground( list.getSelectionForeground() );
    }
    else
    {
      mLabelPane.setBackground( list.getBackground() );
      mLabelPane.setForeground( list.getForeground() );
    }

    if (value instanceof Row)
    {
      Row row = (Row)value;
      mLabelPane.setLayout(new GridLayout());
      int count = mAttrCount;
      Object attr;
      CellLabel lbl = null;
      int i;
      if (count != -1)
      {
        Object val;
        for (i = 0; i < count; i++)
        {
          val = row.getAttribute(mAttrIndices[i]);
          mLabels[i].setText((val != null) ? val.toString() : "");
          mLabels[i].setSize(mAttrSizes[i]);
        }
      }
      else
      {
        AttributeDef ad;
        AttributeDef ads[] = mAttrDefs;
        mAttrCount = count = mAttrDefs.length;
        mAttrIndices = new int[count];
        mAttrSizes = new Dimension[count];
        CellLabel lbls[] = new CellLabel[count];

        int idx;
        for (i = 0; i < count; i++)
        {

          ad = (AttributeDef)ads[i];
          mAttrIndices[i] = idx = ad.getIndex();
          lbl = new CellLabel(list, row.getAttribute(idx), isSelected, cellHasFocus, modelIndex);
          mLabelPane.add(lbl);
          lbls[i] = lbl;
        }

        int columnWidth = 5;
        int columnHeight = 20;
        if (lbl != null)
        {
          FontMetrics metrics = lbl.getFontMetrics(lbl.getFont());
          columnWidth = metrics.charWidth('M');
          columnHeight = metrics.getHeight();
        }
        for (i = 0; i < count; i++)
        {
          mAttrSizes[i] = new Dimension(columnWidth * lbls[i].getText().length(), columnHeight);
        }
        mLabels  = lbls;
      }
    }

    return mLabelPane;
  }
}

