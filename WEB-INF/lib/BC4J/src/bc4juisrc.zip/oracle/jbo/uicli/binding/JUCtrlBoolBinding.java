/*
 * @(#)JUCtrlBoolBinding.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.uicli.binding;

import oracle.jbo.domain.TypeFactory;

/**
 * Implements data binding support for controls that allow only one of two values,
 * like a checkbox. This binding lets a subclass provide two values in a list
 * and by default the first value is returned to indicate a TRUE value and the second
 * value represents the FALSE value.
 */
abstract public class JUCtrlBoolBinding extends JUCtrlListBinding
{

   //represents the first value in the list means true.
   private boolean mBoolVal = true;
   
   
   /**
   * This constructor binds a Swing control to an attribute 'attrName' in the ViewObject
   * identified by the given IteratorBinding iterBinding. This constructor should only
   * be used if the attribute values for TRUE and FALSE states are boolean 'true' and 'false'
   * and not some other values.
   */
   public JUCtrlBoolBinding(Object control, JUIteratorBinding iterBinding, String attrName)
   {
      super(control, iterBinding, new String[] {attrName}, LIST_OPER_SET_ATTRIBUTE);
   }


   /**
   * This constructor binds a Swing control to an attribute 'attrName' in the ViewObject
   * identified by the given IteratorBinding iterBinding. This constructor should only
   * be used if the attribute values for TRUE and FALSE states are identified by the
   * first two values in the given list. If boolVal  = true, then the first value
   * in the list is returned when this control's state is TRUE for the value of the attribute.
   * If boolVal = false, then the first value in the list is returned to mean control's state = FALSE.
   */
   public JUCtrlBoolBinding(Object control, JUIteratorBinding iterBinding, String attrName,
                            Object[] valueList, boolean boolVal)
   {
      super(control, iterBinding, new String[] {attrName}, valueList);

      mBoolVal = boolVal;
   }


   /**
   * Matches the given value to a boolean based on what's in the list and the setting
   * of boolval parameter from the constructor.
   */
   public Object findValue(Object val)
   {
      Object[] valueList = getValueList();

      if (valueList == null || valueList.length == 0)
      {
         return TypeFactory.getInstance(java.lang.Boolean.class, val);
         /*
         if (val instanceof Boolean)
         {
            return val;
         }
         else
         {
            return new Boolean(false);
         }
         */
      }

      int listIndex = findListIndex(val);

      if (listIndex == 0)
      {
         return new Boolean(mBoolVal);
      }
      else
      {
         if (val == null)
         {
            return null;
         }
         
         return new Boolean(!mBoolVal);
      }
   }

   
   /**
   * Matches the boolean value to a value from the list based on boolVal parameter in the
   * constructor. If boolVal equals b, returns the first element in the list. Otherwise,
   * returns the second element or null when no second element was given. 
   */
   public Object getValueFromBoolean(boolean b)
   {
      Object[] valList = getValueList();

      if (valList == null || valList.length == 0)
      {
         return new Boolean(b);
      }
      else  if (b == mBoolVal)
      {
         return valList[0];
      }
      else
      {
         if (valList.length >= 2)
         {
            return valList[1];
         }

         return null;
      }
   }
}
