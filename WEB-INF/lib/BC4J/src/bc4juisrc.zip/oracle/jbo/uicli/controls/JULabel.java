/*
 * @(#)JULabel.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.uicli.controls;

import javax.swing.Icon;
import oracle.jbo.uicli.jui.JULabelBinding;

/**
 * Implements a BC4J data bound JLabel subclass. 
 * <p>
 * Swing's JLabel does not have a model object. In order to display static labels
 * on a Panel with data from a BC4J ViewObject, JULabel should be used.
 * When the label is instantiated at runtime, it could have a default string
 * but that gets overridden by the attribute value from a BC4J ViewObject
 * attribute to which this label is bound when that ViewObject is executed.
 */
public class JULabel extends javax.swing.JLabel
{
   JULabelBinding mBinding;
    /**
     * Creates a <code>JLabel</code> instance with the specified
     * text, image, and horizontal alignment.
     * The label is centered vertically in its display area.
     * The text is on the trailing edge of the image.
     *
     * @param text  The text to be displayed by the label.
     * @param icon  The image to be displayed by the label.
     * @param horizontalAlignment  One of the following constants
     *           defined in <code>SwingConstants</code>:
     *           <code>LEFT</code>,
     *           <code>CENTER</code>,
     *           <code>RIGHT</code>,
     *           <code>LEADING</code> or
     *           <code>TRAILING</code>.
     */
    public JULabel(String text, Icon icon, int horizontalAlignment) 
    {
       super(text, icon, horizontalAlignment);
    }
            
    /**
     * Creates a <code>JLabel</code> instance with the specified
     * text and horizontal alignment.
     * The label is centered vertically in its display area.
     *
     * @param text  The text to be displayed by the label.
     * @param horizontalAlignment  One of the following constants
     *           defined in <code>SwingConstants</code>:
     *           <code>LEFT</code>,
     *           <code>CENTER</code>,
     *           <code>RIGHT</code>,
     *           <code>LEADING</code> or
     *           <code>TRAILING</code>.
     */
    public JULabel(String text, int horizontalAlignment) 
    {
        super(text, null, horizontalAlignment);
    }

    /**
     * Creates a <code>JLabel</code> instance with the specified text.
     * The label is aligned against the leading edge of its display area,
     * and centered vertically.
     *
     * @param text  The text to be displayed by the label.
     */
    public JULabel(String text) 
    {
        super(text, null, LEADING);
    }

    /**
     * Creates a <code>JLabel</code> instance with the specified
     * image and horizontal alignment.
     * The label is centered vertically in its display area.
     *
     * @param icon  The image to be displayed by the label.
     * @param horizontalAlignment  One of the following constants
     *           defined in <code>SwingConstants</code>:
     *           <code>LEFT</code>,
     *           <code>CENTER</code>, 
     *           <code>RIGHT</code>,
     *           <code>LEADING</code> or
     *           <code>TRAILING</code>.
     */
    public JULabel(Icon image, int horizontalAlignment) 
    {
        super(null, image, horizontalAlignment);
    }

    /**
     * Creates a <code>JLabel</code> instance with the specified image.
     * The label is centered vertically and horizontally
     * in its display area.
     *
     * @param icon  The image to be displayed by the label.
     */
    public JULabel(Icon image) 
    {
        super(null, image, CENTER);
    }

    /**
     * Creates a <code>JLabel</code> instance with 
     * no image and with an empty string for the title.
     * The label is centered vertically 
     * in its display area.
     * The label's contents, once set, will be displayed on the leading edge 
     * of the label's display area.
     */
    public JULabel() 
    {
        super("", null, LEADING);
    }

   
   /**
   * Binds this label control with an attribute in a ViewObject. 
   * When the ViewObject/RowSet behind the iterator to which the given binding
   * belongs is executed, the binding object updates this label's display string
   * with data from the ViewObject.
   */
   public void setModel(JULabelBinding binding)
   {
     mBinding = binding;
   }
   
   /**
   * Returns the attribute-binding model that this control is bound to.
   */
   public JULabelBinding getModel()
   {
     return mBinding;
   }
}