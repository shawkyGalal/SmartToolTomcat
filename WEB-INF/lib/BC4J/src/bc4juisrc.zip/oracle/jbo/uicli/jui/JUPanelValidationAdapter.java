/*
 * @(#)JUPanelValidationAdapter.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.uicli.jui;

/**
 * Default implementation for JUPanelValidationListener interface.
 * This implementation simply prints a diagnostic message for each
 * event it receives. JClient design time creates a subclass of this
 * adapter with overridden methods as per an application's choice
 * when the Event Inspector is used to generate JUPanelValidationEvent
 * listener code.
 */
public class JUPanelValidationAdapter implements JUPanelValidationListener
{
   public void beforeSetAttribute(JUPanelValidationEvent ev)
   {
      oracle.jbo.common.DebugDiagnostic.println("beforeSetAttribute");
   }
   
   public void beforeCurrencyChange(JUPanelValidationEvent ev)
   {
      oracle.jbo.common.DebugDiagnostic.println("beforeCurrencyChange");
   }

   public void beforeSaveTransaction(JUPanelValidationEvent ev)
   {
      oracle.jbo.common.DebugDiagnostic.println("beforeSaveTransaction");
   }
}
