/*
 * @(#)JULovDialog.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.uicli.controls;

import java.awt.BorderLayout;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.Dimension;
import java.awt.Frame;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JDialog;
import oracle.jbo.common.StringManager;
import oracle.jbo.uicli.UIMessageBundle;
import oracle.jbo.uicli.jui.JULovButtonBinding;
import oracle.jbo.uicli.jui.JULovDialogInterface;

public class JULovDialog extends JDialog implements JULovDialogInterface, ActionListener
{
   JPanel lovContainerPanel = new JPanel();
   JPanel buttonPanel = new JPanel();
   
   protected JButton btnOK = new JButton();
   protected JButton btnCancel = new JButton();
   protected JButton btnHelp = new JButton();
   BorderLayout borderLayout = new BorderLayout();
   GridBagLayout gridBagLayout1 = new GridBagLayout();
   GridBagLayout gridBagLayout2 = new GridBagLayout();
   JULovButtonBinding  mLovBinding;
   boolean mOK = false;
   private static final String MSG_BUNDLE = "oracle.jbo.uicli.UIMessageBundle";
   
   public JULovDialog()
   {
      this(null, "", false);
   }
   
   public JULovDialog(Frame parent, String title, boolean modal)
   {
      super(parent, title, modal);
      try
      {
         jbInit();

         btnOK.setText(
                       StringManager.getString(MSG_BUNDLE, UIMessageBundle.STR_LOV_BUTTON_OK, "", null)
                      );
         btnCancel.setText(
                           StringManager.getString(MSG_BUNDLE, UIMessageBundle.STR_LOV_BUTTON_CANCEL, "", null)
                          );
         btnHelp.setText(
                         StringManager.getString(MSG_BUNDLE, UIMessageBundle.STR_LOV_BUTTON_HELP, "", null)
                        );
      }
      catch(Exception e)
      {
         e.printStackTrace();
      }
   
   }

   //so that guava could close the dialog after setting this flag.
   public void setOKSelected(boolean flag)
   {
      mOK = flag;
   }

   public boolean isOKSelected ()
   {
      return mOK;
   }
   
   public void setLov( JULovButtonBinding lov )
   {
     JPanel lovPanel = lov.getLovPanelInterface().getPanel();
     lovContainerPanel.setLayout(new BorderLayout());
     lovContainerPanel.add(lovPanel, BorderLayout.CENTER);
     mLovBinding = lov;
   }
   
   void jbInit() throws Exception
   {
    this.setSize(new Dimension(400, 300));
    buttonPanel.setLayout(gridBagLayout2);
    
    
    btnOK.setActionCommand("OK");
    btnCancel.setActionCommand("CANCEL");
    btnHelp.setActionCommand("HELP");

    this.getContentPane().setLayout(borderLayout);
    this.getContentPane().add(lovContainerPanel, BorderLayout.CENTER);
    this.getContentPane().add(buttonPanel, BorderLayout.SOUTH);

    //this.getContentPane().setLayout(gridBagLayout1);
    //this.getContentPane().add(lovContainerPanel, new GridBagConstraints(0, 0, 1, 1, 1.0, 1.0, GridBagConstraints.CENTER, GridBagConstraints.BOTH, new Insets(0, 0, 0, 0), 0, 0));
    //this.getContentPane().add(buttonPanel, new GridBagConstraints(0, 1, 1, 1, 1.0, 0.0, GridBagConstraints.SOUTH, GridBagConstraints.HORIZONTAL, new Insets(0, 0, 0, 0), 0, 0));
    
    buttonPanel.add(btnOK, new GridBagConstraints(1, 0, 1, 1, 1.0, 1.0, GridBagConstraints.EAST, GridBagConstraints.NONE, new Insets(1, 1, 1, 1), 0, 0));
    buttonPanel.add(btnCancel, new GridBagConstraints(2, 0, 1, 1, 0.0, 0.0, GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(1, 1, 1, 1), 0, 0));
    buttonPanel.add(btnHelp, new GridBagConstraints(0, 0, 1, 1, 1.0, 1.0, GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(1, 1, 1, 1), 0, 0));
   
    btnOK.addActionListener(this);
    btnCancel.addActionListener(this);
    btnHelp.addActionListener(this);
   }
   
   public void actionPerformed (ActionEvent ae)
   {
      String action = ae.getActionCommand();
      if (action.equals("HELP"))
      {
         mLovBinding.getLovPanelInterface().helpAction(ae);
      }
      else 
      {
         setOKSelected((action.equals("OK")));
         this.dispose();
      } 
   }

    /*
    * Gets the OK Button.
    * Use this method to gain access to the button and provide
    * it with mnemonics for ADA support.
    */
   public JButton getOKButton()
   {
      return btnOK;
   }

    /*
    * Gets the Cancel Button.
    * Use this method to gain access to the button and provide
    * it with mnemonics for ADA support.
    */
   public JButton getCancelButton()
   {
      return btnCancel;
   }

    /*
    * Gets the Help Button.
    * Use this method to gain access to the button and provide
    * it with mnemonics for ADA support.
    */
   public JButton getHelpButton()
   {
      return btnHelp;
   }

}