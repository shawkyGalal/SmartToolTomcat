/*
 * @(#)JUCtrlValueBinding.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.uicli.binding;

import com.sun.java.util.collections.ArrayList;
import oracle.jbo.AttributeDef;
import oracle.jbo.AttributeList;
import oracle.jbo.AttributeHints;
import oracle.jbo.DeleteEvent;
import oracle.jbo.InsertEvent;
import oracle.jbo.InvalidDefNameException;
import oracle.jbo.JboException;
import oracle.jbo.LocaleContext;
import oracle.jbo.NavigationEvent;
import oracle.jbo.NoDefException;
import oracle.jbo.Row;
import oracle.jbo.ScrollEvent;
import oracle.jbo.ViewObject;

import oracle.jbo.domain.Struct;

/**
 * A JUControlBinding class responsible for maintaining which attribute(s)
 * of a row this binding can display/update. This class accepts a list of attribute names and
 * gets the AttributeDef objects for those attributes from the associated ViewObject. 
 * This class also provides APIs to update values in a control given a new row or a set of rows.
 * JUIteratorBinding uses APIs in this class to notify the controls of:
 * <ul>
 * <li>Change in scrolling range if the control works with a range of rows
 * <li>Change in currency
 * <li>Row-inserted event
 * <li>Row-deleted event
 * </ul>
 * <p>
 * This class also has accessor methods that return attribute values for Attributes with which
 * this control binding is working. The indices of these attributes are ordered based on 
 * the names provided to this control binding in the constructor.
 */
abstract public class JUCtrlValueBinding extends JUControlBinding implements AttributeList
{
   private String[] mAttrNames;
   private AttributeDef[] mAttrs;

   private final byte BIND_INIT = -1;
   private final byte BIND_OBJ_ATTR = 1;
   private final byte BIND_VO_ATTR  = 0;
   private byte mObjAttrBinding = BIND_INIT;

   final byte TYPE_ROW_ITERATOR = 0;
   final byte TYPE_ARRAY_ITERATOR = 1;
   byte mIteratorBindingType = TYPE_ROW_ITERATOR;

   /**
   * Given a row, update the control with new attribute values from this row based on
   * the attributes with which this binding is associated.
   */
   public void updateValuesFromRow(Row row)
   {
      if (mAttrs == null) //OTO
      {
         if (isObjectAttributeBindingType()) 
         {
            resolveObjectAttributeDefs(row);
         }
      }
   }
   
   /**
   * Given a set of rows, update the control with new attribute values from the rows based on
   * the attributes with which this binding is associated.
   * If clear is true, the control is expected to remove the current displayed value and associated
   * children values (like in a tree, remove all subnodes) and then set the new values.
   */
   abstract public void updateValuesFromRows(Row[] rows, boolean clear);

   /**
   * Update the control display based on whether the rows of data has scrolled. 
   * @see oracle.jbo.ScrollEvent 
   */
   abstract public void updateRangeScrolled(ScrollEvent event);

   /**
   * Update the current row display as the currency has navigated in the iterator
   * with which this control binding is working.
   */
   abstract public void updateNavigated(NavigationEvent event);

 
   protected JUCtrlValueBinding()
   {
   }

   /**
   * Notification that a new row was inserted in the associated iterator.
   * Control-bindings like JTable refresh their display to show the new row on this event.
   */
   public void updateRowInserted(InsertEvent event)
   {
   }
   
   
   /**
   * Notification that a row was deleted in the associated iterator.
   * Moves the currency on the associated row iterator to the next row (or previous row
   * if there is no next row) when the currency on the iterator was on the deleted row.
   */
   public void updateRowDeleted(DeleteEvent event)
   {
/*
      synchronized(getIteratorBinding().getSyncLock())
      {
         RowIterator iter = getRowIterator();

         try
         {
            if (iter != null && iter.getCurrentRowSlot() == RowSetIterator.SLOT_DELETED)
            {
               if (iter.hasNext())
               {
                  iter.next();
               }
               else if (iter.hasPrevious()) 
               {
                  iter.previous();
               }
               else
               {
               }
            }
         }
         catch(Exception ex)
         {
            reportException(ex);
         }
      }
*/
   }
   
   
   public JUCtrlValueBinding(Object control, JUIteratorBinding iterBinding, String[] attrNames)
   {
      super(control, iterBinding);

      mAttrNames = attrNames;
      mAttrs = null;

      if (iterBinding != null && iterBinding.getApplicationModule() != null)
      {
         iterBinding.addValueBinding(this);
      }
   }


   public String[] getAttributeNames()
   {
      return mAttrNames;
   }

   
   public AttributeDef[] getAttributeDefs()
   {
      if (mAttrs == null)
      {
         synchronized(getIteratorBinding().getSyncLock())
         {
            try
            {
               ViewObject vo = getViewObject();
   
               if (vo == null)
               {
                  mAttrs = new AttributeDef[0];

                  if (mAttrNames == null)
                  {
                     mAttrNames = new String[0];
                  }
               }
               else  if (mAttrNames == null)
               {
                  AttributeDef[] attrs = vo.getAttributeDefs();
                  ArrayList al = new ArrayList(attrs.length);
                  int kind = 0;

                  for (int i = 0; i < attrs.length; i++)
                  {
                     kind = attrs[i].getAttributeKind();
                     if (kind == AttributeDef.ATTR_ASSOCIATED_ROW
                         || kind == AttributeDef.ATTR_ASSOCIATED_ROWITERATOR)
                     {
                        continue;
                     }
                     al.add(attrs[i]);
                  }

                  mAttrs = (AttributeDef[]) (al.toArray(new AttributeDef[al.size()]));
                  mAttrNames = new String[mAttrs.length];

                  for (int i = 0; i < mAttrNames.length; i++)
                  {
                     mAttrNames[i] = mAttrs[i].getName();
                  }
               }
               else
               {
                  if (isAttributeBindingType()) //OTO
                  {
                     mAttrs = new AttributeDef[mAttrNames.length];
         
                     for (int j = 0; j < mAttrNames.length; j++)
                     {
                        mAttrs[j] = vo.findAttributeDef(mAttrNames[j]);
                     }
                  }
               }
            }
            catch(Exception ex)
            {
               reportException(ex);
            }
         }
      }

      return mAttrs;
   }


   public AttributeDef getAttributeDef(int index)
   {
      AttributeDef[] ads = getAttributeDefs();
      if (ads != null && ads.length > index) 
      {
         return ads[index];
      }
      return null;
   }


   public AttributeDef findAttributeDef(String name)
   {
      try
      {
         if (name == null)
         {
            throw new InvalidDefNameException(InvalidDefNameException.TYP_ATTRIBUTE,
                                              name);
         }
   
         AttributeDef[] attrs = getAttributeDefs();
         
         for (int j = 0; j < attrs.length; j++)
         {
            if (attrs[j].getName().equals(name))
            {
               return attrs[j];
            }
         }

         throw new NoDefException(NoDefException.TYP_ATTRIBUTE, name);
      }
      catch(Exception ex)
      {
         reportException(ex);
      }

      return null;
   }


   public Object getAttributeFromRow(int rowIndexInRange, int attrIndex)
   {
      {
         try
         {
            Row row = getRowAtRangeIndex(rowIndexInRange);

            if (row == null)
            {
               return null;
            }
            
            if (mAttrs == null) //OTO
            {
               if (isObjectAttributeBindingType()) 
               {
                  resolveObjectAttributeDefs(row);
               }
            }
            return getAttributeFromRow(row, getAttributeDef(attrIndex));
         }
         catch(Exception ex)
         {
            reportException(ex);
         }

         return null;
      }
   }


   public Object getAttributeFromRow(int rowIndexInRange, String name)
   {
      return getAttributeFromRow(rowIndexInRange, getAttributeIndexOf(name));
   }


   public Object getAttributeFromRow(Row row, AttributeDef def)
   {
      LocaleContext locale = getApplicationModule().getSession().getLocaleContext();
      
      if (row == null || def == null)
      {
         return null;
      }
      else
      {
         JUIteratorBinding iterBind = getIteratorBinding();
         synchronized(iterBind.getSyncLock())
         {
            try
            {
               AttributeHints hints = def.getUIHelper();
               if(!iterBind.isFindMode() && hints != null && hints.hasFormatInformation(locale))
               {
                  //for now domain attribute defs do not have hints.
                  return def.getUIHelper().getFormattedAttribute(row, locale);
               }
               if (isObjectAttributeBindingType()) 
               {
                  return Struct.getStructAttribute(row, getViewObject(), mAttrNames[getDefIndex(def)]);
               }
               return row.getAttribute(def.getIndex());
            }
            catch(Exception ex)
            {
               reportException(ex);
            }

            return null;
         }
      }
   }


   public Object getAttributeFromRow(Row row, int attrIndex)
   {
      if (mAttrs == null) //OTO
      {
         if (isObjectAttributeBindingType()) 
         {
            resolveObjectAttributeDefs(row);
         }
      }
      return getAttributeFromRow(row, getAttributeDef(attrIndex));
   }


   public Object getAttributeFromRow(Row row, String name)
   {
      if (mAttrs == null) //OTO
      {
         if (isObjectAttributeBindingType()) 
         {
            resolveObjectAttributeDefs(row);
         }
      }
      return getAttributeFromRow(row, findAttributeDef(name));
   }

   
   public void setAttributeInRow(int rowIndexInRange, int attrIndex, Object value, boolean handleException)
   {
      {
         try
         {
/***************
            Row[] rows = getAllRowsInRange();
            setAttributeInRow(rows[rowIndexInRange], getAttributeDef(attrIndex), value, handleException);
***************/
            Row row = getRowAtRangeIndex(rowIndexInRange);

            if (mAttrs == null) //OTO
            {
               if (isObjectAttributeBindingType()) 
               {
                  resolveObjectAttributeDefs(row);
               }
            }
            setAttributeInRow(row, getAttributeDef(attrIndex), value, handleException);
         }
         catch(JboException ex)
         {
            if (handleException) 
            {
               reportException(ex);
            }
            else
            {
               throw ex;
            }
         }
      }
   }


   public void setAttributeInRow(int rowIndexInRange, String name, Object value, boolean handleException)
   {
      setAttributeInRow(rowIndexInRange, getAttributeIndexOf(name), value, handleException);
   }

   public void setAttributeInRow(Row row, AttributeDef def, Object value)
   {
      setAttributeInRow(row, def, value, true);
   }

   public void setAttributeInRow(Row row, AttributeDef def, Object value, boolean handleException)
   {
      LocaleContext locale = getApplicationModule().getSession().getLocaleContext();
      
      if (def != null)
      {
         JUIteratorBinding iterBind = getIteratorBinding();
         synchronized(iterBind.getSyncLock())
         {
            try
            {
               if (row != null) 
               {
                  if (!iterBind.isFindMode()) 
                  {
                     if (value != null) 
                     {
                        Object parsedValue = null;
      
                        
                        AttributeHints hints = def.getUIHelper();
                        if(hints != null && hints.hasFormatInformation(locale))
                        {
                           //for now domain attribute defs do not have hints.
                           parsedValue = def.getUIHelper().parseFormattedAttribute(value.toString(), locale) ;
                        }
                        value = (parsedValue != null) ? parsedValue : value;
                     }
                  }
                  else
                  {
                     //find mode, so see if controlbinding allows findMode.
                     if (!isControlQueriable()) 
                     {
                        //return without setting the value if the
                        //control is not a queriable control. 
                        //currently only textfield and grid support query.
                        return;
                     }
                  }
   
                  getFormBinding().callBeforeSetAttribute(this, row, def, value);
                  if (isAttributeBindingType()) 
                  {
                     row.setAttribute(def.getIndex(), value);
                  }
                  else
                  {
                     Struct.setStructAttribute(row, getViewObject(), mAttrNames[getDefIndex(def)], value);
                  }
               }
               else
               {
                  //do not throw exception as updates to controls via apis lead to this route
                  //in some cases.
                  oracle.jbo.common.Diagnostic.println("Attempt to update attribute in null row!");
               }
            }
            catch(JboException ex)
            {
               if (handleException) 
               {
                  reportException(ex);
               }
               else
               {
                  throw ex;
               }
            }
         }
      }
   }

   
   public void setAttributeInRow(Row row, int attrIndex, Object value, boolean handleException)
   {
      if (mAttrs == null) //OTO
      {
         if (isObjectAttributeBindingType()) 
         {
            resolveObjectAttributeDefs(row);
         }
      }
      setAttributeInRow(row, getAttributeDef(attrIndex), value, handleException);
   }


   public void setAttributeInRow(Row row, String name, Object value, boolean handleException)
   {
      setAttributeInRow(row, findAttributeDef(name), value, handleException);
   }

   
   //
   // AttributeList implementation
   //

   public Object getAttribute(int index)
   {
      Row row = getCurrentRow();
      if (mAttrs == null) //OTO
      {
         if (isObjectAttributeBindingType()) 
         {
            resolveObjectAttributeDefs(row);
         }
      }
      return getAttributeFromRow(row, getAttributeDef(index));
   }


   public Object getAttribute(String name)
   {
      return getAttributeFromRow(getCurrentRow(), findAttributeDef(name));
   }


   public void setAttribute(int index, Object value)
   {
      Row row = getCurrentRow();
      if (mAttrs == null) //OTO
      {
         if (isObjectAttributeBindingType()) 
         {
            resolveObjectAttributeDefs(row);
         }
      }
      setAttributeInRow(row, getAttributeDef(index), value, false);
   }


   public void setAttribute(String name, Object value)
   {
      Row row = getCurrentRow();
      if (mAttrs == null) //OTO
      {
         if (isObjectAttributeBindingType()) 
         {
            resolveObjectAttributeDefs(row);
         }
      }
      setAttributeInRow(row, findAttributeDef(name), value, false);
   }


   public int getAttributeCount()
   {
      getAttributeDefs();

      return (mAttrs != null) ? mAttrs.length : 0;
   }
   

   public int getAttributeIndexOf(String name)
   {
      try
      {
         if (name == null)
         {
            throw new InvalidDefNameException(InvalidDefNameException.TYP_ATTRIBUTE,
                                              name);
         }
   
         AttributeDef[] attrs = getAttributeDefs();
         
         for (int j = 0; j < attrs.length; j++)
         {
            if (attrs[j].getName().equals(name))
            {
               return j;
            }
         }

         throw new NoDefException(NoDefException.TYP_ATTRIBUTE, name);
      }
      catch(Exception ex)
      {
         reportException(ex);
      }

      return -1;
   }

   
   public Object[] getAttributeValues()
   {
      Object[] retVal = new String[getAttributeCount()];

      for (int j = 0; j < retVal.length; j++)
      {
         retVal[j] = getAttribute(j);
      }

      return retVal;
   }

   
   /**
   * Determines whether this attribute is updateable for that row instance. 
   * Returns true if iterator is in data mode and is the corresponding row. If 
   * iterator is in find mode, then does an additional check to determine
   * whether the associated control is queriable.
   */
   public boolean isAttributeUpdateable(int index)
   {
      JUIteratorBinding iterBind = getIteratorBinding();
      synchronized(iterBind.getSyncLock())
      {
         try
         {
            Row row = getCurrentRow();

            if (row != null)
            {
               if (!iterBind.isFindMode()) 
               {
                  if (mAttrs == null) //OTO
                  {
                     if (isObjectAttributeBindingType()) 
                     {
                        resolveObjectAttributeDefs(row);
                     }
                  }
                  return (isAttributeBindingType()) //OTO
                           ? row.isAttributeUpdateable(getAttributeDef(index).getIndex())
                           : true; //could we ask the attribute list for updateability?
               }
               else
               {
                  if (isObjectAttributeBindingType()) 
                  {
                     return false;
                  }
                  return (row.isAttributeUpdateable(getAttributeDef(index).getIndex())
                          && isControlQueriable());
               }
            }
         }
         catch(Exception ex)
         {
            reportException(ex);
         }

         return false;
      }
   }

   /**
   * Notified by NavigationBar to stop any edits on the current control.
   * Primarily for grid and tree to notify their cell editors to stop
   * editing.
   */
   public void stopEditing() {}


   final void resolveAttributeBindingType()
   {
      if (mObjAttrBinding == BIND_INIT) 
      {
         String names[] = mAttrNames;
         if (names != null) 
         {
            for (int i = 0; i < names.length; i++) 
            {
               if (names[i].indexOf('.') > 0) 
               {
                  mObjAttrBinding = BIND_OBJ_ATTR;
                  break;
               }
            }
         }
         if (mObjAttrBinding == BIND_INIT) 
         {
            mObjAttrBinding = BIND_VO_ATTR;
         }
      }
   }

   final boolean isObjectAttributeBindingType()
   {
      if (mObjAttrBinding == BIND_INIT) 
      {
         resolveAttributeBindingType();
      }
      return (mObjAttrBinding == BIND_OBJ_ATTR);
   }

   final boolean isAttributeBindingType()
   {
      if (mObjAttrBinding == BIND_INIT) 
      {
         resolveAttributeBindingType();
      }
      return (mObjAttrBinding == BIND_VO_ATTR);
   }

   final void resolveObjectAttributeDefs(Row row)
   {
      mAttrs = new AttributeDef[mAttrNames.length];
      Struct.fillObjectAttributeDefs(row, getViewObject(), mAttrNames, mAttrs);
   }

   final int getDefIndex(AttributeDef ad)
   {
      for (int i = 0; i < mAttrs.length; i++) 
      {
         if (ad == mAttrs[i]) 
         {
            return i;
         }
      }
      return -1;
   }

   public void setArrayIteratorType()
   {
      mIteratorBindingType = TYPE_ARRAY_ITERATOR;
   }

   public boolean isArrayIteratorType()
   {
      return (mIteratorBindingType == TYPE_ARRAY_ITERATOR);
   }
   
   void release()
   {
      JUIteratorBinding iter = getIteratorBinding();
      if (iter != null) 
      {
         iter.removeValueBinding(this);
      }
      super.release();
   }
}
