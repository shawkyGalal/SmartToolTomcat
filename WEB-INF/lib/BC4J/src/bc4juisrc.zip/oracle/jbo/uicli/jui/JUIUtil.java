/*
 * @(#)JUIUtil.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.uicli.jui;

import java.awt.Component;
import java.awt.Frame;
import java.awt.Window;

public class JUIUtil
{
   public final static String DESIGNTIME_PROPERTY = "inJUIDesigntime";

   public static Frame getParentFrame(Component parentComponent)
   {
      while (true)
      {
         if (parentComponent == null)
         {
            return null;
         }

         if (parentComponent instanceof Frame)
         {
            return (Frame) parentComponent;
         }

         parentComponent = parentComponent.getParent();
      }
   }

   public static Window getParentWindow(Component parentComponent)
   {
      while (true)
      {
         if (parentComponent == null)
         {
            return null;
         }

         if (parentComponent instanceof Window)
         {
            return (Window) parentComponent;
         }

         parentComponent = parentComponent.getParent();
      }
   }

   public static boolean inDesignTime()
   {
      try
      {
         if (System.getProperty(DESIGNTIME_PROPERTY) != null)
         {
            return true;
         }
      }
      catch(Exception e)
      {
         return false;
      }

      return false;
   }
}
