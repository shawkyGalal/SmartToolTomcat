/*
 * @(#)JUTextFieldBinding.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.uicli.jui;

import java.awt.Component;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.event.DocumentListener;
import javax.swing.event.UndoableEditListener;
import javax.swing.text.AttributeSet;
import javax.swing.text.BadLocationException;
import javax.swing.text.Document;
import javax.swing.text.Element;
import javax.swing.text.JTextComponent;
import javax.swing.text.PlainDocument;
import javax.swing.text.Position;
import javax.swing.text.Segment;
import oracle.jbo.uicli.binding.JUCtrlAttrsBinding;
import oracle.jbo.uicli.binding.JUFormBinding;
import oracle.jbo.uicli.binding.JUIteratorBinding;

/**
 * JUTextFieldBinding is a lightweight Document model that implements
 * binding a <code>javax.swing.JTextComponent</code> to an attribute in 
 * a row of a BC4J ViewObject.
 * 
 *
 * @see oracle.jbo.Row
 * @see javax.swing.JTextField
 * @see javax.swing.JTextComponent
 */
public class JUTextFieldBinding extends JUCtrlAttrsBinding implements Document, ActionListener
{
   private Document mDocument = null;

   /**
   * Creates an instance of this binding object that binds a swing JTextComponent with an attribute
   * for rows in a given Iterator binding. This binding object holds on to the Document object
   * behind the JTextComponent control, if one is found. Otherwise, it attempts to set a PlainDocument
   * as the document of the JTextComponent.
   * <p>
   * If this control is a JTextField, then this binding object also registers itself as an ActionListener
   * so that when return key is pressed on the JTextField or whenever an ActionEvent is raised by the
   * JTextField, this binding object responds by saving the text in the control into the BC4J
   * Row object. The same save operation occurs on focus out from the control, as it also registers 
   * a FocusAdapter that performs the set operation on the BC4J Row object for the given attribute
   * when focus moves out of this control.
   * <p>
   * JDeveloper wizards use the createAttributeBinding() method that returns a Document object to
   * bind a ViewObject and attribute to a text control. An example usage for binding to 
   * Deptno attribute of DeptView ViewObject instance is like:
   * <code>jTextField2.setDocument(JUTextFieldBinding.createAttributeBinding(panelBinding, jTextField2, "DeptView", null, "DeptViewIter", "Deptno"));</code>
   * More details on the arguments can be found in the javadoc for the above method.
   * <p>
   * @param control JTextComponent which should be bound to an attribute of a BC4J row.
   * @param iterBinding JUIteratorBinding object that contains a reference to the RowIterator that contains Rows to display.
   * @param attrName Name of the attribute in the BC4J Row object to display.
   */
   public JUTextFieldBinding(JTextComponent control, JUIteratorBinding iterBinding, String attrName)
   {
      super(control, iterBinding, new String[] { attrName });

      init(control);
   }


   private void init(JTextComponent control)
   {
      mDocument = getModelImpl(control);

      if (control != null)
      {
         if (mDocument != control.getDocument())
         {
            control.setDocument(mDocument);
         }

         if (control instanceof JTextField) 
         {
            ((JTextField)control).addActionListener(this);
         }
         control.addFocusListener(new JUSVUpdateableFocusAdapter(this, 0));
      }
   }

   /**
   * Returns the Document object that provides data for the given control. If no Document object
   * is registered with the control, then this method creates an instance of PlainDocument and registers
   * that as the Document object for the given control.
   */
   protected Document getModelImpl(JTextComponent control)
   {
      Document doc = mDocument;

      if (doc == null)
      {
         if (control != null)
         {
            doc = control.getDocument();
         }
   
         if (doc == null)
         {
            doc = new PlainDocument();
         }
      }

      return doc;
   }

   /**
   * Returns true, so that JTextComponents can participate in a query in the Find Mode of the
   * containing panel. When the containing panel Binding object is set to Find mode, it queries
   * all control-bindings in it and disables those controls whose bindings return false
   * for this method during the Find mode. The return value from this method indicates 
   * whether to consult an attribute definition for queriability.
   * <p>
   * An application could create a subclass of this binding object and return false from this
   * method to prevent the associated control from participating in find mode. Additionally, a
   * BC4J attribute itself can control whether that attribute can participate in Query or
   * not. That property takes precedence over this method's return, if this method returns true.
   * In other words, if this binding is bound to a CLOB attribute type and the attribute
   * definition for that attribute indicates that it is not queriable, then the default behavior
   * of JUPanelBinding in Find mode will be to disable this binding's control, even though
   * this method returns true.
   */
   protected boolean isControlQueriable()
   {
      return true;
   }
   
   /**
   * *** For internal framework use only ***
   */
   public void addControlToPanel(Object panel, Object layoutObject, Object layoutCons)
   {
      ((JPanel) panel).add((Component) layoutObject, layoutCons);
   }

   
   /**
   * Fetches the text contained in the associated control. This method is used by the
   * framework to get the current value associated with this binding to update into the
   * associated attribute of a BC4J Row. This method calls the JTextComponent.getText()
   * to get the value.
   * @param attrIndex ignored for this control binding.
   * @see javax.swing.JTextComponent#getText
   */
   public Object getValueAt(int attrIndex)
   {
      return ((JTextComponent) getControl()).getText();
   }


   /**
   * Sets the given String representation of value (using value.toString()) into the
   * associated text control. Calls JTextComponent.setText() to set the value. If the
   * value is null, sets "" (an empty string) into the text control. 
   * @param value The value to display in the associated text control.
   * @param attrIndex Ignored for this control binding.
   * @see javax.swing.JTextComponent#setText
   */
   public void setValueAt(Object value, int attrIndex)
   {
      ((JTextComponent) getControl()).setText(value == null ? "" : value.toString());
   }
   
   /*
   Object mValue;
   public void setValueAt(Object value, int attrIndex)
   {
      mValue = value;

      javax.swing.SwingUtilities.invokeLater(new Runnable() {
          public void run() {
              //this leads to other deadlocks. 
              //synchronized(getTreeLock())
              {
                 ((JTextComponent) getControl()).setText(mValue == null ? "" : mValue.toString());
              }
          }
      });
   }
   */


   /**
   * Applications should call this method to update the value of an attribute
   * using this binding such that both the associated text control and the associated
   * row attribute gets updated.
   * @param value Value to display in the associated text control and to set in the attribute.
   * @param attrIndex Ignored for this control binding.
   */
   public void setDataValueAt(Object value, int attrIndex)
   {
      setValueAt(value, attrIndex);

      setAttribute(0, value);
   }

   
   /**
   * Handles the actionPerformed event generated by the associated TextControl.
   * Sets the associated attribute in this binding's iterator's current Row, with
   * the current value from the text control.
   */
   public void actionPerformed(ActionEvent e)
   {
      setAttribute(0, getValueAt(0));
   }


   //
   // Document implementation
   //

   /***
   * Delegates to the Swing Document object of the associated 
   * text component.
   * <p>
   * Registers the given observer to begin receiving notifications
   * when changes are made to the document.
   *
   * @param listener The observer to register.
   * @see Document#removeDocumentListener
   * @see javax.swing.text.Document
   */
   public void addDocumentListener(DocumentListener listener)
   {
      mDocument.addDocumentListener(listener);
   }


   /**
   * Delegates to the Swing Document object of the associated 
   * text component.
   * <p>
   * Registers the given observer to begin receiving notifications
   * when undoable edits are made to the document.
   *
   * @param listener The observer to register.
   * @see javax.swing.event.UndoableEditEvent
   * @see javax.swing.text.Document
   */
   public void addUndoableEditListener(UndoableEditListener listener)
   {
      mDocument.addUndoableEditListener(listener);
   }


   /**
   * Delegates to the swing Document object of the associated 
   * text component.
   * <p>
   * This method allows an application to mark a place in
   * a sequence of character content. This mark can then be 
   * used to tracks change as insertions and removals are made 
   * in the content. The policy is that insertions always
   * occur prior to the current position (the most common case) 
   * unless the insertion location is zero, in which case the 
   * insertion is forced to a position that follows the
   * original position. 
   *
   * @param offs The offset from the start of the document >= 0.
   * @return The position.
   * @exception BadLocationException If the given position does not
   *   represent a valid location in the associated document.
   * @see javax.swing.text.Document
   */
   public Position createPosition(int offs)
      throws BadLocationException
   {
      return mDocument.createPosition(offs);
   }

   
   /**
   * Delegates to the Swing Document object of the associated 
   * text component.
   * <p>
   * Returns the root element that views should be based upon,
   * unless some other mechanism for assigning views to element
   * structures is provided.
   *
   * @return The root element.
   * @see javax.swing.text.Document
   */
   public Element getDefaultRootElement()
   {
      return mDocument.getDefaultRootElement();
   }


   /**
   * Delegates to the Swing Document object of the associated 
   * text component.
   * <p>
   * Returns a position that represents the end of the document.  The
   * position returned can be counted on to track change and stay 
   * located at the end of the document.
   *
   * @return the position
   * @see javax.swing.text.Document
   */
   public Position getEndPosition()
   {
      return mDocument.getEndPosition();
   }

   
   /**
   * Delegates to the Swing Document object of the associated 
   * text component.
   * <p>
   * Returns number of characters of content currently 
   * in the document.
   *
   * @return Number of characters >= 0.
   * @see javax.swing.text.Document
   */
   public int getLength()
   {
      return mDocument.getLength();
   }


   /**
   * Delegates to the Swing Document object of the associated 
   * text component.
   * <p>
   * Gets properties associated with the document.  Allows one to
   * store things like the document title, author, etc.
   *
   * @param key A non-null property.
   * @return the properties
   * @see javax.swing.text.Document
   */
   public Object getProperty(Object key)
   {
      return mDocument.getProperty(key);
   }


   /**
   * Delegates to the Swing Document object of the associated 
   * text component.
   * <p>
   * Returns all of the root elements that are defined.
   * <p>
   * Typically there will be only one document structure, but the interface
   * supports building an arbitrary number of structural projections over the 
   * text data. The document can have multiple root elements to support 
   * multiple document structures.  Some examples might be:
   * </p>
   * <ul>
   * <li>Text direction.
   * <li>Lexical token streams.
   * <li>Parse trees.
   * <li>Conversions to formats other than the native format.
   * <li>Modification specifications.
   * <li>Annotations.
   * </ul>
   *
   * @return the root element
   * @see javax.swing.text.Document
   */
   public Element[] getRootElements()
   {
      return mDocument.getRootElements();
   }


   /**
   * Method delegates to the swing Document object of the associated 
   * text component.
   * <p>
   * Returns a position that represents the start of the document.  The 
   * position returned can be counted on to track change and stay 
   * located at the beginning of the document.
   *
   * @return the position
   * @see javax.swing.text.Document
   */
   public Position getStartPosition()
   {
      return mDocument.getStartPosition();
   }


   /**
   * Method delegates to the swing Document object of the associated 
   * text component.
   * <p>
   * Fetches the text contained within the given portion 
   * of the document.
   *
   * @param offset  the offset into the document representing the desired 
   *   start of the text >= 0
   * @param length  the length of the desired string >= 0
   * @return the text, in a String of length >= 0
   * @exception BadLocationException  some portion of the given range
   *   was not a valid part of the document.  The location in the exception
   *   is the first bad position encountered.
   * @see javax.swing.text.Document
   */
   public String getText(int offset, int length)
      throws BadLocationException
   {
      return mDocument.getText(offset, length);
   }


   /**
   * Method delegates to the swing Document object of the associated 
   * text component.
   * <p>
   * Fetches the text contained within the given portion 
   * of the document.
   *
   * @param offset  the offset into the document representing the desired 
   *   start of the text >= 0
   * @param length  the length of the desired string >= 0
   * @param txt the Segment object to return the text in
   *
   * @exception BadLocationException  Some portion of the given range
   *   was not a valid part of the document.  The location in the exception
   *   is the first bad position encountered.
   * @see javax.swing.text.Document
   */
   public void getText(int offset, int length, Segment txt)
      throws BadLocationException
   {
      mDocument.getText(offset, length, txt);
   }


   /**
   * Method delegates to the swing Document object of the associated 
   * text component.
   * <p>
   * Inserts a string of content.  This will cause a DocumentEvent
   * of type DocumentEvent.EventType.INSERT to be sent to the
   * registered DocumentListers, unless an exception is thrown.
   * The DocumentEvent will be delivered by calling the
   * insertUpdate method on the DocumentListener.
   * The offset and length of the generated DocumentEvent
   * will indicate what change was actually made to the Document.
   * <p align=center><img src="doc-files/Document-insert.gif">
   * <p>
   * If the Document structure changed as result of the insertion,
   * the details of what Elements were inserted and removed in
   * response to the change will also be contained in the generated
   * DocumentEvent.  It is up to the implementation of a Document
   * to decide how the structure should change in response to an
   * insertion.
   * <p>
   * If the Document supports undo/redo, an UndoableEditEvent will
   * also be generated.  
   *
   * @param offset  the offset into the document to insert the content >= 0.
   *    All positions that track change at or after the given location 
   *    will move.  
   * @param str    the string to insert
   * @param a      the attributes to associate with the inserted
   *   content.  This may be null if there are no attributes.
   * @exception BadLocationException  the given insert position is not a valid 
   * position within the document
   * @see javax.swing.text.Document
   * @see javax.swing.event.DocumentEvent
   * @see javax.swing.event.DocumentListener
   * @see javax.swing.event.UndoableEditEvent
   * @see javax.swing.event.UndoableEditListener
   */
   public void insertString(int offset, String str, AttributeSet a)
      throws BadLocationException
   {
      mDocument.insertString(offset, str, a);
   }

   /**
   * Method delegates to the swing Document object of the associated 
   * text component.
   * <p>
   * Puts a new property on the list.
   *
   * @param key the non-null property key
   * @param value the property value
   * @see javax.swing.text.Document
   */
   public void putProperty(Object key, Object value)
   {
      mDocument.putProperty(key, value);
   }


   /**
   * Method delegates to the swing Document object of the associated 
   * text component.
   * <p>
   * Removes a portion of the content of the document.  
   * This will cause a DocumentEvent of type 
   * DocumentEvent.EventType.REMOVE to be sent to the 
   * registered DocumentListeners, unless an exception
   * is thrown.  The notification will be sent to the
   * listeners by calling the removeUpdate method on the
   * DocumentListeners.
   * <p>
   * To ensure reasonable behavior in the face 
   * of concurrency, the event is dispatched after the 
   * mutation has occurred. This means that by the time a 
   * notification of removal is dispatched, the document
   * has already been updated and any marks created by
   * createPosition have already changed.
   * For a removal, the end of the removal range is collapsed 
   * down to the start of the range, and any marks in the removal 
   * range are collapsed down to the start of the range.
   * <p align=center><img src="doc-files/Document-remove.gif">
   * <p>
   * If the Document structure changed as result of the removal,
   * the details of what Elements were inserted and removed in
   * response to the change will also be contained in the generated
   * DocumentEvent. It is up to the implementation of a Document
   * to decide how the structure should change in response to a
   * remove.
   * <p>
   * If the Document supports undo/redo, an UndoableEditEvent will
   * also be generated.  
   *
   * @param offs  the offset from the begining >= 0
   * @param len   the number of characters to remove >= 0
   * @exception BadLocationException  some portion of the removal range
   *   was not a valid part of the document.  The location in the exception
   *   is the first bad position encountered.
   * @see javax.swing.text.Document
   * @see javax.swing.event.DocumentEvent
   * @see javax.swing.event.DocumentListener
   * @see javax.swing.event.UndoableEditEvent
   * @see javax.swing.event.UndoableEditListener
   */
   public void remove(int offs, int len)
      throws BadLocationException
   {
      mDocument.remove(offs, len);
   }


   /**
   * Method delegates to the swing Document object of the associated 
   * text component.
   * <p>
   * Unregisters the given observer from the notification list
   * so it will no longer receive change updates.  
   *
   * @param listener the observer to register
   * @see Document#addDocumentListener
   * @see javax.swing.text.Document
   */
   public void removeDocumentListener(DocumentListener listener)
   {
      mDocument.removeDocumentListener(listener);
   }


   /**
   * Method delegates to the swing Document object of the associated 
   * text component.
   * <p>
   * Unregisters the given observer from the notification list
   * so it will no longer receive updates.
   *
   * @param listener the observer to register
   * @see javax.swing.event.UndoableEditEvent
   * @see javax.swing.text.Document
   */
   public void removeUndoableEditListener(UndoableEditListener listener)
   {
      mDocument.removeUndoableEditListener(listener);
   }


   /**
   * Method delegates to the swing Document object of the associated 
   * text component.
   * <p>
   * This allows the model to be safely rendered in the presence
   * of currency, if the model supports being updated asynchronously.
   * The given runnable will be executed in a way that allows it
   * to safely read the model with no changes while the runnable
   * is being executed.  The runnable itself may <em>not</em>
   * make any mutations.  
   *
   * @param r a Runnable used to render the model
   * @see javax.swing.text.Document
   */
   public void render(Runnable r)
   {
      mDocument.render(r);
   }

   /**
   * This method is used by the JDeveloper designtime wizards for binding a text component
   * with an attribute of rows of a ViewObject/RowIterator.
   * This method calls JUFormBinding.getRowIterBinding to get the iterator binding using
   * the given parameters and then registers a new JUTextFieldBinding with the iterator
   * binding object so as to display/edit the current row's attribute of the given name.
   * <p>
   * @param formBinding The containing JUPanelBinding in which the given iterator binding
   * would be found/created.
   * @param control The control instance to bind to a ViewObject's attribute.
   * @param voInstanceName Name of the instance of the ViewObject in a BC4J ApplicationModule.
   * @param voIterName Runtime instance name of the iterator in the ViewObject (optional).
   * @param voIterBindingName Instance name of the iterator binding that uniquely identifies an
   * iterator binding object used to read/write data in this given JUPanelBinding instance.
   * @param attrName The name of the attribute of this ViewObject rows that contains data
   * to display/edit in the associated text control.
   * @return Document object bound to the given text control.
   */
   public static Document createAttributeBinding( JUFormBinding formBinding, 
                                                  JTextComponent control,
                                                  String        voInstanceName,
                                                  String        voIterName, /*temporarily taking nulls for this*/
                                                  String        voIterBindingName,
                                                  String        attrName)
   {
      if (!JUIUtil.inDesignTime())
      {
         JUTextFieldBinding bind = new JUTextFieldBinding(control, 
                                       formBinding.getRowIterBinding(voInstanceName, voIterName, voIterBindingName),
                                       attrName);
         bind.refreshControl();
         return bind.getModelImpl(null);
      }
      else
      {
         try
         {
            Class clazz = Class.forName("oracle.jbo.dt.ui.jui.propertyeditors.dtmodels.DTJTextFieldBinding");
            java.lang.reflect.Constructor constructor = clazz.getConstructors()[0];
            Object [] args = { voInstanceName + "." + attrName };
            Object object = constructor.newInstance(args);
            return (Document)object;
         }
         catch (Exception e)
         {
            return null;
         }
      }
   }

   /**
   * @deprecated since JDeveloper 9.0.2
   */
   public static Document getInstance(JUFormBinding formBinding, 
                                                  JTextComponent control,
                                                  String        voInstanceName,
                                                  String        voIterName,
                                                  String        voIterBindingName,
                                                  String        attrName)
   {
      return createAttributeBinding(formBinding, control, voInstanceName, voIterName, voIterBindingName, attrName);
   }
}
