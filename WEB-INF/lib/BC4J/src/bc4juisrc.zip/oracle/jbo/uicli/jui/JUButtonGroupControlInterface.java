/*
 * @(#)JUButtonGroupControlInterface.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.uicli.jui;

import javax.swing.AbstractButton;

/**
 * A control implements this interface if it binds to a JUButtonGroupBinding and 
 * is responsible for creating AbstractButtons to render/display the associated attribute
 * for all rows in the associated RowSetIterator. JURadioButtonGroupPanel implements
 * this interface in the framework to display a series of radio buttons grouped in 
 * one button group.
 * @see oracle.jbo.uicli.controls.JURadioButtonGroupPanel
 * @see oracle.jbo.uicli.jui.JUButtonGroupBinding
 */
public interface JUButtonGroupControlInterface
{
   /**
   * Creates buttons for each object in the given list and adds it to the control's
   * display.
   */
   AbstractButton[] createButtons(Object object[]);
}
