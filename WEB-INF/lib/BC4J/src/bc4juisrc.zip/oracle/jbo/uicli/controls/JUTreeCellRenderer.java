/*
 * @(#)JUTreeCellRenderer.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.uicli.controls;

import javax.swing.Icon;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeCellRenderer;
import oracle.jbo.uicli.binding.JUCtrlHierTypeBinding;
import oracle.jbo.uicli.jui.JUTreeNodeBinding;

public class JUTreeCellRenderer extends DefaultTreeCellRenderer
{
   public JUTreeCellRenderer() 
   {
      super();
   }

   public java.awt.Component getTreeCellRendererComponent(javax.swing.JTree tree, Object value,
                 boolean sel,
                 boolean expanded,
                 boolean leaf, int row,
                 boolean hasFocus) 
   {
      //this code is pretty much replica of javax.swing.tree.DefaultTreeCellRenderer.
      
      Icon icon = null;

      //has to be DefaultMutableTreeNode ???
      boolean nodeSpecifiedIcon = false;
      Object userObject = ((DefaultMutableTreeNode)value).getUserObject();
      if (userObject instanceof JUTreeNodeBinding) 
      {
         JUCtrlHierTypeBinding nodeType = ((JUTreeNodeBinding)userObject).getHierTypeBinding();
         
         if (nodeType != null && (nodeSpecifiedIcon = nodeType.hasIcon()))
         {
            //shouldn't all entries be JUTreeNodeBinding?
            icon = (leaf) 
                      ? nodeType.getLeafIcon() 
                      : ((expanded) 
                         ? nodeType.getOpenIcon() 
                         : nodeType.getClosedIcon());
         }
      }
      if (!nodeSpecifiedIcon) 
      {
         icon = (leaf) ? getLeafIcon() : ((expanded) ? getOpenIcon() : getClosedIcon());
      }
      
      this.selected = sel;
      this.hasFocus = hasFocus;

      setText(tree.convertValueToText(value, sel, expanded, leaf, row, hasFocus));
      
      if(sel)
      {
         setForeground(getTextSelectionColor());
      }
      else
      {
         setForeground(getTextNonSelectionColor());
      }

      if (!tree.isEnabled()) 
      {
         setEnabled(false);
         setDisabledIcon(icon);
      }
      else 
      {
         setEnabled(true);
         setIcon(icon);
      }
      
      setComponentOrientation(tree.getComponentOrientation());
      return this;
   }
}
