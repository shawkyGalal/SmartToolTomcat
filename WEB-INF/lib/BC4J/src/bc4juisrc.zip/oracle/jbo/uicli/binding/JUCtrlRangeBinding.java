/*
 * @(#)JUCtrlRangeBinding.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.uicli.binding;

import oracle.jbo.NavigationEvent;
import oracle.jbo.Row;
import oracle.jbo.RowIterator;
import oracle.jbo.RowSetIterator;
import oracle.jbo.ScrollEvent;

/**
 * A JUControlBinding class responsible for binding controls/models
 * that are bound to a range of Row objects in the BC4J layer.
 * This class:
 * <ul>
 * <li>Is responsible for updating the Control Bindings with attribute values
 * from the BC4J Row objects for all attributes that this Control Binding is bound to
 * by calling setValueAt() method for each attribute value with approprate row, column and
 * value information.
 * <li>Declares (abstract) methods that all subclasses need to implement
 * to handle Scroll and Navigation events from the BC4J RowIterator.
 * </ul>
 */
abstract public class JUCtrlRangeBinding extends JUCtrlValueBinding
{
   /**
   * Returns the value as stored in the control at a given row and column index.
   * This value is used by the binding to update attribute values in BC4J rows.
   */
   abstract public Object getValueAt(int rowIndex, int attrIndex);

   /**
   * Sets the given value from a BC4J row into the control at the given row/column.
   * This method is used by the framework to pass attribute values from Row objects into
   * a control with which this binding works.
   */
   abstract public void setValueAt(Object value, int rowIndex, int attrIndex);


   /**
   * This constructor passes on the control, iterator, and attribute binding information
   * to its super.
   */
   public JUCtrlRangeBinding(Object control, JUIteratorBinding iterBinding, String[] attrNames)
   {
      super(control, iterBinding, attrNames);
   }


   /**
   * Returns the number of rows in the collection defined by the
   * associated ViewObject's query (if this control is in data display mode).
   * If this control is in find mode, returns the number of rows in the 
   * associated ViewCriteria object.
   */
   public long getEstimatedRowCount()
   {
      RowIterator iter = getRowIterator();

      if (getIteratorBinding().isFindMode())
      {
         return iter.getRowCount();
      }
      else if (iter != null) 
      {
         try
         {
            return ((RowSetIterator)iter).getRowSet().getEstimatedRowCount();
         }
         catch(Exception ex)
         {
            reportException(ex);
         }
      }

      return 0;
   }


   /**
   * This method is called in the framework when values of a single row need to be 
   * updated in a control (typically on a navigation event). 
   */
   public void updateValuesFromRow(Row row)
   {
      updateValuesFromRows(new Row[] { row }, false /*clear*/);
   }


   /**
   * This method is invoked in the framework to update values displayed in the associated 
   * control. This implementation updates all values given in the array of rows irrespective
   * of the clear flag (which indicates whether to clear out the existing displayed values or not).
   */
   public void updateValuesFromRows(Row[] rows, boolean clear)
   {
      int ct = getAttributeCount();
      int rCt = rows.length;

      Row r;
      for (int i = 0; i < rCt; i++)
      {
         r = rows[i];
         for (int j = 0; j < ct; j++)
         {
            Object value = getAttributeFromRow(r, j);
            setValueAt(value, i, j);
         }
      }
   }

   
   /**
   * Method to handle scroll events from the BC4J iterator. Subclasses need to implement
   * this method to update the currently displayed rowset (if desired).
   */
   public void updateRangeScrolled(ScrollEvent event)
   {
   }


   /**
   * Method to handle Navigation event from the BC4J iterator. Subclasses need to implement
   * this method to update their current row display (if desired).
   */
   public void updateNavigated(NavigationEvent event)
   {
   }

   /**
   * *** For internal framework use only ***
   * <p>
   * Updates the values in a control that is bound using an Iterator already in use.
   * (a valid row iterator)
   * If you do not call this method, your control won't update unless you refresh the Iterator.
   */
   public void refreshControl()
   {
      if (getRowIterator() == null)
         return;

      if (getRowIterator().getCurrentRowSlot() == oracle.jbo.RowIterator.SLOT_VALID)
      {
         updateValuesFromRows(getAllRowsInRange(), false);
      }
      
   }
   
}
