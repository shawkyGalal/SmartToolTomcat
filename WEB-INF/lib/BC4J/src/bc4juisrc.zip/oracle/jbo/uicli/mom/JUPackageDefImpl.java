/*
 * @(#)JUPackageDefImpl.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.uicli.mom;

import oracle.jbo.common.Diagnostic;
import oracle.jbo.mom.ContainerDefImpl;
import oracle.jbo.mom.xml.DefElementImpl;
import oracle.jbo.mom.xml.JTXMLTags;

class JUPackageDefImpl extends ContainerDefImpl
{
   JUPackageDefImpl()
   {
      super(JUMetaObjectManager.getJUMom());
   }

   
   protected com.sun.java.util.collections.ArrayList getContainerDefNames(boolean recursive)
   {
      return getPackageDefNames(recursive);
   }

   
   com.sun.java.util.collections.ArrayList getPackageDefNames(boolean recursive)
   {
      com.sun.java.util.collections.ArrayList v = new com.sun.java.util.collections.ArrayList();

      getChildObjectNames(recursive, JTXMLTags.PACKAGE, v);

      return v;
   }

   
   protected ContainerDefImpl createContainerType(String typeName)
   {
      if (typeName.equalsIgnoreCase(JTXMLTags.PACKAGE))
      {
         return new JUPackageDefImpl();
      }

      return null;
   }

   
   public void loadContainees(DefElementImpl xmlElement, boolean sepXMLFiles) 
   {
      if ( sepXMLFiles )
      {
         Diagnostic.println("Loading from indvidual XML files");
         // If the Application is not Lazily loaded then only load the
         // contents
         loadContainees(xmlElement);
      }
      else
      {
         // All the elements in this package are in one XML file
         // loadEntities(xmlElement);
         // loadAssociations(xmlElement);
         // loadViewObjects(xmlElement);
         // loadViewLinks(xmlElement);
         // loadAppModules(xmlElement);
      }
   }

   
   protected void setIsProject(boolean isProject)
   {
      super.setIsProject(isProject);
   }

   
   protected void loadFromXMLFile(DefElementImpl xmlElement) 
   {
      super.loadFromXMLFile(xmlElement);
   }
}
