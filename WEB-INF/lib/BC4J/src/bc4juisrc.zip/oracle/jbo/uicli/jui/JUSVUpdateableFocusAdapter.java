/*
 * @(#)JUSVUpdateableFocusAdapter.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.uicli.jui;

import java.awt.event.FocusEvent;
import oracle.jbo.uicli.binding.JUCtrlAttrsBinding;
import oracle.jbo.uicli.binding.JUCtrlValueBinding;

/**
 * This focus adapter class is registered by controls that should perform setAttribute
 * on the binding directly upon focusOut. Bindings for TextField, ProgressBar, Slider, and
 * ScrollBar register an instance of this adapter as a FocusListener on the associated
 * control and upon focus out, the focusLost() performs a setAttribute() on the control
 * binding to update the value from the control to the BC4J attribute if the attribute
 * value has changed.
 */
public class JUSVUpdateableFocusAdapter extends JUSVFocusAdapter
{
   JUCtrlValueBinding mAttrBinding;

   /**
   * Creates an instance of this adapter for the given control binding and registers
   * an interest in the attribute at the given index (for most controls this value
   * is zero) in the control binding.
   */
   public JUSVUpdateableFocusAdapter(JUCtrlValueBinding controlBinding, int attrIndex)
   {
      super(controlBinding, attrIndex);
      if (attrIndex > -1) 
      {
         oracle.jbo.common.Diagnostic.ASSERT(controlBinding instanceof JUCtrlAttrsBinding);
      }
      mAttrBinding = controlBinding;
   }


   /**
   * Performs a setAttribute() on the control binding to save the changes made by 
   * the control to the attribute value.
   */
   public void focusLost(FocusEvent e)
   {
      if (e.isTemporary())
      {
         return;
      }

      JUCtrlAttrsBinding binding = (JUCtrlAttrsBinding)mAttrBinding;

      if (binding.getIteratorBinding() == null) 
      {
         //iterator binding is released.
         return;
      }
      

      Object cVal = binding.getValueAt(mAttrIndex);    // Value from the control
      Object dVal = binding.getAttribute(mAttrIndex);  // value from the row

      // If value is the same, don't do anything
      if (cVal == dVal)
      {
         return;
      }

      // Here "" is the definiton of a null value
      String cStr = (cVal == null) ? "" : cVal.toString();
      String dStr = (dVal == null) ? "" : dVal.toString();

      if (!cStr.equals(dStr))
      {
         try
         {
            mAttrBinding.setAttribute(mAttrIndex, cVal);
         }
         catch (oracle.jbo.JboException ex)
         {
            mAttrBinding.reportException(ex, true);
         }
      }
   }
}
