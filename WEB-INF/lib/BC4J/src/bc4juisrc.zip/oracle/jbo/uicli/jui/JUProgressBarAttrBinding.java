/*
 * @(#)JUProgressBarAttrBinding.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.uicli.jui;

import java.awt.Component;
import javax.swing.BoundedRangeModel;
import javax.swing.DefaultBoundedRangeModel;
import javax.swing.JPanel;
import javax.swing.JProgressBar;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import oracle.jbo.uicli.binding.JUCtrlAttrsBinding;
import oracle.jbo.uicli.binding.JUIteratorBinding;

/**
 * Implements binding a JProgressBar control with a BC4J attribute.
 * <p>
 * This binding sets the minimum, maximum, and extent values of the ProgressBar and on change of currency
 * in the associated rowset, displays the associated value by adjusting the ProgressBar between the minimum
 * and maximum values. Note that the minimum and maximum values should be provided such that all possible
 * values of the associated attribute in a RowSet can be displayed in the ProgressBar.
 */
public class JUProgressBarAttrBinding extends JUCtrlAttrsBinding implements BoundedRangeModel, ChangeListener 
{
   private BoundedRangeModel mSBModel = null;
   boolean mSettingValue = false;
   int mMax = 100;
   int mMin = 0;
   int mExt = 1;

   /**
   * Binds the given ProgressBar control to display and update values from the given attribute
   * in a BC4J RowSet.
   * @param control JProgressBar control to bind a BC4J attribute with.
   * @param iterBinding Iterator binding that provides the RowSet with which this binding should work.
   * @param attrName The attribute name in the RowSet with which this binding works.
   * @param min Minimum value that the JSlider displays (what the starting value should be in
   * the JProgressBar control.
   * @param max Maximum value that the JProgressBar displays (what the end value should be in the control).
   */
   public JUProgressBarAttrBinding(JProgressBar control, JUIteratorBinding iterBinding, String attrName,
                              int min, int max)
   {
      super(control, iterBinding, new String[] { attrName });

      mMin = min;
      mMax = max;
      //mExt = ext;
      init(control);

   }


   private void init(JProgressBar sb)
   {
      mSBModel = getModelImpl(sb);

      if (sb != null)
      {
         if (mSBModel != sb.getModel())
         {
            sb.setModel(mSBModel);
         }
         // this set has no effect as subsequent setModel cleans it up.
         sb.setMinimum(mMin);
         sb.setMaximum(mMax);
         //sb.setExtent(mExt);
         //sb.setPaintTicks(true);
         //sb.setMajorTickSpacing(mExt);
         //sb.setSnapToTicks(true);
         // this set has no effect as subsequent setModel cleans it up.


         sb.addChangeListener(this);
         sb.addFocusListener(new JUSVUpdateableFocusAdapter(this, 0));
      }
   }


   /**
   * Registers the BoundedRangeModel that this binding works with. If the progress bar
   * has a model, this method registers it with this binding and returns the model.
   * If the control or model is null, then this method creates a DefaultBoundedRangeModel
   * and returns it.
   */
   protected BoundedRangeModel getModelImpl(JProgressBar sb)
   {
      BoundedRangeModel sbModel = mSBModel;

      if (sbModel == null)
      {
         if (sb != null)
         {
            sbModel = sb.getModel();
         }

         if (sbModel == null)
         {
            sbModel = new DefaultBoundedRangeModel();
         }
      }

      return sbModel;
   }

   
   /**
   * *** For internal framework use only ***
   */
   public void addControlToPanel(Object panel, Object layoutObject, Object layoutCons)
   {
      ((JPanel) panel).add((Component) layoutObject, layoutCons);
   }

   
   /**
   * Returns the current value indicated by the ProgressBar control.
   */
   public Object getValueAt(int attrIndex)
   {
      return new Integer(((JProgressBar) getControl()).getValue());
   }


   boolean mInit = false;
   /**
   * Sets the current value in the JProgressBar control. This method adjusts the position of JProgressBar
   * current value indicator based on the input value and the minimum and maximum value the JProgressBar
   * is set to handle.
   */
   public void setValueAt(Object value, int attrIndex)
   {
      if (mSBModel != null) 
      {
         if (!mInit) 
         {
            mInit = true;
            JProgressBar sb  = (JProgressBar)getControl();
            sb.setMinimum(mMin);
            sb.setMaximum(mMax);
            
            /*
            sb.setExtent(0);
            sb.setPaintTicks(true);
            sb.setMajorTickSpacing(mExt);
            sb.setSnapToTicks(true);
            */
         }

         Integer integerVal = (Integer)oracle.jbo.domain.TypeFactory.getInstance(java.lang.Integer.class, value);
         if (integerVal != null) 
         {
            try
            {
               mSettingValue = true;
               
               JProgressBar sb  = (JProgressBar)getControl();
               if (sb != null) 
               {
                  sb.setValue(integerVal.intValue());
               }
               else
               {
                  mSBModel.setValue(integerVal.intValue());
               }
            }
            finally
            {
               mSettingValue = false;
            }
         }
      }
      //((JSlider) getControl()).setText(value == null ? "" : value.toString());
   }

   /**
   * Returns true, so that ProgressBar can participate in a query in the Find Mode of the
   * containing panel. When the containing panel Binding object is set to Find mode, it queries
   * all control-bindings in it and disables those controls whose bindings return false
   * for this method during the Find mode. The return value from this method indicates 
   * whether to consult an attribute definition for queriability.
   * <p>
   * An application could create a subclass of this binding object and return false from this
   * method to prevent the associated control from participating in find mode. Additionally, a
   * BC4J attribute itself can control whether that attribute can participate in Query or
   * not. That property takes precedence over this method's return, if this method returns true.
   * In other words, if this binding is bound to a CLOB attribute type and the attribute
   * definition for that attribute indicates that it is not queriable, then the default behavior
   * of JUPanelBinding in Find mode will be to disable this binding's control, even though
   * this method returns true.
   */
   protected boolean isControlQueriable()
   {
      return true;
   }

   /**
   * Use this method to update the ProgressBar value, as well as the value in the associated BC4J attribute.
   */
   public void setDataValueAt(Object value, int attrIndex)
   {
      setValueAt(value, attrIndex);

      setAttribute(0, value);
   }

   /**
   * Sets the BC4J attribute value as per the change in the JProgressBar current value.
   */
   public void stateChanged(ChangeEvent e) 
   {
      if (!mSettingValue && !mSBModel.getValueIsAdjusting())
      {
         
         try
         {
            setAttribute(0, getValueAt(0));
         }
         catch (Exception ex)
         {
            reportException(ex, true);
         }
      }
   }

   //
   // BoundedRangeModel implementation
   //
   
   public int getMinimum()
   {
      return mSBModel.getMinimum();
   }


   public void setMinimum(int newMinimum)
   {
      mSBModel.setMinimum(newMinimum);
   }


   public int getMaximum()
   {
      return mSBModel.getMaximum();
   }


   public void setMaximum(int newMaximum)
   {
      mSBModel.setMaximum(newMaximum);
   }


   public int getValue()
   {
      return mSBModel.getValue();
   }


   public void setValue(int newValue)
   {
      mSBModel.setValue(newValue);
   }


   public void setValueIsAdjusting(boolean b)
   {
      mSBModel.setValueIsAdjusting(b);
   }


   public boolean getValueIsAdjusting()
   {
      return mSBModel.getValueIsAdjusting();
   }


   public int getExtent()
   {
      return mSBModel.getExtent();
   }


   public void setExtent(int newExtent)
   {
      mSBModel.setExtent(newExtent);
   }

   public void setRangeProperties(int value, int extent, int min, int max, boolean adjusting)
   {
      mSBModel.setRangeProperties(value, extent, min, max, adjusting);
   }


   public void addChangeListener(ChangeListener x)
   {
      mSBModel.addChangeListener(x);
   }


   public void removeChangeListener(ChangeListener x)
   {
      mSBModel.removeChangeListener(x);
   }

   /**
   * Creates a binding for the JProgressBar control.
   * @param formBinding The containing JUPanelBinding in which the given iterator binding
   * would be found/created.
   * @param control JProgressBar control to bind a BC4J attribute with.
   * @param voInstanceName Name of the instance of the ViewObject in a BC4J ApplicationModule.
   * @param voIterName Runtime instance name of the iterator in the ViewObject (optional).
   * @param voIterBindingName Instance name of the iterator binding that uniquely identifies an
   * iterator binding object used to read/write data in this given JUPanelBinding instance.
   * @param attrName The attribute name in the RowSet with which this binding works.
   * @param min Minimum value that the JProgressBar displays (what the starting value should be in
   * the JSlider control).
   * @param max Maximum value that the JProgressBar displays (what the end value should be in the control).
   */
   public static BoundedRangeModel createAttributeBinding(JUPanelBinding formBinding, 
                                               JProgressBar       control,
                                               String        voInstanceName,
                                               String        voIterName, /*temporarily taking nulls for this*/
                                               String        voIterBindingName,
                                               String        attrName,
                                               int           min, 
                                               int           max)
   {
      if (!JUIUtil.inDesignTime())
      {
         JUProgressBarAttrBinding bind = new JUProgressBarAttrBinding(control, 
                                       formBinding.getRowIterBinding(voInstanceName, voIterName, voIterBindingName),
                                       attrName, min, max);
         bind.refreshControl();
         //formBinding.addIteratorChangedListener(bind);
         return bind.getModelImpl(control);
      }
      else
      {
         try
         {
            Class clazz = Class.forName("oracle.jbo.dt.ui.jui.propertyeditors.dtmodels.DTJProgressBarAttrBinding");
            java.lang.reflect.Constructor constructor = clazz.getConstructors()[0];

            Object [] args = {(new StringBuffer(voInstanceName)
                                  .append('.').append(attrName)).toString(),
                              Integer.toString(min), 
                              Integer.toString(max)};
            Object object = constructor.newInstance(args);
            return (BoundedRangeModel)object;
         }
         catch (Exception e)
         {
            return null;
         }
      }
   }

   /**
   * @deprecated since 9.0.2 use createAttributeBinding method instead.
   */
   public static BoundedRangeModel getInstance(JUPanelBinding formBinding, 
                                               JProgressBar       control,
                                               String        voInstanceName,
                                               String        voIterName, /*temporarily taking nulls for this*/
                                               String        voIterBindingName,
                                               String        attrName,
                                               int           min, 
                                               int           max)
   {
      return createAttributeBinding(formBinding, control, voInstanceName, voIterName, voIterBindingName, attrName, min, max);
   }
}
