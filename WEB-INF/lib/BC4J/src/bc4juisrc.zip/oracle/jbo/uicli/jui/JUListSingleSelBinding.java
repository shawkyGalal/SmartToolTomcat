/*
 * @(#)JUListSingleSelBinding.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.uicli.jui;

import java.awt.Component;
import java.util.ArrayList;
import javax.swing.DefaultListModel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.ListCellRenderer;
import javax.swing.ListModel;
import javax.swing.event.ListDataListener;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import oracle.jbo.AttributeDef;
import oracle.jbo.Row;
import oracle.jbo.RowIterator;
import oracle.jbo.ViewObject;
import oracle.jbo.uicli.binding.JUCtrlListBinding;
import oracle.jbo.uicli.binding.JUFormBinding;
import oracle.jbo.uicli.binding.JUIteratorBinding;
import oracle.jbo.uicli.controls.JUMultiAttrListCellRenderer;

/**
 * Implements binding a Swing JList (in single selection mode)
 *  to a BC4J Attribute, ViewObject, or as an LOV.
 * <p>
 * A list can be bound in the following ways:
 * <ul>
 * <li>Display single or multiple attributes for rows in a RowSet and
 * iterate the rowset currency.
 * <li>Display a single attribute from rows in a RowSet and update another attribute
 * in a different ViewObject.
 * <li>Display single or multiple attributes from rows in a RowSet and update one or
 * multiple attributes in a different ViewObject (similar to an LOV).
 * <li>Display a static LOV and update one attribute in a BC4J row.
 * </ul>
 * <p>
 * This class also implements ListSelectionListener interface and listens to ListSelectionEvent from
 * the bound list. On selection event, it either performs an update of the target
 * ViewObject attributes or iterates a target ViewObject based on the list operation mode
 * set in the constructor.
 */
public class JUListSingleSelBinding extends JUCtrlListBinding implements ListSelectionListener, ListModel
{
   private ListModel mListModel = null;
   private int mSelectionIndex = -1;
   private boolean mShouldScroll = true;
   private boolean mSettingValue = false;
   private JScrollPane mScrollPane;


   /**
   * Binds a ListBox to a RowSet associated with the given iterator binding and, 
   * based on listOperMode setting, either iterates the currency on the target iterator
   * or updates the attribute value for the given attribute (in attrNames) in the current
   * row in the target RowSet. Note that the list will display and (optionally) update 
   * the same attribute from a RowSet.
   * @param list JList control instance with which to associate this binding.
   * @param iterBinding Provides the RowSet from which this binding accesses data 
   * to display in the list and optionally provides the current row in which attribute(s)
   * is to be updated.
   * @param attrNames An ordered array of attribute names to display and optionally update
   * in a ViewObject.
   * @param listOperMode Can be one of two values:
   * <ul>
   * <li> LIST_OPER_SET_ATTRIBUTE (default) to indicate that this list
   * is to be used to update attributes in the current row of the associated RowSet.
   * <li> LIST_OPER_NAVIGATE to indicate that this list should be used to 
   * iterate currency in the associated RowSet.
   * </ul>
   * @param shouldScroll When true, indicates scroll the selected item into view
   * if it is not being displayed in the current viewport.
   */
   public JUListSingleSelBinding(JList list, JUIteratorBinding iterBinding,
                                 String[] attrNames, int listOperMode, boolean shouldScroll)
   {
      super(list, iterBinding, attrNames, listOperMode);

      init(list, shouldScroll);
   }


   
   /**
   * Binds a JList to an attribute in the associated RowSet. The values displayed in ListBox
   * are provided by the valueList objects.
   * @param list JList control instance with which to associate this binding.
   * @param iterBinding Provides the RowSet that is used to update current selection 
   * from the listbox into the current row in the rowset.
   * @param attrNames Provides the name of an attribute (only one attribute is updateable in 
   * this mode).
   * @param valueList A static list of values that are displayed in the listbox as options 
   * from which to select.
   * @param shouldScroll When true, indicates scroll the selected item into view
   * if it is not being displayed in the current viewport.
   */
   public JUListSingleSelBinding(JList list, JUIteratorBinding iterBinding,
                                 String[] attrNames, Object[] valueList, boolean shouldScroll)
   {
      super(list, iterBinding, attrNames, valueList);

      init(list, shouldScroll);
   }


   /**
   * Binds separate ViewObject/RowSets for display and updates to the same listbox.
   * Use this binding constructor to provide a separate iterator binding for update
   * and a separate iterator binding which provides rows for display in the listbox.
   * Optionally, the attributes displayed can be different from the attributes that 
   * should be used to update a corresponding set of attributes in the target/updateable 
   * ViewObject.
   * <p>
   * @param list JList control instance to associate this binding with.
   * @param iterBinding Provides the RowSet in which the current row is updated
   * based on selection in the listbox.
   * @param attrNames An ordered array of attribute names to update
   * in a ViewObject. This list should have the same number of attributes as
   * in listAttrNames which provides the corresponding attribute names from the 
   * display ViewObject/RowSet.
   * @param listIterBinding Provides the RowSet that is used to display data in the
   * listbox.
   * @param listAttrNames An ordered list of attribute names which are used to 
   * get the values to update into the attributes from the attrNames list in the
   * target ViewObject. If this list is null, the attribute names for display 
   * are set to the same as attrNames.
   * @param listDisplayAttrNames An ordered list of attribute names that specify
   * the attributes to display from rows in the display ViewObject/RowSet.
   * If this list is null, attribute names are assumed to be same as in attrNames. 
   * @param shouldScroll When true, indicates scroll the selected item into view
   * if it is not being displayed in the current viewport.
   */

   public JUListSingleSelBinding(JList list, JUIteratorBinding iterBinding,
                                 String[] attrNames, JUIteratorBinding listRSI,
                                 String[] listAttrNames, String[] listDisplayedAttrNames,
                                  boolean shouldScroll)
   {
      // sim 5/11/01 -- If listRSI is null, we get the values
      //    from iterBinding, i.e., the list is formed from iterBinding.
      super(list, iterBinding, attrNames, listRSI, listAttrNames, listDisplayedAttrNames);

      init(list, shouldScroll);
   }


   private void init(JList list, boolean shouldScroll)
   {
      mListModel = getModelImpl(list);
      mShouldScroll = shouldScroll;

      if (list != null)
      {
         if (mListModel != list.getModel())
         {
            list.setModel(mListModel);
         }
         
         if (mValueList != null && mStaticList) 
         {
            setupListItems(false, false);
         }
         //list.addListSelectionListener(this);
      }
   }

   /**
   * This method is used by the framwork to setup the list of values that will be displayed in
   * this listbox.
   * @param clean Controls whether to clean the existing entries in the listbox.
   * @param keepSelectedIndex Indicates whether to maintain current index as the selected index 
   * after the display data is updated. If this value is true, the current index is maintained.
   * However, if the current index is more than the number of items in the listbox, the selection
   * is reset to the first item.
   */
   protected void setupListItems(boolean clean, boolean keepSelectedIndex)
   {
      JList list = (JList)getControl();
      
      list.removeListSelectionListener(this);
      
      list.setListData(new Object[0]);

      if (mValueList == null || clean) 
      {
         super.setupListItems(clean, keepSelectedIndex);
      }

      list.setListData(getValueList());

      //
      // sim 9/13/01 -- JList.setListData creates a new model
      //    object for the list.  So, we need to refresh.
      //
      mListModel = list.getModel();
      if (getIteratorBinding() != null) 
      {
         Row r = getCurrentRow();
         if (r != null) 
         {
            mSettingValue = true;
            try
            {
               updateValuesFromRow(r);
               //so that it does not come all over again.
            }
            finally
            {
               mSettingValue = false;
            }
         }
      }

      list.addListSelectionListener(this);
   }
   
   /**
   * Sets the model reference in this binding class by using the current
   * model in the listbox. Returns the same model reference. If there is
   * no model in the lsitbox, creates a DefaultListModel and returns that.
   */
   protected ListModel getModelImpl(JList control)
   {
      ListModel listModel = mListModel;
      if (listModel == null)
      {
         if (control != null)
         {
            listModel = control.getModel();
         }
   
         if (listModel == null)
         {
            listModel = new DefaultListModel();
         }
      }

      return listModel;
   }

   
   /**
   * *** For internal framework use only ***
   */
   public void addControlToPanel(Object panel, Object layoutObject, Object layoutCons)
   {
      ((JPanel) panel).add((Component) layoutObject, layoutCons);
   }

   
   /**
   * *** For internal framework use only ***
   */
   public Object getLayoutObject()
   {
      if (mScrollPane == null)
      {
         return getControl();
      }
      else
      {
         return mScrollPane;
      }
   }

   
   /**
   * *** For internal framework use only ***
   */
   public void setLayoutObject(JScrollPane scrollPane)
   {
      mScrollPane = scrollPane;
   }

   

   /**
   * Returns true, so that JTextComponents can participate in a query in the Find Mode of the
   * containing panel. When the containing panel Binding object is set to Find mode, it queries
   * all control-bindings in it and disables those controls whose bindings return false
   * for this method during the Find mode. The return value from this method indicates 
   * whether to consult an attribute definition for queriability.
   * <p>
   * An application could create a subclass of this binding object and return false from this
   * method to prevent the associated control from participating in find mode. Additionally, a
   * BC4J attribute itself can control whether that attribute can participate in Query or
   * not. That property takes precedence over this method's return, if this method returns true.
   * In other words, if this binding is bound to a CLOB attribute type and the attribute
   * definition for that attribute indicates that it is not queriable, then the default behavior
   * of JUPanelBinding in Find mode will be to disable this binding's control, even though
   * this method returns true.
   */
   protected boolean isControlQueriable()
   {
      return true;
   }

   /**
   * Finds the item in the list that matches the given value and sets it as the current item.
   * @param value This value is used in findMatchingListValue method to find out the item in
   * the list that represents the given value. If the value is not found, no item is selected
   * in the list.
   * @param attrIndex This argument is ignored by this method.
   */
   public void setValueAt(Object value, int attrIndex)
   {
      //if (getListOperMode() == LIST_OPER_NAVIGATE) 
      {
         if (attrIndex > 0) 
         {
            //only look up by first attribute.
            return;
         }
      }
      Object val = findMatchingListValue(value);

      try
      {
         mSettingValue = true;

         //val could be null when a value is set via other means that cannot be found in this list.
         if (val != null)
         {
            ((JList) getControl()).setSelectedValue(val, mShouldScroll);
         }
         else
         {
            //in case value is not in list, set reset selection.
            ((JList) getControl()).setSelectedIndices(new int[] {});
         }
      }
      finally
      {
         mSettingValue = false;
      }
   }


   /**
   * This method is overridden to be a noop.
   */
   public void setDataValueAt(Object value, int attrIndex)
   {
   }

   
   /**
   * Sets the item at the given index as current selection in the listbox.
   */
   public void setSelectedIndex(int listIndex)
   {
      super.setSelectedIndex(listIndex);

      if (listIndex >= 0)
      {
         ((JList) getControl()).setSelectedValue(getValueFromList(listIndex), mShouldScroll);
      }
      else
      {
         ((JList) getControl()).setSelectedIndices(new int[] {});
      }
   }

   
   /**
   * Based on listOperMode, this binding either navigates the target rowset to the selected
   * row or sets the attribute/attributes based on the settings in the constructor.
   */
   public void valueChanged(ListSelectionEvent e) 
   {
      //
      // 'e.getValueIsAdjusting() == true' means that the event was fired
      // when the mouse was pressed down.  We ignore that and wait until
      // we get 'e.getValueIsAdjusting() == false' which means that the
      // mouse is released.
      //
      if (!mSettingValue && !e.getValueIsAdjusting())
      {
         try
         {
            int selIndex = ((JList) getControl()).getSelectedIndex();

            if (getListOperMode() == LIST_OPER_NAVIGATE)
            {
               if (selIndex >= 0)
               {
                  RowIterator rsi = getRowIterator();

                  if (rsi != null)
                  {
                     ((JUPanelBinding)getFormBinding()).callBeforeRowNavigated(getIteratorBinding());
                     rsi.setCurrentRowAtRangeIndex(selIndex);
                  }
               }
            }
            else
            {
               updateTargetFromSelectedValue(getValueFromList(selIndex));
            }
         }
         catch(Exception ex)
         {
            reportException(ex);
         }
      }
   }

   
   //
   // ListModel implementation
   //

   public int getSize()
   {
      return mListModel.getSize();
   }


   public Object getElementAt(int index)
   {
      return mListModel.getElementAt(index);
   }
   

   public void addListDataListener(ListDataListener l)
   {
      mListModel.addListDataListener(l);
   }
   

   public void removeListDataListener(ListDataListener l)
   {
      mListModel.removeListDataListener(l);
   }

   public static ListModel createLovBinding(JUFormBinding    formBinding, 
                                                  JList     control,
                                                  String        voInstanceName,
                                                  String        voIterName, // temporarily taking nulls for this
                                                  String        voIterBindingName,
                                                  String[]      attrNames,
                                                  String        listVOInstanceName)
   {
      return createLovBinding(formBinding, control, voInstanceName, voIterName,
                         voIterBindingName, attrNames, listVOInstanceName, attrNames,
                         null, null);
   }

   /**
   * @deprecated since 9.0.2 use createEnumerationBinding, createNavigationBinding or createLovBinding instead
   */
   public static ListModel getInstance(JUFormBinding    formBinding, 
                                                  JList     control,
                                                  String        voInstanceName,
                                                  String        voIterName, // temporarily taking nulls for this
                                                  String        voIterBindingName,
                                                  String[]      attrNames,
                                                  String        listVOInstanceName)
   {
      return createLovBinding(formBinding, control, voInstanceName, voIterName, 
                                                     voIterBindingName, attrNames, listVOInstanceName);
   }

   /**
   * Use this method to bind a list control to a ViewObject/RowSet, identified by voInstanceName,
   * when a static list of values are displayed in the listbox, and the listbox is used to display/update
   * the same attribute in the same viewobject.
   */
   public static ListModel createEnumerationBinding(JUFormBinding    formBinding, 
                                                  JList     control,
                                                  String        voInstanceName,
                                                  String        voIterName, // temporarily taking nulls for this
                                                  String        voIterBindingName,
                                                  String        attrName,
                                                  Object        values[])
   {
      if (!JUIUtil.inDesignTime())
      {
         JUListSingleSelBinding bind = new JUListSingleSelBinding(control, 
                                       formBinding.getRowIterBinding(voInstanceName, voIterName, voIterBindingName),
                                       new String[] { attrName },
                                       values, true);
         bind.refreshControl();
         return bind.getModelImpl(control);
      }
      else
      {
         try
         {
            StringBuffer buf = new StringBuffer(voInstanceName).append(".").append(attrName);
            Object [] args = { buf.toString(), values };

            Class clazz = Class.forName("oracle.jbo.dt.ui.jui.propertyeditors.dtmodels.DTJEnumListBinding");
            java.lang.reflect.Constructor constructor = clazz.getConstructors()[0];
            Object object = constructor.newInstance(args);
            return (ListModel)object;
         }
         catch (Exception e)
         {
            return null;
         }
      }
   }

   /**
   * @deprecated since 9.0.2 use createEnumerationBinding, createNavigationBinding or createLovBinding instead
   */
   public static ListModel getInstance(JUFormBinding    formBinding, 
                                                  JList     control,
                                                  String        voInstanceName,
                                                  String        voIterName, // temporarily taking nulls for this
                                                  String        voIterBindingName,
                                                  String        attrName,
                                                  Object        values[])
   {
      return createEnumerationBinding(formBinding, control, voInstanceName, voIterName, voIterBindingName, attrName, values);
   }


   /**
   * Use this binding when two ViewObjects are to be used in this list control: one for displaying the list
   * of values and the other ViewObject whose rows are updated.
   * Optionally, a UI can provide a cell renderer for the list and an editor which can
   * be used to implement ComboBox customization.
   * By default, if this binding method creates an instance of JUMultiAttrListCellRenderer
   * and JUMultiAttrListCellEditor to display and edit LOVs.
   */
   public static ListModel createLovBinding(  JUFormBinding    formBinding, 
                                         JList            control,
                                         String           voInstanceName,
                                         String           voIterName, // temporarily taking nulls for this
                                         String           voIterBindingName,
                                         String[]         voAttrNames, //target vo attribute names 
                                         String           lovVOInstanceName,
                                         String[]         lovVOAttrNames, //source vo attribute names
                                         String[]         lovVODisplayedAttrNames,
                                         ListCellRenderer cellRenderer
                                         )
   {
      if (!JUIUtil.inDesignTime())
      {
         JUIteratorBinding binding = (voInstanceName != null)
                                   ? formBinding.getRowIterBinding(voInstanceName, voIterName, voIterBindingName)
                                   : null;

         JUIteratorBinding listValuesBinding = (lovVOInstanceName != null) 
                                   ? formBinding.getRangeIterBinding(lovVOInstanceName, null, null, -1)
                                     : null;

         AttributeDef ad;
         ArrayList adList = null;
         int i = 0;
         
         AttributeDef ads[] = (listValuesBinding != null) 
                               ? listValuesBinding.getViewObject().getAttributeDefs() 
                               : new AttributeDef[0]; 

         int count = ads.length;
         adList = new ArrayList(count);
            
         if (lovVODisplayedAttrNames == null)
         {
            int kind;
            ArrayList al = null;
            al = new ArrayList(count); 
            for (i = 0; i < count; i++)
            {
               ad = ads[i];
               kind = ad.getAttributeKind();
               if (kind == ad.ATTR_ASSOCIATED_ROWITERATOR
                   || kind == ad.ATTR_ASSOCIATED_ROW)
               {
                  continue;
               }
               al.add(ad.getName());
               adList.add(ad);
            }

            lovVODisplayedAttrNames = (String[])al.toArray(new String[al.size()]);
         }
         else if (listValuesBinding != null)
         {
            ViewObject vo = listValuesBinding.getViewObject();
            for (i = 0; i < lovVODisplayedAttrNames.length; i++)
            {
               ad = vo.findAttributeDef(lovVODisplayedAttrNames[i]) ;
               if (ad != null)
               {
                  adList.add(ad);
               }
            }
         }



         //this executes the inner query which we shouldn't do on init. One should execute this only 
         //when getValueList() is invoked.
         JUListSingleSelBinding bind = new JUListSingleSelBinding
                                                ( control, 
                                                  binding,
                                                  voAttrNames,
                                                  listValuesBinding,
                                                  lovVOAttrNames, lovVODisplayedAttrNames,
                                                  true
                                                );
         bind.refreshControl();
         if (!bind.isSingleAttrList() && adList.size() > 0)
         {
            if (cellRenderer == null)
            {
               cellRenderer = new JUMultiAttrListCellRenderer((AttributeDef[])adList.toArray(new AttributeDef[adList.size()]));
            }
         }

         if (cellRenderer != null)
         {
            control.setCellRenderer(cellRenderer);
         }
         
         if (binding == null && listValuesBinding != null) 
         {
            //if binding is null but LOV is not, we need to register interest
            //in the LOV binding's RSI to get notified when it's data gets populated.
            listValuesBinding.getRowSetIterator().addListener(bind);
         }
         
         return control.getModel();
      }
      else
      {
         try
         {
            Class defClazz = Class.forName("oracle.jbo.dt.ui.jui.propertyeditors.dtmodels.DTJLovBindingDef"); 
            java.lang.reflect.Constructor defConstructor = defClazz.getConstructors()[0];
            Object [] defArgs = { lovVOInstanceName, lovVODisplayedAttrNames, voInstanceName, lovVOAttrNames, voAttrNames };

            Class clazz = Class.forName("oracle.jbo.dt.ui.jui.propertyeditors.dtmodels.DTJListBinding");
            java.lang.reflect.Constructor constructor = clazz.getConstructors()[0];
            Object [] args = { defConstructor.newInstance(defArgs) };
            Object object = constructor.newInstance(args);
            return (ListModel)object;
         }
         catch (Exception e)
         {
            return null;
         }
      }
   }

   /**
   * @deprecated since 9.0.2 use createEnumerationBinding, createNavigationBinding or createLovBinding instead
   */
   public static ListModel getInstance(  JUFormBinding    formBinding, 
                                         JList            control,
                                         String           voInstanceName,
                                         String           voIterName, // temporarily taking nulls for this
                                         String           voIterBindingName,
                                         String[]         voAttrNames, //target vo attribute names 
                                         String           lovVOInstanceName,
                                         String[]         lovVOAttrNames, //source vo attribute names
                                         String[]         lovVODisplayedAttrNames,
                                         ListCellRenderer cellRenderer )
   {
       return createLovBinding( formBinding, control, voInstanceName, voIterName, voIterBindingName, voAttrNames, 
                      lovVOInstanceName, lovVOAttrNames, lovVODisplayedAttrNames, cellRenderer ); 
   }

   /**
   * Use this binding when the given list control is used as a navigation control to 
   * iterate through a range of rows in a RowSet.
   * Optionally, a UI can provide a cell renderer for the list and an editor which can
   * be used to implement ComboBox customization.
   * By default, this binding method creates an instance of JUMultiAttrListCellRenderer
   * and JUMultiAttrListCellEditor to display and edit LOVs.
   */
   public static ListModel createNavigationBinding(  JUFormBinding    formBinding, 
                                         JList            control,
                                         String           voInstanceName,
                                         String           voIterName, // temporarily taking nulls for this
                                         String           voIterBindingName,
                                         String[]         voAttrNames, //target vo attribute names 
                                         ListCellRenderer cellRenderer
                                         )
   {
      if (!JUIUtil.inDesignTime())
      {
         JUIteratorBinding binding = formBinding.getRowIterBinding(voInstanceName, voIterName, voIterBindingName);
         
         //this executes the inner query which we shouldn't do on init. One should execute this only 
         //when getValueList() is invoked.
         JUListSingleSelBinding bind = new JUListSingleSelBinding
                                                ( control, 
                                                  binding,
                                                  voAttrNames,
                                                  LIST_OPER_NAVIGATE,
                                                  true
                                                );
         bind.refreshControl();
         if (!bind.isSingleAttrList())
         {
            if (cellRenderer == null)
            {
               cellRenderer = new JUMultiAttrListCellRenderer(bind.getAttributeDefs());
            }
         }

         if (cellRenderer != null)
         {
            control.setCellRenderer(cellRenderer);
         }
         
         return control.getModel();
      }
      else
      {
         try
         {
            Class clazz = Class.forName("oracle.jbo.dt.ui.jui.propertyeditors.dtmodels.DTJListNavigationBinding");
            java.lang.reflect.Constructor constructor = clazz.getConstructors()[0];

            String firstAttribute = "";
            if (voAttrNames != null && voAttrNames.length != 0)
               firstAttribute = voAttrNames[0];
            int size = voAttrNames == null ? 0 : voAttrNames.length;
            StringBuffer stbuf = new StringBuffer(firstAttribute);
            for (int i=1; i<size; i++)
            {
               stbuf.append(",");
               stbuf.append(voAttrNames[i]);
            }

            Object [] args = { voInstanceName + "." + stbuf.toString() };
            Object object = constructor.newInstance(args);
            return (ListModel)object; 
         }
         catch (Exception e)
         {
            return null;
         }
      }
   }

}
