/*
 * @(#)JUCtrlHierTypeBinding.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.uicli.binding;

import java.util.HashMap;
import javax.swing.Icon;
import oracle.jbo.mom.xml.DefElementImpl;
import oracle.jbo.mom.xml.DefPersistenceException;
import oracle.jbo.mom.xml.DefWriter;

abstract public class JUCtrlHierTypeBinding extends JUDefBase
{
   protected String mVODefName;
   protected String mDiscrColumnName;
   protected Object mDiscrColumnValue;
   protected String mChildAccessorName;
   protected String mChildAttrName;
   protected Icon mLeafIcon;
   protected Icon mOpenIcon;
   protected Icon mClosedIcon;

   
   static final String PNAME_TYPE = "JUCtrlHierTypeBinding";

   static final String PNAME_ViewDefName = "ViewDefName";
   static final String PNAME_DiscrColumnName = "DiscrColumnName";
   static final String PNAME_DiscrColumnValue = "DiscrColumnValue";
   static final String PNAME_AccessorName = "AccessorName";
   static final String PNAME_AttributeName = "AttributeName";
//   static final String PNAME_LeafIconName = "LeafIcon";
//   static final String PNAME_OpenIconName = "OpenIcon";
//   static final String PNAME_ClosedIconName = "ClosedIcon";


   public JUCtrlHierTypeBinding()
   {
   }

   
   public JUCtrlHierTypeBinding(String voTypeName, 
                                String discrColumnName, 
                                String discrColumnValue,
                                String accessorName, 
                                String attrName,
                                Icon leafIcon,
                                Icon openIcon,
                                Icon closedIcon
                                )
   {
      mVODefName = voTypeName;
      mDiscrColumnName = discrColumnName;
      mDiscrColumnValue = discrColumnValue;
      mChildAccessorName = accessorName;
      mChildAttrName = attrName;
      mLeafIcon   = leafIcon;   
      mOpenIcon   = openIcon;   
      mClosedIcon = closedIcon; 
   }

   
   public void init(HashMap initValues)
   {
      Object val;

      if ((val = initValues.get(PNAME_ViewDefName)) != null)
      {
         mVODefName = val.toString();
      }

      if ((val = initValues.get(PNAME_DiscrColumnName)) != null)
      {
         mDiscrColumnName = val.toString();
      }
      
      if ((val = initValues.get(PNAME_DiscrColumnValue)) != null)
      {
         mDiscrColumnValue = val.toString();
      }
      
      if ((val = initValues.get(PNAME_AccessorName)) != null)
      {
         mChildAccessorName = val.toString();
      }
      
      if ((val = initValues.get(PNAME_AttributeName)) != null)
      {
         mChildAttrName = val.toString();
      }
     /* 
      if ((val = initValues.get(PNAME_LeafIconName)) != null)
      {
         mLeafIconName = val.toString();
      }
      if ((val = initValues.get(PNAME_OpenIconName)) != null)
      {
         mOpenIconName = val.toString();
      }
      if ((val = initValues.get(PNAME_ClosedIconName)) != null)
      {
         mClosedIconName = val.toString();
      }
      */
   }

   
   public String getXMLElementTag()
   {
      return PNAME_TYPE;
   }

   
   public String getViewDefName()
   {
      return mVODefName;
   }


   public String getDiscrColumnName()
   {
      return mDiscrColumnName;
   }

   
   public Object getDiscrColumnValue()
   {
      return mDiscrColumnValue;
   }


   public String getAccessorName()
   {
      return mChildAccessorName;
   }


   public String getAttributeName()
   {
      return mChildAttrName;
   }

   public boolean hasIcon()
   {
      return (mLeafIcon != null
               || mClosedIcon != null
               || mOpenIcon != null) ;
   }

   public Icon getLeafIcon()
   {
      return mLeafIcon;
   }
   
   public Icon getOpenIcon()
   {
      return mOpenIcon;
   }

   public Icon getClosedIcon()
   {
      return mClosedIcon;
   }

   public abstract boolean matchViewObjectType(String str);

   public abstract boolean isDiscrColumnType();

   
   protected void retrieveFromXML(DefElementImpl xmlElement, HashMap valueTab)
   {
      super.retrieveFromXML(xmlElement, valueTab);
      
      readXMLString(xmlElement, PNAME_ViewDefName, valueTab);
      readXMLString(xmlElement, PNAME_DiscrColumnName, valueTab);
      readXMLString(xmlElement, PNAME_DiscrColumnValue, valueTab);
      readXMLString(xmlElement, PNAME_AccessorName, valueTab);
      readXMLString(xmlElement, PNAME_AttributeName, valueTab);
//      readXMLString(xmlElement, PNAME_LeafIconName, valueTab);
//      readXMLString(xmlElement, PNAME_OpenIconName, valueTab);
//      readXMLString(xmlElement, PNAME_ClosedIconName, valueTab);
   }
   
      
   public void writeContents(DefWriter jos)
      throws DefPersistenceException
   {
      super.writeContents(jos);

      jos.writeString(PNAME_ViewDefName, getViewDefName());
      jos.writeString(PNAME_DiscrColumnName, getDiscrColumnName());

      Object discrColumnValue = getDiscrColumnValue();

      jos.writeString(PNAME_DiscrColumnValue, (discrColumnValue == null) ? null : discrColumnValue.toString());
      jos.writeString(PNAME_AccessorName, getAccessorName());
      jos.writeString(PNAME_AttributeName, getAttributeName());
//      jos.writeString(PNAME_LeafIconName, mLeafIconName);
//      jos.writeString(PNAME_OpenIconName, mOpenIconName);
//      jos.writeString(PNAME_ClosedIconName, mClosedIconName);
   }
}
