/*
 * @(#)JUSessionDefImpl.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.uicli.mom;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import oracle.jbo.CSMessageBundle;
import oracle.jbo.JboException;
import oracle.jbo.PersistenceException;
import oracle.jbo.common.JBOClass;
import oracle.jbo.mom.DefinitionObject;
import oracle.jbo.mom.xml.DefElementImpl;
import oracle.jbo.mom.xml.DefPersistable;
import oracle.jbo.mom.xml.DefPersistenceException;
import oracle.jbo.mom.xml.DefWriter;

// import oracle.dacf.dataset.SessionInfo;
public class JUSessionDefImpl extends DefinitionObject implements DefPersistable  
{

   String packageName;
   String configuration;
   
   Object dacObj;
   /**
    * Creates the EntityDefImpl from the XML metadata stream.
    * @param xmlElement  the name of the XML node from which to load.
    * @exception oracle.jbo.PersistenceException is thrown if an error occurs
    * while loading the XML node.
   */

   JUSessionDefImpl() {}

   JUSessionDefImpl (String name)
   {
      setName(name);
   }

   public void setDacObj(Object obj)
   {
      dacObj = obj;
   }

   public Object getDacObj()
   {
      return dacObj;
   }

   public void setPackageName(String name)
   {
      packageName = name;
   }

   public void setConfiguration(String name)
   {
      configuration = name;
   }

   public String getPackageName()
   {
      return packageName;
   }

   public String getConfiguration()
   {
      return configuration;
   }

   static JUSessionDefImpl loadFromXML(DefElementImpl xmlElement, String appName)
   {
      JUSessionDefImpl eInfo;
      try
      {
         //if (eInfo == null)
         {
            // If there's a java def class, then use that class. If not, create a generic SessionDef
            String defClassName = xmlElement.readString(JUTags.DefClass);

            if (defClassName != null)
            {
               eInfo = (JUSessionDefImpl) JBOClass.forName(defClassName).newInstance();
            }
            else
            {
              // TODO: inherit defclass?
               eInfo = new JUSessionDefImpl();
            }
         }

         String name = xmlElement.readString(JUTags.Name);
         eInfo.setName(name);
         eInfo.packageName = xmlElement.readString(JUTags.Package);
         eInfo.configuration = xmlElement.readString(JUTags.Configuration);
         name = (new StringBuffer(appName).append(".").append(name)).toString();
         eInfo.setFullName(name);

         com.sun.java.util.collections.ArrayList children = xmlElement.getSimilarChildrenList(JUTags.RowSet);
         JURowSetDefImpl child;
         for ( int i = 0; i < children.size(); i++ )
         {
            child = JURowSetDefImpl.loadFromXML((DefElementImpl)children.get(i), name);
            eInfo.addRowSetDef(child);
         }

         return eInfo;
      }
      catch ( JboException je )
      {
         throw je;
      }
      catch ( Exception jbe )
      {
         PersistenceException pe = new PersistenceException(
                                       CSMessageBundle.EXC_GENERIC_PERSISTENCE,
                                       null);
         pe.addToDetails(jbe);
         throw pe;
      } 
   }


   public HashMap getRowSetEventsMap()
   {
      HashMap map = null;
      if (rowSetDefs != null)
      {
         int size = rowSetDefs.size();
         map = new HashMap(size);
         JURowSetDefImpl def;
         for (int i = 0; i < size; i++)
         {
            def = (JURowSetDefImpl)rowSetDefs.get(i);
            map.put(def.getName(), def.getEventArrayList());
         }
      }
      return map;
   }

   ArrayList rowSetDefs = null;
   public void addRowSetDef(JURowSetDefImpl def)
   {
      if (rowSetDefs == null) 
      {
         rowSetDefs = new ArrayList(10);
      }
      rowSetDefs.add(def);
   }

   public JURowSetDefImpl findRowSetDef(String name)
   {
      JURowSetDefImpl def = null;
      if (rowSetDefs != null) 
      {
         Iterator iter = rowSetDefs.iterator();
         while (iter.hasNext())
         {
            def = ((JURowSetDefImpl)iter.next());
            if (def.getName().equals(name))
            {
               return def;
            }
         }
         def = null;
      }
      return def;
   }

   public void removeRowSetDef(String name)
   {
      JURowSetDefImpl def = findRowSetDef(name);
      if (def != null)
      {
         rowSetDefs.remove(def);
      }
   }

   public void addRowSetDef(String name, String className)
   {
      if (findRowSetDef(name) == null)
      {
         addRowSetDef(new JURowSetDefImpl(name, className));
      }
   }

   public ArrayList getRowSetDefs()
   {
      return rowSetDefs;
   }

   boolean mDirty = false;
   boolean mIsNew = false;
   /**
    * This method returns if an Object is modified from last save/load
    * @return Returns true if the Object is dirty. Returns false otherwise.
    **/
   public boolean isDirty()
   {
      return mDirty;
   }

   /**
    * This method marks the Object dirty
    * @param isDirty If true the Object is marked Dirty.
    **/
   public void    setDirty(boolean isDirty)
   {
      mDirty = true;
   }

   /**
    * This method returns if this object is previously persisted.
    * @return true if the Object is previously persisted. Returns false otherwise.
    **/
   public boolean isNew()
   {
      return mIsNew;
   }

   /**
    * This method marks the as previously persisted. By default all objects
    * are new objects. When the object is persisted first time, that object is
    * marked as 'not new' object
    * @param isNew If true the Object is marked as new object.
    **/
   public void    setNew(boolean isNew)
   {
      mIsNew = isNew;
   }


   /**
    * Objects should write their persistence output in this method
    * @param jos the Output storage for persistence
    **/
   public void writeObject(DefWriter jos) throws DefPersistenceException
   {
      jos.writeObject(this);
   }

   /**
    * Objects should write their persistence output in this method
    * @param jos the Output storage for persistence
    * @DefPersistable parent Parent Object that's calling the writeChildren
    * @return Number of Contents returned
    * @Exception Error in writing the Object's contents to Persistent Storage
    **/
   public void writeContents(DefWriter jos) throws DefPersistenceException
   {
      jos.writeString(JUTags.Package, packageName);
      jos.writeString(JUTags.Configuration, configuration);
   }

   /**
    * Writes the Object's children to the Persistent storage
    * @param jos the Output storage for persistence
    * @Exception Error in writing the Object's Children to the storage
    **/
   public void writeChildren(DefWriter jos) throws DefPersistenceException
   {
      if (rowSetDefs != null)
      {
         Iterator e= rowSetDefs.iterator();
         while ( e.hasNext() )
         {
            ((JURowSetDefImpl)e.next()).writeObject(jos);
         }
      }
   }


   /**
    * Returns a piece of static info for the type of object this is invoked
    * upon.  Examples are PreparedStatements for insert, update, delete,
    * and String containing a base the select statement for retrieving
    * instances of this type through the SQLInputStream
    * @param type Type of the Persistence Statement requested. The type
    *             can be any of the Statement types defined in this interface.
    * @return returns the Statement required to store in Persitent Storage.
    *         Incase of XML, it just returns the String. In the case of SQL
    *         a JDBC PreparedStatement is returned.
    **/
   public String getXMLElementTag()
   {
      return JUTags.Session;
   }
}

