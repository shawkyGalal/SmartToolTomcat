/*
 * @(#)JUTreeBinding.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.uicli.jui;

import java.awt.Component;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTree;
import javax.swing.event.TreeExpansionEvent;
import javax.swing.event.TreeExpansionListener;
import javax.swing.event.TreeModelListener;
import javax.swing.event.TreeSelectionEvent;
import javax.swing.event.TreeSelectionListener;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeModel;
import javax.swing.tree.TreeModel;
import javax.swing.tree.TreeNode;
import javax.swing.tree.TreePath;
import oracle.jbo.Row;
import oracle.jbo.uicli.binding.JUCtrlHierBinding;
import oracle.jbo.uicli.binding.JUCtrlHierTypeBinding;
import oracle.jbo.uicli.binding.JUFormBinding;
import oracle.jbo.uicli.binding.JUIteratorBinding;
import oracle.jbo.uicli.controls.JUTreeCellRenderer;

/**
 * A lightweight Document model that implements
 * binding a <code>javax.swing.JTree</code> to a BC4J RowIterator 
 * and display a selected attribute. Each tree node may
 * display a set of child nodes bound to another Iterator that is
 * retrieved via an accessor on the rows of the first iterator.
 * <p>
 * This binding allows Trees that can have two types of nodes:
 * <ul>
 * <li>JUTreeAccessorTypeBinding - that display a selected attribute for all rows of a 
 * ViewObject/Iterator and upon expansion, expand the same accessor for all rows.</li>
 * <li>JUTreeDiscrAttrTypeBinding - that allow displaying different attributes for each
 * row of a ViewObject/Iterator determined by a unique value of the same or different
 * attribute in the same row, and upon expansion, potentially expands to display rows from 
 * a different accessor for each row based on the discriminator attribute value. This
 * type of node binding can be used to display polymorphic Rows in a ViewObject or display
 * different attributes/accessors for each row based on the discriminator attribute value 
 * on that row: For example, assuming an EmpView, display EmployeeSal for all Employees of deptid=10
 * while displaying EmployeeRate for all Employees of deptid=20 and so on.</li>
 * </ul>
 *
 * @see oracle.jbo.RowIterator
 * @see javax.swing.JTree
 * @see javax.swing.tree.TreeModel
 * @see javax.swing.tree.TreeNode
 */
public class JUTreeBinding extends JUCtrlHierBinding
   implements TreeExpansionListener, TreeSelectionListener, TreeModel
{
   DefaultTreeModel mTreeModel = null;
   private JScrollPane mScrollPane;
   private JUTreeNodeBinding mRootBinding = null;

   
   /**
   * This method is used by the JClient model-binding editors to bind a JTree to this binding.
   * The rules for ViewObjects that will be displayed in this binding are passed in the nodeBindings
   * array. 
   * <p>
   * The rules the govern the node bindings are:
   * <ul>
   * <li>Each ViewObject in the tree can either be displayed using a JUTreeAccessorTypeBinding 
   * or a JUTreeDiscrAttrTypeBinding.</li>
   * <li>JUTreeAccessorTypeBinding takes precedence</li>
   * <li>Only one attribute is displayed for each node based on the attribute setting in
   * the corresponding JUCtrlHierTypeBinding object.</li>
   * <li>Only one accessor is expanded for each node based on the accessor setting in 
   * the corresponding JUCtrlHierTypeBinding object.</li>
   * <li>The order of nodes determine the search order for discriminator values in case
   * of JUTreeDiscrAttrTypeBinding bindings and the first matching value determines
   * the attribute and accessor for that node.</li>
   * </ul>
   */
   public static DefaultTreeModel createTreeNodeTypeBinding(JUFormBinding formBinding, 
                                                  JTree         control,
                                                  String        voInstanceName,
                                                  String        voIterName, /*temporarily taking nulls for this*/
                                                  String        voIterBindingName,
                                                  JUCtrlHierTypeBinding nodeBindings[])
   // currently only displaying one attribute per child vo on a given accessor.
   // that should be modifiable to display all/some attrs.
   {
      if (!JUIUtil.inDesignTime())
      {
         JUTreeBinding bind = new JUTreeBinding( control, 
                                   formBinding.getRangeIterBinding(voInstanceName, voIterName, voIterBindingName, -1),
                                   nodeBindings);
         bind.refreshControl();
         return bind.getModelImpl(null);
      }
      else
      {
         try
         {
            // this class has more then one constructor, so I have to verify some paramater matching.
            Class defClazz = Class.forName("oracle.jbo.dt.ui.jui.propertyeditors.dtmodels.DTJTreeBindingDef");
            java.lang.reflect.Constructor [] defConstructors = defClazz.getConstructors();
            java.lang.reflect.Constructor defConstructor = null;
            for (int i = 0; i < defConstructors.length; i++)
            {
               Class [] params = defConstructors[i].getParameterTypes();
               if (params.length == 2 && params[0].isInstance(voInstanceName) && params[1].isInstance(nodeBindings))
               {
                  defConstructor = defConstructors[i];
                  break;
               }
            }
            Object [] defArgs = { voInstanceName, nodeBindings };


            Class clazz = Class.forName("oracle.jbo.dt.ui.jui.propertyeditors.dtmodels.DTJTreeBinding");
            java.lang.reflect.Constructor constructor = clazz.getConstructors()[0];
            Object [] args = { defConstructor.newInstance(defArgs) };
            Object object = constructor.newInstance(args);
            return (DefaultTreeModel)object;
         }
         catch (Exception e)
         {
            return null;
         }
      }
   }

   /**
   * @deprecated since 9.0.2
   */
   public static DefaultTreeModel getInstance(JUFormBinding formBinding, 
                                                  JTree         control,
                                                  String        voInstanceName,
                                                  String        voIterName, /*temporarily taking nulls for this*/
                                                  String        voIterBindingName,
                                                  JUCtrlHierTypeBinding nodeBindings[])
   {
      return createTreeNodeTypeBinding(formBinding, control, voInstanceName, voIterName, voIterBindingName, nodeBindings);
   }

   /**
   * This constructor binds a JTree with Rows from a given JUIteratorBinding and
   * displays data as per the node-types passed in typeBindings.
   */
   public JUTreeBinding(JTree tr, JUIteratorBinding iterBinding, 
                        JUCtrlHierTypeBinding[] typeBindings)
   {
      super(tr, iterBinding, new String[] {}, typeBindings);

      init(tr);
   }

   /**
   * *** For internal framework use only ***
   */
   public JUTreeBinding(JTree tr, JUIteratorBinding iterBinding, String attrName,
                        JUCtrlHierTypeBinding[] typeBindings)
   {
      super(tr, iterBinding, new String[] { attrName }, typeBindings);

      init(tr);
   }


   private void init(JTree tr)
   {
      if (tr != null)
      {
         if (mTypeBindings.length > 0)
         {
            if (mTypeBindings[0].hasIcon()) 
            {
               tr.setCellRenderer(new JUTreeCellRenderer());
            }
         }

         tr.addTreeExpansionListener(this);
         tr.addTreeSelectionListener(this);
         tr.addFocusListener(new JUSVFocusAdapter(this)
            {
               public void focusGained(java.awt.event.FocusEvent e)
               {
                  if (!e.isTemporary())
                  {
                     if (panelBinding == null) 
                     {
                        panelBinding = (JUPanelBinding)mControlBinding.getIteratorBinding().getFormBinding();
                     }

                     JTree tree = (JTree)((JUTreeBinding)mControlBinding).getControl();
                     
                     int sel = tree.getSelectionCount();
                     if (sel == 1)
                     {
                        DefaultMutableTreeNode treeNode = (DefaultMutableTreeNode) tree.getSelectionPath().getLastPathComponent();
                        JUTreeNodeBinding treeNodeBinding = (JUTreeNodeBinding) treeNode.getUserObject();
                        panelBinding.focusGained(treeNodeBinding.getIteratorBinding(), treeNodeBinding, mAttrIndex);
                     }
                     else
                     {
                        panelBinding.focusGained(getIteratorBinding(), mControlBinding, mAttrIndex);
                     }
                  }
               }
            });
      }
   }
   
   /**
   * Returns the TreeModel to which the associated JTree is bound. 
   * Unlike JUTableBinding, tree binding does not implement a custom TreeModel, but
   * rather reuses the existing TreeModel in JTree and simply attaches itself as
   * an associate to the TreeModel and passes BC4J data to it.
   */
   protected DefaultTreeModel getModelImpl(JTree control)
   {
      return mTreeModel;
   }
   
   /**
   * *** For internal framework use only ***
   */
   public void addControlToPanel(Object panel, Object layoutObject, Object layoutCons)
   {
      ((JPanel) panel).add((Component) layoutObject, layoutCons);
   }

   
   /**
   * *** For internal framework use only ***
   */
   public Object getLayoutObject()
   {
      if (mScrollPane == null)
      {
         return getControl();
      }
      else
      {
         return mScrollPane;
      }
   }

   
   /**
   * *** For internal framework use only ***
   */
   public void setLayoutObject(JScrollPane scrollPane)
   {
      mScrollPane = scrollPane;
   }

   
   /**
   * Returns null, as tree is not implemented to return attribute values
   * for a given Row. The displayed value is accessible via the TreeModel.
   */
   public Object getValueAt(int rowIndex, int attrIndex)
   {
      return null;
   }

   
   /**
   * This method is a noop. JUTreeBinding is currently only a readonly binding
   */
   public void setValueAt(Object value, int rowIndex, int attrIndex)
   {
   }
   
   /**
   * Returns the attribute that is displayed in the first-level nodes of this tree.
   */
   public String[] getAttributeNames()
   {
      JUCtrlHierTypeBinding[] types = getTypeBindings();
      if (types != null && types.length > 0)
      {
         return new String []{types[0].getAttributeName()};
      }
      return super.getAttributeNames();
   }
   
   /**
   * Updates the nodes in the tree based on the given set of rows. Clears the existing
   * display if clear flag is true.
   */
   public void updateValuesFromRows(Row[] rows, boolean clear)
   {
      if (mRootBinding == null)
      {
         JTree tr = (JTree) getControl();
         JUIteratorBinding iterBinding = getIteratorBinding();
         String[] attrNames = getAttributeNames();
         
         mRootBinding = new JUTreeNodeBinding(tr, this, null /*parent*/,
                                              (JUIteratorBinding) iterBinding,
                                              (attrNames != null && attrNames.length > 0) ? attrNames[0] : null,
                                              iterBinding.getViewObject().getName(), true);
         mRootBinding.mTypeBinding = mTypeBindings[0];

         mTreeModel = new DefaultTreeModel(mRootBinding.getTreeNode());
         tr.setModel(mTreeModel);
      }
      mRootBinding.updateValuesFromRows(rows, clear);
   }

   /**
   * This method is called in the framework when values of a single row need to be 
   * updated in a control (typically on a navigation event). 
   */
   public void updateValuesFromRow(Row row)
   {
      //updateValuesFromRows(new Row[] { row }, false /*clear*/);
   }


   /**
   * Returns the root node binding that contains the iterator that the root node is displaying.
   */
   public JUTreeNodeBinding getRootBinding()
   {
      return mRootBinding;
   }

   
   //
   // TreeExpansionListener implementation
   //
   
   public void treeCollapsed(TreeExpansionEvent e)
   {
   }


   public void treeExpanded(TreeExpansionEvent e)
   {
      JTree tr = (JTree) getControl();
      if (tr.getModel() !=  mTreeModel)
      {
         tr.setModel(mTreeModel);
      }
      DefaultMutableTreeNode treeNode = (DefaultMutableTreeNode) e.getPath().getLastPathComponent();
      JUTreeNodeBinding treeNodeBnd = (JUTreeNodeBinding) treeNode.getUserObject();

      treeNodeBnd.executeQueryIfNeeded();
   }


   //
   // TreeSelectionListener implementation
   //
   
   public void valueChanged(TreeSelectionEvent e)
   {
      DefaultMutableTreeNode treeNode = (DefaultMutableTreeNode) e.getPath().getLastPathComponent();
      JUTreeNodeBinding treeNodeBnd = (JUTreeNodeBinding) treeNode.getUserObject();

      treeNodeBnd.nodeSelected();
   }
   
   
   //
   // TreeModel implementation
   //

   public Object getRoot()
   {
      if (mTreeModel != null)
      {
         return mTreeModel.getRoot();
      }
      else
      {
         return null;
      }
   }


   public Object getChild(Object parent, int index)
   {
      if (mTreeModel != null)
      {
         return mTreeModel.getChild(parent, index);
      }
      else
      {
         return null;
      }
   }


   public int getChildCount(Object parent)
   {
      if (mTreeModel != null)
      {
         return mTreeModel.getChildCount(parent);
      }
      else
      {
         return 0;
      }
   }


   public boolean isLeaf(Object node)
   {
      if (mTreeModel != null)
      {
         return mTreeModel.isLeaf(node);
      }
      else
      {
         return false;
      }
   }


   public void valueForPathChanged(TreePath path, Object newValue)
   {
      if (mTreeModel != null)
      {
         mTreeModel.valueForPathChanged(path, newValue);
      }
   }


   public int getIndexOfChild(Object parent, Object child)
   {
      if (mTreeModel != null)
      {
         return mTreeModel.getIndexOfChild(parent, child);
      }
      else
      {
         return -1;
      }
   }


   public void addTreeModelListener(TreeModelListener l)
   {
      if (mTreeModel != null)
      {
         mTreeModel.addTreeModelListener(l);
      }
   }


   public void removeTreeModelListener(TreeModelListener l)
   {
      if (mTreeModel != null)
      {
         mTreeModel.removeTreeModelListener(l);
      }
   }
}
