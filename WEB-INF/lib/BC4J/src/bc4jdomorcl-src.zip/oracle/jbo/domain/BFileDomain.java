package oracle.jbo.domain;

import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.OutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.ByteArrayOutputStream;
import oracle.jbo.Transaction;
//import oracle.jbo.server.DBTransactionImpl;
import oracle.jbo.JboException;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Constructor;
import java.lang.reflect.Method;

// Oracle Specific JDBC classes: 
import oracle.sql.BFILE;

// Core JDBC classes: 
import java.sql.Types;
import java.sql.SQLException;

import com.sun.java.util.collections.HashMap; 


// ---------------------------------------------------
// ---    jbo generated file.
// ---    Business object: BFileDomain
// ---------------------------------------------------


/**
* This class provides a lightweight wrapper for <tt>oracle.sql.BFILE</tt>,
* the Java representation of the
* BFILE database type. This wrapper allows an instance of the
* <tt>oracle.sql.BFILE</tt> to be used as a domain object.
* <p>
*
* @since JDeveloper 3.0
*/
public class BFileDomain implements 
  LobStreamInterface, java.io.Serializable {

   private static final long serialVersionUID = -4600794293346504285L;

   transient ByteArrayOutputStream mData = null;
   transient private BFILE bFile = null;
   transient private Transaction xAct = null;
   static final String CLIENT_LOB_DOMAIN_INPUT  = "oracle.jbo.client.remote.LobDomainInputStream";
   static final String CLIENT_APPMODULE_CLASS = "oracle.jbo.client.remote.ApplicationModuleImpl";

   private static final int MAX_CHUNK_SIZE = 32767;
   transient InputStream inStream;
   transient DomainOwnerInterface mOwner = null;
   transient boolean mDataModified = false;
   transient boolean mClient = false;
   transient Integer relIdx = new Integer(-1);
   transient String mIndexString = null;

   /**
   * Constructor for this class.
   **/
   public BFileDomain()
   {
   }

   /**
   * Constructor for this class, given a BFILE object.
   * This is for use by JDBC.
   * @param bFile name of a BFILE object.
   **/
   public BFileDomain(BFILE bFile)
   {
      this.bFile = bFile;
   }

   /**
   * <b>Internal:</b>  <em>Applications should not use this constructor.</em>
   * <p>
   * Creates an instance of this class with data as described in
   * <code>bFileData</code>
   * and using the transaction context from <code>bFile</code> to use the
   * file-locator
   * in the database.
   * <p>
   * @param bfile the name of the BFILE.
   * @param bFileData the data for the BFILE.
    * @deprecated since 9.0.4 BFile domains cannot be updated.
   **/
   public BFileDomain(BFILE bFile, byte[] bFileData)
   {
      this.bFile = bFile;
      setBytes(bFileData);
   }

   /**
   * <b>Internal:</b>  <em>Applications should not use this constructor.</em>
   * Creates an instance of this class with data as described in
   * <code>bFileData</code>
   * and using the transaction context from <code>bFile</code> to use the
   * file-locator
   * in the database.
   * <p>This constructor should be used by applications using the framework
   * to create
   * BFileDomain objects.
   * <p>
   * @param bfile the name of the BFILE.
   * @param bFileData the data forthe BFILE.
   * @deprecated since 9.0.4 BFile domains cannot be updated.
   **/
   public BFileDomain(BFileDomain bFile, byte[] bFileData)
   {
      shareBFILE(bFile);
      setBytes(bFileData);
   }

   /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   * <p>
   * If this object does not have a transaction context, shares the transaction
   * and BFILE locator from <code>newBfile</code>.
   * <p>
   * @param  newBfile name of the BFILE with which this BFILE will share its transaction and file locator information.
   **/
   public void shareBFILE(BFileDomain newBFile)
   {
      if (bFile == null)
      {
         bFile = (BFILE)newBFile.bFile;

         try
         {
            bFile = new BFILE((oracle.jdbc.OracleConnection)bFile.getJavaSqlConnection());
         }
         catch (SQLException sqle)
         {
            throw new JboException(sqle);
         }
      }
   }


   /**
   * <b>Internal:</b>  <em>Applications should not use this method.</em>
   * <p>
   * If this object does not have a transaction context, shares the transaction
   * and BFILE locator from <code>newBfile</code>.
   * <p>
   * @param newBfile name of the BFILE with which this BFILE will share its
   * transaction and BFILE locator information.
   **/
   public void useBFILE(BFILE newBlob)
   {
      if (bFile == null)
      {
         bFile = newBlob;
      }
   }

   /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
    * 
    * Sets the file data for this object.
    * <p>
    * @param bFileData the data used to fill the BFILE.
    * @throws oracle.jbo.domain.DomainValidationException if domain creation fails.
    * @deprecated since 9.0.4 BFile domains cannot be updated.
    */
   public void setBytes(byte[] bFileData) throws DomainValidationException
   {
   }


   /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   * <p>
   * Uses the given transaction context to load data from the database.
   * <p>
   * @param xAct the name of the transaction to use.
   **/
   public void loadFromDatabase(Transaction xAct)
      throws Exception
   {
      this.xAct = xAct;
   }


   /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   * <p>
   * Sets the transaction context for this BFILE.
   *
   *
   **/
   public void setContext(DomainOwnerInterface owner, Transaction trans, Object ctx)
   {
      this.xAct = trans;
      this.mOwner = owner;
      HashMap ctxMap = (HashMap)ctx;
      Integer idx = (Integer)(ctxMap.get(DomainContext.RELATIVE_INDEX));
      this.relIdx = (idx != null) ? idx : relIdx;
      if (ctxMap.get(DomainContext.CLIENT_DOMAIN) != null)
      {
         this.mClient = true;
      }
      if (xAct instanceof oracle.jbo.ApplicationModule)
      {
         this.mClient = true;
      }
      mIndexString = null; //recalc.
   }

   static Object invokeCreateCallableStatement(Transaction xtn, String str, int n)
   {
      try
      {
         Class implCls = Class.forName("oracle.jbo.server.DBTransactionImpl");
         Method mth = implCls.getMethod("createCallableStatement", new Class[] {java.lang.String.class, java.lang.Integer.TYPE});
         return mth.invoke(xtn, new Object[]{str, new Integer(n)});
      }
      catch (JboException jboe)
      {
         throw jboe;
      }
      catch (Exception e)
      {
         throw new JboException(e);
      }
   }

   // Utility function to dump the contents of a Bfile
   private ByteArrayOutputStream dumpBFile (Transaction xact, BFILE bfile)
   {
      byte[] buf = null;
      mData = new ByteArrayOutputStream();

      oracle.jdbc.driver.OracleCallableStatement read 
          = (oracle.jdbc.driver.OracleCallableStatement)invokeCreateCallableStatement
                                       (xact, "begin dbms_lob.read (?, ?, ?, ?); end;", 1);
      /*
      oracle.jdbc.driver.OracleCallableStatement read =
         (oracle.jdbc.driver.OracleCallableStatement)((oracle.jbo.server.DBTransactionImpl)xact).createCallableStatement ("begin dbms_lob.read (?, ?, ?, ?); end;", 1);
      */

      try
      {
//         String filename = filegetname (xact, bfile);
//         System.out.println ("Dumping file " + filename);
//         System.out.println ("File exists: " + fileexists (xact, bfile));
//         System.out.println ("File open: " + fileisopen (xact, bfile));
//         System.out.println ("Opening File: ");

         bfile = fileopen (xact, bfile);

//         System.out.println ("File open: " + fileisopen (xact, bfile));

         long length = getLength (xact, bfile);

//         System.out.println ("File length: " + length);

         long i = 0;
         int chunk = 31 * 1024;
         buf = new byte[(int)chunk];

         while (i < length)
         {
            read.setBfile (1, bfile);
            read.setLong (2, chunk);
            read.registerOutParameter (2, Types.NUMERIC);
            read.setLong (3, i + 1);
            read.registerOutParameter (4, Types.VARBINARY);
            read.execute ();

            long read_this_time = read.getLong (2);
            byte[] bytes_this_time = read.getBytes(4);
            mData.write(bytes_this_time, 0, (int) read_this_time);

//            System.out.print ("Read " + read_this_time + " bytes: ");

            i += read_this_time;
         }

         fileclose (xact, bfile);
         fileisopen (xact, bfile);
         read.close ();
     }
      catch (Exception ex)
      {
         throw new JboException(ex);
      }

      return mData;
   }

 
   // Utility function to get the length of a Bfile
   static private long getLength (Transaction xact, BFILE bfile)
     throws SQLException
   {
      oracle.jdbc.driver.OracleCallableStatement cstmt 
         = (oracle.jdbc.driver.OracleCallableStatement)invokeCreateCallableStatement
                                       (xact, "begin ? := dbms_lob.getLength (?); end;", 1);
     try
     {
       cstmt.registerOutParameter (1, Types.NUMERIC);
       cstmt.setBfile (2, bfile);
       cstmt.execute ();
       return cstmt.getLong (1);
     }
     finally
     {
       cstmt.close ();
     }
   }

 
   // Utility function to test if a Bfile exists
   static private boolean fileexists (Transaction xact, BFILE bfile)
     throws SQLException
   {
     oracle.jdbc.driver.OracleCallableStatement cstmt 
        = (oracle.jdbc.driver.OracleCallableStatement)invokeCreateCallableStatement
                                    (xact, "begin ? := dbms_lob.fileexists (?); end;", 1);
 
     try
     {
       cstmt.registerOutParameter (1, Types.NUMERIC);
       cstmt.setBfile (2, bfile);
       cstmt.execute ();
       return cstmt.getBoolean (1);
     }
     finally
     {
       cstmt.close ();
     }
   }

 
   // Utility function to return the filename of a Bfile
   static private String filegetname (Transaction xact, BFILE bfile)
     throws SQLException
   {
     oracle.jdbc.driver.OracleCallableStatement cstmt 
        = (oracle.jdbc.driver.OracleCallableStatement)invokeCreateCallableStatement
                                 (xact, "begin dbms_lob.filegetname (?, ?, ?); end;", 1);
 
     try
     {
       cstmt.setBfile (1, bfile);
       cstmt.registerOutParameter (2, Types.VARCHAR);
       cstmt.registerOutParameter (3, Types.VARCHAR);
       cstmt.execute ();
       
       return cstmt.getString (2) + cstmt.getString (3);
     }
     finally
     {
       cstmt.close ();
     }
   }

 
   // Utility function to open a Bfile.
   // Note that an open Bfile is a different object from the
   // closed one.  The fileopen entrypoint returns the open file object
   // which is the one you have to use to read the file contents.
   static private BFILE fileopen (Transaction xact, BFILE bfile)
     throws SQLException
   {
     oracle.jdbc.driver.OracleCallableStatement cstmt 
        = (oracle.jdbc.driver.OracleCallableStatement)invokeCreateCallableStatement
                              (xact, "begin dbms_lob.fileopen (?, 0); end;", 1);
 
     try
     {
       cstmt.setBfile (1, bfile);
       cstmt.registerOutParameter (1, oracle.jdbc.driver.OracleTypes.BFILE);
       cstmt.execute ();
       return cstmt.getBFILE (1);
     }
     finally
     {
       cstmt.close ();
     }
   }
 
   // Utility function to test if a Bfile is open
   static private boolean fileisopen (Transaction xact, BFILE bfile)
     throws SQLException
   {
      oracle.jdbc.driver.OracleCallableStatement cstmt 
         = (oracle.jdbc.driver.OracleCallableStatement)invokeCreateCallableStatement
           (xact, "begin ? := dbms_lob.fileisopen (?); end;", 1);
 
     try
     {
       cstmt.registerOutParameter (1, Types.NUMERIC);
       cstmt.setBfile (2, bfile);
       cstmt.execute ();
       return cstmt.getBoolean (1);
     }
     finally
     {
       cstmt.close ();
     }
   }

 
   // Utility function to close a Bfile
   static private void fileclose (Transaction xact, BFILE bfile)
     throws SQLException
   {
     oracle.jdbc.driver.OracleCallableStatement cstmt
        = (oracle.jdbc.driver.OracleCallableStatement)invokeCreateCallableStatement
           (xact, "begin dbms_lob.fileclose (?); end;", 1);
 
//     System.out.println ("Closing bfile.");
     cstmt.setBfile (1, bfile);
     cstmt.execute ();
     cstmt.close ();
   }


   /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   * <p>
   * Returns a <code>BFILE</code> that contains data for this object.
   * <p>
   * @returns a BFILE as a <tt>java.lang.Object</tt>.
   **/
   public Object getData() 
   {
      return bFile;
   }


   /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   * <p>
   * NOT IMPLEMENTED FOR 3.0
   * Uses the given transaction context to store data back into the database
   * using the BFILE locator which should be set before this method is invoked.
   * <p>
   * @param xAct the name of the transaction.
   **/
   public void saveToDatabase(Transaction xAct) 
      throws Exception
   {
      if (bFile != null)
      {
         if (mData != null) 
         {
            //bfile.putChars(1, mData.toString().toCharArray());
         }
      }
   }


   /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   * <p>
   * NOT IMPLEMENTED FOR 3.0
   * Uses the given transaction context to store data back into the database
   * using the BFILE locator which should be set before this method is invoked.
   **/
   public void saveToDatabase(Transaction xAct, Object emptySQLObject) 
      throws SQLException
   {
      //get the oracle.sql.BFILE object from BfileDomain to set it's locator.
      BFILE nFile = ((BFileDomain)emptySQLObject).bFile;

      if (bFile != null)
      {
         //if I already have a populated bfile just reuse the locator.
         bFile.setLocator(nFile.getLocator());
      }
      else
      {
         //if the bfile value was null, use the current blob just for
         //the lcoator.
         useBFILE(nFile);
      }

      if (mData == null)
      {
         mData = dumpBFile(xAct, bFile);
      }

      //post the bfile data to the database, using the new locator.
      //bfile.putChars(1, mData.toString().toCharArray());
   }

   /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   *
   *
   **/
   public void   prepareForDML(Object context)
   {
      if (bFile == null && mData != null)
      {
         /*
         try
         {
            oracle.jdbc.driver.OracleCallableStatement cstmt = (oracle.jdbc.driver.OracleCallableStatement)
                   ((oracle.jdbc.driver.OracleConnection)context).prepareCall("begin select empty_clob() into ? from dual; end;");
            cstmt.registerOutParameter(1, oracle.jdbc.driver.OracleTypes.CLOB);
            cstmt.execute();
            clob = cstmt.getCLOB(1);
         }
         catch (SQLException sqle)
         {
            throw new JboException(sqle);
         }
         */
      }
   }

  /**
    *
    *
    * 
    * For testing purposes only: returns the contents fo the BFILE as a string.
    * @param the contents of the BFILE as a string.
    */
   public String toString() 
   {
      return new String (toByteArray());
   }
   

  /**
    * Returns the contents of this BFILE as a byte array.
    * @return the contents of the BFILE as a byte array.
    */
   public byte[] toByteArray()
   {
      if ((mData == null) &&
          (this.bFile != null))
      {
         mData = dumpBFile (xAct, bFile);
      }

      if (mData != null)
      {
         return mData.toByteArray();
      }
      return null;
   }


   /**
   * Converts all the data into a String and compares the two strings.
   * This is a default implementation of equals which could be overridden
   * to perform more scalable application-specific comparision.
   * <p>
   * @param obj the object to compare to this BfileDomain.
   **/
   public boolean equals(Object obj)
   {
      if (obj instanceof BFileDomain)
      {
        return true;
      }
      return false;
   }

   public OutputStream getOutputStream()
   {
     OutputStream out = null;
     return out;
   }

   public void closeOutputStream()
   {
   }

   public InputStream  getInputStream()
   {
/*
     InputStream is = null;
     try{
       is = bFile.getBinaryStream();
     }catch(Exception e){}
     return is;
*/


     if (inStream != null)
     {
       return inStream;
     }

     if (bFile != null) 
     {
        //local mode.
        try
        {
          inStream = bFile.getBinaryStream();
        }catch(SQLException e){}
     }
     else if (mClient) 
     {
        //do marshalling via an inner class that knows this domain instance and it's
        //owner row and txn.
        if (mIndexString == null) 
        {
           //simply write the absolute index : rowindex[.structindex]*
           getRemoteIdString();
        }

        try
        {
           Class implCls = Class.forName(CLIENT_LOB_DOMAIN_INPUT);
           Constructor cons = implCls.getConstructor(new Class[] { Transaction.class,
                                                                   DomainOwnerInterface.class,
                                                                   String.class });
           inStream = (InputStream) cons.newInstance(new Object[] { xAct, getOwnerRow(), mIndexString });
        }
        catch(Exception ex)
        {
           Throwable th = ex;

           if (th instanceof InvocationTargetException)
           {
              th = ((InvocationTargetException) th).getTargetException();
           }

           if (th instanceof JboException)
           {
              throw (JboException) th;
           }

           throw new JboException(th);
        }
     }
     return inStream;

   }
   
  protected DomainOwnerInterface getOwnerRow()
  {
     DomainOwnerInterface owner = mOwner;
     while (owner instanceof LobInterface) 
     {
        owner = ((LobInterface)owner).getOwner();
     }
     return (owner instanceof oracle.jbo.Row) ? owner : null;
  }

  public String getRemoteIdString()
  {
     if (mIndexString == null)
     {
        StringBuffer absIndex = new StringBuffer(relIdx.toString());
        String relIndex;
        DomainOwnerInterface owner = mOwner;
        while (owner instanceof LobInterface) 
        {
           absIndex = absIndex.insert(0, '.');
           absIndex = absIndex.insert(0, (new Integer(((LobInterface)owner).getOwnerAttributeIndex())).toString());
           owner = ((LobInterface)owner).getOwner();
        }
        mIndexString = absIndex.toString();
     }
     return mIndexString;
  }

  public void syncServerLob(LobInterface oldObj)
  {
     if (oldObj != null) 
     {
        BFileDomain old = (BFileDomain)oldObj;

        bFile = old.bFile;
        inStream  = old.inStream;
        
        //these could carry forward.
        mOwner    = old.mOwner;
        xAct      = old.xAct;
        mClient   = old.mClient;
        relIdx    = old.relIdx;
     }
  }

  public void syncClientLob(LobInterface oldObject)
  {
  }

  public DomainOwnerInterface getOwner()
  {
     return mOwner;
  }

  public long getSize()
  {
     //need to implement this.
     return -1;
  }

  public int getOwnerAttributeIndex()
  {
     return relIdx.intValue();
  }

   private void writeObject(ObjectOutputStream out)
     throws IOException
   {
     out.writeObject(relIdx);
   }
   
   private void readObject(ObjectInputStream in)
     throws IOException, ClassNotFoundException
   {
     relIdx = (Integer)in.readObject();
   }

   //
   // needs to be implemented as a remote method
   //
  public void openFile() 
  {
    if(mClient)
    {
      Method mth  = getInvokeDomainMethod();
      try
      {
         if (mIndexString == null) 
         {
            getRemoteIdString();
         }
         mth.invoke(xAct, new Object[] {
                           getOwnerRow(),
                           mIndexString, 
                           Boolean.FALSE, 
                           "openFile", 
                           new String[] {},
                           new Object[] {}
                          });
      }
      catch (Exception e)
      {
         throw new JboException(e);
      }
    }else
    {
      try {
        bFile.openFile();
      }catch(SQLException e)
      {
        throw new JboException(e);
      }
    }
  }

   //
   // needs to be implemented as a remote method
   //
  public void closeFile()
  {
    if(mClient)
    {
      Method mth  = getInvokeDomainMethod();
      try
      {
         if (mIndexString == null) 
         {
            getRemoteIdString();
         }
         mth.invoke(xAct, new Object[] {
                           getOwnerRow(),
                           mIndexString, 
                           Boolean.FALSE, 
                           "closeFile", 
                           new String[] {},
                           new Object[] {}
                          });
      }
      catch (Exception e)
      {
         throw new JboException(e);
      }
    }else
    {
      try {
        bFile.closeFile();
      }catch(SQLException e)
      {
        throw new JboException(e);
      }
    }
  }

  public static Method getInvokeDomainMethod()
  {
     try
     {
        Class implCls = Class.forName(CLIENT_APPMODULE_CLASS);

        Method cons = implCls.getMethod("invokeDomainMethod", new Class[] {
                                                          oracle.jbo.Row.class,
                                                          java.lang.String.class, 
                                                          Boolean.TYPE,
                                                          java.lang.String.class, 
                                                          java.lang.String[].class,
                                                          java.lang.Object[].class});
        return cons;
     }
     catch (Exception e)
     {
        throw new JboException(e);
     }

  }

  public java.io.Reader getCharacterStream()
  {
     return new java.io.InputStreamReader(getInputStream());
  }
  
  public java.io.Writer getCharacterOutputStream()
  {
    return new java.io.OutputStreamWriter(getOutputStream());
  }
  
  public void closeCharacterOutputStream()
  {
    closeOutputStream();
  }
  
}




