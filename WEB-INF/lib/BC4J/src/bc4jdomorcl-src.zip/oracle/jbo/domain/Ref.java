
package oracle.jbo.domain;


import java.io.Serializable;
import java.io.ObjectOutputStream;
import java.io.ObjectInputStream;
import java.io.IOException;

import java.sql.SQLException;

import oracle.sql.CustomDatum;
import oracle.sql.CustomDatumFactory;
import oracle.sql.Datum;
import oracle.sql.REF;
import oracle.sql.StructDescriptor;

import oracle.jbo.common.Diagnostic;
import oracle.jbo.JboException;
import oracle.jbo.Row;
import oracle.jbo.Transaction;

/**
* This class provides a lightweight wrapper for <tt>oracle.sql.Ref</tt>,
* the Java representation of the
* REF database type. This wrapper allows an instance of the
* <tt>oracle.sql.Ref</tt> to be used as an immutable Domain object.
* <p>
* The <tt>oracle.jbo.domain.Ref</tt> class is the Java representation
* of the underlying
* database type that you must use if you want to exploit the domain feature of
* Business Components for Java.
* @since JDeveloper 3.0
*/
public class Ref implements DomainInterface,
                            CustomDatum,
                            Serializable
{
   String mStructName = null;
   byte[] mData = null;
   Transaction mTrans = null;
   
   static CustomDatumFactory fac = null;
   static final long serialVersionUID = -4710224942623842135L;

  /**
    * <b>Internal:</b> <em>Applications should not invoke this method.</em>
    * <p>Initializes the <code>Ref</code> Domain.
    *
    * This method is invoked when Business Components for Java is initialized.
    *
    * @return the <code>CustomDatumFactory</code> for the
    * <code>Ref</code> Domain.
    */
   public static CustomDatumFactory getCustomDatumFactory()
   {
      if (fac == null)
      {
         class facClass implements CustomDatumFactory
         {
            public CustomDatum create(Datum d, int sql_type_code) throws SQLException
            {
               if (d != null)
               {
                  return new Ref(d);
               }
               return null;
            }
         }  ;
         fac = new facClass();
      }
      return fac;
   }
  /**
  * <b>Internal:</b> <em>Applications should not invoke this constructor.</em>
  */
   protected Ref()
      throws SQLException
   {
   }

   /**
   * <b>Internal:</b> <em>Applications should not invoke this constructor.</em>
   * <p>
   * Creates a Ref Domain object.
   */
   public Ref(String structName, byte[] data)
   {
      mStructName = structName;
      mData = data;
   }

  /**
  * <b>Internal:</b> <em>Applications should not invoke this constructor.</em>
  */
   public Ref(Datum d)
      throws SQLException 
   {
      mStructName = ((REF) d).getBaseTypeName();
      mData = d.getBytes();
   }

   /**
    * <b>Internal:</b> <em>Applications should not invoke this method.</em>
    * <p>Converts this <code>Ref</code> Domain object back into a
    * SQL <code>REF</code> object.
    *
    * @param <code>conn</code> Not used.
    * @return A <code>Datum</code> containing <code>REF</code> object.
    * @throws java.sql.SQLException Never.
    */
   public Datum toDatum(oracle.jdbc.driver.OracleConnection conn) throws SQLException
   {
      return new REF(new StructDescriptor(mStructName, conn),
                     conn, mData);
   }

  /**
  * <b>Internal:</b> <em>Applications should not invoke this method.</em>
  */
   public void setContext(DomainOwnerInterface owner, Transaction trans, Object fac)
   {
      mTrans = trans;
   }

  /**
    * <b>Internal:</b> <em>Applications should not invoke this method.</em>
    * <p>
    * Converts <code>this</code> to a JDBC object.
    *
    *
    * @return the JDBC representation of <code>this</code>, or  <code>null</code>,
    * if the conversion fails.
    */
   public Object getData()
   {
      return mTrans.createRef(mStructName, mData);
   }

    /**
    * Returns the name of the struct associated with this RefDomain.
    * @return the name of the struct.
    */
   public String getStructName()
   {
      return mStructName;
   }

   /**
   * Returns the contents of the Ref in byte format.
   * @return a byte array containing the contents of the Ref.
   */
   public byte[] getBytes()
   {
      return mData;
   }

   /**
   * Returns an an instance of the refernced row, given the attribute
   * definition object.
   *
   * The referenced row is returned as an {@link oracle.jbo.Row} object.
   * @param ad the attribute's attribute definition object.
   * @return the row corredsponding to the attribute definition object.
   * @see oracle.jbo.Row
   *
   */
   public Row getReferencedObject(DomainAttributeDef ad)
   {
      try
      {
         if (ad != null)
         {
            return ad.getReferencedObject(this, mTrans);
         }
         return null;
      }
      catch (JboException je)
      {
         throw je;
      }
      catch (Exception e)
      {
         Diagnostic.println("Must be running in non-local mode!");
         throw new JboException(e);
      }
   }

  /**
    * Tests <code>this</code> for equality with another object.
    *
    * <p>The argument is converted to a <code>Ref</code> object, if necessary.
    *
    * @param other  an arbitrary <code>Object</code>.
    * @return <code>true</code> if conversion was successful and the converted
    * argument is identical to <code>this</code>.
    */
   public boolean equals(Object obj)
   {
      if (obj instanceof Ref)
      {
         Ref otherRef = (Ref) obj;
         String otherStructName = otherRef.getStructName();
         byte[] otherBytes = otherRef.getBytes();

         if (mStructName == null)
         {
            if (otherStructName != null)
            {
               return false;
            }
         }
         else
         {
            if (!mStructName.equals(otherStructName))
            {
               return false;
            }
         }

         if (mData == null)
         {
            if (otherBytes != null)
            {
               return false;
            }
         }
         else
         {
            if (mData.length != otherBytes.length)
            {
               return false;
            }
            
            for (int j = 0; j < mData.length; j++)
            {
               if (mData[j] != otherBytes[j])
               {
                  return false;
               }
            }
         }

         return true;
      }

      return false;
   }

   
   private void writeObject(ObjectOutputStream out)
      throws IOException
   {
      if (mStructName != null)
      {
         out.writeBoolean(false);
         out.writeUTF(mStructName);
      }
      else
      {
         out.writeBoolean(true);
      }

      if (mData != null)
      {
         out.writeBoolean(false);
         out.writeInt(mData.length);
         out.write(mData);
      }
      else
      {
         out.writeBoolean(true);
      }
   }


   private void readObject(ObjectInputStream in)
      throws IOException, ClassNotFoundException
   {
      if (!in.readBoolean())
      {
         mStructName = in.readUTF();
      }

      if (!in.readBoolean())
      {
         int len = in.readInt();

         mData = new byte[len];
         in.read(mData, 0, len);
      }
   }
}
