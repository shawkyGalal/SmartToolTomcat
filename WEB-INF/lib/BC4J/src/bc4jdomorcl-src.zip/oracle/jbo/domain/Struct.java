
package oracle.jbo.domain;

import java.lang.reflect.Method;
import java.io.ObjectOutputStream;
import java.io.ObjectInputStream;
import java.io.PrintWriter;
import java.io.Serializable;
import java.io.IOException;
import java.sql.SQLException;
import java.util.Hashtable;
import com.sun.java.util.collections.HashMap; 


import oracle.sql.CustomDatum;
import oracle.sql.CustomDatumFactory;
import oracle.sql.Datum;
import oracle.sql.STRUCT;

import oracle.jbo.AttributeDef;
import oracle.jbo.AttributeList;
import oracle.jbo.StructureDef;
import oracle.jbo.SQLDatumException;
import oracle.jbo.CSMessageBundle;
import oracle.jbo.Transaction;
import oracle.jbo.JboException;
import oracle.jbo.InvalidOperException;
import oracle.jbo.common.TypeMarshaller;
import oracle.svcmsg.ResponseValues;


/**
* This class provides a lightweight wrapper for <tt>oracle.sql.STRUCT</tt>,
* the Java representation of the
* Struct database type. This wrapper allows an instance of the
* <tt>oracle.sql.STRUCT</tt> to be used as a domain object.
* <p>
* The <tt>oracle.jbo.domain.StructDomain</tt> class is the Java representation
* of the underlying
* database type that you must use if you want to exploit the domain feature of
* Business Components for Java.
* @since JDeveloper 3.0
*/
public abstract class Struct implements LobInterface,
                                        DomainOwnerInterface,
                                        XMLDomainInterface,
                                        AttributeList,
                                        CustomDatum,
                                        Serializable,
                                        MarshalledDomain
{
   /**
   * <b>Internal:</b> <em>Applications should not use this field.</em>
   */
   protected Object  mData;
   int     mHashCode;
   boolean mIsHashGood;
   String mIndexString;
   DomainOwnerInterface mOwner = null;

   /**
   * <b>Internal:</b> <em>Applications should not use this field.</em>
   */
   protected Object  mConnection;

   /**
   * <b>Internal:</b> <em>Applications should not use this field.</em>
   */
   protected Transaction mTxn;

   /**
   * <b>Internal:</b> <em>Applications should not use this field.</em>
   */
   protected HashMap mContext = new HashMap(2);

   /**
   * Index of the attribute in the domain owner's container.
   */
   protected int mOwnerAttrIndex = -1;

   //could be overridden by subclasses to set their specific values.
   /**
   * The factory object that creates an instance of this STRUCT given
   * an XML element.
   */
   protected XMLDomainFactory mXmlFac = null;

   /**
   * Factories for each of the attibutes if they have one.
   *
   */
   protected XMLDomainFactory mAttrXmlFac[] = null;

   /**
   * Returns the column type of the database column that corresponds to
   * this STRUCT.
   * <p>
   * @return the column type as a String.
   */
   abstract public String getColumnType();

   /**
   * Returns the structure definition, that describes the details of the
   * attributes, of this domain.
   * <p>
   * @return the structure definition as a StructureDef object.
   */
   abstract public StructureDef getStructureDef();

   /**
   * Returns the SQL types for the attributes of the structure.
   */
   abstract public int[] getAttrSQLTypes();

   /**
   * Returns factories that oracle.sql requires to create the attributes of
   * this structure.
   */
   abstract public CustomDatumFactory[] getAttrCustomDatumFactories();

    /**
    * Initializes the structure definition of this object and its
    * attribute definitions.
    */
   abstract protected void initStructureDef();

   private void initStruct(Datum d)
   {
      mHashCode = -1;
      mIsHashGood = false;

      initStructureDef();
      mData = (d != null) ? (Object)d : new Object[getAttributeCount()];

      /*
      if (d == null)
      {
         mData = new MTMutableStruct(new Object[getAttributeCount()],
                                      getAttrSQLTypes(),
                                      getAttrCustomDatumFactories());
      }
      else
      {
         mData = new MTMutableStruct((STRUCT) d,
                                   getAttrSQLTypes(),
                                   getAttrCustomDatumFactories());
      }
      */
   }

   /**
   * Constructs an instance of this class.
   */
   protected Struct()
      throws SQLException
   {
      initStruct(null);
   }

   /**
   * <b>Internal:</b> <em>Applications should not use this constructor.</em>
   * <p>
   * @param d a datum object.
   * @throws java.lang.SQLException
   */
   protected Struct(Datum d)
      throws SQLException
   {
      initStruct(d);
   }
   
  /**
    * <b>Internal:</b> <em>Applications should not use this method.</em>
    * <p>
    * Converts <code>this</code> to a Struct JDBC object.
    *
    *
    * @return the JDBC representation of <code>this</code>, or  <code>null</code>,
    * if the conversion fails.
    */
   public Object getData()
   {
      return this;
   }

    /**
   * Notification method that this domain calls whenever any of its
   * attribute values are about
   * to be modified. This Domain should always notify its owner.
   * @param d the domain being modified.
   */
   public void domainToBeModified(DomainInterface d)
   {
      if (mOwner != null) 
      {
         mOwner.domainToBeModified(this);
      }
   }


    /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   * <p>
   */
   public void setContext(DomainOwnerInterface owner, Transaction trans, Object ctx)
   {

      //how do I figure that the owner is not the same entity (after commit when entity is refetched?
      //may be we have to look at PKs for the two entities, but what happens when PK is null
      //to start with for two entities that're filling in attributes?
      //if (mOwner != null && owner != null && !mOwner.equals(owner)) 
      //{
      //   throw new DataCreationException(this.getClass().getName(), 
      //                                   "An instance of struct domain cannot be shared by two owners",
      //                                   null);
      //}
      mOwner = owner;
      mTxn = trans;

      HashMap context = (HashMap)ctx;
      mContext = (HashMap)context.clone();
      
      //could be -1 incase of varray.
      mOwnerAttrIndex = ((Integer)mContext.get(DomainContext.RELATIVE_INDEX)).intValue();

      Object obj;
      for ( int i = 0; i < getAttributeCount(); i++)
      {
         obj = getAttribute(i);
         if (obj instanceof DomainInterface) 
         {
            //what happens to older contexts?
            //also what happens to values that are null to start with?

            //pass myself as the owner of the contained domain for proper chaining
            //and setAttribute stuff to work.
            mContext.put(DomainContext.RELATIVE_INDEX, new Integer(i));
            ((DomainInterface)obj).setContext(this, trans, mContext);
         }
      }
   }

  /**
    * Tests <code>this</code> for equality with another object.
    *
    * <p> The argument is converted to a <code>STRUCT</code> object, if necessary.
    *
    * @param obj  an arbitrary <code>Object</code>.
    * @return <code>true</code> if conversion was successful and the converted
    * argument is identical to <code>this</code>.
    */
   public boolean equals(Object obj)
   {
      if (obj instanceof Struct)
      {
         Struct str = (Struct) obj;
         int attrCount = getAttributeCount();

         if (attrCount != str.getAttributeCount())
         {
            return false;
         }
         
         for (int j = 0; j < attrCount; j++)
         {
            Object attrVal = getAttribute(j);
            Object theOtherAttrVal = str.getAttribute(j);
            
            if (attrVal == null)
            {
               if (theOtherAttrVal != null)
               {
                  return false;
               }
               else
               {
                  continue;
               }
            }
            
            if (!attrVal.equals(theOtherAttrVal))
            {
               return false;
            }
         }
         
         return true;
      }
      
      return false;
   }
   
  /**
    * Computes a hash code for <code>this</code> StructDomain object.
    *
    * @return the hash code of <code>this</code> StructDomain object.
    */
   public int hashCode()
   {
      if (mIsHashGood)
      {
         int attrCount = getAttributeCount();

         mHashCode = 0;
         for (int j = 0; j < attrCount; j++)
         {
            mHashCode += getAttribute(j).hashCode();
         }

         mIsHashGood = true;
      }
      
      return mHashCode;
   }
   
    /**
    * <b>Internal:</b> <em>Applications should not use this method.</em>
    * <p>
    * For testing purposes only. Converts <code>this</code> Struct
    * object to a text representation.
    * @return a String representation of this Struct object.
    */
   public String toString()
   {
      int attrCount = getAttributeCount();
      String retVal = "(";
      
      for (int j = 0; j < attrCount; j++)
      {
         if (j > 0)
         {
            retVal += ", ";
         }
         
         retVal += getAttribute(j);
      }
      
      retVal += ")";
      
      return retVal;
   }

   void convertArrayToStruct()
   {
      if (mData instanceof STRUCT)
      {
         try
         {
            mConnection = (oracle.jdbc.OracleConnection)((STRUCT)mData).getJavaSqlConnection();
         }
         catch(Exception sqle) //9i throws SQLException
         {
           // this is not handled for now.
           // the exception is introduced from 9i
         }
       mData = new oracle.jpub.runtime.MutableStruct((STRUCT) mData,
                                   getAttrSQLTypes(),
                                   getAttrCustomDatumFactories());
      }
      else if (!(mData instanceof oracle.jpub.runtime.MutableStruct))
      {
         Object arr[];
         if (mData != null) 
         {
            //has to be an object array.
            arr = (Object [])mData;
         }
         else 
         {
            arr = new Object[getAttributeCount()];
         }
         
         /*
         //Commented out for 817. Need to bring this back when we work with 8.2 jdbc
         //See bug 1400872 for details. For 8.1.7, need to call the other constructor
         //and set the attributes individually. Basically the code in next set of
         //brackets need to be removed and the following line uncommneted in 8.2
         mData = new oracle.jpub.runtime.MutableStruct(arr,
                                         getAttrSQLTypes(),
                                         getAttrCustomDatumFactories());
         */

         {
            //workaround for bug 1400872 in jdbc 8.1.7. Needs to go in 8.2
            oracle.jpub.runtime.MutableStruct mutableStruct 
                       = new oracle.jpub.runtime.MutableStruct((STRUCT)null,
                                      getAttrSQLTypes(),
                                      getAttrCustomDatumFactories());
   
            Object attrObj;
            for (int i = 0; i < arr.length; i++) 
            {
               try
               {
                  attrObj = arr[i];

                  //assuming that lobs implement CustomDatum interface.
                  mutableStruct.setAttribute(i, attrObj);
               }
               catch (SQLException sqle)
               {
                  //ignore this sqlexception as this should never be the case.
                  //plus when we move to 8.2, things would work differently.
               }
            }
   
            mData = mutableStruct;
         }

      }
   }
   
   /**
    * <b>Internal:</b> <em>Applications should not use this method.</em>
    * <p>
    * Converts this <code>Struct</code> Domain object back into an
    * SQL <code>STRUCT</code> object.
    *
    * @param <code>conn</code> Not used.
    * @return A <code>Datum</code> containing <code>STRUCT</code> object.
    * @throws java.sql.SQLException Never.
    */
   public Datum toDatum(oracle.jdbc.driver.OracleConnection conn) throws SQLException
   {
      return toDatum((oracle.jdbc.OracleConnection)conn);
   }
   
   /**
    * <b>Internal:</b> <em>Applications should not use this method.</em>
    * <p>
    * Converts this <code>Struct</code> Domain object back into an
    * SQL <code>STRUCT</code> object.
    *
    * @param <code>conn</code> Not used.
    * @return A <code>Datum</code> containing <code>STRUCT</code> object.
    * @throws java.sql.SQLException Never.
    */
   public Datum toDatum(oracle.jdbc.OracleConnection conn) throws SQLException
   {
      convertArrayToStruct();
      mConnection = conn;
      int sqlTypes[] = getAttrSQLTypes();
      Object arr[] = ((oracle.jpub.runtime.MutableStruct)mData).getAttributes();
      boolean bChanged = false;
      for (int i = 0; i < sqlTypes.length; i++)
      {
         if (sqlTypes[i] > 2000 && arr[i] instanceof String)
         {
            sqlTypes[i] = oracle.jdbc.OracleTypes.VARCHAR;
            bChanged = true;
         }
      }
      if (bChanged)
      {
         mData = new oracle.jpub.runtime.MutableStruct(arr,
                                         sqlTypes,
                                         getAttrCustomDatumFactories());
      }
      return ((oracle.jpub.runtime.MutableStruct)mData).toDatum(conn, getColumnType());
   }


   /**
   * Returns the attribute from this StructDomain object, given its index.
   * <p>
   * @param index index for the attribute in the StructDomain object.
   * @return an attribute as an Object type.
   */
   public Object getAttribute(int index)
   {
      try
      {
         if (mData instanceof Object[]) 
         {
            return ((Object [])mData)[index];
         }
         
         convertArrayToStruct();

         //what's returned from jdbc may not be same type as domain expects.
         //need to convert using TypeFactory.
         Object baseVal = ((oracle.jpub.runtime.MutableStruct)mData).getAttribute(index);
         Object attrVal = baseVal;
         if (getAttrCustomDatumFactories()[index] == null) 
         {
            attrVal = TypeFactory.getInstance(getStructureDef().getAttributeDef(index).getJavaType(), baseVal);
            if (attrVal instanceof DomainInterface && attrVal != baseVal) 
            {
               //what happens to older contexts?
               //also what happens to values that are null to start with?
   
               //pass myself as the owner of the contained domain for proper chaining
               //and setAttribute stuff to work.
               mContext.put(DomainContext.RELATIVE_INDEX, new Integer(index));
               ((DomainInterface)attrVal).setContext(this, mTxn, mContext);
               if (attrVal instanceof LobInterface) 
               {
                  ((oracle.jpub.runtime.MutableStruct)mData).setAttribute(index, attrVal);    
               }
            }
         }
         return attrVal;
      }
      catch(SQLException ex)
      {
         throw new SQLDatumException(CSMessageBundle.class,
                                     CSMessageBundle.EXC_JDBC_GET_SQL_DATUM,
                                     new Object[] { getColumnType(),
                                                    getStructureDef().getAttributeDef(index).getName() },
                                     ex);
      }
   }

   /*
   public Object clone() 
   {
      try
      {
         try
         {
            Struct other = (Struct)getClass().newInstance();
            other.mData        = this.mData;        
            other.mHashCode    = this.mHashCode;    
            other.mIsHashGood  = this.mIsHashGood;  
            return other;
         }
         catch(Exception e)
         {
         }
         return super.clone();
      }
      catch (java.lang.CloneNotSupportedException cnse)
      {
      }
      return this;
   }
   */


    /**
   * Returns the attribute from this StructDomain object, given its name.
   * <p>
   * @param name name for the attribute in the StructDomain object.
   * @return an attribute as an Object type.
   */
   public Object getAttribute(String name)
   {
      return getAttribute(getAttributeIndexOf(name));
   }
   
   /**
   * Sets the value of an attribute in this StructDomain, at the given index
   * position.
   * <p>
   * @param index index for the attribute in the StructDomain object.
   * @param value value for the attribute.
   */
   public void setAttribute(int index, Object value)
   {
      if (mOwner != null)
      {
         mOwner.domainToBeModified(this);
      }
      
      try
      {
         mIsHashGood = false;
         
         if (value instanceof DomainInterface ) 
         {
            //pass myself as the owner of the contained domain for proper chaining
            //and setAttribute stuff to work.
            mContext.put(DomainContext.RELATIVE_INDEX, new Integer(index));
            ((DomainInterface)value).setContext(this, mTxn, mContext);
         }

         value = TypeFactory.getInstance(getStructureDef().getAttributeDef(index).getJavaType(), value);

         if (mData instanceof Object[]) 
         {
            ((Object [])mData)[index] = value;
         }
         else
         {
            convertArrayToStruct();
            ((oracle.jpub.runtime.MutableStruct)mData).setAttribute(index, value);
         }
      }
      catch(SQLException ex)
      {
         throw new SQLDatumException(CSMessageBundle.class,
                                     CSMessageBundle.EXC_JDBC_GET_SQL_DATUM,
                                     new Object[] { getColumnType(),
                                                    getStructureDef().getAttributeDef(index).getName(),
                                                    value },
                                     ex);
      }

      if (mOwner instanceof AttributeList && mOwnerAttrIndex > -1) 
      {
         //this may be too slow, but hey, we need to perform attribute validations
         //on the domain once any attribute on it are changed somewhere.
         ((AttributeList)mOwner).setAttribute(mOwnerAttrIndex, this);

         //we can optimize this by performing update only when ready, however, we need
         //to build such mechanism.

         //subclasses could build such mechanism now, by caching AttrIndex themselves
         //and setting it to -1 or some negative value, till they're ready to validate
         //this attribute and then perform entity's setAttribute themselves or by calling
         //setAttribute on this domain object after resetting the mAttrIndex to a valid
         //attribute index.

      }
   }

   public String getRemoteIdString()
   {
      if (mIndexString == null)
      {
         StringBuffer absIndex = new StringBuffer(new Integer(mOwnerAttrIndex).toString());
         String relIndex;
         DomainOwnerInterface owner = mOwner;
         while (owner instanceof Struct) 
         {
            absIndex = absIndex.insert(0, '.');
            absIndex = absIndex.insert(0, (new Integer(((Struct)owner).mOwnerAttrIndex)).toString());
            owner = ((Struct)owner).mOwner;
         }
         mIndexString = absIndex.toString();
      }
      return mIndexString;
   }

   /**
   * Sets the value of an attribute in this StructDomain object, at the given index
   * position.
   * <p>
   * @param index index for the attribute in the StructDomain object.
   * @param value value for the attribute.
   */
   public void setAttributeNoCheck(int index, Object value)
   {
      try
      {
         mIsHashGood = false;
         
         if (mData instanceof Object[]) 
         {
            if (value instanceof DomainInterface ) 
            {
               //pass myself as the owner of the contained domain for proper chaining
               //and setAttribute stuff to work.
               mContext.put(DomainContext.RELATIVE_INDEX, new Integer(index));
               ((DomainInterface)value).setContext(this, mTxn, mContext);
            }
            ((Object [])mData)[index] = value;
            return;
         }

         convertArrayToStruct();
         ((oracle.jpub.runtime.MutableStruct)mData).setAttribute(index, value);
      }
      catch(SQLException ex)
      {
         throw new SQLDatumException(CSMessageBundle.class,
                                     CSMessageBundle.EXC_JDBC_GET_SQL_DATUM,
                                     new Object[] { getColumnType(),
                                                    getStructureDef().getAttributeDef(index).getName(),
                                                    value },
                                     ex);
      }
   }

   /**
   * Sets the value of an attribute in this StructDomain object, given the
   * attributes's name.
   *
   * <p>
   * @param name name of the attribute in the StructDomain object.
   * @param value value for the attribute.
   */
   public void setAttribute(String name, Object value)
   {
      setAttribute(getAttributeIndexOf(name), value);
   }
   
   /**
   * Returns the number of attributes in this StructDomain object.
   * @return the number of attributes as an int.
   */
   public int getAttributeCount()
   {
      return getStructureDef().getAttributeCount();
   }
   
   /**
   * Returns the index of a named attribute in this StructDomain object.
   * <p>
   * @param name name of an attribute in this StructDomain object.
   * @return the index of the named attribute as an int.
   */
   public int getAttributeIndexOf(String name)
   {
      return getStructureDef().findAttributeDef(name).getIndex();
   }

   /**
   * Returns an array of the SQL datatypes of the attributes in this
   * StructDomain object.
   * @return an array of SQL datatypes.
   */
   public int[] buildAttrSQLTypes()
   {
      int attrCount = getStructureDef().getAttributeCount();
      int[] retVal = new int[attrCount];

      for (int j = 0; j < attrCount; j++)
      {
         retVal[j] = getStructureDef().getAttributeDef(j).getSQLType();
      }

      return retVal;
   }

   public ResponseValues marshal()
   {
      return TypeMarshaller.serializeObject(this);
   }
   
   private void writeObject(ObjectOutputStream out)
      throws IOException
   {
      out.writeInt(mHashCode);
      out.writeBoolean(mIsHashGood);
      
      int attrCount = getAttributeCount();

      for (int j = 0; j < attrCount; j++)
      {
         out.writeObject(getAttribute(j));
      }
   }


   private void readObject(ObjectInputStream in)
      throws IOException, ClassNotFoundException
   {
      if (mData == null)
      {
         initStruct(null);
      }
      
      mHashCode = in.readInt();
      //System.out.println("Hashcode :"+mHashCode);
      mIsHashGood = in.readBoolean();
      //System.out.println("mIsHashGood:"+mIsHashGood);
      
      int attrCount = getAttributeCount();
      //System.out.println("AttributeCount:"+attrCount);

      Object[] data = (Object[])mData;
      for (int j = 0; j < attrCount; j++)
      {
         //setAttribute(j, in.readObject());
         data[j] = in.readObject();
      }
      mIsHashGood = false;
   }

   //xml stuff hereon.

   /**
   * Returns this class name as xml-element tag for this Struct domain object.
   * Override this method to return a custom xml-element tag for this domain.
   **/
   protected String getXMLElementTag()
   {
      //in the generated code, we should always generate this method and return
      //hardcoded classname to avoid slow runtime performance due to calculation 
      //of the name.
      String className = this.getClass().getName();
      int index = className.lastIndexOf('.');
      if (index > 0) 
      {
         className = className.substring(index+1);
      }
      return className;
   }

   /**
   * Returns the class name of this domain, appended with the name of the
   * attribute  as xml-element tag for this domain-attribute.
   * 
   * Override this method to return a custom xml-element tag for the given 
   * attribute.
   * @param ad the name of an AttributeDef.
   **/
   protected String getAttrXMLElementTag(AttributeDef ad)
   {
      return getXMLElementTag()+"_"+ad.getName();
   }

   /**
   * Returns false always.
   * Override to determine whether the given domain-attribute is
   * to be rendered in CDATA format in xml.
   * @param ad name of an AttributeDef.
   **/
   protected boolean isAttrXMLCData(AttributeDef ad)
   {
      return false;
   }

   /**
   * Creates the xml node in the given xml document for this domain's data.
   * @param xmlDoc name of the XML document in which the node should be created.
   **/
   public org.w3c.dom.Node getXMLContentNode(org.w3c.dom.Document xmlDoc)
   {
      String xmlName = getXMLElementTag();
      org.w3c.dom.Node e = xmlDoc.createElement(xmlName);
      org.w3c.dom.Node n;
      org.w3c.dom.Node c;

      AttributeDef attrs[] = getStructureDef().getAttributeDefs();

      for (int i = 0; i < attrs.length; i++)
      {
         xmlName = getAttrXMLElementTag(attrs[i]);
         if (!xmlName.equals("#hide")) 
         {
            c = DomainAttributeDef.getXMLContentNode(xmlDoc, getAttribute(i), isAttrXMLCData(attrs[i]), false);
            if (c != null) 
            {
               n = xmlDoc.createElement(xmlName);
               n.appendChild(c);
               e.appendChild(n);
            }
         }
      }
      return e;
      
   }

   /**
   * Reads all the attribute values from the xml-element and sets them 
   * into this row.
   * If the xml has a process instruction of the form:
   * <?bc4j remove?> then, invokes remove() on this row.
   **/
   protected void readAttrsFromXML(org.w3c.dom.Element rowElt)
   {
      AttributeDef[] attrs = getStructureDef().getAttributeDefs();
      if (mAttrXmlFac == null)
      {
         initAttrXMLDomainFactories(attrs);
      }


      Object value = null;
      rowElt = (org.w3c.dom.Element)rowElt.getFirstChild();
      if (rowElt == null) 
      {
         return;
      }
      for (int i=0; i < attrs.length; i++)
      {
         value = null;
         org.w3c.dom.NodeList nl = ((oracle.xml.parser.v2.XMLElement)rowElt).getChildrenByTagName(getAttrXMLElementTag(attrs[i]));
         if (nl.getLength() > 0)
         {
            if (mAttrXmlFac[i] != null) 
            {
               value = (DomainInterface) mAttrXmlFac[i].createDomainFromXMLElement((org.w3c.dom.Element)nl.item(0));
            }
            else
            {
               value = nl.item(0).getFirstChild().getNodeValue();
               if (value != null)
               {
                  //get the properly typed-attribute value 
                  value = TypeFactory.getInstance(attrs[i].getJavaType(), value);
               }
            }
         }
         if (value != null) 
         {
            setAttribute(i, value);
         }
      }
   }

   /**
   * Prints the DTD info for this domain in the given print writer.
   * Returns the DTD string to be added to this domain's container
   * entity/domain.
   * <p> The <tt>allDefs</tt> hashtable contains predefined XML definitions and
   * is passed by whatever calls this method.
   * <p>
   * @param allDefs a hashtable of predefined XML definitions passed from whatever
   * calls this method.
   * @param pw print writer into which the defnition is being printed.
   * @param bContainees if <tt>true</tt>, prints definitions of contained objects.
   **/
   public String printXMLDefinition(Hashtable allDefs, PrintWriter pw, 
                             boolean bContainees)
   {
      AttributeDef ad[] = getStructureDef().getAttributeDefs();
      String xmlTag = getXMLElementTag();

      if (allDefs.get(xmlTag) == null) 
      {
         StringBuffer elementStr = (new StringBuffer("<!ELEMENT ")
                                        .append(xmlTag)
                                        .append(" (")
                                   );
   
         String attrTag;
         for (int i = 0; i < ad.length; i++) 
         {
            attrTag = getAttrXMLElementTag(ad[i]);
            if (i != 0)
            {
               elementStr.append(", ");
            }
            elementStr.append(DomainAttributeDef.printAttrXMLDefinition((AttributeList)this, attrTag, ad[i], allDefs, pw, bContainees));
         }
         
         elementStr.append(")>");
         allDefs.put(xmlTag, xmlTag);
         pw.println(elementStr.toString());
      }
      return xmlTag;
   }

   /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   */
   public static XMLDomainFactory getXMLDomainFactory(Class attrClass) 
   {
      class facClass implements XMLDomainFactory 
      {
         Class mAttrClass;
         facClass(Class clas)
         {
            mAttrClass = clas;
         }

         public DomainInterface createDomainFromXMLElement(org.w3c.dom.Element node)
         {
            try
            {
               Struct s = (Struct)mAttrClass.newInstance();
               s.readAttrsFromXML(node);
               return s;
            }
            catch (JboException e)
            {
               throw e;
            }
            catch (Exception e)
            {
               //throw new jbo exception here.
               throw new JboException(e);
            }
         }
      }
      
      return new facClass(attrClass);
   }

   /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   */
   protected void initAttrXMLDomainFactories(AttributeDef attrs[])
   {
      if (mAttrXmlFac == null)
      {
         mAttrXmlFac = new XMLDomainFactory[attrs.length];
         for (int i = 0; i < mAttrXmlFac.length; i++)
         {
            try
            {
               Object arg[] = new Object[] {attrs[i].getJavaType()};
               Method mth = ((Class)arg[0]).getMethod(
                                        "getXMLDomainFactory", new Class[] {arg[0].getClass()});
               //must be a static method.
               mAttrXmlFac[i] = (XMLDomainFactory)mth.invoke(null, arg);
            }
            catch (Exception e)
            {
               //ignore.
            }
         }
      }
   }

   /**
    * <b>Internal:</b> <em>Applications should not use this method.</em>
    * <p>
    * Loads the actual data of the LOB-type database attribute into memory.
    *
    * <p>The transaction argument is needed to perform an additional query into
    * the database to extract the data.
    * <p>This method does not need to be invoked for a new attribute.
    *
    * @param transaction the {@link oracle.jbo.server.DBTransactionImpl}
    * of the current Application Module.
    */
   public void loadFromDatabase( Transaction transaction )
      throws Exception
   {
      Object obj;
      for ( int i = 0; i < getAttributeCount(); i++)
      {
         obj = getAttribute(i);
         if (obj instanceof LobInterface) 
         {
            ((LobInterface)obj).loadFromDatabase(transaction);
         }
      }
   }

   /**
    * <b>Internal:</b> <em>Applications should not use this method.</em>
    * <p> Saves data in memory to a database LOB-type attribute.
    *
    * <p>The transaction argument is is needed to perform an additional query into
    * the database to write the data.
    * <p>This method does not need to be invoked if this attribute's data
    * has not changed.
    *
    * @param transaction the {@link oracle.jbo.server.DBTransactionImpl}
    * instance of the current Application Module.
    */
   public void saveToDatabase( Transaction transaction )
      throws Exception
   {
      Object obj;
      for ( int i = 0; i < getAttributeCount(); i++)
      {
         obj = getAttribute(i);
         if (obj instanceof LobInterface) 
         {
            ((LobInterface)obj).saveToDatabase(transaction);
         }
      }
   }

      /**
     * <b>Internal:</b> <em>Applications should not use this method.</em>
     * <p>
     * Uses the given transaction context to store data back into the
     * database using the LOB-locator which should
     * be set before this method is invoked.
     */
   public void saveToDatabase( Transaction transaction, Object postedSQLObject )
      throws Exception
   {
      Object obj;
      Struct postedObj = (Struct)postedSQLObject;
      for ( int i = 0; i < getAttributeCount(); i++)
      {
         obj = getAttribute(i);
         if (obj instanceof LobInterface) 
         {
            ((LobInterface)obj).saveToDatabase(transaction, postedObj.getAttribute(i));
         }
      }
   }

   public void  prepareForDML( Object context )
   {
      Object obj;
      for ( int i = 0; i < getAttributeCount(); i++)
      {
         obj = getAttribute(i);
         if (obj instanceof LobInterface) 
         {
            ((LobInterface)obj).prepareForDML(context);
         }
      }
   }

   public void syncClientLob(LobInterface old)
   {
      if (old instanceof Struct)
      {
         Struct mt = (Struct)old;
         int count = mt.getAttributeCount();
         Object obj;
         for (int i = 0; i < count; i++)
         {
            obj = getAttribute(i);
            if (obj instanceof LobInterface)
            {
               //if existing Lob, sync it instead of replacing it.
               ((LobInterface)obj).syncClientLob((LobInterface)mt.getAttribute(i));
            }
            else
            {
               //if new object is a Lob, need to set it's context.
               setAttributeNoCheck(i, mt.getAttribute(i));
            }
         }
      }
   }

   public void syncServerLob(LobInterface old)
   {
      if (old instanceof Struct) 
      {
         Struct oldStruct = (Struct)old;
         int attrCount = getAttributeCount();
   
         Object obj;
         for (int j = 0; j < attrCount; j++)
         {
            obj = this.getAttribute(j);
            if (obj instanceof LobInterface)
            {
               ((LobInterface)obj).syncServerLob((LobInterface)oldStruct.getAttribute(j));
            }
         }
      }
   }

   public DomainOwnerInterface getOwner()
   {
      return mOwner;
   }

   public int getOwnerAttributeIndex()
   {
      return mOwnerAttrIndex;
   }
 
   protected DomainOwnerInterface getOwnerRow()
   {
      DomainOwnerInterface owner = mOwner;
      while (owner instanceof LobInterface) 
      {
         owner = ((LobInterface)owner).getOwner();
      }
      return (owner instanceof oracle.jbo.Row) ? owner : null;
   }
 

   public long getSize()
   {
      //throw unimplemented exception.
      throw new InvalidOperException(CSMessageBundle.class, 
                                 CSMessageBundle.EXC_INVALID_METHOD_CALL, 
                                 new Object[] {"TransPostEntityRow.writeXML"});
   }


   public static void setStructAttribute (AttributeList inAttrList, 
                                          StructureDef inStructDef,
                                          String fullAttrName,   
                                          Object value)
   {
      int index = fullAttrName.indexOf('.');
      try
      {
         if (index < 0) 
         {
            //set the new struct into it's owner.
            inAttrList.setAttribute(fullAttrName, value);
            return;
         }
            
         AttributeDef structAttrDef = inStructDef.findAttributeDef(fullAttrName.substring(0, index));
         int domainIndex = structAttrDef.getIndex();
         
         //this better be a domain.
         Struct structVal = (Struct)inAttrList.getAttribute(domainIndex);
         boolean newStruct;
         if ((newStruct = (structVal == null))) 
         {
            structVal = (Struct)structAttrDef.getJavaType().newInstance();
         }
         
         //recurse
         setStructAttribute(structVal, structVal.getStructureDef(), fullAttrName.substring(index+1), value);
         
         if (newStruct)
         {
            inAttrList.setAttribute(domainIndex, structVal);
         }
      }
      catch (JboException e)
      {
         throw e;
      }
      catch (Exception e)
      {
         throw new JboException (e);
      }
   }

   public static Object getStructAttribute (AttributeList inAttrList, 
                                            StructureDef inStructDef,
                                            String fullAttrName)
   {
      int index = fullAttrName.indexOf('.');
      try
      {
         if (index < 0) 
         {
            //set the new struct into it's owner.
            return inAttrList.getAttribute(fullAttrName);
         }
            
         AttributeDef structAttrDef = inStructDef.findAttributeDef(fullAttrName.substring(0, index));
         int domainIndex = structAttrDef.getIndex();
         
         //this better be a domain.
         Struct structVal = (Struct)inAttrList.getAttribute(domainIndex);
         boolean newStruct;
         if ((newStruct = (structVal == null))) 
         {
            structVal = (Struct)structAttrDef.getJavaType().newInstance();
         }
         
         //recurse
         return getStructAttribute(structVal, structVal.getStructureDef(), fullAttrName.substring(index+1));
         
      }
      catch (JboException e)
      {
         throw e;
      }
      catch (Exception e)
      {
         throw new JboException (e);
      }
   }

   public static void fillObjectAttributeDefs(AttributeList al, StructureDef def, String attrNames[], AttributeDef ads[])
   {
      String fullAttrName = attrNames[0];
      int index = fullAttrName.indexOf('.');
      int length = attrNames.length;
      if (index < 0) 
      {
         //get domain defs from this def.
         for (int i = 0; i < length; i++) 
         {
            ads[i] = def.findAttributeDef(attrNames[i]);
         }
         return;
      }
      AttributeDef structAttrDef = def.findAttributeDef(fullAttrName.substring(0, index));
      int domainIndex = structAttrDef.getIndex();
      
      //this better be a domain.
      try
      {
         Struct structVal = (Struct)al.getAttribute(domainIndex);
         boolean newStruct;
         if ((newStruct = (structVal == null))) 
         {
            structVal = (Struct)structAttrDef.getJavaType().newInstance();
         }
         
         String[] nextAttrNames = new String[length];
         index++;
         for (int i = 0; i < length; i++) 
         {
            nextAttrNames[i] = attrNames[i].substring(index);
         }  
         //recurse
         fillObjectAttributeDefs(structVal, structVal.getStructureDef(), nextAttrNames, ads);
      }
      catch (JboException je)
      {
         throw je;
      }
      catch (Exception e)
      {
         throw new JboException(e);
      }
      
   }

   public String[] getAttributeNames() 
   {
      return null;
   }
   
   public Object[] getAttributeValues()
   {
      return null;
   }

}
