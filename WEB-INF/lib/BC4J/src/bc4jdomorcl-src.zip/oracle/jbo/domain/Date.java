package oracle.jbo.domain;

//import java.util.Calendar;
//import java.util.GregorianCalendar;
import java.sql.Timestamp;
import java.sql.Time;
import oracle.sql.CustomDatum;
import oracle.sql.CustomDatumFactory;
import oracle.sql.Datum;
import oracle.sql.DATE;    
import oracle.sql.NUMBER;    
import java.sql.SQLException;
import java.io.IOException;
import java.io.Serializable;

import oracle.jbo.Transaction;

// ---------------------------------------------------
// ---    jbo generated file.
// ---    Business object: DateDomain
// ---------------------------------------------------

/**
* This class extends <tt>oracle.sql.DATE</tt>,
* Oracle's Java representation of the
* DATE database type. This class allows an instance of the
* <tt>oracle.sql.DATE</tt> to be used as an immutable domain object.
* <p>
* The intent of many of the methods in this class is to wrap the corresponding
* method in the <tt>oracle.sql</tt> class such that it returns an instance of an
* <tt>oracle.jbo.domain.*</tt> object.
* <p>
* The <tt>oracle.jbo.domain.Date</tt> class is the Java representation
* of the underlying
* database type that you must use if you want to exploit the domain feature of
* Business Components for Java.
* <p>
* <code>Date</code> objects consist of data (a byte array)
* and a Domain type code.
* Domain dates extend SQL dates by being convertable to and from
* JDBC values.
* <h3>Date/Time Formats Accepted</h3>
* The <tt>oracle.jbo.domain.Date</tt> class accepts dates and times in the
* same format accepted by <tt>java.sql.TimeStamp</tt> (either a long milliseconds time value
* or the year, month, day, hour,
* minute, second, nano format) and <tt>java.sql.Date</tt> (either a milliseconds time value
* or the year, month, day format).
* <h3>Converting Between Date Formats</h3>
* The following code snippet demonstrates one technique of converting
* from the date format expressed by <tt>oracle.jbo.domain.Date</tt> to another format.
* <p>
* <pre>
*   ...
*  Date convertedDate = new Date();
*  String convertedDateString;
*
*  java.text.SimpleDateFormat displayDateFormat = new java.text.SimpleDateFormat ("MM/dd/yyyy");
*  convertedDateString = displayDateFormat.format(convertedDate.dateValue());
* </pre>
* <p>
* <h3>Converting Between Date Classes</h3>
* The following code snippet demonstrates one technique of converting from an
* <tt>oracle.jbo.domain.Date</tt> data item to a <tt>java.util.Date</tt>
* data item:
* <p>
* <pre>
*  ...
*  oracle.jbo.domain.Date dt = row.getBirthDate();
*  java.sql.Date ts = (java.sql.Date) dt.dateValue();
*  // since java.sql.Date is a java.util.Date, then...
*  Calendar c = new Calendar(dt);
*  ...
* </pre>
* <p>
* @since JDeveloper 3.0
 * 
 * @javabean.class name=Date
*/
public class Date
             extends oracle.sql.DATE 
             implements DomainInterface, 
                        XMLDomainWriter,
                        KeyAttributeInterface,
                        CustomDatum,
                        Serializable 
{
  private static final long serialVersionUID = 5600076615126868258L;
  //private static GregorianCalendar mCal = new GregorianCalendar();

  static CustomDatumFactory fac = null;
  static
  {
     TypeFactory.addCustomConverter(oracle.jbo.domain.Date.class, java.lang.String.class, 
     new TypeConvMapEntry()
     {
         protected Object convert(Class toClass, Class valClass, Object val)
         {
             try
             {
                return new oracle.jbo.domain.Date((String)val);
             }
             catch (Exception e)
             {
                //check for null/ String and 0 length.
                if (val instanceof String && ((String)val).trim().length() == 0)
                {
                   return null;
                }
                throw new DataCreationException(toClass.getName(), val, e);
             }
          }
     }
     );

  }
  private int mHashCode = 0;

  /**
    * <b>Internal:</b> <em>Applications should not invoke this method.</em>
    * <p>Initializes the <code>Date</code> Domain.
    *
    * <p>This method is invoked when JBO is initialized.
    * Applications should not call this method directly.
    *
    * @return the <code>CustomDatumFactory</code> for the
    * <code>Date</code> Domain.
    */
  public static CustomDatumFactory getCustomDatumFactory()
  {
     if( fac == null )
     {
        class facClass implements DatumFactory
        {
            public Datum createDatum(java.sql.CallableStatement jdbc, int index)
               throws SQLException
            {
               byte[] data = jdbc.getBytes(index);
               return (data != null) ? new Date(data) : null;
            }
            
            public Datum createDatum(java.sql.ResultSet jdbc, int index)
               throws SQLException
            {
               byte[] data = jdbc.getBytes(index);
               return (data != null) ? new Date(data) : null;
            }
         
            public CustomDatum create(Datum d, int sql_type_code) throws SQLException
            {
               if (d != null)
               {
                  return new Date( d.getBytes());
               }
               return null;
            }
        };
        fac = new facClass();
     }
     return fac;
  }
  
  /**
    * <b>Internal:</b> <em>Applications should not invoke this method.</em>
    * <p>Converts this <code>Date</code> Domain object back into an
    * SQL <code>DATE</code> object.
    *
    * @param <code>conn</code> Not used.
    * @return A <code>Datum</code> containing <code>DATE</code> object.
    * @throws <code>SQLException</code> Never.
    */
  public Datum toDatum(oracle.jdbc.driver.OracleConnection conn) throws SQLException
  {
     return new DATE(getBytes());
  }
  
  /**
    * Creates a default <code>Date</code> Domain object.
    *
    * <p>This constructor does not create a null date:
    * use one of the <code>NullValue()</code> constructors.
    */
  public Date() {
     super();
  }

  /**
    * <b>Internal:</b> <em>Applications should not invoke this method.</em>
    * <p>Creates a <code>Date</code> Domain object from the given byte array.
    *
    * @param value a value returned by a previous call to
    * <code>getBytes()</code> on an SQL object compatable with
    * <code>Date</code>.
    */
  public Date(byte[] value) {
     super(value);
  }             

  /**
    * Creates a <code>Date</code> Domain object from an Oracle SQL
    * <code>DATE</code>.
    *
    * @param value a <code>DATE</code> SQL object.
     */
  public Date(DATE value) {
     super(value.getBytes());
  }             

  /**
    * Creates a <code>Date</code> identical to an
    * existing <code>Date</code>.
    *
    * @param value a <code>Date</code> Domain object.
    */
  public Date(Date value) {
     super(value.getBytes());
  }

  /**
    * Creates a <code>Date</code> Domain object from a JDBC
    * <code>Date</code>.
    *
    * @param value a <code>DATE</code> SQL object.
     */
  public Date(java.sql.Date value) {
     super(value);
  }             

  /**
    * Creates a <code>Date</code> Domain object from a JDBC
    * <code>Time</code> object.
    *
    * @param value a <code>Time</code> SQL object.
     */
  public Date(Time value) {
     super(value);
  }             

  /**
    * Creates a <code>Date</code> Domain object from a JDBC
    * <code>Timestamp</code> object.
    *
    * @param value a <code>TimeStamp</code> SQL object.
     */
  public Date(Timestamp value) {
     super(value);
  }             

  /**
    * Creates a <code>Date</code> Domain object from a
    * JDBC <code>Object</code>.
    *
    * @param   value   an <code>Object</code> that is an instance of
    * <code>Date</code>,
    * <code>Time</code>, <code>Timestamp</code>, or
    * <code>String</code>.
    * @throws  SQLException if the object is not of one of the recognized classes.
    */
  public Date(Object value) throws SQLException {
     if (value instanceof String)
     {
        setBytes(toDate((String)value).getBytes());
     }
     else
     {
        setBytes((new DATE(value)).getBytes());
     }
  }             
  
  /**
    * Creates a <code>Date</code> Domain object from a
    * Java <code>String</code>.
    *
    * @param   value   a textual representation of a <code>Date</code>.
    */
  public Date(String value) {
     setBytes(toDate(value).toBytes());
          
  }             

  public static final java.sql.Time ZERO_TIME = new java.sql.Time(0, 0, 0);
  
  /**
     * <b>Internal:</b> <em>Applications should not invoke this method.</em>
    *
    * @value The JDBC representation of <code>this</code>,
    */
  public Object getData() {
    // Timestamp ts = (Timestamp) timestampValue();
    byte[] dataBytes = getBytes();
    
    if (toTime(dataBytes).equals(ZERO_TIME))
    // if (ts.getNanos() == 0 && (ts.getTime() % NUM_MILLIS_IN_ONE_DAY) == 0)
    //mCal.setTime(ts);

    //if( mCal.get(Calendar.HOUR_OF_DAY) == 0 && mCal.get(Calendar.MINUTE) == 0
    //    && mCal.get(Calendar.SECOND) == 0 && ts.getNanos() == 0 )
    {
       return toDate(dataBytes);
    }
    return toTimestamp(dataBytes);
  }
   /**
   * <b>Internal:</b> <em>Applications should not invoke this method.</em>
   */
  public void setContext(DomainOwnerInterface owner, Transaction trans, Object ctx) {
  }

   /**
   * Converts an Oracle Date expressed as a string to a Java Date. The Java
   * date can be either an <tt>java.sql.Timestamp</tt> or an <tt>java.sql.Date</tt>.
   * @return returns a <tt>java.sql.Date</tt> object.
   */
  public static Date toDate(String value)
  {
     DATE dt;
     value = value.trim();
     try
     {
        //this would try timestamp format.
        dt = new DATE(value);
     }
     catch(Exception e)
     {
        java.sql.Date javaObj = java.sql.Date.valueOf(value);
        dt = new DATE(javaObj);
     }

     return new Date(dt);
  }

  /**
    * For testing purposes only: converts <code>this</code> to a textual
    * representation.
    */
  public String toString() {
     Object ts = getData();
     if( ts != null  )
     {
        return ts.toString();
     }
     return null;
  }

  /**
    * Tests <code>this</code> for equality with another object.
    *
    * The argument is converted to a <code>Date</code> object, if necessary.
    *
    * @param other  an arbitrary <code>Object</code>.
    * @return <code>true</code> if conversion was successful and the converted
    * argument is identical to <code>this</code>.
    */
  public boolean equals(Object other) {
     if (other == null)
     {
        return false;
     }

     if (!other.getClass().equals(getClass()))
     {
        try
        {
           Date charOther =  new Date(other);
           return super.equals(charOther);
        }
        catch( Exception sqle )
        {
           //for any exception simply return false from equals.
           return false;
        }
     }
     return super.equals(other);
  }

  /*
  public boolean equals( Object obj )
  {
     if( obj instanceof Date )
     {
        return (compareTo((DATE)obj) == 0);
     }
     return false;
  }
  */

  /**
    * Computes a hash code for <code>this</code>.
    *
    * @return the hash code of <code>this</code>.
    */
   public int hashCode()
   {
      if (mHashCode == 0)
      {
         mHashCode = getData().hashCode();
         if (mHashCode == 0)
         {
            mHashCode = -6855;
         }
      }
      return mHashCode;
   }

  private void writeObject(java.io.ObjectOutputStream out)
    throws IOException
  {
     byte[] bytes = getBytes();
     out.writeInt(bytes.length);
     out.write(bytes);
  }

  private void readObject(java.io.ObjectInputStream in)
    throws IOException, ClassNotFoundException
  {
     int size = in.readInt();
     byte[] bytes = new byte[size];
     in.read(bytes);
     setBytes(bytes);
  }

  /**
  * Adds the number of Julian days to a DateDomain. Returns a
  * new <code>Date</code> Domain object initalized to the DATE
  * values added to the Julian days.
  * @param julianDay number of Julian days to add to Date.
  * @param julianSec number of seconds past midnight.
  * @return a new <code>Date</code> Domain object.
  * @throws oracle.jbo.domain.GenericDomainException
  **/
  public DATE addJulianDays(int julianDay, int julianSec) {
     try
     {
        return new Date(super.addJulianDays(julianDay, julianSec));
     }
     catch (SQLException sqle)
     {
        throw new GenericDomainException("Date.addJulianDays", this, sqle);
     }
  }

  /**
  * Adds months to a date. Overrides the <tt>oracle.sql.DATE</tt> method of the same name to return a
  * <code>Date</code> Domain object.
  * @paarm months integer number of months to add to date
  * @return new Date object initialized to the Date value added to months.
  * Months can be negative to perform month subtraction.
  * @see "oracle.sql.DATE"
  **/
  public DATE addMonths(int months) {
     try
     {
        return new Date(super.addMonths(months));
     }
     catch (SQLException sqle)
     {
        throw new GenericDomainException("Date.addMonths", this, sqle);
     }
  }

  /**
  * Calculates the difference between two dates in months.
  * Overrides the <tt>oracle.sql.DATE</tt> method of the same name to return a
  * <code>Date</code> Domain object.
  * @param date Date to be subtracted as a DateDomain.
  * @return Number difference in months.
  * @see "oracle.sql.DATE"
  **/
  public Number diffInMonths(Date date) {
     try
     {
        return new Number(super.diffInMonths(date));
     }
     catch (SQLException sqle)
     {
        throw new GenericDomainException("Date.diffInMonths", this, sqle);
     }
  }

   /**
  * Calculates the difference between two dates in months.
  * Overrides the <tt>oracle.sql.DATE</tt> method of the same name to return a
  * <code>Date</code> Domain object.
  * @param date Date to be subtracted, as an oracle.sql.DATE.
  * @return Number difference in months.
  * @see "oracle.sql.DATE"
  */
  public NUMBER diffInMonths(DATE date) {
     return diffInMonths(new Date(date));
  }

  /**
  * Gets current date and time. Overrides the <tt>oracle.sql.DATE</tt> method of the same name to return a
  * <code>Date</code> Domain object.
  * @return a Date object
  * @see "oracle.sql.DATE"
  **/
  public static DATE getCurrentDate() {
     // try
     // {
        return new Date(new java.sql.Date(System.currentTimeMillis()));
     // }
     // catch (SQLException sqle)
     // {
     //    throw new GenericDomainException("Date.getCurrentDate", null, sqle);
     // }
  }

  /**
  * Converts given Julian days and seconds to a date.
  * Overrides the <tt>oracle.sql.DATE</tt> method of the same name to return a
  * <code>Date</code> Domain object.
  * @param julianDay Number of Julian days
  * @param julianSec Number of seconds past midnight
  * @return new Date Domain object initialized based on the number of Julian days.
  * @throws oracle.jbo.domain.GenericDomainException
  * @see "oracle.sql.DATE"
  **/
  public static DATE fromJulianDays(int julianDay, int julianSec) {
     try
     {
        return new Date(DATE.fromJulianDays(julianDay, julianSec));
     }
     catch (SQLException sqle)
     {
        throw new GenericDomainException("Date.fromJulianDays", null, sqle);
     }
  }

  /**
  * Converts a formatted string to a date.
  * Overrides the <tt>oracle.sql.DATE</tt> method of the same name to return a
  * <code>Date</code> Domain object.
  * param datestr text to convert
  * @param fmt format
  * @param lang the NLS language the conversion is to be performed in,
  * null indicates use default.
  * @throws oracle.jbo.domain.GenericDomainException
  * @see "oracle.sql.DATE"
  **/
  public static DATE fromText(String datestr, String fmt, String lang ) {
     try
     {
        return new Date(DATE.fromText(datestr, fmt, lang));
     }
     catch (SQLException sqle)
     {
        throw new GenericDomainException("Date.fromText", datestr, sqle);
     }
  }

  /**
  * Returns a date intialized to the last day of the month.
  * Overrides the <tt>oracle.sql.DATE</tt> method of the same name to return a
  * <code>Date</code> Domain object.
  * @throws oracle.jbo.domain.GenericDomainException
  * @see "oracle.sql.DATE"
  **/
  public DATE lastDayOfMonth() {
     try
     {
        return new Date(super.lastDayOfMonth());
     }
     catch (SQLException sqle)
     {
        throw new GenericDomainException("Date.lastDayOfMonth", this, sqle);
     }
  }

  /**
  * Returns a date rounded to a specified precision.
  * Overrides the <tt>oracle.sql.DATE</tt> method of the same name to return a
  * <code>Date</code> Domain object.
  * @param prec  precision to use while rounding
  * @throws oracle.jbo.domain.GenericDomainException
  * @see "oracle.sql.DATE"
  **/
  public DATE round(String prec) {
     try
     {
        return new Date(super.round(prec));
     }
     catch (SQLException sqle)
     {
        throw new GenericDomainException("Date.round", this, sqle);
     }
  }

  /**
  * Returns a date initialized to a date advanced to the week of the day
  * specified.
  * Overrides the <tt>oracle.sql.DATE</tt> method of the same name to return a
  * <code>Date</code> Domain object.
  * @param day  day of the week the date needs to be advanced
  * @throws oracle.jbo.domain.GenericDomainException
  * @see "oracle.sql.DATE"
  **/
  public DATE setDayOfWeek(int day) {
     try
     {
        return new Date(super.setDayOfWeek(day));
     }
     catch (SQLException sqle)
     {
        throw new GenericDomainException("Date.setDayOfWeek", this, sqle);
     }
  }                 

  /**
  * Converts this date to an <tt>oracle.sql.NUMBER</tt>.
  * @return a <code>Date</code> Domain object.
  * @throws oracle.jbo.domain.GenericDomainException
  **/
  public NUMBER toNumber() {
     try
     {
        return new Number(super.toNumber());
     }
     catch (SQLException sqle)
     {
        throw new GenericDomainException("Date.toNumber", this, sqle);
     }
  }

  /**
  * Returns a date truncated to a specified precision.
  * @param prec precision to use while truncating
  * @return a <code>Date</code> Domain object.
  * @throws oracle.jbo.domain.GenericDomainException
  **/
  public DATE truncate(String prec) {
     try
     {
        return new Date(super.truncate(prec));
     }
     catch (SQLException sqle)
     {
        throw new GenericDomainException("Date.truncate", this, sqle);
     }
  }


   /**
   * Prints the DTD info for this domain in the given print writer.
   * Returns the DTD string to be added to this domain's container
   * entity/domain.
   * <p> The <tt>allDefs</tt> hashtable contains predefined XML definitions and
   * is passed by whatever calls this method.
   * <p>
   * @param allDefs a hashtable of predefined XML definitions passed from whatever
   * calls this method.
   * @param pw print writer into which the defnition is being printed.
   * @param bContainees if <tt>true</tt>, prints definitions of contained objects.
   **/
   public String printXMLDefinition(java.util.Hashtable allDefs, java.io.PrintWriter pw, 
                             boolean bContainees)
   {
      return "#PCDATA";
   }

  /**
  * Creates the xml node in the given xml document for this domain's data.
  * @param xmlDoc name of the XML document in which the node should be created.
  **/
  public org.w3c.dom.Node getXMLContentNode(org.w3c.dom.Document xmlDoc)
  {
     return xmlDoc.createTextNode(toString());
  }

  /**
  * Creates the xml node in the given xml document for this domain's data in hex format of the byte[]
  * representation of the data.
  * @param xmlDoc name of the XML document in which the node should be created.
  **/
  public org.w3c.dom.Node getSerializedDomainXML(org.w3c.dom.Document xmlDoc)
  {
     //for now render as String. If we find that this leads to NLS issues, we should
     //revert back to the RepConversion solution.
     return xmlDoc.createTextNode(toString());
     //return xmlDoc.createTextNode(oracle.jbo.common.RepConversion.bArray2String(getBytes()));
  }

   /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   */
   public static XMLDomainReaderFactory getXMLDomainFactory(Class attrClass) 
   {
      class facClass implements XMLDomainReaderFactory, XMLDomainFactory
      {
         public DomainInterface createDomainFromXMLElement(org.w3c.dom.Element attrElem)
         {
            try
            {
               org.w3c.dom.Node valNode = (org.w3c.dom.Node)attrElem.getFirstChild();
               if( valNode != null)
               {
                  String attrValue = valNode.getNodeValue();
                  if (attrValue != null)
                  {
                     //get the properly typed-attribute value 
                     return new Date(attrValue);
                  }
               }
            }
            catch (oracle.jbo.JboException e)
            {
               throw e;
            }
            catch (Exception e)
            {
               //throw new jbo exception here.
               throw new oracle.jbo.JboException(e);
            }
            return null;
         }
         
         public Object createDomainFromSerializedXML(org.w3c.dom.Element attrElem)
         {
            try
            {
               org.w3c.dom.Node valNode = (org.w3c.dom.Node)attrElem.getFirstChild();
               if( valNode != null)
               {
                  String attrValue = valNode.getNodeValue();
                  if (attrValue != null)
                  {
                     //for now render as String. If we find that this leads to NLS issues, we should
                     //revert back to the RepConversion solution.
                     //return new Date(oracle.jbo.common.RepConversion.convertHexStringToByte(attrValue));
                     return new Date(attrValue);
                  }
               }
            }
            catch (oracle.jbo.JboException e)
            {
               throw e;
            }
            catch (Exception e)
            {
               //throw new jbo exception here.
               throw new oracle.jbo.JboException(e);
            }
            return null;
         }
      }
      
      return new facClass();
   }

  
  //------------------------------------------------------------------------
  //
  // Test Methods
  //
  //------------------------------------------------------------------------

   /**
    * <b>Internal:</b> <em>Applications should not invoke this method.</em>
    */
  public static void main(
    String[]       argv
    )
    throws SQLException
  {
    System.out.println("Date Test BEGIN");

    Date dt = new Date();

    try
    {
       //testing some of the overriddenmethods to see if the correct
       //object instance is returned.
       System.out.println(dt);
       Date curDate = (Date)Date.getCurrentDate();
       if (dt.addMonths(2) instanceof Date) {
          System.out.println("Date: addMonths() = "+dt.addMonths(2));
       }
       if (dt.lastDayOfMonth() instanceof Date) {
          System.out.println("Date: lastDayOfMonth() = "+dt.lastDayOfMonth());
       }
       if (dt.setDayOfWeek(4) instanceof Date) {
          System.out.println("Date: setDayOfWeek() = "+dt.setDayOfWeek(4));
       }
       if (dt.toNumber() instanceof Number)
       {
          System.out.println("Date: toNumber() = "+dt.toNumber());
       }

    }
    catch (Exception sqle)
    {
       sqle.printStackTrace();
    }

  }
}



 
