
package oracle.jbo.domain;


import java.io.Serializable;
import java.lang.reflect.Method;
import java.lang.reflect.InvocationTargetException;

import oracle.jbo.JboException;
import oracle.jbo.Transaction;
import oracle.jbo.ApplicationModule;

import com.sun.java.util.collections.HashMap; 
import oracle.sql.CustomDatumFactory;
import oracle.sql.Datum;
import java.sql.SQLException;
import oracle.jbo.domain.Number;
import java.math.BigDecimal;
import java.math.BigInteger;

/**
 * A lightweight, tier-independent wrapper that allows working with
 * attributes that should get their number values from database sequence
 * on insert of a new row.
 * <p>
 * If you designated an Entity Object attribute to be of type
 * <tt>DBSequence</tt>, the framework assumes that the attribute value
 * will be refreshed when that Entity Object is posted to the database
 * This implementation assumes that there is an insert-trigger on the
 * table corresponding to the Entity Object, that populates the 
 * corresponding column value with a number when the Entity is
 * inserted into the database.
 * <p>
 * At runtime when a new Entity instance is created, this domain automatically
 * fills in a temporary negative value as a place-holder for the attribute
 * that is marked to be of DBSequence type. When the new Entity is posted,
 * this value is updated from the database.
 * <p>
 * @see oracle.jbo.server.EntityImpl
 * @since JDeveloper 3.2.3
 */
public class DBSequence implements /*CustomDatum,*/ DomainInterface, Serializable, KeyAttributeInterface
{
   public static final String AM_IMPL_CLIENT = "oracle.jbo.client.remote.ApplicationModuleImpl";

   Long mVal = null;
   String mValString;
   private boolean mSeed = false;
   private static long NEXT_SEQ = 0;

   static CustomDatumFactory fac = null;
   /**
    * <b>Internal:</b> <em>Applications should not invoke this method.</em>
    * <p>Initializes the <code>Number</code> Domain.
    *
    * This method is invoked when JBO is initialized.
    *
    * @return the <code>CustomDatumFactory</code> for the
    * <code>Number</code> Domain.
    */
   public static CustomDatumFactory getCustomDatumFactory()
   {
     return null;
   }
   
   /**
   * <b>Internal:</b> <em>Applications should not use this constructor.</em>
   */
   public DBSequence()
   {
   }

   /**
    * Create an instance of DBSequence with the given number as it's value.
    **/
   public DBSequence(BigInteger num)
   {
      //called usually from fk population logic where one is simply interesed
      //in copying the existing sequence value and not create a new one.
      if (num != null) 
      {
         mVal = new Long(num.longValue());
      }
      else
      {
         throw new JboException("Illegal sequence copy attempted!");
      }
   }

   /**
    * Create an instance of DBSequence with the given number as it's value.
    **/
   public DBSequence(BigDecimal num)
   {
      //called usually from fk population logic where one is simply interesed
      //in copying the existing sequence value and not create a new one.
      if (num != null) 
      {
         mVal = new Long(num.longValue());
      }
      else
      {
         throw new JboException("Illegal sequence copy attempted!");
      }
   }
   
   /**
    * Create an instance of DBSequence with the given number as it's value.
    **/
   public DBSequence(Long num)
   {
      //called usually from fk population logic where one is simply interesed
      //in copying the existing sequence value and not create a new one.
      if (num != null) 
      {
         mVal = num;
      }
      else
      {
         throw new JboException("Illegal sequence copy attempted!");
      }
   }

   /**
    * Create an instance of DBSequence with the given number as it's value.
    **/
   public DBSequence(Integer num)
   {
      //called usually from fk population logic where one is simply interesed
      //in copying the existing sequence value and not create a new one.
      if (num != null) 
      {
         mVal = new Long(num.longValue());
      }
      else
      {
         throw new JboException("Illegal sequence copy attempted!");
      }
   }

   /**
    * Create an instance of DBSequence with the given number as it's value.
    **/
   public DBSequence(oracle.jbo.domain.Number num)
   {
      //called usually from fk population logic where one is simply interesed
      //in copying the existing sequence value and not create a new one.
      if (num != null) 
      {
         mVal = new Long(num.longValue());
      }
      else
      {
         throw new JboException("Illegal sequence copy attempted!");
      }
   }

   /**
   * <b>Internal:</b> <em>Applications should not invoke this method.</em>
   */
   public DBSequence(DBSequence seq)
   {
      //called usually from fk population logic where one is simply interesed
      //in copying the existing sequence value and not create a new one.
      if (seq != null) 
      {
         if (seq.mValString != null) 
         {
            //this was created for a new row.
            if (seq.mSeed == true) 
            {
               //called to insert a new row from a seed sequence value.
               mVal = nextVal();
               mValString = mVal.toString();
            }
            else
            {
               //called from fk population.
               mVal = seq.mVal;
               mValString = seq.mValString;
            }
         }
         else
         {
            mVal = seq.mVal;
         }
      }
      else
      {
         throw new JboException("Illegal sequence copy attempted!");
      }
   }

   /**
    * <b>Internal:</b> <em>Applications should not invoke this method.</em>
    * <p>
    * Called from AttributeDef for default values only.
   */
   public DBSequence(String numberString)
   {

      if (numberString != null)
      {
         numberString = numberString.trim();
         if (numberString.length() > 0)
         {
            //if @ then, it's coming from attribute def, default value.
            if (numberString.indexOf("@") == 0) 
            {
               mSeed = true;
               numberString = numberString.substring(1);
            }
            try
            {
               Long val = new Long(numberString);
               if (val.intValue() < NEXT_SEQ) 
               {
                  //use up the next number
                  val = nextVal();
               }
               else
               {
                  //given value is larger than the next sequence so, set the
                  //next sequence to one larger than the given value.
                  NEXT_SEQ = val.longValue()+1;
               }
               mValString = val.toString();
               mVal = val;
               return;
            }
            catch (Exception e)
            {
               //ignore.
            }
         }
      }
   }

   /**
    * Uses the given sequence name to get a Sequence value that is stored
    * for the value of this DBSequence instance
    * <p>
    * This method will increment the specified database sequence when it is
    * invoked.
    *
    * @param seqName The name of the database sequence that will be used to
    *    generate sequence values.
    *
    * @param am The application module instance that will provide the JDBC
    *    connection and the marshalling context for the sequence requests.
    */
   public DBSequence(String seqName, ApplicationModule am)
   {
      if (seqName != null && am != null) 
      {
         mVal = (Long) (new Sequence(seqName, am)).getData();
      }
   }
   
   /**
    * <b>Internal:</b> <em>Applications should not invoke this method.</em>
    * @return The value that this sequence object represents
    */
   public Object getData()
   {
      //if new sequence required pass in number of value 0 assuming
      //that insert trigger will update the number anyway.
      if (mValString == null) 
      {
         return mVal;
      }
      return null;
   }

  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   */
   public void setContext(DomainOwnerInterface owner, Transaction trans, Object ctx)
   {
      if (mVal == null)
      {
         if (((HashMap)ctx).get(DomainContext.CLIENT_DOMAIN) != null)
         {
            //client - called when a new seq is set into an attribute.
            // mVal = (Long) ((oracle.jbo.client.remote.ApplicationModuleImpl) trans)
            //                                          .getDomainValue("oracle.jbo.domain.DBSequence",
            //                                                     new String[] {},
            //                                                     new Object[] {});
            try
            {
               String[] strArr = new String[0];
               Object[] objArr = new Object[0];
               Class implCls = Class.forName(AM_IMPL_CLIENT);
               Method getDomainValueMethod = implCls.getMethod("getDomainValue",
                                                               new Class[] { String.class,
                                                                             strArr.getClass(),
                                                                             objArr.getClass() });

               mVal = (Long) getDomainValueMethod.invoke(trans,
                                                         new Object[] { "oracle.jbo.domain.DBSequence",
                                                                        strArr, objArr });
            }
            catch(Exception ex)
            {
               Throwable th = ex;

               if (th instanceof InvocationTargetException)
               {
                  th = ((InvocationTargetException) th).getTargetException();
               }
    
               if (th instanceof JboException)
               {
                  throw (JboException) th;
               }

               throw new JboException(th);
            }
         }
         else
         {
            while (owner instanceof LobInterface) 
            {
               owner = ((LobInterface)owner).getOwner();
            }
            if (owner instanceof oracle.jbo.Row) 
            {
               if (mVal == null) 
               {
                  //so that domains get populated for default 0 values.
                  mVal = nextVal();
                  mValString = mVal.toString();
               }
               if (((oracle.jbo.server.EntityImpl)owner).getPostState() != oracle.jbo.server.EntityImpl.STATUS_NEW) 
               {
                  mValString = null;
               }
            }
            //mVal = nextVal();
         }
      }
   }


   /**
   * Returns the value of this Sequence as an oracle.jbo.domain.Number
   **/
   public Number getSequenceNumber()
   {
      try
      {
         return new Number(mVal);
      }
      catch (JboException jboe)
      {
         throw jboe;
      }
      catch (Exception e)
      {
         throw new JboException(e);
      }
   }
   
   /**
    * For testing purposes only: Returns a string representation of the
    * generated sequence value.
    */
   public String toString()
   {
      if (mVal != null) 
      {
         return mVal.toString();
      }
      return "";
   }

   /**
    * Test if the specified value is equal to <code>this</code> Sequence
    * object.
    *
    * @param other The object to which the Sequence should be compared.
    *
    * @return true The specified object is equal to the <code>this</code>
    *    Sequence.
    */
   public boolean equals(Object other)
   {
      if (other instanceof DBSequence) 
      {
         DBSequence otherSeq = (DBSequence)other;
         if (mVal != null) 
         {
            return mVal.equals(otherSeq.mVal);
         }
         if (mValString != null) 
         {
            return (mValString.equals(otherSeq.mValString));
            //otherwise check number if they're equal too!
         }
      }
      else if (other instanceof java.lang.Number) 
      {
         return (mVal.longValue() == (((java.lang.Number)other).longValue()));
      }
      else if (other instanceof oracle.sql.NUMBER) 
      {
         try
         {
            return (mVal.longValue() == (((oracle.sql.NUMBER)other).longValue()));
         }
         catch (Exception e)
         {
            oracle.jbo.common.Diagnostic.printStackTrace(e);
         }
      }
         

      return false;
   }

  /**
    * Computes a hash code for <code>this</code> Sequence object.
    *
    * @return the hash code of <code>this</code> Sequence object.
    */
   public int hashCode()
   {
      if (mVal != null) 
      {
         return mVal.hashCode();
      }
      return -1;
   }


   private void writeObject(java.io.ObjectOutputStream out)
      throws java.io.IOException
   {
      if (mVal != null) 
      {
         out.writeShort(1);
         out.writeLong(((Long) mVal).longValue());
      }
      else
      {
         out.writeShort(0);
      }
   }


   private void readObject(java.io.ObjectInputStream in)
      throws java.io.IOException, ClassNotFoundException
   {
      if (in.readShort() == 1) 
      {
         mVal = new Long(in.readLong());
      }
   }
   
   /**
    * A class method that may be invoked to retrieve the next value from a
    * database sequence.
    *
    * @param seqName The name of the database sequence that will be used to
    *    generate the sequence value.
    *
    * @param am The application module instance that will provide the JDBC
    *    connection for the sequence request
    *
    * @deprecated since 9.0.3. Use new instance of this class
    * to get the next value.
    */
   public static Long createInstanceWithAM(ApplicationModule am)
   {
      return nextVal();
   }


   static synchronized Long nextVal()
   {
      return new Long(-1 * NEXT_SEQ++);
   }
   /**
     * <b>Internal:</b> <em>Applications should not invoke this method.</em>
     * <p>Converts this <code>Number</code> Domain object back into an
     * SQL <code>NUMBER</code> object.
     *
     * @param <code>conn</code> Not used.
     * @return A <code>Datum</code> containing <code>NUMBER</code> object.
     * @throws <code>SQLException</code> Never.
     */
   public Datum toDatum(oracle.jdbc.driver.OracleConnection conn) throws SQLException
   {
      //if new sequence required pass in number of value 0 assuming
      //that insert trigger will update the number anyway.
      if (mValString == null) 
      {
         if (mVal != null) 
         {
            return new oracle.sql.NUMBER(mVal);
         }
      }

      //even though this doesn't work right now lets keep null here.
      //return new oracle.sql.NUMBER(-1);
      return null;
   }

   /**
    * <b>Internal:</b> <em>Applications should not invoke this method.</em>
    * Converts this domain value into a bytes, so that the oracle.jbo.Key object
    * can render this domain into a short string form.
    * 
    * @return a byte array representing this object
    */
   public byte[] getBytes()
   {
      if (mVal != null) 
      {
         return mVal.toString().getBytes();
      }
      return new byte[0];
   }
 
   /**
   * Passes in the bytes that represent the value of this object.
   * This method is to be used by the oracle.jbo.Key object to pass in
   * key value read from a stream in byte array format.
   **/
   public void setBytes(byte[] bArr)
   {
      if (bArr != null) 
      {
         if (bArr.length == 0) 
         {
            mVal = null;
         }
         else
         {
            try
            {
               mVal = new Long(new String(bArr));
            }
            catch (NumberFormatException e)
            {
               throw new JboException(e);
            }
         }
      }
   }

   /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   */
   public static XMLDomainFactory getXMLDomainFactory(Class attrClass) 
   {
      class facClass implements XMLDomainFactory 
      {
         Class mAttrClass;
         facClass(Class clas)
         {
            mAttrClass = clas;
         }

         public DomainInterface createDomainFromXMLElement(org.w3c.dom.Element node)
         {
            try
            {
               DBSequence s = (DBSequence)mAttrClass.newInstance();
               s.mVal = new Long(node.getFirstChild().getNodeValue());
               return s;
            }
            catch (Exception e)
            {
               //throw new jbo exception here.
               throw new oracle.jbo.JboException(e);
            }
         }
      }
      
      return new facClass(attrClass);
   }

}
