package oracle.jbo.domain;

import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Reader;
import java.io.Writer;
import java.io.CharArrayWriter;
import java.io.CharArrayReader;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
// import oracle.jbo.server.DBTransactionImpl;
import oracle.jbo.Transaction;
import oracle.jbo.CSMessageBundle;
import oracle.jbo.common.Diagnostic;
import oracle.jbo.JboException;
import oracle.svcmsg.ResponseValues;

import oracle.jbo.common.SvcMsgResponseValues;

// Oracle Specific JDBC classes: 
import oracle.sql.CLOB;
import oracle.sql.Datum;
import oracle.jdbc.driver.OracleConnection;

// Core JDBC classes: 
import java.sql.SQLException;

import java.lang.reflect.Method;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;


// ---------------------------------------------------
// ---    jbo generated file.
// ---    Business object: ClobDomain
// ---------------------------------------------------

/**
* This class provides a lightweight wrapper for <tt>oracle.sql.Clob</tt>,
* the Java representation of the
* CLOB database type. This wrapper allows an instance of the
* <tt>oracle.sql.Clob</tt> to be used as a domain object.
*
* @since JDeveloper 3.0
*/
public class ClobDomain extends BaseLobDomain implements 
LobStreamInterface, 
java.io.Serializable
{

  private static final long serialVersionUID = 4019326676362184304L;

  transient private CLOB mylob = null;

  transient ClobWriter mcData;
  transient Reader inReader;
  transient Writer outWriter;

  /**
  * Constructor for this class.
  **/
  public ClobDomain() {}

  /**
  * Constructs an instance of this class, given a string.
  * @param a string to be used for a ClobDomain.
  **/
  public ClobDomain(String str)
  {
    setChars((str != null) ? str.toCharArray() : new char[0]);
  }

  /**
   * Constructs an instance of this class, given a byte array.
   * @param a byte array to be used for a ClobDomain.
   * 
   * @deprecated since 9.0.3.5. Use ClobDomain(char[] data) Constructor instead.
   **/
  public ClobDomain(byte[] data)
  {
    if (data != null)
    {
      setChars(new String(data).toCharArray());
    }
  }

  /**
   * Constructs an instance of this class, given a char array.
   * @param a char array to be used for a ClobDomain.
   **/
  public ClobDomain(char[] data)
  {
    if (data != null)
    {
      setChars(data);
    }
  }
  /**
   * Constructs an instance of this class, given a CLOB object.
   * @param a CLOB to be used for a ClobDomain.
   **/
  public ClobDomain(CLOB clob)
  {
    super(clob);
    mylob = clob;
  }

  /**
  * <b>Internal:</b> <em>Applications should not use this constructor.</em>
  * <p>
  * Creates an instance of this class with data as described in
  * <code>clobData</code>
  * and using the transaction context from <code>clob</code> to use the
  * CLOB locator
  * in the database.
  * <p>
  * @param clob name of the CLOB to use as a ClobDomain.
  * @param clobData data to fill the CLOB.
  * 
  * @deprecated since 9.0.3.5. Use ClobDomain(CLOB clob, char[] clobData) 
  * Constructor instead.
  **/
  public ClobDomain(CLOB clob, byte[] clobData) 
  {
    syncLob(clob);
    if (clobData != null)
    {
      setChars(new String(clobData).toCharArray());
    }
  }

  /**
  * <b>Internal:</b> <em>Applications should not use this constructor.</em>
  * <p>
  * Creates an instance of this class with char data as described in
  * <code>clobData</code>
  * and using the transaction context from <code>clob</code> to use the
  * CLOB locator
  * in the database.
  * <p>
  * @param clob name of the CLOB to use as a ClobDomain.
  * @param clobData data to fill the CLOB.
  **/
  public ClobDomain(CLOB clob, char[] clobData) 
  {
    syncLob(clob);
    if (clobData != null)
    {
      setChars(clobData);
    }
  }

  /**
  * Creates an instance of this class with data as described in <code>clobData</code>
  * and using the transaction context from <code>clob</code> to use the clob-locator
  * in the database.
  * <p>This constructor should be used by applications using the framework to create
  * ClobDomain objects.
  * <p>
  * @param clob name of the CLOB to use as a ClobDomain.
  * @param clobData data to fill the CLOB.
  * 
  * @deprecated since 9.0.3.5. Use ClobDomain(ClobDomain clob, char[] clobData) 
  * Constructor instead.
  **/
  public ClobDomain(ClobDomain nclob, byte[] clobData) 
  {
    super(nclob, clobData);
    try
    {
      if (nclob.lob != null)
      {
        syncLob(new CLOB((oracle.jdbc.driver.OracleConnection)nclob.mylob.getConnection()));
      }
    }
    catch (SQLException sqle)
    {
      throw new JboException(sqle);
    }
  }

  /**
  * Creates an instance of this class with data as described in <code>clobData</code>
  * and using the transaction context from <code>clob</code> to use the clob-locator
  * in the database.
  * <p>This constructor should be used by applications using the framework to create
  * ClobDomain objects.
  * <p>
  * @param clob name of the CLOB to use as a ClobDomain.
  * @param clobData data to fill the CLOB.
  **/
  public ClobDomain(ClobDomain nclob, char[] clobData) 
  {
    // super(nclob, clobData);
    mClient = nclob.mClient;
    if (clobData != null)
    {
      setChars(clobData);
    }
    try
    {
      if (nclob.lob != null)
      {
        syncLob(new CLOB((oracle.jdbc.driver.OracleConnection)nclob.mylob.getConnection()));
      }
    }
    catch (SQLException sqle)
    {
      throw new JboException(sqle);
    }
  }

  public ClobDomain(ResponseValues respVals)
  {
    // super(respVals);
    boolean hasData = respVals.getBooleanValues()[0];
    boolean dataModified = respVals.getBooleanValues()[1];
    boolean needsServerSync = respVals.getBooleanValues()[2];
    String className = (String) respVals.getObjectValues()[0];
    char[] bytes = (char[]) respVals.getObjectValues()[1];

    mDataModified = dataModified;

    if (hasData)
    {
      if (dataModified)
      {
        setChars(bytes);
      }
    }

    mNeedsServerSync = needsServerSync;
  }

  /**
  * <b>Internal:</b> <em>Applications should not use this method.</em>
  * <p>
  * If this object does not have a transaction context, shares the transaction
  * and CLOB locator from <code>newClob</code>.
  * @param newClob name of the CLOB with which this CLOB will share its
  * transaction and CLOB locator information.
  **/
  public void useCLOB(CLOB newClob)
  {
    if (newClob != null)
    {
      syncLob(newClob);
      if (mDataModified && mcData == null)
      {
        //an attempt to reuse an old CLOB in a new domain.
        //mark the new domain unmodified as CLOB has the real data.
        mDataModified = false;
      }
    }
  }

  /**
  * <b>Internal:</b> <em>Applications should not use this method.</em>
  *
  **/
  public ResponseValues marshal()
  {
    SvcMsgResponseValues svcMsgVal = new SvcMsgResponseValues(SvcMsgResponseValues.RES_MARSHALLED_DOMAIN_VALUE, null);

    boolean hasData = mClient || mDataModified;
    boolean needsServerSync;
    String className = getClass().getName();
    char[] bytes = null;

    if (mDataModified)
    {
      needsServerSync = false;
      bytes = toCharArray();
    }
    else
    {
      needsServerSync = (!mClient && lob != null) || (mClient && mNeedsServerSync);
    }

    svcMsgVal.setBooleanValues(new boolean[] { hasData, mDataModified, needsServerSync});
    svcMsgVal.setObjectValues(new Object[] { className, bytes});

    return svcMsgVal;
  }

  /**
  * <b>Internal:</b> <em>Applications should not use this method.</em>
  *
  **/
  public void   prepareForDML(Object context)
  {
    if (mylob == null)   //jdbc cannot handle null incase of objects containing blobs. 
    {
      try
      {
        syncLob(CLOB.empty_lob());
      }
      catch (SQLException sqle)
      {
        throw new JboException(sqle);
      }
    }
  }

  //for structs to put this in.
  public Datum toDatum(OracleConnection c) throws SQLException
  {
    prepareForDML(c);
    return mylob;
  }

  /**
  *
  * <b>Internal:</b> <em>Applications should not use this method.</em>
  * <p>
  * Uses the given transaction context to store data back into the database
  * using the blob-locator which should be set before this method is invoked.
  * <p>
  * @param xAct name of the transaction context.
  **/
  public void saveToDatabase(Transaction xAct)
  throws SQLException
  {
    if (mylob != null)
    {
      if (mcData != null)
      {
        writeCharsToLob();
      }
    }
  }

  /**
  * <b>Internal:</b> <em>Applications should not use this method.</em>
  * <p>
  * Uses the given transaction context to store data back into the database
  * using the blob-locator which should be set before this method is invoked.
  **/
  public void saveToDatabase(Transaction xAct, Object emptySQLObject)
  throws SQLException
  {
    try
    {
      if (inReader != null)
      {
        inReader.close();
        inReader  = null;
      }
    }
    catch (Exception e)
    {
      //ignore.
    }

    closeOutputStream();

    if (mcData != null)
    {
      syncLob(((ClobDomain)emptySQLObject).mylob);    //????
      writeCharsToLob();
    }
  }

  /**
  * Converts all the data into a String and compares the two strings.
  * This is a default implementation of equals which could be overridden
  * to perform more scalable application-specific comparision.
  * <p>
  * @param obj the object to compare to this ClobDomain.
  **/
  public boolean equals(Object obj) 
  {
    if (obj instanceof ClobDomain)
    {
      ClobDomain other = (ClobDomain)obj;
      if (mylob != null && other.mylob != null && !mDataModified)
      {
        //check addresses first.
        if (mylob == other.mylob)
        {
          return true;
        }

        //return the length equality. no need to compare bytes.
        return(getLength() == other.getLength());
      }
      if (mcData == null && lob != null)
      {
        dumplob();
      }
      if (other.mcData ==  null && other.lob != null)
      {
        other.dumplob();
      }

      if (mcData == other.mcData)
      {
        return true;
      }
      if (mcData != null)
      {
        //note in the interest of speed, we consider two blobs of equal size as equal
        //so that for locking purposes things go faster.
        return(mcData.size() == other.mcData.size());
      }
      else
      {
        return other.getData() == null;
      }
    }
    return false;
  }


  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   * 
  */
  public static XMLDomainFactory getXMLDomainFactory(Class attrClass) 
  {
    class facClass implements XMLDomainFactory 
    {
      Class mAttrClass;
      facClass(Class clas)
      {
        mAttrClass = clas;
      }

      public DomainInterface createDomainFromXMLElement(org.w3c.dom.Element node)
      {
        try
        {
          ClobDomain s = (ClobDomain)mAttrClass.newInstance();

          org.w3c.dom.Node domNode = node.getFirstChild();
          if (domNode != null)
          {
            s.setChars(domNode.getNodeValue().toCharArray());
          }
          return s;
        }
        catch (JboException e)
        {
          throw e;
        }
        catch (Exception e)
        {
          //throw new jbo exception here.
          throw new JboException(e);
        }
      }
    }

    return new facClass(attrClass);
  }

  /**
  * Creates an empty CLOB object.
  * <p>
  * @param context an internal framework context.
  **/
  public static CLOB createEmptyCLOB(Object context)
  {
    try
    {
      return CLOB.empty_lob();
    }
    catch (SQLException sqle)
    {
      throw new JboException(sqle);
    }
  }

  /**
   * Returns a copy of the specified substring
   * in the <code>CLOB</code> value
   * designated by this <code>Clob</code> object.
   * The substring begins at position
   * <code>offset</code> and has up to <code>length</code> consecutive
   * characters.
   * @param offset the first character of the substring to be extracted.
   *            The first character is at position 0.
   * @param length the number of consecutive characters to be copied
   * @return a <code>String</code> that is the specified substring in
   *         the <code>CLOB</code> value designated by this <code>Clob</code> object
   * @exception SQLException if there is an error accessing the
   * <code>CLOB</code>
   */
  public String getSubString(long offset, int length)
  {
    if (mcData != null)
    {
      if (offset < 1)
      {
        return null;
      }
      char[] bytes = new char[length];
      System.arraycopy (mcData.getStorage(), (int)offset-1, bytes, 0, length);
      return new String(bytes);
    }
    else if (mClient)
    {
      Method mth  = getInvokeDomainMethod();
      try
      {
        if (mIndexString == null)
        {
          //simply write the absolute index : rowindex[.structindex]*
          getRemoteIdString();
        }
        return(String)mth.invoke(xAct, new Object[] {
                                   getOwnerRow(),
                                   mIndexString, 
                                   Boolean.FALSE, 
                                   "getSubString", 
                                   new String[] {Long.TYPE.getName(), Integer.TYPE.getName()},
                                   new Object[] {new Long(offset), new Integer(length)}
                                 });
      }
      catch (Exception e)
      {
        throw new JboException(e);
      }
    }
    else if (mylob != null)
    {
      try
      {
        return mylob.getSubString(offset, length);
      }
      catch (SQLException sqle)
      {
        throw new JboException(sqle);
      }
    }
    return null;
  }

  private void writeObject(ObjectOutputStream out)
  throws IOException
  {
    //if client side blob and mData is modified using setBytes, need to marshall it.
    out.writeBoolean(mClient || mDataModified);   //hasData.
    if (mClient || mDataModified)
    {
      out.writeBoolean(mDataModified);
      if (mDataModified)
      {
        char[] bytes = toCharArray();
        if (bytes != null)
        {
          out.writeInt(bytes.length);

          out.writeChars(new String(bytes));
        }
        else
        {
          out.writeInt(-1);
        }

        //needs no sync as I have complete data already.
        out.writeBoolean(false);
        return;
      }
    }

    //new lob needs no syncing, if client and no data - emptylob.
    //if server side and i have lob locator i need syncing.
    out.writeBoolean((!mClient && lob != null) 
                     || (mClient && mNeedsServerSync));
  }

  private void readObject(ObjectInputStream in)
  throws IOException, ClassNotFoundException
  {
    //if server side blob and mData is modified using setBytes, need to marshall it.
    boolean hasData = in.readBoolean();   //if server wrote bytes, then I should be client.
    if (hasData)
    {
      if (in.readBoolean())
      {
        int size = in.readInt();
        char[] bytes = null;
        if (size > -1)
        {
          bytes = new char[size];
          for (int i = 0; i < bytes.length; i++)
          {
            bytes[i] = in.readChar();
          }
          //in.read(bytes); //doesn't work for large bytes all the time. 
        }
        setChars(bytes);
      }
    }

    //if new Blob, this will be true.
    mNeedsServerSync = in.readBoolean(); 
  }

  /**
   * get ascii OutputStream of the CLOB.
   *
   * @return a ascii output stream.
   * 
   * @deprecated since 9.0.3.5. Use getCharacterOutputStream() instead.
   */
  public OutputStream getAsciiOutputStream()
  {
    return getOutputStream();
  }

  /**
   * Gets the <code>CLOB</code> value designated by this <code>Clob</code>
   * object as a stream of Ascii bytes.
   * @return an InputStream containing the <code>CLOB</code> data 
   * <code>CLOB</code> value
   * 
   * @deprecated since 9.0.3.5. Use getCharacterStream() instead.
   */
  public InputStream getInputStream() 
  {
    return new ClobInputStream(getCharacterStream());
  }
  /**
   * Gets the <code>CLOB</code> value designated by this <code>Clob</code>
   * object as a stream of Ascii bytes.
   * @return an ascii stream containing the <code>CLOB</code> data
   * <code>CLOB</code> value
   */
  public InputStream getAsciiStream()
  {
    return getInputStream();
  }

  protected void resetCachedData()
  {
    mcData = null;  //no need for mcData now.
    mDataModified = false;
  }

  /**
    * Converts this CLOB contents into a char array.
    * @return a Char array containing the contents of the CLOB.
    */
  public char[] getStorageCharArray()
  {
    if (mcData != null)
    {
      return mcData.getStorage();
    }
    return null;
  }

  /**
   * @deprecated since 9.0.3.5. Use getStorageCharArray() instead.
   */
  public byte[] getStorageByteArray()
  {
    return getStorageByteArray(sun.io.ByteToCharConverter.getDefault().getCharacterEncoding());
  }

  /**
   * @deprecated since 9.0.3.5. Use getStorageCharArray() instead.
   */
  public byte[] getStorageByteArray(String enc) 
  {
    if (mcData != null)
    {
      try
      {
        return new String(mcData.getStorage()).getBytes(enc);  
      }
      catch (UnsupportedEncodingException ex)
      {
        return null;
      }
    }
    return null;
  }

  /*
   * The containing row should be locked before getting an output stream
   * Otherwise, data written into the returned stream may be lost.
   *
   * There's no proper place in the framework to check this/lock the container
   * as this object could be embedded deep in domains and in that case by the
   * time one reaches this method, the containing row may have re-fetched the
   * domain.
   */
  /**
   * get OutputStream of the Domain.
   *
   * @return an outputStream.
   * 
   * @deprecated since 9.0.3.5. Use getCharacterOutputStream() instead.
   */
  public OutputStream getOutputStream() 
  {
    return new ClobOutputStream(getCharacterOutputStream());
  }

  /**
   * Returns a Writer for Unicode stream to the CLOB that uses the default character encoding.
   *
   * @return a Unicode character writer.
   */
  public Writer getCharacterOutputStream()
  {
    if (outWriter != null)
    {
      return outWriter;
    }

    //whenever getOutputStream is called, it pretty much means input stream is 
    //to be reset to start from beginning as what's happening likely is one
    //is writing to this stream and input stream should start fresh.
    if (inReader != null)
    {
      try
      {
        inReader.close();
      }
      catch (IOException ioe)
      {

      }
      inReader = null;
    }

    //if data was read into mData for some reason but not modified using setBytes,
    //clean it up as it needs to be refetched next time.
    if (!mDataModified && mcData != null)
    {
      resetCachedData();
    }

    if (!mClient)
    {
      //see if the containing row is locked. If not throw.

      //we could move this method to a real method in a server class.
      // how about testing for dead/deleted entity as well.

      //should be ok to refer to entity straight as this is executed
      //only in server case.
      Object ownerRow = getOwnerRow();
      if (ownerRow != null)
      {
        try
        {
          Class implCls = Class.forName("oracle.jbo.server.EntityDefImpl");
          Method mth = implCls.getMethod("checkEntityLocked", new Class[] {oracle.jbo.Row.class});
          if (!((Boolean)mth.invoke(null, new Object[]{ownerRow})).booleanValue())
          {
            throw new JboException(CSMessageBundle.class, 
                                   CSMessageBundle.EXC_LOCK_ROW_BEFORE_LOB_USE, null);
          }
        }
        catch (JboException jboe)
        {
          throw jboe;
        }
        catch (Exception e)
        {
          throw new JboException(e);
        }
      }

      if (mylob != null)
      {
        //local mode.
        if (mDataModified)
        {
          writeCharsToLob();
        }

        //can't lock owner here as that re-fetches the data rendering this object
        //as unused (incase of domains-in-domains)
        try
        {
          outWriter = mylob.getCharacterOutputStream();  
        }
        catch (SQLException ex)
        {
          throw new JboException(ex);
        }

      }
      else if (mcData != null)
      {
        //server side data.
        outWriter = mcData;
      }
      else
      {
        //for a new domain on the client, the equivalent on the server
        //needs to have a new bytearray output stream. This is an unposed
        //lob and hence needs to work without a locator.
        outWriter = mcData = new ClobWriter();
        mDataModified = true;
      }
    }
    else
    {
      //do marshalling via an inner class that knows this domain instance
      //it's owner row and the txn.
      if (mIndexString == null)
      {
        //simply write the absolute index : rowindex[.structindex]*
        getRemoteIdString();
      }

      try
      {
        Class implCls = Class.forName("oracle.jbo.client.remote.ClobDomainCharacterOutputStream");
        Constructor cons = implCls.getConstructor(new Class[] { Transaction.class,
                                                    DomainOwnerInterface.class,
                                                    String.class});
        outWriter = (Writer) cons.newInstance(new Object[] { xAct, getOwnerRow(), mIndexString});

        //sure the caller is going to write from the server, so clean my instance here.
        resetCachedData();
      }
      catch (Exception ex)
      {
        Throwable th = ex;

        if (th instanceof InvocationTargetException)
        {
          th = ((InvocationTargetException) th).getTargetException();
        }

        if (th instanceof JboException)
        {
          throw (JboException) th;
        }

        throw new JboException(th);
      }
    }

    return outWriter;
  }

  /**
   * Returns a Writer for Unicode stream to the CLOB that uses the named character encoding
   * 
   * @return a Unicode character writer.
   * 
   * @deprecated since 9.0.3.5. Use getCharacterOutputStream() instead.
   */
  public Writer getCharacterOutputStream(String enc)
  {
    return getCharacterOutputStream();
  }

  /**
   * Gets the <code>Clob</code> contents as a Unicode reader.
   * @return a Unicode reader containing the <code>CLOB</code> data
   * @exception SQLException if there is an error accessing the
   * <code>CLOB</code>
   */
  public Reader getCharacterStream()
  {
    if (inReader != null)
    {
      try
      {
        if (inReader.ready())
        {
          return inReader;
        }
        inReader.close();
      }
      catch (IOException e)
      {
      }

      inReader = null;
    }

    if (mylob != null)
    {
      //local mode.
      if (mDataModified)
      {
        writeCharsToLob();
      }
      try
      {
        inReader = mylob.getCharacterStream();
        inReader.reset();
      }
      catch (SQLException ex)
      {
        throw new JboException(ex);
      }
      catch (IOException e)
      {
      }
    }
    else if (mcData != null || mDataModified)
    {
      inReader = new CharArrayReader(mcData.toCharArray());
    }
    else if (mClient)
    {
      //do marshalling via an inner class that knows this domain instance and it's
      //owner row and txn.
      if (mIndexString == null)
      {
        //simply write the absolute index : rowindex[.structindex]*
        getRemoteIdString();
      }

      try
      {
        Class implCls = Class.forName("oracle.jbo.client.remote.ClobDomainCharacterStream");
        Constructor cons = implCls.getConstructor(new Class[] { Transaction.class,
                                                    DomainOwnerInterface.class,
                                                    String.class});
        inReader = (Reader) cons.newInstance(new Object[] { xAct, getOwnerRow(), mIndexString});
      }
      catch (Exception ex)
      {
        Throwable th = ex;

        if (th instanceof InvocationTargetException)
        {
          th = ((InvocationTargetException) th).getTargetException();
        }

        if (th instanceof JboException)
        {
          throw (JboException) th;
        }

        throw new JboException(th);
      }
    }
    return inReader;
  }

  /**
   * Gets the <code>Clob</code> contents as a Unicode stream that uses the named character encoding.
   * @return a Unicode stream containing the <code>CLOB</code> data
   * @exception SQLException if there is an error accessing the
   * <code>CLOB</code>
   * 
   * @deprecated since 9.0.3.5. Use getCharacterStream() instead.
   */
  public Reader getCharacterStream(String enc)
  {
    return getCharacterStream();
  }

  /**
   * Sets the Clob data for this object. 
   * On the client side, if there's a context available with this object,
   * the bytes are streamed to the middle-tier object right-away. However
   * if there's no context object, it's assumed that there will be a setAttribute
   * call invoked on a containing row with this object as argument to stream
   * the bytes via piggy-back.
   * <p>
   * @param clobData data to fill the Blob.
   * 
   * @deprecated since 9.0.3.5. Use setChars(char[] clobData) instead.
   */
  public void setBytes(byte[] clobData) 
  {
    if (clobData != null)
    {
      setChars(new String(clobData).toCharArray());
    }
  }
  /**
   * Sets the Clob data for this object. 
   * On the client side, if there's a context available with this object,
   * the bytes are streamed to the middle-tier object right-away. However
   * if there's no context object, it's assumed that there will be a setAttribute
   * call invoked on a containing row with this object as argument to stream
   * the bytes via piggy-back.
   * <p>
   * @param clobData data to fill the Blob.
   */
  public void setChars(char[] clobData) 
  {
    //if (mClient) 
    {
      Writer os = getCharacterOutputStream();
      if (os != null)
      {
        try
        {
          if (inReader != null)
          {
            inReader.close();
            inReader = null;
          }
          if (clobData != null)
          {
            os.write(clobData, 0, clobData.length);
          }
          else
          {
            os.write(new char[]{}, 0, 0);
          }
          closeCharacterOutputStream();

          return;
        }
        catch (IOException ioe)
        {
          //ignore and let mData write this blob via piggyback.
          Diagnostic.println("Error opening cache'd stream. Set the attribute again into it's row");
        }
      }
    }

    mDataModified = true;
  }

  /**
  * <b>Internal:</b> <em>Applications should not use this function.</em>
  */ 
  public void syncClientLob(LobInterface oldObj)
  {
    if (oldObj != null)
    {
      ClobDomain old = (ClobDomain)oldObj;
      mcData = null;
      mDataModified = false;

      //Fix the bug for sync client
      mcData = old.mcData;
      mDataModified = old.mDataModified;

      if (inReader != null)
      {
        try
        {
          inReader.close();
        }
        catch (IOException ioe)
        {

        }
        inReader = null;
      }
      closeCharacterOutputStream();
    }
  }


  /**
  * <b>Internal:</b> <em>Applications should not use this function.</em>
  */ 
  public void syncServerLob(LobInterface oldObj)
  {
    if (oldObj != null)
    {
      ClobDomain old = (ClobDomain)oldObj;
      //if data was pushed in via memory stream, then this would be 
      //a new lob data, so ignore syncing.
      if (mNeedsServerSync)
      {
        //I was serialized from a client.
        syncLob(old.lob);
        mcData     = old.mcData;
        inReader  = old.inReader;
        outWriter = old.outWriter;
        mDataModified = old.mDataModified;
        mNeedsServerSync = false;
      }
      else if (old.xAct != null && !old.mDataModified && !mDataModified)
      {
        syncLob(old.lob);
        mcData     = null;
        mDataModified = false;
        if (inReader != null)
        {
          try
          {
            inReader.close();
          }
          catch (IOException ioe)
          {

          }
          inReader = null;
        }
        closeCharacterOutputStream();
      }

      //these could carry forward.
      mOwner    = old.mOwner;
      xAct      = old.xAct;
      mClient   = old.mClient;
      relIdx    = old.relIdx;
    }
  }

  /**
    * Converts this ClobDomain object to a string.
    * @return this ClobDomain as a string.
    */
  public String toString()
  {
    if (mcData == null && lob == null)
    {
      if (!mClient || mOwner == null)
      {
        return "";
      }
    }
    char[] barr = toCharArray();
    if (barr != null)
    {
      return new String (barr);
    }
    return "";
  }

  /**
  * <b>Internal:</b> <em>Applications should not use this method.</em>
  * <p>
  **/
  public Object getData()
  {
    return mylob;
  }

  /**
    * Converts this CLOB contents into a char array.
    * @return a char array containing the contents of the BLOB.
    */
  public char[] toCharArray()
  {
    if (!mDataModified && mcData == null)
    {
      if (mylob != null)
      {
        dumplob();
      }
      else if (mOwner != null)
      {
        //needs to serialize using owner id, via transaction interface.
        dumpStream();
      }

    }

    if (mcData != null)
    {
      return mcData.toCharArray();
    }
    return null;
  }

  //abstract methods.
  char[] readCharsFromLob(long offset, int length)
  {
    try
    {
      return mylob.getSubString(offset, length).toCharArray();
    }
    catch (SQLException sqle)
    {
      throw new JboException (sqle);
    }
  }

  void writeCharsToLob()
  {
    try
    {
      mylob.putChars(1, mcData.toCharArray());
      super.resetCachedData();
    }
    catch (SQLException sqle)
    {
      throw new JboException (sqle);
    }
  }
  //abstract methods.
  byte[] readBytesFromLob(long offset, int length)
  {
    try
    {
      return mylob.getSubString(offset, length).getBytes();
    }
    catch (SQLException sqle)
    {
      throw new JboException (sqle);
    }
  }

  void writeBytesToLob()
  {
    writeCharsToLob();
  }

  OutputStream getInternalOutputStream()
  {
    try
    {
      return mylob.getAsciiOutputStream();
    }
    catch (SQLException sqle)
    {
      throw new JboException (sqle);
    }
  }

  InputStream getInternalStream()
  {
    try
    {
      return mylob.getAsciiStream();
    }
    catch (SQLException sqle)
    {
      throw new JboException (sqle);
    }
  }

  InputStream getInternalDataStream()
  {
    //for reading Characters.
    return new DataInputStream(new ByteArrayInputStream(new String(mcData.toCharArray()).getBytes()));
  }

  void syncLob (Datum otherLob)
  {
    lob = mylob = (CLOB)otherLob;
  }

  /**
   * Returns the number of characters
   * in the <code>CLOB</code> value
   * designated by this <code>Clob</code> object.
   * @return length of the <code>CLOB</code> in characters
   */
  public long getLength()
  {
    if (mClient)
    {
      return super.getRemoteLength();
    }
    if (!mDataModified && mylob != null)
    {
      try
      {
        return mylob.length();
      }
      catch (SQLException sqle)
      {
        Diagnostic.println("Warning : SQLException during ClobDomain.getLength()");
      }
    }

    if (mcData != null)
    {
      return mcData.size();
    }
    return 0;
  }

  /**
   * Get ideal LOB db access buffer size.
   *
   * @return the size in terms of characters.
   */ 
  public int getBufferSize() 
  {
    if (mClient)
    {
      return super.getRemoteBufferSize();
    }

    if (!mDataModified && mylob != null)
    {
      try
      {
        return mylob.getBufferSize();
      }
      catch (SQLException sqle)
      {
        Diagnostic.println("Warning : SQLException during ClobDomain.getLength()");
      }
    }

    if (mcData != null)
    {
      return mcData.size();
    }
    return 0;
  }


  private void dumpStream() 
  {

    //need this for flush/close
    Reader in = getCharacterStream();
    try
    {
      mcData = new ClobWriter();
      try
      {
        int index = 0;
        int chunk = 31 * 1024;
        char[] buf = new char[chunk];
        do
        {
          chunk = in.read(buf, 0, chunk);
          mcData.write(buf, 0, chunk);
        } while (buf.length == chunk);
      }
      catch (NullPointerException ioe)
      {
        //ignore null pointer exception as that;s
        //thrown when blob is done reading.
      }
      mcData.flush();

      in.close();
      inReader = null;

      mcData.close();
    }
    catch (Exception sqle)
    {
      new JboException (sqle);
    }
  }

  //dump the lob into a local output writer.
  private CharArrayWriter dumplob () 
  {
    //need this for flush/close
    try
    {
      mcData = new ClobWriter();
      char[] buf;
      try
      {
        int index = 0;
        int chunk = 31 * 1024;
        do
        {
          buf = readCharsFromLob(index+1, chunk);

          if (buf == null)
          {
            break;
          }
          mcData.write(buf, 0, buf.length);
          index += buf.length;
        } while (buf.length == chunk);
      }
      catch (NullPointerException ioe)
      {
        //ignore null pointer exception as that;s
        //thrown when blob is done reading.
      }
      mcData.flush();
      mcData.close();
    }
    catch (Exception sqle)
    {
      new JboException (sqle);
    }

    return mcData;
  }

  public void closeOutputStream()
  {
    closeCharacterOutputStream();  
  }

  public void closeCharacterOutputStream()
  {
    if (outWriter != null)
    {
      try
      {
        outWriter.flush();
        outWriter.close();
      }
      catch (Exception e)
      {
        //ignore
        //Diagnostic.printStackTrace(e);
      }
      outWriter = null;
    }
  }

  class ClobWriter extends CharArrayWriter
  {
    ClobWriter() 
    {
      // super(128);
    }

    ClobWriter(int size) 
    {
      super(size);
    }

    synchronized char[] getStorage()
    {
      return buf;
    }

  }

  class ClobInputStream extends InputStream
  {
    Reader in = null;

    ClobInputStream(Reader in)
    {
      this.in = in;
    }

    public int read() throws IOException
    {
      return in.read();
    }

    public int read(byte b[]) throws IOException 
    {
      return read(b, 0, b.length);
    }

    public int read(byte b[], int off, int len) throws IOException 
    {
      if (b == null)
      {
        throw new NullPointerException();
      }

      char buf[] = new char[len];

      int i = in.read(buf,off,len);

      for (int j = 0; j < i; j++)
      {
        b[j] = (byte) buf[j];
      }

      return i;
    }

    public long skip(long n) throws IOException 
    {
      return in.skip(n);
    }

    /*
     * return 1, ready to read
     * return 0, not ready.
     */
    public int available() throws IOException 
    {
      return(in.ready()?1:0);
    }

    public void close() throws IOException 
    {
      in.close();
    }

    public synchronized void mark(int readlimit) 
    {
      try
      {
        in.mark(readlimit);
      }
      catch ( Exception e)
      {
        Diagnostic.printStackTrace(e);
      }
    }

    public synchronized void reset() throws IOException 
    {
      in.reset();
    }

    /**
     * Tests if this input stream supports the <code>mark</code> and
     * <code>reset</code> methods. Whether or not <code>mark</code> and
     * <code>reset</code> are supported is an invariant property of a
     * particular input stream instance. The <code>markSupported</code> method
     * of <code>InputStream</code> returns <code>false</code>.
     *
     * @return  <code>true</code> if this stream instance supports the mark
     *          and reset methods; <code>false</code> otherwise.
     * @see     java.io.InputStream#mark(int)
     * @see     java.io.InputStream#reset()
     */
    public boolean markSupported() 
    {
      return in.markSupported();
    }
  }

  class ClobOutputStream extends OutputStream
  {
    Writer os = null;

    ClobOutputStream(Writer os) 
    {
      this.os = os;
    }

    public void close() throws IOException
    {
      os.close();
    }

    public void flush() throws IOException
    {
      os.flush();
    }

    public void write(byte[] b) throws IOException
    {
      os.write(new String(b));
    }

    public void write(byte[] b, int off, int len) throws IOException
    {
      os.write(new String(b,off,len));
    }

    public void write(int b) throws IOException
    {
      os.write(b);  
    }
  }
}  

