package oracle.jbo.domain;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;

import oracle.jbo.Transaction;
// import oracle.jbo.client.remote.LobDomainInputStream; 
// import oracle.jbo.client.remote.LobDomainOutputStream; 
// import oracle.jbo.server.DBTransactionImpl;
import oracle.jbo.common.Diagnostic;
import oracle.jbo.CSMessageBundle;
import oracle.jbo.JboException;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;

import oracle.sql.CustomDatum;
import oracle.sql.Datum;

// Core JDBC classes: 
import java.sql.SQLException;
import com.sun.java.util.collections.HashMap; 

//reflection
import java.lang.reflect.Method;

import oracle.jbo.common.SvcMsgResponseValues;
import oracle.svcmsg.ResponseValues;


/*
class LobMarshaller implements oracle.jbo.common.ObjectMarshaller
{
   public Object marshal(Object obj)
   {
      if (obj instanceof BaseLobDomain)
      {
         return ((BaseLobDomain) obj).marshal();
      }

      return null;
   }
   
   public Object unMarshal(Object obj)
   {
      if (obj instanceof SvcMsgResponseValues)
      {
         if (((SvcMsgResponseValues) obj).getOperation() == SvcMsgResponseValues.RES_GET_LOB_DOMAIN_VALUE)
         {
            return BaseLobDomain.unMarshal((SvcMsgResponseValues) obj);
         }
      }

      return null;
   }
   
   public boolean isCustomMarshalled(Object obj)
   {
      return obj instanceof Char;
   }
   
   public String getMarshalledTypeName(Object obj)
   {
      return null;
   }
   
   public void finishedPiggybacking()
   {
   }
}
*/


// ---------------------------------------------------
// ---    jbo generated file.
// ---    Business object: BlobDomain
// ---------------------------------------------------

/**
* This class provides a lightweight wrapper for <tt>oracle.sql.BLOB</tt>,
* the Java representation of the
* BLOB database type. This wrapper allows an instance of the
* <tt>oracle.sql.BLOB</tt> to be used as a domain object.
* <p>
* @since JDeveloper 3.0
*/
abstract public class BaseLobDomain implements java.io.Serializable, CustomDatum, MarshalledDomain
{
   static final String CLIENT_LOB_DOMAIN_INPUT  = "oracle.jbo.client.remote.LobDomainInputStream";
   static final String CLIENT_LOB_DOMAIN_OUTPUT = "oracle.jbo.client.remote.LobDomainOutputStream";
   static final String CLIENT_APPMODULE_CLASS = "oracle.jbo.client.remote.ApplicationModuleImpl";

   private static final int MAX_CHUNK_SIZE = 32767;
   transient BlobOutputStream mData;     // the data contained in the blob
   transient Datum lob = null;          // the blob handle
   transient InputStream inStream;
   transient OutputStream outStream;
   transient DomainOwnerInterface mOwner = null;
   transient oracle.jbo.Transaction xAct = null;
   transient boolean mDataModified = false;
   transient boolean mClient = false;
   transient Integer relIdx = new Integer(-1);
   transient String mIndexString = null;
   transient boolean mNeedsServerSync = false;
//   transient double mRandomID = 0; 

   //transient private Object dataToReturn = null;

/*
   static
   {
      oracle.jbo.common.TypeMarshaller.addCustomMarshaller(new LobMarshaller());
   }
*/

   /**
   * Constructor for this object.
   **/
   BaseLobDomain()
   {
      mDataModified = true;
   }

   /**
   *
   * Constructor for this object. This is for use by JDBC.
   * This constructor uses the transaction context from <code>blob</code>
   * to use the blob-locator
   * in the database.
   * @param blob the BLOB from which to construct the BlobDomain.
   **/
   BaseLobDomain(Datum blob)
   {
      this.lob = blob;
   }

   /**
   * Constructor for this class. Creates an instance of this class
   * with data as described in <code>blobData</code>.
   * @param blobData data for the BLOB.
   **/
   BaseLobDomain (byte[] data)
   {
      if (data != null) 
      {
         setBytes(data);
      }
   }

   /**
   *
   * Creates an instance of this class with data as described in <code>blobData</code>
   * and using the transaction context from <code>blob</code> to use the blob-locator
   * in the database.
   * <p>
   * @param blob transaction context for the BLOB locator, as a BLOB object.
   * @param blobData data for the BLOB.
   **/
   BaseLobDomain(Datum blob, byte[] blobData) 
   {
      this.lob = blob;
      setBytes(blobData);
   }

   /**
   * Creates an instance of this class with data as described in <code>blobData</code>
   * and using the transaction context from <code>blob</code> to use the blob-locator
   * in the database.
   * <p>This constructor should be used by applications using the framework to create
   * BlobDomain objects.
   * <p>
   * @param blob transaction context for the BLOB locator as a BlobDomain object.
   * @param blobData data for the BLOB.
   **/
   BaseLobDomain(BaseLobDomain nblob, byte[] blobData) 
   {
      mClient = nblob.mClient;
      setBytes(blobData);
   }

   BaseLobDomain(ResponseValues respVals)
   {
      boolean hasData = respVals.getBooleanValues()[0];
      boolean dataModified = respVals.getBooleanValues()[1];
      boolean needsServerSync = respVals.getBooleanValues()[2];
      String className = (String) respVals.getObjectValues()[0];
      byte[] bytes = (byte[]) respVals.getObjectValues()[1];

      mDataModified = dataModified;

      if (hasData)
      {
         if (dataModified)
         {
            setBytes(bytes);
         }
      }
      
      mNeedsServerSync = needsServerSync;
   }

   //for structs to put this in.
   public Datum toDatum(oracle.jdbc.driver.OracleConnection c) throws SQLException
   {
      prepareForDML(c);
      return lob;
   }

   /**
    * Sets the blob data for this object. 
    * On the client side, if there's a context available with this object,
    * the bytes are streamed to the middle-tier object right-away. However
    * if there's no context object, it's assumed that there will be a setAttribute
    * call invoked on a containing row with this object as argument to stream
    * the bytes via piggy-back.
    * <p>
    * @param blobData data to fill the Blob.
    */
   public void setBytes(byte[] blobData) 
   {
      //if (mClient) 
      {
         OutputStream os = getOutputStream();
         if (os != null) 
         {
            try
            {
               if (inStream != null) 
               {
                  inStream.close();
                  inStream = null;
               }
               if (blobData != null) 
               {
                  os.write(blobData, 0, blobData.length);
               }
               else
               {
                  os.write(new byte[]{}, 0, 0);
               }
               closeOutputStream();               
               
               return;
            }
            catch (IOException ioe)
            {
               //ignore and let mData write this blob via piggyback.
               Diagnostic.println("Error opening cache'd stream. Set the attribute again into it's row");
            }
         }
      }

      /*
      if (blobData != null) 
      {
         if (mOwner != null) 
         {
            mOwner.domainToBeModified((DomainInterface)this);  //lock container.
         }

         mData = new ByteArrayOutputStream( blobData.length );
         mData.write( blobData, 0, blobData.length );
      }
      else
      {
         mData = null;
      }
      */
      mDataModified = true;
   }


   /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   * <p>
   * Uses the given transaction context to load data from the database.
   * <p>
   * @param xAct name of the transaction context.
   **/
   public void loadFromDatabase( Transaction xAct)
      throws Exception
   {
      this.xAct = xAct;
   }

   /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   * <p>
   * Sets the transaction context for this Blob.
   **/
   public void setContext(DomainOwnerInterface owner, Transaction trans, Object ctx)
   {
      //get the transaction/owner/attribute index(relative to the owner of this lob), 
      this.xAct = trans;
      this.mOwner = owner;
      HashMap ctxMap = (HashMap)ctx;
      //and whether this is a client-side lob.

      if (ctxMap.get(DomainContext.CLIENT_DOMAIN) != null)
      {
         this.mClient = true;
      }
      if (xAct instanceof oracle.jbo.ApplicationModule)
      {
         this.mClient = true;
      }

      Integer idx = (Integer)(ctxMap.get(DomainContext.RELATIVE_INDEX));
      this.relIdx = (idx != null) ? idx : relIdx;
      mIndexString = null; //recalc.
   }


   //methods to be implemented by blob/clob domains.
   abstract void prepareForDML(Object context);
   abstract byte[] readBytesFromLob(long offset, int length);
   abstract void writeBytesToLob();
   abstract OutputStream getInternalOutputStream();
   abstract InputStream getInternalStream();
   abstract InputStream getInternalDataStream();
   abstract void syncLob(Datum otherLob);
   abstract long getLength();

   protected int getRemoteBufferSize() 
   {
      Method mth  = getInvokeDomainMethod();
      try
      {
         if (mIndexString == null) 
         {
            //simply write the absolute index : rowindex[.structindex]*
            getRemoteIdString();
         }
         Object obj = mth.invoke(xAct, new Object[] {
                           getOwnerRow(),
                           mIndexString, 
                           Boolean.FALSE, 
                           "getBufferSize", 
                           new String[] {},
                           new Object[] {}
                          });
         System.out.println("Return value:"+obj);
         if (obj instanceof java.lang.Number)
         {
            return ((java.lang.Number)obj).intValue();
         }
      }
      catch (Exception e)
      {
         throw new JboException(e);
      }

      return 0;
   }
   

   protected long getRemoteLength()
   {
      Method mth  = getInvokeDomainMethod();
      try
      {
         if (mIndexString == null) 
         {
            //simply write the absolute index : rowindex[.structindex]*
            getRemoteIdString();
         }
         Object obj = mth.invoke(xAct, new Object[] {
                           getOwnerRow(),
                           mIndexString, 
                           Boolean.FALSE, 
                           "getLength", 
                           new String[] {},
                           new Object[] {}
                          });
         System.out.println("Return value:"+obj);
         if (obj instanceof java.lang.Number)
         {
            return ((java.lang.Number)obj).longValue();
         }
      }
      catch (Exception e)
      {
         throw new JboException(e);
      }

      return 0;
   }

   //dump the lob into a local output stream.
   private ByteArrayOutputStream dumplob () 
   {

      //need this for flush/close
      try
      {
         mData = new BlobOutputStream();
         byte[] buf;
         try
         {
            int index = 0;
            int chunk = 31 * 1024;
            do
            {
               buf = readBytesFromLob(index+1, chunk);

               if (buf == null) 
               {
                  break;
               }
               mData.write(buf, 0, buf.length);
               index += buf.length;
            } while(buf.length == chunk);
         }
         catch (NullPointerException ioe)
         {
            //ignore null pointer exception as that;s
            //thrown when blob is done reading.
         }
         mData.flush();
         mData.close();
      }
      catch (Exception sqle)
      {
         new JboException (sqle);
      }
      
      return mData;
   }

   private void dumpStream() 
   {

      //need this for flush/close
      InputStream in = getInputStream();
      try
      {
         mData = new BlobOutputStream();
         try
         {
            int index = 0;
            int chunk = 31 * 1024;
            byte[] buf = new byte[chunk];
            do
            {
               chunk = in.read(buf, 0, chunk);
               mData.write(buf, 0, chunk);
            } while(buf.length == chunk);
         }
         catch (NullPointerException ioe)
         {
            //ignore null pointer exception as that;s
            //thrown when blob is done reading.
         }
         mData.flush();
         
         in.close();
         inStream = null;

         mData.close();
      }
      catch (Exception sqle)
      {
         new JboException (sqle);
      }
   }

   /*
   public Object getDatumObject()
   {
      return blob;
   }
   */

   /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   * <p>
   **/
   public Object getData()
   {
      return lob;
   }

   
   /**
   *
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   * <p>
   * Uses the given transaction context to store data back into the database
   * using the blob-locator which should be set before this method is invoked.
   * <p>
   * @param xAct name of the transaction context.
   **/
   public void saveToDatabase(Transaction xAct)
      throws SQLException
   {
      if (lob != null)
      {
         if (mData != null)
         {
            writeBytesToLob();
         }
      }
   }

   /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   * <p>
   * Uses the given transaction context to store data back into the database
   * using the blob-locator which should be set before this method is invoked.
   **/
   public void saveToDatabase(Transaction xAct, Object emptySQLObject)
      throws SQLException
   {
      //get the oracle.sql.BLOB object from BlobDomain to set its locator.
//      mRandomID = 0;
      try
      {
         if (inStream != null) 
         {
            inStream.close();
            inStream  = null;
         }
      }
      catch (Exception e)
      {
         //ignore.
      }
      
      closeOutputStream();

      if (mData != null)
      {
         syncLob(((BaseLobDomain)emptySQLObject).lob);
         writeBytesToLob();
      }
   }


  /**
    *
    *
    * For testing purposes only: converts this BlobDomain object to a string.
    * @return this BlobDomain as a string.
    */
   public String toString() 
   {
      if (mData == null && lob == null)
      {
         if (!mClient || mOwner == null) 
         {
            return "";
         }
      }
      byte[] barr = toByteArray();
      if (barr != null) {
         return new String (barr);
      }
      return "";
   }

   public boolean isCacheDataModified()
   {
      return (mDataModified && mData != null);
   }
 
   /*
   * If BlobDomain has an in-memory output-stream, this method
   * returns the actual storage byte-array in the output-stream
   * so that there's no copying of the same byte-stream.
   * Callers should not make any changes to the data of this stream
   * as it's not guarenteed to be posted/saved. Also the behaviour
   * may be un-deterministic if contents of this byte-array is
   * modified on return.
   */
   public byte[] getStorageByteArray()
   {
      if (mData != null) 
      {
         return mData.getStorage();
      }
      return null;
   }


  /**
    * Converts this BLOB contents into a byte array.
    * @return a byte array containing the contents of the BLOB.
    */
   public byte[] toByteArray()
   {
      if (!mDataModified && mData == null)
      {
         if (this.lob != null)
         {
            dumplob();
         }
         else if (mOwner != null) 
         {
            //needs to serialize using owner id, via transaction interface.
            dumpStream();
         }

      }

      if (mData != null)
      {
         return mData.toByteArray();
      }
      return null;
   }


   /**
   * Tests for equality between <tt>this</tt> and <tt>obj</tt>.
   * Converts all the data into a String and compares the two strings.
   * This is a default implementation of equals which could be overridden
   * to perform more scalable application-specific comparisons.
   * <p>
   * @param obj the data item to compare against.
   **/
   public boolean equals(Object obj) 
   {
      if (obj instanceof BaseLobDomain) 
      {
         BaseLobDomain other = (BaseLobDomain)obj;
         if (lob != null && other.lob != null && !mDataModified) 
         {
//            if (mRandomID == other.mRandomID)
            {
               //check addresses first.
               if (lob == other.lob)
               {
                  return true;
               }
               
               //return the length equality. no need to compare bytes.
               return (getLength() == other.getLength());
            }
//            return false;
         }
         if (mData == null && lob != null) 
         {
            dumplob();
         }
         if (other.mData ==  null && other.lob != null) 
         {
            other.dumplob();
         }

         if (mData == other.mData) 
         {
            return true;
         }
         if (mData != null)
         {
            //note in the interest of speed, we consider two blobs of equal size as equal
            //so that for locking purposes things go faster.
            return (mData.size() == other.mData.size());
         }
         else
         {
            return other.getData() == null;
         }
      }
      return false;
   }


   public ResponseValues marshal()
   {
      SvcMsgResponseValues svcMsgVal = new SvcMsgResponseValues(SvcMsgResponseValues.RES_MARSHALLED_DOMAIN_VALUE, null);

      boolean hasData = mClient || mDataModified;
      boolean needsServerSync;
      String className = getClass().getName();
      byte[] bytes = null;
      
      if (mDataModified) 
      {
         needsServerSync = false;
         bytes = toByteArray();
      }
      else
      {
         needsServerSync = (!mClient && lob != null) || (mClient && mNeedsServerSync);
      }
      
      svcMsgVal.setBooleanValues(new boolean[] { hasData, mDataModified, needsServerSync });
      svcMsgVal.setObjectValues(new Object[] { className, bytes });

      return svcMsgVal;
   }
   
   
   private void writeObject(ObjectOutputStream out)
     throws IOException
   {
      //if client side blob and mData is modified using setBytes, need to marshall it.
      out.writeBoolean(mClient || mDataModified); //hasData.
      if (mClient || mDataModified) 
      {
         out.writeBoolean(mDataModified);
         if (mDataModified)
         {
            byte[] bytes = toByteArray();
            if (bytes != null) 
            {
               out.writeInt(bytes.length);
         
               for (int i = 0; i < bytes.length; i++) 
               {
                  out.write(bytes[i]);
               }
            }
            else
            {
               out.writeInt(-1);
            }

            //needs no sync as I have complete data already.
            out.writeBoolean(false);
            return;
         }
      }
      
      //new lob needs no syncing, if client and no data - emptylob.
      //if server side and i have lob locator i need syncing.
      out.writeBoolean((!mClient && lob != null) 
                       || (mClient && mNeedsServerSync));
   }
   
   
   private void readObject(ObjectInputStream in)
     throws IOException, ClassNotFoundException
   {
      //if server side blob and mData is modified using setBytes, need to marshall it.
      boolean hasData = in.readBoolean(); //if server wrote bytes, then I should be client.
      if (hasData)
      {
         if (in.readBoolean())
         {
            int size = in.readInt();
            byte[] bytes = null;
            if (size > -1) 
            {
               bytes = new byte[size];
               for (int i = 0; i < bytes.length; i++) 
               {
                  bytes[i] = (byte)in.read();
               }
               //in.read(bytes); //doesn't work for large bytes all the time. 
            }
            setBytes(bytes);
         }
      }
      
      //if new Blob, this will be true.
      mNeedsServerSync = in.readBoolean(); 
   }

   /*
   * The containing row should be locked before getting an output stream
   * Otherwise, data written into the returned stream may be lost.
   *
   * There's no proper place in the framework to check this/lock the container
   * as this object could be embedded deep in domains and in that case by the
   * time one reaches this method, the containing row may have re-fetched the
   * domain.
   */
  public OutputStream getOutputStream() 
  {
     if (outStream != null) 
     {
        return outStream;
     }

//     if (mRandomID == 0)
     {
        //indicate that this lob has been modified atleast once.
//        mRandomID = Math.random();                                                 
     }

     //whenever getOutputStream is called, it pretty much means input stream is 
     //to be reset to start from beginning as what's happening likely is one
     //is writing to this stream and input stream should start fresh.
     if (inStream != null) 
     {
        try
        {
           inStream.close();
        }
        catch (IOException ioe)
        {

        }
        inStream = null;
     }

     //if data was read into mData for some reason but not modified using setBytes,
     //clean it up as it needs to be refetched next time.
     if (!mDataModified && mData != null) 
     {
        resetCachedData();
     }

     if (!mClient)
     {
        //see if the containing row is locked. If not throw.
        
        //we could move this method to a real method in a server class.
        // how about testing for dead/deleted entity as well.

        //should be ok to refer to entity straight as this is executed
        //only in server case.
        Object ownerRow = getOwnerRow();
        if (ownerRow != null) 
        {
           try
           {
              Class implCls = Class.forName("oracle.jbo.server.EntityDefImpl");
              Method mth = implCls.getMethod("checkEntityLocked", new Class[] {oracle.jbo.Row.class});
              if (!((Boolean)mth.invoke(null, new Object[]{ownerRow})).booleanValue())
              {
                 throw new JboException(CSMessageBundle.class, 
                                        CSMessageBundle.EXC_LOCK_ROW_BEFORE_LOB_USE, null);
              }
           }
           catch (JboException jboe)
           {
              throw jboe;
           }
           catch (Exception e)
           {
              throw new JboException(e);
           }
        }
        /*
        oracle.jbo.server.EntityImpl ownerRow = (oracle.jbo.server.EntityImpl)getOwnerRow();
        if (ownerRow != null) 
        {
           if ( (ownerRow.getPostState() != oracle.jbo.server.Entity.STATUS_NEW)
                   && !ownerRow.isLocked())
           {
              //need to convert to a proper exception message.
           }
        }
        */
        if (lob != null) 
        {
           //local mode.
           if (mDataModified) 
           {
              //blob.putBytes(1, mData.toByteArray());
              writeBytesToLob();
           }

           //can't lock owner here as that re-fetches the data rendering this object
           //as unused (incase of domains-in-domains)
           outStream = getInternalOutputStream();
        }
        else if (mData != null) 
        {
           //server side data.
           outStream = mData;
        }
        else 
        {
           //for a new domain on the client, the equivalent on the server
           //needs to have a new bytearray output stream. This is an unposed
           //lob and hence needs to work without a locator.
           outStream = mData = new BlobOutputStream();
           mDataModified = true;
        }
     }
     else 
     {
        //do marshalling via an inner class that knows this domain instance
        //it's owner row and the txn.
        if (mIndexString == null) 
        {
           //simply write the absolute index : rowindex[.structindex]*
           getRemoteIdString();
        }
        
        // outStream = new LobDomainOutputStream(xAct,
        //                                     getOwnerRow(),
        //                                     mIndexString);

        try
        {
           Class implCls = Class.forName(CLIENT_LOB_DOMAIN_OUTPUT);
           Constructor cons = implCls.getConstructor(new Class[] { Transaction.class,
                                                                   DomainOwnerInterface.class,
                                                                   String.class });
           outStream = (OutputStream) cons.newInstance(new Object[] { xAct, getOwnerRow(), mIndexString });
           
           //sure the caller is going to write from the server, so clean my instance here.
           resetCachedData();
        }
        catch(Exception ex)
        {
           Throwable th = ex;

           if (th instanceof InvocationTargetException)
           {
              th = ((InvocationTargetException) th).getTargetException();
           }

           if (th instanceof JboException)
           {
              throw (JboException) th;
           }

           throw new JboException(th);
        }
     }

     return outStream;
  }

  public String getRemoteIdString()
  {
     if (mIndexString == null)
     {
        StringBuffer absIndex = new StringBuffer(relIdx.toString());
        String relIndex;
        DomainOwnerInterface owner = mOwner;
        while (owner instanceof LobInterface) 
        {
           absIndex = absIndex.insert(0, '.');
           absIndex = absIndex.insert(0, (new Integer(((LobInterface)owner).getOwnerAttributeIndex())).toString());
           owner = ((LobInterface)owner).getOwner();
        }
        mIndexString = absIndex.toString();
     }
     return mIndexString;
  }
  
  public DomainOwnerInterface getOwner()
  {
     return mOwner;
  }

  public int getOwnerAttributeIndex()
  {
     return relIdx.intValue();
  }

  protected DomainOwnerInterface getOwnerRow()
  {
     DomainOwnerInterface owner = mOwner;
     while (owner instanceof LobInterface) 
     {
        owner = ((LobInterface)owner).getOwner();
     }
     return (owner instanceof oracle.jbo.Row) ? owner : null;
  }

  public InputStream getInputStream() 
  {
     if (inStream != null)
     {
        try
        {
           if (inStream.available() > 0) 
           {
              return inStream;
           }
           inStream.close();
        }
        catch (IOException e)
        {
        }

        inStream = null;
     }

     if (lob != null) 
     {
        //local mode.
        if (mDataModified) 
        {
           writeBytesToLob();
        }
        inStream = getInternalStream();
        try
        {
           inStream.reset();
        }
        catch (IOException e)
        {
        }
   
     }
     else if (mData != null || mDataModified) 
     {
        inStream = getInternalDataStream();
     }
     else if (mClient) 
     {
        //do marshalling via an inner class that knows this domain instance and it's
        //owner row and txn.
        if (mIndexString == null) 
        {
           //simply write the absolute index : rowindex[.structindex]*
           getRemoteIdString();
        }

        // inStream = new LobDomainInputStream(xAct,
        //                                     getOwnerRow(),
        //                                     mIndexString);

        try
        {
           Class implCls = Class.forName(CLIENT_LOB_DOMAIN_INPUT);
           Constructor cons = implCls.getConstructor(new Class[] { Transaction.class,
                                                                   DomainOwnerInterface.class,
                                                                   String.class });
           inStream = (InputStream) cons.newInstance(new Object[] { xAct, getOwnerRow(), mIndexString });
        }
        catch(Exception ex)
        {
           Throwable th = ex;

           if (th instanceof InvocationTargetException)
           {
              th = ((InvocationTargetException) th).getTargetException();
           }

           if (th instanceof JboException)
           {
              throw (JboException) th;
           }

           throw new JboException(th);
        }
     }
     return inStream;
  }

  protected void resetCachedData()
  {
     mData = null; //no need for mData now.
     mDataModified = false;
  }

  public void syncClientLob(LobInterface oldObj)
  {
     if (oldObj != null) 
     {
        BaseLobDomain old = (BaseLobDomain)oldObj;
        mData = null;
        mDataModified = false;
        
        //Fix the bug for sync client
        mData = old.mData;
        mDataModified = old.mDataModified;
        
        if (inStream != null) 
        {
           try
           {
              inStream.close();
           }
           catch (IOException ioe)
           {
   
           }
           inStream = null;
        }
        closeOutputStream();
     }
  }

  /*
  public void syncFromDB(LobInterface newObject)
  {
     if (newObject != null) 
     {
        BaseLobDomain old = (BaseLobDomain)newObject;
        syncLob(old.lob);
        mData     = old.mData;
        xAct      = old.xAct;

        if (inStream != null) 
        {
           try
           {
              inStream.close();
           }
           catch (IOException ioe)
           {
   
           }
           inStream = null;
        }
        closeOutputStream();
     }
  }
  */

  public void syncServerLob(LobInterface oldObj)
  {
     if (oldObj != null) 
     {
        BaseLobDomain old = (BaseLobDomain)oldObj;
        //if data was pushed in via memory stream, then this would be 
        //a new lob data, so ignore syncing.
        if (mNeedsServerSync) 
        {
           //I was serialized from a client.
           syncLob(old.lob);
           mData     = old.mData;
           inStream  = old.inStream;
           outStream = old.outStream;
           mDataModified = old.mDataModified;
           mNeedsServerSync = false;
        } 
        else if (old.xAct != null && !old.mDataModified && !mDataModified) 
        {
           syncLob(old.lob);
           mData     = null;
           mDataModified = false;
           if (inStream != null) 
           {
              try
              {
                 inStream.close();
              }
              catch (IOException ioe)
              {
      
              }
              inStream = null;
           }
           closeOutputStream();
        }
        
        //these could carry forward.
        mOwner    = old.mOwner;
        xAct      = old.xAct;
        mClient   = old.mClient;
        relIdx    = old.relIdx;
     }
  }

  public long getSize()
  {
     //need to implement this.
     return -1;
  }

  public static Method getInvokeDomainMethod()
  {
     try
     {
        Class implCls = Class.forName(CLIENT_APPMODULE_CLASS);
        //invokeDomainMethod(Row row, String attrId, String methodName, String[] clzNames, Object[] args) 
        Method cons = implCls.getMethod("invokeDomainMethod", new Class[] {
                                                          oracle.jbo.Row.class,
                                                          java.lang.String.class, 
                                                          Boolean.TYPE,
                                                          java.lang.String.class, 
                                                          java.lang.String[].class,
                                                          java.lang.Object[].class});
        return cons;
     }
     catch (Exception e)
     {
        throw new JboException(e);
     }

  }

  public void closeOutputStream()
  {
     if (outStream != null)
     {
        try
        {
           outStream.flush();
           outStream.close();
        }
        catch (Exception e)
        {
           //ignore
           Diagnostic.printStackTrace(e);
        }
        outStream = null;
     }
  }

  class BlobOutputStream extends ByteArrayOutputStream
  {
     BlobOutputStream() 
     {
        super(128);
     }

     BlobOutputStream(int size) 
     {
        super(size);
     }
    
     synchronized byte[] getStorage()
     {
        return buf;
     }

  }
}




