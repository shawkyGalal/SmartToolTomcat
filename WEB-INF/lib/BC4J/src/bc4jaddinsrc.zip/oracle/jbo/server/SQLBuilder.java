/*
 * @(#)SQLBuilder.java
 *
 * Copyright 1999-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.server;

import com.sun.java.util.collections.HashMap;
import com.sun.java.util.collections.ArrayList;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.util.Vector;
import javax.sql.DataSource;
import oracle.jbo.JboException;
import oracle.jbo.RowSet;
import oracle.jbo.Transaction;
import oracle.jbo.domain.DataCreationException;

// import java.sql.CallableStatement;
/**
 * <b>Internal:</b> <em>Applications should not use this interface.</em>
 * <p>
 * <b>Note:</b> This interface is subject to change.
 * <p>
 * This interface is used by View Objects to construct SQL statements
 * that create, retrieve, update and delete table rows based
 * on the state of the cache.
 * @since JDeveloper 3.0
 */
public interface SQLBuilder
{
   // published interface constants
   // TODO: wrap theses in a typesafe constant class
   public static final int    DML_INSERT = 1;
   public static final int    DML_UPDATE = 2;
   public static final int    DML_DELETE = 3;

   public static final int    BINDING_STYLE_UNKNOWN = -1;
   public static final int    BINDING_STYLE_JDBC = 0;
   public static final int    BINDING_STYLE_ORACLE = 1;

   // Version of the pluggable SQLBuilder Implementation
   /**
    * Gets a string describing the version of this implentation
    * of this interface.
    */
   public String getVersion();

   /**
    * returns a string uniquely identifying this type of
    * SQLBuilder. Examples are: "Oracle", "OLite", "SQL92"
    */
   public String getDbType();

   /**
    * Returns a String identifying the preferred type map to use.
    */
   public String getTypeMapName();

   /**
    * Returns the name of default PersistManager class name.
    */
   public String getPersistManagerClassName();
   
   /**
    * returns a constant identifying the best binding
    * style for this sort of SQL (see the BINDINGSTYLE constants)
    */
   public int getDefaultBindingStyle();

   // Driver Methods
   /**
    * Registers the JDBC driver associated with this type of
    * JDBC connection. 
    * @throws SQLException
    */
   public void doRegisterDefaultDriver()
      throws SQLException;

   // Entity methods
   /**
    * Performs the appropriate SQL Data Manipulation Language (DML)
    * operations on the database to reflect an update, delete or
    * insert operation on an Entity Object.
    * <p>
    * <b>Note:</b> this method is subject to change.
    * @param enrt the Entity Object.
    * @param operation  one of <tt>DML_INSERT</tt>, <tt>DML_UPDATE</tt>, or <tt>DML_DELETE</tt>.
    * @param e the transaction.
    */
   public void doEntityDML(EntityImpl enrt,  int operation, TransactionEvent e);

   public StringBuffer buildInsertStatement(EntityImpl entityContext,
                                            AttributeDefImpl[] cols,
                                            AttributeDefImpl[] retrCols,
                                            AttributeDefImpl[] retrKeyCols,
                                            boolean batchMode);

   public StringBuffer buildUpdateStatement(EntityImpl entityContext,
                                               AttributeDefImpl[] cols,
                                               AttributeDefImpl[] retrCols,
                                               AttributeDefImpl[] retrKeyCols,
                                               boolean batchMode);

   public StringBuffer buildDeleteStatement(EntityImpl entityContext);

   public void buildSelectString(DBTransactionImpl trans,
                                    StringBuffer buffer, 
                                    String sourceName,
                                    String sourceAlias,
                                    AttributeDefImpl[] attrs,
                                    boolean withIntoClause,
                                    int bindingStyle);

   public int bindInsertStatement(EntityImpl entityContext,
                                   PreparedStatement stmt,
                                   AttributeDefImpl[] cols,
                                   AttributeDefImpl[] retrCols,
                                   AttributeDefImpl[] retrKeyCols,
                                   HashMap retrList,
                                   boolean batchMode) throws SQLException;

   public int bindUpdateStatement(EntityImpl entityContext,
                                   PreparedStatement stmt,
                                   AttributeDefImpl[] cols,
                                   AttributeDefImpl[] retrCols,
                                   AttributeDefImpl[] retrKeyCols,
                                   HashMap retrList,
                                   boolean batchMode) throws SQLException;

   public int bindWhereClause(EntityImpl entityContext, 
                              PreparedStatement stmt, 
                              Object rowid,
                              int bindIndex) throws SQLException;
                              
   public int bindWhereClause(EntityImpl entityContext, 
                              PreparedStatement stmt, 
                              AttributeDefImpl[] retrKeyCols,
                              Object rowid,
                              int bindIndex) throws SQLException;

   /**
    * Perform the appropriate SQL operations to execute a select operation
    * on an Entity Object.
    * <p>
    * <b>Note:</b> this method is subject to change.
    * @param enrt the Entity Object.
    * @param lock if <tt>true</tt>, a "SELECT for UPDATE" statement is used.
    */
   public void doEntitySelect(EntityImpl e,  boolean lock);

   /**
    * Performs the equivalent of <tt>setRowPrefetch()</tt> on a statement.
    */
   public void doStatementSetRowPrefetch(Statement ps, int prefetchSize)
      throws SQLException;

   /**
    * Sets the binding style for the statement.
    */
   public void doStatementSetBindingStyle(Statement ps, int bindingStyle);
   public void doStatementSetBindingStyleDefault(Statement ps);

   /**
    * Performs the equivalent of <tt>defineColumnType()</tt> on a prepared statement.
    */
   public void doPreparedStatementDefineColumnType(PreparedStatement ps, int colnum, int sqltype)
      throws SQLException;

   /**
    * Performs the equivalent of <tt>clearDefines()</tt> on a prepared statement.
    */
   //public void doPreparedStatementClearDefines(PreparedStatement ps)
   //   throws SQLException;

   public void doPreparedStatementDefines(PreparedStatement ps, AttributeDefImpl attrs[]);


   /**
    * Populates the system typemap table with entries appropriate
    * for the JDBC implementation.
    */
   public void populateJboTypeMapEntries();

   /**
    * Tests if a type is numeric.
    */
   public boolean isNumericType(int type); //TODO: should be able to make this generic within typemap
   /**
    * Tests if a type is character
    */
   public boolean isCharType(int type); //TODO: should be able to make this generic within typemap

   //AttributeDef methods
   /**
    * Loads an object from a result set.
    * <p>
    * <b>Note:</b> this method is subject to change.
    * @param theTypeFactory  a custom factory to be used for constructing new instances.
    * @param index  the index of the object to be loaded.
    */
   public Object doLoadFromResultSet(Object theTypeFactory, Object theElemFactory,
      Class theJavaType, byte attrLoad, ResultSet rs,
      int index, DBTransactionImpl trans)
      throws DataCreationException;

   /**
    * Loads an array of objects from a result set.
    * <p>
    * <b>Note:</b> this method is subject to change.
    * @param index  the index of the object to be loaded.
    */
   public Object[] doLoadBulkFromResultSet(AttributeDefImpl[] attrs,
                                           int attrIndex, ResultSet rs,
                                           int rsIndex, DBTransactionImpl trans)
      throws DataCreationException;

   /**
    * Loads an object from a result set.
    * <p>
    * <b>Note:</b> this method is subject to change.
    * @param theTypeFactory  a custom factory to be used for constructing new instances.
    * @param index  the index of the object to be loaded.
    */
   public Object doLoadFromStatement(Object theTypeFactory, Object theElemFactory,
      Class theJavaType, PreparedStatement ps,
      int index, Transaction trans)
      throws DataCreationException;

   /**
    * issue a SAVEPOINT - if possible
    * <p>
    * @param id = the id for a savepoint
    */
   public void setSavepoint(Connection conn, String id)
      throws SQLException;
   
   /**
    * rollback to SAVEPOINT - if possible
    * <p>
    * @param id = the id for a savepoint
    */
   public void rollbackToSavepoint(Connection conn, String id)
      throws SQLException;

   /**
    * release SAVEPOINT - if possible
    * <p>
    * @param id = the id for a savepoint
    */
   public void releaseSavepoint(Connection conn, String id)
      throws SQLException;

   /**
    * Generates a ROWID for an Entity Object.
    * <p>
    */
   /*
    * TODO: this might not always be possible, so the method needs
    * to throw something identifiable.
    */
   public Object generateRowID(EntityImpl e);

   /**
    * Generates a PK-Based REF for an Entity Object.
    * This is used for an object table.
    */
   public Object generatePKBasedRef(EntityImpl entityContext);

   /**
    * Generates an object Ref and OID for an Entity Object.
    * This is used for an object table.
    */
   public Object[] generateRefAndOID(EntityImpl e);

   /**
    * Provides streaming support.
    */
   public boolean isStreamType(int sqlTypeId);

   /**
    * return a list of tables visible in this connection
    */
   public ArrayList getTables(Connection conn, String defaultUserName, String userName, boolean bTable, boolean bAlias, boolean bView, boolean bSnap)
   throws Exception;

   /**
    * return a list of tables visible in this connection
    */
   public Vector getTableList(Connection conn, String defaultUserName, String userName, boolean bTable, boolean bAlias, boolean bView, boolean bSnap)
   throws Exception;

   /**
    * return a list of schemas for this database
    * (note that for Oracle this is synonymous with users)
    */                       
   public ArrayList getSchemas(Connection conn)
   throws Exception;

   /**
    * return a list of schemas for this database
    * (note that for Oracle this is synonymous with users)
    */
   public Vector getSchemaList(Connection conn)
   throws Exception;

   /**
    * return vector of with constraint details for this table
    * where each detail is in a String array with this structure:
    * 0  String owner <p>
    * 1  String constraint_name <p>
    * 2  String constraint_type <p>
    * 3  String table_name <p>
    * 4  String search_condition <p>
    * 5  Integer delete_rule (cascade) <p>
    * 6  Integer status (enabled) <p>
    * 7  Integerdeferrable <p>
    * 8  Integer deferred <p>
    * 9  Integer validated <p>
    * 10 String column_name <p>
    * 11 Integer position <p>
    * 12 String fkname<p>
    * 13 String fkother <>
    */
   public ArrayList getConstraintsList(Connection conn, String catalog,String schema,String table)
   throws SQLException;

   public Vector getConstraints(Connection conn, String catalog,String schema,String table)
   throws SQLException;

   /**
    * unroll any synonyms that may be present, and get
    * the real objectname
   */
   public String getBaseTable(Connection conn, String schema, String name)
   throws SQLException;

   public void executeBatch(PreparedStatement stmt)
   throws SQLException;

   public DataSource lookupDataSource(String nsUrl, 
                                      String nsUser, 
                                      String nsPasswd,
                                      String dataSourceName) throws JboException;

   public boolean isDataSourceJTABased(DataSource ds) ;

   public ViewCriteriaAdapter getViewCriteriaAdapter();

   public Timestamp getCurrentDbTime(Connection conn);

   public abstract String getCreateSequenceInsertTriggerSQL(String triggerName, String tableName,  
                                                            String sequenceName, String colName);
   
   public abstract String getCreateSequenceSQL(String sequenceName, int startVal);

   public abstract String getDropSequenceSQL(String sequenceName);

   public String getDropTableSQL(String dbObjectName);

   public boolean isDisplayBindValueUI();

   public void doRefreshSQL(EntityImpl entityContext, int operation, AttributeDefImpl[] columns, AttributeDefImpl[] keyCols);

   public boolean supportsReturningClause();

   public String getQueryHitCountSQL(RowSet rs);

   public boolean supportsRowNumQuery();

   public boolean isConnectionAlive(Connection conn);

   public void buildWhereClause(EntityImpl entityContext, StringBuffer buffer, AttributeDefImpl[] keyCols, Object rowid);
   
} // interface SQLBuilder


