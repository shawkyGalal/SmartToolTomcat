/*
 * @(#)JboCompareValidatorBeanInfo.java
 *
 * Copyright 1998-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.server.rules;

import java.beans.BeanDescriptor;
import java.beans.IntrospectionException;
import java.beans.PropertyDescriptor;
import java.beans.SimpleBeanInfo;
import oracle.jbo.server.rules.CompareTypeEditor;
import oracle.jbo.server.rules.CompareValidatorCustomizer;

/*
 * This class implements an example validation rule beaninfo.
 *
 * @version PUBLIC
 * @see JboCompareValidator
 */
/**
 * The external interface for <code>JboCompareValidator</code>.
 * <p>
 * @see JboCompareValidator
 * @since Jdeveloper 3.0
 */
public class JboCompareValidatorBeanInfo extends SimpleBeanInfo
{
   private final static Class myClass = JboCompareValidator.class;

  /**
    * Describes external access to <code>JboCompareValidator</code> methods.
    * <p>
    * @return an array of descriptors for the following properties,
    * which are accessible through
    * <code>set</code><em>Property</em> and <code>get</code><em>Property</em> methods.
    * <ul><code>
    * <li>Description</li>
    * <li>Inverse</li>
    * <li>Type</li>
    * <li>RhsValue</li>
    * </code></ul>
    */
   public PropertyDescriptor[] getPropertyDescriptors()
   {
      try
      {
         PropertyDescriptor pdDesc = new PropertyDescriptor("description", myClass);
         PropertyDescriptor pdInverse = new PropertyDescriptor("inverse", myClass);
         PropertyDescriptor pdType = new PropertyDescriptor("type", myClass);
         pdType.setPropertyEditorClass(CompareTypeEditor.class);
         PropertyDescriptor pdRhs = new PropertyDescriptor("rhsValue", myClass);

         PropertyDescriptor[] list = {pdDesc, pdInverse, pdType, pdRhs };
         return list;
      }
      catch(IntrospectionException ie )
      {
         throw new Error(ie.toString());
      }
   }

  /**
   * Identifies this bean's validator and customizer classes.
   * @return a bean descriptor.
   */
  public BeanDescriptor getBeanDescriptor() {
     return new BeanDescriptor( JboCompareValidator.class,
                                CompareValidatorCustomizer.class );
  }
}
