/*
 * @(#)JboBaseValidator.java
 *
 * Copyright 1998-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.server.rules;

import oracle.jbo.CSMessageBundle;
import oracle.jbo.JboException;
import oracle.jbo.common.StringManager;
import oracle.jbo.server.AttributeDefImpl;
import oracle.jbo.server.Entity;
import oracle.jbo.server.RowImpl;
import oracle.jbo.server.EntityDefImpl;
import oracle.jbo.server.ValidationBeanLoader;
import oracle.jbo.server.util.PropertyChangeEvent;

/**
 * The superclass for all pre-defined validators.
 * <p>
 * This class implements the basic functionality of storing the value
 * of either an attribute to be validated, or the entity or application module
 * reference on which validation is to be invoked.
 *
 * Subclasses must provide <code>validateValue</code>, which performs the actual
 * validation test.
 *
 * @since Jdeveloper 3.0
 */
abstract public class JboBaseValidator
{
   boolean mbInverse = false;
   transient protected Object mLValue;
   transient Object mSource;
   String mDescription;
   String mMsgId;
   AttributeDefImpl mValidatingAttr;
   String mValidatingAttrName;
   public final String MSG_BUNDLE_SUFFIX = "MsgBundle";

   boolean mInit = false;

   protected void initialize()
   {
      if (mValidatingAttr == null && mValidatingAttrName != null)
      {
         oracle.jbo.StructureDef def = ((RowImpl)mSource).getStructureDef();
         mValidatingAttr = (AttributeDefImpl)def.findAttributeDef(mValidatingAttrName);
      }
   }

    /**
      * Invokes <code>validateValue()</code> on a value contained in a constrained property.
      * <p>.
      * @param evObj  a <code>PropertyChangeEvent</code> containing a property
      * to be validated.
      * @throws JboException if validation fails, with <code>CSMessageBundle</code>
      * error code <code>EXC_VAL_ATTR_SET_FAILED</code>.
      */
    /*
      * Invokes validateValue after setting the left-hand-side
      * operand of the expression to compare.
      */
    public void vetoableChange(PropertyChangeEvent evObj)
              throws JboException
    {
       //initialize to false meaning failure, 
       //just in case validateValue throws.
       boolean bval = false;
          
       try {

          mSource = evObj.getSource();
          if (!mInit)
          {
             initialize();
          }
          
          if (mValidatingAttr != null && !mValidatingAttr.getName().equals(evObj.getPropertyName()))
          {
             setNewValue(((RowImpl)mSource).getAttribute(mValidatingAttr.getIndex()));
          }
          else
          {
             setNewValue(evObj.getNewValue());
          }

          bval = validateValue(mLValue);
          //thow when,
          //   either inverse is true and bval is true
          //   or inverse is false and bval is false
          if(mbInverse == bval)
          {
             raiseException(null, evObj);
          }
       }
       catch( JboException ve )
       {
          //thow when,
          //   inverse is true and exception is thrown due to validation failure
          if(mbInverse == bval)
          {
             throw ve;
          }
       }
       catch( Exception e )
       {
          raiseException(e, evObj);
       }
    }

    protected void raiseException(Exception e, PropertyChangeEvent evObj)
    {
       Class clz = CSMessageBundle.class;
       String errMsgId = CSMessageBundle.EXC_VAL_ATTR_SET_FAILED;

       if (mMsgId != null) 
       {
          EntityDefImpl edi = mValidatingAttr.getEntityDef();
          if (edi != null) 
          {
             clz = edi.getMessageBundleClass();
             errMsgId = mMsgId;
          }
       }
       ValidationBeanLoader.raiseException(clz,
                               errMsgId,
                               mSource,
                               (mValidatingAttr == null)
                               ? evObj.getPropertyName()
                               : mValidatingAttr.getName(),
                               mLValue, null, e);
    }

    /**
      * Validates an object.
      * <p>
      * Subclasses must implement this method.
      * @param value the object to be validated.
      * @return <code>true</code> if the object is valid.
      * @throws Exception if validation cannot be performed.
     */
    abstract public boolean validateValue(Object value) throws Exception;

     /**
       * When the newValue is an Entity, get the attribute's value
       * by using the get<em>Attribute</em> method on the entity. Otherwise,
       * newValue should be a value to compare in this validator.
       * @param newValue either the attribute's value or a value to use to compare
       * in the validator.
       */
    protected void setNewValue(Object newValue) throws Exception
    {
       if( newValue instanceof Entity )
       {
          //get the method of <mMethodName> and get it's value.
          mLValue = ((Entity)newValue).getAttribute(mValidatingAttr.getIndex());
       }
       else
       {
          mLValue = newValue;
       }
    }

    public void setValidatingAttributeName(String name)
    {
       mValidatingAttrName = name;
    }

    /**
      * Sets the validating attribute.
      * <p>
      * @param attr an attribute.
      */
    public void setValidatingAttribute( AttributeDefImpl attr )
    {
       mValidatingAttr = attr;
    }

    /**
      * Sets the validating attribute by name.
      * <p>
      * This variant is used when the validator is
      * attached to an entity, rather than to an attribute.
      * @param beanInfo  the entity containing the attribute.
      * @param str an attribute name as a string.
      */
    public void setValidatingAttribute( EntityDefImpl beanInfo, String str )
    {
       mValidatingAttr = beanInfo.getAttributeDefImpl(str);
    }

    /**
    * Allows the logic of this validator to be inverted.
    * @param bInverse <code>true</code> if the validation result is to be inverted,
    *  and <code>false</code> if the validation result is not to be inverted.
    **/
    public void setInverse( boolean bInverse )
    {
       mbInverse = bInverse;
    }

    /**
    * Reports whether the logic of this validator is inverted.
    * @return <code>true</code> if the validation result is inverted, and
    *   <code>false</code> if the validation result is not inverted.
    **/
    public boolean getInverse( )
    {
       return mbInverse;
    }

    /**
    * Gets the textul description of this validator.
    * @return  a documentation string.
    **/
   public String getDescription()
   {
      return mDescription;
   }

    /**
    * Sets the textul description of this validator using a specified string.
    * @param description  a documentation string.
    **/
   public void setDescription( String description)
   {
      mDescription = description;
   }

    /**
    * Sets the textul description of this validator using locale message code.
    * @param description  a message code.
    **/
   void setDefaultDescription(String descId)
   {
      mDescription = StringManager.getString("oracle.jbo.CSMessageBundle",
                         descId,
                         null,
                         null);
   }

   public String getErrorMsgId()
   {
      return mMsgId;
   }

   public void setErrorMsgId(String msgId)
   {
      mMsgId = msgId;
   }
}
