/*
 * @(#)JboVOListValidator.java
 *
 * Copyright 1998-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.server.rules;

import java.util.Vector;
import oracle.jbo.Row;
import oracle.jbo.server.Entity;
import oracle.jbo.server.EntityImpl;
import oracle.jbo.server.ViewObjectImpl;

/**
 * A validator that tests for the presence of a literal value in a
 * list of database values.
 *
 * A View Object of at least two columns must be specified.  The list of values is
 * obtained by invoking the View Object's query, and taking the values from the
 * second column of the result.
 * @since Jdeveloper 3.0
 */
/*
 * List validator that gets its list from executing a pre-defined QO.
 * <p>
 * Note : For now, the QO should have atleast two columns, the first
 * a primary key and the second column is used as the column defining
 * the LOV. An attribute value is validated against the second
 * column. This will however change, when, the UI allows specifying
 * which column from a query to match.
 *
 * @version PUBLIC
 */
public class JboVOListValidator extends JboListValidator
{
    String mQueryName;
    String mAttrName;
    ViewObjectImpl mQueryInfoRef;

    /**
     * Creates an uninitialized list validator.
     * <p>
     * Invoke <code>setList()</code> to provide a list of comparison values.
     **/
    public JboVOListValidator()
    {
       super(false);
       mOwner = null; //no owner //only for use with BeanEditors.
    }

    /**
     * Creates a list validator.
     * <p>
     * @param inverse  if <code>true</code> the logic of this validator's
     * test is inverted.
     * @param vec a list of comparison values.
     **/
    /*
    * Setup the validator with the reference to its owner beaninfo
    * to get the  application reference and the string that defines
    * the fully-qualified name of a QO to execute (e.g.
    * "JboSession.ApplicationModule1.Query1")
    **/
    public JboVOListValidator( boolean bInverse, Object owner, String str )
    {
       super(bInverse);
       //mbInverse = bInverse;
       mOwner = owner;
       setVOAttrName(str);
    }

    /**
      * Gets this validator's list of values.
      * <p>
      * This method executes the View Object's query and extracts the second column
      * of the result.
      * @return a vector containing the values from the second column of the result.
      */
    public Vector getList( )
    {
       //execute the QO and return the list.
       mList = new Vector();
       mQueryInfoRef = getQO();
       if( mQueryInfoRef != null )
       {
          Row query;
          Object obj;
          int attrIndex = -1;
            
          mQueryInfoRef.reset();
          while( mQueryInfoRef.hasNext() )
          {
             query = (Row)mQueryInfoRef.next();
             if( attrIndex == -1 )
             {
                attrIndex = query.getAttributeIndexOf(getVOAttrName());
             }
             mList.addElement(query.getAttribute(attrIndex));
          }
       }
       mQueryInfoRef.remove();
       return mList;
    }

    /**
    * Private utitlity method that gets the QO reference by getting
    * the application and parsing the string, looking up the
    * container hierarchy. This should be replaced by a global
    * name-space call.
    **/
    private ViewObjectImpl getQO()
    {
      if( mSource instanceof Entity )
       {
          return (ViewObjectImpl)((EntityImpl)mSource).getDBTransaction().createViewObject(mQueryName);
       }
       return null;
    }

    /**
     * Gets the name of this validator's View Object.
     * @return the View Object's name.
     * @see JboQOListValidator#setQueryAttrName
     */
    public String getVOName()
    {
       return mQueryName;
    }

    /**
     * Gets this validator's attribute name.
     * @return the attribute name.
     * @see JboQOListValidator#setQueryAttrName
     */
    public String getVOAttrName()
    {
       return mAttrName;
    }

    /**
     * Sets this validator's View Object and attribute names.
     * @param voname  the qualified name of the attribute, consisting of a series
     * of component names separated by <code>"."</code> characters.  The part
     * preceding the final dot becomes the View Object name, and the part
     * after the final dot becomes the attribute name.
     */
    public void setVOAttrName(String voname)
    {
       //name looks like : package1.AppModule.View.DeptView.loc
       // so viewobject name should be package1.AppModule.DeptView
       //  and attribute name is loc.
       
       int lastDot = voname.lastIndexOf(".");
       mAttrName = voname.substring(lastDot+1);
       mQueryName = voname.substring( 0, lastDot );
    }

    /**
    * <b>Internal:</b> <em>For debugging purposes only.</em>
    * <p>
    */
     public String toString()
     {
        return new String("VO List("+mQueryName+")");
     }

}
