/*
 * @(#)JboGenericValidatorBeanInfo.java
 *
 * Copyright 1998-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.server.rules;

import java.beans.IntrospectionException;
import java.beans.PropertyDescriptor;
import java.beans.SimpleBeanInfo;

/**
 * The external interface for <code>JboGenericValidator</code>.
 * <p>
 * @see JboGenericValidator
 * @since Jdeveloper 3.0
 */
public class JboGenericValidatorBeanInfo extends SimpleBeanInfo
{
   private final static Class myClass = JboGenericValidator.class;
   private final static Class listEditorClass = ValueListEditor.class;

  /**
    * Describes external access to <code>JboGenericValidator</code> methods.
    * <p>
    * @return an array of descriptors for the following properties,
    * which are accessible through
    * <code>set</code><em>Property</em> and <code>get</code><em>Property</em> methods.
    * <ul><code>
    * <li>Description</li>
    * <li>List</li>
    * <li>Min</li>
    * <li>Max</li>
    * <li>Prec</li>
    * </code></ul>
    */
   public PropertyDescriptor[] getPropertyDescriptors()
   {
      try
      {
         PropertyDescriptor pdList = new PropertyDescriptor("list", myClass);
         pdList.setPropertyEditorClass( listEditorClass );
         PropertyDescriptor pdMin = new PropertyDescriptor("min", myClass);
         PropertyDescriptor pdMax = new PropertyDescriptor("max", myClass);
         PropertyDescriptor pdPrec = new PropertyDescriptor("prec", myClass);
         PropertyDescriptor pdDesc = new PropertyDescriptor("description", myClass);
         PropertyDescriptor[] list = {pdDesc, pdList, pdMin, pdMax, pdPrec};
         return list;
      }
      catch(IntrospectionException ie )
      {
         throw new Error(ie.toString());
      }
   }
}
