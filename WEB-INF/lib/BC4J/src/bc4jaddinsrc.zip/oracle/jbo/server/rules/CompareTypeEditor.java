/*
 * @(#)CompareTypeEditor.java
 *
 * Copyright 1998-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.server.rules;

/*
 * @(#)CompareTypeEditor.java	0.0
 * 
 * Copyright (c) 1999 Oracle Corporation All Rights Reserved.
 * 
 * This software is the confidential and proprietary information of 
 * Oracle Corporation ("Confidential  Information").  You shall not
 * disclose such Confidential  Information and shall use it only in
 * accordance with  the terms of  the license agreement you entered 
 * into with Oracle.
 * 
 * ORACLE MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY 
 * OF THE  SOFTWARE,  EITHER  EXPRESS  OR  IMPLIED, INCLUDING  BUT NOT 
 * LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, OR NON-INFRINGEMENT. ORACLE SHALL NOT BE LIABLE
 * FOR  ANY  DAMAGES  SUFFERED  BY  LICENSEE  AS  A  RESULT  OF USING, 
 * MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 * 
 * CopyrightVersion 0.0_beta
 * 
 */
/**
 * An example validation property editor.
 * <p>
 * This class supports GUIs that provide for the selection of a relation operation.
 * @since Jdeveloper 3.0
 */
public class CompareTypeEditor extends BaseEnumEditor
{
    private final String[] tags = { "Equals",
                                   "LessThan",
                                   "GreaterThan",
                                   "LessThanEqualTo",
                                   "GreaterThanEqualTo"
                                 };

   protected String getEnumName()
   {
      return "JboCompareValidator";
   }

  /**
    * Constructs an array of value tags from the enumerated symbols.
    * <p>
    * @return the array of value tags.
    */
   public String[] getTags()
   {
      return tags;
   }
}

