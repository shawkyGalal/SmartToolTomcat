/*
 * @(#)JboSQLCompareValidatorBeanInfo.java
 *
 * Copyright 1998-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.server.rules;

import java.beans.IntrospectionException;
import java.beans.PropertyDescriptor;
import java.beans.SimpleBeanInfo;
import oracle.jbo.server.rules.CompareTypeEditor;

/**
 * The external interface for <code>JboSQLCompareValidator</code>.
 * <p>
 * @see JboSQLCompareValidator
 * @since Jdeveloper 3.0
 */
public class JboSQLCompareValidatorBeanInfo extends SimpleBeanInfo
{
   private final static Class myClass = JboSQLCompareValidator.class;

  /**
    * Describes external access to <code>JboSQLCompareValidator</code> methods.
    * <p>
    * @return an array of descriptors for the following properties,
    * which are accessible through
    * <code>set</code><em>Property</em> and <code>get</code><em>Property</em> methods.
    * <ul><code>
    * <li>Description</li>
    * <li>Inverse</li>
    * <li>Type</li>
    * <li>RhsValue</li>
    * </code></ul>
    */
   public PropertyDescriptor[] getPropertyDescriptors()
   {
      try
      {
         PropertyDescriptor pdDesc = new PropertyDescriptor("description", myClass);
         PropertyDescriptor pdInverse = new PropertyDescriptor("inverse", myClass);
         PropertyDescriptor pdType = new PropertyDescriptor("type", myClass);
         pdType.setPropertyEditorClass(CompareTypeEditor.class);
         PropertyDescriptor pdRhs = new PropertyDescriptor("rhsValue", myClass);
         pdRhs.setDisplayName("SQL");
         PropertyDescriptor[] list = {pdDesc, pdInverse, pdType, pdRhs };
         return list;
      }
      catch(IntrospectionException ie )
      {
         throw new Error(ie.toString());
      }
   }
}
