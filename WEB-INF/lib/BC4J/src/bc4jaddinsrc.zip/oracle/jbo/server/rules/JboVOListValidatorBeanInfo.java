/*
 * @(#)JboVOListValidatorBeanInfo.java
 *
 * Copyright 1998-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.server.rules;

import java.beans.IntrospectionException;
import java.beans.PropertyDescriptor;
import java.beans.SimpleBeanInfo;

/**
 * The external interface for <code>JboVOListValidator</code>.
 * <p>
 * @see JboVOListValidator
 * @since Jdeveloper 3.0
 */
public class JboVOListValidatorBeanInfo extends SimpleBeanInfo
{
   private final static Class myClass = JboVOListValidator.class;

  /**
    * Describes external access to <code>JboVOListValidator</code> methods.
    * <p>
    * @return an array of descriptors for the following properties,
    * which are accessible through
    * <code>set</code><em>Property</em> and <code>get</code><em>Property</em> methods.
    * <ul><code>
    * <li>Description</li>
    * <li>Inverse</li>
    * <li>queryName</li>
    * </code></ul>
    */
   public PropertyDescriptor[] getPropertyDescriptors()
   {
      try
      {
         PropertyDescriptor pdDesc = new PropertyDescriptor("description", myClass);
         PropertyDescriptor pdInverse = new PropertyDescriptor("inverse", myClass);
         PropertyDescriptor pdQO = new PropertyDescriptor("queryName", myClass);
         
         PropertyDescriptor[] list = {pdDesc, pdInverse, pdQO };
         return list;
      }
      catch(IntrospectionException ie )
      {
         throw new Error(ie.toString());
      }
   }
}
