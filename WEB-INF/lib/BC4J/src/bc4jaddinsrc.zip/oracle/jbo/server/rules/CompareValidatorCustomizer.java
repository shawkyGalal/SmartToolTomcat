/*
 * @(#)CompareValidatorCustomizer.java
 *
 * Copyright 1998-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.server.rules;

import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.Panel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.beans.Customizer;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import oracle.jdeveloper.layout.GridBagConstraints2;

/**
 * An example JavaBean customizer.
 * <p>
 * This example provides a JavaBean editor for the
 * <code>JboCompareValidator</code> JavaBean.  This class is installed at
 * design-time in the <code>ValidatorType</code> wizard.
 * <p>
 * Note that JavaBean customizers must implement the
 * <code>java.beans.Customizer</code> interface.
 *
 * @see JboCompareValidator
 * @see JboCompareValidatorBeanInfo
 * @since Jdeveloper 3.0
 */
public class CompareValidatorCustomizer extends Panel
             implements Customizer, ItemListener,
                        ActionListener, DocumentListener
{

  //stores validator bean instance.
  Object mVal;

  //note: ability to handle only one listener implemented in this
  //example. It covers the basic editing needs. However to be
  //fully scalable, this should be a list of listeners.
  PropertyChangeListener listener;

  //note the indexes of these strings in the list is important
  //it should match the OP_xxxx ids in JboCompareValidator.
  final String STR_EQUALTO         = "Equals";
  final String STR_LESSTHAN        = "Less than";
  final String STR_GREATERTHAN     = "Greater than";
  final String STR_LESSEQUALTO     = "Less or Equal to";
  final String STR_GREATEREQUALTO  = "Greater or Equal to";

  //UI components.
  JCheckBox chkInverse = new JCheckBox();
  JComboBox operList = new JComboBox();
  JTextField rhsText = new JTextField();
  JLabel label1 = new JLabel();
  JLabel label2 = new JLabel();
  GridBagLayout gridBagLayout1 = new GridBagLayout();

  /**
  * Creates and initializes a compare validator customizer.
  **/
  public CompareValidatorCustomizer()
  {
    try {
      jbInit();
      //note the indexes of these strings in the list is important
      //it should match the OP_xxxx ids in JboCompareValidator.
      operList.addItem(STR_EQUALTO       );
      operList.addItem(STR_LESSTHAN      );
      operList.addItem(STR_GREATERTHAN   );
      operList.addItem(STR_LESSEQUALTO   );
      operList.addItem(STR_GREATEREQUALTO);
    }
    catch (Exception e) {
      e.printStackTrace();
    }
  }


  /**
  * Sets the JavaBean instance to be edited, and initializes the editor
  * comonents.
  * @param p0  an instance of <code>JboCompareValidator</code>. Objects of
  * other classes have no effect.
  **/
  public void setObject(Object p0)
  {
     if( p0 instanceof oracle.jbo.server.rules.JboCompareValidator
         && p0 != mVal )
     {
        initializeValidator((JboCompareValidator)p0);
     }
  }

  /**
  * Initialize the editor with values from the given compare-validator.
  **/
  void initializeValidator( JboCompareValidator val )
  {
     mVal = val;
     operList.setSelectedIndex(val.getType());
     chkInverse.setSelected(val.getInverse());
     rhsText.setText((String)val.getRhsValue());
     chkInverse.addActionListener(this);
     operList.addItemListener(this);
     rhsText.getDocument().addDocumentListener(this);
  }

  /**
  * Sets the subscriber to this customizer's <code>PropertyChange</code> events.
  * <p>
  * This class supports only a single listener.
  * @param p0 the new listener.
  **/
  public void addPropertyChangeListener(PropertyChangeListener p0)
  {
     listener = p0;
  }

  /**
  * Removes the subscriber to this customizer's <code>PropertyChange</code> events.
  * <p>
  * @param p0 the listener to be removed.
  **/
  public void removePropertyChangeListener(PropertyChangeListener p0)
  {
     if( listener == p0 )
     {
        listener = null;
     }
  }

  /**
  * Setup the editor components.
  **/
  private void jbInit() throws Exception{
    this.setSize(new Dimension(244, 147));
    chkInverse.setText("Inverse");
    label1.setText("Operation :");
    label2.setText("Compare With :");
    this.setLayout(gridBagLayout1);
    this.add(chkInverse, new GridBagConstraints2(0, 4, 2, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(5, 5, 5, 0), 0, 0));
    this.add(operList, new GridBagConstraints2(0, 1, 4, 1, 1.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.HORIZONTAL, new Insets(0, 5, 5, 5), 0, 0));
    this.add(rhsText, new GridBagConstraints2(0, 3, 4, 1, 1.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.HORIZONTAL, new Insets(0, 5, 5, 5), 0, 0));
    this.add(label1, new GridBagConstraints2(0, 0, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(5, 5, 0, 0), 0, 0));
    this.add(label2, new GridBagConstraints2(0, 2, 3, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0, 5, 0, 0), 0, 0));
  }

  /**
  * raise the PropertyChange Event to all listeners.
  **/
  void raise( PropertyChangeEvent ev )
  {
     if( listener != null )
     {
        listener.propertyChange(ev);
     }
  }

  /**
  * Handles a mouse click in a checkbox.
  * <p>
  * Raises a <code>PropertyChangeEvent</code> when the <b>Inverse</b>
  * box is clicked.
  * @param p0 ignored.
  **/
  public void actionPerformed(ActionEvent p0)
  {
     raise(new PropertyChangeEvent( this,
                              "inverse",
                              new Boolean(chkInverse.isSelected()),
                              new Boolean(!chkInverse.isSelected()) )
          );
  }

  /**
  * Handles a mouse click on a list item.
  * <p>
  * Raises a <code>PropertyChangeEvent</code> when a list item is selected.
  * @param p0 an event identifying the newly selected item
  **/
  public void itemStateChanged(ItemEvent p0)
  {
     if( p0.getStateChange() == ItemEvent.SELECTED )
     {
        raise(new PropertyChangeEvent( this,
                              "type",
                              new Integer(operList.getSelectedIndex()),
                              new Integer(operList.getSelectedIndex()) )
             );
     }
  }

  /**
  * Handles a text-insertion event.
  * <p>
  * Raises a <code>PropertyChangeEvent</code> when text is inserted.
  * @param p0 an event identifying the changed text.
  **/
  public void insertUpdate(DocumentEvent p0)
  {
     changedUpdate(p0);
  }

  /**
  * Handles a text-deletion event.
  * <p>
  * Raises a <code>PropertyChangeEvent</code> when text is deleted.
  * @param p0 an event identifying the changed text.
  **/
  public void removeUpdate(DocumentEvent p0)
  {
     changedUpdate(p0);
  }

  /**
  * Handles a text-change event.
  * <p>
  * Raises a <code>PropertyChangeEvent</code> when text is changed.
  * @param p0 an event identifying the changed text.
  **/
  public void changedUpdate(DocumentEvent p0)
  {
     raise(new PropertyChangeEvent( this,
                           "rhsValue",
                           rhsText.getText(),
                           rhsText.getText() )
          );
  }
}
