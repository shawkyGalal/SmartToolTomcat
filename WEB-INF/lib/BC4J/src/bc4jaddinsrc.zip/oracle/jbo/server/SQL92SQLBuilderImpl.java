/*
 * @(#)SQL92SQLBuilderImpl.java
 *
 * Copyright 2000-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.server;

import oracle.jbo.common.Diagnostic;
import oracle.jbo.common.JboEnvUtil;
import oracle.jbo.common.PropertyConstants;
import oracle.jbo.common.PropertyMetadata;
import oracle.jbo.RowSet;
import oracle.jbo.ViewObject;

/**
 * SQL92-specific implementation of the <tt>SQLBuilder</tt> interface.
 *
 * 26Sep01 - KM - added method for registerDefaultDriver which indirects through
 * the jbo.sql92.jdbcdriver property
 * @since JDeveloper 3.2
 */
public class SQL92SQLBuilderImpl extends BaseSQLBuilderImpl
{
   public static final int ERROR_OLITE_RESOURCE_BUSY_AND_NOWAIT_SPECIFIED = -3264;

   protected static final String ORACLE_ROWID_COLUMN = "ROWID";
   protected static SQLBuilder mSQLBuilderInterface=null;

   /**
    * This is a singleton class
    */
   protected SQL92SQLBuilderImpl()
   {
   }

   /**
    * Gets the singleton instance of this class.
    */
   public static SQLBuilder getInterface()
   {
      if (mSQLBuilderInterface == null)
      {
         mSQLBuilderInterface = (SQLBuilder)(new SQL92SQLBuilderImpl());

         if (Diagnostic.isOn())
         {
            Diagnostic.println(mSQLBuilderInterface.getVersion());
         }
      }
      return mSQLBuilderInterface;
   }

   //--------------------------------------------------------------------------
   // {{ interface SQLBuilder implementation
   //--------------------------------------------------------------------------

   public String getVersion()
   {
      return "SQL92 SQLBuilder version 0.0.0.3";
   }

   public String getDbType()
   {
      return PropertyConstants.SQL92;
   }

   public String getTypeMapName()
   {
      // By default, we use OracleTypeMap with generic domain implementation
      return PropertyConstants.ORACLE;
   }

   public String getPersistManagerClassName()
   {
      return null;
   }

//--------------------------------------------------------------------------
// }} interface SQLBuilder implementation
//--------------------------------------------------------------------------
   
   /**
    * required override: provide the name of the default jdbc driver class
    * KM: 2001-09-26 - now 
   */
   protected String getJDBCDriverClassName()
   {        
      String sDriverClassName = JboEnvUtil.getProperty(PropertyConstants.PN_JDBC_DRIVER_CLASS);

      if (!PropertyConstants.JDBC_ODBC_DRIVER_CLASS.equals(sDriverClassName))
      {
         Diagnostic.println("SQL92: using " + sDriverClassName + " jdbc driver class");
      }

      return sDriverClassName;
   }

   protected String getSqlVariantLockTrailer()
   {
      // Jbo system property jbo.sql92.LockTrailer 
      // sql server: "WITH (HOLDLOCK)";
      // default: "FOR UPDATE"
      return PropertyMetadata.PN_SQL92_LOCKTRAILER.getProperty(true);
   }

   public String getDbTimeQuery()
   {
      return JboEnvUtil.getProperty(PropertyConstants.PN_DBTIME_QUERY);
   }

   public String getDropTableSQL(String dbObjectName)
   {
      if (dbObjectName == null) 
      {
         return null;
      }

      return "DROP TABLE " + dbObjectName;
   }

   public boolean isDisplayBindValueUI()
   {
      return true;
   }

   public String getCreateSequenceInsertTriggerSQL(String triggerName, String tableName,  
                                                   String sequenceName, String colName)   
   {
      return null;
   }
   
   public String getCreateSequenceSQL(String sequenceName, int startVal)
   {
      return null;
   }

   public String getDropSequenceSQL(String sequenceName)
   {
      return null;
   }

   public String getQueryHitCountSQL(RowSet rs)
   {
      ViewObject vo = rs.getViewObject();
      int noUserParams = rs.getWhereClauseParams().length;
      String qry = ((ViewObjectImpl) vo).buildQuery(noUserParams, true /*forRowCount*/);
      
      if (qry == null)
      {
         return null;
      }
      
      String optimizerHint = vo.getQueryOptimizerHint();
      StringBuffer sqlBuffer = new StringBuffer(100);

      if (optimizerHint == null) 
      {
         sqlBuffer.append("SELECT count(1) FROM (");
      }
      else
      {
         sqlBuffer.append("SELECT /*+ ")
                  .append(optimizerHint)
                  .append(" */ count(1) FROM (");
      }
      
      sqlBuffer.append(qry);

      // KM: 19Oct00 - placed a table alias at the end to keep
      // MS SQL*Server happy - it's optional for Oracle
      sqlBuffer.append(") ESTCOUNT");

      return sqlBuffer.toString();
   }
} // class OLiteSQLBuilderImpl
/* end of file */

