/*
 * @(#)DomainOwnerInterface.java
 *
 * Copyright 2000-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.domain;

public interface DomainOwnerInterface
{
   /**
   * Notification method that this domain calls whenever any of its
   * attribute values are about
   * to be modified. This Domain should always notify its owner.
   * @param d the domain being modified.
   */
   void domainToBeModified(DomainInterface d);
}
