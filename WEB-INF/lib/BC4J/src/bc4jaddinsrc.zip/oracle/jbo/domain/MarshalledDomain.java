/*
 * @(#)MarshalledDomain.java
 *
 * Copyright 1998-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.domain;

import oracle.svcmsg.ResponseValues;


public interface MarshalledDomain
{
   // getObjectValues()[0] must be the class name
   ResponseValues marshal();

   // For unmarshalling, we assume that the domain has a constructor
   // that take ResponseValues as its parameter.
}
