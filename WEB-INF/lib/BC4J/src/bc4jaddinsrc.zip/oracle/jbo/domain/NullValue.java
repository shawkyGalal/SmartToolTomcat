/*
 * @(#)NullValue.java
 *
 * Copyright 1999-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.domain;

import java.sql.Types;
import oracle.jbo.Transaction;
import oracle.jbo.common.JboTypeMap;
import oracle.jbo.common.UnknownSQLTypeException;

/**
 * Provides a means of creating and serializing null Domain objects.
 *
 * <p>The zero-parameter constructors for each Domain type produce default objects,
 * rather than null objects.  Use the constructors for this class to produce
 * typed null Domain objects.
 * @since JDeveloper 3.0
 */
public class NullValue implements DomainInterface,
                       java.io.Serializable
{
   static final long serialVersionUID = 6384347001003884267L;

   private int mSQLTypeId;

  /**
    * Creates a default null Domain object, of type <code>VARCHAR</code>.
    */
   public NullValue()
   {
      mSQLTypeId = Types.VARCHAR;
   }

  /**
    * Creates a null value for a specified Domain type.
    *
    * @param sqlTypeId an integer representing a JDBC type.
    * @see "java.sql.TYPES"
    */
   public NullValue(int sqlTypeId)
   {
      //     KM: 2001-10-01 - fix for SQL*Server which doesn't like
      // column identifiers with value zero - zero seems to be used by AssociationDefImpl
      // as a "default" value
      if (sqlTypeId!=0)
      {
         mSQLTypeId = sqlTypeId;
      }
      else
      {
          mSQLTypeId = Types.VARCHAR;
      }
   }
   
  /**
    * Creates a null value for a specified Domain type.
    *
    * @param sqlType an string representing a JDBC type.
    * @see oracle.jbo.common.JboTypeMap
    */
   public NullValue(String sqlType)
   {
      mSQLTypeId = JboTypeMap.sqlTypeToSQLTypeId(sqlType);

      if (mSQLTypeId == Types.NULL)
      {
         throw new UnknownSQLTypeException(sqlType);
      }
   }

  /**
    * Converts <code>this</code> to a JDBC type ID.
    *
    * @value an integer representing a JDBC type.
    * @see "java.sql.TYPES"
    */
   public int getSQLTypeId()
   {
      return mSQLTypeId;
   }
   
  /**
    * Converts <code>this</code> to string naming a JDBC type.
    *
    * @value a string representing a JDBC type.
    * @see oracle.jbo.common.JboTypeMap
    */
   public String getSQLType()
   {
      return JboTypeMap.sqlTypeIdToSQLType(mSQLTypeId);
   }
  
  /**
    *  <b>Internal:</b> <em>Applications should not invoke this method.</em>
    * <p> Converts <code>this</code> to a JDBC object.
    *
    * @value <code>null</code>.
    */
   public Object getData()
   {
      return null;
   }

     /**
    *  <b>Internal:</b> <em>Applications should not invoke this method.</em>
    * <p>
    */
   public void setContext(DomainOwnerInterface owner, Transaction trans, Object ctx)
   {
   }

  /**
    * For testing purposes only: converts <code>this</code> to a string.
    *
    * @value <code>null</code>.
    */
   public String toString()
   {
      return "null";
   }

   /**
    * Generates a hashcode for NullValue.
    *
    * @return the hashcode.
    */
   public int hashCode()
   {
      return -47;
   }
   
  /**
    * Tests <code>this</code> for equality with another object.
    *
    * @param obj  an arbitrary <code>Object</code>.
    * @return <code>true</code> if the parameter is either <code>null</code>,
    * or a <code>NullValue</code> of the same Domain type as <code>this</code>.
    */
   public boolean equals(Object obj)
   {
      if (obj == null)
      {
         return true;
      }

      if (obj instanceof NullValue)
      {
         NullValue nullVal = (NullValue) obj;

         if (nullVal.getSQLTypeId() == getSQLTypeId())
         {
            return true;
         }
      }

      return false;
   }
}
