/*
 * @(#)MutableDomainInterface.java
 *
 * Copyright 2000-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.domain;


/**
 * Implemented by domain classes.
 *
 * <p>Domain classes extend or encapsulate Oracle SQL datatypes. 
 * Domain objects can be converted to the standard JDBC data types.
 *
 * @see TypeFactory
 * @see "JboDomainValidator"
 * @since JDevloper 3.0
 */
public interface MutableDomainInterface extends DomainInterface 
{
   //those domains that should not check for equality on the client
   //side before syncing up the data.
}
