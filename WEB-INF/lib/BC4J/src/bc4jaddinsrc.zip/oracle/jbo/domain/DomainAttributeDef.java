/*
 * @(#)DomainAttributeDef.java
 *
 * Copyright 1999-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.domain;

import java.util.Hashtable;
import oracle.jbo.AttributeDef;
import oracle.jbo.AttributeHints;
import oracle.jbo.AttributeList;
import oracle.jbo.Row;
import oracle.jbo.Transaction;

public class DomainAttributeDef implements AttributeDef
{
   String mName;
   String mColumnName;
   int mIndex;
   Class mJavaType;
   int mSQLType;
   String mSQLTypeName;
   int mScale;
   int mPrecision;
   boolean mIsMandatory;
   String mRefObjDefName;
   

   public DomainAttributeDef(String name, String columnName, int index, 
                      Class javaType, int sqlType, String sqlTypeName,
                      int scale, int precision, boolean isMandatory)
   {
      mName = name;
      mColumnName = columnName;
      mIndex = index;
      mJavaType = javaType;
      mSQLType = sqlType;
      mSQLTypeName = sqlTypeName;
      mScale = scale;
      mPrecision = precision;
      mIsMandatory = isMandatory;
   }
   
   public DomainAttributeDef(String name, String columnName, int index, 
                      Class javaType, int sqlType, String sqlTypeName,
                      int scale, int precision, boolean isMandatory, 
                      String entityDefName)
   {
      this(name, columnName, index, javaType, sqlType,
                         sqlTypeName, scale, precision, isMandatory);
      mRefObjDefName = entityDefName;
   }
   
   
   /**
    * Gets the attribute kind.
    *
    * @return one of the <code>ATTR</code> constants defined for this class.
    */
   public byte getAttributeKind()
   {
      return ATTR_PERSISTENT;
   }


   /**
    * Gets the name of the attribute.
    *
    * @return the name of the attribute.
    */
   public String getName()
   {
      return mName;
   }
   

   /**
    * Gets the name of the database column the attribute represents.
    *
    * @return the name of the column.
    */
   public String getColumnName()
   {
      return mColumnName;
   }


   public String getColumnNameForQuery()
   {
      return getColumnName();
   }


   /**
    * Gets the index of the attribute in the context of a <code>StoreInfo</code>
    * instance.
    *
    * @return the index of the attribute row's definition object.
    */
   public int getIndex()
   {
      return mIndex;
   }
   

   /**
    * Gets the Java class of the object stored for this attribute definition.
    *
    * @return the class of the attribute.
    */
   public Class getJavaType()
   {
      return mJavaType;
   }
   

   /**
    * Gets the JDBC type of the attribute.
    *
    * @return the JDBC type.
    * @see java.sql.Types
    */
   public int getSQLType()
   {
      return mSQLType;
   }
   

   /**
    * Get the scale value of a numeric attribute.
    * @return the scale value for this attribute, if applicable. 
    */
   public int getScale()
   {
      return mScale;
   }
   

   /**
    * Gets the precision of a numeric or string attribute.
    * <p>
    * 'Precision' for a string is the maximum length.
    *
    * @return the precision value for this attribute. 
    */
   public int getPrecision()
   {
      return mPrecision;
   }
   

   /**
    * Tests if an attribute is queriable.
    * <p>
    * Queriable attributes are those that
    * may have a filter condition for the WHERE clause
    * If this method returns false, the attribute will
    * not be used in constructing the WHERE clause
    * of SQL statements to fetch data.
    *
    * @return <code>true</code> if this attribute is queriable.
    */
   public boolean isQueriable()
   {
      return false;
   }


   /**
    * Tests if an attribute can be modified.
    *
    * @return <code>READONLY</code>, <code>UPDATEABLE</code>, or <code>UPDATEABLE_WHILE_NEW</code>.
    */
   public byte getUpdateableFlag()
   {
      return UPDATEABLE;
   }


   /**
    * Tests if an attribute is a Primary Key.
    *
    * @return <code>true</code> if this is either a Primary Key attribute or
    * part of the attributes that constitute the Primary Key for a given row.
    */
   public boolean isPrimaryKey()
   {
      return false;
   }
   

   /**
    * Tests if an attribute does not allow null values.
    * @return <code>true</code> if this attribute cannot store a null value
    **/
   public boolean isMandatory()
   {
      return mIsMandatory;
   }
   
   
   /**
    * Retrieves the specified property, if it exists.
    * @return the named property.
    */
   public Object getProperty(String hintName)
   {
      return null;
   }
   

   public Object refreshProperty(String hintName)
   {
      return getProperty(hintName);
   }


   public String getReferencedObjectDefName()
   {
      return mRefObjDefName;
   }


   /**
    * Gets the table of properties.
    * @return a hashtable of properties.
    */
   public Hashtable getProperties()
   {
      return null;
   }


   /**
   * @deprecated since 9.0.2 use the other getXMLContentNode() .
   **/
   static public org.w3c.dom.Node getXMLContentNode(org.w3c.dom.Document xmlDoc, 
                                                    Object attrValue,
                                                    boolean isCData)
   {
      return getXMLContentNode(xmlDoc, attrValue, isCData, false);
   }
   
   static public org.w3c.dom.Node getXMLContentNode(org.w3c.dom.Document xmlDoc, 
                                                    Object attrValue,
                                                    boolean isCData,
                                                    boolean serialize)
   {
      if (attrValue != null)
      {
         if (serialize && attrValue instanceof XMLDomainWriter) 
         {
            return ((XMLDomainWriter)attrValue).getSerializedDomainXML(xmlDoc);
         }
         if (attrValue instanceof XMLDomainInterface)
         {
            return ((XMLDomainInterface)attrValue).getXMLContentNode(xmlDoc);
         }
         
         //for attribute values that cannot be represented by toString(), how about
         //a from/toXML() method that lets the domain implement it's rendering.
         //Likewise for dtd, we may need an extra method.
         
         return (isCData) 
                ? xmlDoc.createCDATASection(attrValue.toString())
                : xmlDoc.createTextNode(attrValue.toString());
      }

      return null;
   }


   //method to print any attribute def into xml definition.
   //used in AttributeDefImpl and Struct classes.
   static public String printAttrXMLDefinition(AttributeList row, 
                                               String attrTag,
                                               AttributeDef ad,
                                               java.util.Hashtable allDefs, 
                                               java.io.PrintWriter pw, 
                                               boolean bContainees)
   {
      if (allDefs.get(attrTag) == null) 
      {
         Object sValue = row.getAttribute(ad.getIndex());
         String elemStr = "#PCDATA";

         if (sValue instanceof XMLDomainInterface)
         {
            elemStr = ((XMLDomainInterface)sValue).printXMLDefinition(allDefs, pw, bContainees);
         }
         pw.println((new StringBuffer("<!ELEMENT ")
                         .append(attrTag)
                         .append(" (")
                         .append(elemStr)
                         .append(")>"))
                         .toString()
                    );
         allDefs.put(attrTag, attrTag);
      }

      if (!(ad.isPrimaryKey() || ad.isMandatory()))
      {
         attrTag = attrTag + "?";
      }
      return attrTag;
   }

   /**
   * Returns an an instance of the refernced row, given the attribute
   * definition object.
   *
   * The referenced row is returned as an {@link oracle.jbo.Row} object.
   * @param ad the attribute's attribute definition object.
   * @return the row corredsponding to the attribute definition object.
   * @see oracle.jbo.Row
   *
   */
   Row getReferencedObject(Object refDomain, Transaction trans)
   {
      oracle.jbo.server.EntityDefImpl ed = oracle.jbo.server.EntityDefImpl.findDefObject(getReferencedObjectDefName());
      if (ed != null)
      {
         oracle.jbo.server.AttributeListImpl al = new oracle.jbo.server.AttributeListImpl();
         al.setAttribute("REF$", refDomain);
         return ed.findByPrimaryKey((oracle.jbo.server.DBTransaction)trans, ed.createKey(al));
      }
      return null;
   }

   /**
    ** when property support gets added to domains, this function will
    ** return a valid ui hint  implementation.
    **/
   public AttributeHints getUIHelper()
   {
      return null;
   }

   /**
    * Return null;
    */
   public Class getElemType()
   {
      return null;
   }

   /**
    * Return -1;
    */
   public int getElemSQLType()
   {
      return java.sql.Types.NULL;
   }
}
