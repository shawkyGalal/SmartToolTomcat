/*
 * @(#)BlobDomainInterface.java
 *
 * Copyright 1999-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.domain;

import oracle.jbo.Transaction;

/**
 * Provides methods to save data to, and extract data from,
 * LOB domain classes. These methods are implemented by all LOB-based
 * domain classes: {@link oracle.jbo.domain.BlobDomain BlobDomain},
 * {@link oracle.jbo.domain.BFileDomain BFileDomain}, and
 * {@link oracle.jbo.domain.ClobDomain ClobDomain}.
 *
 * <p>Domain classes encapsulate Oracle SQL datatypes.
 * Domain objects can be converted to the standard JDBC data types.
 *
 * @see TypeFactory
 * @see "JboDomainValidator"
 * @since JDevloper 3.0
 */
public interface BlobDomainInterface extends DomainInterface
{
   /**
    * @Obsolete
    * <b>Internal:</b> <em>Applications should not use this method.</em>
    * <p>
    * Loads the actual data of the LOB-type database attribute into memory.
    *
    * <p>The transaction argument is needed to perform an additional query into
    * the database to extract the data.
    * <p>This method does not need to be invoked for a new attribute.
    *
    * @param transaction the {@link oracle.jbo.server.DBTransactionImpl}
    * of the current Application Module.
    */
   void loadFromDatabase( Transaction transaction )
      throws Exception ;

   /**
    * @Obsolete
    * <b>Internal:</b> <em>Applications should not use this method.</em>
    * <p> Saves data in memory to a database LOB-type attribute.
    *
    * <p>The transaction argument is is needed to perform an additional query into
    * the database to write the data.
    * <p>This method does not need to be invoked if this attribute's data
    * has not changed.
    *
    * @param transaction the {@link oracle.jbo.server.DBTransactionImpl}
    * instance of the current Application Module.
    */
   void saveToDatabase( Transaction transaction )
      throws Exception;

      /**
     * <b>Internal:</b> <em>Applications should not use this method.</em>
     * <p>
     * Uses the given transaction context to store data back into the
     * database using the LOB-locator which should
     * be set before this method is invoked.
     */
   void saveToDatabase( Transaction transaction, Object emptySQLObject )
      throws Exception;

     /**
    * <b>Internal:</b> <em>Applications should not use this method.</em>
    *
    */
   void  prepareForDML( Object context );  //this is where you may store the old bytearray.

   //Object getDatumObject();
}
