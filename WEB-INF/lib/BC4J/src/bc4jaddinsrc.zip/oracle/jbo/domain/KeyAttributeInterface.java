/*
 * @(#)KeyAttributeInterface.java
 *
 * Copyright 2000-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.domain;

/**
 * Implemented by domain classes, instances of which could be an attribute 
 * of a oracle.jbo.Key
 * <p>
 * This interface is used by Key serialization to come up with
 * a string representation of the key that is of a reasonable
 * length. By default the key uses java-serialization to convert
 * an attribute value into bytearray. But that ends up creating
 * a large string, which gets unmanageable when Web/HTML/JSP UIs
 * have to display the key/use the key in URLs. The intent here
 * is to get a shorter but meaningful String representation of
 * this object.
 * <p> 
 * Note that another requirement of this interface is that the
 * domain class should have a public default constructor, so
 * that the framework can call Class.newInstance() to create an
 * instance of this domain class and set the byte array from a
 * key into this instance using setBytes method.
 *
 * @see oracle.jbo.Key
 * @since JDevloper 3.0
 */
public interface KeyAttributeInterface {


  /**
   * Converts this attribute value into a byte-array. For domains
   * that extend oracle.sql.* classes, this method is implemented
   * by a baseclass. For others, this method needs to return a 
   * byte-array representation of the value held in the domain
   * object. 
   * 
   * @return a byte array representing this object
   */
  byte[] getBytes();

  /**
  * Passes in the bytes that represent the value of this object.
  * For domains that extedn oracle.sql.* classes, this method is
  * implemented by a base-class. 
  **/
  void setBytes(byte[] bArr);
  
}
