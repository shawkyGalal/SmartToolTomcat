/*
 * @(#)TypeFactory.java
 *
 * Copyright 1998-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.domain;

import com.sun.java.util.collections.HashMap;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import oracle.jbo.JboException;
import oracle.jbo.common.DebugDiagnostic;
import oracle.jbo.common.Diagnostic;
import oracle.jbo.common.JBOClass;
import oracle.jbo.common.JboTypeMap;

/**
 * <b>Internal:</b> <em>Applications should not extend this class or invoke its methods.</em>
 * <p>A utility for creating immutable Domain objects.
 *
 * <p>Create a Domain object by passing a fully qualified classname and a
 * compatable data value to a <code>getInstance</code> method. The classname 
 * may be a expressed as a <code>Class</code> or as a <code>String</code>.
 * <p>.  The data value may be an <code>Object</code> or a value of any of the
 * primitive data types.
 * <p> Note that for non-String data types that do not have String constructors
 * or that throw exceptions for empty strings ("") from their constructor or
 * valueOf() methods, this factory assumes the value to be NULL value. So for
 * example if an attribute is of type Number and setAttribute() is called for
 * that attribute with a "" (empty string), the value for the attribute will
 * be set to NULL. This helps all thin-clients to share the same logic of 
 * setting NULL values and provide similar behaviour without special-casing
 * for "" strings. This behavior can be overruled by creating a domain for
 * the desired data-type that has a string constructor or a valueOf(String) method
 * that could accept "" (empty string) and convert that to some default value;
 *
 *
 * @since JDevloper 3.0
 */
public class TypeFactory
{
   static HashMap mPrimitiveToObjectMap = null;

   static final HashMap mMap = new HashMap(20);

   static boolean typeMapConvInit = false;

   //*************************************************************
   //First set of Getters that take in a Class and a data Argument
   //*************************************************************

   /**
    * Creates an object of type <code>clazz</code> having the value
    * <code>val</code>.
    *
    * @param clazz  A fully qualified classname.
    * @param val An object.
    * @return An object consisting of <code>val</code> converted to
    * <code>clazz</code>. If <code>val</code> is <code>null</code> or already of
    * type <code>clazz</code> then <code>val</code> itself is returned.
    * @throws DataCreationException if <code>val</code> is incompatable with
    * <code>clazz</code>.
    */
   static public Object getInstance( Class clazz, Object val )
      //throws DataCreationException
   {
      //try to create the instance only for non=null values
      //and if the instance is of some other type.
      if( val == null || clazz.isInstance( val ) )
      {
         return val;
      }

      return get( clazz, val.getClass(), val);
   }

   /**
    * Creates an object of type <code>clazz</code> from the value
    * <code>val</code>. If the value is an instance of the class, try 
    * to create a copy of the val and return the copy.
    *
    * @param clazz  A fully qualified classname.
    * @param val An object.
    * @param anotherInstance If the value matches the required type, create
    * a copy if this parameter is true.
    * @return An object consisting of <code>val</code> converted to
    * <code>clazz</code>. If <code>val</code> is <code>null</code> or already of
    * type <code>clazz</code> then <code>val</code> itself is returned.
    * @throws DataCreationException if <code>val</code> is incompatable with
    * <code>clazz</code>.
    */
   static public Object getInstance( Class clazz, Object val, boolean anotherInstance )
      //throws DataCreationException
   {
      //try to create the instance only for non=null values
      //and if the instance is of some other type.
      if( val == null || (!anotherInstance && clazz.isInstance(val)))
      {
         return val;
      }

      return get( clazz, val.getClass(), val);
   }

   /**
    * Incase, a constructor in the class of type domainClass does not
    * take one argument of type same as <code>val</code>, use the class given by
    * <code>param</code> to find the constructor, assuming that <code>val</code>
    * is convertible to an object of <code>param</code> class.
    * @param domainClass full qualified classname of the target object
    * @param param full qualified classname of the parameter 
    * @param val value to convert into the domainClass type.
    */
   public static Object getInstance( String domainClass, String param, Object val ) 
   {
      Class claz = null;
      try 
      {
         return get(domainClass, JBOClass.forName(param), val);
      }
      catch (ClassNotFoundException ex)
      {
         throw new DataCreationException(domainClass, val, ex);
      }
   }

   /**
    * Incase, a constructor in the class of type domainClass does not
    * take one argument of type same as <code>val</code>, use the class given by
    * <code>param</code> to find the constructor, assuming that <code>val</code>
    * is convertible to an object of <code>param</code> class.
    * @param domainClass Preferred Class type of the target object
    * @param param Class type of the parameter 
    * @param val value to convert into the domainClass type.
    */
   public static Object getInstance( Class domainClass, Class param, Object val ) 
   {
      return get(domainClass, param, val);
   }

   /**
    * Creates an object of type <code>clazz</code> having the value
    * <code>val</code>.
    *
    * @param clazz  A fully qualified classname.
    * @param val A 32-bit signed integer.
    * @return An object consisting of <code>val</code> converted to
    * <code>clazz</code>.
    * @throws DataCreationException if <code>val</code> is incompatable with
    * <code>clazz</code>.
    */
   static public Object getInstance( Class clazz, int val )
      //throws DataCreationException
   {
      return get( clazz, Integer.TYPE, new Integer(val));
   }


   /**
    * Creates an object of type <code>clazz</code> having the value
    * <code>val</code>.
    *
    * @param clazz  A fully qualified classname.
    * @param val A 32-bit signed integer.
    * @return An object consisting of <code>val</code> converted to
    * <code>clazz</code>.
    * @throws DataCreationException if <code>val</code> is incompatable with
    * <code>clazz</code>.
    */
   static public Object getInstance( Class clazz, short val )
      //throws DataCreationException
   {
      return get( clazz, Short.TYPE, new Short(val));
   }

     
   /**
    * Creates an object of type <code>clazz</code> having the value
    * <code>val</code>.
    *
    * @param clazz  A fully qualified classname.
    * @param val A 64-bit signed integer.
    * @return An object consisting of <code>val</code> converted to
    * <code>clazz</code>.
    * @throws DataCreationException if <code>val</code> is incompatable with
    * <code>clazz</code>.
    */
   static public Object getInstance( Class clazz, long val )
      //throws DataCreationException
   {
      return get( clazz, Long.TYPE, new Long(val));
   }


   /**
    * Creates an object of type <code>clazz</code> having the value
    * <code>val</code>.
    *
    * @param clazz  A fully qualified classname.
    * @param val A 32-bit floating-point value.
    * @return An object consisting of <code>val</code> converted to
    * <code>clazz</code>.
    * @throws DataCreationException if <code>val</code> is incompatable with
    * <code>clazz</code>.
    */
   static public Object getInstance( Class clazz, float val )
      //throws DataCreationException
   {
      return get( clazz, Float.TYPE, new Float(val));
   }

     
   /**
    * Creates an object of type <code>clazz</code> having the value
    * <code>val</code>.
    *
    * @param clazz  A fully qualified classname.
    * @param val A 64-bit floating-point value.
    * @return An object consisting of <code>val</code> converted to
    * <code>clazz</code>.
    * @throws DataCreationException if <code>val</code> is incompatable with
    * <code>clazz</code>.
    */
   static public Object getInstance( Class clazz, double val )
      //throws DataCreationException
   {
      return get( clazz, Double.TYPE, new Double(val));
   }


   /**
    * Creates an object of type <code>clazz</code> having the value
    * <code>val</code>.
    *
    * @param clazz  A fully qualified classname.
    * @param val An 8-bit signed integer.
    * @return An object consisting of <code>val</code> converted to
    * <code>clazz</code>.
    * @throws DataCreationException if <code>val</code> is incompatable with
    * <code>clazz</code>.
    */
   static public Object getInstance( Class clazz, byte val )
      //throws DataCreationException
   {
      return get( clazz, Byte.TYPE, new Byte(val));
   }
   

   /**
    * Creates an object of type <code>clazz</code> having the value
    * <code>val</code>.
    *
    * @param clazz  A fully qualified classname.
    * @param val <code>true</code> or <code>false</code>.
    * @return An object consisting of <code>val</code> converted to
    * <code>clazz</code>.
    * @throws DataCreationException if <code>val</code> is incompatable with
    * <code>clazz</code>.
    */
   static public Object getInstance( Class clazz, boolean val )
      //throws DataCreationException
   {
      return get( clazz, Boolean.TYPE, new Boolean(val));
   }

   
   /**
    * Creates an object of type <code>clazz</code> having the value
    * <code>val</code>.
    *
    * @param clazz  A fully qualified classname.
    * @param val A unicode character.
    * @return An object consisting of <code>val</code> converted to
    * <code>clazz</code>.
    * @throws DataCreationException if <code>val</code> is incompatable with
    * <code>clazz</code>.
    */
   static public Object getInstance( Class clazz, char val )
      //throws DataCreationException
   {
      //how do I get a char class.
      return get( clazz, Character.TYPE, new Byte((byte)val));
   }

   
   //*************************************************************
   //Second set of Getters that take in a Class and a data Argument
   //*************************************************************

   /**
    * Creates an object of type <code>clazz</code> having the value
    *
    * @param clazz  A fully qualified classname.
    * <code>val</code>.
    * @param val An object.
    * @return An object consisting of <code>val</code> converted to
    * <code>clazz</code>.
    * @throws DataCreationException if <code>val</code> is incompatable with
    * <code>clazz</code>.
    */
   static public Object getInstance( String clazz, Object val )
      //throws DataCreationException
   {
      return (val != null) ? get( clazz, val.getClass(), val) : val;
   }

   
   /**
    * Creates an object of type <code>clazz</code> having the value
    * <code>val</code>.
    *
    * @param clazz  A fully qualified classname.
    * @param val A 32-bit signed integer.
    * @return An object consisting of <code>val</code> converted to
    * <code>clazz</code>.
    * @throws DataCreationException if <code>val</code> is incompatable with
    * <code>clazz</code>.
    */
   static public Object getInstance( String clazz, int val )
      //throws DataCreationException
   {
      return get( clazz, Integer.TYPE, new Integer(val));
   }
     

   /**
    * Creates an object of type <code>clazz</code> having the value
    * <code>val</code>.
    *
    * @param clazz  A fully qualified classname.
    * @param val A 16-bit signed integer.
    * @return An object consisting of <code>val</code> converted to
    * <code>clazz</code>.
    * @throws DataCreationException if <code>val</code> is incompatable with
    * <code>clazz</code>.
    */
   static public Object getInstance( String clazz, short val )
      //throws DataCreationException
   {
      return get( clazz, Short.TYPE, new Short(val));
   }


   /**
    * Creates an object of type <code>clazz</code> having the value
    * <code>val</code>.
    *
    * @param clazz  A fully qualified classname.
    * @param val A 64-bit signed integer.
    * @return An object consisting of <code>val</code> converted to
    * <code>clazz</code>.
    * @throws DataCreationException if <code>val</code> is incompatable with
    * <code>clazz</code>.
    */
   static public Object getInstance( String clazz, long val )
      //throws DataCreationException
   {
      return get( clazz, Long.TYPE, new Long(val));
   }


   /**
    * Creates an object of type <code>clazz</code> having the value
    * <code>val</code>.
    *
    * @param clazz  A fully qualified classname.
    * @param val A 32-bit floating-point value.
    * @return An object consisting of <code>val</code> converted to
    * <code>clazz</code>.
    * @throws DataCreationException if <code>val</code> is incompatable with
    * <code>clazz</code>.
    */
   static public Object getInstance( String clazz, float val )
      //throws DataCreationException
   {
      return get( clazz, Float.TYPE, new Float(val));
   }

     
   /**
    * Creates an object of type <code>clazz</code> having the value
    * <code>val</code>.
    *
    * @param clazz  A fully qualified classname.
    * @param val A 64-bit floating-point value.
    * @return An object consisting of <code>val</code> converted to
    * <code>clazz</code>.
    * @throws DataCreationException if <code>val</code> is incompatable with
    * <code>clazz</code>.
    */
   static public Object getInstance( String clazz, double val )
      //throws DataCreationException
   {
      return get( clazz, Double.TYPE, new Double(val));
   }


   /**
    * Creates an object of type <code>clazz</code> having the value
    * <code>val</code>.
    *
    * @param clazz  A fully qualified classname.
    * @param val An 8-bit signed integer.
    * @return An object consisting of <code>val</code> converted to
    * <code>clazz</code>.
    * @throws DataCreationException if <code>val</code> is incompatable with
    * <code>clazz</code>.
    */
   static public Object getInstance( String clazz, byte val )
      //throws DataCreationException
   {
      return get( clazz, Byte.TYPE, new Byte(val));
   }

   
   /**
    * Creates an object of type <code>clazz</code> having the value
    * <code>val</code>.
    *
    * @param clazz  A fully qualified classname.
    * @param val <code>true</code> or <code>false</code>.
    * @return An object consisting of <code>val</code> converted to
    * <code>clazz</code>.
    * @throws DataCreationException if <code>val</code> is incompatable with
    * <code>clazz</code>.
    */
   static public Object getInstance( String clazz, boolean val )
      //throws DataCreationException
   {
      return get( clazz, Boolean.TYPE, new Boolean(val));
   }

   
   /**
    * Creates an object of type <code>clazz</code> having the value
    * <code>val</code>.
    *
    * @param clazz  A fully qualified classname.
    * @param val A unicode character.
    * @return An object consisting of <code>val</code> converted to
    * <code>clazz</code>.
    * @throws DataCreationException if <code>val</code> is incompatable with
    * <code>clazz</code>.
    */
   static public Object getInstance( String clazz, char val )
      //throws DataCreationException
   {
      //how do I get a char class.
      return get( clazz, Character.TYPE, new Byte((byte)val));
   }


   static public boolean checkEquals(Object srcValue, Object targetValue)
   {
      if (srcValue instanceof NullValue)
      {
         srcValue = null;
      }
      if (targetValue instanceof NullValue)
      {
         targetValue = null;
      }
      
      if ((srcValue == null && targetValue != null) ||
          (srcValue != null && targetValue == null))
      {
         return false;
      }

      if (srcValue != null)
      {
         if (!srcValue.equals(targetValue))
         {
            targetValue = getInstance(srcValue.getClass(), targetValue);
         
            if (targetValue == null || !srcValue.equals(targetValue))
            {
               // targetValue == null means could not convert.

               return false;
            }
         }
      }

      return true;
   }
   

   /**
    * Incase, a constructor in the class of name className does not
    * take one argument of type same as <code>val</code>, use the class given by
    * <code>param</code> to find the constructor, assuming that <code>val</code>
    * is convertible to an object of <code>param</code> class.
    */
   private static Object get( String className, Class param, Object val )
      //throws DataCreationException
   {
      Class claz = null;
      try 
      {
         claz = JBOClass.forName(className);
         //if class is same as class for the passed in value,
         //return the value as is.
         if( claz.equals( param ) )
         {
            return val;
         }
      }
      catch (ClassNotFoundException ex)
      {
         throw new DataCreationException(className, val, ex);
      }
      return get(claz, param, val);
   }
   

   public static void addStaticConverter(Class domainClass /*toClass*/, Class paramClass /*valClass*/,
                                         int opId)
   {
      TypeConvMapEntry mth = null;
      HashMap mthMap = (HashMap) mMap.get(domainClass);

      if (mthMap == null)
      {
         mthMap = new HashMap(2);
         mMap.put(domainClass, mthMap);
      }

      mth = new TypeConvMapEntry(opId);

      mthMap.put(paramClass, mth);
   }

   public static void addCustomConverter(Class domainClass /*toClass*/, Class paramClass /*valClass*/,
                                         TypeConvMapEntry mth)
   {
      HashMap mthMap = (HashMap) mMap.get(domainClass);

      if (mthMap == null)
      {
         mthMap = new HashMap(2);
         mMap.put(domainClass, mthMap);
      }
      else
      {
         if (Diagnostic.isOn() && mthMap.get(paramClass) != null)
         {
            Diagnostic.println("Warning! TypeFactory - Registering duplicate entry to convert from "+paramClass+" to "+domainClass);
         }
      }

      mthMap.put(paramClass, mth);
   }

   
   static TypeConvMapEntry lookupMethod(Class domainClass, Class paramClass)
   {
      TypeConvMapEntry mth = null;
      HashMap mthMap = (HashMap) mMap.get(domainClass);

      if (mthMap == null)
      {
         mthMap = new HashMap(2);
         mMap.put(domainClass, mthMap);
      }
      else
      { 
         mth = (TypeConvMapEntry) mthMap.get(paramClass);

         if (mth != null)
         {
            return mth;
         }
      }

      //mthMap has no entry for this parameter type.
      Constructor ctor;
      Method valueOf;

      final Class methodParams[] = new Class[1];
      methodParams[0] = paramClass;

      try
      {
         //try constructor first.
         ctor = domainClass.getConstructor(methodParams);
         mth = new TypeConvMapEntry(TypeConvMapEntry.TYPED_CTOR, ctor);
         mthMap.put(paramClass, mth);
      }
      catch (NoSuchMethodException nsme)
      {
         boolean found = false;
         try
         {
            //try intValueOf method first.
            if (java.lang.Number.class.isAssignableFrom(domainClass))
            {
               String mthName = domainClass.getName();
               String firstChar="";
               int idx = mthName.lastIndexOf('.');
               if (idx > 0) 
               {
                  idx++;
                  firstChar = mthName.substring(idx, idx+1).toLowerCase();
                  mthName = mthName.substring(idx+1);
               }

               mthName = (new StringBuffer(firstChar).append(mthName).append("Value")).toString();
               valueOf = paramClass.getMethod(mthName, new Class[]{});
               mth = new TypeConvMapEntry(TypeConvMapEntry.TYPED_VALUE_MTH, valueOf);
               mthMap.put(paramClass, mth);
               found = true;
            }
         }
         catch (NoSuchMethodException e)
         {
         }
         catch (Exception e)
         {
            DebugDiagnostic.printStackTrace(e);
         }

         if (!found) 
         {
            try
            {
               //try valueOf method first.
               valueOf = domainClass.getMethod("valueOf", methodParams);
               mth = new TypeConvMapEntry(TypeConvMapEntry.TYP_VALUE_OF, valueOf);
               mthMap.put(paramClass, mth);
            }
            catch (NoSuchMethodException nsme1)
            {
               //if String constructor not found.
               if (!String.class.equals(paramClass))
               {
                  try
                  {
                     //try string constructor next.
                     methodParams[0] = String.class;
                     ctor = domainClass.getConstructor(methodParams);
                     mth = new TypeConvMapEntry(TypeConvMapEntry.STRING_CTOR, ctor);
                     mthMap.put(paramClass, mth);
                  }
                  catch (NoSuchMethodException nsme2)
                  {
                     //try valueOf(String) next.
                     try
                     {
                        valueOf = domainClass.getMethod("valueOf", methodParams);
                        mth = new TypeConvMapEntry(TypeConvMapEntry.STR_VALUE_OF, valueOf);
                        mthMap.put(paramClass, mth);
                     }
                     catch (NoSuchMethodException nmse3)
                     {
                        //no matching conversion method found.
                        DebugDiagnostic.println("No matching conversion to "+domainClass.getName() +" from "+paramClass.getName());
                        throw new DataCreationException(domainClass.getName(), paramClass.getName(), nmse3);
                     }
                  }
               }
            }
         }
      }
      //should be non null by now.
      return mth;
   }

   /**
    * Incase, a constructor in the class of type domainClass does not
    * take one argument of type same as <code>val</code>, use the class given by
    * <code>param</code> to find the constructor, assuming that <code>val</code>
    * is convertible to an object of <code>param</code> class.
    */
   private static Object get(Class domainClass, Class paramClass, Object val)
   {
      try 
      {
         if (domainClass.isPrimitive())
         {
            domainClass = getObjectClass(domainClass);
         }

         synchronized(mMap)
         {
            if (typeMapConvInit == false)
            {
               JboTypeMap.populateConversion(mMap);
               typeMapConvInit = true;
            }
         
            TypeConvMapEntry mthEntry = lookupMethod(domainClass, paramClass);

            if (mthEntry != null)
            {
               return mthEntry.convert(domainClass, paramClass, val);
            }
            else
            {
               if (val != null) 
               {
                  throw new DataCreationException(domainClass.getName(), val, null);
               }
            }
            return null;
         }
      }
      catch (JboException jex)
      {
         throw jex;
      }
      catch (InvocationTargetException ie)
      {
         if (paramClass == String.class && domainClass != String.class ) 
         {
            //see if value is "" (empty String), if so set NULL for the value.
            if (((String)val).length() == 0) 
            {
               //note that null is set only for types that have string constructors.
               return null;
            }
         }
         Throwable th = ie.getTargetException();
         if ( th instanceof JboException )
         {
            throw (JboException)th;
         }
         throw new DataCreationException(domainClass.getName(), val, (Exception)th);
      }
      catch (Exception ex)
      {
         throw new DataCreationException(domainClass.getName(), val, ex);
      }
   }              

   /**
    * Finds a constructor in the given class which takes in one parameter
    * of type same as the argument <code>val</code>, and invokes that
    * constructor with the argument <code>val</code>. 
    */
   private static Object get( Class domainClass, Object val )
      //throws DataCreationException
   {
      return get(domainClass, val.getClass(), val);
   }
   
   /*
   public static void main(String[] args)
   {
      oracle.jbo.common.Timer       timer = new oracle.jbo.common.Timer();
      oracle.jbo.common.Diagnostic.println(" " + timer.start());
      for (int i = 0; i < 200; i++)
      {
         (TypeFactory.getInstance(java.sql.Date.class, "1222-12-12"));
         (TypeFactory.getInstance(java.lang.Integer.class, "12"));
         (TypeFactory.getInstance(java.math.BigDecimal.class, "12"));
         (TypeFactory.getInstance(java.math.BigDecimal.class, ""));
         (TypeFactory.getInstance(oracle.jbo.domain.Number.class, ""));
         (TypeFactory.getInstance(oracle.jbo.domain.Number.class, "7"));
         (TypeFactory.getInstance(oracle.jbo.domain.Number.class, "7.90"));
         (TypeFactory.getInstance(oracle.jbo.domain.Date.class, "1290-09-09"));
         (TypeFactory.getInstance(oracle.jbo.domain.Date.class, "1390-09-09"));
         (TypeFactory.getInstance(java.lang.String.class, "1390-09-09"));
      }
      oracle.jbo.common.Diagnostic.println("takes: " + timer.end() + " ms.");
   }
   */
   static private Class getObjectClass(Class primitiveClass)
   {
      populatePrimitiveToObjectMap();
      
      Object o = mPrimitiveToObjectMap.get(primitiveClass);

      if (o != null)
      {
         return (Class) o;
      }

      return primitiveClass;
   }


   static private void populatePrimitiveToObjectMap()
   {
      if (mPrimitiveToObjectMap == null)
      {
         mPrimitiveToObjectMap = new HashMap(8);

         synchronized(mPrimitiveToObjectMap)
         {
            mPrimitiveToObjectMap.put(Integer.TYPE, Integer.class);
            mPrimitiveToObjectMap.put(Long.TYPE, Long.class);
            mPrimitiveToObjectMap.put(Short.TYPE, Short.class);
            mPrimitiveToObjectMap.put(Boolean.TYPE, Boolean.class);
            mPrimitiveToObjectMap.put(Float.TYPE, Float.class);
            mPrimitiveToObjectMap.put(Double.TYPE, Double.class);
            mPrimitiveToObjectMap.put(Character.TYPE, Character.class);
            mPrimitiveToObjectMap.put(Boolean.TYPE, Boolean.class);
         }
      }
   }
} //TypeFactory class
