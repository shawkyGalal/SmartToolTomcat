/*
 * @(#)XMLDomainInterface.java
 *
 * Copyright 2000-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.domain;

/**
 * Implemented by domain classes which can read and write domain values as XML.
 *
 * @since JDevloper 4.0
 */
public interface XMLDomainWriter extends XMLDomainInterface
{
   /**
   * Creates the XML node in the given XML document for this domain's data.
   * <p>
   * @param xmlDoc name of the XML document in which the node should be created.
   **/
   org.w3c.dom.Node getSerializedDomainXML(org.w3c.dom.Document xmlDoc);
}

