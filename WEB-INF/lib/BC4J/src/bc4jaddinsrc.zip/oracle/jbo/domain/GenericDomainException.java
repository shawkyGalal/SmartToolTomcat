/*
 * @(#)GenericDomainException.java
 *
 * Copyright 1999-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.domain;

import oracle.jbo.CSMessageBundle;
import oracle.jbo.JboException;

/**
 * Thrown when creation of Domain objects fails.
 *
 * @since JDevloper 3.0
 */
public class GenericDomainException
   extends JboException
{
   static final long serialVersionUID = -3138195987151128797L;

   public GenericDomainException(String operation,
                                Object val,
                                Exception ex)
   {
      super(CSMessageBundle.class,
            (val != null) ? CSMessageBundle.EXC_DOMAIN_OPERATION : CSMessageBundle.EXC_DATA_CREATION_WITH_MSG,
            (Object[]) null);
 
      Object arr[] = null;
      if (val != null) 
      {
         arr = new Object[3];
         arr[0] = operation;
         arr[1] = val;
         arr[2] = val.getClass().getName();
      }
      else
      {
         arr = new Object[2];
         arr[0] = operation;
         arr[1] = ex;
      }
      setErrorParameters(arr);
      if( ex != null )
      {
         addToDetails(ex);
      }
   }

} // class GenericDomainException
