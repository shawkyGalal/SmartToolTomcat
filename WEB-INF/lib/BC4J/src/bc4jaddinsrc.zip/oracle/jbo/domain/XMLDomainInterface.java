/*
 * @(#)XMLDomainInterface.java
 *
 * Copyright 2000-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.domain;

import java.io.PrintWriter;
import java.util.Hashtable;

/**
 * Implemented by domain classes which can read and write domain values as XML.
 *
 * @since JDevloper 4.0
 */
public interface XMLDomainInterface
{
   /**
   * Creates the XML node in the given XML document for this domain's data.
   * <p>
   * @param xmlDoc name of the XML document in which the node should be created.
   **/
   org.w3c.dom.Node getXMLContentNode(org.w3c.dom.Document xmlDoc);

   /**
   * Prints the DTD info for this domain in the given print writer.
   * Returns the DTD string to be added to this domain's container
   * entity/domain.
   * <p> The <tt>allDefs</tt> hashtable contains predefined XML definitions and
   * is passed by whatever calls this method.
   * <p>
   * @param allDefs a hashtable of predefined XML definitions passed from whatever
   * calls this method.
   * @param pw print writer into which the defnition is being printed.
   * @param bContainees if <tt>true</tt>, prints definitions of contained objects.
   **/
   String printXMLDefinition(Hashtable allDefs, PrintWriter pw,
                             boolean bContainees);
   
   
}

