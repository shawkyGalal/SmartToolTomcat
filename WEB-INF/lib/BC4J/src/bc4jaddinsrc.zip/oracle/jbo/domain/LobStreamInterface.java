/*
 * @(#)LobStreamInterface.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.domain;

import java.io.InputStream;
import java.io.Reader;
import java.io.Writer;
import java.io.OutputStream;

/**
 * Provides methods to save data to, and extract data from,
 * LOB domain classes. These methods are implemented by all LOB-based
 * domain classes: {@link oracle.jbo.domain.BlobDomain BlobDomain},
 * {@link oracle.jbo.domain.BFileDomain BFileDomain}, and
 * {@link oracle.jbo.domain.ClobDomain ClobDomain}.
 *
 * <p>Domain classes encapsulate Oracle SQL datatypes.
 * Domain objects can be converted to the standard JDBC data types.
 *
 * @see TypeFactory
 * @see "JboDomainValidator"
 * @since JDevloper 3.0
 */
public interface LobStreamInterface extends 
                                 LobInterface
{

   /**
   * Returns a stream to be used to write bytes into this LOB.
   * This stream works in both 2/3 tiers. In 2-tier, this stream could be the same
   * as the stream returned by the internal jdbc object. In 3-tier, this stream is
   * a remote OutputStream that streams data from the middle-tier LOB.
   **/
   OutputStream getOutputStream();

   /**
   * Closes and cleansup internal reference to output stream.
   **/
   void closeOutputStream();
   
   /**
   * Returns a stream to be used to read bytes from this LOB.
   * This stream works in both 2/3 tiers. In 2-tier, this stream could be the same
   * as the stream returned by the internal jdbc object. In 3-tier, this stream is
   * a remote OutputStream that streams data from the middle-tier LOB.
   **/
   InputStream  getInputStream();

   /**
   * Returns a reader to be used to read char from this CLOB.
   * This stream works in both 2/3 tiers. In 2-tier, this stream could be the same
   * as the stream returned by the internal jdbc object. In 3-tier, this stream is
   * a remote reader that streams data from the middle-tier LOB.
   **/
   Reader  getCharacterStream();

   /**
   * Returns a writer to be used to write chars into this CLOB.
   * This stream works in both 2/3 tiers. In 2-tier, this writer could be the same
   * as the writer returned by the internal jdbc object. In 3-tier, this stream is
   * a remote writer that streams data from the middle-tier LOB.
   **/
   Writer getCharacterOutputStream();

   /**
   * Closes and cleansup internal reference to writer.
   **/
   void closeCharacterOutputStream();
}
