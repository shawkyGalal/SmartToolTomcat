/*
 * @(#)DomainStructureDef.java
 *
 * Copyright 1999-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.domain;

import oracle.jbo.AttributeDef;
import oracle.jbo.NoDefException;
import oracle.jbo.StructureDef;

public class DomainStructureDef implements StructureDef
{
   AttributeDef[] mAttrDefs;


   public DomainStructureDef(AttributeDef[] attrDefs)
   {
      mAttrDefs = attrDefs;
   }
   
   
   /**
    * Gets the defined attributes.
    *
    * @return an array of attribute definitions.
    */
   public AttributeDef[] getAttributeDefs()
   {
      return mAttrDefs;
   }


   /**
    * Counts the defined attributes.
    *
    * @return the number of attributes.
    */
   public int getAttributeCount()
   {
      return mAttrDefs.length;
   }
   

   /**
    * Gets an attribute definition by name.
    *
    * @param name the name of an <code>AttributeDef</code>.
    * @return  an attribute definition, or <code>null</code> if not found.
    */
   public AttributeDef findAttributeDef(String name)
   {
      AttributeDef a = lookupAttributeDef(name);
      if (a != null)
      {
         return a;
      }

      throw new NoDefException(NoDefException.TYP_ATTRIBUTE, name);
   }


   /**
    * Gets an attribute definition by name.
    *
    * @param name the name of an <code>AttributeDef</code>.
    * @return  an attribute definition, or <code>null</code> if not found.
    */
   public AttributeDef lookupAttributeDef(String name)
   {
      int attrCount = getAttributeCount();

      for (int j = 0; j < attrCount; j++)
      {
         if (mAttrDefs[j].getName().equals(name))
         {
            return mAttrDefs[j];
         }
      }
      
      return null;
   }
   

   /**
    * Gets an attribute definition by index.
    *
    * @param index the index of an <code>AttributeDef</code>, where the leftmost
    * attribute has index zero.
    * @return  an attribute definition.
    */
   public AttributeDef getAttributeDef(int index)
   {
      return mAttrDefs[index];
   }
}
