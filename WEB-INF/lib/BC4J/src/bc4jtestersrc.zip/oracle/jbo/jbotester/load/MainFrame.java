package oracle.jbo.jbotester.load;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JLabel;
import javax.swing.JButton;
import javax.swing.JRadioButton;

import javax.swing.BorderFactory;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;
import javax.swing.BoxLayout;
import javax.swing.Box;
import javax.swing.ButtonGroup;

import javax.swing.border.BevelBorder;

import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.Toolkit;
import java.awt.Font;

import java.text.SimpleDateFormat;

import java.util.Date;
import java.util.Enumeration;

import com.sun.java.util.collections.ArrayList;

import java.awt.Dimension;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import java.util.TimerTask;
import java.util.Timer;

import oracle.jbo.jbotester.PoolParameterPanel;

import oracle.jbo.pool.ResourcePoolStatistics;
import oracle.jbo.pool.ResourcePoolManager;
import oracle.jbo.pool.ResourcePool;

import oracle.jbo.server.ConnectionPoolManagerFactory;
import oracle.jbo.server.ConnectionPoolManager;

import oracle.jbo.common.ampool.ApplicationPool;

public class MainFrame extends JFrame implements StateChangeListener, ActionListener
{
   private Controller mController;

   private static long REFRESH_RATE = 500;
   
   private Object mLock = new Object();

   // this is expensive to create
   SimpleDateFormat mDateFormatter = new SimpleDateFormat("HH:mm:ss");;

   private JLabel mNumOfSessionsText = new JLabel("0");
   private JLabel mNumOfIterationsText = new JLabel("0");
   private JLabel mAvgDurationText = new JLabel("0");

   private JLabel mMessageAreaLabel = new JLabel(" ");
   private JLabel mElapsedTimeLabel = new JLabel("00:00:00");

   private JButton mRunButton = new JButton("Run");
   private JButton mStopButton = new JButton("Stop");
   private JButton mResetButton = new JButton("Reset");

   private JMenuItem mMenuViewAMPool = new JMenuItem();
   private JMenuItem mMenuViewConnPool = new JMenuItem();
   private JMenuItem mMenuEditSimulation = new JMenuItem();
   private JMenuItem mMenuEditPool = new JMenuItem();

   private ApplicationPoolViewPanel mApplicationPoolViewPanel = null;
   private ConnectionPoolViewPanel mConnectionPoolViewPanel = null;
   private SimulationParametersPanel mSimulationParametersPanel = null;
   
   private static String SIMULATION_SUM_COMMAND = "SIMULATION_SUM_COMMAND";
   private static String AM_POOL_SUM_COMMAND = "AM_POOL_SUM_COMMAND";
   private static String CONN_POOL_SUM_COMMAND = "CONN_POOL_SUM_COMMAND";
   
   private Timer mTimer = new Timer();

   private TimeSeriesGraph mHistoryGraph = new TimeSeriesGraph();
   private TimeSeriesModel mResponseHistoryModel = new TimeSeriesModel();
   private TimeSeriesModel mAMPoolSizeHistoryModel = new TimeSeriesModel();
   private TimeSeriesModel mConnPoolSizeHistoryModel = new TimeSeriesModel();

   private boolean mUpdateRunStatistics = false;
   private boolean mUpdateUI = false;
   
   public MainFrame()
   {
      super("BC4J Load Simulator");

      init();
   }

   void init()
   {
      // model
      mController = new Controller("mypackage1.Mypackage1Module", "Mypackage1ModuleLocal");
      mController.addControllerStateListener(this);

      GridBagLayout layout   = new GridBagLayout();
      GridBagConstraints   constraints   = new GridBagConstraints();
      getContentPane().setLayout(layout);
//      getContentPane().setBorder(BorderFactory.createEmptyBorder(2,2,2,2));

      setSize(new Dimension(450, 400));
      addWindowListener(new WindowAdapter()
      {
         public void windowClosing(WindowEvent e)
         {
            System.exit(0);
         }
      });

      mHistoryGraph.setModel(mResponseHistoryModel, "Average Response Time History");

      constraints.anchor = GridBagConstraints.NORTHWEST;
      constraints.gridx = 0;
      constraints.gridy = 0;
      constraints.weighty=1;
      constraints.weightx=1;
      constraints.gridwidth=2;
      constraints.fill=GridBagConstraints.BOTH;
      constraints.insets=new Insets(5, 5, 5, 5);

      layout.setConstraints(mHistoryGraph, constraints);
      getContentPane().add(mHistoryGraph);

      constraints.anchor = GridBagConstraints.NORTHWEST;
      constraints.gridx = 0;
      constraints.gridy = 1;
      constraints.weighty=0;
      constraints.weightx=0;
      constraints.gridwidth=1;
      constraints.fill=GridBagConstraints.BOTH;
      constraints.insets=new Insets(2, 5, 2, 0);

//      JPanel panel = buildSimulatorView();
      JPanel panel = buildDisplayOptionsPanel();
      layout.setConstraints(panel, constraints);
      getContentPane().add(panel);

      constraints.anchor = GridBagConstraints.NORTHWEST;
      constraints.gridx = 1;
      constraints.gridy = 1;
      constraints.weighty=0;
      constraints.weightx=1;
      constraints.fill=GridBagConstraints.BOTH;
      constraints.insets=new Insets(0, 5, 0, 0);

      panel = new JPanel();
      layout.setConstraints(panel, constraints);
      getContentPane().add(panel);

      constraints.anchor = GridBagConstraints.SOUTHWEST;
      constraints.gridx = 0;
      constraints.gridy = 2;
      constraints.gridwidth=2;
      constraints.weighty=0;
      constraints.weightx=0;
      constraints.fill=GridBagConstraints.HORIZONTAL;
      constraints.insets=new Insets(5,0,5,0);

      panel = buildButtonsBar();
      layout.setConstraints(panel, constraints);
      getContentPane().add(panel);

      constraints.anchor = GridBagConstraints.SOUTHWEST;
      constraints.gridx = 0;
      constraints.gridy = 3;
      constraints.weighty=0;
      constraints.weightx=0;
      constraints.fill=GridBagConstraints.HORIZONTAL;
      constraints.insets=new Insets(0,0,0,0);

      panel = buildStatusBar();
      layout.setConstraints(panel, constraints);
      getContentPane().add(panel);

      buildMenu();
      
      Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
      Dimension frameSize = getSize();
      if (frameSize.height > screenSize.height)
      {
         frameSize.height = screenSize.height;
      }
      if (frameSize.width > screenSize.width)
      {
         frameSize.width = screenSize.width;
      }
      setLocation((screenSize.width - frameSize.width) / 2, (screenSize.height - frameSize.height) / 2);

      setVisible(true);
      invalidate();
   }
   
   public void actionPerformed(ActionEvent ev)
   {
      String actionCommand = ev.getActionCommand();
      if (SIMULATION_SUM_COMMAND.equals(actionCommand))
      {
         mHistoryGraph.setModel(mResponseHistoryModel, "Average Response Time History");
      }
      else if (AM_POOL_SUM_COMMAND.equals(actionCommand))
      {
         mHistoryGraph.setModel(mAMPoolSizeHistoryModel, "ApplicationPool Size History");
      }
      else if (CONN_POOL_SUM_COMMAND.equals(actionCommand))
      {
         mHistoryGraph.setModel(mConnPoolSizeHistoryModel, "ConnectionPool Size History");
      }
   }

   public void stateChanged(StateChangedEvent stateChangedEvent)
   {
      final String messageAreaLabelText;
      switch (stateChangedEvent.getNewState())
      {
         case (Controller.STATE_COMPLETED):
         {
            setUpdateUI(false);
            mRunButton.setEnabled(true);
            mResetButton.setEnabled(true);
            mStopButton.setEnabled(false);
            messageAreaLabelText = "Finished";
            break;
         }
         case (Controller.STATE_NEW):
         case (Controller.STATE_INITIALIZED):
         {
            messageAreaLabelText = "Ready";
            break;
         }
         case (Controller.STATE_RAMPING_UP):
         {
            setUpdateUI(true);
            mStopButton.setEnabled(true);
            messageAreaLabelText = "Ramping Up...";
            mController.schedule(
               new TimerTask()
               {
                  public void run()
                  {
                     SwingUtilities.invokeLater(
                        new Runnable()
                        {
                           public void run()
                           {
                              update();
                           }
                        });
                  }
               }
               , REFRESH_RATE);
            break;
         }
         case (Controller.STATE_RUNNING):
         {
            setUpdateRunStatistics(true);
            messageAreaLabelText = "Running...";
            break;
         }
         case (Controller.STATE_RAMPING_DOWN):
         {
            setUpdateRunStatistics(false);
            mStopButton.setEnabled(false);
            messageAreaLabelText = "Ramping Down...";
            break;
         }
         case (Controller.STATE_CANCELLED):
         {
            setUpdateRunStatistics(false);
            mStopButton.setEnabled(false);
            messageAreaLabelText = "Cancelled...";
            break;
         }
         default:
         {
            messageAreaLabelText = "Ready";
         }
      }
      
      SwingUtilities.invokeLater(
         new Runnable()
         {
            public void run()
            {
               mMessageAreaLabel.setText(messageAreaLabelText);
            }
         });
   }
   
   private void setUpdateRunStatistics(boolean updateRunStatistics)
   {
      mUpdateRunStatistics = updateRunStatistics;
   }

   private void setUpdateUI(boolean updateUI)
   {
      mUpdateUI = updateUI;
   }

   private void buildMenu()
   {
      JMenuBar menuBar = new JMenuBar();

      setJMenuBar(menuBar);

      JMenu menuFile = new JMenu();
      menuFile.setText("File");

      JMenuItem menuFileExit = new JMenuItem();
      menuFileExit.setText("Exit");
      menuFileExit.addActionListener(new ActionListener()
         {
            public void actionPerformed(ActionEvent ae)
            {
               fileExit_ActionPerformed(ae);
            }
         });
      menuFile.add(menuFileExit);

      JMenu menuEdit = new JMenu();
      menuEdit.setText("Edit");

      mMenuEditSimulation.setText("Simulation Parameters...");
      mMenuEditSimulation.addActionListener(new ActionListener()
         {
            public void actionPerformed(ActionEvent ae)
            {
               editSimulation_ActionPerformed(ae);
            }
         });
      menuEdit.add(mMenuEditSimulation);

      mMenuEditPool.setText("Pool Parameters...");
      mMenuEditPool.addActionListener(new ActionListener()
         {
            public void actionPerformed(ActionEvent ae)
            {
               editPool_ActionPerformed(ae);
            }
         });
      menuEdit.add(mMenuEditPool);

      JMenu menuView = new JMenu();
      menuView.setText("View");

      mMenuViewAMPool.setText("ApplicationPool Statistics...");
      mMenuViewAMPool.addActionListener(new ActionListener()
         {
            public void actionPerformed(ActionEvent ae)
            {
               viewAMPool_ActionPerformed(ae);
            }
         });
      menuView.add(mMenuViewAMPool);

      mMenuViewConnPool.setText("ConnectionPool Statistics...");
      mMenuViewConnPool.addActionListener(new ActionListener()
         {
            public void actionPerformed(ActionEvent ae)
            {
               viewConnPool_ActionPerformed(ae);
            }
         });
      menuView.add(mMenuViewConnPool);

      menuBar.add(menuFile);
      menuBar.add(menuEdit);
      menuBar.add(menuView);
   }
   
   private JPanel buildDisplayOptionsPanel()
   {
      GridBagLayout layout   = new GridBagLayout();
      JPanel panel = new JPanel(layout);
      GridBagConstraints   constraints   = new GridBagConstraints();

      panel.setBorder(BorderFactory.createTitledBorder("Display Options"));
      
      ButtonGroup radioButtonGroup = new ButtonGroup();

      constraints.anchor = GridBagConstraints.NORTHWEST;
      constraints.gridx = 0;
      constraints.gridy = 0;
      constraints.weighty=0;
      constraints.weightx=1;
      constraints.fill=GridBagConstraints.HORIZONTAL;
      constraints.insets=new Insets(5, 5, 5, 5);

      JRadioButton radioButton = new JRadioButton("Simulation Summary", true);
      radioButton.setActionCommand(SIMULATION_SUM_COMMAND);
      radioButton.addActionListener(this);
      radioButtonGroup.add(radioButton);
      panel.add(radioButton, constraints);
      
      constraints.anchor = GridBagConstraints.NORTHWEST;
      constraints.gridx = 0;
      constraints.gridy = 1;
      constraints.weighty=0;
      constraints.weightx=1;
      constraints.fill=GridBagConstraints.HORIZONTAL;
      constraints.insets=new Insets(5, 5, 5, 5);

      radioButton = new JRadioButton("ApplicationPool Summary", false);
      radioButton.setActionCommand(AM_POOL_SUM_COMMAND);
      radioButton.addActionListener(this);
      radioButtonGroup.add(radioButton);
      panel.add(radioButton, constraints);
      
      constraints.anchor = GridBagConstraints.NORTHWEST;
      constraints.gridx = 0;
      constraints.gridy = 2;
      constraints.weighty=0;
      constraints.weightx=1;
      constraints.fill=GridBagConstraints.HORIZONTAL;
      constraints.insets=new Insets(5, 5, 5, 5);

      radioButton = new JRadioButton("ConnectionPool Summary", false);
      radioButton.setActionCommand(CONN_POOL_SUM_COMMAND);
      radioButton.addActionListener(this);
      radioButtonGroup.add(radioButton);
      panel.add(radioButton, constraints);
      
      return panel;
   }

   private JPanel buildSimulatorView()
   {
      GridBagLayout layout   = new GridBagLayout();
      JPanel panel = new JPanel(layout);
      GridBagConstraints   constraints   = new GridBagConstraints();

      panel.setBorder(BorderFactory.createTitledBorder("Simulation Statistics"));

      // shared contrainst settings:
      constraints.gridx = 0;
      constraints.gridy = 0;

      JLabel numOfSessionsLabel = new JLabel("Total number of sessions started:  ");
      UIHelper.buildRow(
         panel
         , constraints
         , layout
         , numOfSessionsLabel
         , mNumOfSessionsText);

      JLabel numOfIterationsLabel = new JLabel("Total number of tasks completed:  ");

      UIHelper.buildRow(
         panel
         , constraints
         , layout
         , numOfIterationsLabel
         , mNumOfIterationsText);

      JLabel avgDurationLabel = new JLabel("Average task completion time(ms):  ");

      UIHelper.buildRow(
         panel
         , constraints
         , layout
         , avgDurationLabel
         , mAvgDurationText);

      return panel;
   }

   private JPanel buildButtonsBar()
   {
      int maxWidth = 0;
      ArrayList buttons = new ArrayList();

      JPanel panel = new JPanel();
      panel.setLayout(new BoxLayout(panel, BoxLayout.X_AXIS));
      panel.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 0));
      
      buttons.add(mResetButton);
      maxWidth = Math.max(maxWidth, mResetButton.getMinimumSize().width);
      mResetButton.setEnabled(true);
      mResetButton.addActionListener(
         new ActionListener()
         {
            public void actionPerformed(ActionEvent ev)
            {
               reset();
            }
         });

      buttons.add(mStopButton);
      maxWidth = Math.max(maxWidth, mStopButton.getMinimumSize().width);
      mStopButton.setEnabled(false);
      mStopButton.addActionListener(
         new ActionListener()
         {
            public void actionPerformed(ActionEvent ev)
            {
               stop();
            }
         });

      buttons.add(mRunButton);
      maxWidth = Math.max(maxWidth, mRunButton.getMinimumSize().width);
      mRunButton.setEnabled(true);
      mRunButton.addActionListener(
         new ActionListener()
         {
            public void actionPerformed(ActionEvent ev)
            {
               run();
            }
         });

      Dimension   d = new Dimension(maxWidth, mRunButton.getMinimumSize().height);
      Dimension   spacing = new Dimension(8, 0);
      JButton     b;

      for (int i = 0; i < buttons.size(); i++)
      {
         b = (JButton) buttons.get(i);
         b.setPreferredSize(d);

         if (i == 0)
         {
            panel.add(Box.createHorizontalGlue());
            panel.add(b);
            panel.add(Box.createRigidArea(spacing));
         }
         else
         {
            panel.add(b);
            panel.add(Box.createRigidArea(spacing));
         }
      }
      
      return panel;      
      
   }

   private JPanel buildStatusBar()
   {
      GridBagLayout layout   = new GridBagLayout();
      GridBagConstraints   constraints   = new GridBagConstraints();

      JPanel panel = new JPanel(layout);
      Dimension dim = panel.getPreferredSize();
      dim.setSize(dim.getWidth(), 25);
      panel.setPreferredSize(dim);

      // shared contrainst settings:
      constraints.anchor = GridBagConstraints.WEST;
      constraints.gridx = 0;
      constraints.gridy = 0;
      constraints.fill = GridBagConstraints.BOTH;
      constraints.weightx = 1.0;
      constraints.weighty = 0.0;

      mMessageAreaLabel.setFont(new Font("SansSerif", Font.PLAIN, 11));
      mMessageAreaLabel.setBorder(BorderFactory.createBevelBorder(BevelBorder.LOWERED));
      dim = mMessageAreaLabel.getPreferredSize();
      dim.setSize(dim.getWidth() + 150, dim.getHeight());
      mMessageAreaLabel.setPreferredSize(dim);
      mMessageAreaLabel.setText("Ready");
      
      panel.add(mMessageAreaLabel, constraints);

      constraints.anchor = GridBagConstraints.WEST;
      constraints.gridx = 1;
      constraints.gridy = 0;
      constraints.fill = GridBagConstraints.VERTICAL;
      constraints.weightx = 0.0;
      constraints.weighty = 0.0;

      mElapsedTimeLabel.setFont(new Font("SansSerif", Font.PLAIN, 11));
      mElapsedTimeLabel.setBorder(BorderFactory.createBevelBorder(BevelBorder.LOWERED));

      panel.add(mElapsedTimeLabel, constraints);

      return panel;      
   }

   void run()
   {
      reset();
      
      mRunButton.setEnabled(false);
      mResetButton.setEnabled(false);
      
      Thread simulationThread = new Thread()
      {
         public void run()
         {
            mController.start();
         }
      };

      simulationThread.start();
   }

   void reset()
   {
      mController.reset();
      resetPanelUI();
   }
   
   void stop()
   {
      mStopButton.setEnabled(false);
      mController.stop();
   }

   private void resetPanelUI()
   {
      mNumOfSessionsText.setText("0");
      mNumOfIterationsText.setText("0");
      mAvgDurationText.setText("0");

      if (mApplicationPoolViewPanel != null)
      {
         mApplicationPoolViewPanel.resetPanelUI();
      }

      if (mConnectionPoolViewPanel != null)
      {
         mConnectionPoolViewPanel.resetPanelUI();
      }

      if (mSimulationParametersPanel != null)
      {
         mSimulationParametersPanel.resetPanelUI();
      }
      
      mElapsedTimeLabel.setText("00:00:00");
      
      mResponseHistoryModel.reset();
      mAMPoolSizeHistoryModel.reset();
      mConnPoolSizeHistoryModel.reset();
      mHistoryGraph.reset();
   }

   private void update()
   {
      if (mUpdateUI)
      {
         updatePanelUI();
         
         if (mUpdateRunStatistics)
         {
            if (mController.getLogger() != null)
            {
               oracle.jbo.jbotester.load.Statistics loggerStats =
                  mController.getLogger().getStatistics();
      
               mNumOfSessionsText.setText(new Float(loggerStats.mNumOfSessions).toString());
               mNumOfIterationsText.setText(new Float(loggerStats.mNumOfIterations).toString());
      
               float roundedFloat = (float)Math.round(loggerStats.mAvgResponseTime * 10) / 10;
               mAvgDurationText.setText(new Float(roundedFloat).toString());
      
               mResponseHistoryModel.addDataPoint(loggerStats.mAvgResponseTime);
            }
         }
         
         mTimer.schedule(
               new TimerTask()
               {
                  public void run()
                  {
                     SwingUtilities.invokeLater(
                        new Runnable()
                        {
                           public void run()
                           {
                              update();
                           }
                        });
                  }
               }
               , REFRESH_RATE);
      }
   }
   
   private void updatePanelUI()
   {
      if (mApplicationPoolViewPanel != null)
      {
         mApplicationPoolViewPanel.updatePanelUI();
      }

      if (mConnectionPoolViewPanel != null)
      {
         mConnectionPoolViewPanel.updatePanelUI();
      }
      
      ResourcePoolStatistics connPoolStats = null;

      ConnectionPoolManager mgr = null;
      if (ConnectionPoolManagerFactory.isInitialized())
      {
         mgr = ConnectionPoolManagerFactory.getConnectionPoolManager();
      }

      if (mgr instanceof ResourcePoolManager)
      {
         Enumeration pools = ((ResourcePoolManager)mgr).getResourcePools();

         while (pools.hasMoreElements())
         {
            ResourcePool connPool = (ResourcePool)pools.nextElement();
            if (connPoolStats == null)
            {
               connPoolStats = connPool.getResourcePoolStatistics();
            }
            else
            {
               connPoolStats.add(connPool.getResourcePoolStatistics());
            }
         }
         
         mConnPoolSizeHistoryModel.addDataPoint(connPoolStats.mResourceCount);
/*
         mNumOfConnCreationsLabel.setText(new Long(connPoolStats.mNumOfInstanceCreations).toString());
         mNumOfConnRemovalsLabel.setText(new Long(connPoolStats.mNumOfInstanceRemovals).toString());
         mNumOfConnCheckoutsLabel.setText(new Long(connPoolStats.mNumOfCheckouts).toString());
         mNumOfConnCheckinsLabel.setText(new Long(connPoolStats.mNumOfCheckins).toString());
         mNumOfConnsLabel.setText(new Integer(connPoolStats.mResourceCount).toString());
         mMaxNumOfConnsLabel.setText(new Long(connPoolStats.mMaxNumOfInstances).toString());
         mAvgNumOfConnsLabel.setText(new Long(connPoolStats.mAvgNumOfInstances).toString());
         mNumOfAvailConnsLabel.setText(new Integer(connPoolStats.mAvailableResourceCount).toString());
         mNumOfConns10Label.setText(new Integer(connPoolStats.mResourceAgeHistogram.mBuckets[3]).toString());
         mNumOfConns5Label.setText(new Integer(connPoolStats.mResourceAgeHistogram.mBuckets[2]).toString());
         mNumOfConns1Label.setText(new Integer(connPoolStats.mResourceAgeHistogram.mBuckets[1]).toString());
         mNumOfConns0Label.setText(new Integer(connPoolStats.mResourceAgeHistogram.mBuckets[0]).toString());
*/         
      }
      
      ApplicationPool pool = mController.getApplicationPool(false);
      if (pool != null)
      {
         oracle.jbo.common.ampool.Statistics stats = pool.getStatistics();
      
         mAMPoolSizeHistoryModel.addDataPoint(stats.mResourceCount);
/*         
         mNumOfAMCreationsLabel.setText(new Long(stats.mNumOfInstanceCreations).toString());
         mNumOfAMRemovalsLabel.setText(new Long(stats.mNumOfInstanceRemovals).toString());
         mNumOfAMActivationsLabel.setText(new Long(stats.mNumOfStateActivations).toString());
         mNumOfAMPassivationsLabel.setText(new Long(stats.mNumOfStatePassivations).toString());
         mNumOfAMCheckoutsLabel.setText(new Long(stats.mNumOfCheckouts).toString());
         mNumOfAMCheckinsLabel.setText(new Long(stats.mNumOfCheckins).toString());
         mNumOfRefAMReuseLabel.setText(new Long(stats.mNumOfInstancesReused).toString());
         mNumOfRefAMRecycleLabel.setText(new Long(stats.mNumOfReferencedInstancesRecycled).toString());
         mNumOfUnrefAMRecycleLabel.setText(new Long(stats.mNumOfUnreferencedInstancesRecycled).toString());
         mNumOfAMsLabel.setText(new Integer(stats.mResourceCount).toString());
         mMaxNumOfAMsLabel.setText(new Long(stats.mMaxNumOfInstances).toString());
         mAvgNumOfAMsLabel.setText(new Long(stats.mAvgNumOfInstances).toString());
         mNumOfAvailAMsLabel.setText(new Integer(stats.mAvailableResourceCount).toString());
         mNumOfRefAMsLabel.setText(new Integer(stats.mReferencedApplicationModules).toString());
         mNumOfRefAMs10Label.setText(new Integer(stats.mRefInstanceAgeHistogram.mBuckets[3]).toString());
         mNumOfRefAMs5Label.setText(new Integer(stats.mRefInstanceAgeHistogram.mBuckets[2]).toString());
         mNumOfRefAMs1Label.setText(new Integer(stats.mRefInstanceAgeHistogram.mBuckets[1]).toString());
         mNumOfRefAMs0Label.setText(new Integer(stats.mRefInstanceAgeHistogram.mBuckets[0]).toString());
         mNumOfAMs10Label.setText(new Integer(stats.mUnrefInstanceAgeHistogram.mBuckets[3]).toString());
         mNumOfAMs5Label.setText(new Integer(stats.mUnrefInstanceAgeHistogram.mBuckets[2]).toString());
         mNumOfAMs1Label.setText(new Integer(stats.mUnrefInstanceAgeHistogram.mBuckets[1]).toString());
         mNumOfAMs0Label.setText(new Integer(stats.mUnrefInstanceAgeHistogram.mBuckets[0]).toString());
         mNumOfSessionsLabel.setText(new Integer(stats.mNumOfSessions).toString());
         mAvgNumOfSessionsLabel.setText(new Long(stats.mAvgNumOfSessionsReferencingState).toString());
         mNumOfSessions10Label.setText(new Integer(stats.mSessionAgeHistogram.mBuckets[3]).toString());
         mNumOfSessions5Label.setText(new Integer(stats.mSessionAgeHistogram.mBuckets[2]).toString());
         mNumOfSessions1Label.setText(new Integer(stats.mSessionAgeHistogram.mBuckets[1]).toString());
         mNumOfSessions0Label.setText(new Integer(stats.mSessionAgeHistogram.mBuckets[0]).toString());
*/         
      }

      Date date = new Date(mController.getElapsedRunningTime());
      date.setMinutes(date.getMinutes() + date.getTimezoneOffset());
      
      mElapsedTimeLabel.setText(mDateFormatter.format(date));

   }

   void fileExit_ActionPerformed(ActionEvent e)
   {
      System.exit(0);
   }

   void editSimulation_ActionPerformed(ActionEvent e)
   {
      mMenuEditSimulation.setEnabled(false);

      JFrame frame = new JFrame("Simulation Parameters...");
      GridBagLayout layout   = new GridBagLayout();
      GridBagConstraints   constraints   = new GridBagConstraints();
      frame.getContentPane().setLayout(layout);

      frame.setSize(new Dimension(450, 220));
      frame.addWindowListener(new WindowAdapter()
      {
         public void windowClosing(WindowEvent e)
         {
            mSimulationParametersPanel = null;
            mMenuEditSimulation.setEnabled(true);
         }
      });

      constraints.anchor = GridBagConstraints.NORTHWEST;
      constraints.gridx = 0;
      constraints.gridy = 0;
      constraints.weighty=0;
      constraints.weightx=1;
      constraints.gridheight=1;
      constraints.fill=GridBagConstraints.HORIZONTAL;
      constraints.insets=new Insets(5,5,5,5);

      mSimulationParametersPanel = new SimulationParametersPanel(mController);
      layout.setConstraints(mSimulationParametersPanel, constraints);
      frame.getContentPane().add(mSimulationParametersPanel);

      Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
      Dimension frameSize = getSize();
      if (frameSize.height > screenSize.height)
      {
         frameSize.height = screenSize.height;
      }
      if (frameSize.width > screenSize.width)
      {
         frameSize.width = screenSize.width;
      }
      frame.setLocation((screenSize.width - frameSize.width) / 2, (screenSize.height - frameSize.height) / 2);

      frame.setVisible(true);
   }

   void editPool_ActionPerformed(ActionEvent e)
   {
      mMenuEditPool.setEnabled(false);

      JFrame frame = new JFrame("Pool Parameters");
      GridBagLayout layout   = new GridBagLayout();
      GridBagConstraints   constraints   = new GridBagConstraints();
      frame.getContentPane().setLayout(layout);

      frame.setSize(new Dimension(450, 450));
      frame.addWindowListener(new WindowAdapter()
      {
         public void windowClosing(WindowEvent e)
         {
//            ApplicationPoolViewPanel panel = mApplicationPoolViewPanel;
//            mApplicationPoolViewPanel = null;

//            panel.close();
            mMenuEditPool.setEnabled(true);
         }
      });

      constraints.anchor = GridBagConstraints.NORTHWEST;
      constraints.gridx = 0;
      constraints.gridy = 0;
      constraints.weighty=0;
      constraints.weightx=1;
      constraints.gridheight=1;
      constraints.fill=GridBagConstraints.HORIZONTAL;
      constraints.insets=new Insets(5,5,5,5);

      PoolParameterPanel panel = new PoolParameterPanel(this, mController);
      layout.setConstraints(panel, constraints);
      frame.getContentPane().add(panel);

      Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
      Dimension frameSize = getSize();
      if (frameSize.height > screenSize.height)
      {
         frameSize.height = screenSize.height;
      }
      if (frameSize.width > screenSize.width)
      {
         frameSize.width = screenSize.width;
      }
      frame.setLocation((screenSize.width - frameSize.width) / 2, (screenSize.height - frameSize.height) / 2);

      frame.setVisible(true);
   }
   
   void viewAMPool_ActionPerformed(ActionEvent e)
   {
      mMenuViewAMPool.setEnabled(false);
      
      JFrame frame = new JFrame("ApplicationPool Statistics");
      GridBagLayout layout   = new GridBagLayout();
      GridBagConstraints   constraints   = new GridBagConstraints();
      frame.getContentPane().setLayout(layout);

      frame.setSize(new Dimension(450, 700));
      frame.addWindowListener(new WindowAdapter()
      {
         public void windowClosing(WindowEvent e)
         {
            ApplicationPoolViewPanel panel = mApplicationPoolViewPanel;
            mApplicationPoolViewPanel = null;

            panel.close();
            mMenuViewAMPool.setEnabled(true);
         }
      });

      constraints.anchor = GridBagConstraints.NORTHWEST;
      constraints.gridx = 0;
      constraints.gridy = 0;
      constraints.weighty=0;
      constraints.weightx=1;
      constraints.gridheight=1;
      constraints.fill=GridBagConstraints.HORIZONTAL;
      constraints.insets=new Insets(5,5,5,5);

      mApplicationPoolViewPanel = new ApplicationPoolViewPanel(mController);
      layout.setConstraints(mApplicationPoolViewPanel, constraints);
      frame.getContentPane().add(mApplicationPoolViewPanel);

//      JPanel panel = new GraphViewPanel(mController);
//      layout.setConstraints(panel, constraints);
//      frame.getContentPane().add(panel);


      Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
      Dimension frameSize = getSize();
      if (frameSize.height > screenSize.height)
      {
         frameSize.height = screenSize.height;
      }
      if (frameSize.width > screenSize.width)
      {
         frameSize.width = screenSize.width;
      }
      frame.setLocation((screenSize.width - frameSize.width) / 2, (screenSize.height - frameSize.height) / 2);

      frame.setVisible(true);
   }

   void viewConnPool_ActionPerformed(ActionEvent e)
   {
      mMenuViewConnPool.setEnabled(false);
      JFrame frame = new JFrame("ConnectionPool Statistics");
      GridBagLayout layout   = new GridBagLayout();
      GridBagConstraints   constraints   = new GridBagConstraints();
      frame.getContentPane().setLayout(layout);

      frame.setSize(new Dimension(450, 320));
      frame.addWindowListener(new WindowAdapter()
      {
         public void windowClosing(WindowEvent e)
         {
            ConnectionPoolViewPanel panel = mConnectionPoolViewPanel;
            mConnectionPoolViewPanel = null;

            panel.close();
            mMenuViewConnPool.setEnabled(true);
         }
      });

      constraints.anchor = GridBagConstraints.NORTHWEST;
      constraints.gridx = 0;
      constraints.gridy = 0;
      constraints.weighty=0;
      constraints.weightx=1;
      constraints.gridheight=1;
      constraints.fill=GridBagConstraints.HORIZONTAL;
      constraints.insets=new Insets(5,5,5,5);

      mConnectionPoolViewPanel = new ConnectionPoolViewPanel(mController);
      layout.setConstraints(mConnectionPoolViewPanel, constraints);
      frame.getContentPane().add(mConnectionPoolViewPanel);

      Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
      Dimension frameSize = getSize();
      if (frameSize.height > screenSize.height)
      {
         frameSize.height = screenSize.height;
      }
      if (frameSize.width > screenSize.width)
      {
         frameSize.width = screenSize.width;
      }
      frame.setLocation((screenSize.width - frameSize.width) / 2, (screenSize.height - frameSize.height) / 2);

      frame.setVisible(true);
   }


   public static void main(String[] args)
   {
      try
      {
         UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
      }
      catch (Exception e)
      {
      }

      MainFrame mainFrame = new MainFrame();
   }
}
