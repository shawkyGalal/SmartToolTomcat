/*
 * @(#)MainWindow.java
 *
 * Copyright 1999-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.jbotester;

import java.awt.CardLayout;
import java.util.Hashtable;
import javax.swing.JApplet;
import javax.swing.JPanel;
import oracle.jbo.ApplicationModule;
import oracle.jbo.common.Diagnostic;

public class MainWindow extends JApplet
{
   public static final String APPMODULE_PANEL = "AppModule";
   public static final String VIEW_PANEL = "ViewObjects";

   private static Hashtable mORBProperties = null;

   static boolean isStandalone = true;
   JPanel mainPanel = new JPanel();
   CardLayout cardLayout1 = new CardLayout();
   BaseTree appPanel = new BaseTree();

   ApplicationModule mRootAppModule = null;

   public static MainWindow mApplet = null;

//Get a parameter value

   public String getParameter(String key, String def)
   {
      return isStandalone ? System.getProperty(key, def) :
      (getParameter(key) != null ? getParameter(key) : def);
   }

   // Override Applet's getParameter to look in the ORB parameters
   public String getParameter(String key)
   {
      if(mORBProperties != null)
      {
         Object o = mORBProperties.get(key);
         if(o != null)
         {
            return o.toString();
         }
      }
      return super.getParameter(key);
   }

   //Construct the applet

   public MainWindow()
   {
      
   }
//Initialize the applet

   public void init()
   {
      try
      {
         jbInit();
      }
      catch(Exception e)
      {
         Diagnostic.printStackTrace(e);
      }
   }
//Component initialization

   private void jbInit() throws Exception
   {
//      ConnectionPanel conPanel = new ConnectionPanel(null);
      //conPanel.setParent(this);
      mainPanel.setLayout(cardLayout1);
      mainPanel.add(appPanel, APPMODULE_PANEL);
      this.getContentPane().add(mainPanel, null);

      String mode = getParameter("Mode", "None");
      if ((mode == null) || (mode.length() <= 0))
      {
         return ;
      }
      
//      conPanel.setOrbMode(mode);
   }
//Start the applet

   public void start()
   {
      // Initialize this only in the Applet Environment.
      mApplet = this;
   }
//Stop the applet

   public void stop()
   {
      if(mRootAppModule != null)
      {
         mRootAppModule.getTransaction().disconnect();
         mRootAppModule = null;
      }
   }
//Destroy the applet

   public void destroy()
   {
      if(mRootAppModule != null)
      {
         mRootAppModule.getTransaction().disconnect();
         mRootAppModule = null;
      }
   }
//Get Applet information

   public String getAppletInfo()
   {
      return "Applet Information";
   }
//Get parameter info

   public String[][] getParameterInfo()
   {
      return null;
   }
//Main method
/*
  public static void main(String[] args) {
    MainWindow applet = new MainWindow();
    applet.isStandalone = true;
    JFrame frame = new JFrame();
    frame.setTitle("Applet Frame");
    frame.getContentPane().add(applet, BorderLayout.CENTER);
    applet.init();
    applet.start();
    frame.setSize(500,300);
    frame.addWindowListener(new WindowListener() {
       public void windowOpened(WindowEvent p0){}
       public void windowClosing(WindowEvent p0)
       {
          System.exit(0);
       }
       public void windowClosed(WindowEvent p0){}
       public void windowIconified(WindowEvent p0){}
       public void windowDeiconified(WindowEvent p0){}
       public void windowActivated(WindowEvent p0){}
       public void windowDeactivated(WindowEvent p0){}
    });
    Dimension d = Toolkit.getDefaultToolkit().getScreenSize();
    frame.setLocation((d.width - frame.getSize().width) / 2, (d.height - frame.getSize().height) / 2);
    frame.setVisible(true);
  }
*/

   public void connected(ApplicationModule appMod)
   {
      mRootAppModule = appMod;
      appPanel.setAppModule(appMod);
      cardLayout1.show(mainPanel, APPMODULE_PANEL);
   }

   public static MainWindow getApplet()
   {
      return mApplet;
   }

   public static boolean isStandaloneApp()
   {
      return isStandalone;
   }

   public static void setORBProperties(Hashtable orbProps)
   {
      mORBProperties = orbProps;
   }
}

