/*
 * @(#)MainFrame.java
 *
 * Copyright 1999-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.jbotester;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.Frame;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.lang.reflect.Method;
import java.util.Hashtable;
import javax.swing.Action;
import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JSplitPane;
import javax.swing.JToolBar;
import javax.swing.JWindow;
import javax.swing.KeyStroke;
import javax.swing.SwingConstants;
import javax.swing.UIManager;
import javax.swing.WindowConstants;
import javax.swing.event.MenuEvent;
import javax.swing.event.MenuListener;
import oracle.jbo.ApplicationModule;
import oracle.jbo.CSMessageBundle;
import oracle.jbo.JboException;
import oracle.jbo.Version;
import oracle.jbo.ViewObject;
import oracle.jbo.client.Configuration;
import oracle.jbo.common.Diagnostic;
import oracle.jbo.common.PropertyMetadata;

public final class MainFrame extends JFrame
{
   private static MainFrame frame;
   private static ByteArrayOutputStream sysOut;
   private static String      helpUrlStr;
   private static HelpManager helpMan;

   private boolean      noConnectionDialog;
   private JMenuItem    menuViewOutput;
   private JMenuItem    menuViewDataXML;
   private JMenuItem    menuCreateAM;
   private JMenuItem    menuCreateVO;
   private JMenuItem    menuCreateVL;

   private JComponent   statusBar;
   private JLabel       statusLine;

   static
   {
      try
      {
         if (UIManager.getSystemLookAndFeelClassName().toLowerCase().indexOf(".windows.") > 0)  // DtuUtil.isWindows()
         {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());  // should be in JBuilder, not here
         }
      }
      catch (Exception e)
      {
         Diagnostic.println("Cannot set windows look and feel");
      }
   }


   private final JSplitPane   mSplitPane  = new JSplitPane();
   private BaseTree     mObjectTree;
   private ResultWindow mResultPanel;

   private JWindow mPopup;

   private final Action connectAction     = new FileConnectAction();
   private final Action disconnectAction  = new FileDisconnectAction();
   private final Action commitAction      = new CommitAction();
   private final Action rollbackAction    = new RollbackAction();
   private final Action exitAction        = new FileExitAction();
   private final Action saveAmAction      = new FileSaveAction();
   private final Action loadAmAction      = new FileLoadAction();
   private final Action helpContentAction = new HelpContentAction();

   private Hashtable mConnectionParams;

   private Configuration mConfiguration;
   private String mConfigurationName;

   public MainFrame(Hashtable params)
   {
      this();

      setConnectionParams(params);
   }

   public MainFrame()
   {
      super();
   }

   public static MainFrame getInstance()
   {
      return frame;
   }

   public BaseTree getBaseTree()
   {
      return mObjectTree;
   }

   public Dimension getPreferredSize()
   {
      return new Dimension(640, 480);
   }

   public void exit()
   {
      try
      {
         ConnectionInfo.releaseApplicationModule();
      }
      catch (Exception ex)
      {
         Diagnostic.println("Fail during disconnect.");
      }
      finally
      {
         System.out.println("BC4J Tester exit code(0)");
         System.exit(0);
      }
   }
   
   
   public void setConnectionParams(Hashtable params)
   {
      mConnectionParams = params;

      try
      {
         noConnectionDialog = (params.get(PropertyMetadata.DEPLOY_PLATFORM.getName()) != null);
   
         mResultPanel = ResultWindow.createResultWindow();
         mObjectTree = new BaseTree();
   
         addWindowListener(new WindowAdapter()
            {
               public void windowClosing(WindowEvent e)
               {
                  exit();
               }
   
               public void windowActivated(WindowEvent e)
               {
                  if (mPopup != null)
                  {
                     mPopup.setVisible(false);
                  }
               }
            });
   
         setDefaultCloseOperation(WindowConstants.DO_NOTHING_ON_CLOSE);
   
         getRootPane().registerKeyboardAction(helpContentAction,
            KeyStroke.getKeyStroke(KeyEvent.VK_F1, 0), JComponent.WHEN_IN_FOCUSED_WINDOW);
   
         this.setJMenuBar(createMainMenuBar());
         this.getContentPane().add(createMainToolBar(), BorderLayout.NORTH);
         this.getContentPane().add(createStatusBar(), BorderLayout.SOUTH);
         this.getContentPane().add(mSplitPane, BorderLayout.CENTER);
         mSplitPane.setLeftComponent(mObjectTree);
         mSplitPane.setRightComponent(mResultPanel.getTabbedPane());
         disconnected();
      }
      catch (Throwable t)
      {
         ErrorHandler.displayError(this, t);
         exitAction.actionPerformed(null);
      }
      
   }

   public Hashtable getConnectionParams()
   {
      return mConnectionParams;
   }

   public Configuration getConfiguration()
   {
      return mConfiguration;
   }

   public void setConfiguration(Configuration configuration)
   {
      mConfiguration = configuration;
   }

   public String getConfigurationName()
   {
      return mConfigurationName;
   }

   public void setConfigurationName(String configName)
   {
      mConfigurationName = configName;
   }

   void helpAbout_ActionPerformed(ActionEvent e)
   {
      GenericDialog gd = new GenericDialog(this, Res.format(Res.TESTER_ABOUT_BOX, Res.format(Res.TESTER_TITLE, "")),
                                           new MainFrame_AboutBoxPanel1(), GenericDialog.OK_OPTION);
      gd.show();
   }

   private void viewDataXML_ActionPerformed(ActionEvent e)
   {
      int ret = JOptionPane.showConfirmDialog(this, Res.getString(Res.MAIN_XMLDATA_WARNING), Res.getString(Res.MAIN_XMLDATA_CONFIRM),
                                              JOptionPane.YES_NO_CANCEL_OPTION,
                                              JOptionPane.QUESTION_MESSAGE);


      if (ret == JOptionPane.YES_OPTION)
      {
         // user selected yes to continue.
         ViewObject vo = (ViewObject) mObjectTree.getSelectedObject();
         OutputDialog out = new OutputDialog(this, Res.getString(Res.MAIN_TITLE_XMLWINDOW), true);

         out.setText(JboTesterUtil.getDataAsXML(vo));

         out.setLocationRelativeTo(frame);

         out.pack();
         out.setVisible(true);
      }
   }

   public void launchConnectDialog()
   {
      String classNames[] = { "oracle.jbo.jbotester.jdev.ConnectionDialog",
                              "oracle.jbo.jbotester.jdevx.ConnectionDialog" };
      Class cls = null;
      String implClassName;
       
      if (Version.isUsing32IDE())
      {
         implClassName = classNames[0];
         Diagnostic.println("Loading 3.2 connection dialog");
      }
      else
      {
         implClassName = classNames[1];
         Diagnostic.println("Loading 5.0 connection dialog");
      }
         
      try
      {
         cls = Class.forName(implClassName);
      }
      catch (ClassNotFoundException ce)
      {
         ErrorHandler.displayError(this, ce);
      }

      try
      {
         Method launchConnectDialogMethod = cls.getMethod("launchConnectDialog", new Class[]
                                                {  Frame.class,
                                                   Hashtable.class
                                                });
         Object args[] = new Object[] { frame, getConnectionParams() };
         launchConnectDialogMethod.invoke(null, args);
      }
      catch (Exception e)
      {
         ErrorHandler.displayError(this, e);
      }
      
      if (ConnectionInfo.isConnected())
      {
         frame.connected();
      }
   }

   public static void StartClient(String packageName, String configName)
   {
      frame = new MainFrame();

      // Set the environment using the configuration file
      Configuration config = new Configuration();

      Hashtable params = null;
      try
      {
         config.loadFromClassPath(Configuration.buildConfigurationFileNameFromClassPath(packageName));
         params = config.getConfiguration(configName);
      }
      catch (Exception e)
      {
         ErrorHandler.displayError(frame, e);
         System.exit(0);

         // JRS Display the exception if the configuration is not located
         // the configuration is not required by the tester
         //params = new Hashtable();
      }

      frame.setConfiguration(config);
      frame.setConfigurationName(configName);

      frame.setConnectionParams(params);
      frame.init();
   }

   public static void main(String[] args)
   {
      frame = new MainFrame();
      Hashtable params = frame.processArgs(args);
      frame.setConnectionParams(params);
      frame.init();
   }

   private void init()
   {
      if (noConnectionDialog)
      {
         try
         {
            setCursor(Cursor.getPredefinedCursor(Cursor.WAIT_CURSOR));

            if (!ConnectionInfo.useApplicationModule(
               this
               , getConfiguration()
               , getConfigurationName()))
            {
               exitAction.actionPerformed(null);
            }
         }
         catch (Throwable t)
         {
            ErrorHandler.displayError(frame, t);
            exitAction.actionPerformed(null);
         }

         setCursor(Cursor.getPredefinedCursor(Cursor.DEFAULT_CURSOR));

         if (ConnectionInfo.isConnected())
         {
            connected();
         }
      }
      else
      {
         // If we were unsuccesfull to retrieve param, bring up the connection dialog
         launchConnectDialog();
      }

      mSplitPane.resetToPreferredSizes();
      Dimension size = mSplitPane.getLeftComponent().getPreferredSize();
      mSplitPane.setDividerLocation(size.width + mSplitPane.getDividerSize()/ 2 + 1);
      
      pack();
      JboTesterUtil.centerWindow(this);
      setVisible(true);
   }


   public void connected()
   {
      // Enable/Disable menu items and toolbar buttons
      if (!noConnectionDialog)
      {
         connectAction.setEnabled(false);
         disconnectAction.setEnabled(true);
      }

      saveAmAction.setEnabled(true);
      loadAmAction.setEnabled(true);

      commitAction.setEnabled(true);
      rollbackAction.setEnabled(true);

      // Display the Objects Tree in the Splitter window
      mObjectTree.setAppModule(ConnectionInfo.getRootAppModule());

      updateTitle();
      this.setCursor(Cursor.getPredefinedCursor(Cursor.DEFAULT_CURSOR));
   }

   public void disconnected()
   {
      if (!noConnectionDialog)
      {
         connectAction.setEnabled(true);
         disconnectAction.setEnabled(false);
      }
      
      commitAction.setEnabled(false);
      rollbackAction.setEnabled(false);

      menuCreateAM.setEnabled(false);
      menuCreateVO.setEnabled(false);
      menuCreateVL.setEnabled(false);
      mObjectTree.clearAll();
      updateTitle();
  }

   public void viewMenu_Selected(MenuEvent e)
   {
      boolean enabled = mObjectTree.getSelectedObject() instanceof ViewObject;

      menuViewDataXML.setEnabled(enabled);
  }

  public void createMenu_Selected(MenuEvent e)
  {
     boolean enabled = mObjectTree.getSelectedObject() instanceof ApplicationModule;

     menuCreateAM.setEnabled(enabled);
     menuCreateVO.setEnabled(enabled);
     menuCreateVL.setEnabled(enabled);
  }

   private Hashtable processArgs(String[] args)
   {
      Hashtable connInfo = new Hashtable(20);
      int i= 0;
      String str = null;

      while ( i < args.length )
      {
         if (args[i].equalsIgnoreCase("-X"))
         {
            str = args[++i];
            if ( str != null )
            {
               Configuration testerConfig = new Configuration();
               testerConfig.loadFromClassPath("tester.xcfg");
               connInfo = testerConfig.getConfiguration(str);

               setConfiguration(testerConfig);
               setConfigurationName(str);
            }
         }
         else if (args[i].equalsIgnoreCase("-H"))
         {
            str = args[++i];
            if ( str != null )
            {
               helpUrlStr = str;
            }
         }
         else if (args[i].equalsIgnoreCase("-O"))
         {
            sysOut = new ByteArrayOutputStream();
            System.setOut(new PrintStream(sysOut));
         }
         
         i++;
      }

      return connInfo;
   }

   public static JMenuItem addMenuItem(JMenu menu, int resId)
   {
      JMenuItem item;

      String caption = Res.getString(resId);
      item = (JMenuItem) menu.add(JboTesterUtil.stripMnemonic(caption));
      
      int mnemonic  = JboTesterUtil.getMnemonicKeyCode(caption);
      if (mnemonic != 0)
      {
         item.setMnemonic(mnemonic);
      }

      return item;
   }

   public static JMenu createMenu(int resId)
   {
      JMenu menu;

      String caption = Res.getString(resId);
      menu = new JMenu(JboTesterUtil.stripMnemonic(caption));
      
      int mnemonic  = JboTesterUtil.getMnemonicKeyCode(caption);
      if (mnemonic != 0)
      {
         menu.setMnemonic(mnemonic);
      }

      return menu;
   }

   private JMenuBar createMainMenuBar()
   {
      JMenuBar    mainMenuBar = new JMenuBar();
      JMenu       menuFile = createMenu(Res.MAIN_MENU_FILE);
      JMenu       menuView = createMenu(Res.MAIN_MENU_VIEW);
      JMenu       menuDatabase = createMenu(Res.MAIN_MENU_DATABASE);
      JMenu       menuHelp = createMenu(Res.MAIN_MENU_HELP);
      JMenu       menuCreate = createMenu(Res.MAIN_MENU_CREATE);
      JMenuItem   item;

      if (!noConnectionDialog)
      {
         menuFile.add(connectAction);
         menuFile.add(disconnectAction);
         menuFile.addSeparator();
      }

      menuFile.add(saveAmAction);
      saveAmAction.setEnabled(false);

      menuFile.add(loadAmAction);
      loadAmAction.setEnabled(false);
      
      item = menuFile.add(exitAction);
      item.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_F4, ActionEvent.ALT_MASK));

      if (!noConnectionDialog && sysOut != null)
      {
         menuViewOutput = (JMenuItem) menuView.add(new JMenuItem(Res.getString(Res.MAIN_MENU_OUTPUT)));

         menuViewOutput.addActionListener(new ActionListener()
         {
            public void actionPerformed(ActionEvent e)
            {
               OutputDialog out = new OutputDialog(MainFrame.this, Res.getString(Res.MAIN_TITLE_OUTPUT_DIALOG), true);

               out.setText(sysOut.toString());
               out.setLocationRelativeTo(frame);

               out.pack();
               out.setVisible(true);
            }
         });
      }

      menuViewDataXML = addMenuItem(menuView, Res.MAIN_MENU_XML);
      menuViewDataXML.addActionListener(new ActionListener()
      {
         public void actionPerformed(ActionEvent e)
         {
            viewDataXML_ActionPerformed(e);
         }
      });

      item = menuDatabase.add(commitAction);
      item.setAccelerator(KeyStroke.getKeyStroke(Res.getString(Res.MAIN_TOOLBAR_COMMIT_KEY).charAt(0), ActionEvent.ALT_MASK));
      item = menuDatabase.add(rollbackAction);
      item.setAccelerator(KeyStroke.getKeyStroke(Res.getString(Res.MAIN_TOOLBAR_ROLLBACK_KEY).charAt(0), ActionEvent.ALT_MASK));
      
      menuHelp.add(helpContentAction);

      item = addMenuItem(menuHelp, Res.MAIN_MENU_ABOUT);
      item.addActionListener(new ActionListener()
      {
         public void actionPerformed(ActionEvent e)
         {
            helpAbout_ActionPerformed(e);
         }
      });

      menuCreateAM = (JMenuItem) menuCreate.add(ObjTreeNode.createAMAction);
      menuCreateVO = (JMenuItem) menuCreate.add(ObjTreeNode.createVOAction);
      menuCreateVL = (JMenuItem) menuCreate.add(ObjTreeNode.createVLAction);

      menuView.addMenuListener(new MenuListener()
      {
         public void menuCanceled(MenuEvent p0) {}
         public void menuDeselected(MenuEvent p0){}
         public void menuSelected(MenuEvent e)
         {
            viewMenu_Selected(e);
         }
      });

      menuCreate.addMenuListener(new MenuListener()
      {
         public void menuCanceled(MenuEvent p0) {}
         public void menuDeselected(MenuEvent p0){}
         public void menuSelected(MenuEvent e)
         {
            createMenu_Selected(e);
         }
      });

      mainMenuBar.add(menuFile);
      mainMenuBar.add(menuView);
      mainMenuBar.add(menuCreate);
      mainMenuBar.add(menuDatabase);
      mainMenuBar.add(menuHelp);

      return mainMenuBar;
   }

   private JToolBar createMainToolBar()
   {
      JToolBar mToolBar = new JToolBar();

      if (!noConnectionDialog)
      {
         addToolbarButton(mToolBar, connectAction, Res.MAIN_TOOLBAR_CONNECT_KEY, NavBar.CONNECT);
         addToolbarButton(mToolBar, disconnectAction, Res.MAIN_TOOLBAR_DISCONNECT_KEY, NavBar.DISCONNECT);

         mToolBar.addSeparator();
      }

      addToolbarButton(mToolBar, commitAction, Res.MAIN_TOOLBAR_COMMIT_KEY, NavBar.COMMIT);
      addToolbarButton(mToolBar, rollbackAction, Res.MAIN_TOOLBAR_ROLLBACK_KEY, NavBar.ROLLBACK);

      return mToolBar;
   }

   private JButton addToolbarButton(JToolBar toolbar, Action act, int mnemonicRes, int index)
   {
      JButton button = toolbar.add(act);
      NavBar.initButton(button, Res.getString(mnemonicRes).charAt(0), index);
      return button;
   }


   public void updateTitle()
   {
      this.setTitle(Res.format(Res.TESTER_TITLE, Res.format(Res.MAIN_TITLE_CONNECTION, ConnectionInfo.getConnectionTitle())));
   }

   private Component createStatusBar()
   {
      statusBar = new StatusBar();

      statusLine = new JLabel("", SwingConstants.LEFT);
      statusBar.add(statusLine);

      return statusBar;
   }

   final JLabel getStatusLine()
   {
      return statusLine;
   }

   boolean isHelpAvailable()
   {
      return (helpUrlStr != null);
   }

   
   public void helpMe(String topicID)
   {
      if (helpMan == null)
      {
         helpMan = new HelpManager(helpUrlStr);
      }

      helpMan.helpMe(topicID);
   }
   
   public void setPopup(JWindow window)
   {
      mPopup = window;
   }

   private final class StatusBar extends JComponent
   {
      public StatusBar()
      {
         super();
         setLayout(new BoxLayout(this, BoxLayout.X_AXIS));
         setBorder(BorderFactory.createEmptyBorder(2, 2, 2, 2));
      }

      public void paint(Graphics g)
      {
         super.paint(g);
      }
   }

   abstract class AbstractMainAction extends AbstractJboAction
   {
      public AbstractMainAction(String name)
      {
         super(name);
      }

      public AbstractMainAction(String name, int index, int tooltipResId)
      {
         super(name, index, tooltipResId);
      }
      
      protected MainFrame getMainFrame()
      {
         return MainFrame.this;
      }
   }
   
   private final class FileConnectAction extends AbstractMainAction
   {
      public FileConnectAction()
      {
         super(Res.getString(Res.MAIN_MENU_CONNECT), NavBar.CONNECT, Res.MAIN_TOOLBAR_CONNECT);
      }

      protected void doAction(ActionEvent e)
      {
         MainFrame.this.launchConnectDialog();
      }
   }

   private final class FileDisconnectAction extends AbstractMainAction
   {
      public FileDisconnectAction()
      {
         super(Res.getString(Res.MAIN_MENU_DISCONNECT), NavBar.DISCONNECT, Res.MAIN_TOOLBAR_DISCONNECT);
      }

      protected void doAction(ActionEvent e)
      {
         // not used
      }
      
      public void actionPerformed(ActionEvent e)
      {
         ApplicationModule am = ConnectionInfo.getRootAppModule();
         if (am != null)
         {
            ConnectionInfo.releaseApplicationModule();
            mResultPanel.removeAllTabs();
            disconnected();
         }
      }
   }

   private final class CommitAction extends AbstractMainAction
   {
      public CommitAction()
      {
         super(Res.getString(Res.MAIN_MENU_COMMIT), NavBar.COMMIT, Res.MAIN_TOOLBAR_COMMIT);
      }

      protected void doAction(ActionEvent e)
      {
         ApplicationModule am = ConnectionInfo.getRootAppModule();
         if (am != null)
         {
            am.getTransaction().commit();
            // Since there is no commit event, always refresh the view without changing
            // the currency. This is to update the readonly state of some fields, like
            // only when new field (bug 1560237).
            mResultPanel.refreshAll(false);
         }
      }
   }

   private final class RollbackAction extends AbstractMainAction
   {
      public RollbackAction()
      {
         super(Res.getString(Res.MAIN_MENU_ROLLBACK), NavBar.ROLLBACK, Res.MAIN_TOOLBAR_ROLLBACK);
      }

      protected void doAction(ActionEvent e)
      {
         ApplicationModule am = ConnectionInfo.getRootAppModule();
         if (am != null)
         {
            am.getTransaction().rollback();
            // After rollback, need to refresh all currently open views.
            mResultPanel.refreshAll(true);

            // enable the commit button as it could have been disabled by passivate/save.
            commitAction.setEnabled(true);      
         }
      }
   }

   private final class FileExitAction extends AbstractMainAction
   {
      public FileExitAction()
      {
         super(Res.getString(Res.MAIN_MENU_EXIT));
      }

      protected void doAction(ActionEvent e)
      {
         // not used
      }
      
      public void actionPerformed(ActionEvent e)
      {
//         if (isApplet())
//         {
//            dispose();
//         }
//         else
//         {
            exit();
//         }
      }
   }

   private final class FileSaveAction extends AbstractMainAction
   {
      public FileSaveAction()
      {
         super(Res.getString(Res.MAIN_MENU_SAVE_TXN));
      }

      protected void doAction(ActionEvent e)
      {
         int l = ConnectionInfo.getRootAppModule().passivateState(new byte[]{});
         JOptionPane.showMessageDialog(MainFrame.this, Res.getString(Res.STR_TXN_ID_)+l, Res.getString(Res.STR_PASSIVATED), /*"Save",*/ JOptionPane.INFORMATION_MESSAGE);         
         commitAction.setEnabled(false);
      }
   }
   
   private final class FileLoadAction extends AbstractMainAction
   {
      public FileLoadAction()
      {
         super(Res.getString(Res.MAIN_MENU_LOAD_TXN));
      }

      protected void doAction(ActionEvent e)
      {
         // not used
      }
      
      public void actionPerformed(ActionEvent event)
      {
         try
         {
            String s = JOptionPane.showInputDialog(Res.getString(Res.STR_TXN_ID_));
            if (s == null || s.trim().length() == 0) 
            {
               //noop.
               return;
            }
            ConnectionInfo.getRootAppModule().activateState(Integer.valueOf(s).intValue(), true);
            mResultPanel.refreshAfterActivate();
            mResultPanel.refreshAll(false);
            JOptionPane.showMessageDialog(MainFrame.this, Res.getString(Res.STR_TXN_ID_)+s, Res.getString(Res.STR_ACTIVATED), /*"Save",*/ JOptionPane.INFORMATION_MESSAGE);         
            commitAction.setEnabled(true);      
         }
         catch (JboException je)
         {
            if (je.getErrorCode().equals(CSMessageBundle.EXC_PCOLL_INVALID_ROOT_NODE))
            {
               ErrorHandler.displayError(MainFrame.this, Res.getString(Res.ERROR_INVALID_ROOT_NODE));
            }
            else
            {
               ErrorHandler.displayError(MainFrame.this, je);
            }
         }
         catch (java.lang.NumberFormatException e)
         {
            ErrorHandler.displayError(MainFrame.this, Res.getString(Res.ERROR_INVALID_NUMBER)+e.getMessage());
         }
         catch (Exception ex)
         {
            ErrorHandler.displayError(MainFrame.this, ex);
         }
      }
   }

   private final class HelpContentAction extends AbstractMainAction
   {
      public HelpContentAction()
      {
         super(Res.getString(Res.MAIN_MENU_HELP_CONTENT));
      }

      protected void doAction(ActionEvent e)
      {
         helpMe("f1_bcbctbrowser_html");
      }
   }
}

