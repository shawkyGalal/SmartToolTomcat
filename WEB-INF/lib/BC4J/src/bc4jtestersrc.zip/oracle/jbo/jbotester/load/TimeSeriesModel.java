package oracle.jbo.jbotester.load;

import com.sun.java.util.collections.ArrayList;

public class TimeSeriesModel
{
   private static int DEFAULT_MAX_SAMPLE_SIZE = 200;
   private static double ERROR_TOLERANCE = 0.05d;

   private static double RESPONSE_TIME_FACTOR = 0.95d;
   
   private int mMaxSampleSize = DEFAULT_MAX_SAMPLE_SIZE;
   private int mSampleSize = 0;
   
   private Object mSyncLock = new Object();
      
   double[] mData = new double[mMaxSampleSize];
   double[] mTimeIntervals = new double[mMaxSampleSize];

   // the number of new data points between translations
   private int mSampleSizeDelta = 0;

   private long mLastUpdateTime = 0;
   private long mFirstUpdateTime = 0;

   // mPos is always pointing at the last update
   private int mPos = -1;

   private double mTotalTime = 0;
   private double mDataMax = 0;
   private double mDataMin = 0;
   private double mDataTotal = 0;
   
   private double mDataPointTotal = 0;

   private double mXScale = 1d;
   private double mYScale = 1d;

   private ArrayList mModelListeners = new ArrayList();

   public TimeSeriesModel()
   {
      init();
   }

   private void init()
   {
/*         mLastUpdateTime = System.currentTimeMillis();
      for (int i=0; i < MAX_LENGTH; i++)
      {
         // uneven intervals
         mLastUpdateTime = mLastUpdateTime - (1000 * (i % 5));
         addResponseTime(1000 * (i % 5));
      }
*/         
   }

   public void addModelListener(TimeSeriesModelListener listener)
   {
      mModelListeners.add(listener);
   }

   public void removeModelListener(TimeSeriesModelListener listener)
   {
      mModelListeners.remove(listener);
   }
   
   /**
    *  Reset the model.  This will clear all data points and reset the maximum
    *  sample size to the default sample size.
    */
   public void reset()
   {
      mMaxSampleSize = DEFAULT_MAX_SAMPLE_SIZE;
      mSampleSize = 0;
      
      mData = new double[mMaxSampleSize];
      mTimeIntervals = new double[mMaxSampleSize];
   
      mSampleSizeDelta = 0;
   
      mFirstUpdateTime = 0;
      mLastUpdateTime = 0;
   
      // mPos is always pointing at the last update
      mPos = -1;
   
      mTotalTime = 0;
      mDataTotal = 0;
      mDataMin = 0;
      mDataMax = 0;
   
      mXScale = 1d;
      mYScale = 1d;
      
      fireModelChanged();
   }

   private void fireModelChanged()
   {
      for (int i=0; i < mModelListeners.size(); i++)
      {
        ((TimeSeriesModelListener)mModelListeners.get(i)).modelChanged();
      }
   }

   public void addDataPoint(double dataPoint)
   {
      synchronized(mSyncLock)
      {
         if (mSampleSizeDelta < mMaxSampleSize - 1)
         {
            mSampleSizeDelta++;
         }
         
         long updateTime = System.currentTimeMillis();

         // the first time interval is always zero.  This is okay
         // since this will always translate to the origin of the series line
         // (width - timeInterval).
         long timeInterval = 0;
         if (mLastUpdateTime > 0)
         {
            timeInterval = updateTime - mLastUpdateTime;
         }
         mLastUpdateTime = updateTime;
         
         if (mFirstUpdateTime == 0)
         {
            mFirstUpdateTime = mLastUpdateTime;
         }

         // increment the position marker.
         mPos++;
         if (mPos == mMaxSampleSize)
         {
            mPos = 0;
            mDataMin = dataPoint;
         }

         // increment the number of points counter until it reaches max.
         if (mSampleSize < mMaxSampleSize)
         {
            mSampleSize++;
         }

         // update the total time.  this must be in scaled units since it will
         // be used to determine the x scale factor for the scaled time
         // intervals.
         mTotalTime = mTotalTime - (mTimeIntervals[mPos] / mXScale);
         mDataTotal = mDataTotal - (mData[mPos] / mYScale);

         double scaledTimeInterval = (double)timeInterval * mXScale;
         mTotalTime += timeInterval;

         // update the max response time.  required to determine y scale factor
         double scaledDataPoint = (double)dataPoint * mYScale;
         mDataMax = Math.max(mDataMax, dataPoint);
         mDataMin = Math.min(mDataMin, dataPoint);
         
         mDataTotal += dataPoint;

         // store a scaled response time
         mData[mPos] = scaledDataPoint;
            
         // store a scaled time interval
         mTimeIntervals[mPos] = scaledTimeInterval;
      }
      
      fireModelChanged();
   }

   public double getDataMax()
   {
      synchronized(mSyncLock)
      {
         return mDataMax;
      }
   }

   public double getDataMin()
   {
      synchronized(mSyncLock)
      {
         return mDataMin;
      }
   }
   
   public double getDataAvg()
   {
      synchronized(mSyncLock)
      {
         return mDataTotal / mSampleSize;
      }
      
   }

   public int getMaxSampleSize()
   {
      synchronized(mSyncLock)
      {
         return mMaxSampleSize;
      }
   }

   public int getSampleSize()
   {
      synchronized(mSyncLock)
      {
         return mSampleSize;
      }
   }

   public long getTotalTime()
   {
      synchronized(mSyncLock)
      {
         return (long)mTotalTime;
      }
   }
   
   public long getLastUpdateTime()
   {
      synchronized(mSyncLock)
      {
         return mLastUpdateTime;
      }
   }

   public long getFirstUpdateTime()
   {
      synchronized(mSyncLock)
      {
         return mFirstUpdateTime;
      }
   }

   private void rescale(double[] statistics, double oldScale, double newScale)
   {
      synchronized(mSyncLock)
      {
         // if mPos == -1 then we have nothing to rescale
         if (mPos == -1) return;

         int pos = mPos;
         
         for (int i=mMaxSampleSize - 1; i > 0; --i)
         {
            statistics[pos] = ((statistics[pos] / oldScale) * newScale);

            --pos;

            if (pos < 0)
            {
               pos = mMaxSampleSize - 1;
            }
         }
      }
   }

   int getSampleSizeDelta()
   {
      synchronized(mSyncLock)
      {
         return mSampleSizeDelta;
      }
   }

   Object getSyncLock()
   {
      return mSyncLock;
   }

   int translate(int[] xCoordinates, int[] yCoordinates, double width, double height)
   {
      synchronized(mSyncLock)
      {
         mSampleSizeDelta = 0;
         
         // if mPos == -1 then there is nothing to translate
         if (mPos == -1) return 0;

         int pos = mPos;

         // how long should a second be?  Determine the new scale factor
         // by dividing the width by the current total time.  if total time
         // is less than zero then reverse engineer the scale factor from
         // the old scale factor.
         double xScale = 0;
         if (mTotalTime > 0)
         {
            // the proper scale is the width divided by the unscaled total.
            double totalTime = (mTotalTime / mSampleSize) * mMaxSampleSize;
            xScale = width / totalTime;

            // if the scale factor is off by TOLERANCE then rescale
            double error = Math.abs((mXScale - xScale) / mXScale);
            if (error > ERROR_TOLERANCE)
            {
               rescale(mTimeIntervals, mXScale, xScale);
               mXScale = xScale;
            }
         }

         // how long should a second be?  Determine the new scale factor
         // by dividing the width by the current total time.  if total time
         // is less than zero then reverse engineer the scale factor from
         // the old scale factor.
         double yScale = 0;
         if (mDataMax > 0)
         {
            yScale = height / mDataMax;
            double error = Math.abs((mYScale - yScale) / mYScale);
            if (error > ERROR_TOLERANCE)
            {
               rescale(mData, mYScale, yScale);
               mYScale = yScale;
            }
         }
         
         // okay lets translate the points to the coordinate system.  the
         // points are already scaled so this is mostly an exercise of
         // decrementing the x position from the width (origin) to 0 using
         // the scaled time intervals starting from mPos and moving backwards.
         int sampleSize = 0;
         double xPos = width;
         
         for (int i=mMaxSampleSize - 1; i > 0; --i)
         {
            // if the numOfPoints translated equals mNumOfPoints then we are
            // done.
            if (sampleSize == mSampleSize) break;

            xCoordinates[i] = (int)xPos;
            yCoordinates[i] = (int)(height - (mData[pos] * RESPONSE_TIME_FACTOR));

            //xPos = xPos - Math.ceil(mTimeIntervals[pos]);
            xPos = xPos - Math.round(mTimeIntervals[pos]);

            sampleSize++;

            // if the xposition is greater than zero then we are done.
            // the scale must be off a little, but within tolerance.
            if (xPos <= 0)
            {
               break;
            }
            
            --pos;
            if (pos < 0)
            {
               pos = mMaxSampleSize - 1;
            }
         }
         
         return sampleSize;
      }
   }
}
