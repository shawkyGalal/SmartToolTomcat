package oracle.jbo.jbotester.load;

import oracle.jbo.common.ampool.PoolMgr;
import oracle.jbo.common.ampool.ApplicationPool;

import oracle.jbo.common.JboNameUtil;

import java.io.PrintWriter;

import com.sun.java.util.collections.ArrayList;

import java.util.Timer;
import java.util.TimerTask;
import java.util.Enumeration;

// JRS Won't work in 3tier
import oracle.jbo.server.ConnectionPoolManagerFactory;
import oracle.jbo.server.ConnectionPoolManager;
import oracle.jbo.pool.ResourcePoolManager;

public class Controller implements StateChangeListener
{
   private Timer mTimer;
   
   private static final char NUM_OF_SESSIONS_FLAG   = 'N';
   private static final char NUM_OF_ITERATIONS_FLAG = 'I';
   private static final char THINK_TIME_FLAG        = 'L';
   private static final char DURATION_FLAG          = 'D';
   private static final char TASK_CLASS_NAME_FLAG   = 'T';
   private static final char PRINT_HELP_FLAG        = '?';

   public static final int NUM_OF_SESSIONS_DEF = 5;
   public static final int NUM_OF_ITERATIONS_DEF = 5;
   public static final int THINK_TIME_DEF = 1000; // one second
   public static final int DURATION_DEF = 60*1000;  // one minute
   public static final String TASK_CLASS_NAME_DEF = "oracle.jbo.jbotester.load.DefaultTask";

   public static final int STATE_NEW = 0;
   public static final int STATE_INITIALIZED = 1;
   public static final int STATE_RAMPING_UP = 2;
   public static final int STATE_RUNNING = 3;
   public static final int STATE_RAMPING_DOWN = 4;
   public static final int STATE_COMPLETED = 5;
   public static final int STATE_CANCELLED = 6;

   private static final String[] STATE_DESCRIPTIONS = new String[]
   {
      "STATE_NEW"
      , "STATE_INITIALIZED"
      , "STATE_RAMPING_UP"
      , "STATE_RUNNING"
      , "STATE_RAMPING_DOWN"
      , "STATE_COMPLETED"
      , "STATE_CANCELLED"
   };

   private final String mApplicationPoolName;
   private final String mApplicationModuleDefName;
   private final String mConfigurationName;

   private final boolean mDebug = false;
   private final Object mLock = new Object();

   // mutable state   
   private Logger mLogger = null;

   private long mStartTime = -1;

   private ArrayList mControllerStateListeners = new ArrayList(0);

   private int mState = STATE_NEW;

   private int mNumOfSessions   = NUM_OF_SESSIONS_DEF;
   private int mNumOfIterations = NUM_OF_ITERATIONS_DEF;
   private int mThinkTime       = THINK_TIME_DEF; // one second
   private int mDuration        = DURATION_DEF; // one minute
   private String mTaskClassName   = TASK_CLASS_NAME_DEF;

   private int mNumOfInitializedSessions = 0;


   Controller(String applicationModuleDefName, String configurationName)
   {
      mApplicationModuleDefName = applicationModuleDefName;
      mConfigurationName = configurationName;

      String packageName = JboNameUtil.getContainerPartOfName(mApplicationModuleDefName);

      // configPackage name
      mApplicationPoolName = packageName + '.' + mConfigurationName;
      
      transitionState(STATE_INITIALIZED);
   }

   void transitionState(int state)
   {
      int oldState = -1;
      synchronized(mLock)
      {
         oldState = getState();
         switch(state)
         {
            case STATE_INITIALIZED:
            {
               if (oldState != STATE_NEW && oldState != STATE_COMPLETED) return;
               break;
            }
            case STATE_RAMPING_UP:
            {
               if (oldState != STATE_INITIALIZED) return;
               break;
            }
            case STATE_RUNNING:
            {
               if (oldState != STATE_RAMPING_UP) return;
               break;
            }
            case STATE_CANCELLED:
            {
               if (oldState != STATE_RAMPING_UP && oldState != STATE_RUNNING) return;
               break;
            }
            case STATE_RAMPING_DOWN:
            {
               if (oldState != STATE_RUNNING) return;
               break;
            }
            case STATE_COMPLETED:
            {
               if (oldState != STATE_RAMPING_DOWN && oldState != STATE_CANCELLED) return;
               break;
            }
         }

         mState = state;
      }

      if (isDebug())
      {
         StringBuffer sb = new StringBuffer("Transitioned controller from state ");
         sb.append(STATE_DESCRIPTIONS[oldState]);
         sb.append(" to state ");
         sb.append(STATE_DESCRIPTIONS[state]);
         System.out.println(sb.toString());
      }

      fireControllerStateChanged(new StateChangedEvent(this, oldState, state));

      switch(state)
      {
         case STATE_INITIALIZED:
         {
            initialize();
            break;
         }
         case STATE_RAMPING_UP:
         {
            rampUp();
            break;
         }
         case STATE_RUNNING:
         {
            run();
            break;
         }
         case STATE_CANCELLED:
         case STATE_RAMPING_DOWN:
         {
            rampDown();
            break;
         }
      }
   }

   public int getState()
   {
      synchronized(mLock)
      {
         return mState;
      }
   }
   
   private void initialize()
   {
      // only reset the controllers internal state
      if (mTimer != null)
      {
         mTimer.cancel();
         mTimer = null;
      }
      mTimer = new Timer();
   }

   public void setNumOfSessions(int numOfSessions)
   {
      mNumOfSessions = numOfSessions;
   }

   public int getNumOfSessions()
   {
      return mNumOfSessions;
   }

   public void setNumOfIterations(int numOfIterations)
   {
      mNumOfIterations = numOfIterations;
   }

   public int getNumOfIterations()
   {
      return mNumOfIterations;
   }

   public void setThinkTime(int thinkTime)
   {
      mThinkTime = thinkTime;
   }

   public int getThinkTime()
   {
      return mThinkTime;
   }

   public void setDuration(int duration)
   {
      mDuration = duration;
   }

   public int getDuration()
   {
      return mDuration;
   }

   public String getTaskClassName()
   {
      return mTaskClassName;
   }

   public void setTaskClassName(String taskClassName)
   {
      mTaskClassName = taskClassName;
   }

   int schedule(TimerTask timerTask, long interval)
   {
      int rtn = 0;
      synchronized(mLock)
      {
         int state = getState();
         if (state == STATE_RAMPING_UP
            || state == STATE_RUNNING)
         {
            mTimer.schedule(timerTask, interval);
         }
         else
         {
            rtn = 1;
         }
      }

      return rtn;
   }

   public void start()
   {
      if (getState() == STATE_COMPLETED)
      {
         transitionState(STATE_INITIALIZED);
      }
      transitionState(STATE_RAMPING_UP);
   }

   private void run()
   {
      int durationCounter = 0;
      while ((durationCounter < mDuration) && (getState() == STATE_RUNNING))
      {
         try
         {
            Thread.currentThread().sleep(1000);
         }
         catch (java.lang.InterruptedException ie)
         {
         }
         
         durationCounter += 1000;
      }

      transitionState(STATE_RAMPING_DOWN);
   }

   void stop()
   {
      transitionState(STATE_CANCELLED);
   }

   public void resetParameters()
   {
      mNumOfSessions   = NUM_OF_SESSIONS_DEF;
      mNumOfIterations = NUM_OF_ITERATIONS_DEF;
      mThinkTime       = THINK_TIME_DEF; // one second
      mDuration        = DURATION_DEF; // one minute
      mTaskClassName   = TASK_CLASS_NAME_DEF;
   }
   
   public void reset()
   {
      if (getState() != STATE_COMPLETED || getState() != STATE_INITIALIZED) return;

      mLogger = null;
      if (mApplicationPoolName != null &&
         PoolMgr.getInstance().isPoolCreated(mApplicationPoolName))
      {
         PoolMgr.getInstance().removeResourcePool(mApplicationPoolName);
      }

      if (ConnectionPoolManagerFactory.isInitialized())
      {
         ConnectionPoolManager connPoolMgr =
            ConnectionPoolManagerFactory.getConnectionPoolManager();
         if (connPoolMgr instanceof ResourcePoolManager)
         {
            ResourcePoolManager mgr = (ResourcePoolManager)connPoolMgr;
            Enumeration poolKeys = mgr.getResourcePoolKeys();
            while (poolKeys.hasMoreElements())
            {
               mgr.removeResourcePool(poolKeys.nextElement());
            }
         }
      }

      transitionState(STATE_INITIALIZED);
   }

   public ApplicationPool getApplicationPool(boolean create)
   {
      ApplicationPool pool = null;
      if (create)
      {
         // bootstrap the pool
         pool = PoolMgr.getInstance().findPool(
            mApplicationPoolName
            , JboNameUtil.getContainerPartOfName(mApplicationModuleDefName)
            , mConfigurationName
            , null // pool properties
         );
      }
      else
      {
         pool = (ApplicationPool)PoolMgr.getInstance().getResourcePool(mApplicationPoolName);
      }

      return pool;
   }

   private void rampUp()
   {
      mStartTime = System.currentTimeMillis();
      mLogger = new Logger();

      getApplicationPool(true);
     
      TaskThreadPool taskThreadPool = (TaskThreadPool)TaskThreadPoolManager
         .getInstance()
         .getResourcePool(TaskThreadPoolManager.SINGLETON_POOL_NAME);

      taskThreadPool.open();

      Session session = null;
      for (int i=0; i < mNumOfSessions; i++)
      {
         // Another thread cancelled the test during rampup.
         synchronized(mLock)
         {
            if (getState() != STATE_RAMPING_UP) return;
            session = new Session(this, new Integer(i).toString(), new Integer(i).toString());
         }

         // stagger the initialization.  Try 2s per session.  Note that the logger
         // is not registered until after initialization has completed.
         try
         {
            Thread.currentThread().sleep(1000);
         }
         catch (java.lang.InterruptedException e)
         {
         }
      }

      transitionState(STATE_RUNNING);
   }

   private void rampDown()
   {
      while (mNumOfInitializedSessions > 0)
      {
         try
         {
            Thread.currentThread().sleep(100);
         }
         catch (java.lang.InterruptedException ie)
         {
         }
      }

      mTimer.cancel();

      TaskThreadPool taskThreadPool = (TaskThreadPool)TaskThreadPoolManager
         .getInstance()
         .getResourcePool(TaskThreadPoolManager.SINGLETON_POOL_NAME);

      taskThreadPool.close();

      if (isDebug())
      {
         System.out.println("Dumping thread pool statistics...");
         taskThreadPool.dumpPoolStatistics(new PrintWriter(System.out, true));
      }

      mLogger.dumpStatistics(new PrintWriter(System.out, true));

      transitionState(STATE_COMPLETED);
   }
   
   void addControllerStateListener(StateChangeListener controllerStateListener)
   {
      synchronized(mControllerStateListeners)
      {
         mControllerStateListeners.add(controllerStateListener);
      }
   }

   void removeControllerStateListener(StateChangeListener controllerStateListener)
   {
      synchronized(mControllerStateListeners)
      {
         mControllerStateListeners.remove(controllerStateListener);
      }
   }

   void fireControllerStateChanged(StateChangedEvent event)
   {
      ArrayList controllerStateListeners = null;
      synchronized(mControllerStateListeners)
      {
         controllerStateListeners = (ArrayList)mControllerStateListeners.clone();
      }

      for (int i=0; i < controllerStateListeners.size(); i++)
      {
         ((StateChangeListener)controllerStateListeners.get(i)).stateChanged(event);
      }
   }

   public void stateChanged(StateChangedEvent ev)
   {
      // session state change event
      switch(ev.getNewState())
      {
         case Session.STATE_DESTROYED:
         {
            // don't set the session state to closed here.  it will
            // result in a circular call!
            synchronized(mLock)
            {
               --mNumOfInitializedSessions;
            }

            synchronized(mLock)
            {
               int state = getState();
               if (state != STATE_RAMPING_DOWN && state != STATE_CANCELLED)
               {
                  Session session = new Session(
                     this
                     , ((Session)ev.getSource()).getApplicationId()
                     , ((Session)ev.getSource()).getSessionId());
               }
               break;
            }
         }
         case Session.STATE_INITIALIZED:
         {
            synchronized(mLock)
            {
               mNumOfInitializedSessions++;
            }
            break;
         }
      }

      // delegate to the logger
      if (getState() == STATE_RUNNING)
      {
         mLogger.stateChanged(ev);
      }
   }

   long getElapsedRunningTime()
   {
      long elapsedTime = 0;
      
      if (mState == STATE_RAMPING_UP
         || mState == STATE_RUNNING
         || mState == STATE_RAMPING_DOWN
         || mState == STATE_CANCELLED)
      {
         elapsedTime = System.currentTimeMillis() - mStartTime;
      }

      return elapsedTime;
   }

   Logger getLogger()
   {
      return mLogger;
   }

   public Timer getTimer()
   {
      return mTimer;
   }

   boolean isDebug()
   {
      return mDebug;
   }
   
   public static void main(String[] args)
   {
      if (args.length < 2)
      {
         printUsage();
         System.exit(0);
      }
      
      Controller lc = new Controller(args[args.length - 2], args[args.length -1]);
      
      for (int i=0; i < (args.length - 2); i++)
      {
         if (!(args[i].startsWith("-") || args[i].startsWith("/"))
            || args[i].length() != 2)
         {
            printUsage();
            System.exit(0);
         }

         char flag = Character.toUpperCase(args[i].charAt(1));
         i++;

         switch(flag)
         {
            case NUM_OF_SESSIONS_FLAG:
            {
               lc.setNumOfSessions(Integer.parseInt(args[i]));
               break;
            }
            case NUM_OF_ITERATIONS_FLAG:
            {
               lc.setNumOfIterations(Integer.parseInt(args[i]));
               break;
            }
            case THINK_TIME_FLAG:
            {
               lc.setThinkTime(Integer.parseInt(args[i]));
               break;
            }
            case DURATION_FLAG:
            {
               lc.setDuration(Integer.parseInt(args[i]));
               break;
            }
            case TASK_CLASS_NAME_FLAG:
            {
               lc.setTaskClassName(args[i]);
               break;
            }
            case PRINT_HELP_FLAG:
            default:
            {
               printUsage();
               System.exit(0);
            }
         }
      }

      lc.start();
   }

   public static void printUsage()
   {
      System.out.println("Usage:");
      System.out.println("java oracle.jbo.jbotester.load.LoadController [parameters] <ApplicationDefName> <ConfigName>");
      System.out.println("[parameters]:");
      System.out.println("[-N <num of sessions>] -- The number of concurrent sessions");
      System.out.println("[-I <num of iterations>] -- The number of iterations for each session");
      System.out.println("[-L <think time (ms)>] -- The think time between iterations");
      System.out.println("[-D <test duration (ms)>] -- The duration of the simulation");
      System.out.println("[-T <task class name>] -- The name of the Task class that should be execute for each iteration");
      
   }
}
