package oracle.jbo.jbotester.load;

import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JComponent;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;

import java.awt.Component;
import java.awt.Font;

import oracle.bali.ewt.spinBox.NumericSpinBox;
import oracle.bali.ewt.spinBox.SpinBuddy;

public class UIHelper
{
   public static final void buildPoolHeaderRow(
      JPanel panel
      , GridBagConstraints constraints
      , GridBagLayout layout
      , JLabel label)
   {
      constraints.gridx = 0;
      constraints.anchor = GridBagConstraints.NORTHWEST;
      constraints.fill = GridBagConstraints.NONE;
      constraints.gridwidth = 3;
      constraints.weightx = 0.0;
      constraints.weighty = 0.0;
      constraints.insets = new Insets(2, 0, 2, 0);

      label.setFont(label.getFont().deriveFont(Font.BOLD));
      layout.setConstraints(label, constraints);
      panel.add(label);

      constraints.gridy++;
   }
   
   public static final void buildPoolRow(
      JPanel panel
      , GridBagConstraints constraints
      , GridBagLayout layout
      , JLabel label
      , JComponent comp)
   {
      buildRow(panel, constraints, layout, label, comp);
   }

   public static final void buildRow(
      JPanel panel
      , GridBagConstraints constraints
      , GridBagLayout layout
      , JLabel label
      , JComponent comp)
   {
      panel.setAlignmentY(Component.TOP_ALIGNMENT);

      constraints.anchor = GridBagConstraints.NORTHWEST;
      constraints.gridx = 0;
      constraints.fill = GridBagConstraints.HORIZONTAL;
      constraints.weightx = 0.0;
      constraints.weighty = 0.0;
      constraints.insets = new Insets(2, 0, 2, 0);

//      label.setFont(new Font("SansSerif", Font.PLAIN, 12));
      layout.setConstraints(label, constraints);
      panel.add(label);

      constraints.anchor = GridBagConstraints.NORTHEAST;
      constraints.gridx++;
      constraints.fill = GridBagConstraints.HORIZONTAL;
      constraints.weightx = 1.0;
      constraints.weighty = 0.0;
      constraints.insets = new Insets(2, 5, 2, 0);

      if (comp instanceof NumericSpinBox)
      {
         NumericSpinBox spin = (NumericSpinBox)comp;
         SpinBuddy buddy = spin.getSpinBuddy();
         if (buddy instanceof JTextField)
         {
            ((JTextField)buddy).setHorizontalAlignment(SwingConstants.RIGHT);
         }
//         constraints.insets = new Insets(2, 250, 0, 0);
      }
      else if (comp instanceof JLabel)
      {
         JLabel compLabel = (JLabel)comp;
         compLabel.setHorizontalAlignment(JLabel.RIGHT);
      }

      layout.setConstraints(comp, constraints);
      panel.add(comp);

      constraints.gridy++;
   }

   public static final void buildSpinBoxRow(
      JPanel panel
      , GridBagConstraints constraints
      , GridBagLayout layout
      , JLabel label
      , NumericSpinBox spin)
   {
      panel.setAlignmentY(Component.TOP_ALIGNMENT);

      constraints.anchor = GridBagConstraints.NORTHWEST;
      constraints.gridx = 0;
      constraints.fill = GridBagConstraints.HORIZONTAL;
      constraints.weightx = 0.0;
      constraints.weighty = 0.0;
      constraints.insets = new Insets(5, 0, 2, 0);

//      label.setFont(new Font("SansSerif", Font.PLAIN, 12));
      layout.setConstraints(label, constraints);
      panel.add(label);

      constraints.anchor = GridBagConstraints.NORTHEAST;
      constraints.gridx++;
      constraints.fill = GridBagConstraints.HORIZONTAL;
      constraints.weightx = 1.0;
      constraints.weighty = 0.0;
      constraints.insets = new Insets(5, 5, 2, 0);

      JLabel dummyLabel = new JLabel();
      layout.setConstraints(dummyLabel, constraints);
      panel.add(dummyLabel);
      
      constraints.anchor = GridBagConstraints.NORTHEAST;
      constraints.gridx++;
      constraints.fill = GridBagConstraints.HORIZONTAL;
      constraints.weightx = 0.0;
      constraints.weighty = 0.0;
      constraints.insets = new Insets(5, 5, 2, 0);

      SpinBuddy buddy = spin.getSpinBuddy();
      if (buddy instanceof JTextField)
      {
         ((JTextField)buddy).setHorizontalAlignment(SwingConstants.RIGHT);
      }

      layout.setConstraints(spin, constraints);
      panel.add(spin);

      constraints.gridy++;
   }

}
