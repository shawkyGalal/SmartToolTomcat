package oracle.jbo.jbotester;

import oracle.jbo.common.ampool.EnvInfoProvider;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Insets;

import java.util.Hashtable;
import java.util.Properties;

import oracle.jbo.common.PropertyMetadata;

import oracle.jbo.JboContext;

import oracle.jbo.client.Configuration;

import javax.swing.BorderFactory;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.UIManager;

import oracle.jbo.ConnectionModeConstants;

import oracle.jbo.common.ampool.DefaultConnectionStrategy;
import oracle.jbo.common.PropertyConstants;

class TesterEnvInfoProvider implements EnvInfoProvider
{
   private Component mParent = null;
   private String mUserName = null;
   private String mPassword = null;
   private String mConnectString = null;
   private String mPrincipal = null;
   private String mCredentials = null;
      
   public TesterEnvInfoProvider(Component parent)
   {
      mParent = parent;
   }

   public void modifyInitialContext(Object initialContext)
   {
   }

   public int getNumOfRetries()
   {
      return 0;
   }
      
   public Object getInfo(String info, Object env)
   {
      Hashtable envHT = (Hashtable)env;
      String platform      = (String)envHT.get(PropertyMetadata.DEPLOY_PLATFORM.getName());

      boolean isJ2EE = !(JboContext.PLATFORM_VB.equals(platform) 
         || JboContext.PLATFORM_LOCAL.equals(platform));

      mConnectString = (String)envHT.get(Configuration.DB_CONNECTION_PROPERTY);
      
      if (!isJ2EE)
      {
         if (mUserName == null)
         {
            mUserName = (String)envHT.get(Configuration.DB_USERNAME_PROPERTY);
         }
         
         if (mPassword == null)
         {
            mPassword = (String)envHT.get(Configuration.DB_PASSWORD_PROPERTY);
         }
      }
      else  // IAS OR WLS
      {
         if (mUserName == null)
         {
            mUserName = (String) envHT.get(PropertyMetadata.SECURITY_PRINCIPAL.getName());
         }

         if (mPassword == null)
         {
            mPassword = (String) envHT.get(PropertyMetadata.SECURITY_CREDENTIALS.getName());
         }
      }

      boolean correctPassword = (mPassword != null && mPassword.length() > 0);

      if (!correctPassword)
      {
         requestConnParams(mParent);
      }
         
      envHT.put(Configuration.DB_USERNAME_PROPERTY, mUserName);
      envHT.put(Configuration.DB_PASSWORD_PROPERTY, mPassword);      

      if (isJ2EE)
      {
         // Overwrite the environment property with the new possible new values
         // of username and password.
         envHT.put(PropertyMetadata.SECURITY_PRINCIPAL.getName(), mUserName);
         envHT.put(PropertyMetadata.SECURITY_CREDENTIALS.getName(), mPassword);
      }
      else if (JboContext.PLATFORM_VB.equals(platform))
      {
         if (ConnectionInfo.getConnectionMode(envHT) == ConnectionModeConstants.REMOTE)
         {
            if (!MainWindow.isStandaloneApp())
            {
               envHT.put(JboContext.USE_APPLET, MainWindow.getApplet());

               Properties orbProperties = new Properties();
               orbProperties.put(
                  ConnectionInfo.ORB_GATEKEEPER_IOR
                  , envHT.get(ConnectionInfo.ORB_GATEKEEPER_IOR));

               orbProperties.put("ORBalwaysProxy", "true");
               MainWindow.setORBProperties(orbProperties);
            }
         }
      }

      String securityEnforceStr = (String)((Hashtable) envHT).get(PropertyMetadata.ENV_SECURITY_ENFORCE.getName());
      if (securityEnforceStr != null &&
          ( PropertyConstants.SECURITY_ENFORCE_TEST.equals(securityEnforceStr) ||
            PropertyConstants.SECURITY_ENFORCE_MUST.equals(securityEnforceStr) ))
      {
         if (mPrincipal == null)
         {
            mPrincipal = (String) ((Hashtable) envHT).get(JboContext.SECURITY_PRINCIPAL);
         }
         if (mCredentials == null)
         {
            mCredentials = (String) ((Hashtable) envHT).get(JboContext.SECURITY_CREDENTIALS);
         }

         boolean isPrincipalEmpty = ((mPrincipal == null) || (mPrincipal.length() <= 0));
         boolean isCredentialEmpty = ((mCredentials == null) || (mCredentials.length() <= 0));

         RuntimeException exc = ((RuntimeException)((Hashtable) envHT).get(DefaultConnectionStrategy.LAST_EXCEPTION));
         if (isPrincipalEmpty || isCredentialEmpty || exc != null)
         {
            requestSecurityParams(mParent);
         }
         envHT.put(JboContext.SECURITY_PRINCIPAL, mPrincipal);
         envHT.put(JboContext.SECURITY_CREDENTIALS, mCredentials);      
      }

      ConnectionInfo.setEnv(envHT);
      return envHT;
   }

   private String requestConnParams(Component parent)
   {
      JPasswordField passwdField = new JPasswordField(10);
      JTextField userField = new JTextField(mUserName, 10);
      JPanel mainPanel = new JPanel(new BorderLayout());
      JPanel top = new JPanel(new GridLayout(2, 0));
      JLabel l;

      GridBagLayout gbl       = new GridBagLayout();
      JPanel panel            = new JPanel(gbl);
      GridBagConstraints gbc  = new GridBagConstraints();

      gbc.fill = GridBagConstraints.HORIZONTAL;

      gbc.gridx = 0;
      gbc.gridy = 0;
      gbc.anchor = GridBagConstraints.WEST;
      gbc.weightx = 0.0;
      gbc.gridwidth = 1;
      gbc.insets = new Insets(8, 0, 8, 8);
      l = new JLabel(Res.getString(Res.PASSWORD_DIALOG_USERNAME));
      gbl.setConstraints(l, gbc);
      panel.add(l);

      gbc.gridx = GridBagConstraints.RELATIVE;
      gbc.gridy = 0;
      gbc.anchor = GridBagConstraints.EAST;
      gbc.weightx = 1.0;
      gbc.gridwidth = GridBagConstraints.REMAINDER;
      gbc.insets = new Insets(8, 0, 8, 0);
      gbl.setConstraints(userField, gbc);
      panel.add(userField);

      gbc.anchor = GridBagConstraints.WEST;
      gbc.gridx = 0;
      gbc.gridy = GridBagConstraints.RELATIVE;
      gbc.weightx = 0.0;
      gbc.gridwidth = 1;
      gbc.insets = new Insets(0, 0, 8, 8);
      l = new JLabel(Res.getString(Res.PASSWORD_DIALOG_PASSWORD));
      gbl.setConstraints(l, gbc);
      panel.add(l);

      gbc.anchor = GridBagConstraints.EAST;
      gbc.gridx = GridBagConstraints.RELATIVE;
      gbc.gridy = 1;
      gbc.weightx = 1.0;
      gbc.gridwidth = GridBagConstraints.REMAINDER;
      gbc.insets = new Insets(0, 0, 8, 0);
      gbl.setConstraints(passwdField, gbc);
      panel.add(passwdField);

      JboTesterUtil.removeKeyBindingCompatibility(passwdField);

      mainPanel.add(panel, BorderLayout.CENTER);

      String hostname = null;

      if (mConnectString != null)
      {
         int bIndex = mConnectString.indexOf('@');
         if (bIndex == -1)
         {
            bIndex = mConnectString.indexOf("//");
            if (bIndex == -1)
            {
               hostname = mConnectString;
            }
            else
            {
               hostname = mConnectString.substring(bIndex + 2);
            }
         }
         else
         {
            hostname = mConnectString.substring(bIndex + 1);
         }
      }

      top.add(new JLabel(Res.getString(Res.PASSWORD_DIALOG_QUESTION)));
      top.add(new JLabel(hostname));
      mainPanel.add(top, BorderLayout.NORTH);

      mainPanel.setBorder(BorderFactory.createEmptyBorder(8, 8, 0, 8));

      GenericDialog dialog = new GenericDialog(JOptionPane.getFrameForComponent(parent),
                                               Res.getString(Res.PASSWORD_DIALOG_TITLE),
                                               mainPanel,
                                               GenericDialog.OK_CANCEL_OPTION);

      dialog.setHelpLocation("f1_bcbctbrowser_html");
      
      JLabel iconLabel = new JLabel(UIManager.getIcon("OptionPane.questionIcon"));
      iconLabel.setVerticalAlignment(SwingConstants.TOP);
      iconLabel.setBorder(BorderFactory.createEmptyBorder(8, 8, 8, 8));

      dialog.getContentPane().add(iconLabel, BorderLayout.WEST);

      dialog.setInitialFocusComponent(passwdField);
      dialog.show();

      if (dialog.getExitCommand() != GenericDialog.OK_ACTION)
      {
         return null;
      }

      mUserName = userField.getText();
      mPassword = new String(passwdField.getPassword());

      return mPassword;
   }

   private String requestSecurityParams(Component parent)
   {
      JPasswordField passwdField = new JPasswordField(10);
      JTextField userField = new JTextField(mPrincipal, 10);
      JPanel mainPanel = new JPanel(new BorderLayout());
      JPanel top = new JPanel(new GridLayout(2, 0));
      JLabel l;

      GridBagLayout gbl       = new GridBagLayout();
      JPanel panel            = new JPanel(gbl);
      GridBagConstraints gbc  = new GridBagConstraints();

      gbc.fill = GridBagConstraints.HORIZONTAL;

      gbc.gridx = 0;
      gbc.gridy = 0;
      gbc.anchor = GridBagConstraints.WEST;
      gbc.weightx = 0.0;
      gbc.gridwidth = 1;
      gbc.insets = new Insets(8, 0, 8, 8);
      l = new JLabel(Res.getString(Res.SECURITY_DIALOG_PRINCIPAL));
      gbl.setConstraints(l, gbc);
      panel.add(l);

      gbc.gridx = GridBagConstraints.RELATIVE;
      gbc.gridy = 0;
      gbc.anchor = GridBagConstraints.EAST;
      gbc.weightx = 1.0;
      gbc.gridwidth = GridBagConstraints.REMAINDER;
      gbc.insets = new Insets(8, 0, 8, 0);
      gbl.setConstraints(userField, gbc);
      panel.add(userField);

      gbc.anchor = GridBagConstraints.WEST;
      gbc.gridx = 0;
      gbc.gridy = GridBagConstraints.RELATIVE;
      gbc.weightx = 0.0;
      gbc.gridwidth = 1;
      gbc.insets = new Insets(0, 0, 8, 8);
      l = new JLabel(Res.getString(Res.SECURITY_DIALOG_CREDENTIALS));
      gbl.setConstraints(l, gbc);
      panel.add(l);

      gbc.anchor = GridBagConstraints.EAST;
      gbc.gridx = GridBagConstraints.RELATIVE;
      gbc.gridy = 1;
      gbc.weightx = 1.0;
      gbc.gridwidth = GridBagConstraints.REMAINDER;
      gbc.insets = new Insets(0, 0, 8, 0);
      gbl.setConstraints(passwdField, gbc);
      panel.add(passwdField);

      JboTesterUtil.removeKeyBindingCompatibility(passwdField);

      mainPanel.add(panel, BorderLayout.CENTER);
      mainPanel.add(top, BorderLayout.NORTH);

      mainPanel.setBorder(BorderFactory.createEmptyBorder(8, 8, 0, 8));

      GenericDialog dialog = new GenericDialog(JOptionPane.getFrameForComponent(parent),
                                               Res.getString(Res.SECURITY_DIALOG_TITLE),
                                               mainPanel,
                                               GenericDialog.OK_CANCEL_OPTION);

      dialog.setHelpLocation("f1_bcbctbrowser_html");
      

      dialog.setInitialFocusComponent(passwdField);
      dialog.show();

      if (dialog.getExitCommand() != GenericDialog.OK_ACTION)
      {
         return null;
      }

      mPrincipal = userField.getText();
      mCredentials = new String(passwdField.getPassword());

      return mPassword;
   }
}   


