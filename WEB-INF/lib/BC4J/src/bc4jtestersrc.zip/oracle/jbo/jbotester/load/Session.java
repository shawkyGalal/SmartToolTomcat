package oracle.jbo.jbotester.load;

import oracle.jbo.common.ampool.ApplicationPool;
import oracle.jbo.common.ampool.SessionCookie;

import java.util.TimerTask;

import com.sun.java.util.collections.ArrayList;

public class Session
{
   private SessionCookie mSessionCookie;
   private Task mTask;
   private boolean mSleeping = false;
   private int mIterationCounter;

   private final String mApplicationId;
   private final String mSessionId;

   private final Controller mController;

   private final ArrayList mSessionStateListeners = new ArrayList();

   private Object mLock = new Object();

   public static final int STATE_NEW = 0;
   public static final int STATE_INITIALIZED = 1;
   public static final int STATE_SCHEDULED = 2;
   public static final int STATE_RUNNING = 3;
   public static final int STATE_CLOSED = 4;
   public static final int STATE_DESTROYED = 5;

   private static final String[] STATE_DESCRIPTIONS = new String[]
   {
      "STATE_NEW"
      , "STATE INITIALIZED"
      , "STATE_SCHEDULED"
      , "STATE_RUNNING"
      , "STATE_CLOSED"
      , "STATE_DESTROYED"
   };

   private int mState = STATE_NEW;
   
   Session(Controller controller, String applicationId, String sessionId)
   {
      mController = controller;

      // always add the controller as a session state listener
      addSessionStateListener(mController);
      
      mApplicationId = applicationId;
      mSessionId = sessionId;

      // pool should have been created already
      ApplicationPool pool = mController.getApplicationPool(false);

      mSessionCookie = pool.createSessionCookie(applicationId, sessionId, null);

      mIterationCounter = mController.getNumOfIterations();

      transitionState(STATE_INITIALIZED);
      transitionState(STATE_SCHEDULED);
   }

   public String getApplicationId()
   {
      return mApplicationId;  
   }

   public String getSessionId()
   {
      return mSessionId;
   }

   SessionCookie getSessionCookie()
   {
      return mSessionCookie;
   }

   void addSessionStateListener(StateChangeListener sessionStateListener)
   {
      mSessionStateListeners.add(sessionStateListener);
   }

   void removeSessionStateListener(StateChangeListener sessionStateListener)
   {
      mSessionStateListeners.remove(sessionStateListener);
   }

   void fireSessionStateChanged(StateChangedEvent ev)
   {
      for (int i=0; i < mSessionStateListeners.size(); i++)
      {
         ((StateChangeListener)mSessionStateListeners.get(i)).stateChanged(ev);
      }
   }

   private int getState()
   {
      return mState;
   }

   void transitionState(int state)
   {
      transitionState(state, -1);
   }

   void transitionState(int state, long responseTime)
   {
      int oldState = -1;
      synchronized(mLock)
      {
         oldState = getState();
         switch(state)
         {
            case STATE_INITIALIZED:
            {
               if (oldState != STATE_NEW) return;
               break;
            }
            case STATE_SCHEDULED:
            {
               if (oldState == STATE_CLOSED || oldState == STATE_DESTROYED) return;
               break;
            }
            case STATE_RUNNING:
            {
               if (oldState != STATE_SCHEDULED) return;
               break;
            }
            case STATE_CLOSED:
            {
               if (oldState == STATE_DESTROYED) return;
               break;
            }
            case STATE_DESTROYED:
            {
               if (oldState != STATE_CLOSED) return;
            }
         }

         mState = state;
      }

      if (mController.isDebug())
      {
         StringBuffer sb = new StringBuffer("Transitioned session ");
         sb.append(getSessionId());
         sb.append(" from state ");
         sb.append(STATE_DESCRIPTIONS[oldState]);
         sb.append(" to state ");
         sb.append(STATE_DESCRIPTIONS[state]);
         System.out.println(sb.toString());
      }

      StateChangedEvent ev = new StateChangedEvent(this, oldState, state);
      ev.setStateChangeInterval(responseTime);
      fireSessionStateChanged(ev);

      switch(state)
      {
         case STATE_SCHEDULED:
         {
            schedule(oldState == STATE_INITIALIZED ? 0 : mController.getThinkTime());
            break;
         }
         case STATE_RUNNING:
         {
            runTask();
            break;
         }
         case STATE_CLOSED:
         {
            destroy();
            break;
         }
         case STATE_DESTROYED:
         {
            mSessionStateListeners.clear();      
         }
      }
   }

   private void schedule(long timeToStart)
   {
      int rtn = mController.schedule(
         new TimerTask()
         {
            public void run()
            {
               transitionState(STATE_RUNNING);
            }
         }
         , timeToStart);

      // the controller could not schedule us.  The test must be over.
      // destroy the session.
      if (rtn != 0)
      {
         transitionState(STATE_CLOSED);
      }
   }

   private void runTask()
   {
      if (mIterationCounter != -1 && mIterationCounter - 1 < 0)
      {
         transitionState(STATE_CLOSED);
      }
      else
      {
         if (mIterationCounter != -1)
         {
            --mIterationCounter;
         }
         
         TaskThreadPool pool = (TaskThreadPool)TaskThreadPoolManager
            .getInstance()
            .getResourcePool(TaskThreadPoolManager.SINGLETON_POOL_NAME);

         // use reflection to instantiate the task.  Ask the controller for
         // the task class.   Require a null constructor.
         if (mTask == null)
         {
            try
            {
               String taskClassName = mController.getTaskClassName();
               Class taskClass = Class.forName(taskClassName);
               mTask = (Task)taskClass.newInstance();
            }
            catch (Exception e)
            {
               e.printStackTrace();
               throw new RuntimeException(e.getMessage());
            }
            
            mTask.initialize(this);
         }

         pool.execute(mTask);
      }
   }   

   private void destroy()
   {
      ApplicationPool pool = mController.getApplicationPool(false);

      pool.removeSessionCookie(mSessionCookie);
      mSessionCookie = null;

      transitionState(STATE_DESTROYED);
   }
}
