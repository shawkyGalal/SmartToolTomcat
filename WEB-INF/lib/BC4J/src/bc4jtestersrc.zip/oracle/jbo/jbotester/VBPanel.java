/*
 * @(#)VBPanel.java
 *
 * Copyright 1999-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.jbotester;

import java.awt.Frame;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Hashtable;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JTextField;
import oracle.jbo.ConnectionModeConstants;
import oracle.jbo.common.JboEnvUtil;
import oracle.jbo.common.PropertyMetadata;

public final class VBPanel extends PlatformPanel implements ActionListener
{
   static final int USE_COLOCATED   = 0;
   static final int USE_BIND        = 1;
   static final int USE_REMOTE      = 2;

   // VB Panel Controls  Begin
   private final JComboBox orbConTypeCombo = new JComboBox(new String[]{ Res.getString(Res.VB_PANEL_USE_COLOCATED),
                                                                         Res.getString(Res.VB_PANEL_USE_BIND),
                                                                         Res.getString(Res.VB_PANEL_USE_REMOTE)});
   
   private final JTextField hostField      = new JTextField();
   private final JLabel hostLabel          = JboTesterUtil.createLabel(Res.VB_PANEL_HOST_NAME_LABEL, hostField);
   private final JTextField nmsRootField   = new JTextField();
   private final JLabel nmsRoot            = JboTesterUtil.createLabel(Res.VB_PANEL_NS_ROOT_LABEL, nmsRootField);

   public VBPanel(Frame parentFrame)
   {
      super(new GridBagLayout());

      parent = parentFrame;

      JLabel orbConTypeLabel = JboTesterUtil.createLabel(Res.VB_PANEL_ORB_TYPE_LABEL, orbConTypeCombo);
      
      orbConTypeCombo.setEditable(false);
      orbConTypeCombo.addActionListener(this);

      orbConTypeCombo_actionPerformed(null);

      // Layout components
      GridBagLayout gbl         = (GridBagLayout) getLayout();
      GridBagConstraints gbc    = new GridBagConstraints();

      gbc.fill = GridBagConstraints.HORIZONTAL;

      gbc.gridx = 0;
      gbc.gridy = 0;
      gbc.gridwidth = 1;
      gbc.weightx = 0.0;
      gbc.weighty = 0.0;
      gbc.insets = new Insets(0, 10, 10, 0);
      gbc.anchor = GridBagConstraints.EAST;
      gbl.setConstraints(orbConTypeLabel, gbc);
      add(orbConTypeLabel);

      gbc.anchor = GridBagConstraints.WEST;
      gbc.gridx = 1;
      gbc.gridy = 0;
      gbc.gridwidth = GridBagConstraints.REMAINDER;
      gbc.weightx = 1.0;
      gbl.setConstraints(orbConTypeCombo, gbc);
      add(orbConTypeCombo);

      gbc.anchor = GridBagConstraints.EAST;
      gbc.gridx = 0;
      gbc.gridy = 1;
      gbc.gridwidth = 1;
      gbc.weightx = 0.0;
      gbl.setConstraints(hostLabel, gbc);
      add(hostLabel);

      gbc.anchor = GridBagConstraints.WEST;
      gbc.gridx = 1;
      gbc.gridy = 1;
      gbc.gridwidth = GridBagConstraints.REMAINDER;
      gbc.weightx = 1.0;
      gbl.setConstraints(hostField, gbc);
      add(hostField);

      gbc.anchor = GridBagConstraints.EAST;
      gbc.gridx = 0;
      gbc.gridy = 2;
      gbc.gridwidth = 1;
      gbc.weightx = 0.0;
      gbl.setConstraints(nmsRoot, gbc);
      add(nmsRoot);

      gbc.anchor = GridBagConstraints.WEST;
      gbc.gridx = 1;
      gbc.gridy = 2;
      gbc.gridwidth = GridBagConstraints.REMAINDER;
      gbc.weightx = 1.0;
      gbl.setConstraints(nmsRootField, gbc);
      add(nmsRootField);
   }

   // ActionListener interface
   public void actionPerformed(ActionEvent e)
   {
      orbConTypeCombo_actionPerformed(e);
   }

   void orbConTypeCombo_actionPerformed(ActionEvent e)
   {
      switch (orbConTypeCombo.getSelectedIndex())
      {
         case USE_BIND:
            hostLabel.setEnabled(true);
            hostLabel.setText(JboTesterUtil.stripMnemonic(Res.VB_PANEL_HOST_NAME_LABEL));
            hostField.setEditable(true);
            hostField.setEnabled(true);
   
            nmsRoot.setEnabled(false);
            nmsRootField.setEditable(false);
            nmsRootField.setEnabled(false);
            break;
      
         case USE_COLOCATED:
            hostLabel.setEnabled(false);
            hostField.setEditable(false);
            hostField.setEnabled(false);
   
            nmsRoot.setEnabled(false);
            nmsRootField.setEditable(false);
            nmsRootField.setEnabled(false);
            break;

         case USE_REMOTE:
            hostLabel.setText(Res.getString(Res.VB_PANEL_GATE_KEEPER_LABEL));
   
            nmsRoot.setEnabled(true);
            nmsRootField.setEditable(true);
            nmsRootField.setEnabled(true);
   
            boolean allowGateKeeper = !MainWindow.isStandaloneApp();
   
            hostLabel.setEnabled(allowGateKeeper);
            hostField.setEditable(allowGateKeeper);
            hostField.setEnabled(allowGateKeeper);
            break;
      }
   }


   // Initialize fields given the hashtable of values
   public void setParams(Hashtable params)
   {
      int mode = ConnectionInfo.getConnectionMode(params);
      int orbType;

      String host = (String) params.get(PropertyMetadata.HOST_NAME.getName());
      if (host == null)
      {
         host = JboEnvUtil.getDefaultHost();
      }

      hostField.setText(host);

      switch (mode)
      {
         case ConnectionModeConstants.USE_BIND:
            orbType = USE_BIND;
            break;

         case ConnectionModeConstants.REMOTE:
            orbType = USE_REMOTE;
            String nsRoot = (String) params.get(PropertyMetadata.APPLICATION_PATH.getName());
            if (nsRoot != null && nsRoot.length() > 0)
            {
               nmsRootField.setText(nsRoot);
            }
            else
            {
               nmsRootField.setText("");
            }
            break;

         case ConnectionModeConstants.COLOCATE:
         default:
            orbType = USE_COLOCATED;
            break;
      }

      orbConTypeCombo.setSelectedIndex(orbType);
   }

   public boolean getParams(Hashtable params, boolean showError)
   {
      int orbType = orbConTypeCombo.getSelectedIndex();
      int mode;
      boolean isValid;

      String host = hostField.getText();
      if (host != null)
      {
         host.trim();
      }

      if (orbType == USE_BIND)
      {
         mode = ConnectionModeConstants.USE_BIND;

         if (host.length() > 0)
         {
            params.put(PropertyMetadata.HOST_NAME.getName(), host);
         }
      }
      else if (orbType == USE_REMOTE)
      {
         mode = ConnectionModeConstants.REMOTE;

         isValid = false;
         String s = nmsRootField.getText();
         if (s != null)
         {
            s.trim();
            if (s.length() > 0)
            {
               params.put(PropertyMetadata.APPLICATION_PATH.getName(), s);
               isValid = true;
            }
         }

         if (!isValid)
         {
            if (showError)
            {
               ErrorHandler.displayError(parent, Res.getString(Res.VB_PANEL_NS_ROOT_ERROR));
            }
            return false;
         }

         if (host.length() > 0)
         {
            params.put(ConnectionInfo.ORB_GATEKEEPER_IOR, s);
         }
      }
      else // COLOCATE case
      {
         mode = ConnectionModeConstants.COLOCATE;
      }

      params.put(PropertyMetadata.CONNECTION_MODE.getName(), Integer.toString(mode));

      return true;
   }
}
