/*
 * @(#)HelpManager.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.jbotester;

import java.net.URL;
import oracle.help.Help;
import oracle.help.library.helpset.HelpSet;
import oracle.jbo.common.Diagnostic;

public final class HelpManager
{
   private final Help help;

   public HelpManager(String helpUrlStr)
   {
      try
      {
         URL helpUrl = new URL(helpUrlStr);
      
         help = new Help();
         Diagnostic.println("Loading HelpBook: " + helpUrl);
         help.addBook(new HelpSet(helpUrl));
      }
      catch (java.net.MalformedURLException ex)
      {
         throw new RuntimeException(Res.getString(Res.ERROR_CANT_FIND_HELP));
      }
      catch (oracle.help.library.helpset.HelpSetParseException ex)
      {
         throw new RuntimeException(ex.toString());
      }
   }
   
   public void helpMe(String topicID)
   {
      if (topicID == null)
      {
         //_help.showTopic( null, HelpTopics.CS_DEFAULT );
         Diagnostic.println("Showing navigator window");
         help.showNavigatorWindow();
      }
      else
      {
         help.showTopic(null, topicID);
      }
   }

}
