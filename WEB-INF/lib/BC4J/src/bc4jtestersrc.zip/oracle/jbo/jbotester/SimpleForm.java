/*
 * @(#)SimpleForm.java
 *
 * Copyright 1999-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.jbotester;

import java.awt.BorderLayout;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import oracle.jbo.RowSetIterator;
import oracle.jbo.ViewObject;

public class SimpleForm extends JPanel
{
   private final MainFrame    mainFrame;
   private final RowSetPanel  masterPanel;
   private final NavBar       toolBar;
   private final ObjTreeNode  node;         // Tree node associated with the form
   protected final JScrollPane scroller;
   
   public SimpleForm(MainFrame frame, ObjTreeNode objNode)
   {
      this(frame, objNode, null);
   }

   public SimpleForm(MainFrame frame, ObjTreeNode objNode, ViewObject vo)
   {
      super(new BorderLayout(), false);

      mainFrame = frame;
      node = objNode;

      masterPanel = new RowSetPanel(frame);
      scroller = new JScrollPane(masterPanel);

      toolBar = new NavBar(mainFrame);

      add(toolBar, BorderLayout.NORTH);
      add(scroller, BorderLayout.CENTER);

      if (vo != null)
      {
         setIterator(vo);
      }
   }

   public final void setIterator(RowSetIterator iterator)
   {
      toolBar.setIterator(iterator);
      if (iterator != null)
      {
         toolBar.setMyParent(this);
      }
      masterPanel.setIterator(iterator);
   }

   public final RowSetIterator getIterator()
   {
      return masterPanel.getIterator();
   }

   public final ObjTreeNode getTreeNode()
   {
      return node;
   }

   public final MainFrame getMainFrame()
   {
      return mainFrame;
   }

   public final void refreshAll()
   {
      masterPanel.refreshAll(getIterator().getCurrentRow());
   }
}

