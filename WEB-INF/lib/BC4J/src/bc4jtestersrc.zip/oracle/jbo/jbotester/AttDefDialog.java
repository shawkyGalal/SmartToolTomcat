/*
 * @(#)AttDefDialog.java
 *
 * Copyright 1999-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.jbotester;

import java.awt.Color;
import java.awt.Container;
import java.awt.Font;
import java.awt.Frame;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.util.Enumeration;
import java.util.Hashtable;
import javax.swing.BorderFactory;
import javax.swing.JLabel;
import javax.swing.JWindow;
import oracle.jbo.AttributeDef;

public class AttDefDialog extends JWindow
{
   private AttributeDef mAttrDef   = null;

   private GridBagLayout gbl       = new GridBagLayout();
   private GridBagConstraints gbc  = new GridBagConstraints();

   private int ypos = 0;

   public AttDefDialog(AttributeDef attrDef, Frame parent)
   {
      super(parent);

      mAttrDef = attrDef;

      try
      {
         jbInit();
         pack();
      }
      catch (Exception e)
      {
         ErrorHandler.displayError(parent, e);
      }
   }

   private void jbInit() throws Exception
   {
      Container mainPanel = getContentPane();

      mainPanel.setLayout(gbl);
      mainPanel.setBackground(Color.white);
      getRootPane().setBorder(BorderFactory.createLineBorder(Color.black));

      ypos = 0;

      gbc.fill = GridBagConstraints.HORIZONTAL;
      gbc.gridx = 0;
      gbc.gridy = 0;
      gbc.anchor = GridBagConstraints.EAST;
      gbc.gridwidth = 1;
      gbc.insets = new Insets(0, 5, 0, 5);

      createLabel(mainPanel, Res.getString(Res.ATTR_DIALOG_NAME), mAttrDef.getName(), Font.PLAIN);
      createLabel(mainPanel, Res.getString(Res.ATTR_DIALOG_COLUMN_NAME), mAttrDef.getColumnName(), Font.PLAIN);
      createLabel(mainPanel, Res.getString(Res.ATTR_DIALOG_INDEX), String.valueOf(mAttrDef.getIndex()), Font.PLAIN);
      createLabel(mainPanel, Res.getString(Res.ATTR_DIALOG_JAVA_TYPE), mAttrDef.getJavaType().getName(), Font.PLAIN);
      createLabel(mainPanel, Res.getString(Res.ATTR_DIALOG_SQL_TYPE), String.valueOf(mAttrDef.getSQLType()), Font.PLAIN);
      int uFlag = Res.ATTR_DIALOG_UPDATEABLE;
      if ( mAttrDef.getUpdateableFlag() == mAttrDef.READONLY )
      {
         uFlag = Res.ATTR_DIALOG_READONLY;
      }
      else if ( mAttrDef.getUpdateableFlag() == mAttrDef.UPDATEABLE_WHILE_NEW)
      {
         uFlag = Res.ATTR_DIALOG_UPDATEABLE_WHL_NEW;
      }
      createLabel(mainPanel, Res.getString(Res.ATTR_DIALOG_UPDATEABLE_FLAG), Res.getString(uFlag), Font.PLAIN);
      String str = "";
      switch (mAttrDef.getAttributeKind())
      {
      case AttributeDef.ATTR_DYNAMIC:
         str = Res.getString(Res.ATTR_DIALOG_ATTR_DYNAMIC);
         break;
      case AttributeDef.ATTR_ASSOCIATED_ROW:
         str = Res.getString(Res.ATTR_DIALOG_ATTR_ASSOCIATED_ROW);
         break;
      case AttributeDef.ATTR_ASSOCIATED_ROWITERATOR:
         str = Res.getString(Res.ATTR_DIALOG_ATTR_ASSOCIATED_ROWITERATOR);
         break;
      case AttributeDef.ATTR_TRANSIENT:
         str = Res.getString(Res.ATTR_DIALOG_ATTR_TRANSIENT);
         break;
      case AttributeDef.ATTR_PERSISTENT:
         str = Res.getString(Res.ATTR_DIALOG_ATTR_PERSISTENT);
         break;
      case AttributeDef.ATTR_SQL_DERIVED:
         str = Res.getString(Res.ATTR_DIALOG_ATTR_SQL_DERIVED);
         break;
      case AttributeDef.ATTR_ENTITY_DERIVED:
         str = Res.getString(Res.ATTR_DIALOG_ATTR_ENTITY_DERIVED);
         break;
      }
      createLabel(mainPanel, Res.getString(Res.ATTR_DIALOG_ATTRIBUTE_KIND), str, Font.PLAIN);
      createLabel(mainPanel, Res.getString(Res.ATTR_DIALOG_QUERIABLE), String.valueOf(mAttrDef.isQueriable()), Font.PLAIN);
      createLabel(mainPanel, Res.getString(Res.ATTR_DIALOG_PRIMARY_KEY), String.valueOf(mAttrDef.isPrimaryKey()), Font.PLAIN);
      createLabel(mainPanel, Res.getString(Res.ATTR_DIALOG_SCALE), String.valueOf(mAttrDef.getScale()), Font.PLAIN);
      createLabel(mainPanel, Res.getString(Res.ATTR_DIALOG_PRECISION), String.valueOf(mAttrDef.getPrecision()), Font.PLAIN);

      Hashtable ht = mAttrDef.getProperties();
      if (ht != null)
      {
         Enumeration en = ht.keys();
         String key;
         if (en.hasMoreElements())
         {
            createLabel(mainPanel, Res.getString(Res.ATTR_DIALOG_PROPERTY), Res.getString(Res.ATTR_DIALOG_VALUE), Font.BOLD);
         }
         while (en.hasMoreElements())
         {
            key = (String)en.nextElement();
            createLabel(mainPanel, key, (String)ht.get(key), Font.PLAIN);
         }
      }
   }

   private void createLabel(Container pane, String name, String value, int style)
   {
      JLabel nameLabel = new JLabel(name);
      JLabel valueLabel = new JLabel(value);

      gbc.anchor = GridBagConstraints.EAST;
      gbc.gridx = 0;
      gbc.gridy = GridBagConstraints.RELATIVE;
      gbc.gridwidth = 1;
      gbl.setConstraints(nameLabel, gbc);
      pane.add(nameLabel);
      applyStyle(nameLabel, style);

      gbc.anchor = GridBagConstraints.WEST;
      gbc.gridx = GridBagConstraints.RELATIVE;
      gbc.gridy = ypos++;
      gbc.gridwidth = GridBagConstraints.REMAINDER;
      gbl.setConstraints(valueLabel, gbc);
      pane.add(valueLabel);
      applyStyle(valueLabel, style);
   }

   private void applyStyle(JLabel label, int style)
   {
      Font ft = label.getFont();
      if (ft.getStyle() != style)
      {
         switch( style )
         {
            case Font.BOLD:
            case Font.PLAIN:
            case Font.ITALIC:
            {
               Font newft = new Font(ft.getName(), style, ft.getSize());
               label.setFont(newft);
            }
            default:
            //donothing.
         }
      }
   }
}

