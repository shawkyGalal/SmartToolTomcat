/*
 * @(#)GenericDialog.java
 *
 * Copyright 1999-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.jbotester;

import com.sun.java.util.collections.ArrayList;
import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Frame;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import javax.swing.AbstractAction;
import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.KeyStroke;

public class GenericDialog extends JDialog implements ActionListener
{
   public static final int OK_HELP_OPTION = 0;
   public static final int CLOSE_HELP_OPTION = 1;
   public static final int OK_CANCEL_HELP_OPTION = 2;
   public static final int OK_OPTION = 3;
   public static final int OK_CANCEL_OPTION = 4;

   public static final String OK_ACTION     = "ok";
   public static final String CANCEL_ACTION = "cancel";
   public static final String CLOSE_ACTION  = "close";

   protected final Frame         parent;
   protected final JPanel        mainPanel;
   private        String         helpLocation;
   protected      String         exitCmd;
   protected      Component      initialFocusComponent;
   private final  AbstractAction helpAction = new HelpAction();
   private        ActionListener helpActionListener;
   private        boolean        isRegisteredToHelp;

   public GenericDialog(Frame parent, String title, JPanel mainPanel, int dlgType)
   {
      this(parent, title, mainPanel, dlgType, null);
   }

   public GenericDialog(Frame parent, String title, JPanel mainPanel)
   {
      this(parent, title, mainPanel, OK_HELP_OPTION, null);
   }

   public GenericDialog(Frame parent, String title, JPanel mainPanel, int dlgType, String defBtnText)
   {
      super(parent, title, true);

      this.parent = parent;
      this.mainPanel = mainPanel;

      JPanel mSouthPanel = new JPanel();
      mSouthPanel.setLayout(new BoxLayout(mSouthPanel, BoxLayout.X_AXIS));
      mSouthPanel.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 0));

      getContentPane().add(mainPanel, BorderLayout.CENTER);
      getContentPane().add(mSouthPanel, BorderLayout.SOUTH);

      registerKeyboardActions();
  
      JButton mDefaultButton;
      int maxWidth = 0;
      ArrayList buttons = new ArrayList();

      if (dlgType == OK_HELP_OPTION || dlgType == OK_CANCEL_HELP_OPTION || dlgType == OK_OPTION || dlgType == OK_CANCEL_OPTION)
      {
         if (defBtnText == null)
         {
            defBtnText = Res.getString(Res.DIALOG_OK_BUTTON);
         }

         mDefaultButton = new JButton(defBtnText);

         mDefaultButton.setActionCommand(OK_ACTION);
      }
      else if (dlgType == CLOSE_HELP_OPTION)
      {
         if (defBtnText == null)
         {
            defBtnText = Res.getString(Res.DIALOG_CLOSE_BUTTON);
         }

         mDefaultButton = new JButton(defBtnText);
         mDefaultButton.setActionCommand(CLOSE_ACTION);
      }
      else
      {
         return;
      }

      mDefaultButton.addActionListener(this);

      if (dlgType != OK_OPTION && dlgType != OK_CANCEL_OPTION)
      {
         JButton mHelpButton = new JButton(helpAction);
         int mnemonic  = JboTesterUtil.getMnemonicKeyCode(Res.DIALOG_HELP_BUTTON);
         if (mnemonic != 0)
         {
            mHelpButton.setMnemonic(mnemonic);
         }

         buttons.add(mHelpButton);
         maxWidth = Math.max(maxWidth, mHelpButton.getMinimumSize().width);
      }
      
      maxWidth = Math.max(maxWidth, mDefaultButton.getMinimumSize().width);
      buttons.add(mDefaultButton);

      if (dlgType == OK_CANCEL_HELP_OPTION || dlgType == OK_CANCEL_OPTION)
      {
         JButton mCancelButton = new JButton(Res.getString(Res.DIALOG_CANCEL_BUTTON));
         mCancelButton.setActionCommand(CANCEL_ACTION);
         mCancelButton.addActionListener(this);
         maxWidth = Math.max(maxWidth, mCancelButton.getMinimumSize().width);
         buttons.add(mCancelButton);
      }

      Dimension   d = new Dimension(maxWidth, mDefaultButton.getMinimumSize().height);
      Dimension   spacing = new Dimension(8, 0);
      JButton     b;

      for (int i = 0; i < buttons.size(); i++)
      {
         b = (JButton) buttons.get(i);
         b.setPreferredSize(d);

         if (i == 0)
         {
            if (b.getAction() == helpAction)
            {
               mSouthPanel.add(b);
               mSouthPanel.add(Box.createHorizontalGlue());
            }
            else
            {
               mSouthPanel.add(Box.createHorizontalGlue());
               mSouthPanel.add(b);
               mSouthPanel.add(Box.createRigidArea(spacing));
            }
         }
         else
         {
            mSouthPanel.add(b);
            mSouthPanel.add(Box.createRigidArea(spacing));
         }
         
      }

      getRootPane().setDefaultButton(mDefaultButton);
      setInitialFocusComponent(mDefaultButton);

      addWindowListener(new WindowAdapter()
      {
         boolean gotFocus = false;

         public void windowActivated(WindowEvent we)
         {
            // Once window gets focus, set initial focus
            if (!gotFocus)
            {
               getInitialFocusComponent().requestFocus();
               gotFocus = true;
            }
         }
      });
   }
   
   public JPanel getMainPanel()
   {
      return mainPanel;
   }

   public String getExitCommand()
   {
      return exitCmd;
   }

   public void setHelpLocation(String help)
   {
      helpLocation = help;
   }

   public String getHelpLocation()
   {
      return helpLocation;
   }

   public void setHelpActionListener(ActionListener help)
   {
      helpActionListener = help;
   }

   public ActionListener getHelpActionListener()
   {
      return helpActionListener;
   }

   public void setInitialFocusComponent(Component comp)
   {
      initialFocusComponent = comp;
   }

   public Component getInitialFocusComponent()
   {
      return initialFocusComponent;
   }

   // ActionListener interface
   public void actionPerformed(ActionEvent event)
   {
      String cmd = event.getActionCommand();

      if (cmd.equals(OK_ACTION) || cmd.equals(CANCEL_ACTION) || cmd.equals(CLOSE_ACTION))
      {
         exitCmd = cmd;
         close();
      }
   }

   public void close()
   {
      if (isRegisteredToHelp)
      {
         oracle.bali.ewt.util.WindowUtils.unregisterWindow(this);
         isRegisteredToHelp = false;
      }
      this.setVisible(false);
      this.dispose();

   }

   // override JDialog.show()
   public void show()
   {
      this.pack();
      // Custom show which will automatically center this dialog
      this.setLocationRelativeTo(parent);
      super.show();
   }

   public void doHelp()
   {
      if (parent instanceof MainFrame)
      {
         if (!isRegisteredToHelp)
         {
            isRegisteredToHelp = true;
            oracle.bali.ewt.util.WindowUtils.registerWindow(this);
         }
         ((MainFrame) parent).helpMe(helpLocation);
      }
   }

   private final void registerKeyboardActions()
   {
      JComponent c = getRootPane();

      // register an action listener for f1
      c.registerKeyboardAction(helpAction, KeyStroke.getKeyStroke(KeyEvent.VK_F1, 0), JComponent.WHEN_IN_FOCUSED_WINDOW);
      c.registerKeyboardAction(helpAction, KeyStroke.getKeyStroke(KeyEvent.VK_HELP, 0), JComponent.WHEN_IN_FOCUSED_WINDOW);

      // register an action listener for Esc
      c.registerKeyboardAction(this, CANCEL_ACTION, KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0), JComponent.WHEN_IN_FOCUSED_WINDOW);
   }

   private final class HelpAction extends AbstractAction
   {
      public HelpAction()
      {
         super(JboTesterUtil.stripMnemonic(Res.getString(Res.DIALOG_HELP_BUTTON)));
      }

      public void actionPerformed(ActionEvent e)
      {
         doHelp();
      }
   }
}

