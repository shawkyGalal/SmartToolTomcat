/*
 * @(#)NavBar.java
 *
 * Copyright 1999-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.jbotester;

import java.awt.event.ActionEvent;
import javax.swing.Action;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JToolBar;
import javax.swing.border.Border;
import javax.swing.SwingUtilities;

import oracle.jbo.DeleteEvent;
import oracle.jbo.InsertEvent;
import oracle.jbo.NavigationEvent;
import oracle.jbo.RangeRefreshEvent;
import oracle.jbo.Row;
import oracle.jbo.RowIterator;
import oracle.jbo.RowSetIterator;
import oracle.jbo.ScrollEvent;
import oracle.jbo.UpdateEvent;
import oracle.jbo.common.DebugDiagnostic;

public final class NavBar extends JToolBar implements JBOControl
{
   private final MainFrame mainFrame;
   private RowSetIterator iter;

   private JPanel mParent;
   private Action mActions[] = new Action[NUM_BUTTONS + 1];

   public static final int FIRST         = 0;
   public static final int PREVIOUS      = 1;
   public static final int NEXT          = 2;
   public static final int LAST          = 3;
   public static final int INSERT        = 4;
   public static final int DELETE        = 5;
   public static final int NEXT_PAGE     = 6;
   public static final int PREV_PAGE     = 7;
   public static final int COMMIT        = 8;
   public static final int ROLLBACK      = 9;
   public static final int CONNECT       = 10;
   public static final int DISCONNECT    = 11;
   public static final int FIND          = 12;
   public static final int SEPARATE_WIN  = 13;
   public static final int CLOSE         = 14;
   public static final int VALIDATE      = 15;
   public static final int NUM_BUTTONS   = 16;

   public static final String images[][] = {
                                  {"firstrec.gif",  "firstrecd.gif"},
                                  {"prevrec.gif",   "prevrecd.gif"},
                                  {"nextrec.gif",   "nextrecd.gif"},
                                  {"lastrec.gif",   "lastrecd.gif"},
                                  {"addnew.gif",    "addnewd.gif"},
                                  {"deleterec.gif", "deleterecd.gif"},
                                  {"nextpage.gif",  "nextpaged.gif"},
                                  {"prevpage.gif",  "prevpaged.gif"},
                                  {"save.gif",      "saved.gif"},
                                  {"rollback.gif",  "rollbackd.gif"},
                                  {"gologin.gif",   "gologind.gif"},
                                  {"gologout.gif",  "gologoutd.gif"},
                                  {"query.gif",     "queryd.gif"},
                                  {"sepwin.gif",    "sepwin.gif"},
                                  {"close.gif",     "close.gif"},
                                  {"validaterow.gif", "validaterow.gif"},
                               };

   public static final Border buttonBorder = BorderFactory.createEmptyBorder(5,5,5,5);

   public NavBar(MainFrame frame)
   {
      this(frame, false, JToolBar.HORIZONTAL);
   }

   public NavBar(MainFrame frame, boolean noPopup)
   {
      this(frame, noPopup, JToolBar.HORIZONTAL);
   }

   public NavBar(MainFrame frame, boolean noPopup, int orient)
   {
      super(orient);

      mainFrame = frame;

      add(new rsFirst(), Res.NAVBAR_TOOLBAR_FIRST_KEY, FIRST);
      add(new rsPrevPage(), Res.NAVBAR_TOOLBAR_PREV_PAGE_KEY, PREV_PAGE);
      add(new rsPrev(), Res.NAVBAR_TOOLBAR_PREV_KEY, PREVIOUS);
      add(new rsNext(), Res.NAVBAR_TOOLBAR_NEXT_KEY, NEXT);
      add(new rsNextPage(), Res.NAVBAR_TOOLBAR_NEXT_PAGE_KEY, NEXT_PAGE);
      add(new rsLast(), Res.NAVBAR_TOOLBAR_LAST_KEY, LAST);
      addSeparator();
      add(new rsInsert(), Res.NAVBAR_TOOLBAR_INSERT_KEY, INSERT);
      add(new rsDelete(), Res.NAVBAR_TOOLBAR_DELETE_KEY, DELETE);
      addSeparator();
      add(new rsFind(), Res.NAVBAR_TOOLBAR_FIND_KEY, FIND);
      add(new rsValidate(), Res.NAVBAR_TOOLBAR_VALIDATE_KEY, FIND);
      if (!noPopup)
      {
         addSeparator();
         add(new rsWin(), Res.NAVBAR_TOOLBAR_WINDOW_KEY, SEPARATE_WIN);
         add(new rsClose(), Res.NAVBAR_TOOLBAR_CLOSE_KEY, CLOSE);
         addSeparator();
      }
   }

   //
   // JBOcontrol interface
   //
   public RowSetIterator getIterator()
   {
      return iter;
   }

   public synchronized void setIterator(RowSetIterator iterator)
   {
      if (iter == iterator)
      {
         return;
      }

      if (iter != null)
      {
         iter.removeListener(this);
      }

      iter = iterator;
      if (iter != null)
      {
         iter.addListener(this);
         DebugDiagnostic.println(">>New iterator on Navigator: " + (iter != null ? iter.getName() : "null") );

         if (iter.getRowSet().getViewObject().isReadOnly())
         {
            // the ViewObject is Read-Only. SO disallow the following options
            DebugDiagnostic.println("**** VO IS READ ONLY! ****");
            mActions[INSERT].setEnabled(false);
            mActions[DELETE].setEnabled(false);
         }

         resetButtons();
//         iter.getAllRowsInRange();
      }
   }

   void add(Action act, int mnemonicRes, int index)
   {
      JButton button = super.add(act);
      initButton(button, Res.getString(mnemonicRes).charAt(0), index);
      mActions[index] = act;
   }

   public static void initButton(JButton button, char mnemonic, int index)
   {
      button.setText("");
      button.setMnemonic(mnemonic);
      button.setBorderPainted(false);
      button.setBorder(buttonBorder);
      button.setDisabledIcon(JboTesterUtil.getIcon(images[index][1]));
   }

   public void setMyParent(JPanel parent)
   {
      mParent = parent;
   }

   public JPanel getMyParent()
   {
      if ( mParent == null )
      {
         return (JPanel)getParent();
      }
      return mParent;
   }

   //
   // RowSet listener
   //
   public void navigated(NavigationEvent event)
   {
      resetButtons();
   }

   public void rangeRefreshed(RangeRefreshEvent event)
   {
      RangeRefreshHandler hdlr = new RangeRefreshHandler();
      hdlr.event = event;
      hdlr.navBar = this;
      SwingUtilities.invokeLater(hdlr);
   }

   public void rangeScrolled(ScrollEvent event)
   {
   }

   public void rowDeleted(DeleteEvent event)
   {
      resetButtons();
   }

   public void rowInserted(InsertEvent event)
   {
      resetButtons();
   }

   public void rowUpdated(UpdateEvent event)
   {
   }

   boolean stopCellEditing()
   {
      if (mParent instanceof MDForm) 
      {
         javax.swing.CellEditor editor = ((MDForm)mParent).detailTable.getCellEditor();
         if (editor != null) 
         {
            return (editor.stopCellEditing());
         }
      }
      return true;
   }

   void cancelCellEditing()
   {
      if (mParent instanceof MDForm) 
      {
         javax.swing.CellEditor editor = ((MDForm)mParent).detailTable.getCellEditor();
         if (editor != null) 
         {
            (editor.cancelCellEditing());
         }
      }
   }

   // Actions inner classes
   abstract class AbstractNavAction extends AbstractJboAction
   {
      public AbstractNavAction(String name)
      {
         super(name);
      }

      public AbstractNavAction(String name, int index, int tooltipResId)
      {
         super(name, index, tooltipResId);
      }
      
      protected MainFrame getMainFrame()
      {
         return mainFrame;
      }
   }
   
   final class rsFirst extends AbstractNavAction
   {
      public rsFirst()
      {
         super("first", FIRST, Res.NAVBAR_TOOLBAR_FIRST);
      }

      protected void doAction(ActionEvent e)
      {
         if (stopCellEditing())
         {
            iter.first();
         }
      }
   }

   final class rsPrev extends AbstractNavAction
   {
      public rsPrev()
      {
         super("prev", PREVIOUS, Res.NAVBAR_TOOLBAR_PREV);
      }

      protected void doAction(ActionEvent e)
      {
         if (stopCellEditing())
         {
            iter.previous();
         }
      }
   }

   final class rsPrevPage extends AbstractNavAction
   {
      public rsPrevPage()
      {
         super("prevpage", PREV_PAGE, Res.NAVBAR_TOOLBAR_PREV_PAGE);
      }

      protected void doAction(ActionEvent e)
      {
         int nRet = iter.scrollRange(-iter.getRangeSize());
         if (nRet < 0)
         {
            if (stopCellEditing())
            {
               iter.setCurrentRowAtRangeIndex(0);
            }
         }
      }
   }

   final class rsNext extends AbstractNavAction
   {
      public rsNext()
      {
         super("next", NEXT, Res.NAVBAR_TOOLBAR_NEXT);
      }

      protected void doAction(ActionEvent e)
      {
         if (stopCellEditing())
         {
            iter.next();
         }
      }
   }

   final class rsNextPage extends AbstractNavAction
   {
      public rsNextPage()
      {
         super("nextpage", NEXT_PAGE, Res.NAVBAR_TOOLBAR_NEXT_PAGE);
      }

      protected void doAction(ActionEvent e)
      {
         int nRet = iter.scrollRange(iter.getRangeSize());
         if ( nRet > 0 )
         {
            if (stopCellEditing())
            {
               iter.setCurrentRowAtRangeIndex(0);
            }
         }
      }
   }

   final class rsLast extends AbstractNavAction
   {
      public rsLast()
      {
         super("last", LAST, Res.NAVBAR_TOOLBAR_LAST);
      }

      protected void doAction(ActionEvent e)
      {
         if (stopCellEditing())
         {
            iter.last();
         }
      }
   }

   final class rsInsert extends AbstractNavAction
   {
      public rsInsert()
      {
         super("insert", INSERT, Res.NAVBAR_TOOLBAR_INSERT);
      }

      protected void doAction(ActionEvent e)
      {
         if (stopCellEditing())
         {
            Row newRow = iter.createRow();

            if (newRow != null)
            {
               iter.insertRow(newRow);
            }
         }
      }
   }

   final class rsDelete extends AbstractNavAction
   {
      public rsDelete()
      {
         super("delete", DELETE, Res.NAVBAR_TOOLBAR_DELETE);
      }

      protected void doAction(ActionEvent e)
      {
         cancelCellEditing();
         iter.removeCurrentRow();
      }
   }

   final class rsValidate extends AbstractNavAction
   {
      public rsValidate()
      {
         super("validate", VALIDATE, Res.NAVBAR_TOOLBAR_VALIDATE);
      }

      protected void doAction(ActionEvent e)
      {
         if (stopCellEditing())
         {
            iter.getCurrentRow().validate();
         }
      }
   }
   
   final class rsFind extends AbstractNavAction
   {
      public rsFind()
      {
         super("find", FIND, Res.NAVBAR_TOOLBAR_FIND);
      }

      protected void doAction(ActionEvent e)
      {
         cancelCellEditing();
         JboTesterUtil.createViewCriteria(mainFrame, iter.getRowSet().getViewObject());
      }
   }

   final class rsWin extends AbstractNavAction
   {
      public rsWin()
      {
         super("window", SEPARATE_WIN, Res.NAVBAR_TOOLBAR_WINDOW);
      }

      protected void doAction(ActionEvent e)
      {
         ResultWindow.getResultWindow().displayInWindow((JPanel)getMyParent());
      }
   }

   final class rsClose extends AbstractNavAction
   {
      public rsClose()
      {
         super("close", CLOSE, Res.NAVBAR_TOOLBAR_CLOSE);
      }

      protected void doAction(ActionEvent e)
      {
         SimpleForm f = (SimpleForm) getMyParent();

         ObjTreeNode node = f.getTreeNode();
         if (node != null)
         {
            ResultWindow.getResultWindow().removeTab(node.getFullName());
         }
      }
   }

   void resetButtons()
   {
      boolean enable;

      if (iter == null)
      {
         return;
      }

      enable = iter.hasNext();

      mActions[NEXT].setEnabled(enable);
      mActions[NEXT_PAGE].setEnabled(enable);
      mActions[LAST].setEnabled(enable);

      enable = iter.hasPrevious();

      mActions[PREVIOUS].setEnabled(enable);
      mActions[PREV_PAGE].setEnabled(enable);
      mActions[FIRST].setEnabled(enable);

      mActions[DELETE].setEnabled(!iter.getRowSet().getViewObject().isReadOnly() &&
                                  iter.getCurrentRowSlot() == RowIterator.SLOT_VALID);
   }

   class RangeRefreshHandler implements Runnable
   {
      RangeRefreshEvent event;
      NavBar navBar;

      public void run()
      {
         if (navBar.iter.getCurrentRowSlot() != RowIterator.SLOT_VALID &&
             event.getRowCountInRange() > 0)
         {
            navBar.iter.first();
         }
         else
         {
            navBar.resetButtons();
         }
      }
   }
}


