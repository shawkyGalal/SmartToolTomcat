/*
 * @(#)ObjTreeNode.java
 *
 * Copyright 1999-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.jbotester;

import java.awt.event.ActionEvent;
import java.beans.BeanInfo;
import java.util.Enumeration;
import javax.swing.Action;
import javax.swing.ImageIcon;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import javax.swing.tree.DefaultMutableTreeNode;
import oracle.jbo.ComponentObject;
import oracle.jbo.jbotester.properties.PropertyDialog;
import oracle.jbo.jbotester.properties.PropertyPanel;

abstract public class ObjTreeNode extends DefaultMutableTreeNode
{
   public static final int APP_MODULE  = 0;
   public static final int VIEW_OBJECT = 1;
   public static final int VIEW_LINK   = 2;
   public static final int APP_MODULE_BRANCH = 3;
   public static final int VIEW_OBJECT_BRANCH = 4;
   public static final int VIEW_LINK_BRANCH = 5;

   public static final Action createVOAction = new CreateViewObjectAction();
   public static final Action createVLAction = new CreateViewLinkAction();
   public static final Action createAMAction = new CreateApplicationModuleAction();
   
   private Action findAction;
   private Action reExecuteAction;
   protected Action removeAction;
   protected JPopupMenu popupMenu;
   
   public ObjTreeNode(String name)
   {
      super(name);
   }

   abstract public String getName();

   public String getFullName()
   {
      return null;
   }

   abstract public Object getData();

   abstract public void setData(Object data);

   abstract public int getType();

   abstract public ImageIcon getIcon();

   public void showForm()
   {
      // nothing by default
   }

   public String getStatus()
   {
      return " ";
   }

   public void handleEvent(ActionEvent e)
   {
      // nothing by default
   }

   public JPopupMenu getMenu()
   {
      return null;
   }

   public void remove()
   {
      for (int i = getChildCount()-1; i >= 0; i--)
      {
          ((ObjTreeNode) getChildAt(i)).remove();
      }

      MainFrame.getInstance().getBaseTree().removeFromParent(this);
   }

   public void showProperties()
   {
      return;
   }

   /**
    *  Returns Name of the Node
    **/
   public String toString()
   {
      return getName();
   }

//
// Utility methods ----------------------------------------------------
//

   final public ObjTreeNode getChildOfName(String name)
   {
      ObjTreeNode child = null;

      for (Enumeration e = breadthFirstEnumeration(); e.hasMoreElements();)
      {
         child = (ObjTreeNode) e.nextElement();
         if (name.equals(child.getName()))
         {
            break;
         }
      }

      return child;
   }
   
   /**
    * Recurse through the parents for a node of a certain type
    */
   final public ObjTreeNode getParentOfType(int type)
   {
      if (getType() == type)
      {
         return this;
      }

      ObjTreeNode parent = (ObjTreeNode) getParent();
      if (parent == null)
      {
         return null;
      }

      return parent.getParentOfType(type);
   }

   final public boolean isFormDisplayed(ComponentObject cObj)
   {
      boolean isShowing = true;

      if (cObj != null)
      {
         JPanel form = ResultWindow.getResultWindow().getTab(cObj.getFullName());

         isShowing = (form != null);
      }
      else
      {
         isShowing = false;
      }

      return isShowing;
   }

   // Action classes definitions
   static final class CreateViewObjectAction extends AbstractJboAction
   {
      public CreateViewObjectAction()
      {
         super(Res.getString(Res.TREE_MENU_CREATE_VO));
      }

      protected MainFrame getMainFrame()
      {
         return MainFrame.getInstance();
      }
      
      protected void doAction(ActionEvent e)
      {
         getMainFrame().getBaseTree().createDynViewObject();
      }
   }

   static final class CreateViewLinkAction extends AbstractJboAction
   {
      public CreateViewLinkAction()
      {
         super(Res.getString(Res.TREE_MENU_CREATE_VL));
      }

      protected MainFrame getMainFrame()
      {
         return MainFrame.getInstance();
      }
      
      public void doAction(ActionEvent e)
      {
         getMainFrame().getBaseTree().createDynViewLink();
      }
   }

   static final class CreateApplicationModuleAction extends AbstractJboAction
   {
      public CreateApplicationModuleAction()
      {
         super(Res.getString(Res.TREE_MENU_CREATE_AM));
      }

      protected MainFrame getMainFrame()
      {
         return MainFrame.getInstance();
      }
      
      public void doAction(ActionEvent e)
      {
         getMainFrame().getBaseTree().createApplicationModule();
      }
   }

   final protected JPopupMenu createVOVLMenu(ComponentObject cObj)
   {
      if (popupMenu == null)
      {
         popupMenu = new JPopupMenu();
      
         popupMenu.add(new ShowAction());
         
         if (removeAction == null)
         {
            removeAction = new RemoveAction();
         }
         popupMenu.add(removeAction);
         
         if (findAction == null)
         {
            findAction = new HandleEventAction(Res.getString(Res.TREE_MENU_FIND));
         }
         popupMenu.add(findAction);

         if (reExecuteAction == null)
         {
            reExecuteAction = new HandleEventAction(Res.getString(Res.TREE_MENU_EXECUTE));
         }
         popupMenu.add(reExecuteAction);

         popupMenu.addSeparator();
         popupMenu.add(new PropertiesAction());
      }
      
      boolean isShowing = isFormDisplayed(cObj);
      
      findAction.setEnabled(isShowing);
      reExecuteAction.setEnabled(isShowing);

      return popupMenu;
   }

   final protected void showPropertyDialog(Object bean, BeanInfo beanInfo, int resString)
   {
      PropertyPanel panel = new PropertyPanel(MainFrame.getInstance(), bean, beanInfo);

      PropertyDialog pd = new PropertyDialog(MainFrame.getInstance(), Res.getString(resString), panel);
      pd.setHelpLocation("f1_bcbctproperties_html");
      pd.show();
   }

   // Default action handler for nodes

   abstract class AbstractNodeAction extends AbstractJboAction
   {
      public AbstractNodeAction(String name)
      {
         super(name);
      }

      public AbstractNodeAction(String name, int index, int tooltipResId)
      {
         super(name, index, tooltipResId);
      }
      
      protected MainFrame getMainFrame()
      {
         return MainFrame.getInstance();
      }
   }

   final class HandleEventAction extends AbstractNodeAction
   {
      public HandleEventAction(String name)
      {
         super(name);
      }

      public void doAction(ActionEvent e)
      {
         ObjTreeNode.this.handleEvent(e);
      }
   }

   final class RemoveAction extends AbstractNodeAction
   {
      public RemoveAction()
      {
         super(Res.getString(Res.TREE_MENU_REMOVE));
      }

      public void doAction(ActionEvent e)
      {
         ObjTreeNode.this.remove();
      }
   }

   final class PropertiesAction extends AbstractNodeAction
   {
      public PropertiesAction()
      {
         super(Res.getString(Res.TREE_MENU_PROPERTIES));
      }

      public void doAction(ActionEvent e)
      {
         ObjTreeNode.this.showProperties();
      }
   }

   final class ShowAction extends AbstractNodeAction
   {
      public ShowAction()
      {
         super(Res.getString(Res.TREE_MENU_SHOW));
      }

      public void doAction(ActionEvent e)
      {
         ObjTreeNode.this.showForm();
      }
   }
}
