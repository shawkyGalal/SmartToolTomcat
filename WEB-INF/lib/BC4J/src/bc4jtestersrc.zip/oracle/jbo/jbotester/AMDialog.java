/*
 * @(#)AMDialog.java
 *
 * Copyright 1999-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.jbotester;

import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import oracle.jbo.ApplicationModule;

public final class AMDialog extends GenericDialog
{
   private ApplicationModule mAppModule;
   private final ApplicationModule mParentAppModule;

   private final JTextField   amField     = new JTextField();
   private final JComboBox    amdCombo    = new JComboBox();

   public AMDialog(JFrame frame, ApplicationModule appMod)
   {
      super(frame, Res.getString(Res.AM_DIALOG_TITLE), new JPanel(new GridBagLayout()), OK_CANCEL_HELP_OPTION, Res.getString(Res.DIALOG_CREATE_BUTTON));

      mParentAppModule = appMod;

      createAMPanel(getMainPanel());
      initAmDefCombo();

      setInitialFocusComponent(amField);
      setHelpLocation("f1_bcbctcreateappmod_html");
   }

   private void createAMPanel(JPanel amPanel)
   {
      GridBagLayout gbl      = (GridBagLayout) amPanel.getLayout();
      GridBagConstraints gbc = new GridBagConstraints();

      JLabel amName = JboTesterUtil.createLabel(Res.AM_DIALOG_AM_LABEL, amField);
      JLabel amDefName = JboTesterUtil.createLabel(Res.AM_DIALOG_AM_DEF_LABEL, amdCombo);

      amField.setColumns(25);
      JboTesterUtil.removeKeyBindingCompatibility(amField);

      amName.setHorizontalAlignment(SwingConstants.RIGHT);
      amDefName.setHorizontalAlignment(SwingConstants.RIGHT);
      amdCombo.setEditable(true);

      gbc.fill = GridBagConstraints.HORIZONTAL;

      gbc.gridx = 0;
      gbc.gridy = 0;
      gbc.anchor = GridBagConstraints.EAST;
      gbc.gridwidth = 1;
      gbc.insets = new Insets(30, 0, 10, 10);
      gbl.setConstraints(amName, gbc);
      amPanel.add(amName);

      gbc.gridx = GridBagConstraints.RELATIVE;
      gbc.gridy = 0;
      gbc.insets = new Insets(30, 0, 10, 10);
      gbc.anchor = GridBagConstraints.WEST;
      gbc.gridwidth = GridBagConstraints.REMAINDER;
      gbl.setConstraints(amField, gbc);
      amPanel.add(amField);

      gbc.anchor = GridBagConstraints.EAST;
      gbc.gridx = 0;
      gbc.insets = new Insets(0, 10, 30, 10);
      gbc.gridy = GridBagConstraints.RELATIVE;
      gbc.gridwidth = 1;
      gbl.setConstraints(amDefName, gbc);
      amPanel.add(amDefName);

      gbc.anchor = GridBagConstraints.WEST;
      gbc.gridx = GridBagConstraints.RELATIVE;
      gbc.insets = new Insets(0, 0, 30, 10);
      gbc.gridy = 1;
      gbc.gridwidth = GridBagConstraints.REMAINDER;
      gbl.setConstraints(amdCombo, gbc);
      amPanel.add(amdCombo);
   }

   private void createAppModule()
   {
      try
      {
         String amDefName = (String)amdCombo.getSelectedItem();
         if (amDefName.length() <= 0)
         {
            ErrorHandler.displayError(parent, Res.getString(Res.AM_DIALOG_AM_NAME_ERROR));
            return ;
         }
         mAppModule = mParentAppModule.createApplicationModule(amField.getText(), amDefName);

         close();
      }
      catch(Exception e)
      {
         ErrorHandler.displayError(parent, e);
      }
   }

   public ApplicationModule getApplicationModule()
   {
      return mAppModule;
   }

   private void initAmDefCombo()
   {
      String amdNames[] = mParentAppModule.getSession().getAllApplicationModuleDefNames();
      if ((amdNames == null) || (amdNames.length <= 0))
      {
         return ;
      }

      for (int i=0; i < amdNames.length; i++)
      {
         amdCombo.addItem(amdNames[i]);
      }
   }

   public void actionPerformed(ActionEvent event)
   {
      String cmd = event.getActionCommand();

      if (cmd.equals(OK_ACTION))
      {
         createAppModule();
      }
      else
      {
         super.actionPerformed(event);
      }
   }
}
