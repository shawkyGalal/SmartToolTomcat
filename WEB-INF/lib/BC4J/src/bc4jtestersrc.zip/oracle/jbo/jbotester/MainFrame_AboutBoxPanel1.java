/*
 * @(#)MainFrame_AboutBoxPanel1.java
 *
 * Copyright 1999-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.jbotester;

import java.awt.BorderLayout;
import javax.swing.BorderFactory;
import javax.swing.JLabel;
import javax.swing.JPanel;
import oracle.jbo.Version;

public class MainFrame_AboutBoxPanel1 extends JPanel
{
   public static final String tester_version = "1.2";
   
   public MainFrame_AboutBoxPanel1()
   {
      super(new BorderLayout());

      JLabel jLabel1 = new JLabel(Res.format(Res.TESTER_TITLE, ""), JLabel.CENTER);
      JLabel jLabel2 = new JLabel(Res.format(Res.ABOUT_DIALOG_VERSION, tester_version), JLabel.CENTER);
      JLabel jLabel3 = new JLabel(Res.format(Res.ABOUT_DIALOG_RUNTIME_VERSION, Version.getAsString()), JLabel.CENTER);

      jLabel1.setBorder(BorderFactory.createEmptyBorder(20, 50, 5, 50));
      jLabel2.setBorder(BorderFactory.createEmptyBorder(5, 10, 10, 10));
      jLabel3.setBorder(BorderFactory.createEmptyBorder(10, 10, 40, 10));

      add(jLabel1, BorderLayout.NORTH);
      add(jLabel2, BorderLayout.CENTER);
      add(jLabel3, BorderLayout.SOUTH);
   }
}

