/*
 * @(#)JBOTreeModel.java
 *
 * Copyright 1999-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.jbotester;

import com.sun.java.util.collections.HashMap;
import javax.swing.tree.DefaultTreeModel;
import oracle.jbo.DeleteEvent;
import oracle.jbo.InsertEvent;
import oracle.jbo.NavigationEvent;
import oracle.jbo.RangeRefreshEvent;
import oracle.jbo.Row;
import oracle.jbo.RowSetListener;
import oracle.jbo.ScrollEvent;
import oracle.jbo.UpdateEvent;
import oracle.jbo.common.DebugDiagnostic;

class JBOTreeModel extends DefaultTreeModel implements RowSetListener
{
   JBOTreeModel(Row root, String attrName)
   {
      super(new JBOTreeNode(new HashMap(), root, attrName), true);
   }

   final public JBOTreeNode getNode(Row row)
   {
      return (JBOTreeNode) ((JBOTreeNode) getRoot()).getNode(row);
   }

   // RowSet listener
   //
   public void rangeRefreshed(RangeRefreshEvent event)
   {
   }

   public void rangeScrolled(ScrollEvent event)
   {
   }

   public void navigated(NavigationEvent event)
   {
   }

   public void rowUpdated(UpdateEvent event)
   {
      Row r = event.getRow();

      //$$$ Temporary way to figure out if a row is new
      if (r.getAttribute("Name") == null)
      {
         return;
      }

      boolean needUpdateName = false;

      String[] changedAttr = event.getChangedAttrNames();
      for (int i = 0; i < changedAttr.length; i++)
      {
         if (changedAttr[i].compareTo("Name") == 0)
         {
            needUpdateName = true;
            break;
         }
      }

      JBOTreeNode node = null;

      // The might be a problem in LOCAL mode for getNode(r) because in local mode
      // the event contain the entity row instead of the viewrow
      node = getNode(r);

      if (node != null)
      {
         DebugDiagnostic.println("Node '" + node.toString() + "' is updating.");

         if (needUpdateName)
         {
            nodeChanged(node);
         }
         else // Reset the tooltip is anything else changed except name
         {
//            node.setToolTipText(null);
         }
      }
   }

   public void rowDeleted(DeleteEvent event)
   {
      Row r = event.getRow();

      JBOTreeNode node = getNode(r);
      // If node still in tree, remove it
      if (node != null)
      {
         JBOTreeNode  parent = (JBOTreeNode) node.getParent();

         int[]    childIndex = new int[1];
         Object[] removedArray = new Object[1];

         childIndex[0] = event.getRowIndex();

         // Remove itself from the local hashMap
         node.removeNode(r);

         node.setParent(null);
         removedArray[0] = node;
         nodesWereRemoved(parent, childIndex, removedArray);
      }

      DebugDiagnostic.println("Row '" + r.getAttribute("Name") + "' has been deleted.");
   }

   public void rowInserted(InsertEvent event)
   {
      Row r = event.getRow();

      JBOTreeNode node = getNode(r);

/*
      // Retrieve the parent node using the parentId
      JBOTreeNode parent = getNode((Number) r.getAttribute(4)); // parentId

      // Sign of a reparenting where we receive the insert before the delete
      if (node.getParent() != parent)
      {

      }

      // If node not in the tree, add it
      else if (node == null)
      {
         node = parent.createNode(r);
         node.setParent(parent);

         int[] newIndexs = new int[1];
         newIndexs[0] = event.getRowIndex();

         nodesWereInserted(parent, newIndexs);
      }
*/

      DebugDiagnostic.println("Row '" + r.getAttribute(0) + "' has been inserted.");
   }
}


