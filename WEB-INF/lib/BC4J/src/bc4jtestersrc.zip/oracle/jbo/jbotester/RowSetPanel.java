/*
 * @(#)RowSetPanel.java
 *
 * Copyright 1999-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.jbotester;

import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.MouseEvent;
import java.sql.Types;
import java.util.NoSuchElementException;
import javax.swing.BorderFactory;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;
import oracle.jbo.AttributeDef;
import oracle.jbo.AttributeHints;
import oracle.jbo.DeleteEvent;
import oracle.jbo.InsertEvent;
import oracle.jbo.LocaleContext;
import oracle.jbo.NavigationEvent;
import oracle.jbo.RangeRefreshEvent;
import oracle.jbo.Row;
import oracle.jbo.RowIterator;
import oracle.jbo.RowSetIterator;
import oracle.jbo.ScrollEvent;
import oracle.jbo.UpdateEvent;
import oracle.jbo.common.DebugDiagnostic;

public final class RowSetPanel extends JPanel implements JBOControl
{
   private RowSetIterator  iter;
   private JBOField        fields[];
   protected final MainFrame mainFrame;

   public RowSetPanel(MainFrame frame)
   {
      super(new GridBagLayout());

      mainFrame = frame;
   }

   public void setIterator(RowSetIterator iterator)
   {
      if (iter == iterator)
      {
         return;
      }

      if (iter != null)
      {
         iter.removeListener(this);
      }

      iter = iterator;
      if (iter == null)
      {
         return;
      }

      if (iter.getRowSet().getViewObject().isReadOnly())
      {
         DebugDiagnostic.println("RowSetPanel.setRowSet(): ***** RS is Read Only! *****");
      }

      iter.addListener(this);

      AttributeDef[] attrDefs = JboTesterUtil.getDisplayableAttributes(iter.getRowSet());
      DebugDiagnostic.println("Number of attribs :" + attrDefs.length);

      fields = new JBOField[attrDefs.length];

      removeAll();

      int ypos=0;
      GridBagConstraints gbc = new GridBagConstraints();
      GridBagLayout gbl = (GridBagLayout) this.getLayout();

      setBorder(BorderFactory.createEmptyBorder(0, 0, 5, 0));

      gbc.insets = new Insets(5, 5, 0, 5);

      JComponent firstComponent = null;
      JComponent lastComponent = null;
      Font font = null;
      LocaleContext locale = iter.getRowSet().getApplicationModule().getSession().getLocaleContext();
      
      for (int i = 0; i < attrDefs.length; i++)
      {
         AttributeDef attrDef = attrDefs[i];
         AttributeHints hints = attrDef.getUIHelper();
             
         JLabel label = new JLabel(hints.getLabel(locale) + ":");
         label.setEnabled(attrDef.getUpdateableFlag() != AttributeDef.READONLY);
         label.addMouseListener(new LabelMouseAdapter(attrDef));

         JComponent control;
         JBOField field;

         int height = hints.getDisplayHeight(locale);
         int width = ((hints.getDisplayWidth(locale) * 3) + 1) / 2;
         int controlType = hints.getControlType(locale);
         String tooltipText = hints.getTooltip(locale);

         if (width <=0)
         {
            width = 10;
         }

         // For very long field we use TextArea
         if (width > 50 && controlType == AttributeHints.CTLTYPE_DEFAULT && height == 1)
         {
            height = 3;
            width = 50;
         }

         if (height > 1)
         {
            RowsetTextArea textArea = new RowsetTextArea(attrDef, locale);
            ((JTextArea)textArea.getJComponent()).setColumns(width);
            ((JTextArea)textArea.getJComponent()).setRows(height);
            if (tooltipText != null)
            {
               textArea.getJComponent().setToolTipText(tooltipText);
            }

            if (font != null)
            {
               font = (new JTextField()).getFont();
            }

            ((JTextArea)textArea.getJComponent()).setFont(font);

            control = textArea.getScrollPane();
            field = textArea;
         }
         else
         {
            field = new RowsetTextField(width, attrDef, locale);
            control = field.getJComponent();
            font = ((JTextField)control).getFont();
            if (tooltipText != null)
            {
               control.setToolTipText(tooltipText);
            }
         }
         
         fields[i] = field;
         label.setLabelFor(field.getJComponent());

         if (firstComponent == null)
         {
            firstComponent = field.getJComponent();
         }
         lastComponent = field.getJComponent();

         gbc.fill = GridBagConstraints.NONE;
         gbc.anchor = GridBagConstraints.EAST;
         gbc.gridx = 0;
         gbc.gridy = ypos;
         gbc.gridwidth = 1;
         gbc.weightx = 0.0;
//         gbc.weighty = 0.0;
         gbl.setConstraints(label, gbc);
         add(label);

         if (attrDef.getSQLType() == Types.STRUCT)
         {
            gbc.fill = GridBagConstraints.HORIZONTAL;
            gbc.gridwidth = GridBagConstraints.REMAINDER;
         }
         else
         {
            gbc.fill = GridBagConstraints.NONE;
            gbc.gridwidth = GridBagConstraints.RELATIVE;
         }
         gbc.anchor = GridBagConstraints.WEST;
         gbc.gridx = GridBagConstraints.RELATIVE;
         gbc.gridy = ypos++;
         gbc.weightx = 0.0;
//         gbc.weighty = 1.0;
         gbl.setConstraints(control, gbc);
         add(control);
      }

      // Circle the focus loop
/*      if (firstComponent != null && firstComponent != lastComponent)
      {
         lastComponent.setNextFocusableComponent(firstComponent);
      }
*/
      refreshAll(iter.getCurrentRow());
   }

   public RowSetIterator getIterator()
   {
      return iter;
   }

   // RowsetListener
   public void rangeRefreshed(RangeRefreshEvent event)
   {
      if (event.getRowCountInRange() == 0)
      {
         RowIterator rsi = (RowIterator) event.getSource();
         // Propagate empty detail to nested details Bug 1782878
         if (rsi.getCurrentRowSlot() == RowIterator.SLOT_BEFORE_FIRST)
         {
            rsi.first();
         }
         refreshAll(rsi.getCurrentRow());
      }
   }

   public void rangeScrolled(ScrollEvent event)
   {
   }

   public void rowUpdated(UpdateEvent event)
   {
      if (fields == null)
      {
         return;
      }

      if (event.getRow() == ((RowIterator) event.getSource()).getCurrentRow())
      {
         int[] attrIndexes = event.getChangedAttrIndices();

         if (attrIndexes == null)
         {
            refreshAll(event.getRow());
         }
         else
         {
            // Since the set of displayable attribute might be different
            // than the set of attributes in the row, need to map...
            for (int i = 0; i < attrIndexes.length; i++)
            {
               for (int j = 0; j < fields.length; j++)
               {
                  JBOField f = fields[j];
                  if (f.getAttributeDef().getIndex() == attrIndexes[i])
                  {
                     f.setRow(event.getRow());
                     break;
                  }
               }
            }
         }
      }
   }

   public void navigated(NavigationEvent event)
   {
      refreshAll(event.getRow());
   }

   public void rowDeleted(DeleteEvent event)
   {
      SwingUtilities.invokeLater(new Runnable()
      {
         public void run()
         {
            try
            {
               // Move the currency on next available row.
               // Need to check it the currency has not been move already by an other view
               // on the same iterator...(Master view, Master+Detail view)
               if (iter.getCurrentRowSlot() == RowIterator.SLOT_DELETED)
               {
                  if (iter.hasNext())
                  {
                     iter.next();
                  }
                  else if (iter.hasPrevious())
                  {
                     iter.previous();
                  }
                  else
                  {
                     refreshAll(null);
                  }
               }
            }
            catch (Exception e)
            {
               ErrorHandler.displayError(mainFrame, e);
            }
         }
      });
   }

   public void rowInserted(InsertEvent event)
   {
   }

   public void refreshAll(Row row)
   {
      if (fields == null)
      {
         return;
      }

      try
      {
         for (int i = 0; i < fields.length; i++)
         {
            fields[i].setRow(row);
         }
      }
      catch(NoSuchElementException ex)
      {

      }
      catch(Exception e)
      {
         ErrorHandler.displayError(mainFrame, e);
      }
   }

   final class LabelMouseAdapter extends JBOControlMouseAdapter
   {
      private AttributeDef attrDef;
      private AttDefDialog mDlg;

      LabelMouseAdapter(AttributeDef attDef)
      {
         super(mainFrame);

         this.attrDef = attDef;
      }

      public AttributeDef getAttributeDef(MouseEvent e)
      {
         return attrDef;
      }

      public AttDefDialog getAttrDefDialog(AttributeDef attrDef, MainFrame parentFrame)
      {
         if (mDlg == null)
         {
            mDlg = new AttDefDialog(attrDef, parentFrame);
         }

         return mDlg;
      }
   }
}



