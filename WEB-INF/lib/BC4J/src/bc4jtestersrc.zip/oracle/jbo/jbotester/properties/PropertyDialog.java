/*
 * @(#)PropertyDialog.java
 *
 * Copyright 2000-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.jbotester.properties;

import javax.swing.JFrame;
import oracle.jbo.jbotester.GenericDialog;

public final class PropertyDialog extends GenericDialog
{
   PropertyPanel mainPanel;

   public PropertyDialog(JFrame frame, String title, PropertyPanel panel)
   {
      super(frame, title, panel, GenericDialog.CLOSE_HELP_OPTION);
      this.mainPanel = panel;
   }

   public void close()
   {
      mainPanel.close();
      super.close();
   }
}
