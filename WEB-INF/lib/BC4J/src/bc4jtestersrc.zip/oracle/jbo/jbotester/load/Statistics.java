/*
 * @(#)ApplicationPoolImpl.java
 *
 * Copyright 2000-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.jbotester.load;

/**
 *  A structure for ResourcePool statistics.
 */
public class Statistics implements Cloneable
{
   public float mNumOfIterations = 0;
   public float mAvgResponseTime = 0;
   public float mMaxResponseTime = 0;
   public float mMinResponseTime = 0;
   public float mNumOfSessions = 0;

   public Object clone()
   {
      Object clone = null;
      try
      {
         clone = super.clone();
      }
      catch (CloneNotSupportedException e)
      {
         e.printStackTrace();
      }

      return clone;
   }
}
