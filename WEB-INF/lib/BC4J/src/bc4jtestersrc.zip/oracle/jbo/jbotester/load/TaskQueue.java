package oracle.jbo.jbotester.load;

import java.util.LinkedList;

public class TaskQueue 
{
   private Object mLock = new Object();
   private LinkedList mList = new LinkedList();

   private int mWaiters = 0;
   private boolean mIsClosing = false;

   int enqueue(Task task)
   {
      synchronized(mLock)
      {
         mList.addLast(task);

         if (mWaiters > 0)
         {
            mLock.notify();
         }
         return mWaiters;
      }
   }

   Task dequeue()
   {
      synchronized(mLock)
      {
         if (mList.isEmpty())
         {
            mWaiters++;
            while(!mIsClosing && mList.isEmpty())
            {
               try
               {
                  mLock.wait(100);
               }
               catch (java.lang.InterruptedException e)
               {
               }
            }
            --mWaiters;
         }

         Task task = null;
         if (!mIsClosing)
         {
            task = (Task)mList.removeFirst();
         }
         return task;
      }
   }

   boolean isEmpty()
   {
      synchronized(mLock)
      {
         return mList.isEmpty();
      }
   }

   void close()
   {
      synchronized(mLock)
      {
         mIsClosing = true;
         clear();
      }
   }

   boolean isClosing()
   {
      synchronized(mLock)
      {
         return mIsClosing;
      }
   }

   void open()
   {
      synchronized(mLock)
      {
         mIsClosing = false;
      }
      
   }

   void clear()
   {
      synchronized(mLock)
      {
         mList.clear();
      }
   }
}