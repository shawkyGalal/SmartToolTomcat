/*
 * @(#)JBOTreeNode.java
 *
 * Copyright 1999-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.jbotester;

import com.sun.java.util.collections.HashMap;
import java.util.Enumeration;
import java.util.NoSuchElementException;
import javax.swing.tree.MutableTreeNode;
import javax.swing.tree.TreeNode;
import oracle.jbo.Key;
import oracle.jbo.Row;
import oracle.jbo.RowSet;
import oracle.jbo.common.DebugDiagnostic;

/**
 * Use the RowSet storage to implement the MutableTreeNode
 *
 */
public class JBOTreeNode implements MutableTreeNode
{
    /**
     * An enumeration that is always empty. This is used when an enumeration
     * of a leaf node's children is requested.
     */
   static public final Enumeration EMPTY_ENUMERATION = new Enumeration()
   {
	   public boolean hasMoreElements() { return false; }
	   public Object nextElement()
      {
		   throw new NoSuchElementException(Res.getString(Res.NO_MORE_ELEMENT_ERROR));
	   }
   };

   /** this node's parent, or null if this node has no parent */
   private   MutableTreeNode  parent;
   private   Row              row;
   transient protected Object userObject;
   protected RowSet           children;
   protected HashMap          allNodes;
   protected String           accessor;

   JBOTreeNode(HashMap nodes, Row row, String attrName)
   {
   	this.parent = null;
   	this.userObject = null;
      this.row = row;
      this.allNodes = nodes;
      this.accessor = attrName;

      if (row != null)
      {
         allNodes.put(row.getKey(), this);
      }
   }

   //
   // Methods to satisfy the TreeNode interface
   //

   // Returns an enumeration of the children
   public Enumeration children()
   {
      if (children == null)
      {
         return EMPTY_ENUMERATION;
      }
      else
      {
         return new Enumeration()
         {
            Enumeration enum = children.enumerateRowsInRange();

	         public boolean hasMoreElements()
            {
               return enum.hasMoreElements();
            }

	         public Object nextElement()
            {
               synchronized (JBOTreeNode.this)
               {
                  return getNode((Row) enum.nextElement());
               }
	         }
         };
      }
   }

   // Returns true if the receiver allows children.
   public boolean getAllowsChildren()
   {
      return (row != null && row.getAttribute(accessor) != null);
   }

   // Returns the child TreeNode at index.
   public TreeNode getChildAt(int index)
   {
      if (children == null)
      {
         throw new ArrayIndexOutOfBoundsException(Res.getString(Res.NODE_HAS_NO_CHILDREN_ERROR));
      }

      return (JBOTreeNode) getNode((Row) children.getRowAtRangeIndex(index));
   }

   // Returns the number of children.
   public int getChildCount()
   {
      if (children == null)
      {
         return 0;
      }
      else
      {
         return children.getRowCountInRange();
      }
   }

   // Returns the index of node.
   public int getIndex(TreeNode node)
   {
      return children.getRangeIndexOf(((JBOTreeNode) node).getRow());
   }

   // Returns the parent TreeNode of the receiver.
   public TreeNode getParent()
   {
      return parent;
   }

   public boolean isLeaf()
   {
      return (getChildCount() == 0);
   }

   // Methods to satisfy MutableTreeNode interface

   // Adds child to the receiver at index.
   public void insert(MutableTreeNode newChild, int index)
   {
      if (newChild == null)
      {
         throw new IllegalArgumentException(Res.getString(Res.NODE_NULL_CHILD));
      }
      else if (isNodeAncestor(newChild))
      {
         throw new IllegalArgumentException(Res.getString(Res.NODE_CHILD_IS_ANCESTOR));
      }

      MutableTreeNode oldParent = (MutableTreeNode) newChild.getParent();

      if (oldParent != null)
      {
         oldParent.remove(newChild);
      }

      newChild.setParent(this);

      if (children == null)
      {
         // $$$ what to do here
      }
      children.insertRowAtRangeIndex(index, ((JBOTreeNode) newChild).getRow());
   }

   // Removes the child at index from the receiver.
   public void remove(int childIndex)
   {
      JBOTreeNode child = (JBOTreeNode) getChildAt(childIndex);

      // Remove the node from the local HashMap first
      removeNode(child.getRow());

      child.getRow().remove();
      child.setParent(null);
   }

   // Removes node from the receiver.
   public void remove(MutableTreeNode aChild)
   {
      if (aChild == null)
      {
         throw new IllegalArgumentException(Res.getString(Res.NULL_ARGUMENT_ERROR));
      }

      if (!isNodeChild(aChild))
      {
         throw new IllegalArgumentException(Res.getString(Res.NODE_ARGUMENT_NOT_CHILD_ERROR));
      }

      remove(getIndex(aChild));
   }

   // Removes the receiver from its parent.
   public void removeFromParent()
   {
      MutableTreeNode parent = (MutableTreeNode) getParent();
      if (parent != null)
      {
         parent.remove(this);
      }
   }

   // Sets the parent of the receiver to newParent.
   public void setParent(MutableTreeNode newParent)
   {
      parent = newParent;
   }

   public Object getUserObject()
   {
      return userObject;
   }

   final public Row getRow()
   {
      return row;
   }

   final public void setRow(Row r)
   {
      row = r;
   }

   public JBOTreeNode getNode(Row row)
   {
      return (JBOTreeNode) allNodes.get(row.getKey());
   }

   public void removeNode(Row row)
   {
      allNodes.remove(row.getKey());
   }

   // Resets the user object of the receiver to object
   public void setUserObject(Object usrObj)
   {
      userObject = usrObj;
   }

   public RowSet getChildren()
   {
      return children;
   }

   public void setChildren(RowSet newChildren)
   {
      if (children == null)
      {
         children = newChildren;
         children.setRangeSize(-1);
      }
      else
      {
         DebugDiagnostic.println("Trying to overwrite children");
      }
   }

   final public boolean isNodeAncestor(TreeNode anotherNode)
   {
      if (anotherNode == null)
      {
         return false;
      }

      TreeNode ancestor = this;

      do
      {
         if (ancestor == anotherNode)
         {
            return true;
         }
      }
      while ((ancestor = ancestor.getParent()) != null);

      return false;
   }

   final public boolean isNodeChild(TreeNode aNode)
   {
	   boolean retval;

      if (aNode == null)
      {
	      retval = false;
	   }
      else
      {
	      if (getChildCount() == 0)
         {
		      retval = false;
	      }
         else
         {
		      retval = (aNode.getParent() == this);
	      }
	   }

      return retval;
   }

   /**
     * Text that gets displayed in item of tree control
     */
   public String toString()
   {
      if (row == null)
      {
	      return null;
	   }
      else
      {
         Key key = row.getKey();

         StringBuffer buf = new StringBuffer();
         Object value;

         buf.append(accessor);
         buf.append(" [");

         for ( int i = 0; i < key.getAttributeCount(); i++ )
         {
            value = key.getAttribute(i);
            buf.append((value == null) ? "null" : value.toString())
               .append(' ');
         }
         buf.append("]");

         return buf.toString();
      }
   }

   public boolean expand()
   {
      if (getChildren() == null)
      {
         setChildren((RowSet) row.getAttribute(accessor));

         Row[] rows = getChildren().getAllRowsInRange();

         if (rows != null && rows.length > 0)
         {
            for (int i=0; i < rows.length; i++)
            {
               JBOTreeNode newNode = new JBOTreeNode(allNodes, rows[i], accessor);
               newNode.setParent(this);
            }
         }

         return true;
      }
      else
      {
         return false;
      }
   }
}
