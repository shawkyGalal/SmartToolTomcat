package oracle.jbo.jbotester.load;

import oracle.jbo.pool.ResourcePool;

public class TaskThreadPool extends ResourcePool
{
   private TaskQueue mQueue = new TaskQueue();
   private int mNumOfCompletedThreads = 0;
   
   public TaskThreadPool()
   {
      initialize(null);
   }

   public Object instantiateResource(java.util.Properties props)
   {
      return new TaskThread(mQueue);
   }

   public void execute(Task task)
   {
      if (mQueue.isClosing()) return;
      
      int numOfWaiters = mQueue.enqueue(task);

      // if no one is waiting then everyone must be busy.  Go ahead and create
      // someone to handle the task.
      if (numOfWaiters == 0)
      {
         TaskThread taskThread = (TaskThread)useResource(null);
         taskThread.start();
      }
   }

   void close()
   {
      mQueue.close();

      synchronized(mLock)
      {
         while (mNumOfCompletedThreads < getResourceCount())
         {
            try
            {
               mLock.wait(100);
            }
            catch (java.lang.InterruptedException e)
            {
            }
         }
      }

      removeResources();
   }

   void notifyThreadCompleted()
   {
      synchronized(mLock)
      {
         mNumOfCompletedThreads++;
         mLock.notify();
      }
   }

   void open()
   {
      mQueue.open();
   }
}
