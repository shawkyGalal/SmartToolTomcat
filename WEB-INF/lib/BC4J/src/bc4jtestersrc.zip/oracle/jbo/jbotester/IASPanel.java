/*
 * @(#)IASPanel.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.jbotester;

import java.awt.Frame;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.CardLayout;
import java.awt.Insets;
import java.io.File;
import java.io.IOException;
import java.util.Hashtable;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JPanel;
import oracle.jbo.client.Configuration;
import oracle.jbo.common.PropertyMetadata;
import oracle.jdeveloper.cm.ConnectionDescriptor;
import oracle.jdeveloper.cm.ConnectionManager;

public final class IASPanel extends PlatformPanel
{
   private boolean mIsEmbeddedConfig = false;
   private final JTextField applicationNameField = new JTextField();
   private final JComboBox appServerConnectionCombo = new JComboBox();
   private final JTextField appServerHostField = new JTextField();

   private static final String EMBEDDED_LAYOUT_INDEX = "Embedded";
   private static final String UNEMBEDDED_LAYOUT_INDEX = "Unembedded";
   private CardLayout mAppServerConnLayout = new CardLayout();
   private JPanel mAppServerConnPanel;

   public IASPanel(Frame parentFrame)
   {
      super(new GridBagLayout());

      parent = parentFrame;

      JLabel appServerLabel = JboTesterUtil.createLabel(Res.APPSERVER_CONN_LABEL, appServerConnectionCombo);
      JLabel appNameLabel  = JboTesterUtil.createLabel(Res.APPSERVER_APPLICATION_NAME, applicationNameField);

      GridBagLayout gbl          = (GridBagLayout) getLayout();
      GridBagConstraints gbc     = new GridBagConstraints();

      gbc.fill = GridBagConstraints.HORIZONTAL;

      gbc.gridx = 0;
      gbc.gridy = 0;
      gbc.gridwidth = 1;
      gbc.weightx = 0.0;
      gbc.weighty = 0.0;
      gbc.insets = new Insets(0, 10, 10, 0);
      gbc.anchor = GridBagConstraints.EAST;
      gbl.setConstraints(appServerLabel, gbc);
      add(appServerLabel);

      appServerHostField.setEditable(false);
      mAppServerConnPanel = new JPanel(mAppServerConnLayout);
      mAppServerConnPanel.add(appServerHostField, EMBEDDED_LAYOUT_INDEX);
      mAppServerConnPanel.add(appServerConnectionCombo, UNEMBEDDED_LAYOUT_INDEX);
      
      gbc.anchor = GridBagConstraints.WEST;
      gbc.gridx = 1;
      gbc.gridy = 0;
      gbc.gridwidth = GridBagConstraints.REMAINDER;
      gbc.weightx = 1.0;
      gbl.setConstraints(mAppServerConnPanel, gbc);
      add(mAppServerConnPanel);

      gbc.anchor = GridBagConstraints.EAST;
      gbc.gridx = 0;
      gbc.gridy = 1;
      gbc.gridwidth = 1;
      gbc.weightx = 0.0;
      gbl.setConstraints(appNameLabel, gbc);
      add(appNameLabel);

      gbc.anchor = GridBagConstraints.WEST;
      gbc.gridx = 1;
      gbc.gridwidth = GridBagConstraints.REMAINDER;
      gbc.weightx = 1.0;
      gbl.setConstraints(applicationNameField, gbc);
      add(applicationNameField);

      JboTesterUtil.addSpacerPanel(this, 0, 2);

   }

   private void setEmbeddedConfig(boolean isEmbeddedConfig)
   {
      mIsEmbeddedConfig = isEmbeddedConfig;

      if (mIsEmbeddedConfig)
      {
         mAppServerConnLayout.show(mAppServerConnPanel, EMBEDDED_LAYOUT_INDEX);
         applicationNameField.setEditable(false);
      }
      else
      {
         mAppServerConnLayout.show(mAppServerConnPanel, UNEMBEDDED_LAYOUT_INDEX);
         applicationNameField.setEditable(true);
      }
   }
   

   // Initialize fields given the hashtable of values
   public void setParams(Hashtable params)
   {
      boolean isEmbeddedConfig = Configuration.isEmbeddedConfig(params);

      setEmbeddedConfig(isEmbeddedConfig);

      String appServerHostName = (String)params.get(PropertyMetadata.HOST_NAME.getName());
      appServerHostField.setText(appServerHostName);

      String appServerConnectionName = (String)params.get(Configuration.APPSERVER_CONNECTION_NAME);
      initAppServerConnectionCombo(appServerConnectionName);
      
      String value = (String) params.get(PropertyMetadata.APPLICATION_PATH.getName());
      if (value == null)
      {
         value = "";
      }
      applicationNameField.setText(value);
   }

   public boolean getParams(Hashtable params, boolean showError)
   {
      String applicationName = applicationNameField.getText();
      boolean isValid = false;

      isValid = false;
      if (applicationName != null)
      {
         applicationName = applicationName.trim();
         if (applicationName.length() > 0)
         {
            params.put(PropertyMetadata.APPLICATION_PATH.getName(), applicationName);
            isValid = true;
         }
      }
      if (!isValid)
      {
         if (showError)
         {
            ErrorHandler.displayError(parent, Res.getString(Res.APPLICATION_NAME_ERROR));
         }
         return false;
      }

      isValid = false;

      if (!mIsEmbeddedConfig)
      {
         String appServerConnectionName = (String)appServerConnectionCombo.getSelectedItem();
         if (appServerConnectionName != null)
         {
            appServerConnectionName = appServerConnectionName.trim();
            if (appServerConnectionName.length() > 0)
            {
               params.put(Configuration.APPSERVER_CONNECTION_NAME, appServerConnectionName);
               isValid = true;
            }
         }

         if (!isValid)
         {
            if (showError)
            {
               ErrorHandler.displayError(parent, Res.getString(Res.APPSERVER_CONNECTION_ERROR));
            }
            return false;
         }
      }

      addEjbClientJars(params, showError);
      return true;
   }

   private void initAppServerConnectionCombo(String connectionName)
   {
      try
      {
         ConnectionManager cm = ConnectionManager.getInstance();
         String names[] = cm.getConnectionNames(ConnectionDescriptor.CONN_OC4J, true);
         DefaultComboBoxModel model = new DefaultComboBoxModel(names);

         int index = model.getIndexOf(connectionName);
         if (index < 0)
         {
            model.addElement(connectionName);
         }
         
         appServerConnectionCombo.setModel(model);
         if(connectionName != null)
         {
            model.setSelectedItem(connectionName);
         }
      }
      catch(IOException ex)
      {
         ErrorHandler.displayError(parent, ex);
      }
   }

   private void addEjbClientJars(Hashtable params, boolean showErrors)
   {
      if (!mIsEmbeddedConfig)
      {
         String connectionName = (String)appServerConnectionCombo.getSelectedItem();
         if(connectionName != null)
         {
            try
            {
               ConnectionManager cm = ConnectionManager.getInstance();
               ConnectionDescriptor cd = cm.getConnectionDescriptor(connectionName);
               String homeDir = cd.getProperty(ConnectionDescriptor.OC4J_HOME);
               if(homeDir != null)
               {
                  params.put(JboTesterUtil.EJB_CLIENT_JARS,
                             homeDir + File.separator + 
                             Res.getString(Res.IAS_JAR));
               }
            }
            catch(Exception ex)
            {
               if(showErrors)
               {
                  ErrorHandler.displayError(parent, ex);
               }
            }
         }
      }
   }

}
