package oracle.jbo.jbotester.load;

public class StateChangedEvent 
{
   private final Object mSource;
   private int mOldState = -1;
   private int mNewState = -1;

   private long mStateChangeInterval = 0;
   
   public StateChangedEvent(Object source, int oldState, int newState)
   {
      mSource = source;
      mOldState = oldState;
      mNewState = newState;
   }

   public Object getSource()
   {
      return mSource;
   }

   public int getOldState()
   {
      return mOldState;
   }

   public int getNewState()
   {
      return mNewState;
   }

   public void setStateChangeInterval(long stateChangeInterval)
   {
      mStateChangeInterval = stateChangeInterval;
   }

   public long getStateChangeInterval()
   {
      return mStateChangeInterval;
   }
   
}