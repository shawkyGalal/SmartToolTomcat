package oracle.jbo.jbotester.load;

public interface StateChangeListener 
{
   public void stateChanged(StateChangedEvent event);
}