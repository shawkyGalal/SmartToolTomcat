/*
 * @(#)JBOTableModel.java
 *
 * Copyright 1999-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.jbotester;

import com.sun.java.util.collections.HashMap;
import java.awt.Component;
import java.awt.event.MouseEvent;
import javax.swing.BoundedRangeModel;
import javax.swing.DefaultCellEditor;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.SwingConstants;
import javax.swing.SwingUtilities;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.AbstractTableModel;
import oracle.jbo.AttributeDef;
import oracle.jbo.DeleteEvent;
import oracle.jbo.InsertEvent;
import oracle.jbo.NavigationEvent;
import oracle.jbo.RangeRefreshEvent;
import oracle.jbo.Row;
import oracle.jbo.RowIterator;
import oracle.jbo.RowSetIterator;
import oracle.jbo.ScrollEvent;
import oracle.jbo.UpdateEvent;

import oracle.jbo.LocaleContext;
import oracle.jbo.common.DebugDiagnostic;
import oracle.jbo.common.Diagnostic;
import oracle.jbo.ViewObject;

final class JBOTableModel extends AbstractTableModel
                          implements JBOControl, ListSelectionListener, ChangeListener
{
   private RowSetIterator     iter;
   private final JTable       table;
   private final JScrollPane  scrollPane;
   private Row                view[];
   private AttributeDef       attrDefs[];
   private LocaleContext      locale;

   private int                scrollUnit;
   private int                rowCount;
   private int                oldSBvalue;
   private boolean            fromStateChange;
   private boolean            selInProg = false;
   private final MainFrame    mainFrame;

   JBOTableModel(MainFrame parentFrame, JTable tbl, JScrollPane scrlPane, RowSetIterator iterator)
   {
      table = tbl;
      scrollPane = scrlPane;
      mainFrame = parentFrame;
      setIterator(iterator);

      table.addMouseListener(new TableMouseAdapter());

      
      
      table.setModel(this);

      //KM: 02Jun03 bug2738512 DATE NOT EDITABLE WHEN TYPE MAP SET TO JAVA AND SQL FLAVOR IS SQL92
      // Lets face it JTable is a bit hokey - it provides a custom renderer
      // for java.util.Date, but no edit support! It also makes a couple
      // of format choices for Numbers.
      
      // Lets have these dates display just by using their toString() method      
      table.setDefaultRenderer(java.util.Date.class, new javax.swing.table.DefaultTableCellRenderer());
      
      // and lets just have numbers displayed as left justified
      table.setDefaultRenderer(java.lang.Number.class, new javax.swing.table.DefaultTableCellRenderer());
      
      // Now, let us edit dates using the default editor
      table.setDefaultEditor(java.util.Date.class, new javax.swing.DefaultCellEditor(new JTextField()));
      
      ListSelectionModel selectModel = table.getSelectionModel();
      selectModel.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
      selectModel.addListSelectionListener(this);

      scrollPane.getViewport().addChangeListener(this);

//      scrollPane.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);

      scrollPane.getVerticalScrollBar().getModel().addChangeListener(new sbListener());

      // visibleRect (param1) and amount (param 2) are not used.
      scrollUnit = table.getScrollableUnitIncrement(null, SwingConstants.VERTICAL, 0);

      // Force redraw the first time
      stateChanged(null);
   }

   //
   // JBOcontrol interface
   //
   public RowSetIterator getIterator()
   {
      return iter;
   }

   public synchronized void setIterator(RowSetIterator iterator)
   {
      if (iter == iterator)
      {
         return;
      }

      if (iter != null)
      {
         iter.removeListener(this);
      }

      iter = iterator;
      if (iter != null)
      {
         locale = iter.getRowSet().getApplicationModule().getSession().getLocaleContext();
         iter.addListener(this);
         attrDefs = JboTesterUtil.getDisplayableAttributes(iter.getRowSet());
      }
      else
      {
         attrDefs = null;
         locale = null;
      }
   }

   public int getColumnCount()
   {
      if (attrDefs == null)
      {
         return 0;
      }
      return attrDefs.length;
   }

   public int getRowCount()
   {
      return rowCount;
   }

   public String getColumnName(int columnIndex)
   {
       return attrDefs[columnIndex].getUIHelper().getLabel(locale);
   }

   public Class getColumnClass(int columnIndex)
   {
       // if we have formatting, treat it as text
       if(attrDefs[columnIndex].getUIHelper().hasFormatInformation(locale))
           return java.lang.String.class;
       
       return attrDefs[columnIndex].getJavaType();
   }

   public Object getValueAt(int row, int columnIndex)
   {
      int rangeRow = row - iter.getRangeStart();

      if (rangeRow >= 0 && rangeRow < view.length)
      {
          try
          {
             return JboTesterUtil.getData(view[rangeRow], attrDefs[columnIndex], locale);
          }
          catch (Exception e)
          {
             ErrorHandler.displayError(mainFrame, e, (ViewObject) iter);
             return null;
          }
      }
      else
      {
         DebugDiagnostic.println("Out of range: " + row);
         return null;
      }
   }

   public boolean isCellEditable(int row, int columnIndex)
   {
      int rangeRow = row - iter.getRangeStart();

      if (rangeRow >= 0 && rangeRow < view.length)
      {
         return view[rangeRow].isAttributeUpdateable(attrDefs[columnIndex].getIndex());
      }
      else
      {
         return false;
      }
   }

   public void setValueAt(Object value, int rowIndex, int columnIndex)
   {
      try
      {
         int index    = attrDefs[columnIndex].getIndex();
         int rangeRow = rowIndex - iter.getRangeStart();

         if (rangeRow >= 0 && rangeRow < view.length)
         {
            Row row  = view[rangeRow];

            Object oldValue = row.getAttribute(index);
            String strValue = (value == null) ? "" : value.toString();

            if (oldValue == null)
            {
               if (strValue.length() == 0)
               {
                  return;
               }
            }
            else
            {
               if (oldValue.toString().equals(strValue))
               {
                  return;
               }
            }

            JboTesterUtil.setData(row, attrDefs[columnIndex], locale, value);
         }
      }
      catch (Exception e)
      {
         ErrorHandler.displayError(mainFrame, e, (ViewObject) iter);
         SwingUtilities.invokeLater(new DelayedEditCell(value, rowIndex, columnIndex));
      }
   }

   //
   // RowSet listener
   //
   public void rangeRefreshed(RangeRefreshEvent event)
   {
      Diagnostic.println("JBOTableModel: Recvd Event=" + event);
      int newSize = event.getRowCountInRange();

      if (view != null)
      {
         int oldSize = view.length;

         // Notify the grid of any changes in size
         if (oldSize > newSize)
         {
            fireTableRowsDeleted(oldSize, newSize - 1);
         }
         else if (oldSize < newSize)
         {
            fireTableRowsInserted(oldSize, newSize - 1);
         }
      }

      view = event.getAllRowsInRange();
      scrollPane.getVerticalScrollBar().setValue(0);
      rowCount = (int) iter.getRowSet().getEstimatedRowCount();

      refresh();
   }

   public void rangeScrolled(ScrollEvent event)
   {
      view = iter.getAllRowsInRange();

      if (!fromStateChange)
      {
         scrollPane.getVerticalScrollBar().setValue(iter.getRangeStart() * scrollUnit);

         SwingUtilities.invokeLater(new Runnable()
         {
            public void run()
            {
               fireTableDataChanged();
            }
         });
      }
   }

   public void navigated(NavigationEvent event)
   {
      if (table.isEditing())
      {
         table.removeEditor();
      }

      DebugDiagnostic.println("Navigated to " + event.getRowIndex());
      // This is to go through the case the navigation event arrive first.
      // Since we are navigating there is at least one row.
      if (rowCount == 0)
      {
         rowCount++;
      }
      selectRangeRow(event.getRowIndex());
   }

   public void rowDeleted(DeleteEvent event)
   {
      if (table.isEditing())
      {
         table.getCellEditor().stopCellEditing();
      }

      view = iter.getAllRowsInRange();

      SwingUtilities.invokeLater(new Runnable()
      {
         public void run()
         {
            try
            {
               // Move the currency on next available row.
               // Need to check it the currency has not been move already by an other view
               // on the same iterator...(Master view, Master+Detail view)
               if (iter.getCurrentRowSlot() == RowIterator.SLOT_DELETED)
               {
                  if (iter.hasNext())
                  {
                     iter.next();
                  }
                  else
                  {
                     iter.previous();
                  }
               }
            }
            catch (Exception e)
            {
               ErrorHandler.displayError(mainFrame, e);
            }
         }
      });

      // sim 4/10/02 -- No need to handle selInProg here because
      //                we do it in refresh().
      refresh();
   }

   public void rowInserted(InsertEvent event)
   {
      RowSetIterator rsi = (RowSetIterator) event.getSource();

      if (table.isEditing())
      {
         table.getCellEditor().stopCellEditing();
      }
      view = rsi.getAllRowsInRange();

      // sim 4/10/02 -- No need to handle selInProg here because
      //                we do it in refresh().
      refresh();
   }

   public void rowUpdated(UpdateEvent event)
   {
      Row row = event.getRow();
      int rowIndex = event.getRowIndex();
      int tableRow = rowIndex + iter.getRangeStart();

      view[rowIndex] = row;

      int[] attrIndexes = event.getChangedAttrIndices();

      if (attrIndexes == null)
      {
         fireTableRowsUpdated(tableRow, tableRow);
      }
      else
      {
         // Since the set of displayable attribute might be different
         // than the set of attributes in the row, need to map...
         for (int i = 0; i < attrIndexes.length; i++)
         {
            for (int j = 0; j < attrDefs.length; j++)
            {
               if (attrDefs[j].getIndex() == attrIndexes[i])
               {
                  fireTableCellUpdated(tableRow, j);
                  break;
               }
            }
         }
      }
   }

   private void refresh()
   {
      // This is the expensive way where we refresh the entire viewPort
      fireTableDataChanged();

      // Get the rowcount again because of deleted or inserted row
      rowCount = (int) iter.getRowSet().getEstimatedRowCount();

      selInProg = true;

      try
      {
         selectRangeRow(iter.getCurrentRowIndex());
      }
      finally
      {
         selInProg = false;
      }
   }

   private void selectRangeRow(int rangeRow)
   {
      int tableRow;

      if (rangeRow >= 0 && (tableRow = rangeRow + iter.getRangeStart()) < rowCount) // -1 if null or out of range
      {
         DebugDiagnostic.println("Selecting " + tableRow);
         table.setRowSelectionInterval(tableRow, tableRow);
      }
      else
      {
         table.clearSelection();
      }
   }

   //
   // ListSelectionListener
   //
   public void valueChanged(ListSelectionEvent e)
   {
      ListSelectionModel lsm = (ListSelectionModel) e.getSource();

      // Don't care about unfinished business
      if (selInProg || lsm.getValueIsAdjusting())
      {
         return;
      }

      if (lsm.isSelectionEmpty())
      {
         DebugDiagnostic.println("No Rows are selected");
      }
      else
      {
         int selectRow = lsm.getMinSelectionIndex();

         DebugDiagnostic.println("List selecting " + selectRow);
         
         try
         {
            iter.setCurrentRowAtRangeIndex(selectRow - iter.getRangeStart());
         }
         catch (Exception ex)
         {
            ErrorHandler.displayError(mainFrame, ex);
         }
      }
   }

   // ScroolPane ViewPort ChangeListener
   public void stateChanged(ChangeEvent event)
   {
      int height = scrollPane.getViewport().getHeight();

      int rowHeight = table.getRowHeight() + table.getIntercellSpacing().height;

      int n = (height / rowHeight) + 1;
      if (n != iter.getRangeSize())
      {
         DebugDiagnostic.println("New range size = " + n);
         iter.setRangeSize(n);
         view = iter.getAllRowsInRange();
         refresh();
      }
   }

   final class sbListener implements ChangeListener
   {
      public void stateChanged(ChangeEvent event)
      {
         BoundedRangeModel model = (BoundedRangeModel) event.getSource();
         int               value = model.getValue();
         int               delta = value - oldSBvalue;
         int               extent = model.getExtent();

         if (delta == 0)
         {
            return;
         }

         DebugDiagnostic.println("Scroll bar value changed = " + value + " delta= " + delta);

         int start = iter.getRangeStart();
         int size = iter.getRangeSize();
         int scrlAmount;

         if (delta > 0)
         {
            scrlAmount = value + extent - ((start + size) * scrollUnit);

            if (scrlAmount > 0)
            {
               scrlAmount = (scrlAmount / scrollUnit) + 1;

               DebugDiagnostic.println("Scroll amount = " + scrlAmount);

               fromStateChange = true;
               iter.scrollRange(scrlAmount);
               fromStateChange = false;
            }
         }
         else
         {
            scrlAmount = value - (start * scrollUnit);
            if (scrlAmount < 0)
            {
               scrlAmount = (scrlAmount / scrollUnit) - 1;

               DebugDiagnostic.println("Scroll amount = " + scrlAmount);

               fromStateChange = true;
               iter.scrollRange(scrlAmount);
               fromStateChange = false;
            }
         }

         oldSBvalue = value;
      }
   }

   final class TableMouseAdapter extends JBOControlMouseAdapter
   {
      private HashMap mDlgs;

      TableMouseAdapter()
      {
         super(mainFrame);

         mDlgs = new HashMap();
      }

      public AttributeDef getAttributeDef(MouseEvent e)
      {
         return attrDefs[table.columnAtPoint(e.getPoint())];
      }

      public AttDefDialog getAttrDefDialog(AttributeDef attrDef, MainFrame parentFrame)
      {
         AttDefDialog dlg = (AttDefDialog) mDlgs.get(attrDef.getName());

         if (dlg == null)
         {
            dlg = new AttDefDialog(attrDef, parentFrame);
            mDlgs.put(attrDef.getName(), dlg);
         }

         return dlg;
      }
   }

   class DelayedEditCell implements Runnable
   {
      Object   invalidValue;
      int      row;
      int      col;

      public DelayedEditCell(Object value, int row, int col)
      {
         this.invalidValue = value;
         this.row = row;
         this.col = col;
      }

      public void run()
      {
         selInProg = true;

         try
         {
            table.setRowSelectionInterval(row, row);
         }
         finally
         {
            selInProg = false;
         }
         
         table.setColumnSelectionInterval(col, col);
         table.editCellAt(row, col);

         Component comp = ((DefaultCellEditor) table.getCellEditor()).getComponent();
         if (comp instanceof JTextField)
         {
            ((JTextField) comp).setText(invalidValue.toString());
         }

         comp.requestFocus();
      }
   }
}


