/*
 * @(#)ErrorHandler.java
 *
 * Copyright 1999-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.jbotester;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.awt.BorderLayout;
import java.awt.Cursor;
import java.awt.Frame;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import oracle.jbo.JboException;
import oracle.jbo.ViewObject;
import oracle.jbo.common.Diagnostic;


public final class ErrorHandler extends JDialog
{
   static private boolean isUp;

   private final JPanel bPanel = new JPanel();
   private final JButton okButton = new JButton(Res.getString(Res.DIALOG_OK_BUTTON));
   private final JButton detailsButton = new JButton(Res.getString(Res.ERROR_DIALOG_DETAIL));
   private final JTextArea mTextArea = new JTextArea(5, 80);
   private final JScrollPane scrollPane = new JScrollPane(mTextArea);
   private JboException jboex;
   private boolean mShowStackTraces;

   public ErrorHandler(Frame parent, String title, boolean modal)
   {
      super(parent, title, modal);
      try
      {
         jbInit();
         pack();
      }
      catch (Exception e)
      {
         Diagnostic.printStackTrace(e);
      }
   }

   private void jbInit() throws Exception
   {
//      scrollPane.setPreferredSize(new Dimension(600, 200));
      
      mTextArea.setRequestFocusEnabled(false);
      bPanel.add(okButton);
      bPanel.add(detailsButton);

      mTextArea.setNextFocusableComponent(okButton);
      mTextArea.setEnabled(true);

      mTextArea.setEditable(false);
      mTextArea.setWrapStyleWord(true);
      mTextArea.setLineWrap(true);
      mTextArea.setBackground(getBackground());

      okButton.addActionListener( new ActionListener()
      {
         public void actionPerformed(ActionEvent e)
         {
            setVisible(false);
            dispose();
         }
      });

      detailsButton.addActionListener( new ActionListener()
      {
         public void actionPerformed(ActionEvent e)
         {
            mShowStackTraces = true;
            mTextArea.setText(getErrorMessage());
            detailsButton.setEnabled(false);
         }
      });

      okButton.setDefaultCapable(true);
      getRootPane().setDefaultButton(okButton);

      getContentPane().add(scrollPane, BorderLayout.CENTER);
      getContentPane().add(bPanel, BorderLayout.SOUTH);
   }

   public ErrorHandler()
   {
      this(null, Res.format(Res.ERROR_DIALOG_TITLE, ""), false);
   }

   protected void formErrorMessage(int num, int lev, StringBuffer buff, Exception ex)
   {
      String indent = "";

      for (int j = 1; j < lev; j++)
      {
         indent += Res.getString(Res.STR_DETAIL_MSG_INDENT);
      }

      if (lev > 0)
      {
         buff.append(indent).append(Res.getString(Res.STR_DETAIL_MSG_SEPARATOR1)).append(Res.getString(Res.STR_DETAIL_MSG_LEVEL)).append(lev).
              append(Res.getString(Res.STR_DETAIL_MSG_HEADER)).append(num).append(Res.getString(Res.STR_DETAIL_MSG_SEPARATOR2)).append("\n");
      }
      
      if (mShowStackTraces)
      {
         StringWriter stkWriter = new StringWriter();

         ex.printStackTrace(new PrintWriter(stkWriter));

         stkWriter.flush();

         buff.append(indent).append(stkWriter.toString()).append("\n");
      }
      else
      {
         buff.append(indent).append("(").append(ex.getClass().getName()).
              append(") ").append(ex.getMessage()).append("\n");
      }
      
      if (ex instanceof JboException)
      {
         Object[] nextLevDetails = ((JboException) ex).getDetails();
   
         if (nextLevDetails != null)
         {
            for (int j = 0; j < nextLevDetails.length; j++)
            {
               formErrorMessage(j, lev + 1, buff, (Exception) nextLevDetails[j]);
            }
         }
      }
   }

   protected String getErrorMessage()
   {
      StringBuffer msgBuff = new StringBuffer();
      
      formErrorMessage(0, 0, msgBuff, jboex);

      return msgBuff.toString();
   }


   static public void displayError(Frame parent, String errorMessage)
   {
      isUp = true;
      parent.setCursor(Cursor.getPredefinedCursor(Cursor.DEFAULT_CURSOR));

      ErrorHandler ed = new ErrorHandler(parent, Res.format(Res.ERROR_DIALOG_TITLE, Res.getString(Res.ERROR_DIALOG_TITLE_ERROR)), true);

      ed.detailsButton.setEnabled(false);
      ed.mTextArea.setText(errorMessage);

      ed.setLocationRelativeTo(parent);
      ed.okButton.requestDefaultFocus();
      ed.setVisible(true);
      isUp = false;
   }

   static public void displayError(Frame parent, Throwable t)
   {
      displayError(parent, t, null);
   }
   
   static public void displayError(Frame parent, Throwable t, ViewObject vo)
   {
      isUp = true;
      parent.setCursor(Cursor.getPredefinedCursor(Cursor.DEFAULT_CURSOR));

      ErrorHandler ed = new ErrorHandler(parent, Res.format(Res.ERROR_DIALOG_TITLE, t.getClass().getName()), true);

      Diagnostic.printStackTrace(t);

      boolean enableDetail = false;
      if (t instanceof JboException)
      {
         ed.jboex = (JboException) t;

         if (vo != null)
         {
            ed.jboex.doEntityToVOMapping(vo.getApplicationModule(), new ViewObject[]{ vo });
         }
         
         enableDetail = true;
         ed.mTextArea.setText(ed.getErrorMessage());
      }
      else
      {
         ed.mTextArea.setText(t.getMessage());
      }

      ed.detailsButton.setEnabled(enableDetail);
      ed.setLocationRelativeTo(parent);
      ed.okButton.requestDefaultFocus();
      ed.setVisible(true);

      isUp = false;
   }

   static public boolean isUp()
   {
      return isUp;
   }
}


