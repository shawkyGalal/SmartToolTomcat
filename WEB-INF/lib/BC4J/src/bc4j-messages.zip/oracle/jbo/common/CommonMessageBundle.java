/*
 * @(#)CommonMessageBundle.java
 *
 * Copyright 2000-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.common;

import oracle.jbo.common.CheckedListResourceBundle;
import oracle.jbo.common.Diagnostic;
import oracle.jbo.common.PropertyConstants;

public class CommonMessageBundle
   extends CheckedListResourceBundle
{
   //
   // Ranges:
   //   STR_ 02300 - 02499
   //   MSG_ 12300 - 12499
   //   EXC_ 33000 - 33200
   //

   static
   {
      if (Diagnostic.isOn())
      {
         Diagnostic.println("CommonMessageBundle (language base) being initialized");
      }
   }

   public static final String STR_DEPLOY_PLATFORM                            = "02300";
   public static final String STR_CONNECTION_MODE                            = "02301";
   public static final String STR_HOST_NAME                                  = "02302";
   public static final String STR_CONNECTION_PORT                            = "02303";
   public static final String STR_APPLICATION_PATH                           = "02304";
   public static final String STR_ENV_USE_PERS_COLL                          = "02305";
   public static final String STR_ENV_PERS_MAX_ROWS_PER_NODE                 = "02306";
   public static final String STR_ENV_PERS_MAX_ACTIVE_NODES                  = "02307";
   public static final String STR_ENV_PCOLL_MGR                              = "02308";
   public static final String STR_STRINGMANAGER_FACTORY_CLASS                = "02309";
   public static final String STR_ENV_OBJ_MARSHALLER                         = "02310";
   public static final String STR_ENV_TXN_TABLE_NAME                         = "02311";
   public static final String STR_ENV_TXN_SEQ_NAME                           = "02312";
   public static final String STR_ENV_CONTROL_TABLE_NAME                     = "02313";
   
   public static final String STR_DYNAMIC_PACKAGE_NAME                       = "02320";
   public static final String STR_MOM_CONTEXT_FACTORY                        = "02321";
   public static final String STR_INITIAL_CONTEXT_FACTORY                    = "02322";
   public static final String STR_INITIAL_CONTEXT                            = "02323";
   public static final String STR_LOAD_COMP_LAZILY                           = "02324";
   public static final String STR_JBO_323_COMPATIBLE                         = "02325";
   public static final String STR_JBO_903_COMPATIBLE                         = "02326";
  
   public static final String STR_IS_LAZY_LOADING_TRUE                       = "02330";
   public static final String STR_PN_SQLBUILDERIMPL                          = "02331";
   public static final String STR_PN_SQLTYPEMAP                              = "02332";
   public static final String STR_PN_JDBC_DRIVER_CLASS                       = "02333";
   public static final String STR_PN_DBTIME_QUERY                            = "02334";
   public static final String STR_PN_SQL92_LOCKTRAILER                       = "02335";

   public static final String STR_ENV_DEFAULT_LANGUAGE                       = "02340";
   public static final String STR_ENV_DEFAULT_COUNTRY                        = "02341";
   public static final String STR_ENV_FETCH_MODE                             = "02342";
   public static final String STR_SHARED_DATA_HANDLE                         = "02343";
   public static final String STR_HANDLE_NAME                                = "02344";
   public static final String STR_GLOBAL_SUBSTITUTION                        = "02345";
   public static final String STR_JBO_PROJECT                                = "02346";
   public static final String STR_ENV_MAX_CURSORS                            = "02347";
   public static final String STR_ENV_DO_FAILOVER                            = "02348";
   public static final String STR_ENV_MAX_JDBC_POOL_SIZE                     = "02349";
   public static final String STR_ENV_INIT_JDBC_POOL_SIZE                    = "02350";
   public static final String STR_ENV_ENTITYROWSET_MODE                      = "02351";
   public static final String STR_PN_POOL_MANAGER                            = "02352";
   public static final String STR_PN_JBO_JDBC_TRACE                          = "02353";
   public static final String STR_USE_DEFINE_COLUMN_LENGTH                   = "02354";
   public static final String STR_TEMPORARY_FILES_HOME                       = "02355";
   public static final String STR_INTERNAL_CONNECTION_PARAMS                 = "02356";
   public static final String STR_PN_DEBUG_TYPE                              = "02357";
   public static final String STR_PN_DEBUG_PREFIX                            = "02358";
   public static final String STR_PN_SHOW_TIMING                             = "02359";
   public static final String STR_PN_SHOW_FUNCTION                           = "02360";
   public static final String STR_PN_SHOW_LEVEL                              = "02361";
   public static final String STR_PN_SHOW_LINECOUNT                          = "02362";
   public static final String STR_PN_TRACE_THRESHOLD                         = "02363";
   public static final String STR_PN_JDBC_DRIVER_VERBOSE                     = "02364";
   public static final String STR_AM_RELEASE_MODE                            = "02365";
   public static final String STR_SECURITY_PRINCIPAL                         = "02366";
   public static final String STR_SECURITY_CREDENTIALS                       = "02367";
   public static final String STR_ENV_POOL_RECYCLE_THRESHOLD                 = "02368";
   public static final String STR_ENV_EJB_TRANSACTION_TIMEOUT                = "02369";
   public static final String STR_ENV_SESSION_CLASS                          = "02370";
   public static final String STR_ENV_DBTRANSACTION_FACTORY_CLASS            = "02371";
   public static final String STR_ENV_JDBC_POOL_REQUEST_TIMEOUT              = "02372";
   public static final String STR_ENV_PASSIVATION_STORE                      = "02373";
   public static final String STR_ENV_JBO_SCHEMA                             = "02374";
   public static final String STR_XSQL_NO_CONNECTION_FOUND                   = "02375";
   public static final String STR_XSQL_NO_VO_FOUND                           = "02376";
   public static final String STR_XSQL_MUST_GIVE_ATTR                        = "02377";
   public static final String STR_XSQL_MUST_GIVE_TWO_ATTRS                   = "02378";
   public static final String STR_MAX_POOL_COOKIE_AGE                        = "02379";
   public static final String STR_ENV_POOL_CLASS_NAME                        = "02380";
   public static final String STR_ENV_EJB_TXN_TYPE                           = "02381";
   public static final String STR_ENV_DO_CONNECTION_POOLING                  = "02382";
   public static final String STR_ENV_VIEWLINK_MODE                          = "02383";
   public static final String STR_JBO_XML_VALIDATION                         = "02385";
   public static final String STR_ENV_AMPOOL_RESET_NON_TRANS_STATE           = "02386";
   public static final String STR_ENV_AMPOOL_CONNECTION_STRATEGY_CLASS_NAME  = "02387";
   public static final String STR_ENV_AMPOOL_COOKIE_FACTORY_CLASS_NAME       = "02388";
   public static final String STR_ENV_AMPOOL_MAX_POOL_SIZE                   = "02389";
   public static final String STR_ENV_AMPOOL_INIT_POOL_SIZE                  = "02390";
   public static final String STR_ENV_AMPOOL_MONITOR_SLEEP_INTERVAL          = "02391";
   public static final String STR_ENV_AMPOOL_MIN_AVAIL_SIZE                  = "02392";
   public static final String STR_ENV_AMPOOL_MAX_AVAIL_SIZE                  = "02393";
   public static final String STR_ENV_AMPOOL_MAX_INACTIVE_AGE                = "02394";
   public static final String STR_ENV_JDBC_POOL_MONITOR_SLEEP_INTERVAL       = "02395";
   public static final String STR_ENV_JDBC_POOL_MIN_AVAIL_SIZE               = "02396";
   public static final String STR_ENV_JDBC_POOL_MAX_AVAIL_SIZE               = "02397";
   public static final String STR_ENV_JDBC_POOL_MAX_INACTIVE_AGE             = "02398";
   public static final String STR_PN_VIEWCRITERIA_ADAPTER                    = "02399";
   public static final String STR_PN_LOCKING_MODE                            = "02400";
   public static final String STR_ENV_VO_TRACK_INSERT                        = "02401";
   public static final String STR_ENV_AMPOOL_DYNAMIC_JDBC_CREDENTIALS        = "02402";
   public static final String STR_APPMODULE_JNDI_NAME                        = "02403";
   public static final String STR_EJB_DISCONNECT_ON_TXN_COMPLETION           = "02404";
   public static final String STR_JBO_SERVER_USE_NULLDBTRANSACTION           = "02405";
   public static final String STR_ENV_PASSIVATION_SAVE_FOR_LATER             = "02406";
   public static final String STR_ENV_SNAPSHOT_STORE_UNDO                    = "02407";
   public static final String STR_ENV_MAX_PASSIVATION_STACK_SIZE                 = "02408";
   public static final String STR_ENV_TXN_HANDLE_AFTER_POST_EXC                 = "02409";
   public static final String STR_ENV_DISCONNECT_LEVEL                       = "02410";

   public static final String STR_ORD_HTTP_MAX_MEMORY                        = "02420";
   public static final String STR_ORD_HTTP_TEMP_DIR                          = "02421";

   public static final String STR_ORD_WMP_CLASS_ID                           = "02423";
   public static final String STR_ORD_QP_CLASS_ID                            = "02424";
   public static final String STR_ORD_RP_CLASS_ID                            = "02425";

   public static final String STR_ORD_WMP_CODE_BASE                          = "02426";
   public static final String STR_ORD_QP_CODE_BASE                           = "02427";
   public static final String STR_ORD_RP_CODE_BASE                           = "02428";

   public static final String STR_ORD_WMP_PLUGINS_PAGE                       = "02429";
   public static final String STR_ORD_QP_PLUGINS_PAGE                        = "02430";
   public static final String STR_ORD_RP_PLUGINS_PAGE                        = "02431";
   
   public static final String STR_SECURITY_ENFORCE                           = "02432";
   public static final String STR_SECURITY_LOGINMODULE                       = "02433";
   public static final String STR_SECURITY_AUTHORIZED                        = "02434";
   public static final String STR_USER_PRINCIPAL                             = "02435";
   public static final String STR_ENV_AMPOOL_DO_AM_POOLING                   = "02436";
   public static final String MSG_UNABLE_TO_SET_SYSTEM_PROPERTY              = "12300";
   
   /**
   ** <b>JBO-33000: JboException</b>
   ** <p>
   ** <b>Cause:</b> An attempt was made to load a Configuration file (bc4j.xcfg)
   ** from the file system, but this file was not found. A Configuration file can
   ** be loaded by invoking the loadFromFile method in oracle.jbo.client.Configuration 
   ** class.
   ** <p>
   ** <b>Action:</b> Make sure the name of the file passed to the loadFromFile method
   ** is correct and the file exists.
   **
   */
   public static final String EXC_CONF_FILE_NOT_FOUND                        = "33000";

   /**
   ** <b>JBO-33001: JboException</b>
   ** <p>
   ** <b>Cause:</b> An attempt was made to load a Configuration file (bc4j.xcfg)
   ** from the classpath, but this file was not found. A Configuration file can
   ** be loaded by invoking the loadFromClassPath method in oracle.jbo.client.Configuration 
   ** class.
   ** <p>
   ** The Application Module pool implementation loads the Configuration file 
   ** from the classpath.
   ** <p>
   ** <b>Action:</b> Make sure the name of the file passed to the loadFromClassPath 
   ** method is correct and the file exists in the classpath.
   **
   */
   public static final String EXC_CONF_NOT_IN_CLASS_PATH                     = "33001";

   // not used
   public static final String EXC_CONF_CONNECTION_MISSING                    = "33002";

   /**
   ** <b>JBO-33003: JboException</b>
   ** <p>
   ** <b>Cause:</b>This exception is thrown when the JDBC connection definition 
   ** is missing in the Configuration file. The bc4j.xcfg file includes the 
   ** connection definition for each JDBC connection used in different Configuration's.
   **
   ** <p>
   ** <b>Action:</b>Create a new JDBC connection in JDeveloper Connection 
   ** manager. The name of the connection specified in the Connection manager 
   ** should match the JDBC connection name used in the Configuration.
   **
   */
   public static final String EXC_CONF_CONNECTION_NOT_FOUND                  = "33003";


   /**
   ** <b>JBO-33004: JboException</b>
   ** <p>
   ** <b>Cause:</b>This exception is thrown when there is an error passing the 
   ** bc4j.xcfg Configuration file. The Configuration file is a xml file and it 
   ** should be 'Well formed'. 
   ** <p>
   ** This error is likely to occur, if you accidentally modified the bc4j.xcfg 
   ** file outside of JDeveloper
   **
   ** <b>Action:</b>Fix the error in xcfg file. In JDeveloper save the file with 
   ** xml extension, like my.xml, right click on the my.xml node and select validate 
   ** xml.
   **
   */
   public static final String EXC_CONF_ERROR_PARSING                         = "33004";


   /**
   ** <b>JBO-33005: JboException</b>
   ** <p>
   ** <b>Cause:</b>This exception is thrown when the named Configuration is not 
   ** found in the bc4j.xcfg file.
   ** <p>
   ** The bc4j.xcfg file defines one or more Configuraton each identified by a name.
   ** This name is later used in the  client code. For example, it is used in the 
   ** createRootApplicationModule() method of the oracle.jbo.client.Configuration 
   ** class.
   ** <p>
   **
   ** <b>Action:</b>Make sure the name of the Configuration is correct.
   **
   */
   public static final String EXC_CONF_CONFIGURATION_NOT_FOUND               = "33005";

   
   public static final String EXC_UNSUPPORTED_DATASOURCE                     = "33006";

   
   /**
   ** <b>JBO-33007: JboException</b>
   ** <p>
   ** <b>Cause:</b>This exception is thrown when the DataSource definition is 
   ** not found.
   ** <p>
   */
   public static final String EXC_DATASOURCE_NOT_FOUND                       = "33007";

   public static final String EXC_NO_APPLICATION_CONTEXT                     = "33008";
   
   /**
   ** <b>JBO-33020: JboException</b>
   ** <p>
   ** <b>Cause:</b>This exception is thrown, if an error occured while the SQLBuilder 
   ** in effect was attempting to determine the current time on the database server.
   **
   */
   public static final String EXC_GETCURTIME                                 = "33020";

   /**
   ** <b>JBO-33021: JboException</b>
   ** <p>
   ** <b>Cause:</b>This exception is thrown when the JAAS authentication fails.
   ** <p>
   ** <b>Action:</b>Make sure the security credentials are correct.
   */
   public static final String EXC_SECURITY                                   = "33021";

   public static final String STR_ORD_RETRIEVE_PATH                          = "33025";
   

   /**
    * Gets the key-value association table.
    *
    * @return an array of key-value pairs.
    **/
   public Object[][] getContents()
   {
      return sMessageStrings;
   }


   /**
    * Private 2-D array of key-value pairs
    **/
   private static final Object[][] sMessageStrings =
   {
      {STR_DEPLOY_PLATFORM                      , "Deployment Platform"},
      {STR_CONNECTION_MODE                      , "Connection Mode used for Visigenic ORB (1|2|3|4)"},
      {STR_HOST_NAME                            , "Name of the host machine"},
      {STR_CONNECTION_PORT                      , "Connection Port"},
      {STR_APPLICATION_PATH                     , "Application Path"},
      {STR_APPMODULE_JNDI_NAME                  , "Jndi name to lookup application module home"},
      {STR_ENV_USE_PERS_COLL                    , "Use persistent collection for view row spill-over?"},
      {STR_ENV_PERS_MAX_ROWS_PER_NODE           , "Maximum number of rows in a persistent collection node"},
      {STR_ENV_PERS_MAX_ACTIVE_NODES            , "Maximum number of active (in-memory) nodes in a persistent collection"},
      {STR_ENV_PCOLL_MGR                        , "Persistent collection manager"},
      {STR_STRINGMANAGER_FACTORY_CLASS          , "String Manager Factory Class"},
      {STR_ENV_OBJ_MARSHALLER                   , "Object marshaller class"},
      {STR_ENV_TXN_TABLE_NAME                   , "Persistent transaction table name"},
      {STR_ENV_TXN_SEQ_NAME                     , "Persistent transaction sequence name"},
      {STR_ENV_CONTROL_TABLE_NAME               , "Persistent collection control table name"},
      {STR_DYNAMIC_PACKAGE_NAME                 , "Name of package to be loaded dynamically (no default)"},
      {STR_MOM_CONTEXT_FACTORY                  , "MetaObjectManager context factory class"},
      {STR_INITIAL_CONTEXT_FACTORY              , "Class name of BC4J server initial context factory"},
      {STR_INITIAL_CONTEXT                      , "MetaObjectManager XML initial context"},
      {STR_LOAD_COMP_LAZILY                     , "Lazy loading of Application Module components (true|false)"},
      {STR_JBO_323_COMPATIBLE                   , "Compatibility behavior with 3.2.3 (true|false)"},
      {STR_JBO_903_COMPATIBLE                   , "Compatibility behavior with 9.0.3 (true|false)"},
      {STR_IS_LAZY_LOADING_TRUE                 , "Lazy loading of meta objects (true|false)"},
      {STR_PN_SQLBUILDERIMPL                    , "SQLBuilder implementation"},
      {STR_PN_SQLTYPEMAP                        , "TypeMap implementation"},
      {STR_PN_JDBC_DRIVER_CLASS                 , "Name of class implementing jdbc Driver"},
      {STR_PN_SQL92_LOCKTRAILER                 , "SQL Statement trailer clause for locking (eg: FOR UPDATE)"},
      {STR_ENV_DEFAULT_LANGUAGE                 , "The default BC4J session language - part of the Locale"},
      {STR_ENV_DEFAULT_COUNTRY                  , "The default BC4J session country - part of the Locale"},
      {STR_ENV_FETCH_MODE                       , "Control fetch behavior of View Objects (" + PropertyConstants.ENV_FETCH_AS_NEEDED + "|" + PropertyConstants.ENV_FETCH_ALL + ")" },
      {STR_SHARED_DATA_HANDLE                   , "Use shared data handles for common metadata (true|false)" },
      {STR_HANDLE_NAME                          , "Name of shared data handle for common metadata" },
      {STR_GLOBAL_SUBSTITUTION                  , "Global substitution list" },
      {STR_JBO_PROJECT                          , "Project to use for global substitution" },
      {STR_ENV_MAX_CURSORS                      , "Maximum number of cursors to be used by the session" },
      {STR_ENV_DO_FAILOVER                      , "Determines whether failover should occur upon checkin to the application module pool" },
      {STR_ENV_MAX_JDBC_POOL_SIZE               , "Maximum size of a JDBC connection pool"},
      {STR_ENV_INIT_JDBC_POOL_SIZE              , "Initial size of a JDBC connection pool"},
      {STR_ENV_ENTITYROWSET_MODE                , "Are Entity rowset associations kept consistent?"},
      {STR_PN_POOL_MANAGER                      , "Which implementation of a connection pool manager to use"},
      {STR_PN_JBO_JDBC_TRACE                    , "Trace all JDBC activitity with lines flagged by '" + PropertyConstants.JDBC_MARKER + "'"},
      {STR_USE_DEFINE_COLUMN_LENGTH             , "Define column length for all JDBC CHAR or VARCHAR2 columns"},
      {STR_TEMPORARY_FILES_HOME                 , "Declare a directory to create temporary files in."},
      {STR_INTERNAL_CONNECTION_PARAMS           , "Declares the jdbc-connect string to use to store AM state, VO spill-to-disk, etc"},
      {STR_PN_DEBUG_TYPE                        , "The type of diagnostic implementation to use"},
      {STR_PN_DEBUG_PREFIX                      , "Prefix prepended to DebugDiagnostic lines"},
      {STR_PN_SHOW_TIMING                       , "Show timing information between debug calls"},
      {STR_PN_SHOW_FUNCTION                     , "Show the name of the function in diagnostics (expensive)"},
      {STR_PN_SHOW_LEVEL                        , "Show the actual trace level of the diagnostic message (rarely used)"},
      {STR_PN_SHOW_LINECOUNT                    , "Increment a counter and display it at the beginning of each diagnostic line"},
      {STR_PN_TRACE_THRESHOLD                   , "Show only diagnostic messages with a trace level less than or equal to this threshold"},
      {STR_PN_JDBC_DRIVER_VERBOSE               , "Switch the underlying JDBC driver into verbose mode"},
      {STR_PN_LOCKING_MODE                      , "Default locking mode for an application module {pessimistic|optimistic}"},
      {STR_PN_DBTIME_QUERY                      , "Database system time SQL query string"},
      {STR_AM_RELEASE_MODE                      , "Release mode for Application Module pooling (Stateless|Stateful|Reserved)" },
      {STR_SECURITY_PRINCIPAL                   , "JNDI: Identity of principal (e.g. user) for the authentication scheme"},
      {STR_SECURITY_CREDENTIALS                 , "JNDI: Principal's credentials for the authentication scheme"},
      {STR_ENV_POOL_RECYCLE_THRESHOLD           , "Threshold application module pool size at which referenced application modules should be recycled"},
      {STR_ENV_EJB_TRANSACTION_TIMEOUT          , "Time after the application module session bean transaction expires"},
      {STR_EJB_DISCONNECT_ON_TXN_COMPLETION     , "Release and reacquire jdbc connection upon appmdule session bean transaction completion"},
      {STR_JBO_SERVER_USE_NULLDBTRANSACTION     , "Use 9.0.2 compatible oracle.jbo.server.NullDbtransactionImpl when not connected to database"},
      {STR_ENV_PASSIVATION_SAVE_FOR_LATER, "Save snapshots for the lifetime of the transaction"},
      {STR_ENV_SNAPSHOT_STORE_UNDO, "Target for undo snapshots {transient|persistent}"},
      {STR_ENV_MAX_PASSIVATION_STACK_SIZE, "Maximum size of the passivation stack (default 10)"},
      {STR_ENV_TXN_HANDLE_AFTER_POST_EXC, "Use passivation to restore transaction state if an exception occurs after post (default false)"},
      {STR_ENV_DISCONNECT_LEVEL, "Internal:  Mode that should be used to handle database state at disconnect"},
      {STR_ENV_SESSION_CLASS                    , "Name of Session class in middle tier which implementing the oracle.jbo.Session interface"},
      {STR_ENV_DBTRANSACTION_FACTORY_CLASS      , "DatabaseTransactionFactory class to be used for creating DatabaseTransaction"},
      {STR_ENV_JDBC_POOL_REQUEST_TIMEOUT        , "Time a request should wait for a JDBC connection to be released to the connection pool"},
      {STR_ENV_PASSIVATION_STORE                , "The type of store, database or file, that should be used for application module passivation"},
      {STR_ENV_JBO_SCHEMA                       , "Schema name in which BC4J runtime libraries are deployed"},
      {STR_XSQL_NO_CONNECTION_FOUND             , "Connection {0} not found in XSQLConfig.xml"},
      {STR_XSQL_NO_VO_FOUND                     , "View Object {0} not found"},
      {STR_XSQL_MUST_GIVE_ATTR                  , "You must supply the {0} attribute"},
      {STR_XSQL_MUST_GIVE_TWO_ATTRS             , "You must supply the {0} or {1} attribute"},
      {STR_MAX_POOL_COOKIE_AGE                  , "Maximum browser cookie age for pooled application module sessions"},
      {STR_ENV_POOL_CLASS_NAME                  , "Custom ApplicationPool implementation class"},
      {STR_ENV_EJB_TXN_TYPE                     , "EJB container transaction type"},
      {STR_ENV_DO_CONNECTION_POOLING            , "Determines whether the application pool should release the application module connection upon checkin"},
      {STR_ENV_VIEWLINK_MODE                    , "Are view links kept consistent by default?"},
      {STR_JBO_XML_VALIDATION                   , "Determines the validation mode for XML-parser"},
      {STR_ENV_AMPOOL_RESET_NON_TRANS_STATE     , "Determines if non-transactional application module state should be reset upon an unmanaged checkin"},
      {STR_ENV_AMPOOL_CONNECTION_STRATEGY_CLASS_NAME, "Specifies a custom connection strategy implementation"},
      {STR_ENV_AMPOOL_COOKIE_FACTORY_CLASS_NAME , "Specifies a custom session cookie factory implementation"},
      {STR_ENV_AMPOOL_MAX_POOL_SIZE             , "The maximum number of application module instances in a pool"},
      {STR_ENV_AMPOOL_INIT_POOL_SIZE            , "The initial number of application module instances in a pool"},
      {STR_ENV_AMPOOL_MONITOR_SLEEP_INTERVAL    , "The time (ms) that the application pool monitor should sleep between pool checks"},
      {STR_ENV_AMPOOL_MIN_AVAIL_SIZE            , "The minimum number of available application modules that should be referenced by an application pool"},
      {STR_ENV_AMPOOL_MAX_AVAIL_SIZE            , "The maximum number of available application modules that should be referenced by an application pool"},
      {STR_ENV_AMPOOL_MAX_INACTIVE_AGE          , "The maximum amount of time (ms) that an application module may remain inactive before it is removed from the pool"},
      {STR_ENV_AMPOOL_DO_AM_POOLING             , "Enable ApplicationModule pooling"},
      {STR_ENV_JDBC_POOL_MONITOR_SLEEP_INTERVAL , "The time (ms) that the connection pool monitor should sleep between pool checks"},
      {STR_ENV_JDBC_POOL_MIN_AVAIL_SIZE         , "The minimum number of available connections that should be referenced by a connection pool"},
      {STR_ENV_JDBC_POOL_MAX_AVAIL_SIZE         , "The maximum number of available connections that should be referenced by a connection pool"},
      {STR_ENV_JDBC_POOL_MAX_INACTIVE_AGE       , "The maximum amount of time (ms) that a connection may remain inactive before it is removed from the pool"},
      {STR_PN_VIEWCRITERIA_ADAPTER              , "ViewCritieraAdapter ClassName"},
      {STR_ENV_VO_TRACK_INSERT                  , "Track Insert during Passivation/Activation."},
      {STR_ORD_HTTP_MAX_MEMORY                  , "Restrict interMedia memory usage"},
      {STR_ORD_HTTP_TEMP_DIR                    , "interMedia temporary directory"},
      {STR_ENV_AMPOOL_DYNAMIC_JDBC_CREDENTIALS  , "Declares that an application pool may support multiple JDBC users"},
      {STR_ORD_WMP_CLASS_ID			, "Specifies a custom Windows Media Player's CLASS ID"},
      {STR_ORD_QP_CLASS_ID			, "Specifies a custom Quicktime Player's CLASS ID"},
      {STR_ORD_RP_CLASS_ID			, "Specifies a custom Realmedia Player's CLASS ID"},
      {STR_ORD_WMP_CODE_BASE			, "Specifies a custom Windows Media Player's CODE BASE"},
      {STR_ORD_QP_CODE_BASE			, "Specifies a custom Quicktime Player's CODE BASE"},
      {STR_ORD_RP_CODE_BASE			, "Specifies a custom Realmedia Player's CODE BASE"},
      {STR_ORD_WMP_PLUGINS_PAGE			, "Specifies a custom Windows Media Player's embed plugins download page"},
      {STR_ORD_QP_PLUGINS_PAGE			, "Specifies a custom Quicktime Player's embed plugins download page"},
      {STR_ORD_RP_PLUGINS_PAGE			, "Specifies a custom Realmedia Player's embed plugins download page"},
      {STR_ORD_RETRIEVE_PATH                    , "Specifies a custom retrieve path for the interMedia media delivery component"},
      {STR_SECURITY_ENFORCE                     , "JAAS Authentication, default is no authentication (None). Valid values are: None/Test/Must"},
      {STR_SECURITY_LOGINMODULE                 , "LoginModule, default is JAZNUserManager"},
      {STR_SECURITY_AUTHORIZED                  , "Security authorization check"},
      {STR_USER_PRINCIPAL                       , "Authenticated user principal name"},
      
      {EXC_CONF_FILE_NOT_FOUND                  , "Cannot find the configuration file {0}"},
      {EXC_CONF_NOT_IN_CLASS_PATH               , "Cannot find the configuration file {0} in the classpath"},
      {EXC_CONF_CONNECTION_MISSING              , "Connection name missing from the environment"},
      {EXC_CONF_CONNECTION_NOT_FOUND            , "Connection name {0} not defined"},
      {EXC_CONF_ERROR_PARSING                   , "Error parsing configuration file"},
      {EXC_CONF_CONFIGURATION_NOT_FOUND         , "Configuration {0} not found"},
      {EXC_UNSUPPORTED_DATASOURCE               , "Datasource {0} is not supported"},
      {EXC_DATASOURCE_NOT_FOUND                 , "Unable to lookup datasource {0}"},
      {EXC_NO_APPLICATION_CONTEXT               , "Error finding application context"},
      {EXC_GETCURTIME                           , "Error getting current time"},
      {EXC_SECURITY                             , "Failed authenticate user {0}"},

      {MSG_UNABLE_TO_SET_SYSTEM_PROPERTY        , "Unable to set system property {0} to {1}"},
   }  ;
}
