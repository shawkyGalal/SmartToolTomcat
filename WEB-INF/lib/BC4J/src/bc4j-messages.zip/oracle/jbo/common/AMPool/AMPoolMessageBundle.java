/*
 * @(#)AMPoolMessageBundle.java
 *
 * Copyright 2000-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.common.ampool;

import oracle.jbo.common.CheckedListResourceBundle;
import oracle.jbo.common.Diagnostic;

public class AMPoolMessageBundle
   extends CheckedListResourceBundle
{
   //
   // Ranges:
   //   STR_ 02000 - 02299
   //   MSG_ 12000 - 12299
   //   EXC_ 30000 - 32999
   //

   static
   {
      Diagnostic.println("AMPoolMessageBundle (language base) being initialized");
   }

   /**
   ** <b>JBO-30000: ApplicationPoolException</b>
   ** <p>
   ** <b>Cause:</b> The application attempted to create an application pool
   ** with the same name as an existing application pool.
   ** <p>
   ** <b>Action:</b> Correct the application logic that is creating an application
   ** pool. Validate that a pool with the given name has not already been
   ** registered with the pool manager.
   **
   */
   public static final String EXC_AMPOOL_MGR_ALREADY_CREATED    = "30000";

   /**
   ** <b>JBO-30001: ApplicationPoolException</b>
   ** <p>
   ** <b>Cause:</b> Deprecated.
   ** <p>
   ** <b>Action:</b> N/A
   **
   */
   public static final String EXC_AMPOOL_INVALID_COOKIE         = "30001";

   /**
   ** <b>JBO-30002: ApplicationPoolException</b>
   ** <p>
   ** <b>Cause:</b> Deprecated.
   ** <p>
   ** <b>Action:</b> N/A
   **
   */
   public static final String EXC_AMPOOL_INVALID_POOL_SIGNATURE = "30002";

   /**
   ** <b>JBO-30003: ApplicationPoolException</b>
   ** <p>
   ** <b>Cause:</b> The pool failed to create an application module instance
   ** during checkout.  Typically this exception may occur when the pool 
   ** has been configured with an invalid application module name, EJB server,
   ** etc. or when an invalid JDBC username, password, URL, or datasource name
   ** has been specified.
   ** <p>
   ** <b>Action:</b> See the exception details for more information regarding
   ** the failure.  Correct the application's configuration properties 
   ** appropriately. 
   **
   */
   public static final String EXC_AMPOOL_CHECKOUT_FAILED        = "30003";

   /**
   ** <b>JBO-30004: ApplicationPoolException</b>
   ** <p>
   ** <b>Cause:</b> The application attempted to check in an application module
   ** that was not checked out from the pool.
   ** <p>
   ** <b>Action:</b> Remove redundant <code>releaseApplicationModule()</code> invocations
   ** from the application logic.
   **
   */
   public static final String EXC_AMPOOL_INVALID_CHECKIN        = "30004";

   /**
   ** <b>JBO-30005: ApplicationPoolException</b>
   ** <p>
   ** <b>Cause:</b> The application attempted to invoke an application pool
   ** method with an application module that was not created by that application
   ** pool instance.
   ** <p>
   ** <b>Action:</b> Correct the application logic.  Use the session cookie
   ** that was used to acquire the application module instance to acquire
   ** a reference to the application pool that created that application module
   ** instance.
   **
   */
   public static final String EXC_AMPOOL_INVALID_AM_INSTANCE    = "30005";


   /**
   ** <b>JBO-30006: ApplicationPoolException</b>
   ** <p>
   ** <b>Cause:</b> The application attempted to access the application pool
   ** with a session cookie that is not registered with that application pool.
   ** <p>
   ** <b>Action:</b> Correct the application logic.  The application should
   ** not reference the application pool directly.  Use the session cookie
   ** interface for all application pool interaction.
   **
   */
   public static final String EXC_AMPOOL_INVALID_HANDLE         = "30006";

   /**
   ** <b>JBO-30007: ApplicationPoolException</b>
   ** <p>
   ** <b>Cause:</b> The application attempted to release a session cookie lock
   ** that it did not hold.
   ** <p>
   ** <b>Action:</b> Internal exception.  Please contact BC4J Technical Support.
   **
   */
   public static final String EXC_AMPOOL_INVALID_LOCK_RELEASE   = "30007";

   /**
   ** <b>JBO-30008: ApplicationPoolException</b>
   ** <p>
   ** <b>Cause:</b> A session cookie request thread timed out while waiting
   ** for the session cookie lock.
   ** <p>
   ** <b>Action:</b> Verify that all threads that have acquired a session cookie
   ** lock have properly released the session cookie lock when they have completed
   ** their task.  If the lock is properly released then increase the wait timeout
   ** period for the request that was interrupted.
   **
   */
   public static final String EXC_AMPOOL_SESSION_COOKIE_TIMEOUT = "30008";

   /**
   ** <b>JBO-30009: ApplicationPoolException</b>
   ** <p>
   ** <b>Cause:</b> The application attempted to modify the availability status
   ** of an application module that is already in active pool use.
   ** <p>
   ** <b>Action:</b> Remove the application logic that is updating the
   ** application module availability status.
   **
   */
   public static final String EXC_AMPOOL_AM_ALREADY_INITIALIZED = "30009";

   /**
   ** <b>JBO-30010: ApplicationPoolException</b>
   ** <p>
   ** <b>Cause:</b> The web server attempted to replicate a session cookie with
   ** an existing, active cookie.
   ** <p>
   ** <b>Action:</b> Internal exception.  Please contact BC4J Technical Support.
   **
   */
   public static final String EXC_AMPOOL_INVALID_COOKIE_REPL    = "30010";

   /**
   ** <b>JBO-30011: ApplicationPoolException</b>
   ** <p>
   ** <b>Cause:</b> The application attempted to create a session cookie with
   ** an invalid set of cookie parameters.
   ** <p>
   ** <b>Action:</b> Correct the application logic that creates the session
   ** cookie.  Verify that the cookie session id, application id, and application
   ** pool reference are all not null.
   **
   */
   public static final String EXC_AMPOOL_INVALID_COOKIE_PARAMS  = "30011";

   /**
   ** <b>JBO-30012: ApplicationPoolException</b>
   ** <p>
   ** <b>Cause:</b> The application attempted to create a session cookie in an
   ** application pool that already contains that session cookie.
   ** <p>
   ** <b>Action:</b> Correct the application logic that creates the session
   ** cookie.  Remove the existing session cookie before creating a new one
   ** in that pool.
   **
   */
   public static final String EXC_AMPOOL_COOKIE_ALREADY_EXISTS  = "30012";

   /**
   ** <b>JBO-30013: ApplicationPoolException</b>
   ** <p>
   ** <b>Cause:</b> The application attempted to change the session cookie
   ** environment after the session cookie became active.
   ** <p>
   ** <b>Action:</b> Correct the application logic that sets the session cookie
   ** environment.  Move all logic that changes the session cookie such that it
   ** occurs before the session cookie becomes active.  A session cookie is
   ** active after it is first used to acquire an application module.
   **
   */
   public static final String EXC_AMPOOL_COOKIE_ENV_IMMUTABLE   = "30013";

   /**
   ** <b>JBO-30014: ApplicationPoolException</b>
   ** <p>
   ** <b>Cause:</b> The application attempted to remove a session cookie from
   ** the pool while that cookie had an application module instance checked out.
   ** <p>
   ** <b>Action:</b> Correct the application logic that removes the session
   ** cookie from the application pool. Be sure to invoke <code>SessionCookie.releaseApplicationModule()</code>
   ** before invoking <code>ApplicationPool.removeCookie(SessionCookie)</code>.
   **
   */
   public static final String EXC_AMPOOL_CANNOT_REMOVE_COOKIE   = "30014";

   /**
   ** <b>JBO-30015: ApplicationPoolException</b>
   ** <p>
   ** <b>Cause:</b> The application attempted to serialize a session cookie
   ** while that cookie had an application module instance checked out or
   ** which the cookie was locked by a client request thread.
   ** <p>
   ** <b>Action:</b> Correct the serialization logic such that the session cookie
   ** is serialized after the session cookie application module has been
   ** released to the application pool and after all client requests have
   ** released their cookie locks.
   **
   */
   public static final String EXC_ILLEGAL_COOKIE_SERIALIZATION   = "30015";

   /**
   ** <b>JBO-30016: ApplicationPoolException</b>
   ** <p>
   ** <b>Cause:</b> The application request thread was timed out while waiting
   ** for an available appliation module instance in the pool.
   ** <p>
   ** <b>Action:</b> Prevent wait timeouts by increasing the maximum pool
   ** size.
   **
   */
   public static final String EXC_AMPOOL_WAIT_TIME_EXCEEDED      = "30016";

   /**
   ** <b>JBO-30017: ApplicationPoolException</b>
   ** <p>
   ** <b>Cause:</b><code>ApplicationModuleRef.resetState()</code> was invoked
   ** while the ApplicationModuleRef was referencing a reserved
   ** ApplicationModule instance. 
   ** <p>
   ** <b>Action:</b> Release the ApplicationModule with 
   ** <code>ApplicationModuleRef.releaseApplicationModule(true, boolean)</code>
   ** before invoking resetState.
   **
   */
   public static final String EXC_AMPOOL_CANNOT_RESET_STATE = "30017";

   /**
   ** <b>JBO-30018: ApplicationPoolException</b>
   ** <p>
   ** <b>Cause:</b><code>oracle.jbo.http.HttpContainer.findSessionCookie</code>
   ** was invoked with a configName which was different than the configuration
   ** that was used to create the specified SessionCookie.
   ** <p>
   ** <b>Action:</b> Use a distinct applicationId to identify the cookie for
   ** each distinct Configuration.
   **
   */
   public static final String EXC_AMPOOL_CONFIG_MISMATCH = "30018";

   /**
   ** <b>JBO-30019: ApplicationPoolException</b>
   ** <p>
   ** <b>Cause:</b>An ApplicationPool method was invoked for a cookie that was
   ** not currently available.  A cookie can be in an unavailable state
   ** if another thread is currently updating the cookie.  For example, consider
   ** the following scenario:
   ** <p>
   ** 1.  cookie 1 releases an ApplicationModule with the manageed state option
   ** 2.  cookie 2 targets that ApplicationModule for recycling
   ** 3.  Before cookie 2 has passivated the ApplicationModule state for
   **     cookie 1, cookie 1 requests another ApplicationModule
   ** <p>
   ** In this instance the ApplicationPool could throw an unavailable
   ** exception.
   ** <p>
   ** Most of the occurences of this exception should be handled by the BC4J
   ** pooling framework.  If you do encounter this exception please report
   ** the exception to technical support.  A workaround for the exception would
   ** be to attempt to the invalid operation again.
   ** <p>
   ** <b>Action:</b> Report the exception to technical support.  Attempt the
   ** invalid operation again.
   **
   */
   public static final String EXC_AMPOOL_UNAVAILABLE_COOKIE              = "30019";

   /**
   ** <b>JBO-30020: ApplicationPoolException</b>
   ** <p>
   ** <b>Cause:</b><tt>oracle.jbo.common.ampool.SessionCookie.releaseApplicationModule(byte)</tt> was invoked with an unsupported releaseMode.
   ** <p>
   ** <b>Action:</b>Invoke <tt>releaseApplicationModule(int)</tt> with a
   ** a valid releaseMode attribute.  Valid releaseModes include:
   **    <tt>SessionCookie.SHARED_MANAGED_RELEASE_MODE</tt>
   **    <tt>SessionCookie.SHARED_UNMANAGED_RELEASE_MODE</tt>
   **    <tt>SessionCookie.RESERVED_MANAGED_RELEASE_MODE</tt>
   **    <tt>SessionCookie.RESERVED_UNMANAGED_RELEASE_MODE</tt>
   ** <p>
   */
   public static final String EXC_AMPOOL_INVALID_RELEASE_MODE            = "30020";

   public static final String MSG_AMPOOL_NUM_OF_INSTANCE_CREATIONS       = "30100";
   public static final String MSG_AMPOOL_NUM_OF_INSTANCE_REMOVALS        = "30101";
   public static final String MSG_AMPOOL_NUM_OF_ACTIVATIONS              = "30102";
   public static final String MSG_AMPOOL_NUM_OF_PASSIVATIONS             = "30103";
   public static final String MSG_AMPOOL_NUM_OF_CHECK_OUTS               = "30104";
   public static final String MSG_AMPOOL_NUM_OF_CHECK_INS                = "30105";
   public static final String MSG_AMPOOL_NUM_OF_REUSES                   = "30106";
   public static final String MSG_AMPOOL_NUM_OF_REF_INSTANCES_RECYCLED   = "30107";
   public static final String MSG_AMPOOL_NUM_OF_UNREF_INSTANCES_RECYCLED = "30108";
   public static final String MSG_AMPOOL_NUM_OF_INSTANCES                = "30109";
   public static final String MSG_AMPOOL_MAX_NUM_OF_INSTANCES            = "30110";
   public static final String MSG_AMPOOL_AVG_NUM_OF_INSTANCES            = "30111";
   public static final String MSG_AMPOOL_NUM_OF_AVAIL_INSTANCES          = "30112";
   public static final String MSG_AMPOOL_AVG_NUM_OF_AVAIL_INSTANCES      = "30113";
   public static final String MSG_AMPOOL_AVG_NUM_OF_UNAVAIL_INSTANCES    = "30114";
   public static final String MSG_AMPOOL_NUM_OF_REF_INSTANCES            = "30115";
   public static final String MSG_AMPOOL_NUM_OF_UNUSED_REF_INSTANCES     = "30116";
   public static final String MSG_AMPOOL_NUM_OF_USED_REF_INSTANCES       = "30117";
   public static final String MSG_AMPOOL_NUM_OF_UNUSED_INSTANCES         = "30118";
   public static final String MSG_AMPOOL_NUM_OF_USED_INSTANCES           = "30119";
   public static final String MSG_AMPOOL_NUM_OF_SESSIONS                 = "30120";
   public static final String MSG_AMPOOL_AVG_NUM_OF_SESSIONS_REF_STATE   = "30121";
   public static final String MSG_AMPOOL_NUM_OF_INACTIVE_SESSIONS        = "30122";
   public static final String MSG_AMPOOL_NUM_OF_ACTIVE_SESSIONS          = "30123";
   public static final String MSG_AMPOOL_INSTANCE_LIFETIME_STATS         = "31024";
   public static final String MSG_AMPOOL_STATE_MANAGEMENT_STATS          = "31025";
   public static final String MSG_AMPOOL_USE_STATS                       = "31026";
   public static final String MSG_AMPOOL_INSTANCE_STATS                  = "31027";
   public static final String MSG_AMPOOL_INSTANCE_AGE_STATS              = "31028";
   public static final String MSG_AMPOOL_SESSION_STATS                   = "31029";
   public static final String MSG_AMPOOL_SESSION_AGE_STATS               = "31030";
   public static final String MSG_AMPOOL_NUM_OF_CHECK_OUT_FAILURES       = "31031";


   /**
    * Gets the key-value association table.
    *
    * @return an array of key-value pairs.
    **/
   public Object[][] getContents()
   {
      return sMessageStrings;
   }


   /**
    * Private 2-D array of key-value pairs
    **/
   private static final Object[][] sMessageStrings =
   {
      {EXC_AMPOOL_MGR_ALREADY_CREATED, "Application Module Pool {0} has already been created."},
      {EXC_AMPOOL_INVALID_COOKIE, "Cookie {0} is invalid."},
      {EXC_AMPOOL_INVALID_POOL_SIGNATURE, "Cookie's pool signature is invalid."},
      {EXC_AMPOOL_CHECKOUT_FAILED, "The application pool ({0}) failed to checkout an application module due to the following exception:"},
      {EXC_AMPOOL_INVALID_CHECKIN, "An application module that was not checked out was checked into the pool, {0}"},
      {EXC_AMPOOL_INVALID_AM_INSTANCE, "A pool operation was specified for an application module instance that was not created by that pool."},
      {EXC_AMPOOL_INVALID_HANDLE, "The cookie for session {0} and application {1} is not a valid handle for application pool, {2}.  The cookie may not be used to access this pool instance."},
      {EXC_AMPOOL_INVALID_LOCK_RELEASE, "The thread, {0}, attempted to release a session cookie lock that it had not acquired."},
      {EXC_AMPOOL_SESSION_COOKIE_TIMEOUT, "The thread, {0}, was timed out while waiting to acquire a session cookie lock."},
      {EXC_AMPOOL_AM_ALREADY_INITIALIZED, "A thread attempted to set an application module that may be in use as an available.  An application module's availability may not be changed from outside of the pool once it has been made available once."},
      {EXC_AMPOOL_INVALID_COOKIE_REPL, "The cookie for session {0} and application {1} may not be replicated with an active cookie instance."},
      {EXC_AMPOOL_INVALID_COOKIE_PARAMS, "A null session cookie application id, session id, or application pool reference ({0}, {1}, {2}) was specified during cookie construction.  The cookie could not be constructed."},
      {EXC_AMPOOL_COOKIE_ALREADY_EXISTS, "A cookie for session {0} and application {1} has already been registered with application pool {2}.  The cookie must be removed first."},
      {EXC_AMPOOL_COOKIE_ENV_IMMUTABLE, "The cookie environment for session {0} and application {1} may not be reset after the cookie has become active."},
      {EXC_AMPOOL_CANNOT_REMOVE_COOKIE, "The cookie for session {0} and application {1} may not be removed from the application pool while it has an application module checked out."},
      {EXC_ILLEGAL_COOKIE_SERIALIZATION, "The cookie for session {0} and application {1} may not be serialized while in use."},
      {EXC_AMPOOL_WAIT_TIME_EXCEEDED, "The request thread for session {0} and application {1} was timed out while waiting for an available application module in the pool, {2}."},
      {EXC_AMPOOL_CANNOT_RESET_STATE, "The cookie for session {0} and application {1} may not be reset while an ApplicationModule is reserved."},
      {EXC_AMPOOL_CONFIG_MISMATCH, "The cookie configuration does not match the specified configuration.  applicationId:  {0}, sessionId:  {1}, cookieConfig:  {2}, specifiedConfig:  {3}."},
      {EXC_AMPOOL_UNAVAILABLE_COOKIE, "An unavailable cookie state was detected while attempting to use a cookie.  applicationId:  {0}, sessionId: {1}."},
      {EXC_AMPOOL_INVALID_RELEASE_MODE, "An invalid SessionCookie release mode was specified.  applicationId:  {0}, sessionId: {1}."},
      {MSG_AMPOOL_NUM_OF_INSTANCE_CREATIONS, "Application Module Creations"},
      {MSG_AMPOOL_NUM_OF_INSTANCE_REMOVALS, "Application Module Removals"},
      {MSG_AMPOOL_NUM_OF_ACTIVATIONS, "Transactional State Activations"},
      {MSG_AMPOOL_NUM_OF_PASSIVATIONS, "Transactional State Passivations"},
      {MSG_AMPOOL_NUM_OF_CHECK_OUTS, "Application Pool Check Outs"},
      {MSG_AMPOOL_NUM_OF_CHECK_INS, "Application Pool Check Ins"},
      {MSG_AMPOOL_NUM_OF_REUSES, "Referenced Application Modules That were Reused"},
      {MSG_AMPOOL_NUM_OF_REF_INSTANCES_RECYCLED, "Referenced Application Modules That were Recycled"},
      {MSG_AMPOOL_NUM_OF_UNREF_INSTANCES_RECYCLED, "Unreferenced Application Modules That were Recycled"},
      {MSG_AMPOOL_NUM_OF_INSTANCES, "Total Application Modules in the Pool"},
      {MSG_AMPOOL_MAX_NUM_OF_INSTANCES, "Maximum Application Modules in the Pool"},
      {MSG_AMPOOL_AVG_NUM_OF_INSTANCES, "Average Application Modules in the Pool"},
      {MSG_AMPOOL_NUM_OF_AVAIL_INSTANCES, "Total Available Application Modules in the Pool"},
      {MSG_AMPOOL_AVG_NUM_OF_AVAIL_INSTANCES, "Average Available Application Modules in the Pool"},
      {MSG_AMPOOL_AVG_NUM_OF_UNAVAIL_INSTANCES, "Average Unavailable Application Modules in the Pool"},
      {MSG_AMPOOL_NUM_OF_REF_INSTANCES, "Total Referenced Application Modules in the Pool"},
      {MSG_AMPOOL_NUM_OF_UNUSED_REF_INSTANCES, "Referenced Instances Unused for >{0} Minute"},
      {MSG_AMPOOL_NUM_OF_USED_REF_INSTANCES, "Referenced Instances Used During Last {0} Minute"},
      {MSG_AMPOOL_NUM_OF_UNUSED_INSTANCES, "Instances Unused for >{0} Minute"},
      {MSG_AMPOOL_NUM_OF_USED_INSTANCES, "Instances Used During Last {0} Minute"},
      {MSG_AMPOOL_NUM_OF_SESSIONS, "Sessions Registered With the Pool"},
      {MSG_AMPOOL_AVG_NUM_OF_SESSIONS_REF_STATE, "Average Sessions Referencing Transactional State"},
      {MSG_AMPOOL_NUM_OF_INACTIVE_SESSIONS, "Sessions Inactive for >{0} Minute"},
      {MSG_AMPOOL_NUM_OF_ACTIVE_SESSIONS, "Sessions Active During Last {0} Minute"},
      {MSG_AMPOOL_INSTANCE_LIFETIME_STATS, "Application module lifetime statistics"},
      {MSG_AMPOOL_STATE_MANAGEMENT_STATS, "State management statistics"},
      {MSG_AMPOOL_USE_STATS, "Application pool use statistics"},
      {MSG_AMPOOL_INSTANCE_STATS, "Application module statistics"},
      {MSG_AMPOOL_INSTANCE_AGE_STATS, "Application module age statistics"},
      {MSG_AMPOOL_SESSION_STATS, "Session statistics"},
      {MSG_AMPOOL_SESSION_AGE_STATS, "Session age statistics"},
      {MSG_AMPOOL_NUM_OF_CHECK_OUT_FAILURES, "Application Pool Check out Failures"}
   }  ;
}
