package oracle.jbo.domain;

//import oracle.jdbc.driver.OracleConnection;
//import oracle.sql.CustomDatum;
//import oracle.sql.CustomDatumFactory;
//import oracle.sql.Datum;
//import oracle.sql.NUMBER;
import java.math.BigDecimal;
import java.math.BigInteger;
//import java.sql.SQLException;
//import java.io.*;
//import java.text.NumberFormat;
//import java.text.DecimalFormat;
//import java.text.ParseException;
import oracle.jbo.common.DebugDiagnostic;

import oracle.jbo.Transaction; // (for setContext)
import oracle.jbo.domain.KeyAttributeInterface;
import java.io.Serializable;
import java.sql.SQLException;

/**
* This class provides a lightweight wrapper for <code>java.lang.Number</code>,
* the native Java type for number objects. This wrapper allows an instance
* of the <code>java.lang.Number</code> to be used as a domain object.
* The intent of many of the methods in this class is to wrap the corresponding
* method in the <code>java.lang.Number</code> class such that it returns
* an instance of an <tt>oracle.jbo.domain.Number</tt> object.
* <p>
* <code>Number</code> objects consist of data (a byte array)
* and a Domain type code.
* Domain numbers extend SQL characters by being convertable to
* JDBC values.
* @since JDevloper 3.0
*/

public class Number implements DomainInterface, Serializable, KeyAttributeInterface
{
  static {
     DebugDiagnostic.println("Number: using Vanilla domain implementation");
  }
   // Note: the classname is fully qualified here to distinguish
   //       it from this class (oracle.jbo.domain.Number)
   // private java.lang.Number m_data;
   private BigDecimal m_data;
   private int m_precision = -1;

   // TODO: update serial ID
   //private static final long serialVersionUID = -6507359405709672486L;

  // -----------------------
  // {{ Constructors Begin
  // -----------------------

  /**
    * Creates a <code>Number</code> Domain object representing zero.
    *
    * Use one of the <code>NullValue()</code> constructors to create
    * a null <code>Number</code> object.
    */
  public Number() {
     this(0);
  }

  /**
    * Creates a <code>Number</code> Domain object from an <code>int</code>.
    *
    * @param value a 32-bit signed integer.
    */
  public Number(int value) {
     // m_data = new Integer(value);
     m_data = new BigDecimal(value);
     m_precision = 0;
  }

  /**
    * Creates a <code>Number</code> Domain object from an <code>Long</code> object.
    *
    * @param value a 64-bit signed integer.
    */
  public Number(Long value) {
     // m_data = value;
     m_data = new BigDecimal(value.longValue());
     m_precision = 0;
  }

  /**
    * Creates a <code>Number</code> Domain object from an <code>long</code>.
    *
    * @param value a 64-bit signed integer.
    */
  public Number(long value) {
     // m_data = new Long(value);
     m_data = new BigDecimal(value);
     m_precision = 0;
  }

  /**
    * Creates a <code>Number</code> Domain object from an <code>short</code>.
    *
    * @param value a 16-bit signed integer.
    */
  public Number(short value) {
     // m_data = new Short(value);
     m_data = new BigDecimal(value);
     m_precision = 0;
  }

  /**
    * Creates a <code>Number</code> Domain object from an <code>float</code>.
    *
    * @param value a 32-bit floating-point value.
    */
  public Number(float value) {
     // m_data = new Float(value);
     m_data = new BigDecimal(trimStr(String.valueOf(value)));
     m_precision = m_data.scale();
  }

  /**
    * Creates a <code>Number</code> Domain object from an <code>Double</code> object.
    *
    * @param value a 64-bit floating-point value.
    */
  public Number(Double value) {
     // m_data = value;
     m_data = new BigDecimal(trimStr(value.toString()));
     m_precision = m_data.scale();
  }

  /**
    * Creates a <code>Number</code> Domain object from an <code>double</code>.
    *
    * @param value a 64-bit floating-point value.
    * @throws  <code>SQLException</code> on over/underflow of the exponent
    * or on overflow of the mantissa.
    */
  public Number(double value) {
     // m_data = new Double(value);
     m_data = new BigDecimal(trimStr(String.valueOf(value)));
     m_precision = m_data.scale();
  }

  /**
    * Creates a <code>Number</code> Domain object from a
    * <code>BigDecimal</code>.
    */
  public Number(BigDecimal value) {
     // this(value.doubleValue());
     m_data = value;
     m_precision = value.scale();
  }

  /**
  * Creates a <code>Number</code> Domain object from a
    * <code>BigInteger</code>.
    *
    * @param value an arbitrarily integer.
    */
    //* @throws  <code>SQLException</code> on overflow.
  public Number(BigInteger value) {
     // this(value.doubleValue());
     m_data = new BigDecimal(value);
     m_precision = 0;
  }


  /**
  * Creates a <code>Number</code> Domain object from a
    * <code>BigInteger</code>.
    *
    * @param value an arbitrarily integer.
    */
    //* @throws  <code>SQLException</code> on overflow.
  public Number(Object value) {
     this((value != null) ? value.toString() : "0");
  }

  /**
    * Creates a <code>Number</code> Domain object from a
    * Java <code>String</code>.
    *
    * @param value   a textual representation of a fixed-point number.
    * @param precision  ...
    * @throws <code>SQLException</code> on overflow.
    */
  public Number(String value, int precision) {
     this(value);
  // TODO: honour precision
     // DebugDiagnostic.println("Number Warning: ignored precision (" + precision + ")");
     m_precision = precision;
  }

  /**
    * Creates a <code>Number</code> Domain object from a
    * Java <code>String</code>.
    *
    * @param value   a textual representation of a <code>BigDecimal</code>.
    * @throws SQLException on over/underflow of the exponent
    * or on overflow of the mantissa, or if the string does not represent a
    * valid number.
    */
  public Number(String value) 
  {
     //DecimalFormat df = (DecimalFormat)NumberFormat.getInstance();
     // try
     {
        //Object numVal = df.parse(value);

        //if (numVal instanceof Long)
        //{
        //   m_data = new BigDecimal(((Long) numVal).doubleValue());
        //   m_precision = 0;
        //}
        //else  if (numVal instanceof Double)
        //{
        //   m_data = new BigDecimal(((Double) numVal).doubleValue());
        //   m_precision = m_data.scale();
        //}
        //else
        //{
        //   m_data = new BigDecimal(numVal.toString());
        //   m_precision = m_data.scale();
        //}
        m_data = new BigDecimal(value);
        m_precision = m_data.scale();
     }
     // catch (Exception e)
     // {
     //    throw new oracle.jbo.JboException(e);
     // }
     //DebugDiagnostic.println("Number: parsed '" + value + "' as " + m_data.getClass().getName());
  } // String constructor

  /**
    * Creates a <code>Number</code> Domain object from a <code>Boolean</code>.
    *
    * @param value <code>true</code> or <code>false</code>.
    * @return <code>0</code> if <code>value</code> is <code>false</code>,
    * or <code>1</code> otherwise.
    */
  // TODO:
  public Number(boolean value) {
     this(value ? 1 : 0);
  }

  /**
    * Creates a <code>Number</code> Domain object from an arbitrary
    * <code>Object</code>.
    *
    * One of the other constructors for <code>Number</code> is invoked,
    * depending on the type of the argument.
    * @param value an arbitrary object.
    * @throws <code>SQLException</code> if the called method fails,
    * or if the argument's type is not recognized.
    */
  //public Number(Object value) throws SQLException {
  //   super(value);
  //}

  /**
    * Creates a <code>Number</code> identical to an
    * existing <code>Number</code>.
    *
    * @param value a <code>Number</code> Domain object.
    * @throws <code>SQLException</code> never.
    */
  public Number(Number value) {
     // m_data = value.getDataAsJavaNumber();
     m_data = (BigDecimal) value.getDataAsJavaNumber();
     m_precision = m_data.scale();
  }

  // -----------------------
  // }} End Constructors
  // -----------------------

  public int getPrecision()
  {
/*
     if (m_precision == -1)
     {
        if (m_data==null) return -1;
        if (m_data instanceof Long) return 0;
        if (m_data instanceof Double) return 4;
     }
     else
     {
        return m_precision;
     }
     return -1;
*/
     return m_precision;
  }

  // -----------------------
  // {{ Begin output converters
  // -----------------------

  /**
    * Converts <code>this</code> to an <code>Object</code>.
    *
    * @value <code>this</code> converted to <code>BigDecimal</code><code>Object</code>
    */
  public java.lang.Number getDataAsJavaNumber() {
       return m_data;
  }

  /**
    * Converts <code>this</code> to an <code>Object</code>.
    *
    * @value <code>this</code> converted to <code>java.lang.Number</code><code>Object</code>
    */
  public Object getData() {
       // return new BigDecimal(m_data.doubleValue());
       return m_data;
       //return m_data;
  }

  // -----------------------
  // }} end output converters
  // -----------------------

  //TODO: what's this for? - part of DomainInterface
  public void setContext(DomainOwnerInterface owner, Transaction trans, Object ctx) 
  {
  }

  public static String trimStr(String s)
  {
     int index = s.indexOf('.');

     if (index >= 0)
     {
        int len = s.length();
        int j = len - 1;
        
        for ( ; j > index; j--)
        {
           if (s.charAt(j) != '0')
           {
              break;
           }
        }

        if (j == index)
        {
           j--;
        }
        
        if (j != len - 1)
        {
           return s.substring(0, j + 1);
        }
     }

     return s;
  }
  
  /**
    * Converts <code>this</code> to a fixed-point number presented as a string.
    */
  public String toString() {
     String str = m_data.toString();

     if (m_precision > 0)
     {
        str = trimStr(str);
     }
     
     return str;
     //DebugDiagnostic.println("Number ("+ m_data +") was of type: " + m_data.getClass().getName());
     
     //int prec = getPrecision();

     //if (prec < 0)
     //{
     //   return m_data.toString();
    // }
     
     //DecimalFormat df = (DecimalFormat)NumberFormat.getInstance();
     
     //df.setGroupingUsed(false);
     //df.setMaximumFractionDigits(prec);

     //return df.format(m_data.doubleValue());
  }

  /**
    * Tests <code>this</code> for equality with another object.
    *
    * @param other  an arbitrary <code>Object</code>.
    * @return <code>true</code> if conversion was successful and the converted
    * argument is identical to <code>this</code>.
    */
   public boolean equals(Object other)
   {
     if (other == null) 
     {
        return false;
     }

     if (this == other)
     {
        return true;
     }

     if (!other.getClass().equals(getClass()))
     {
        try
        {
           other = new Number(other);
        }
        catch(Exception sqle)
        {
           return false;
        }
     }

     return m_data.equals(((Number) other).m_data);
   }


  /**
    * Computes the hash code.
    *
    * @return the hash code of <code>this</code>.
    */
   public int hashCode()
   {
      return getDataAsJavaNumber().hashCode();
   }

  /* {{ we can let java serializaion handle this
  private void writeObject(java.io.ObjectOutputStream out)
    throws IOException
  {
     byte[] bytes = getBytes();
     out.writeInt(bytes.length);
     out.write(bytes);
  }

  private void readObject(java.io.ObjectInputStream in)
    throws IOException, ClassNotFoundException
  {
     int size = in.readInt();
     byte[] bytes = new byte[size];
     in.read(bytes);
     setBytes(bytes);
  }
  }} */

   /**
    * Implements domain validation logic and throws a JboException on error.
    */
   protected void validate()
   {
      // ### Implement custom domain validation logic here. ###
   }

  /**
   * Returns -1 if NUMBER is less than n, 0 if NUMBER and n are equal (==),
   * 1 if NUMBER is greater than n.
   * @param     n   input Oracle Number
   * @return integer result of comparison
   */
  public int compareTo(double n)
  {
     //Double d = new Double(m_data.doubleValue());
     //Double ad = new Double(n);
     //return d.compareTo(ad);

     // for jdk118 we use this form:
/*
     double d=m_data.doubleValue();
     if (d < n)
     {
         return -1;
     }
     else if (d > n)
     {
          return 1;
     }
     else
     {
         return 0;
     }
*/
     return m_data.compareTo(new BigDecimal(n));
  }

  /**
   * Returns -1 if NUMBER is less than n, 0 if NUMBER and n are equal (==),
   * 1 if NUMBER is greater than n.
   * @param     n   input Oracle Number
   * @return integer result of comparison
   */
  public int compareTo(oracle.jbo.domain.Number n)
  {
     // return compareTo(n.doubleValue());
     return m_data.compareTo(n.m_data);
  }

   /**
   * Multiplies <code>this</code> by another number.
   *
   * @param     n    a number.
   * @return a new <code>Number</code> object.
   */
  public Number multiply(Number n)
  {
    // return new Number(doubleValue()*n.doubleValue());
    return new Number(m_data.multiply(n.m_data));
  }


// {{ Begin Methods lifted from oracle.sql.NUMBER

  /**
   * Calls toDouble to convert internal Oracle Number to a Java double.
   *
   * @return a Java double value
   */
  public double doubleValue()
  {
    return m_data.doubleValue();
  } // doubleValue()

  /**
   * Calls toFloat to convert internal Oracle Number to a Java float.
   *
   * @return a Java float value
   */
  public float floatValue()
  {
    return m_data.floatValue();
  } // floatValue()

  /**
   * Calls toLong to convert internal Oracle Number to a Java long.
   *
   * @return a Java long value
   * @exception SQLException if the Oracle Number 
   *            exponent is out of range.
   */
  public long longValue()
  {
    return m_data.longValue();
  } // longValue()

  /**
   * Calls toInt to convert internal Oracle Number to a Java int.
   *
   * @return a Java int value
   * @exception SQLException if the Oracle Number 
   *            exponent is out of range.
   */
  public int intValue()
  {
    return m_data.intValue();
  } // intValue()

  /**
   * Calls toShort to convert internal Oracle Number to a Java short.
   *
   * @return a Java short value
   * @exception SQLException if the Oracle Number 
   *            exponent is out of range.
   */
  public short shortValue()
  {
    return m_data.shortValue();
  } // shortValue()

  /**
   * Calls toByte to convert internal Oracle Number to a Java byte.
   *
   * @return a Java byte value
   * @exception SQLException if the Oracle Number 
   *            exponent is out of range.
   */
  public byte byteValue()
  {
    return m_data.byteValue();
  } // byteValue()

  /**
   *
   * @return a Java BigInteger value
   * @exception SQLException if the Oracle Number exponent is out of range.
   */
  public BigInteger bigIntegerValue()
  {
    // return BigInteger.valueOf(m_data.longValue());
    return m_data.toBigInteger();
  } // bigIntegerValue()

  /**
   * Calls toBigDecimal to convert internal Oracle Number into a Java
   * BigDecimal.
   *
   * @return a Java BigDecimal value
   * @exception SQLException on over/underflow of the Oracle Number exponent
   *            and on overflow of the mantissa.
   */
  public BigDecimal bigDecimalValue()
  {
    // return BigDecimal.valueOf(m_data.longValue());
    return m_data;
  } // bigDecimalValue()

  /**
   * Calls toString to convert internal Oracle Number to a Java String.
   *
   * @return a Java String value
   */
  public String stringValue()
  {
    return m_data.toString();
  } // stringValue

  /**
   * Calls toBoolean to convert internal Oracle Number to a Java boolean.
   *
   * @return a Java boolean value
   */
  public boolean booleanValue()
  {
    if (m_data.longValue()==0) return false; else return true;
  } // booleanValue


   public byte[] getBytes()
   {
      if (m_data == null)
      {
         return new byte[0];
      }
      else
      {
         return m_data.toString().getBytes();
      }
   }


   public void setBytes(byte[] bArr)
   {
      if (bArr == null || bArr.length == 0)
      {
         m_data = null;
      }
      else
      {
         m_data = new BigDecimal(new String(bArr));
      }
   }
}
