/*
 * @(#)OracleResourceBundle.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.dacf.util;

import java.util.Enumeration;
import java.util.MissingResourceException;
import java.util.ResourceBundle;
import java.util.Vector;

/**
 * <code>OracleResourceBundle</code> is a abstract subclass of
 * <code>ResourceBundle</code> that manages locale-dependent resources
 * in an array.  By using numeric references rather than string
 * references, it requires less overhead and provides better performance than 
 * <code>PropertyResourceBundle</code> and <code>ListResourceBundle</code>. 
 * See <code>ResourceBundle</code> for more information about resource
 * bundles in general.
 *
 * <P>
 * Subclasses must override <code>getContents</code> and provide an array,
 * where each item in the array is the resource value.  The key for each
 * resource value is its numeric offset in the array.  For example, the first
 * element in the array has the key 0.  It may be retrieved by
 * using either getObject(0) or getObject("0");
 *
 * <P>
 * Unlike ListResourceBundle and PropertyResourceBundle, where each
 * locale-specific variation of a bundle can override only selected resources,
 * with OracleResourceBundle, each variation must provide the complete
 * set of Resources.  For example,if MyResources has three resources,
 * then MyResources_ja and MyResources_fr must also have three resources.
 *
 * <p>
 * The following example shows the structure of a ResourceBundle
 * based on OracleResourceBundle.
 * <pre>
 * class MyResource extends OracleResourceBundle {
 * 	public Object[] getContents() {
 * 		return contents;
 * 	}
 * 	static final Object[] contents = {
 * 	// LOCALIZE THIS
 * 		"Yes",    // Label for the YES button
 * 		"No",     // Label for the NO button
 * 		"Cancel"  // Label for the CANCEL button
 * 	// END OF MATERIAL TO LOCALIZE
 * 	};
 * }
 * </pre>
 * 
 * </blockquote>
 * @see ResourceBundle
 * @see ListResourceBundle
 * @see PropertyResourceBundle
 */
public abstract class OracleResourceBundle extends ResourceBundle {

  /**
   * Get a String from an OracleResourceBundle.
   * <BR>Convenience method to save casting.
   * @param key see class description.
   * @return the requested String
   */
  public final String getString(int key) throws MissingResourceException {
    return (String) getObject(key);
  }

  /**
   * Get an String array from a ResourceBundle.
   * <BR>Convenience method to save casting.
   * @param key see class description.
   * @return the requested String array
   */
  public final String[] getStringArray(int key)
    throws MissingResourceException {
    return (String[]) getObject(key);
  }

  private Object[] contents;

  /**
   * See class description.
   */
  protected abstract Object[] getContents();

  protected Object handleGetObject(String key) {
    return getObject(Integer.parseInt(key));
  }
  
  /**
   * Get an object from a ResourceBundle.
   * @param key see class description.
   * @return the requested object
   */
  public Object getObject(int index) {
    if (contents == null)
      contents = getContents();
    try {
      return contents[index];
    }
    catch (IndexOutOfBoundsException e) {
      return null;
    }
  }

  /**
   * Return an enumeration of the keys.
   * @return the enumeration object that can be used to walk the keys.
   */
  public Enumeration getKeys() {
    if (contents == null)
      contents = getContents();
    Vector result = new Vector(contents.length);
    for (int i=0; i<contents.length; i++) {
      result.addElement(String.valueOf(i));
    }
    return result.elements();
  }
}
