/*
 * @(#)ResultSetInfoBeanInfo.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.dacf.dataset;

import java.beans.BeanInfo;
import java.beans.IntrospectionException;
import java.beans.Introspector;
import java.beans.PropertyDescriptor;

/**
 ** <b>Internal:</b> <em>Applications should not use this class.</em>
 ** <p>
 ** BeanInfo implementation for ResultSetInfo.  This class provides the getters and setters for properties
 ** and validation, and methods for enumerated value strings.
 ** @see oracle.dacf.dataset.InfoObjectBeanInfo
 ** @see oracle.dacf.dataset.ResultSetInfo
 **
 ** @version SDK
 */
public class ResultSetInfoBeanInfo
    extends InfoObjectBeanInfo
{
    private static int NAME = 0;
    private static int GETTER = 1;
    private static int SETTER = 2;
    private static int EDITOR = 3;

    /*
    **  propertyName, get method, set method, optional custom property editor
    */
    private String [][] propertyList = new String[][]
    {
        { "queryInfo", "getQueryInfo", "setQueryInfo",
             "oracle.jdeveloper.daceditors.QueryInfoEditor" },
        { "session", "getSession", "setSession", null },
        { "rangeSize", "getRangeSize", "setRangeSize", null },
        { "queryOnOpen", "getQueryOnOpen", "setQueryOnOpen", null }
    };
    
    private static Class beanClass = oracle.dacf.dataset.ResultSetInfo.class;

   /**
    ** <b>Internal:</b> <em>Applications should not use this class.</em>
    ** <p>
    */
    public ResultSetInfoBeanInfo()
    {
        validationListenerMethodNames =
            new String[]
            {
                VALIDATE_ATTRIBUTE_METHOD_NAME,
                    VALIDATE_ROW_METHOD_NAME,
                    VALIDATE_ROWSET_METHOD_NAME
                    };
        changeListenerMethodNames =
            new String[]
            {
                ROW_ADDED_METHOD_NAME,
                    ROW_2B_REMOVED_METHOD_NAME,
                    ROWSET_POPULATED_METHOD_NAME,
                    ROWSET_CLEARED_METHOD_NAME
                    };
    }
    
    protected Class getBeanClass()
    {
        return beanClass;
    }
    
    /**
    ** <b>Internal:</b> <em>Applications should not use this method.</em>
    ** <p>
    ** Returns the property descriptors for the bean.
    ** @see java.beans.BeanInfo#getPropertyDescriptors()
    */
    public PropertyDescriptor[] getPropertyDescriptors()
    {
        PropertyDescriptor[] pdarr =
            new PropertyDescriptor[propertyList.length];
            
        try
        {
            for (int i = 0 ; i < propertyList.length ; i++)
            {
                pdarr[i] = new PropertyDescriptor(propertyList[i][NAME],
                                                  beanClass,
                                                  propertyList[i][GETTER],
                                                  propertyList[i][SETTER]);
                
                if(propertyList[i][EDITOR] != null)
                {
                    try
                    {
                        pdarr[i].setPropertyEditorClass(Class.forName(propertyList[i][EDITOR]));
                    }
                    catch(ClassNotFoundException ex)
                    {
                        // ex.printStackTrace(System.err);
                    }
                }
            }
        }
        catch (IntrospectionException e)
        {
            // e.printStackTrace(System.err);
            pdarr = null;
        }
        return(pdarr);
    }
    
    /**
    ** <b>Internal:</b> <em>Applications should not use this method.</em>
    ** <p>
    ** Returns the property descriptors for the superclass bean.
    ** @see java.beans.BeanInfo#getAdditionalBeanInfo()
    */
    public BeanInfo[] getAdditionalBeanInfo()
    {
        try
        {
            BeanInfo bi = Introspector.getBeanInfo(beanClass.getSuperclass());
            BeanInfo[] biarr = {bi};
            return biarr;
        }
        catch(IntrospectionException e)
        {
            // e.printStackTrace(System.err);
            return null;
        }
    }
}
