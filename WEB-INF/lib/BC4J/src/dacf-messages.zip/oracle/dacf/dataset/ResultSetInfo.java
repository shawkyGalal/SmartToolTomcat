/*
 * @(#)ResultSetInfo.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.dacf.dataset;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.text.MessageFormat;
import java.util.Hashtable;
import java.util.Vector;
import javax.infobus.DataItem;
import javax.infobus.ScrollableRowsetAccess;
import oracle.dacf.util.errormanager.ErrorManager;
import oracle.dacf.util.errormanager.ErrorMessage;
import oracle.dacf.util.errormanager.ErrorMessageText;
import oracle.jbo.ApplicationModule;
import oracle.jbo.AttributeDef;
import oracle.jbo.InvalidObjAccessException;
import oracle.jbo.NoDefException;
import oracle.jbo.Row;
import oracle.jbo.RowSet;
import oracle.jbo.ViewCriteria;
import oracle.jbo.ViewCriteriaRow;
import oracle.jbo.ViewObject;

/**
 **      This class contains all of the dataset specific properties and
 **      validators.  It also establishes the correlation between the
 **      ScrollableRowsetAccess DataItem and the server-side RowSet.
 **      It also serves as a base class for rowset based data producers.
 **
 **      @version SDK: since JDeveloper 3.0
 */
public class ResultSetInfo
    extends InfoObject
    implements Cloneable, QueryCriteriaStoreListener
{
    // update _isSpecialItemName(String name) && open() override below
    // if this list changes
    public static final String CURROW_ATTR_NAME = "#CurrentRow";
    public static final String ROWCNT_ATTR_NAME = "#RowCount";
    public static final String HIGH_ATTR_NAME = "#HighWaterMark";
    public static final String MODIFIED_ATTR_NAME = "#Modified";
    public static final String CURMSG_ATTR_NAME = "#CurrentMessage";
    public static final String QUERYCRITERIA_ATTR_NAME = "#QueryCriteria";
    public static final String DEFAULT_QUERYCRITERIA_ATTR_NAME =
        "#DefaultQueryCriteria";
    protected static final int _SPECIAL_ATTR_CNT = 7;
    private static final int MAXFETCHSIZE_NOT_SAVED = -2;

    private static Hashtable _specialItems = 
        new Hashtable(DacObject.INITIAL_CAPACITY);

    // error message constants that need to be moved out to a resource bundle
    protected static final String ERR_PROD_CODE =
        Res.getString(Res.ERR_PRODUCT_CODE);
    protected ViewObject _viewObj = null;

    private int _rangeSize = DEFAULT_BUFFER_SIZE;

    private String _viewDefName = null;
    private Query _queryInfo;
    private Vector _queryListeners;

    private QueryCriteria _queryCriteria;
    private boolean _queryOnOpen = true;
    private int _savedMaxFetchSize = MAXFETCHSIZE_NOT_SAVED;
    private static final boolean _DEBUG = true;

    /**
    **  The default number of rows to be retrieved at one time.
    */
    public static final int DEFAULT_BUFFER_SIZE = 50 ; // rows

    static
    {
        _specialItems.put(CURROW_ATTR_NAME,
                          CURROW_ATTR_NAME);
        _specialItems.put(ROWCNT_ATTR_NAME,
                          ROWCNT_ATTR_NAME);
        _specialItems.put(HIGH_ATTR_NAME,
                          HIGH_ATTR_NAME);
        _specialItems.put(MODIFIED_ATTR_NAME,
                          MODIFIED_ATTR_NAME);
        _specialItems.put(CURMSG_ATTR_NAME,
                          CURMSG_ATTR_NAME);
        _specialItems.put(QUERYCRITERIA_ATTR_NAME,
                          QUERYCRITERIA_ATTR_NAME);
        _specialItems.put(DEFAULT_QUERYCRITERIA_ATTR_NAME,
                          DEFAULT_QUERYCRITERIA_ATTR_NAME);
    }
    

    public ResultSetInfo()
    {
        this(null);
    }

    public ResultSetInfo(String queryViewName)
    {
        // _debug("constructor");
        setName(queryViewName);
        _queryListeners = new Vector(INITIAL_CAPACITY);
    }

    /**
    ** Determines if the underlying query is automatically executed. <P>
    **
    ** If the QueryOnOpen property is TRUE then the underlying query is
    ** automatically executed when the ResultSetInfo is opened.<p>
    ** If the property is false, then it will be necessary for executeQuery()
    ** to be called before values are retrieved via the DataItem.  The
    ** DataItem will still be published on the InfoBus but it will return
    ** null values until executeQuery() is called.<p>
    ** The default value for this property is TRUE to maintain backwards
    ** compatability with previous versions.
    **
    ** @param queryOnOpen if true then the query is executed on open
    ** @see #getQueryOnOpen()
    */
    public void setQueryOnOpen(boolean queryOnOpen)
    {
        _queryOnOpen = queryOnOpen;        
    } // setQueryOnOpen
    
    /**
    ** Returns if the underlying query is automatically executed. <P>
    **
    ** If the QueryOnOpen property is TRUE then the underlying query is
    ** automatically executed when the ResultSetInfo is opened.<p>
    ** If the property is false, then it will be necessary for executeQuery()
    ** to be called before values are retrieved via the DataItem.  The
    ** DataItem will still be published on the InfoBus but it will return
    ** null values until executeQuery() is called.<p>
    ** The default value for this property is TRUE to maintain backwards
    ** compatability with previous versions.
    **
    ** @return TRUE if the underlying query is automatically executed.
    ** @see #setQueryOnOpen(boolean queryOnOpen)
    */
    public boolean getQueryOnOpen()
    {
        return(_queryOnOpen);        
    } // getQueryOnOpen
    
    /**
    **  Add a column to the ResultSetInfo.
    **
    **  @param  col     The column to be added.
    */
    public void addAttribute(ColumnInfo col)
    {
        addChild(col);          // inherited from ProducerObject
    } // addAttribute

    /**
    **  remove a column from the ResultSetInfo.
    **
    **  @param  col     The column to be removed.
    */
    public void removeAttribute(ColumnInfo col)
    {
        removeChild(col);       // inherited from ProducerObject
    } // removeAttribute

    /**
    **  Return the ColumnInfo that corresponds to the column name.
    **
    **  @return The named ColumnInfo.  The value will be null if the
    **          column is not part of the RowSet.
    */
    public ColumnInfo getAttribute(String name)
    {
        DacObject child = getChild(name);
        
        // _debug("getAttribute: " + name );
        if (child != null && !(child instanceof ColumnInfo))
        {
            child = null;
        }
        
        return((ColumnInfo)child);
    } // getColumn

    /**
    **  Return the number ColumnInfo objects within the ResultSetInfo.
    **
    **  @return the number ColumnInfo objects within the ResultSetInfo.
    */
    public int getAttributeCount()
    {
        // _debug("getAttributeCount");
        int count = 0;
        DacObject[] kids = getChildren();
        
        for(int i = 0, j = 0; i < kids.length; i++)
        {
            if (kids[i] instanceof ColumnInfo)
            {
                count++;
            }
        }
        return(count);
    } // getColumn

    /**
    **  Return the ColumnInfo that corresponds to the column index.
    **
    **  @return ColumnInfo.  The value will be null if the
    **          column is not part of the RowSet.
    */
    public ColumnInfo getAttribute(int colIndex)
    {
        // _debug("getAttribute: " + colIndex);
        ColumnInfo attribute = null;
        DacObject[] kids = getChildren();
        for(int i = 0, j = 0; i < kids.length; i++)
        {
            if (kids[i] instanceof ColumnInfo)
            {
                if (colIndex == j++)
                {
                    attribute = (ColumnInfo)kids[i];
                }
            }
        }
        return(attribute);
    }

    /**
    ** An alternative way to add child ColumnInfo objects
    **
    ** @param kids list of child objects which should be
    **             added to this object
    **/
    public void setAttributeInfo(ColumnInfo[] kids)
    {
       removeChildren();

       for(int i = 0 ; i < kids.length; i++)
       {
           addAttribute(kids[i]);
       }
   }

    /**
    ** Returns the AttributeInfo objects representing the columns returned
    ** by the query.
    */
    public ColumnInfo[] getAttributeInfo()
    {
       DacObject[] kids = getChildren();
       int colInfoCount = 0;

       if ( kids == null)
       {
          return new ColumnInfo[0];
       }
       for(int i = 0; i < kids.length; i++)
       {
           if (kids[i] instanceof ColumnInfo)
           {
               colInfoCount++;
           }
       }
       ColumnInfo[] returnArray = new ColumnInfo[colInfoCount];
       for(int i = 0, j = 0; i < kids.length; i++)
       {
           if (kids[i] instanceof ColumnInfo)
           {
               returnArray[j++] = (ColumnInfo)kids[i];
           }
       }
       return(returnArray);
    }

    /**
    ** Sets the size of the fetch buffer. <P>
    **
    ** @param nuRangeSize the new requested size for fetch buffer; size
    **                    must be > 0 or -1; -1 indicates retrieve all rows.
    **                    The maximum value is the total number of rows.
    ** @see #getRangeSize()
    */
    public void setRangeSize(int nuRangeSize)
    {
        // _debug("setRangeSize");
        if (nuRangeSize > 0 || nuRangeSize == -1)
        {
            _rangeSize = nuRangeSize;
        }
    } // setRangeSize

    /**
    **  Returns the desired size of the fetch buffer. <P>
    **
    **  The actual size of the fetch buffer might be different.  The actual
    **  size of the fetch buffer can be retrieved by querying the associated
    **  RowsetAccess DataItem.
    **
    **  @return the current size of the fetch buffer; -1 indicates retrieve
    **          all rows. The maximum value is the total number of rows.
    **  @see #setRangeSize(int nuRangeSize)
    **  @see #getRowsetAccess()
    */
    public int getRangeSize()
    {
        return(_rangeSize);
    } // getRangeSize

    /**
    **  Creates a deep copy of the ResultSetInfo, including the children.
    **  It also clones the QueryInfo/QueryViewInfo and causes JBO to create
    **  a new ViewObject using the cloned QueryInfo/QueryViewInfo.
    */
    public synchronized Object clone()
    {
        ResultSetInfo rsi = null;

        try
        {
            SessionInfo si = (SessionInfo)getParent();
            ApplicationModule appMod = si.getApplicationModule();
            String defName = _viewObj.getDefName();
            Query query = (Query)getQueryInfo().clone();

            rsi = (ResultSetInfo)super.clone();
            rsi._queryListeners = new Vector(DacObject.INITIAL_CAPACITY);
            rsi._viewDefName = _viewDefName;
            rsi.setViewObject(null);
            rsi.setQueryInfo(query);
            rsi.setViewObject(query._createViewUsage(appMod, rsi.getName(),
                                                     si.getModulePackage()));
        }
        catch(Exception e)
        {
            rsi = null;
        }
        return(rsi);
    }

    public void addQueryListener(QueryListener ql)
    {
        _queryListeners.addElement(ql);
    }

    public void removeQueryListener(QueryListener ql)
    {
        _queryListeners.removeElement(ql);
    }

    public QueryListener[] getQueryListeners()
    {
        QueryListener[] listeners = null;

        synchronized(_queryListeners)
        {
            listeners = new QueryListener[_queryListeners.size()];
            _queryListeners.copyInto(listeners);
        }
        return(listeners);
    }

    /**
    ** Sets the QueryCriteria to be used when executing queries. <P>
    **
    ** @param queryCriteria the QueryCriteria to be used when executing
    **                      queries.
    ** @see #getQueryCriteria()
    */
    public void setQueryCriteria(QueryCriteria queryCriteria)
    {
        if (_viewObj != null)
        {
            _viewObj.applyViewCriteria(null);
        }
        if (_queryCriteria != null &&
            _queryCriteria.getCriteriaStore() != null)
        {
            _queryCriteria.getCriteriaStore().removeListener(this);
        }
        _queryCriteria = queryCriteria;
        if (_queryCriteria != null &&
            _queryCriteria.getCriteriaStore() != null &&
            _viewObj != null)
        {
            _queryCriteria.getCriteriaStore().addListener(this);
            _setViewCriteriaValues();
        }
    } // setQueryCriteria

    /**
    ** Returns the QueryCriteria to be used when executing queries. <P>
    **
    ** @return the QueryCriteria to be used when executing queries.
    ** @see #setQueryCriteria(QueryCriteria queryCriteria)
    */
    public QueryCriteria getQueryCriteria()
    {
        return(_queryCriteria);
    } // getQueryCriteria

    // QueryCriteriaStoreListener interface implementation
    // initial brute force implementation using _setViewCriteriaValues();
    public void rowsAdded(int rowIndex, int count)
    {
        _setViewCriteriaValues();
    }

    public void rowsDeleted(int rowIndex, int count)
    {
        _setViewCriteriaValues();
    }

    public void rowsChanged(int rowIndex, int count)
    {
        _setViewCriteriaValues();
    }

    public void navigated(int oldCurrent, int newCurrent)
    {
    }

    public void attributeChanged(String name, int rowIndex, Object oldValue)
    {
        _setViewCriteriaValues();
    }

    /**
    ** Specify the Where clause of the query statement for the ViewObject. <P>
    **
    ** Bind variable can be specified using '?' at the location of the value.
    **
    ** @param cond The query statement without WHERE
    */
    public void setQueryCondition(String cond)
    {
        // _debug("setQueryCondition");
        if ( _queryInfo != null)
        {
            QueryListener[] mimics = getQueryListeners();

            if (_queryInfo instanceof QueryClauses)
            {
                ((QueryClauses)_queryInfo).setWhereClause(cond);
            }
            for(int i = 0; i < mimics.length; i++)
            {
                mimics[i].whereClauseChanged(cond);
            }
        }
        if (isOpen())
        {
            _viewObj.setWhereClause(cond);
        }
    }

    /**
    ** Retrieve the current WHERE clause of the query statement for the
    ** ViewObject. <P>
    **
    ** @return The query statement without WHERE
    */
    public String getQueryCondition()
    {
        String qc = null;

        // _debug("getQueryCondition");
        if (!isOpen())
        {
            if (_queryInfo != null)
            {
                qc = ((QueryClauses)_queryInfo).getWhereClause();
            }
        }
        else
        {
            qc = _viewObj.getWhereClause();
        }
        return(qc);
    }

    /**
    ** Specify the ORDER BY clause of the query statement for the ViewObject.
    **
    ** @param orderBy The sort order clause without ORDER BY
    */
    public void setQueryOrderbyClause(String orderBy)
    {
        // _debug("setQueryOrderbyClause");
        if (_queryInfo != null)
        {
            QueryListener[] mimics = getQueryListeners();

            ((QueryClauses)_queryInfo).setOrderByClause(orderBy);
            for(int i = 0; i < mimics.length; i++)
            {
                mimics[i].orderbyClauseChanged(orderBy);
            }
        }
        if (isOpen())
        {
            _viewObj.setOrderByClause(orderBy);
        }
    }

    /**
    ** Retrieve the current ORDER BY clause of the query statement for the
    ** ViewObject. <P>
    **
    ** @return The sort order clause without ORDER BY
    */
    public String getQueryOrderbyClause()
    {
        String obc = null;

        // _debug("getQueryOrderbyClause");
        if (!isOpen())
        {
            if (_queryInfo != null)
            {
                obc = ((QueryClauses)_queryInfo).getOrderByClause();
            }
        }
        else
        {
            obc = _viewObj.getOrderByClause();
        }
        return(obc);
    }

    /**
    ** retrieve the bind variable values to use with the condition. <P>
    **
    ** @return Array of values to use in the order they are specified in
    **         the condition.
    */
    public Object[] getQueryConditionParams()
    {
        Object[] params = null;

        // _debug("getQueryConditionParams");
        if (!isOpen())
        {
            if (_queryInfo != null)
            {
                params = _queryInfo.getQueryParams();
            }
        }
        else
        {
            params = _viewObj.getWhereClauseParams();
        }
        return(params);
    }


    /**
    ** Specify the bind variable values to use with the condition. <P>
    **
    ** @param params Array of values to use in the order they are specified in
    **               the condition.
    */
    public void setQueryConditionParams(Object[] params)
    {
        // _debug("setQueryConditionParams");
        if (_queryInfo != null)
        {
            QueryListener[] mimics = getQueryListeners();

            _queryInfo.setQueryParams(params);
            for(int i = 0; i < mimics.length; i++)
            {
                mimics[i].queryParamsChanged(params);
            }
        }
        if (isOpen())
        {
            _viewObj.setWhereClauseParams(params);
        }
    }


    /**
    ** Execute or re-execute the underlying query. <P>
    **
    ** This method will throw a DataSourceOperationException runtime
    ** exception if there are pending changes.  It it recommended that
    ** RowSetInfo.isDirty() be checked before calling this method.
    ** @exception DataSourceOperationException
    **            A Runtime exception thrown when the requested operation
    **            fails.
    */
    public void executeQuery()
    {
        if (!isOpen())
        {
            String errorCode =
                Res.getString(Res.ERR_RESULTSET_EXECUTE_QUERY_FAILED);
            String str =
                Res.getString(Res.ERR_RESULTSET_EXECUTE_QUERY_FAILED_MSG);
            str +=
                (": " + Res.getString(Res.ERR_RESULTSET_ROWSET_NOT_OPEN_MSG));
            DataSourceOperationException dsoe =
                new DataSourceOperationException(str, errorCode, ERR_PROD_CODE,
                                                 null);

            ExceptionProcessor.processException(getDataItem(), -1,
                                                dsoe,
                                                DacfType.CLIENT_FRAMEWORK,
                                                DacfSeverity.ERROR);
            throw(dsoe);
        }

        // _debug(getName() + ".executeQuery()");

        Exception e = null;
        boolean bNavigateToFirstFailed = true; 
        int step = 0;
        boolean hasRows = false;
        RowsetAccessImpl ra = (RowsetAccessImpl)getDataItem();
        try
        {
            if (_savedMaxFetchSize != MAXFETCHSIZE_NOT_SAVED)
            {
                _viewObj.setMaxFetchSize(_savedMaxFetchSize);
                _savedMaxFetchSize = MAXFETCHSIZE_NOT_SAVED;
            }
            _viewObj.executeQuery();
            step++;
            hasRows = ra.hasRows();
            // _debug(getName() + ".executeQuery() retrieved " + rc + " rows");
            step++;
            if (hasRows)
            {
                step++;
				if (_viewObj.getCurrentRowIndex() != 0)
				{
					Row r = _viewObj.first();
					if (r == null)
						bNavigateToFirstFailed = true;
					else
						bNavigateToFirstFailed = false;
				}
				else
				    bNavigateToFirstFailed = false;
                
            }
        }
        catch(Exception e1)
        {
            e = e1;
        }
        finally
        {
            if (e != null)
            {
                String str = null;
                String errorCode = null;

                switch(step)
                {
                case 0: // executeQuery() failed
                    errorCode =
                        Res.getString(Res.ERR_RESULTSET_EXECUTE_QUERY_FAILED);
                    str =
                        Res.getString(Res.ERR_RESULTSET_EXECUTE_QUERY_FAILED_MSG);
                    break;
                case 1: // hasRows() failed
                    errorCode =
                        Res.getString(Res.ERR_RESULTSET_FAILED_GETROWCOUNT);
                    str =
                        Res.getString(Res.ERR_RESULTSET_FAILED_GETROWCOUNT_MSG);
                    break;
                case 2: // hasRows == false
                    errorCode =
                        Res.getString(Res.ERR_RESULTSET_EMPTY_RESULT_SET);
                    str =
                        Res.getString(Res.ERR_RESULTSET_EMPTY_RESULT_SET_MSG);
                    break;
                case 3: // first() failed
                default:
                    if (bNavigateToFirstFailed)
                    {
                        errorCode =
                            Res.getString(Res.ERR_RESULTSET_CANT_NAV_TO_FIRST);
                        str =
                            Res.getString(Res.ERR_RESULTSET_CANT_NAV_TO_FIRST_MSG);
                    }
                    break;
                }

                if (str != null && errorCode != null)
                {
                    DataSourceOperationException dsoe =
                        new DataSourceOperationException(str, errorCode,
                                                         ERR_PROD_CODE, e);

                    ExceptionProcessor.processException(getDataItem(), -1,
                                                        dsoe,
                                                        DacfType.CLIENT_FRAMEWORK,
                                                        DacfSeverity.ERROR);
                }
            }
        }
        if (e == null)
        {
            QueryListener[] mimics = getQueryListeners();

            for(int i = 0; i < mimics.length; i++)
            {
                if (mimics[i] instanceof ResultSetInfo)
                {
                    mimics[i].queryExecuted();
                }
            }
        }
    } // executeQuery


    /**
    ** Set the QueryInfo object for the ResultSetInfo.
    **
    ** The QueryInfo object defines the query that will be used to retrieve
    ** data from the server.<P>
    **
    ** @param info The QueryInfo object that defines the query.
    */
    public void setQueryInfo(Query info)
    {
        // _debug("setQueryInfo");

        if (_viewObj != null)
        {
            String str =
                Res.getString(Res.ERR_RESULTSET_QUERY_DEFINED_MSG);
            String errorCode = Res.getString(Res.ERR_RESULTSET_QUERY_DEFINED);

            DataSourceOperationException dsoe =
                new DataSourceOperationException(str,
                                                 errorCode,
                                                 ERR_PROD_CODE,
                                                 null);

            ExceptionProcessor.processException(getDataItem(), -1, dsoe);
            throw(dsoe);
        }
        _queryInfo = info;
        QueryListener[] mimics = getQueryListeners();

        for(int i = 0; i < mimics.length; i++)
        {
            mimics[i].queryDefChanged(info);
        }
    }

    /**
    ** Returns the QueryInfo object for the ResultSetInfo.
    **
    ** The QueryInfo object defines the query that will be used to retrieve
    ** data from the server.<P>
    **
    ** @return The QueryInfo object that defines the query.
    */
    public Query getQueryInfo()
    {
        // _debug("getQueryInfo");
        return(_queryInfo);
    }


    /**
    ** Returns the updateable property value. <P>
    **
    ** @return true if the InfoObject is updatable
    ** @see #setUpdatable(boolean)
    ** @see #getUpdatable()
    */
    public boolean isUpdateable()
    {
       Query query = getQueryInfo();
       if (query instanceof QueryInfo &&
           ((QueryInfo)query).getEntityClassName() == null)
       {
          return false;
       }
       return super.isUpdateable();
    }
    /**
    **  specify the owning session for this ResultSetInfo. <P>
    **
    **  @param sessInfo sess info to which this rowset has to be added
    */
    public void setSession(SessionInfo sessInfo)
    {
        // _debug("setSession");
        SessionInfo parent = (SessionInfo)getParent();

        if ( parent != sessInfo && parent != null )
        {
            parent.removeChild(this);// remove existing association
        }

        if ( sessInfo != null )
        {
            sessInfo.addRowSet(this);
        }
    }

    /**
    ** return the session associated with this ResultSetInfo
    **
    ** @return SessionInfo associated with this object
    */
    public SessionInfo getSession()
    {
        // _debug("getSession");
        return((SessionInfo)getParent());
    }

    /**
    **  Sets up the ResultSetInfo for use by:
    **  <ul>
    **  <li>connect to the server-side ApplicationModule if defined
    **  <li>connect to the server-side RowSet
    **  <li>executes <tt>open()</tt> on all child ColumnInfo
    **  </ul>
    **  It throws an IllegalStateException exception if required properties
    **  aren't set.
    **
    **  @exception IllegalStateException Thrown if open called when required
    **                                   properties are missing.
    */
    public void open(boolean openChildren)
    {
        // update _SPECIAL_ATTR_CNT if/when a new special item is added
        createChild(CURROW_ATTR_NAME);
        createChild(ROWCNT_ATTR_NAME);
        createChild(HIGH_ATTR_NAME);
        createChild(MODIFIED_ATTR_NAME);
        createChild(CURMSG_ATTR_NAME);
        createChild(QUERYCRITERIA_ATTR_NAME);
        createChild(DEFAULT_QUERYCRITERIA_ATTR_NAME);
        
        super.open(openChildren);
        if (getQueryOnOpen() && !getViewObject().isExecuted())
        {
            executeQuery();
        }
    }

    /**
    **  Creates a child ColumnInfo, StatusInfo or QueryCriteriaProperty.<p>
    **
    **  @param  childName       The name for the new child InfoObject
    */
    protected ProducerObject createChild(String childName)
    {
        // _debug("createChild");
        ProducerObject col;

        col = (ProducerObject)getChild(childName);
        if (col == null)
        {
            if (childName.equals(CURROW_ATTR_NAME) ||
                childName.equals(ROWCNT_ATTR_NAME) ||
                childName.equals(HIGH_ATTR_NAME) ||
                childName.equals(MODIFIED_ATTR_NAME) ||
                childName.equals(CURMSG_ATTR_NAME))
            {
                col = new StatusInfo(childName);
            }
            else if (childName.equals(QUERYCRITERIA_ATTR_NAME) ||
                     childName.equals(DEFAULT_QUERYCRITERIA_ATTR_NAME))
            {
                col = new QueryCriteriaProperty(childName);
            }
            else
            {
                col = new ColumnInfo(childName);
            }
            addChild(col);
        }
        return(col);
    }

    
    /**
    **  Sets up the ResultSetInfo for use by:
    **  <ul>
    **  <li>connect to the server-side ApplicationModule if defined
    **  <li>connect to the server-side RowSet
    **  <li>executes <tt>open()</tt> on all child ColumnInfo
    **  </ul>
    **  It throws an IllegalStateException exception if required properties
    **  aren't set.
    **
    **  @exception IllegalStateException Thrown if open called when required
    **                                   properties are missing.
    */
    protected void openProducerObject()
    {
        // _debug("open");
        String str = null;

        if (!((InfoObject)getParent()).isOpen())
        {
            // call parent with false because we don't want all of the other
            // rowsets to get opened.
            ((InfoObject)getParent()).open(false);
        }

        if (_queryInfo == null)
        {
    			  Object args[] = { getName() };
      			str = MessageFormat.format(Res.getString(
                     Res.ERR_RESULTSET_QUERYINFO_NOT_DEFINED_MSG), args);
        }
        if (str != null)
        {
            String errorCode =
                Res.getString(Res.ERR_RESULTSET_BAD_CONNECT_PROP);
            String msg =
                Res.getString(Res.ERR_RESULTSET_BAD_CONNECT_PROP_MSG);
            Object args[]= { str };

            str = MessageFormat.format(msg, args);
            DataSourceInstantiationException dsie =
                new DataSourceInstantiationException(str,
                                                     errorCode,
                                                     ERR_PROD_CODE,
                                                     null);

            ExceptionProcessor.processException(getDataItem(), -1,
                                                dsie);
            throw(dsie);
        }
        try
        {
            ViewObject vo;
            SessionInfo si = (SessionInfo)getParent();
            ApplicationModule appModule = si.getApplicationModule();

            _viewDefName = _queryInfo.getName();
            _viewObj = _queryInfo._createViewUsage(appModule,
                                                   getDataSourceName(),
                                                   si.getModulePackage());
            if (_viewObj != null)
            {
                ViewRegistry.register(_viewObj.getName(), getName());
                if (!getQueryOnOpen() && !_viewObj.isExecuted())
                {
                    _savedMaxFetchSize = _viewObj.getMaxFetchSize();
                    _viewObj.setMaxFetchSize(0);
                }
            }
            createAssociation();
            findViewLinks(); // will create ColumnInfos for the links
            // Create a single column in the rowset
            // to hold state of all children
            _createPropertyColumn();
        }
        catch(DataSourceInstantiationException dsie)
        {
                throw dsie;
        }
        catch(DataSourceOperationException dsoe)
        {
            throw dsoe;
        }
        catch(Exception e)
        {
            Object args[] = { getName() };

            String msg =
                Res.getString(Res.ERR_RESULTSET_OPEN_FAILED_MSG);
            String errorCode =
                Res.getString(Res.ERR_RESULTSET_OPEN_FAILED);
            msg = MessageFormat.format(msg, args);
            DataSourceOperationException dsoe =
                new DataSourceOperationException(msg,
                                                 errorCode,
                                                 ERR_PROD_CODE,
                                                 e);

            ExceptionProcessor.processException(getDataItem(), -1,
                                                dsoe,
                                                DacfType.CLIENT_FRAMEWORK,
                                                DacfSeverity.PANIC);
            throw dsoe;
        }
    }

    /**
    **  Causes all child objects to be opened.
    */
    protected void openChildren()
    {
        // _debug("openChildren");
        DacObject[] kids = getChildren();
        for(int i = 0; i < kids.length; i++)
        {
            if (kids[i] instanceof InfoObject ||
                kids[i] instanceof PropertyInfo)
            {
                ((ProducerObject)kids[i]).open(true);
            }
        }
    }

    /**
    **  Setups up the DataItems that will be published.
    */
    protected void openDataItems()
    {
        RowsetAccessImpl rsai = (RowsetAccessImpl)getDataItem();

        if (rsai != null)
        {
            int rangeSize;
            ViewObject vo;
            RowSet rs = _viewObj == null ? null : _viewObj.getRowSet();
            String fullDefName = _viewObj.getDefFullName();
            DataItemImpl[] cdi = getClonedDataItems();
            ApplicationModule appMod =
                ((SessionInfo)getParent()).getApplicationModule();
            DacObject[] kids = getChildren();

            if (rsai.getRowSet() == null)
            {
                rsai.setRowSet(rs);
            }

            for(int i = 0; i < kids.length; i++)
            {
                if (kids[i] instanceof InfoObject ||
                    kids[i] instanceof PropertyInfo)
                {
                    rsai.addChild(((ProducerObject)kids[i]).getDataItemImpl());
                }
            }

            for(int i = 0; i < cdi.length; i++)
            {
                rangeSize = ((RowsetAccessImpl)cdi[i]).getBufferSize();
                if (rangeSize == -2)
                {
                    rangeSize = getRangeSize();
                }
                vo = appMod.createViewObject(cdi[i].getName(), fullDefName);
                if (vo != null)
                {
                    ViewRegistry.register(vo.getName(), getName());
                }
                ((RowsetAccessImpl)cdi[i]).setRowSet(vo.getRowSet());
                ((RowsetAccessImpl)cdi[i]).setBufferSize(rangeSize);
            }
        }
    }

    /**
    **  Discovers all ViewAccessor attributes defined in the ViewObject.<p>
    **
    **  If will create a ViewAccessInfo object for each ViewAccessor attribute
    **  it discovers in the ViewObject and parents those ViewAccessInfos to
    **  this ResultSetInfo.
    */
    protected void findViewLinks()
    {
        if (_viewObj != null)
        {
            AttributeDef[] defs = _viewObj.getAttributeDefs();

            for(int i = 0; i < defs.length; i++)
            {
                String n = defs[i].getName();

                byte attrKind = defs[i].getAttributeKind();
                if ( (attrKind == AttributeDef.ATTR_ASSOCIATED_ROW) ||
                     (attrKind == AttributeDef.ATTR_ASSOCIATED_ROWITERATOR))
                {
                    // we've got a ViewLink
                    if (getChild(n) == null)
                    {
                        // create the AttributeInfo for it
                        addAttribute(new ViewAccessorInfo(n));
                    }
                }
            }
        }
    }

    /**
    ** A hook for derived class to create an association
    */
    protected void createAssociation()
    {
    }

    /**
    ** A hook for derived class to remove an association
    */
    protected void destroyAssociation()
    {
    }

    /**
    **  Checks to see if close is permitted.<p>
    **
    **  Internal to the framework; should never be called by client classes
    **
    **  @exception  DataSourceOperationException  Occurs when closing isn't
    **                                            allowed.
    */
    protected void closeCheck()
    {
    }

    /**
    ** Close down the ResultSetInfo. <P>
    */
    protected void closeProducerObject()
    {
        RowSet[] details = null;

        try
        {
           details = _viewObj.getDetailRowSets();
           setQueryCriteria(null);
           destroyAssociation();
        }
        catch (InvalidObjAccessException ex)
        {
           // The view object has already been removed.  Ignore
           // the exception and continue closing the result set.
        }

        setOpen(false);
        if (ViewRegistry.deregister(_viewObj.getName(), getName()) &&
            (details == null || details.length == 0 || _isSelfRef(details)))
        {
            _viewObj.remove();
        }
        _viewObj = null;
    } // close

    private boolean _isSelfRef(RowSet[] details)
    {
        boolean isSelfRef = (details != null);

        for(int i = 0; isSelfRef && i < details.length; i++)
        {
            isSelfRef = (details[i].getViewObject() == _viewObj);
        }
        return(isSelfRef);
    }

    protected void closeChildren()
    {
        // _debug("closeChildren");
        DacObject[] kids = getChildren();
        
        for(int i = 0; i < kids.length; i++)
        {
            if (kids[i] instanceof ProducerObject)
            {
                ((ProducerObject)kids[i]).close();
            }
        }
    }

    protected void closeDataItems()
    {
        ViewObject vo;
        RowSet rs;
        RowSet[] details = null;
        RowsetAccessImpl ra;
        DataItemImpl[] cdi = getClonedDataItems();

        for(int i = 0; i < cdi.length; i++)
        {
            ra = (RowsetAccessImpl)cdi[i];
            rs = ra.getRowSet();
            vo = (rs != null ? rs.getViewObject() : null);
            if (vo != null)
            {
                try
                {
                    details = vo.getDetailRowSets();
                    if (ViewRegistry.deregister(vo.getName(), getName()) &&
                        (details == null || details.length == 0 ))
                    {
                        vo.remove();
                    }
                }
                catch (InvalidObjAccessException ex)
                {
                    // The view object has already been removed or wasn't.
                    // fully setup. Ignore the exception and continue closing
                    // the result set.
                }
            }
            ra.shutdown();
        }
        setClonedDataItems(null);
        ra = (RowsetAccessImpl)getDataItemImpl();
        if (ra != null)
        {
            ra.shutdown();
            setDataItem(null);
        }
    }

    /**
    **  Returns the server-side ViewObject associated with this ResultSetInfo.
    **
    **  @returns the server-side ViewObject for this ResultSetInfo
    */
    protected ViewObject getViewObject()
    {
        return(_viewObj);
    }

    /**
    **  Sets the server-side ViewObject associated with this ResultSetInfo.
    **
    **  @param vuObj the server-side ViewObject for this ResultSetInfo
    */
    protected void setViewObject(ViewObject vuObj)
    {
        ImmediateAccessImpl ia;
        DacObject[] kids = getChildren();
        RowsetAccessImpl rsai = (RowsetAccessImpl)getDataItemImpl();
        DataItemImpl[] cdi = getClonedDataItems();
        RowSet rs = _viewObj == null ? null : _viewObj.getRowSet();
        RowSet nrs = vuObj == null ? null : vuObj.getRowSet();

        _viewObj = vuObj;
        if (rsai != null)
        {
            rsai.setRowSet(nrs);
        }
        for(int i = 0; i < cdi.length; i++)
        {
            if (((RowsetAccessImpl)cdi[i]).getRowSet() == rs)
            {
                ((RowsetAccessImpl)cdi[i]).setRowSet(nrs);
            }
        }
        for(int i = 0; i < kids.length; i++)
        {
            if (kids[i] instanceof ColumnInfo)
            {
                ((ColumnInfo)kids[i]).setViewObject(vuObj);
            }
        }
        _setViewCriteriaValues();
    }

    /**
    ** Returns ScrollableRowsetAccess interface published. <P>
    **
    ** @return ScrollableRowsetAccess
    */
    public ScrollableRowsetAccess getRowsetAccess()
    {
        return((ScrollableRowsetAccess)getDataItem());
    } // getRowsetAccess


    /**
    **  Maps the ScrollableRowsetAccess interface. <P>
    **
    **  Maps the ScrollableRowsetAccess InfoBus interface on to another
    **  ScrollableRowsetAccess so that actions performed against the DataItem
    **  of this ResultSetInfo are reflected in the other DataItem.  There will
    **  be a complete mapping if the data published by <tt>target</tt> is a
    **  superset.  Otherwise the mapping will be partial; i.e. some operations
    **  won't map to <tt>target</tt>.<br>
    */
    public void mapRowsetAccess(ScrollableRowsetAccess target)
    {
        DataItemImpl di = getDataItemImpl();
        boolean published = (di != null && di.isPublished());

        if (di != null)
        {
            di.revoke();
        }
        
        if (target != null)
        {
            MappingRowsetAccessImpl map = new MappingRowsetAccessImpl();
            RowsetAccessImpl rai = (RowsetAccessImpl)getDataItem();
            DacObject parent = rai.getParent();
            DacObject[] kids = rai.getChildren();

            parent.removeChild(rai);
            rai.removeChildren();
            map.setName("Mapping"+getName());
            map.setSource(rai.getSource());
            map.setProducerObject(this);
            map.setRowSet(getViewObject());
            map.setBufferSize(_rangeSize);
            map.setTarget((RowsetAccessImpl)target);
            map.setChildren(kids);
            parent.addChild(map);
            setDataItem(map);
            if (published)
            {
                map.publish();
            }
        }
        else
        {
            setDataItem(null);
        }
    } // getRowsetAccess


    /**
    **  Returns that DataItem for this RowSet.  The DataItem is implemented
    **  by RowsetAccessImpl and exposes the RowsetAccess,
    **  ScrollableRowsetAccess and RowsetValidate InfoBus interfaces.
    **
    **  @return DataItem
    **  @see    RowsetAccessImpl
    */
    protected DataItem getDataItem()
    {
        // _debug("getDataItem");
        DacObject parent = getSession();
        RowsetAccessImpl di = (RowsetAccessImpl)super.getDataItem();

        if (parent != null)
        {
            parent = (DataItemImpl)((ProducerObject)parent).getDataItem();
        }
        if (di == null)
        {
            // Create the dataItem
            di = new RowsetAccessImpl(getName(), getDataProducer(), this,
                                      parent);
            setDataItem(di);
            if (isOpen())
            {
                di.setRowSet(_viewObj == null ? null : _viewObj.getRowSet());
                di.setBufferSize(_rangeSize);
            }
        }
        return(di);
    }

    /**
    **  Convienence function for calling open().
    **
    **  @see #open
    **  @see InfoObject#open
    */
    protected void openRowSet()
    {
        // _debug("openRowSet");
        open(true);
    } // openQueryView


    // Package protected methods
    RowState _getRowState()
    {
        // _debug("_getRowState");
        RowState rowState = null;
        if (_viewObj != null)
        {
            String propColName = InfoObject.PROPERTIES_COLUMN_NAME + getName();
            try
            {
                synchronized(_viewObj)
                {
                    Row r = _viewObj.getCurrentRow();
                    if (r != null)
                    {
                        byte[] ba = (byte[])r.getAttribute(propColName);
                        if (ba == null)
                        {
                            rowState = new RowState(getNumOfChildren());
                            _setRowState(rowState);
                        }
                        else
                        {
                            ByteArrayInputStream bais =
                                new ByteArrayInputStream(ba);
                            ObjectInputStream ois =
                                new ObjectInputStream(bais);
                        
                            rowState = (RowState)ois.readObject();
                        }
                    }
                }
            }
            catch(Exception e)
            {
                Object args[] = { propColName, e.getMessage()};
                String errCode = Res.getString(Res.ERR_RESULTSET_GET_PROP_COL);
                String msg = Res.getString(Res.ERR_RESULTSET_GET_PROP_COL_MSG);
                DacfErrorMessageContext emc =
                    new DacfErrorMessageContext(getDataItem(),
                                                propColName,
                                                null,
                                                -1,
                                                e,
                                                null);
                ErrorMessageText s =
                    new ErrorMessageText(ERR_PROD_CODE + "-" + errCode,
                                         MessageFormat.format(msg,args));
                ErrorMessage em =
                    new ErrorMessage(this,
                                     DacfType.SERVER_APPLICATION,
                                     DacfSeverity.WARNING, s, emc);

                ErrorManager.addErrorMessage(em);
            }
        }
        return(rowState);
    }

    void _setRowState(RowState rowState)
    {
        // _debug("_setRowState");
        if (_viewObj != null && rowState != null)
        {
            String propColName = InfoObject.PROPERTIES_COLUMN_NAME + getName();
            try
            {
                synchronized(_viewObj)
                {
                    Row currow = _viewObj.getCurrentRow();

                    if (currow != null)
                    {
                        ByteArrayOutputStream baos =
                            new ByteArrayOutputStream();
                        ObjectOutputStream oos = new ObjectOutputStream(baos);
                    
                        oos.writeObject(rowState);
                        currow.setAttribute(propColName, baos.toByteArray());
                    }
                }
            }
            catch(Exception e)
            {
                Object args[] = { propColName, e.getMessage()};
                String errCode =
                    Res.getString(Res.ERR_RESULTSET_SET_PROP_COL);
                String msg = Res.getString(Res.ERR_RESULTSET_SET_PROP_COL_MSG);
                DacfErrorMessageContext emc =
                    new DacfErrorMessageContext(getDataItem(),
                                                propColName,
                                                null,
                                                -1,
                                                e,
                                                null);
                ErrorMessageText s =
                    new ErrorMessageText(ERR_PROD_CODE + "-" + errCode,
                                         MessageFormat.format(msg,args));
                ErrorMessage em =
                    new ErrorMessage(this,
                                     DacfType.SERVER_APPLICATION,
                                     DacfSeverity.WARNING,
                                     s, emc);

                ErrorManager.addErrorMessage(em);
            }
        }
    }

    /**
    **  Creates a dynamic attribute in the BC4J ViewObject.
    */
    protected AttributeDef createDynamicAttribute(String name)
    {
        AttributeDef dynaCol = null;

        if (isOpen())
        {
            dynaCol = createDynamicAttributeInternal(name);
        }
        return(dynaCol);
    }


    /**
    ** Returns the index of this DacObject's specified child.
    **
    ** @return the 0-based index of the given child.
    ** @exception IllegalArgumentException if the specified child cannot be
    **                                     found.
    */
    protected int getChildIndex(String childName)
    {
        DacObject[] children = getChildren();
        for(int i = 0, index = 0; i < children.length ; i++)
        {
            if (isSpecialItemName(children[i].getName()))
            {
                continue;
            }
            if (children[i].getName().equals(childName))
            {
                return(index);
            }
            index++;
        }
        throw new IllegalArgumentException("Unable to find child "+childName);
    }

    protected boolean isSpecialItemName(String name)
    {
        return(_specialItems.get(name) != null);
    }

    // Private methods
    private void _createPropertyColumn()
    {
        if (_viewObj != null)
        {
            String name = getName();
            int index = name.lastIndexOf(".");

            name = InfoObject.PROPERTIES_COLUMN_NAME +
                ((index != -1) ? name.substring(index+1) : name);
            createDynamicAttributeInternal(name);
        }
    }

    protected AttributeDef createDynamicAttributeInternal(String name)
    {
        AttributeDef dynaCol = null;

        if (_viewObj != null)
        {
            try
            {
                dynaCol = _viewObj.findAttributeDef(name);
            }
            catch(NoDefException ex)
            {
                dynaCol = _viewObj.addDynamicAttribute(name);
            }
        }
        return(dynaCol);
    }


    private void _setViewCriteriaValues()
    {
        if (_queryCriteria != null && _viewObj != null)
        {
            ViewCriteria vc = null;
            QueryCriteriaRow[] qcr =
                _queryCriteria.getCriteriaStore().getAllRows();

            _viewObj.applyViewCriteria(null); // clear the current ViewCriteria
            if (qcr.length > 0)
            {
                String name;
                ViewCriteriaRow vcr;
                DacObject[] cols = _queryCriteria.getChildren();

                vc = _viewObj.createViewCriteria();
                for(int i = 0; i < qcr.length; i++)
                {
                    if (!qcr[i].isRowEmpty())
                    {
                        vcr = vc.createViewCriteriaRow();
                        for(int j = 0; j < cols.length; j++)
                        {
                            name = cols[j].getName();
                            if (!qcr[i].isAttributeEmpty(name))
                            {
                                vcr.setAttribute(name,
                                                 qcr[i].getAttribute(name));
                            }
                        }
			vcr.setUpperColumns(qcr[i].isUpperColumns());
                        vc.addElement(vcr);
                    }
                }
            }
            if (vc != null && !vc.isEmpty())
            {
                _viewObj.applyViewCriteria(vc);
            }
        }
    }

    /**
    ** Prints debugging information to <TT>System.out</TT> if debugging is
    ** enabled. <P>
    **
    ** @param s The string to print.
    */
    private void _debug(String s)
    {
        if (_DEBUG)
        {
            System.out.println("ResultSetInfo: " + s);
        }
    }
}


