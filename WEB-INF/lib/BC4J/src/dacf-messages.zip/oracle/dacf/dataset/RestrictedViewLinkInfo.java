/*
 * @(#)RestrictedViewLinkInfo.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.dacf.dataset;

import oracle.jbo.AttributeDef;
import oracle.jbo.ViewObject;

// imports
/**
 **      This class is used to specify a complex where clause joining two
 **      ViewObjects.
 **
 ** @version SDK
 */
public class RestrictedViewLinkInfo
    extends ViewLinkInfo
{
    private String _whereClause;
    private static final boolean _DEBUG = true;
    
    public RestrictedViewLinkInfo()
    {
        
    } // RestrictedViewLinkInfo
    
    public RestrictedViewLinkInfo(RowSetInfo master, String viewLinkName,
                              String whereClause)
    {
        super(master, viewLinkName);
        setWhereClause(whereClause);
    } // RestrictedViewLinkInfo
    
    public synchronized Object clone()
    {
        return(new RestrictedViewLinkInfo(_master, _viewLinkName,
                                          _whereClause));
    }

    /**
    ** Set the where clause joining the two views. <P>
    **
    ** @param whereClause the where clause joining the two views
    */
    public void setWhereClause(String whereClause)
    {
        _whereClause = whereClause;
    } // setWhereClause
    
    /**
    ** Returns the where clause joining the two views.<P>
    **
    ** @return the where clause joining the two views
    */
    public String getWhereClause()
    {
        return(_whereClause);
    } // getWhereClause
    
    /**
    **  Creates the link between the master RowSetInfo and the detail
    **  RowSetInfo within the context of the specified ApplicationModule.
    **
    **  Internal to the client framework and should not be used by client
    **  classes
    */
    public void createViewLink(String accessorName,
                               RowSetInfo master, String[] masterLinkCols,
                               RowSetInfo detail, String[] detailLinkCols)
    {
        if (master != null && detail != null &&
            masterLinkCols.length == detailLinkCols.length)
        {
            DacObject accessor;
            AttributeDef[] srcAttrs =
                findAttributeDefs(master, masterLinkCols);
            AttributeDef[] destAttrs =
                findAttributeDefs(detail, detailLinkCols);

            if (srcAttrs!= null && destAttrs != null)
            {
                ViewObject masterVO = master.getViewObject();

                // Pass an empty name to the creation method.  Allow the creation
                // method to generate a name for the view link.
                masterVO.getApplicationModule().createViewLinkBetweenViewObjects(
                   ""
                   , accessorName
                   , masterVO
                   , srcAttrs
                   , detail.getViewObject()
                   , destAttrs
                   , _whereClause);
            }

            master.findViewLinks();
            accessor = master.getChild(accessorName);
            if (accessor != null && accessor instanceof ProducerObject)
            {
                ((ProducerObject)accessor).open(true); // open all children
            }
        }
    }

    protected AttributeDef[] findAttributeDefs(RowSetInfo rs, String[] colList)
    {
        ColumnInfo col = null;
        AttributeDef[] attrs = new AttributeDef[colList.length];

        for(int i = 0; i < colList.length; i++)
        {
            col = _findColumn(rs, colList[i]);
            if (col == null)
            {
                break;
            }
            attrs[i] = col.getAttributeDef();
        }

        return(col == null ? null : attrs);
    }

    private ColumnInfo _findColumn(ResultSetInfo r, String colname)
    {
        ColumnInfo col = null;
        DacObject[] kids = r.getChildren();

        for(int i = 0; i < kids.length; i++)
        {
            if (kids[i] instanceof ColumnInfo &&
                colname.equals(((ColumnInfo)kids[i]).getDataSourceName()))
            {
                col = (ColumnInfo)kids[i];
                break;
            }
        }
        return(col);
    }
    private void _debug(String s)
    {
        if (_DEBUG)
        {
            System.out.println("RestrictedViewLinkInfo: " + s);
        }        
    } // _debug
    
}  // RestrictedViewLinkInfo

