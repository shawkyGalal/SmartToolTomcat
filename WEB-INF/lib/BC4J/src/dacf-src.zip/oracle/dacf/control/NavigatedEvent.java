/*
 * @(#)NavigatedEvent.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.dacf.control;

import java.util.EventObject;

/**
 * NavigatedEvent is used by a Control to notify it's listener's
 * about the type and level of navigation change that occurs
 * when focus changes from control to another. <P>
 *
 * @see Control#addNavigatedListener()
 * @see NavigatedListener
 *
 */
public class NavigatedEvent
    extends EventObject
{
    public static final int NAVIGATE_IN         = 0;
    public static final int NAVIGATE_OUT        = 1;
    
    /**
    *  Constructs a NavigatedEvent object of the given type
    *  and level </P>
    *
    *  @param source  The source Control firing the event.
    *  @param type    Type of the event. Either NAVIGATE_IN or NAVIGATE_OUT.
    *  @param level   Level of change. Should be one of: </P>
    * <UL>
    * <LI>InfoObject.LEVEL_COLUMN
    * <LI>InfoObject.LEVEL_ROW
    * <LI>InfoObject.LEVEL_ROWSET
    * <LI>InfoObject.LEVEL_SESSION
    * </UL>
    */
    public NavigatedEvent(Control source, int type, int level) {
        super(source);
        _type = type;
        _level = level;
    }
    
    /**
    *  Returns the type of the event. </P>
    *  @return  Type of event
    */
    public final int getType() {
        return (_type);
    }
    
    /**
    *  Returns the level of the event. </P>
    *  @return  level of event
    */
    
    public final int getLevel() {
        return (_level);
    }
    
    
    /**
    * Returns a String representaion of this object
    * @return The string representation
    */
    public String toString() {
        Object source = getSource();
        return ("NavigatedEvent: source=" +
                ((source == null) ? "null" : ((Control)source).getDataItemName()) +
                " type=" + _type + " level=" + _level);
    }
    
    
    private int _type;
    private int _level;
}

