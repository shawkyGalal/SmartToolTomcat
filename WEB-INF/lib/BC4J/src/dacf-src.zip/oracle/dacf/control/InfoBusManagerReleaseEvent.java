/*
 * @(#)InfoBusManagerReleaseEvent.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.dacf.control;

import java.awt.Component;
import java.awt.Container;
import java.util.EventObject;

// imports
/**
 **    Delivers the a reference to the Container that causing the release of
 **    resource fo InfoBusMembers.<br>
 **    This most typically will occur when a container such as a frame is being
 **    "closed" but it could also apply to a panel that is being "destroyed".
 **
 */
public class InfoBusManagerReleaseEvent
    extends EventObject
{
    Container _container;
    private static final boolean _DEBUG = true;
    
    public InfoBusManagerReleaseEvent(Object source, Container c)
    {
        super(source);
        _container = c;
    } // InfoBusManagerReleaseEvent
    
    public Container getContainer()
    {
        return(_container);
    }

    public boolean appliesTo(Component c)
    {
        return((Component)_container == c || _container.isAncestorOf(c));
    }

    private void _debug(String s)
    {
        if (_DEBUG)
        {
            System.out.println("InfoBusManagerReleaseEvent: " + s);
        }        
    } // _debug
    
}  // InfoBusManagerReleaseEvent


