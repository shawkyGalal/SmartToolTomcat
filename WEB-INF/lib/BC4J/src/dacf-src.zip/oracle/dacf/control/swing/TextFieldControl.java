/*
 * @(#)TextFieldControl.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.dacf.control.swing;

import java.awt.Component;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.util.Locale;
import javax.infobus.DataItem;
import javax.infobus.DataItemAddedEvent;
import javax.infobus.DataItemDeletedEvent;
import javax.infobus.DataItemRevokedEvent;
import javax.infobus.DataItemValueChangedEvent;
import javax.infobus.ImmediateAccess;
import javax.infobus.InvalidDataException;
import javax.infobus.RowsetCursorMovedEvent;
import javax.infobus.UnsupportedOperationException;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;
import oracle.dacf.control.ApplyEditsListener;
import oracle.dacf.control.ApplyEditsValidationException;
import oracle.dacf.control.Control;
import oracle.dacf.control.ControlEnabledListener;
import oracle.dacf.control.ControlSupport;
import oracle.dacf.control.InfoBusManager;
import oracle.dacf.control.InfoBusManagerListener;
import oracle.dacf.control.InfoBusManagerReleaseEvent;
import oracle.dacf.control.NavigatedEvent;
import oracle.dacf.control.NavigatedListener;
import oracle.dacf.control.NavigatingEvent;
import oracle.dacf.control.NavigatingException;
import oracle.dacf.control.NavigatingListener;
import oracle.dacf.control.NavigationManager;
import oracle.dacf.dataset.DataItemProperties;

/**
 * A data aware control to display and edit an <TT>ImmediateAccess</TT>
 * text item.<P>
 *
 * @version PUBLIC
 */
public class TextFieldControl
    extends JTextField
    implements Control, ImmediateAccess, FocusListener, ControlEnabledListener,
               ApplyEditsListener, InfoBusManagerListener
{
    private boolean _revertValueOnError = false;
    private ControlSupport _controlSupport;

    // Bug 1696519
    private boolean mIsDisabledWhenNotUpdateable = false;
    
    private boolean _trimSpaces = true;

    private static final int DEFAULT_FIELD_SIZE = 9; // What's a good size?
    private static final boolean _DEBUG = false;

    /**
    * Constructs a default TextFieldControl
    */
    public TextFieldControl()
    {
        this("",DEFAULT_FIELD_SIZE);
    }

    /**
    * Constructs a new TextFieldControl initialized with the specified text.
    *
    * @param text the text to be displayed
    */
    public TextFieldControl(String text)
    {
        this(text, DEFAULT_FIELD_SIZE);
    }


    /**
    * Constructs a TextFieldControl with the specified size
    *
    * @param columns number of columsn to display in the
    */
    public TextFieldControl(int columns)
    {
        this("",columns);
    }

    /**
    * Constructs a new TextFieldControl initialized with the specified text
    * and columns.
    *
    * @param text the text to be displayed
    * @param columns the number of columns
    */
    public TextFieldControl(String text, int columns)
    {
        super(text, columns);
        _controlSupport = new ControlSupport(this);
        _controlSupport.addControlEnabledListener(this);
        InfoBusManager.getInstance().addInfoBusManagerListener(this);
        addFocusListener(this);
    }

    /**
    **  Sets the value for the RevertValueOnError property
    **
    **  When this property is set to <tt>true</tt> then the TextFieldControl
    **  will revert to the value displayed prior to being edited.
    **
    ** @param revertIt the value for the RevertValueOnError property
    ** @see #<method>(<sig>)
    ** @see <Class>#<method>(<sig>)
    */
    public void setRevertValueOnError(boolean revertIt)
    {
        _revertValueOnError = revertIt;
    } // setRevertValueOnError

    /**
    **  Returns the value for the RevertValueOnError property
    **
    **  When this property is set to <tt>true</tt> then the TextFieldControl
    **  will revert to the value displayed prior to being edited.
    **
    ** @return the value for the RevertValueOnError property
    ** @see #<method>(<sig>)
    ** @see <Class>#<method>(<sig>)
    */
    public boolean getRevertValueOnError()
    {
        return(_revertValueOnError);
    } // getRevertValueOnError
    
    /**
    **  Sets the value for the TrimSpaces property
    **
    **  When this property is set to <tt>true</tt> then the TextFieldControl
    **  will trim the leading and trailing blank characters
    **
    ** @param trimIt the value for the TrimSpaces property
    ** @see #<method>(<sig>)
    ** @see <Class>#<method>(<sig>)
    */
    public void setTrimSpaces(boolean trimIt)
    {
        _trimSpaces = trimIt;
    } 

    /**
    **  Returns the value for the TrimSpaces property
    **
    */
    public boolean getTrimSpaces()
    {
      return _trimSpaces;
    }


    // ControlEnabledListener interface
    public void enabledChanged(boolean b)
    {
        super.setEnabled(b);
    }

    // InfoBusManagerListener interface implementation
    public void releaseResources(InfoBusManagerReleaseEvent e)
    {
        if (e.appliesTo(this))
        {
            InfoBusManager.getInstance().removeInfoBusManagerListener(this);
            removeFocusListener(this);
            _controlSupport.removeControlEnabledListener(this);
            _controlSupport = null;
        }
    }

    // Control Interface

    /**
    ** An override of java.awt.Component.setEnabled. <P>
    **
    ** @param b boolean flag indicating whether the control is enabled
    */
    public void setEnabled(boolean b)
    {
        super.setEnabled(b);
        if (_controlSupport != null)
        {
            _controlSupport.setEnabled(b);
        }
    } // setEnabled

    public void setEditable(boolean b)
    {
       super.setEditable(b);

       if (isDisabledWhenNotUpdateable())
       {
          setEnabled(b);
       }
    }

    /**
    * Returns the name of the InfoBus this control is connected to. <P>
    * Most controls should delegate this method to <TT>ControlSupport</TT>. <P>
    * @return  The name of the InfoBus this control is connected to.
    * @see ControlSupport#getInfoBusName
    */
    public final String getInfoBusName()
    {
        return(_controlSupport == null ?
               null : _controlSupport.getInfoBusName());
    }

    /**
    * Sets the name of the InfoBus this control is connected to. <P>
    * If the named InfoBus does not exist, it is created automatically. <P>
    * If the control is already connected to an InfoBus, it is disconnected
    * first. <P>
    * Most controls should delegate this method to <TT>ControlSupport</TT>. <P>
    * @param infoBusName   The name of the InfoBus to connect to.
    * @see ControlSupport#setInfoBusName
    */

    public final void setInfoBusName(String infoBusName)
    {
        if (_controlSupport != null)
        {
            _controlSupport.setInfoBusName(infoBusName);
        }
    }

    /**
    * Returns the name of the InfoBus DataItem this control is bound to. <P>
    * Most controls should delegate this method to <TT>ControlSupport</TT>. <P>
    * @return  The name of the InfoBus DataItem this control is bound to,
    *          or <TT>null</TT> if the control is unbound.
    * @see #getDataItem
    * @see ControlSupport#getDataItemName
    */

    public final String getDataItemName()
    {
        return(_controlSupport == null ?
               null : _controlSupport.getDataItemName());
    }

    /**
    * Sets the name of the InfoBus DataItem this control is bound to. <P>
    * The DataItem with the given name is searched for on the InfoBus, and
    * if found, is bound to this control. <P>
    * If the control is already bound to a DataItem, it is unbound first. <P>
    * Most controls should delegate this method to <TT>ControlSupport</TT>. <P>
    * @param dataItemName  The name of the DataItem to bind to.
    * @see #getDataItem
    * @see ControlSupport#setDataItemName
    */
    public final void setDataItemName(String dataItemName)
    {
        if (_controlSupport != null)
        {
            _controlSupport.setDataItemName(dataItemName);
        }
    }

    /**
    * Returns the InfoBus DataItem this control is bound to. <P>
    * @return  The InfoBus DataItem this control is bound to, or
    *          <TT>null</TT> if the control is unbound.
    * @see ControlSupport#getDataItem
    */

    public final Object getDataItem()
    {
        return(_controlSupport == null ?
               null : _controlSupport.getDataItem());
    }



    /**
    * Notifies the control that the bound InfoBus DataItem has changed. <P>
    * The control can safely ignore this notification. <P>
    * @param oldDataItem   The formerly bound DataItem (can be <TT>null</TT>).
    * @param newDataItem   The newly bound DataItem (can be <TT>null</TT>).
    */
    public final void dataItemChanged(Object oldDataItem, Object newDataItem)
    {
        // Don't care
    }

    /**
    * Returns the AWT component associated with this control. <P>
    * @return  The AWT component for this control.
    */
    public final Component getComponent()
    {
        return (this);
    }

    /**
    * Determines whether focus into this control causes validation to
    * occur. <P>
    * Most controls should delegate this method to <TT>ControlSupport</TT>. <P>
    * @return  <TT>true</TT> if focus into this control causes validation to
    *          occur, <TT>false</TT> otherwise.
    * @see ControlSupport#isFocusValidated
    */
    public final boolean isFocusValidated()
    {
        return(_controlSupport == null ?
               false : _controlSupport.isFocusValidated());
    }

    /**
    * Sets whether focus into this control causes validation to occur. <P>
    * Delegates to <TT>ControlSupport</TT>. <P>
    * @param focusValidated    If <TT>true</TT>, focus into this control will
    *                          cause validation to occur.
    * @see ControlSupport#setFocusValidated
    */
    public final void setFocusValidated(boolean focusValidated)
    {
        if (_controlSupport != null)
        {
            _controlSupport.setFocusValidated(focusValidated);
        }
    }

    /**
    * Adds a navigated listener to this control. <P>
    * The listener will be notified of NavigateIn and NavigateOut events. <P>
    * Delegates to <TT>ControlSupport</TT>. <P>
    * @param listener  The listener to add.
    * @see ControlSupport#addNavigatedListener
    */

    public final void addNavigatedListener(NavigatedListener listener)
    {
        if (_controlSupport != null)
        {
            _controlSupport.addNavigatedListener(listener);
        }
    }

    /**
    * Removes a navigated listener from this control. <P>
    * @param listener  The listener to remove.
    */
    public final void removeNavigatedListener(NavigatedListener listener)
    {
        if (_controlSupport != null)
        {
            _controlSupport.removeNavigatedListener(listener);
        }
    }

    /**
    * Processes a navigated event for this control. <P>
    * This method is for use by the NavigationManager only. <P>
    * @param event The navigated event.
    * @see ControlSupport#processNavigatedEvent
    */
    public final void processNavigatedEvent(NavigatedEvent event)
    {
        if (_controlSupport != null)
        {
            _controlSupport.processNavigatedEvent(event);
        }
    }

    /**
    * Adds a navigating listener to this control. <P>
    * The listener will be notified of NavigatingEvents. <P>
    * @param listener  The listener to add.
    */
    public final void addNavigatingListener(NavigatingListener listener)
    {
        if (_controlSupport != null)
        {
            _controlSupport.addNavigatingListener(listener);
        }
    }

    /**
    * Removes a previusly added navigating listener <P>
    * @param listener  The listener to remove.
    */

    public final void removeNavigatingListener(NavigatingListener listener)
    {
        if (_controlSupport != null)
        {
            _controlSupport.removeNavigatingListener(listener);
        }
    }

    /**
    * Processes a navigating event for this control. <P>
    * This method is for use by the NavigationManager only. <P>
    * @param event The navigating event.
    * @exception   NavigatingException    Indicates navigation was rejected.
    * @see ControlSupport#processNavigatedEvent
    */
    public final void processNavigatingEvent(NavigatingEvent event)
        throws NavigatingException
    {
        if (_controlSupport != null)
        {
            _controlSupport.processNavigatingEvent(event);
        }
    }



    // DataItemChangeListener Interface

    /**
    * Indicates a changed value in the bound data item. <P>
    * A reference to the data item that changed can be obtained from the
    * event. <P>
    * @param event Contains change information.
    * @see javax.infobus.DataItemChangeListener#dataItemValueChanged
    */
    public final void dataItemValueChanged(DataItemValueChangedEvent event)
    {
        if ( SwingUtilities.isEventDispatchThread())
        {
            _updateValue(event.getChangedItem());
        }
        else
        {
            _updateValueNow(event.getChangedItem());
        }
    }

    /**
    * Indicates that a new item was added to the bound aggregate data item
    * (e.g. <TT>ArrayAccess</TT>, a JDK Collection, etc). <P>
    * A reference to the data item that was added, and a reference to the one
    * that gained it, can be obtained from the event. <P>
    * @param event Contains details of the addition.
    * @see javax.infobus.DataItemChangeListener#dataItemAdded
    */
    public final void dataItemAdded(DataItemAddedEvent event)
    {
        // Not applicable
    }

    /**
    * Indicates that an item was deleted from the bound aggregate data item
    * (e. g. <TT>ArrayAccess</TT>, a JDK Collection, etc). <P>
    * A reference to the data item that was deleted, and a reference to the
    * one that lost it, can be obtained from the event. <P>
    * @param event Contains details of the deletion.
    * @see javax.infobus.DataItemChangeListener#dataItemDeleted
    */
    public final void dataItemDeleted(DataItemDeletedEvent event)
    {
        // Not applicable
    }

    /**
    * Indicates that the bound data item (and its sub-items, if any) has been
    * revoked, and is temporarily unavailable. <P>
    * A reference to the data item that was revoked can be obtained from
    * the event. <P>
    * @param event Contains details of the revoked data.
    * @see javax.infobus.DataItemChangeListener#dataItemRevoked
    */
    public final void dataItemRevoked(DataItemRevokedEvent event)
    {
        // Not applicable
    }

    /**
    * Indicates that the cursor for the bound <TT>RowsetAccess</TT> data item
    * has changed rows. <P>
    * A reference to the rowset data item can be obtained from the event. <P>
    * @param event Contains details of the cursor move.
    * @see javax.infobus.DataItemChangeListener#rowsetCursorMoved
    */
    public final void rowsetCursorMoved(RowsetCursorMovedEvent event)
    {
        // Not applicable
    }


    // ImmediateAccess Interface

    /**
    * Gets the entered text as a String. <P>
    * @return Text entered in the control
    */

    public String getValueAsString()
    {
        return (getText());
    }

    /**
    * Gets the entered text as an Object. <P>
    * @return Text entered in the control
    */
    public Object getValueAsObject()
    {
        return (getText());
    }

    /**
    * Gets the entered text as a String. <P>
    * @return Text entered in the control
    */
    public String getPresentationString(Locale locale)
    {
        return (getText());
    }

    /**
    *  This method is not supported and always throws an exception
    *  @exception InvalidDataException Always thrown
    */
    public void setValue(Object newValue)
        throws InvalidDataException
    {
        throw (new UnsupportedOperationException(Res.getString(Res.SETVALUE_NOT_SUPPORTED)));
    }

    //FocusListener implementation
    /**
    * This method is an implementaion side effect
    */
    public void focusLost(FocusEvent event)
    {
        // _debug("FocusLost: " + this);
    }

    /**
    * This method is an implementaion side effect
    */
    public void focusGained(FocusEvent event)
    {
        if (isFocusValidated())
        {
            NavigationManager nm = NavigationManager.getNavigationManager();
            nm.validateFocusChange(this);
        }
    }



    /**
    * This method is an implementaion side effect
    */
    public void postActionEvent()
    {
        try
        {
            _applyEdits();
        }
        catch (InvalidDataException e)
        {
        }
        super.postActionEvent();
    }

    public String toString()
    {
        return (super.toString() + "[" + getDataItemName() + "]");
    }

    // ApplyEditsListener implementation
    public void applyEdits()
    {
        try
        {
            _applyEdits();
        }
        catch(InvalidDataException e)
        {
            throw new ApplyEditsValidationException(e.getMessage());
        }
    }

    public void cancelEdits()
    {
        if ( SwingUtilities.isEventDispatchThread())
        {
            _updateValue(getDataItem());
        }
        else
        {
            _updateValueNow(getDataItem());
        }
    }

    public void setDisabledWhenNotUpdateable(boolean isDisabledWhenNotUpdateable)
    {
       mIsDisabledWhenNotUpdateable = isDisabledWhenNotUpdateable;
    }

    public boolean isDisabledWhenNotUpdateable()
    {
       return mIsDisabledWhenNotUpdateable;
    }

    // Private Methods

    private void _applyEdits()
        throws InvalidDataException
    {
        Object dataItem = getDataItem();
        
        if (dataItem != null && dataItem instanceof ImmediateAccess)
        {
            ImmediateAccess ia = (ImmediateAccess)dataItem;
            String oldValue = ia.getPresentationString(Locale.getDefault());
            if (!oldValue.equals(getText()))
            {
                try
                {
                   ia.setValue(this);
                }
                catch(InvalidDataException e)
                {
                    if (_revertValueOnError)
                    {
                        _updateValueLater(dataItem);
                    }
                    throw e;
                }
            }
        }
    }

    private void _updateValueLater(final Object dataItem)
    {
        SwingUtilities.invokeLater(
                                   new Runnable()
                                   {
                                       public void run()
                                           {
                                               _updateValue(dataItem);
                                           }
                                   }
                                   );
    }

    private void _updateValueNow(final Object dataItem)
    {
        try
        {

           SwingUtilities.invokeAndWait(
                     new Runnable()
                     {
                         public void run()
                         {
                             _updateValue(dataItem);
                         }
                     }
           );
        }
        catch(Exception e)
        {
        }
    }


    private void _updateValue(Object dataItem)
    {
        String value = null;
        if (dataItem != null && dataItem instanceof ImmediateAccess)
        {
            Boolean updateable = null;

            value = ((ImmediateAccess)dataItem).getPresentationString(Locale.getDefault());

            if (dataItem instanceof DataItem)
            {
                updateable =
                    (Boolean)((DataItem)dataItem).getProperty(DataItemProperties.UPDATEABLE);
            }
            if (updateable != null)
            {
                // only enable the control if it is updateable
                setEditable(updateable.booleanValue());
            }
        }
        // _debug("setText: > " + ((value != null) ? value.trim() : "") + "<");
        
        if (value != null)
        {
            setText(  (getTrimSpaces() ? value.trim() : value));
        }
        else
        {
          setText("");
        }
    }

    private void _debug(String msg)
    {
        if (_DEBUG)
        {
            System.out.println("TextFieldControl: " + msg);
        }
    }
}


