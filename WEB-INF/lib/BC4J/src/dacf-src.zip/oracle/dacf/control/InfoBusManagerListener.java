/*
 * @(#)InfoBusManagerListener.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.dacf.control;

public interface InfoBusManagerListener
{
    /**
    **  A signalling method used to indicate the the control should free
    **  all resources and unregister any listeners that it has registered.
    */
    public void releaseResources(InfoBusManagerReleaseEvent e);
}  // InfoBusManagerListener

