/*
 * @(#)ContainerControl.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.dacf.control;

// imports
/**
 ** An interface that a Control implements when it is a container like the
 ** GridControl.  It allows the NavigationManager to call the control to move
 ** the row currency after the validation events have been fired and prior to
 ** firing the navigation events.
 **
 */
public interface ContainerControl
{
    /**
    **  Returns true if a ContainerControl (e.g. GridControl) successfully
    **  changes the row currency.<p>
    **  This method is called during the navigation process by the
    **  NavigationManager and should not be called directly.
    */
    public boolean changeCurrency();
}  // ContainerControl
