/*
 * @(#)LabelAwareChartDataSource.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.dacf.control.tdg.chart;

import oracle.dacf.control.tdg.ChartControl;
import oracle.dacf.util.ItemNameTokenizer;

/**
 *  Data source for the chart control which implements
 *  method to return labels.
 *
 *  By default column 0 is used as labels for the row
 *
 *  @see ChartLabelDataSource
 */
public class LabelAwareChartDataSource
      extends MappedChartDataSource
{
    private static final int ROWSET_ITEM_NAME_COUNT=4; //infobus:/oracle/Sess1/Row1
    private static final int COLUMN_ITEM_NAME_COUNT=5; //infobus:/oracle/Sess1/Row1/Col1


    protected boolean _useFirstColumnAsRowLabel = true;
    private ChartLabelDataSource      _rowLabelDataSource =
                                              new ChartLabelDataSourceImpl(this);;
    private ChartLabelDataSource      _colLabelDataSource =
                                              new ChartLabelDataSourceImpl(this);
    /**
    *  Constructor
    */
    public LabelAwareChartDataSource(ChartControl parent)
    {
        super(parent);
        setUseFirstColumnAsRowLabel(true);
    }

    public void setUseFirstColumnAsRowLabel(boolean flag)
    {
        _useFirstColumnAsRowLabel = flag;
    }

    public boolean getUseFirstColumnAsRowLabel()
    {
        return _useFirstColumnAsRowLabel;
    }

    public String columnLabel(int i)
    {
        String label = "";
        if ( _useFirstColumnAsRowLabel )
           label = _colLabelDataSource.getLabel(i+1);
        else
           label = _colLabelDataSource.getLabel(i);
        return label;
    }

    public int getColumns()
    {
        int count = super.getColumns();
        if ( _useFirstColumnAsRowLabel)
            return (count - 1);
        return count;

    }


    public String rowLabel(int i)
    {
        if ( _useFirstColumnAsRowLabel )
        {
           //first column is a row label
           Object o = super.getValue(i,0);
           return ((o==null) ? "" : o.toString());
        }
        else
           return _rowLabelDataSource.getLabel(i);
    }

    public int getRows()
    {
        return super.getRows();
    }

    public Object getValue(int row, int col)
    {
        if ( _useFirstColumnAsRowLabel )
           return (super.getValue(row, col+1));
        else
           return super.getValue(row,col);
    }

    /**
    * Specify data source for row labels. The labels could be
    * <UL>
    * <LI> column values of a table
    * <LI> column names (display names) of a table
    * </UL>
    * <P>
    * The dataitem name of the column should be specified to indicate
    * the column values of a table
    *<P> The dataitem name of the rowset should be specified to indicate
    * the column display name of some table
    *
    * @see setRowLabelDataSource(Object)
    * @param dataitemName of the column values or the rowset
    */
    public void setRowLabelDataItemName(String dataItemName)
    {
         setUseFirstColumnAsRowLabel(false);
         ChartLabelDataSourceImpl impl = _getImpl(dataItemName);
         if (impl != null)
         {
            _rowLabelDataSource = impl;
            ((ChartLabelDataSourceImpl)
                 _rowLabelDataSource).setDataItemName(dataItemName);
           _updateChart();
         }
         else
         {
           if (_rowLabelDataSource instanceof ChartLabelDataSourceImpl)
                ((ChartLabelDataSourceImpl)
                       _rowLabelDataSource).setDataItemName(dataItemName);
          }
    }

    /**
    *  data item name for the row labels, if used
    */
    public String getRowLabelDataItemName()
    {
        if (_rowLabelDataSource instanceof ChartLabelDataSourceImpl)
            return ((ChartLabelDataSourceImpl)
                             _rowLabelDataSource).getDataItemName();
        return "";
    }

    public void setRowLabelDataSource(ChartLabelDataSource labelSource )
    {
        setUseFirstColumnAsRowLabel(false);
        _rowLabelDataSource = labelSource;
        _updateChart();
    }

    public ChartLabelDataSource getRowLabelDataSource()
    {
        return _rowLabelDataSource;
    }

    public void setRowLabel(Object[] labels)
    {
       setUseFirstColumnAsRowLabel(false);
       ((ChartLabelDataSourceImpl)
                             _rowLabelDataSource).setLabels(labels);
       _updateChart();
    }

    public Object[] getRowLabel()
    {
       return ((ChartLabelDataSourceImpl)
                                    _rowLabelDataSource).getLabels();
    }

    /**
    * Specify data source for row labels. The labels could be
    * <UL>
    * <LI> column values of a table
    * <LI> column names (display names) of a table
    * </UL>
    * <P>
    * The dataitem name of the column should be specified to indicate
    * the column values of a table
    *<P> The dataitem name of the rowset should be specified to indicate
    * the column display name of some table
    *
    * @see setRowLabelDataSource(Object)
    * @param dataitemName of the column values or the rowset
    */
    public void setColumnLabelDataItemName(String dataItemName)
    {
       ChartLabelDataSourceImpl impl = _getImpl(dataItemName);
       if ( impl  != null)
       {
          _colLabelDataSource = impl;
          ((ChartLabelDataSourceImpl)
                   _colLabelDataSource).setDataItemName(dataItemName);
          _updateChart();
       }
       else
       {
          if (_colLabelDataSource instanceof ChartLabelDataSourceImpl)
                ((ChartLabelDataSourceImpl)
                       _colLabelDataSource).setDataItemName(dataItemName);
       }
    }

    /**
    *  data item name for the row labels, if used
    */
    public String getColumnLabelDataItemName()
    {
       if (_colLabelDataSource instanceof ChartLabelDataSourceImpl)
          return  ((ChartLabelDataSourceImpl)
                              _colLabelDataSource).getDataItemName();
       return "";
    }

    public void setColumnLabelDataSource(ChartLabelDataSource labelSource )
    {
        _colLabelDataSource = labelSource;
        _updateChart();
    }

    public ChartLabelDataSource getColumnLabelDataSource()
    {
        return _colLabelDataSource;
    }

    public void setColumnLabel(Object[] labels)
    {
       ((ChartLabelDataSourceImpl)
                             _colLabelDataSource).setLabels(labels);
       _updateChart();
    }

    public Object[] getColumnLabel()
    {
       return ((ChartLabelDataSourceImpl)
                                    _colLabelDataSource).getLabels();
    }

    /**
    * Determine if the dataitem name represents a rowset or a column and
    * return a datasource as appropriate
    */
    private ChartLabelDataSourceImpl _getImpl(String dataItemName)
    {
       if ( _isNameRepresentsRowset(dataItemName))
          return new ChartLabelTableColumnNames(this);
       else if ( _isNameRepresentsColumn(dataItemName))
          return new ChartLabelTableColumnValues(this);
       return null;
    }

    private boolean _isNameRepresentsRowset(String dataItemName)
    {
       if (_itemCount(dataItemName) == ROWSET_ITEM_NAME_COUNT)
          return true;
       return false;
    }

    private boolean _isNameRepresentsColumn(String dataItemName)
    {
       if (_itemCount(dataItemName) == COLUMN_ITEM_NAME_COUNT)
          return true;
       return false;
    }

    private int _itemCount(String dataItemName)
    {
       ItemNameTokenizer st = new ItemNameTokenizer(dataItemName);
       return st.countRemaining();
    }


}

