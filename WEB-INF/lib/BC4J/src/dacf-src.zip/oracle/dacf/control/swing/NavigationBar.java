/*
 * @(#)NavigationBar.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.dacf.control.swing;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Container;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.Frame;
import java.awt.Insets;
import java.awt.Point;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.net.URL;
import java.sql.SQLException;
import java.util.Vector;
import javax.infobus.DataItem;
import javax.infobus.DataItemAddedEvent;
import javax.infobus.DataItemChangeManager;
import javax.infobus.DataItemDeletedEvent;
import javax.infobus.DataItemRevokedEvent;
import javax.infobus.DataItemValueChangedEvent;
import javax.infobus.DbAccess;
import javax.infobus.ImmediateAccess;
import javax.infobus.RowsetAccess;
import javax.infobus.RowsetCursorMovedEvent;
import javax.infobus.RowsetValidationException;
import javax.infobus.ScrollableRowsetAccess;
import javax.swing.BorderFactory;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.JToolBar;
import javax.swing.SwingUtilities;
import oracle.dacf.control.ApplyEditsListener;
import oracle.dacf.control.Control;
import oracle.dacf.control.ControlSupport;
import oracle.dacf.control.CurrencyChangedEvent;
import oracle.dacf.control.CurrencyListener;
import oracle.dacf.control.InfoBusManager;
import oracle.dacf.control.InfoBusManagerListener;
import oracle.dacf.control.InfoBusManagerReleaseEvent;
import oracle.dacf.control.NavigatedEvent;
import oracle.dacf.control.NavigatedListener;
import oracle.dacf.control.NavigatingEvent;
import oracle.dacf.control.NavigatingException;
import oracle.dacf.control.NavigatingListener;
import oracle.dacf.control.NavigationManager;
import oracle.dacf.control.swing.find.FindPanelUI;
import oracle.dacf.dataset.AttributeInfo;
import oracle.dacf.dataset.DacfSeverity;
import oracle.dacf.dataset.DacfType;
import oracle.dacf.dataset.DataItemProperties;
import oracle.dacf.dataset.ExceptionProcessor;
import oracle.dacf.dataset.InfoObject;
import oracle.dacf.dataset.IteratorProperties;
import oracle.dacf.dataset.RowSetInfo;
import oracle.dacf.dataset.ValidationManager;

/**
 * Data aware toolbar. Can be bound to a ScrollableRowsetAccess dataitem
 * and can be used
 * to: <P>
 * <UL>
 * <LI> Iterate back and forth over the bound dataitem.</LI>
 * <LI> Insert a new row in the bound dataitem. </LI>
 * <LI> Delete an existing row from the bound item. </LI>
 * <LI> Commmit/Rollback changes made to the bound item. </LI>
 * </UL>
 * <p>
 * <h2>Inserting Cursors and Records</h2>
 * The NavigationBar uses methods on the
 * <tt>javax.infobus.ScrollableRowsetAccess</tt> interface to
 * move the cursor or insert a new record. You can use this interface to
 * perform operations programatically. For example:
 * <p>
 * <pre>
 * import javax.infobus.*;
 *
 * NavigationBar navbar  = ...
 *
 * navbar.setDataItemName(...);
 * ScrollableRowsetAccess rsAccess =
 *              (ScrollableRowsetAccess)navbar.getDataItem();
 *
 * rsAccess.absolute(1); // position the cursor at first row
 * rsAccess.newRow(); // insert a new row
 * ...
 * </pre>
 *
 * @version  PUBLIC
 *
 * @see      #setHasNavigationButtons()
 * @see      #setHasInsertButton()
 * @see      #setHasDeleteButton()
 * @see      #setHasTransactionButtons()
 */
public class NavigationBar
    extends JToolBar
    implements Control, ActionListener, CurrencyListener,
               InfoBusManagerListener
{
    public static final int BUTTON_FIRST    = 0;
    public static final int BUTTON_PREV     = 1;
    public static final int BUTTON_NEXT     = 2;
    public static final int BUTTON_LAST     = 3;
    public static final int BUTTON_INSERT   = 4;
    public static final int BUTTON_DELETE   = 5;
    public static final int BUTTON_COMMIT   = 6;
    public static final int BUTTON_ROLLBACK = 7;
    public static final int BUTTON_FIND     = 8;

    public static final int BUTTON_NORMAL   = 0;
    public static final int BUTTON_PRESSED  = 1;
    public static final int BUTTON_DISABLED = 2;
    public static final int BUTTON_ROLLOVER = 3;

    private ControlSupport _controlSupport;
    
    private JButton _buttons[];
    
    /*
    private static ImageIcon _buttonIcons[];
    private static ImageIcon _onButtonIcons[];
    private static ImageIcon _disButtonIcons[];
    private static ImageIcon _rollButtonIcons[];
    */
    private ImageIcon _buttonIcons[] = null;
    private ImageIcon _onButtonIcons[] = null;
    private ImageIcon _disButtonIcons[] = null;
    private ImageIcon _rollButtonIcons[] = null;

    private static final String _IMAGES_DIR = "/oracle/dacf/images/";
    private static final String _IMAGES[] =
    {
        "first", "prev", "next", "last",
        "insert", "delete", "commit", "rollback", "find"
    };
    private static final String _TOOLTIP[] =
    {
        Res.getString(Res.NBAR_TOOLTIP_FIRST_ROW),
        Res.getString(Res.NBAR_TOOLTIP_PREVIOUS_ROW),
        Res.getString(Res.NBAR_TOOLTIP_NEXT_ROW),
        Res.getString(Res.NBAR_TOOLTIP_LAST_ROW),
        Res.getString(Res.NBAR_TOOLTIP_NEW_ROW),
        Res.getString(Res.NBAR_TOOLTIP_DELETE_ROW),
        Res.getString(Res.NBAR_TOOLTIP_COMMIT),
        Res.getString(Res.NBAR_TOOLTIP_REQUERY),
        Res.getString(Res.NBAR_TOOLTIP_FIND)

    };

    private Object _navGate = new Object();
    private boolean _followKeyboardFocus;
    private static final boolean _DEBUG = true;

    private FindPanel _findPanel = null;
    private FindPanelUI _findPanelUI = null;
    private boolean _hasFindButton;

    protected JDialog _findDialog = null; 

    private Vector _listeners = new Vector();

    private NavigationManager _navmgr;
    private ValidationManager _valmgr;
    private Cursor _busyCursor= Cursor.getPredefinedCursor(Cursor.WAIT_CURSOR);
    private Cursor _defaultCursor= Cursor.getDefaultCursor();
    private boolean _isShowingBusyCursor = false;

    private KeyAdapter _escListener = new KeyAdapter() {
        public void keyReleased(KeyEvent e)
            {
                switch(e.getKeyCode())
                {
                case KeyEvent.VK_ESCAPE:
                    _escKeyPressed();
                    break;
                }
            }
    };

    /**
    * Creates a default instance
    */
    public NavigationBar()
    {
        _navmgr = NavigationManager.getNavigationManager();
        _valmgr = ValidationManager.getValidationManager();

        _loadImages();

        _buttons = new JButton[_buttonIcons.length];
        for (int i = 0; (i < _buttonIcons.length); i++)
        {
            JButton b = new JButton(_buttonIcons[i]);
            b.setRolloverEnabled(true);
            b.setPressedIcon(_onButtonIcons[i]);
            b.setRolloverIcon(_rollButtonIcons[i]);
            //            b.setRolloverSelectedIcon(_rollButtonIcons[i]);
            b.setDisabledIcon(_disButtonIcons[i]);
            b.setToolTipText(_TOOLTIP[i]);
            b.setBorderPainted(false);
            b.setFocusPainted(false);
            b.setMargin(new Insets(0, 0, 0, 0));
            b.setBorder(BorderFactory.createLineBorder(java.awt.Color.lightGray, 0));
            b.setEnabled(false);
            b.addActionListener(this);
            _buttons[i] = b;
        }
        _controlSupport = new ControlSupport(this);
        InfoBusManager.getInstance().addInfoBusManagerListener(this);

        //        setMargin(new Insets(0, 0, 0, 0));
        // Add default buttons to the bar
        setHasInsertButton(true);
        setHasDeleteButton(true);
        setHasNavigationButtons(true);
        setHasTransactionButtons(true);
        setHasFindButton(true);

        _navmgr.addCurrencyListener(this);
        _findDialog = _createFindPanelDialog();
    }

    /**
    *  Set the icon to be used for a button. <P>
    *  @param  button The button whose icon should be changed.
    *           Allowed values should be one of defined by the BUTTON_XXX
    *           constants
    *  @param  icon The new icon
    *  @deprecated
    */
    public void setButtonIcon(int button, Icon icon)
    {
        if (button < BUTTON_FIRST || button > BUTTON_FIND)
        {
            throw new IllegalArgumentException(Res.getString(Res.INVALID_BUTTON_INDEX)+button);
        }
        _buttons[button].setPressedIcon(null);
        _buttons[button].setDisabledIcon(null);
        _buttons[button].setRolloverEnabled(false);
        _buttons[button].setRolloverIcon(null);
        _buttons[button].setIcon(icon);
        revalidate();
    }

    /**
    *  Get the icon being used for a button. <P>
    *  @param  button The button whose icon is being requested
    *           Allowed values should be one of defined by the BUTTON_XXX
    *           constants
    *  @return The icon being used by button
    *  @deprecated
    */

    public Icon getButtonIcon(int button)
    {
        if (button < BUTTON_FIRST || button > BUTTON_FIND)
        {
            throw new IllegalArgumentException(Res.getString(Res.INVALID_BUTTON_INDEX)+button);
        }
        return _buttons[button].getIcon();
    }

    /**
    *  Set the icon to be used for a button. <P>
    *  @param  button The button whose icon should be changed.
    *           Allowed values should be one of defined by the BUTTON_XXX
    *           constants
    *  @param  icon The new button icon
    *  @param  pressedIcon The new button pressed icon
    *  @param  disabledIcon The new button disabled icon
    *  @param  rolloverIcon The new button rollover icon
    */
    public void setButtonIcons(int button, Icon icon, Icon pressedIcon,
                               Icon disabledIcon, Icon rolloverIcon)
    {
        if (button < BUTTON_FIRST || button > BUTTON_FIND)
        {
            throw new IllegalArgumentException(Res.getString(Res.INVALID_BUTTON_INDEX)+button);
        }
        _buttons[button].setIcon(icon);
        _buttons[button].setPressedIcon(pressedIcon);
        _buttons[button].setDisabledIcon(disabledIcon);
        if (rolloverIcon != null)
        {
            _buttons[button].setRolloverEnabled(true);
        }
        else
        {
            _buttons[button].setRolloverEnabled(false);
        }
        _buttons[button].setRolloverIcon(rolloverIcon);
        revalidate();
    }

    /**
    *  Get the icon being used for a button. <P>
    *  @param  button The button whose icon is being requested
    *           Allowed values should be one of defined by the BUTTON_XXX
    *           constants
    *  @param  type The icon type.  Allowed values are BUTTON_NORMAL, BUTTON_PRESSED,
    *          BUTTON_DISABLED, and BUTTON_ROLLOVER
    *  @return The icon being used by button
    */

    public Icon getButtonIcons(int button, int type)
    {
        if (button < BUTTON_FIRST || button > BUTTON_FIND)
        {
            throw new IllegalArgumentException(Res.getString(Res.INVALID_BUTTON_INDEX)+button);
        }
        switch (type)
        {
        case BUTTON_NORMAL:
            return _buttons[button].getIcon();
        case BUTTON_PRESSED:
            return _buttons[button].getPressedIcon();
        case BUTTON_DISABLED:
            return _buttons[button].getDisabledIcon();
        case BUTTON_ROLLOVER:
            return _buttons[button].getRolloverIcon();
        default:
            throw new IllegalArgumentException(Res.getString(Res.INVALID_BUTTON_INDEX)+type);
        }
    }

    /**
    *  Set the icon to be used when a button is pressed. <P>
    *  @param  button The button whose icon should be changed.
    *           Allowed values should be one of defined by the BUTTON_XXX
    *           constants
    *  @param  icon The new icon
    *  @deprecated
    */

    public void setButtonPressedIcon(int button, Icon icon)
    {
        if (button < BUTTON_FIRST || button > BUTTON_FIND)
        {
            throw new IllegalArgumentException(Res.getString(Res.INVALID_BUTTON_INDEX)+button);
        }
        _buttons[button].setDisabledIcon(null);
        _buttons[button].setPressedIcon(icon);
        revalidate();
    }

    /**
    *  Get the icon displayed when a navigation bar button is pressed. <P>
    *  @param  button The button whose icon is being requested
    *           Allowed values should be one of defined by the BUTTON_XXX
    *           constants
    *  @return The icon being used by the button in the pressed button
    *  @deprecated
    */

    public Icon getButtonPressedIcon(int button)
    {
        if (button < BUTTON_FIRST || button > BUTTON_FIND)
        {
            throw new IllegalArgumentException(Res.getString(Res.INVALID_BUTTON_INDEX)+button);
        }

        return _buttons[button].getPressedIcon();
    }

    /**
    * displays a busy cursor
    */
    public void showBusyCursor()
    {
        if (!_isShowingBusyCursor)
        {
            Container p = getTopLevelAncestor();
            if ( p != null )
            {
                _defaultCursor = p.getCursor();
                _isShowingBusyCursor = true;
                p.setCursor(getBusyCursor());
            }
        }
    }

    /**
    * show default cursor
    *
    */
    public void restoreDefaultCursor()
    {
        if (_isShowingBusyCursor)
        {
            Container p = getTopLevelAncestor();
            if ( p != null )
            {
                _isShowingBusyCursor = false;
                p.setCursor(_defaultCursor);
            }
        }
    }

    /**
    * Change the cursor used to indicate busy status
    *
    * @param busyCursor cursor to indicated busy status
    */
    public void setBusyCursor(Cursor busyCursor)
    {
        _busyCursor = busyCursor;
    }

    /**
    * get the cursor currently used to indicated busy status
    *
    * @return get the busy cursor
    */
    public Cursor getBusyCursor()
    {
        return _busyCursor;
    }

    /**
    *  get the button object used in the toolbar
    *
    *  @param  whichButton A constant indicating which button is requested
    *          Allowed values should be one of defined by the BUTTON_XXX
    *          constants
    *  @return The button object

    */
    public JButton getButton(int whichButton)
    {
        if ((whichButton < BUTTON_FIRST) || (whichButton > BUTTON_FIND))
        {
            throw new IllegalArgumentException(Res.getString(Res.INVALID_BUTTON_INDEX)+whichButton);
        }
        return _buttons[whichButton];
    }


    // Attributes

    /**
    ** Set keyboard focus following policy. <P>
    **
    ** If true, when the keyboard focus moves from one rowset to another,
    ** the NavigationBar will reconfigure itself so that it manipulates that
    ** rowset.
    **
    ** @param nuFollowKeyboardFocus if true, then track the keyboard focus
    ** @see #getFollowKeyboardFocus()
    */
    public void setFollowKeyboardFocus(boolean nuFollowKeyboardFocus)
    {
        _followKeyboardFocus = nuFollowKeyboardFocus;
    } // setFollowKeyboardFocus

    /**
    ** Returns keyboard focus following policy. <P>
    **
    ** If true, when the keyboard focus moves from one rowset to another,
    ** the NavigationBar will reconfigure itself so that it manipulates that
    ** rowset.
    **
    ** @return Returns keyboard focus following policy
    ** @see #setFollowKeyboardFocus(boolean nuFollowKeyboardFocus)
    */
    public boolean getFollowKeyboardFocus()
    {
        return(_followKeyboardFocus);
    } // getFollowKeyboardFocus

    /**
    * Determines if the toolbar has the buttons that are used to change the
    * current row
    * of the bound ScrollableRowsetAccess.
    * @return true if the currency can be changed otherwise returns false
    */
    public boolean getHasNavigationButtons()
    {
        return(getComponentIndex(_buttons[BUTTON_FIRST]) != -1);
    }

    /**
    * Tells the toolbar whether to include the navigation buttons or not.
    *
    * @param b if true the the navigation buttons are included in the bar
    *          else the navigation buttons are not included
    */
    public void setHasNavigationButtons(boolean b)
    {
        if (b)
        {
            _addButton(BUTTON_FIRST);
            _addButton(BUTTON_PREV);
            _addButton(BUTTON_NEXT);
            _addButton(BUTTON_LAST);

        }
        else
        {
            _removeButton(BUTTON_FIRST);
            _removeButton(BUTTON_PREV);
            _removeButton(BUTTON_NEXT);
            _removeButton(BUTTON_LAST);

        }
    }

    /**
    * Determines if the toolbar has the button that can be used to
    * insert a new row in the bound ScrollableRowsetAccess.
    * @return true if the button is included else false
    */
    public boolean getHasInsertButton()
    {
        return(getComponentIndex(_buttons[BUTTON_INSERT]) != -1);
    }

    /**
    * Tells the toolbar whether to include the insert button or not
    * @param b if true the insert button is be included else the button is
    * removed
    */
    public void setHasInsertButton(boolean b)
    {

        if (b)
        {
            _addButton(BUTTON_INSERT);
        }
        else
        {
            _removeButton(BUTTON_INSERT);
        }
    }

    /**
    * Determines if the toolbar has the button that can be used to
    * delete an existing row from the bound ScrollableRowsetAccess.
    * @return true if the button is included else false
    */

    public boolean getHasDeleteButton()
    {
        return(getComponentIndex(_buttons[BUTTON_DELETE]) != -1);
    }

    /**
    * Tells the toolbar whether to include the delete button or not
    * @param b if true the delete button is be included else the button is
    * removed
    */

    public void setHasDeleteButton(boolean b)
    {
        if (b)
        {
            _addButton(BUTTON_DELETE);
        }
        else
        {
            _removeButton(BUTTON_DELETE);
        }
    }

    /**
    * Determines if the toolbar has the buttons that can be used to
    * commit/rollback the changes made to the bound ScrollableRowsetAccess.
    * @return true if the buttons are included else false
    */
    public boolean getHasTransactionButtons()
    {
        return(getComponentIndex(_buttons[BUTTON_COMMIT]) != -1);
    }

    /**
    * Tells the toolbar whether to include the commit/rollback buttons or not
    * @param b if true the buttons are included else the buttons are removed
    */
    public void setHasTransactionButtons(boolean b)
    {
        boolean hadTransactionButtons = getHasTransactionButtons();
        if (b)
        {
            _addButton(BUTTON_COMMIT);
            _addButton(BUTTON_ROLLBACK);

            if (!hadTransactionButtons)
            {
               _bindToParent(getDataItem());
            }
        }
        else
        {
            if (hadTransactionButtons)
            {
               _unbindToParent(getDataItem());
            }
            
            _removeButton(BUTTON_COMMIT);
            _removeButton(BUTTON_ROLLBACK);
        }
    }



    /**
    * Determines if the toolbar has the button that can be used to
    * run a restricted query (Find dialog) from the bound ScrollableRowsetAccess.
    * @return true if the button is included else false
    */

    public boolean getHasFindButton()
    {
        return _hasFindButton;
    }

    /**
    * Tells the toolbar whether to include the 'Find button or not
    * @param b if true the 'Find' button is included else the button is
    * removed
    */
    public void setHasFindButton(boolean b)
    {
        _hasFindButton = b; // you can disable even if bound to a master rowset
        if (b)
        {
            if (_canShowFindButton())
                _showFindButton(true);
        }
        else
            _showFindButton(false);

    }



    /**
    * Tells the toolbar whether to include the 'Find button or not
    * @param b if true the 'Find' button is included else the button is
    * removed
    */
    private void _showFindButton(boolean b)
    {
        if (b)
        {
            _addButton(BUTTON_FIND);
        }
        else
        {
            _removeButton(BUTTON_FIND);
        }
    }

    public FindPanel getFindPanel()
    {
        if (_findPanel == null)
           _createFindPanel();
        return _findPanel;
    }

    /**
    *  customize the find dialog displayed by the navigation bar
    *
    *  @param findPanelUI - object which implements FindPanelUI interface
    *  @deprecated
    */
    public void setFindPanelUI(FindPanelUI findPanelUI)
    {
        _findPanelUI = findPanelUI;
        if (_findPanel != null)
        {
            _findPanel.setFindPanelUI(findPanelUI);
            findPanelUI.setProperty(FindPanelUI.PARENT_CONTAINER, _findDialog);
        }
    }

    /**
    * get the find panel UI object which customizes the find dialog
    *
    * @deprecated
    * @return findPanelUI renderer
    */
    public FindPanelUI getFindPanelUI()
    {
        return(_findPanelUI);
    }

    // InfoBusManagerListener interface implementation
    public void releaseResources(InfoBusManagerReleaseEvent e)
    {
        if (e.appliesTo(this))
        {
            InfoBusManager ibm = InfoBusManager.getInstance();

            _unbindToParent(getDataItem());
            _navmgr.removeCurrencyListener(this);
            ibm.removeInfoBusManagerListener(this);
            ibm.fireReleaseResources(_findDialog, _findDialog);
            _findPanel = null;
            _controlSupport.setDataItemName(null);
            _controlSupport = null;
        }
    }

    // Control Interface

    /**
    * get the infobus name to which the control is bound to
    *
    * @return the infobus name
    */
    public final String getInfoBusName()
    {
        return(_controlSupport == null ?
               null : _controlSupport.getInfoBusName());
    }

    /**
    * set the infobus name to which the control is bound to
    *
    * @param infoBusName name of the infobus
    */
    public final void setInfoBusName(String infoBusName)
    {
        if (_controlSupport != null)
        {
            _controlSupport.setInfoBusName(infoBusName);
        }
    }

    /**
    * get the data item name to which this control is bound
    *
    * @return the name of the data item to which the control is bound
    */
    public final String getDataItemName()
    {
        return(_controlSupport == null ?
               null : _controlSupport.getDataItemName());
    }

    /**
    * set the data item name to which the control is bound
    *
    * @param dataitemName name of the data item
    */
    public final void setDataItemName(String dataItemName)
    {
        if (_controlSupport != null)
        {
            _controlSupport.setDataItemName(dataItemName);
        }
    }

    /**
    * get the dataitem object to which the control is bound to
    *
    * @return the dataitem object to which the control is bound
    */
    public final Object getDataItem()
    {
        return(_controlSupport == null ? null : _controlSupport.getDataItem());
    }

    /**
    * notification that the dataitem changed
    *
    * @param oldDataItem old data item object
    * @param newDataItem new data item object
    */
    public final void dataItemChanged(Object oldDataItem, Object newDataItem)
    {
        if (oldDataItem != null && oldDataItem instanceof RowsetAccess)
        {
            _unbindToParent(oldDataItem);
        }
        
        if (newDataItem != null && newDataItem instanceof RowsetAccess)
        {
            _bindToParent(newDataItem);
            _bindFindPanel();
            if ((_hasFindButton) && _canShowFindButton())
            {
                _showFindButton(true);
            }
        }
        
        if (newDataItem != null && newDataItem instanceof DbAccess)
        {
            ((DbAccess)newDataItem).beginTransaction();
        }

        _updateButtonStatesLater();
    }

    /**
    * Returns the AWT component associated with this control. <P>
    * @return  The AWT component for this control.
    */
    public final Component getComponent()
    {
        return(this);
    }

    /**
    * Determines whether focus into this control causes validation to
    * occur. <P>
    * Most controls should delegate this method to <TT>ControlSupport</TT>. <P>
    * @return  <TT>true</TT> if focus into this control causes validation to
    *          occur, <TT>false</TT> otherwise.
    * @see ControlSupport#isFocusValidated
    */
    public final boolean isFocusValidated()
    {
        return(_controlSupport == null ?
               false : _controlSupport.isFocusValidated());
    }

    /**
    * Sets whether focus into this control causes validation to occur. <P>
    * Most controls should delegate this method to <TT>ControlSupport</TT>. <P>
    * @param focusValidated    If <TT>true</TT>, focus into this control will
    *                          cause validation to occur.
    * @see ControlSupport#setFocusValidated
    */
    public final void setFocusValidated(boolean focusValidated)
    {
        if (_controlSupport != null)
        {
            _controlSupport.setFocusValidated(focusValidated);
        }
    }

    /**
    * Adds a navigated listener to this control. <P>
    * The listener will be notified of NavigateIn and NavigateOut events. <P>
    * Most controls should delegate this method to <TT>ControlSupport</TT>. <P>
    * @param listener  The listener to add.
    * @see ControlSupport#addNavigatedListener
    */
    public final void addNavigatedListener(NavigatedListener listener)
    {
        if (_controlSupport != null)
        {
            _controlSupport.addNavigatedListener(listener);
        }
    }

    /**
    * Removes a navigated listener from this control. <P>
    * Most controls should delegate this method to <TT>ControlSupport</TT>. <P>
    * @param listener  The listener to remove.
    * @see ControlSupport#removeNavigatedListener
    */
    public final void removeNavigatedListener(NavigatedListener listener)
    {
        if (_controlSupport != null)
        {
            _controlSupport.removeNavigatedListener(listener);
        }
    }

    /**
    * Processes a navigated event for this control. <P>
    * This method is for use by the NavigationManager only. <P>
    * Most controls should delegate this method to <TT>ControlSupport</TT>. <P>
    * @param event The navigated event.
    * @see ControlSupport#processNavigatedEvent
    */
    public final void processNavigatedEvent(NavigatedEvent event)
    {
        if (_controlSupport != null)
        {
            _controlSupport.processNavigatedEvent(event);
        }
    }

    /**
    * Adds a navigating listener to this control. <P>
    * The listener will be notified of NavigateIn and NavigateOut events. <P>
    * Most controls should delegate this method to <TT>ControlSupport</TT>. <P>
    * @param listener  The listener to add.
    * @see ControlSupport#addNavigatedListener
    */
    public final void addNavigatingListener(NavigatingListener listener)
    {
        if (_controlSupport != null)
        {
            _controlSupport.addNavigatingListener(listener);
        }
    }

    /**
    * Removes a navigating listener from this control. <P>
    * Most controls should delegate this method to <TT>ControlSupport</TT>. <P>
    * @param listener  The listener to remove.
    * @see ControlSupport#removeNavigatedListener
    */
    public final void removeNavigatingListener(NavigatingListener listener)
    {
        if (_controlSupport != null)
        {
            _controlSupport.removeNavigatingListener(listener);
        }
    }

    /**
    * Processes a navigating event for this control. <P>
    * This method is for use by the NavigatedManager only. <P>
    * Most controls should delegate this method to <TT>ControlSupport</TT>. <P>
    * @param event The navigating event.
    * @exception NavigatingException   If the navigation is redirected to a
    *                                  different control.
    * @see ControlSupport#processNavigatedEvent
    */
    public final void processNavigatingEvent(NavigatingEvent event)
        throws NavigatingException
    {
        if (_controlSupport != null)
        {
            _controlSupport.processNavigatingEvent(event);
        }
    }

    public void addVetoableNavigationBarButtonClickListener(
                                                            NavigationBarButtonClickListener  l)
    {
        _listeners.addElement(l);
    }

    public void removableVetoableNavigationBarButtonClickListener(
                                                                  NavigationBarButtonClickListener  l)
    {
        _listeners.removeElement(l);
    }


    // DataItemChangeListener Interface
    /**
    * Indicates a changed value in the bound data item. <P>
    * A reference to the data item that changed can be obtained from the
    * event. <P>
    * @param event Contains change information.
    * @see javax.infobus.DataItemChangeListener#dataItemValueChanged
    */
    public final void dataItemValueChanged(DataItemValueChangedEvent event)
    {
        _updateButtonStatesLater();
    }

    /**
    * Indicates that a new item was added to the bound aggregate data item
    * (e.g. <TT>ArrayAccess</TT>, a JDK Collection, etc). <P>
    * A reference to the data item that was added, and a reference to the one
    * that gained it, can be obtained from the event. <P>
    * @param event Contains details of the addition.
    * @see javax.infobus.DataItemChangeListener#dataItemAdded
    */
    public final void dataItemAdded(DataItemAddedEvent event)
    {
        _updateButtonStatesLater();
    }

    /**
    * Indicates that an item was deleted from the bound aggregate data item
    * (e. g. <TT>ArrayAccess</TT>, a JDK Collection, etc). <P>
    * A reference to the data item that was deleted, and a reference to the
    * one that lost it, can be obtained from the event. <P>
    * @param event Contains details of the deletion.
    * @see javax.infobus.DataItemChangeListener#dataItemDeleted
    */
    public final void dataItemDeleted(DataItemDeletedEvent event)
    {
        _updateButtonStatesLater();
    }

    /**
    * Indicates that the bound data item (and its sub-items, if any) has been
    * revoked, and is temporarily unavailable. <P>
    * A reference to the data item that was revoked can be obtained from
    * the event. <P>
    * @param event Contains details of the revoked data.
    * @see javax.infobus.DataItemChangeListener#dataItemRevoked
    */
    public final void dataItemRevoked(DataItemRevokedEvent event)
    {
        _updateButtonStatesLater();
    }

    /**
    * Indicates that the cursor for the bound <TT>RowsetAccess</TT> data item
    * has changed rows. <P>
    * A reference to the rowset data item can be obtained from the event. <P>
    * @param event Contains details of the cursor move.
    * @see javax.infobus.DataItemChangeListener#rowsetCursorMoved
    */
    public void rowsetCursorMoved(RowsetCursorMovedEvent event)
    {
        _updateButtonStatesLater();
    }

    /**
    * This method allows a menu (for example) to use the navigation bar's
    * navigation logic.
    *
    * @param  index  the identifier for the button to click
    *                (one of the BUTTON_XXX constants)
    */
    public void doClick(int index)
    {
        if (getComponentIndex(_buttons[index]) != -1)
        {
            _buttons[index].doClick();
        }
    }

    /**
    * get the JDialog object which is used to display the Find dialog
    *
    * @return the dialog object to display the find dialog
    */
    public JDialog getFindPanelDialog()
    {
        return _findDialog;
    }



   //ActionListener implementation
   /**
    * This method is an implementation side effect
    */
   public void actionPerformed(ActionEvent event)
   {
      DataItem dataItem =
         (_controlSupport == null
         ? null
         : (DataItem)_controlSupport.getDataItem());

      String dataItemName =
         (_controlSupport == null
         ? null
         : _controlSupport.getDataItemName());

      Control focusedControl = _navmgr.getFocusedControl();
      boolean putFocusBack = false;

      synchronized(_navGate)
      {
         if (dataItem != null)
         {
            int validationLevel = InfoObject.LEVEL_COLUMN;

            JButton source = (JButton) event.getSource();
            int button = _findButton(source);

            ScrollableRowsetAccess rowset = null;
            DbAccess db = null;
            boolean dirty = false;

            switch(button)
            {
               case BUTTON_FIRST:
               case BUTTON_PREV:
               case BUTTON_NEXT:
               case BUTTON_LAST:
               case BUTTON_INSERT:
                  _invokeApplyEdits(focusedControl, true);
                  validationLevel = InfoObject.LEVEL_ROW;
                  break;
               case BUTTON_COMMIT:
                  _invokeApplyEdits(focusedControl, true);
                  validationLevel = InfoObject.LEVEL_SESSION;
                  break;
               case BUTTON_DELETE:
                  validationLevel = -1;
                  break;
               case BUTTON_ROLLBACK:
                  validationLevel = -1;
                  _invokeApplyEdits(focusedControl, false);
                  break;
               case BUTTON_FIND:
                  validationLevel = -1;
                  _invokeApplyEdits(focusedControl, true);
                  break;
            }

            if (focusedControl != null && validationLevel != -1)
            {
               int level = _navmgr.getChangeLevel(focusedControl, this);

               level =
                  ((_controlSupport != null && _controlSupport.isFocusValidated())
                  ? Math.max(level, validationLevel)
                  : validationLevel);

               // fix for bug 1454657
               if (!_navmgr.validateFocusedControl(level))
               {
                  if ((focusedControl != null) && !isBoundToLOV(focusedControl))
                  {
                     ((Component)focusedControl).requestFocus();
                  }
                  return;
               }
            }


            if (dataItem instanceof ScrollableRowsetAccess)
            {
               rowset = (ScrollableRowsetAccess)dataItem;
            }

            if (dataItem instanceof DbAccess)
            {
               db = (DbAccess)dataItem;
            }
            else if (rowset != null)
            {
               db = rowset.getDb();
            }

            if (db != null)
            {
               Object obj = ((DataItem)db).getProperty(DataItemProperties.PENDING_CHANGES);

               if (obj != null && obj instanceof Boolean)
               {
                  dirty = ((Boolean)obj).booleanValue();
               }
            }

            try
            {
               _fireNavigationBarButtonClickEvent(button, event);
            }
            catch (NavigationBarButtonClickVetoException exc)
            {
               return;
            }

            try
            {
               switch(button)
               {
                  case BUTTON_FIRST:
                     if (rowset != null)
                     {
                        try
                        {
                           showBusyCursor();
                           rowset.first();
                           restoreDefaultCursor();
                        }
                        catch (Exception e)
                        {
                           ExceptionProcessor.processException(
                              dataItem
                              , -1
                              , e
                              , DacfType.CLIENT_FRAMEWORK,DacfSeverity.ERROR);
                        }

                        putFocusBack = true;
                     }

                     break;

                  case BUTTON_PREV:

                     if (rowset != null)
                     {
                        try
                        {
                           rowset.previous();
                        }
                        catch (Exception e)
                        {
                           ExceptionProcessor.processException(
                              dataItem
                              , -1
                              , e
                              , DacfType.CLIENT_FRAMEWORK,DacfSeverity.ERROR);
                        }

                        putFocusBack = true;
                     }

                     break;

                  case BUTTON_NEXT:

                     if (rowset != null)
                     {
                        try
                        {
                           rowset.next();
                        }
                        catch (Exception e)
                        {
                           ExceptionProcessor.processException(
                              dataItem
                              ,  -1
                              , e
                              , DacfType.CLIENT_FRAMEWORK,DacfSeverity.ERROR);

                        }

                        putFocusBack = true;
                     }

                     break;

                  case BUTTON_LAST:

                     if (rowset != null)
                     {
                        try
                        {
                           showBusyCursor();
                           rowset.last();
                           restoreDefaultCursor();
                        }
                        catch(Exception e)
                        {
                           ExceptionProcessor.processException(
                              dataItem
                              ,  -1
                              , e
                              , DacfType.CLIENT_FRAMEWORK,DacfSeverity.ERROR);
                        }

                        putFocusBack = true;
                     }

                     break;

                  case BUTTON_INSERT:

                     if (rowset != null)
                     {
                        try
                        {
                           rowset.newRow();
                        }
                        catch (Exception e)
                        {
                           ExceptionProcessor.processException(
                              dataItem
                              , -1
                              , e
                              , DacfType.CLIENT_FRAMEWORK,DacfSeverity.ERROR);
                        }

                        if (focusedControl != null)
                        {
                           String fcName = focusedControl.getDataItemName();

                           if (fcName != null )
                           {
                              putFocusBack = fcName.startsWith(dataItemName);
                           }
                           else
                           {
                              putFocusBack = false;
                           }
                        }
                     }

                     break;

                  case BUTTON_DELETE:

                     if (rowset != null)
                     {
                        rowset.deleteRow();
                        putFocusBack = true;
                     }

                     break;

                  case BUTTON_COMMIT:

                     if (db != null)
                     {
                        showBusyCursor();
                        db.commitTransaction();
                        db.beginTransaction();
                        restoreDefaultCursor();
                        putFocusBack = true;
                     }

                     break;

                  case BUTTON_ROLLBACK:

                     if (db != null)
                     {
                        showBusyCursor();
                        db.rollbackTransaction();
                        db.beginTransaction();
                        restoreDefaultCursor();
                        putFocusBack = true;
                        _navmgr.focusedIsInvalid(false);
                     }

                     break;

                  case BUTTON_FIND:

                     if ( rowset != null )
                     {
                        _displayFindDialog();
                        putFocusBack = true;
                     }

                     break;
               }

               _updateButtonStates();

               if (putFocusBack && (focusedControl != null )
                  && !isBoundToLOV(focusedControl))
               {
                  ((Component)focusedControl).requestFocus();
               }
            }
            catch (RowsetValidationException e)
            {
               // XXX
               restoreDefaultCursor();
            }
            catch (SQLException e)
            {
               // XXX
               restoreDefaultCursor();
            }
         }
      }
   }

    // apply or cancel changes on the focussed control
    // bFlag true - applyEdit, otherwise cancelEdit
    protected void _invokeApplyEdits(Control focusedControl, boolean bFlag)
    {
        if (focusedControl instanceof ApplyEditsListener)
        {
            ApplyEditsListener editsListener = (ApplyEditsListener)focusedControl;

            if (bFlag)
                editsListener.applyEdits();
            else
                editsListener.cancelEdits();
        }
    }

    // CurrencyListener implementation
    public void currencyChanged(CurrencyChangedEvent e)
    {
        Control cur = e.getCurrentControl();

        if (_followKeyboardFocus && !(cur instanceof TreeControl ||
                                      cur instanceof NavigationBar ||
                                      cur instanceof StatusBarControl))
        {
            DataItem di = (DataItem)cur.getDataItem();

            if (di != null)
            {
                if (di instanceof ImmediateAccess)
                {
                    InfoObject io = (InfoObject)di.getProperty(DataItemProperties.INFO_OBJECT);
                    if (io != null && io instanceof AttributeInfo)
                    {
                        RowSetInfo rsi = ((AttributeInfo)io).getRowSetInfo();

                        if (rsi != null)
                        {
                            di = (DataItem)rsi.getRowsetAccess();
                        }
                        else
                        {
                            di = null;
                        }
                    }
                    else
                    {
                        di = null;
                    }
                }
                if (di == null || !(di instanceof ScrollableRowsetAccess))
                {
                    return; // bail; nothing we can do.
                }
                String name = (String)di.getProperty(DataItemProperties.NAME);
                setDataItemName(name);
            }
        }
    }

    /**
    *  Create the find dialog which the NavigationBar uses. This method
    *  should be overriden if you want to have a custom dialog.
    *
    *  This dialog is used to host the FindPanel
    */
    protected JDialog _createFindPanelDialog()
    {
        JDialog dlg = new JDialog(new Frame(),
                                  Res.getString(Res.NBAR_FIND_DIALOG_TITLE), true);

        return dlg;
    }

    protected void _createFindPanel()
    {
        _findPanel = new FindPanel();
        _findPanel.setBusyCursor(getBusyCursor());
        if (_findPanelUI != null)
            _findPanel.setFindPanelUI(_findPanelUI);
        _findPanel.getFindPanelUI().setProperty(FindPanelUI.PARENT_CONTAINER,
                                            _findDialog);
        _bindFindPanel();
    }

        
    protected void _escKeyPressed()
    {
        if (_findDialog != null)
        {
            _findDialog.removeKeyListener(_escListener);
            _findDialog.hide();
        }
    }

    // Private Methods

    private boolean _addButton(int buttonPosition)
    {

        if (getComponentIndex(_buttons[buttonPosition]) == -1)
        {
            int pos ;
            if ((buttonPosition + 1) <= getComponentCount())
                pos = buttonPosition;
            else
                pos = -1;

            add(_buttons[buttonPosition],pos);
            revalidate();
            return true;
        }
        return false;
    }

    private boolean _removeButton(int buttonPosition)
    {
        if (getComponentIndex(_buttons[buttonPosition]) != -1)
        {
            remove(_buttons[buttonPosition]);
            revalidate();
            return true;
        }
        return false;
    }

    protected void _updateButtonStatesLater()
    {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                _updateButtonStates();
            }
        });
    }

    protected void _updateButtonStates()
    {
        boolean buttonStates[] = new boolean[_buttons.length];
        Object dataItem =
            (_controlSupport == null ? null : _controlSupport.getDataItem());
        DbAccess db = null;
        if (dataItem != null)
        {
            if (dataItem instanceof RowsetAccess)
            {
                RowsetAccess rowset = (RowsetAccess)dataItem;
                buttonStates[BUTTON_INSERT] =
                   (getHasInsertButton() ? rowset.canInsert() : false);

                buttonStates[BUTTON_DELETE] =
                   (getHasDeleteButton() ? rowset.canDelete() : false);

                buttonStates[BUTTON_FIND] = true;

                db = rowset.getDb();

               if (getHasNavigationButtons())
               {
                   if ( dataItem instanceof IteratorProperties)
				   {
						IteratorProperties ip = (IteratorProperties)dataItem;

						buttonStates[BUTTON_NEXT] = 
                                 buttonStates[BUTTON_LAST] = ip.hasNext();
						
						buttonStates[BUTTON_PREV] = 
						         buttonStates[BUTTON_FIRST] = ip.hasPrevious();

				   }
				   else if (dataItem instanceof ScrollableRowsetAccess)
                   {
                      ScrollableRowsetAccess sra =
                          (ScrollableRowsetAccess)rowset;
                      int rowNum = sra.getRow();
                      int rowCount = sra.getRowCount();

                      if (rowNum > 1) // origin 1 numbering
                      {
                          buttonStates[BUTTON_FIRST] =
                              buttonStates[BUTTON_PREV] = true;
                      }
                      if (rowNum < rowCount)
                      {
                          buttonStates[BUTTON_NEXT] =
                              buttonStates[BUTTON_LAST] = true;
                      }
                  }
                  else
                  {
                      buttonStates[BUTTON_NEXT] = rowset.hasMoreRows();
                  }
               }
            }
            else if (dataItem instanceof DbAccess)
            {
                db = (DbAccess)dataItem;
            }

            if (db != null && getHasTransactionButtons())
            {
                boolean dirty = false;
                Object obj =
                    ((DataItem)db).getProperty(DataItemProperties.PENDING_CHANGES);

                if (obj != null && obj instanceof Boolean)
                {
                    dirty = ((Boolean)obj).booleanValue();
                }
                buttonStates[BUTTON_COMMIT] = dirty;
                _buttons[BUTTON_ROLLBACK].setToolTipText(Res.getString(dirty ? Res.NBAR_TOOLTIP_ROLLBACK : Res.NBAR_TOOLTIP_REQUERY));
                buttonStates[BUTTON_ROLLBACK] = true;
            }
        }

        for (int i = 0; (i < buttonStates.length); i++)
        {
            if (_buttons[i].hasFocus() && !buttonStates[i])
            {
                requestFocus();
            }
            _buttons[i].setEnabled(buttonStates[i]);
            // _buttons[i].setFocusPainted(false);
            _buttons[i].setBorderPainted(false);
            _buttons[i].setRolloverEnabled(buttonStates[i]);
        }
    }


    private int _findButton(JButton button)
    {
        for(int i = 0 ; i < _buttons.length ; i++)
        {
            if (_buttons[i] == button)
                return i;
        }
        return -1;
    }

    private synchronized void _loadImages()
    {
        if (_buttonIcons != null)
        {
            return;
        }

        _buttonIcons = new ImageIcon[_IMAGES.length];
        _onButtonIcons = new ImageIcon[_IMAGES.length];
        _disButtonIcons = new ImageIcon[_IMAGES.length];
        _rollButtonIcons = new ImageIcon[_IMAGES.length];

        Class cl = NavigationBar.class;
        for (int i = 0; (i < _IMAGES.length); i++)
        {
            URL img, onimg, disimg, rollimg;
            img = cl.getResource(_IMAGES_DIR + _IMAGES[i] + ".gif");
            if (img != null)
                _buttonIcons[i] = new ImageIcon(img);

            onimg = cl.getResource(_IMAGES_DIR + _IMAGES[i] + "on.gif");
            if (onimg != null)
                _onButtonIcons[i] = new ImageIcon(onimg);

            disimg = cl.getResource(_IMAGES_DIR + _IMAGES[i] + "dis.gif");
            if (disimg != null)
                _disButtonIcons[i] = new ImageIcon(disimg);

            rollimg = cl.getResource(_IMAGES_DIR + _IMAGES[i] + "roll.gif");
            if (rollimg != null)
                _rollButtonIcons[i] = new ImageIcon(rollimg);
        }
    }

    /**
    *  get data item name for the Session
    *
    *  @param dataItemName data item name to which the navbar is bound to
    */
    private String _getParentDataItemName()
    {
        String pdiName = null;
        
        Object dataItem = getDataItem();
        if (( dataItem != null ) && ( dataItem instanceof RowsetAccess))
        {
            RowsetAccess rowset = (RowsetAccess)dataItem;
            DbAccess db = rowset.getDb();
            if ( db != null )
            {
                pdiName =
                    (String)((DataItem)db).getProperty(DataItemProperties.NAME);
            }
        };
        return(pdiName);
    }

    /**
    *  If the nav bar is bound to a rowset, then go find the session and bind
    * to it. This is done so that we could update transaction buttons correctly
    */
    private void _bindToParent(Object dataItem)
    {
        if ((getHasTransactionButtons() == true) &&
            ( dataItem != null )) // are we bound to some valid data item ?
        {
            if ( dataItem instanceof RowsetAccess )
            {
                DbAccess dba = ((RowsetAccess)dataItem).getDb();

                if ((dba != null) && (dba instanceof DataItemChangeManager))
                {
                    ((DataItemChangeManager)dba).addDataItemChangeListener(this);
                }
            }
        }
    }

    private void _unbindToParent(Object dataItem)
    {
        if ((getHasTransactionButtons() == true) &&
            ( dataItem != null )) // are we bound to some valid data item ?
        {
            if ( dataItem instanceof RowsetAccess )
            {
                DbAccess dba = ((RowsetAccess)dataItem).getDb();

                if ((dba != null) && (dba instanceof DataItemChangeManager))
                {
                    ((DataItemChangeManager)dba).removeDataItemChangeListener(this);
                }
            }
        }
    }

    /**
    *  Display find dialog. Set up the find panel and display the find
    *  dialog.
    */
    protected void _displayFindDialog()
    {
        // should be able to set the rowset instead
        JPanel panel = new JPanel();
        
        if (_findPanel == null)
            _createFindPanel();

        _findDialog.addKeyListener(_escListener);
        _findDialog.getContentPane().setLayout(new BorderLayout());
        _findDialog.getContentPane().add(_findPanel, BorderLayout.CENTER);
        _findDialog.getContentPane().add(panel, BorderLayout.SOUTH);

        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
        Dimension dlgSize = _computeFindDialogSize(screenSize);
        Point pt  = _computeFindDialogLocation(screenSize, dlgSize);

        _findDialog.setSize(dlgSize);
        _findDialog.setLocation(pt);
        
        _findDialog.show();
    }

    /**
    * override this method to change the size of the find dialog
    */
    protected Dimension _computeFindDialogSize(Dimension screenSize)
    {
        String columnDataItemNames[] = _findPanel.getColumnDataItemName();

        int numFieldsToDisplay =
            ((columnDataItemNames != null && columnDataItemNames.length < 5 ) ?
             columnDataItemNames.length : 5);
        _findDialog.setSize(600, numFieldsToDisplay * 50 + 100);


        Dimension dlgSize = _findDialog.getSize();
        if (dlgSize.height > screenSize.height)
            dlgSize.height = screenSize.height;

        if (dlgSize.height < 150 )
            dlgSize.height = 150;

        if (dlgSize.width > dlgSize.width)
            dlgSize.width = screenSize.width;

        return dlgSize;
    }

    /**
    *  override this method to change the find dialog location
    */
    protected Point _computeFindDialogLocation(Dimension screenSize,
                                               Dimension dlgSize)
    {
        return new Point( (screenSize.width - dlgSize.width)/2,
                          (screenSize.height - dlgSize.height)/2);
    }

    /**
    *  check if the transaction is dirty
    */
    private boolean _isDirty(RowsetAccess rowset)
    {
        boolean isDirty = true;
        DbAccess db = rowset.getDb();
        Object dirty = (Boolean)((DataItem)db).
            getProperty(DataItemProperties.PENDING_CHANGES);

        if (dirty != null && dirty instanceof Boolean)
        {
            isDirty = ((Boolean)dirty).booleanValue();
        }
        return(isDirty);
    }

    /**
    *  figure out if we can show the find button
    */
    private boolean _canShowFindButton()
    {
        Object di = getDataItem();
        if ((di != null) && (di instanceof RowsetAccess))
        {
            RowsetAccess rowset = (RowsetAccess)di;
            Object InfoObject =
                ((DataItem)rowset).getProperty(DataItemProperties.INFO_OBJECT);
            if ((InfoObject != null) && (InfoObject instanceof RowSetInfo))
                return ((((RowSetInfo)InfoObject).getMasterLinkInfo() == null)
                        ? true : false);
        }
        return false;
    }

    /**
    * bind find control if navbar bound to a rowset
    */
    private void _bindFindPanel()
    {
        Object di = getDataItem();
        if ((di != null) && (di instanceof RowsetAccess) &&
            _findPanel != null)
        {
            _findPanel.setDataItemName(getDataItemName());
        }
    }

    private void _fireNavigationBarButtonClickEvent(int buttonId,
                                                    ActionEvent e)
        throws NavigationBarButtonClickVetoException
    {
        NavigationBarButtonClickListener[] listeners =
            _getNavigationBarButtonClickListeners();
        NavigationBarButtonClickEvent evt =
            new NavigationBarButtonClickEvent(this,buttonId, e);
            
        for ( int i = 0; i < listeners.length; i++ )
        {
            listeners[i].navigationBarButtonClicked(evt);
        }
    }

    private NavigationBarButtonClickListener[]
        _getNavigationBarButtonClickListeners()
    {
        NavigationBarButtonClickListener[] listeners;
        synchronized(_listeners)
        {
            listeners =
                new NavigationBarButtonClickListener[_listeners.size()];
            _listeners.copyInto(listeners);
        }
        return(listeners);
    }

    /**
    *  check if an LOV property has been set on the control's dataobject
    *
    */
    protected boolean isBoundToLOV(Control c)
    {
        DataItem di = (DataItem)c.getDataItem();
        if ((di != null) && (di instanceof ImmediateAccess))
        {
            AttributeInfo attrInfo =
                (AttributeInfo )di.getProperty(DataItemProperties.INFO_OBJECT);
            if (attrInfo != null)
                return (( attrInfo.getLOV() != null ) ? true : false);
        }
        return false;
    }
}


