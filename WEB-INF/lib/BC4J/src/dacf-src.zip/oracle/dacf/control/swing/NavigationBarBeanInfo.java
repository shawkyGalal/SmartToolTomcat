/*
 * @(#)NavigationBarBeanInfo.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.dacf.control.swing;

import java.beans.BeanInfo;
import java.beans.EventSetDescriptor;
import java.beans.PropertyDescriptor;
import java.util.Vector;

/**
 * bean info class for the check box control
 *
 * @version SDK
 */
public class NavigationBarBeanInfo extends ControlBeanInfoHelper
{
   BeanInfo [] _beaninfo = null;

   /**
   * Constructor
   */
   public NavigationBarBeanInfo()
   {
       super();
       _beaninfo = getAdditionalBeanInfo();
       // this setting in combination with the getPropertyDescriptors overwrite allows
       // us to hide properties of the superclass (bug 1181229)
       setExposeBaseClassBeanInfo(false);
   }

   /**
   * get the Class object for the bean
   *
   * @return Class object for the bean
   */
   protected Class getBeanClass()
   {
       return NavigationBar.class;
   }

   public PropertyDescriptor[] getPropertyDescriptors()
   {
       Vector vector = new Vector();

       if (_beaninfo != null)
       {
          for(int i=0; i<_beaninfo.length; i++)
          {
             PropertyDescriptor[] pss = _beaninfo[i].getPropertyDescriptors();
             for(int j=0; j<pss.length; j++)
             {
                if (!pss[j].getName().equals("layout"))
                   vector.addElement(pss[j]);
             }
          }
       }

       PropertyDescriptor[] pss = super.getPropertyDescriptors();
       if (pss != null)
       {
          for(int i=0; i<pss.length; i++)
                 vector.addElement(pss[i]);
       }

       PropertyDescriptor [] returnProp = new PropertyDescriptor[vector.size()];
       vector.copyInto(returnProp);

       return returnProp;
   }

   /**
   * get property descriptors for the bean
   *
   * @return PropertyDescriptors specific to this bean
   */
   protected PropertyDescriptor[] getAdditionalPropertyDescriptors()
   {
       try
       {
           PropertyDescriptor hasTransactionButtons =
               new PropertyDescriptor("hasTransactionButtons", getBeanClass(),
               "getHasTransactionButtons", "setHasTransactionButtons");

           PropertyDescriptor hasNavigationButtons =
               new PropertyDescriptor("hasNavigationButtons", getBeanClass(),
               "getHasNavigationButtons", "setHasNavigationButtons");

           PropertyDescriptor  hasInsertButton  =
               new PropertyDescriptor("hasInsertButton", getBeanClass(),
               "getHasInsertButton", "setHasInsertButton");

           PropertyDescriptor  hasDeleteButton  =
               new PropertyDescriptor("hasDeleteButton", getBeanClass(),
               "getHasDeleteButton", "setHasDeleteButton");

           PropertyDescriptor  hasFindButton  =
               new PropertyDescriptor("hasFindButton", getBeanClass(),
               "getHasFindButton", "setHasFindButton");

           PropertyDescriptor  followsFocus  =
               new PropertyDescriptor("followsKeyboardFocus", getBeanClass(),
               "getFollowKeyboardFocus", "setFollowKeyboardFocus");

           PropertyDescriptor[] ret = { hasNavigationButtons,
               hasTransactionButtons,hasInsertButton, hasDeleteButton,
               hasFindButton, followsFocus};
           return ret;
       }
       catch (Exception exc)
       {
           exc.printStackTrace();
           return null;
       }
   }


   /**
   *  get additional events specific to this bean
   */
   protected EventSetDescriptor[] getAdditionalEventDescriptors()
   {
        try
        {
            EventSetDescriptor esd =
                new  EventSetDescriptor(getBeanClass(),
                           "buttonClick",
                           NavigationBarButtonClickListener.class,
                           new String[] {"navigationBarButtonClicked"},
                           "addVetoableNavigationBarButtonClickListener",
                           "removableVetoableNavigationBarButtonClickListener"
                           );
            return new EventSetDescriptor[] { esd };
        }
        catch (Exception exc)
        {
           exc.printStackTrace();
           return null;
        }
   }


}
