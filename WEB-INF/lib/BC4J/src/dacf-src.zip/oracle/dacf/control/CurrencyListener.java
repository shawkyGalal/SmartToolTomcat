/*
 * @(#)CurrencyListener.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.dacf.control;

// imports
/**
 **      This interface is to be implemented by those classes that wish to
 **      notified when the current control changes.
 **
 ** @version SDK
 */
public interface CurrencyListener
{
    /**
    **  This method is called by the NavigationManager after is has determined
    **  the new current control and keyboard focus has been moved to that
    **  control.
    */
    public void currencyChanged(CurrencyChangedEvent e);

}  // CurrencyListener


