/*
 * @(#)CurrencyChangedEvent.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.dacf.control;

// imports
/**
 **      This event is sent by the NavigationManager to all CurrencyListeners
 **      whenever the the "current" control is changed.  The "current" control
 **      is the control that has keyboard focus.
 **
 ** @version SDK
 */
public class CurrencyChangedEvent
{
    private Control _prev;
    private Control _current;
    
    public CurrencyChangedEvent(Control currentControl, Control prevControl)
    {
        _current = currentControl;
        _prev = prevControl;
    } // CurrencyChangedEvent

    /**
    **  returns the current control; the control that now has keyboard
    **  focus.
    */
    public Control getCurrentControl()
    {
        return(_current);
    } // getCurrentControl
    
    /**
    **  returns the previous control; the control that previously had keyboard
    **  focus.
    */
    public Control getPreviousControl()
    {
        return(_prev);
    } // getPreviousControl
}  // CurrencyChangedEvent
