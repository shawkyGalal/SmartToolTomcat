/*
 * @(#)DataPanel.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.dacf.control.swing.find;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionListener;
import java.sql.Timestamp;
import java.sql.Types;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import oracle.dacf.control.swing.FindPanel;
import oracle.dacf.util.ViewCriteriaModifier;

/**
 * Data panel for the ViewCriteriaFindPanel
 */
public class DataPanel extends JPanel
{
    protected int _row=0;
    protected ViewCriteriaFindPanelUI _owner = null;

    /**
    *  labels in the data panel. one label displayed for each queryable column
    */
    protected JLabel[] _label;

    /**
    *  text fields in the data panel. one text field displayed for each queryable
    *  column
    */
    protected JTextField[] _textField;

    /**
    * buttons which bring up custom editors
    */
    protected JButton[] _buttonCustomEditor;

    /**
    * SQL date format
    */
    protected  static String _defaultSQLDateFormatString = "YYYY-MM-DD";

    /**
    * SQL time format
    */
    protected static String _defaultSQLTimeFormatString = "YYYY-MM-DD HH:MI:SS";

    /**
    * date format string used in date formatter
    */
    protected static String _defaultDateFormatString = "yyyy-MM-dd";

	protected FindInvoker _findInvoker = null;

	protected static final String _emptyString = "";

	
    public DataPanel(ViewCriteriaFindPanelUI owner, int whichRow)
    {
         _owner = owner;
         _row = whichRow;
    		 _findInvoker = new FindInvoker(owner._findButton);
    }

	public void setTextFieldValue(int column, String value)
	{
  		if ((_textField != null) && ( _textField[column] !=null))
	  		_textField[column].setText(value);

	}

	public String getTextFieldValue(int column)
	{
  		if ((_textField != null) && ( _textField[column] !=null))
	    		return _textField[column].getText();
    	return "";
	}

    
	public void setEditInvoker(ActionListener[] actionListener, boolean rebuildNow)
	{
      if ( actionListener != null)
      {
          _buttonCustomEditor = new JButton[actionListener.length];
  	    	for (int i=0; i < actionListener.length; i++)
	  	    {
		  	      if (actionListener[i] == null)
        	  			continue;
			        _buttonCustomEditor[i] = new JButton("...");
      		  	_buttonCustomEditor[i].addActionListener(actionListener[i]);
         	}
      }
      else
      {
          _buttonCustomEditor = null;
      }
  		if (rebuildNow)
           _rebuildUI();
	}

    
    /**
    * apply values to the ViewRowset
    */
    public void _applyValues()
    {
        if( _textField != null)
        {
             _checkCursor();
             for ( int i=0 ; i < _textField.length; i++)
             {
                 String editedVal = _textField[i].getText();
                 String decoratedVal = _emptyString;
				 
                 if (editedVal.equals("null") || (editedVal.equals(_emptyString)))
				 {
					decoratedVal = _emptyString;
					editedVal = _emptyString;
				 }
                 else
                 {
                     int sqlType =  _owner._getSQLType(i);
                     Object param = _emptyString;
                     switch (sqlType)
                     {
                         case Types.DATE :
                         case Types.TIME :
                         case Types.TIMESTAMP :
                                      param = getDateFormatString(editedVal);
                                      break;
  
            	         case Types.CHAR:
						 case Types.LONGVARCHAR:
						 case Types.VARCHAR :
							 param = new Boolean(
							_owner.isCaseSensitiveSearch());
							 break; 

                         default :
                                  break;
                     }

					 boolean autoWildCard = !(_owner._isDisableAutomaticWildCardInSearch());

                     decoratedVal = _owner._modifyQueryCriteriaValue(
							   sqlType,editedVal, autoWildCard, param);
                 }

                 String oldVal = _owner._getColumnValue(i);
                 if ( !decoratedVal.equals(oldVal))
                    _owner._setColumnValue(i, decoratedVal);
				 _owner._setUserData(i, editedVal);
             }
        }

    }


    protected void _checkCursor()
    {
        int i = _owner._getRefreshedRowIndex(this);
        _owner.setCurrentViewCriteriaRow(i);
    }

    protected void _rebuildUI()
    {
          if ( !_owner._isDataPublished())
              return;

          this.removeAll();
          
          setLayout( new GridBagLayout());
          GridBagConstraints gc;

          JPanel _dataPanel = new JPanel();
          _dataPanel.setLayout( new GridBagLayout());

         int labelPos = _owner._labelPosition;
         int arrangeItem = _owner._itemDirection;

         if ( labelPos == FindPanel.LEFT)
         {
             if ( arrangeItem == FindPanel.X_AXIS)
             {
                 // labels left
                 // items left to right
                 int x =0;
                 int label_width = 1;
                 int text_width = 2;
                 for ( int i=0; i < _textField.length; i++)
                 {
                     gc =_setConstr(x , 1,  label_width, 1, new Insets(5,5,5,5),
                        0,0,GridBagConstraints.NONE,   GridBagConstraints.EAST, 0,0);
                     _dataPanel.add(_label[i],gc);
                     x = x + label_width;

                     // text field
                     JPanel panel = new JPanel();
                     panel.setLayout( new BorderLayout());
                     panel.add(_textField[i], BorderLayout.CENTER);
                     if (( _buttonCustomEditor != null) &&
                                          (_buttonCustomEditor[i] != null))
                         panel.add(_buttonCustomEditor[i], BorderLayout.EAST);

                     gc =_setConstr(x , 1,  text_width, 1, new Insets(5,5,5,5),
                         0,0,GridBagConstraints.HORIZONTAL,   GridBagConstraints.EAST, 1,0);
                     _dataPanel.add(panel,gc);
                     x = x + text_width;
                 }
             }
             else
             {
                  int textFieldHeight = 5;
                  for ( int i=0 ; i < _textField.length; i++)
                  {
                     // labels left
                     // items top down

                     // label field
                     gc = _setConstr(0 , i * textFieldHeight, 1, 1, new Insets(0,5,5,5),
                         0,0,GridBagConstraints.NONE,   GridBagConstraints.EAST, 0.1,0);
                     _dataPanel.add(_label[i],gc);

                     // text field
                     JPanel panel = new JPanel();
                     panel.setLayout( new BorderLayout());
                     panel.add(_textField[i], BorderLayout.CENTER);
                     if (( _buttonCustomEditor != null) &&
                                          (_buttonCustomEditor[i] != null))
                        panel.add(_buttonCustomEditor[i], BorderLayout.EAST);

                     gc = _setConstr(1 , i* textFieldHeight , 3, textFieldHeight,
                          new Insets(0,5,5,5), 0,0, GridBagConstraints.BOTH,
                          GridBagConstraints.NORTH, 0.9,0);
                     _dataPanel.add(panel, gc);
                  }
             }
         }
         else
         {
             if ( arrangeItem == FindPanel.Y_AXIS)
             {
                 // label above
                 // items top down
                 int y = 0;
                 int label_width = 1;
                 int text_width = GridBagConstraints.REMAINDER;
                 for ( int i=0; i < _textField.length; i++)
                 {
                     _label[i].setHorizontalAlignment(SwingConstants.LEFT);
                     gc =_setConstr(0 , i * y,  label_width, 1, new Insets(0,5,0,1),
                         0,0,GridBagConstraints.NONE,   GridBagConstraints.WEST, 0,0);
                     _dataPanel.add(_label[i],gc);


                     JPanel panel = new JPanel();
                     panel.setLayout( new BorderLayout());
                     panel.add(_textField[i], BorderLayout.CENTER);
                     if (( _buttonCustomEditor != null) &&
                                          (_buttonCustomEditor[i] != null))
                         panel.add(_buttonCustomEditor[i], BorderLayout.EAST);

                     gc =_setConstr(0, i * y + 1,  text_width, 1, new Insets(0,5,5,5),
                           0,0,GridBagConstraints.HORIZONTAL,   GridBagConstraints.WEST, 1,0);
                     _dataPanel.add(panel,gc);
                     y = y + 2 + 1; // 2 per field + 1 extra line
                 }
             }
             else
             {
                 // label above
                 // items left to right

                 int x =0;
                 int label_width = 1 ;
                 int text_width = 2;

                 for ( int i=0; i < _textField.length; i++)
                 {
                     _label[i].setHorizontalAlignment(SwingConstants.LEFT);
                      gc =_setConstr(x , 0 ,  label_width, 1, new Insets(1,5,0,5),
                        0,0,GridBagConstraints.NONE,   GridBagConstraints.WEST, 0,0);
                     _dataPanel.add(_label[i],gc);

                     JPanel panel = new JPanel();
                     panel.setLayout( new BorderLayout());
                     panel.add(_textField[i], BorderLayout.CENTER);
                     if (( _buttonCustomEditor != null) &&
                                          (_buttonCustomEditor[i] != null))
                         panel.add(_buttonCustomEditor[i], BorderLayout.EAST);

                     gc =_setConstr(x, 1,  text_width, 1, new Insets(5,5,5,5),
                        0,0,GridBagConstraints.HORIZONTAL,   GridBagConstraints.WEST, 1,0);
                     _dataPanel.add(panel,gc);
                     x = x  + label_width + text_width;
                  }
             }
         }


          JScrollPane scrollPane = new JScrollPane();
          scrollPane.setViewportView(_dataPanel);
          scrollPane.setBorder(null);

          this.setLayout( new BorderLayout());
          //this.add( _owner._iconPanel, BorderLayout.WEST);
          this.add( scrollPane, BorderLayout.CENTER);

    }

    protected void _notifyPropertyChange(int whichProperty, Object value)
    {
        switch (whichProperty)
        {
           case FindPanelUI.LABEL_FONT:
                _setLabelFont((Font)value);
                break;

           case FindPanelUI.TEXT_FONT:
                _setTextFont((Font)value);
                break;

           case FindPanelUI.LABEL_FORE_CLR:
                _setLabelForeColor((Color)value);
                break;

           case FindPanelUI.TEXT_FORE_CLR:
                _setTextForeColor((Color)value);
                break;

           case FindPanelUI.LABEL_BACK_CLR:
                _setLabelBackColor((Color)value);
                break;

           case FindPanelUI.TEXT_BACK_CLR:
                _setTextBackColor((Color)value);
                break;

           case FindPanelUI.TEXT_COLUMN_WIDTH:
                _setTextColumnWidth((Integer)value);
                break;

           case FindPanelUI.ENABLED :
                _enableControls( ((Boolean)value).booleanValue());
                break;
        }
    }


    protected void _setLabelFont(Object value)
    {
        if ( _label != null)
        {
            for ( int i=0; i < _label.length; i++)
                _label[i].setFont(_owner._labelFont);
        }
    }

    protected void _setTextColumnWidth(Object value)
    {
        if ( _textField != null)
        {
            for ( int i=0; i < _textField.length; i++)
                _textField[i].setColumns(_owner._textColumnWidth);
        }
    }

    protected void _setTextFont(Object value)
    {
        if ( _textField != null)
        {
            for ( int i=0; i < _textField.length; i++)
              _textField[i].setFont(_owner._textFont);
        }
    }


    protected void _setTextBackColor(Object value)
    {
         if ( _textField != null)
         {
             for ( int i=0; i < _textField.length; i++)
                _textField[i].setBackground(_owner._textBackColor);
         }
    }

   protected void _setTextForeColor(Object value)
   {
         if ( _textField != null)
         {
             for ( int i=0; i < _textField.length; i++)
                _textField[i].setForeground(_owner._textForeColor);
         }
   }

   protected void _setLabelForeColor(Object value)
   {
       if ( _label != null)
       {
           for ( int i=0; i < _label.length; i++)
               _label[i].setForeground(_owner._labelForeColor);
       }
   }

   protected void _setLabelBackColor(Object value)
   {
       if ( _label != null)
       {
           for ( int i=0; i < _label.length; i++)
               _label[i].setBackground(_owner._labelBackColor);
       }
   }

   protected void _resetFields()
   {
       if ( _textField != null)
       {
             for ( int i=0; i < _textField.length; i++)
                _textField[i].setText("");
       }
   }

   protected  void _enableControls(boolean flag)
   {
         if ( _label != null)
            for (int i=0; i < _label.length;i++)
                _label[i].setEnabled(flag);

         if ( _textField != null)
             for (int i=0; i < _textField.length;i++)
                _textField[i].setEnabled(flag);

   }

    /**
    * A notification from the parent that one or more data item names changed.
    * Implementation should rebuild the UI
    */
    protected void _itemChanged(boolean queryNewValues)
    {
        int colCount = _owner.getColumnCount();
        _checkCursor();


        _textField = new JTextField[colCount];
        _label = new JLabel[colCount];
        for ( int i=0; i < colCount; i++)
        {
            _textField[i] = new JTextField(_owner._textColumnWidth);
            _textField[i].setToolTipText(_owner._getTooltipText(i));
			String s = ((queryNewValues) ? (String)_owner._getUserData(i) : "");
			if (s == null)
				s = _emptyString;
			
			_textField[i].setText(s);
            _label[i] = new JLabel(_owner._getColumnDisplayLabel(i));
            _label[i].setHorizontalAlignment(SwingConstants.RIGHT);
		    registerActionListener(_textField[i]);
        }
        _rebuildUI();
    }

	/**
	* registers action listener on textfields and invoke
	* mimic find button click, when enter key is pressed.
	*/
	protected void registerActionListener(JTextField f)
	{
		f.addActionListener(_findInvoker);
	}
	

    protected String getDateFormatString(String editedValue)
    {
        String date = ViewCriteriaModifier.parseDataValue(editedValue);
        if (_isTime(date))
            return _defaultSQLTimeFormatString;
        else if (_isDate(date))
            return  _defaultSQLDateFormatString;
        return "";
    }

    /**
    * does the string represent time in YYYY-MM-DD HH:MI:SS format ?
    *
    * return true if the string represent time in above format
    */
    protected boolean _isTime(String s)
    {
        try
        {
            Timestamp.valueOf(s);
            return true;
        }
        catch (IllegalArgumentException e)
        {
        }
        return false;
    }


    /**
    * does the string represent date in YYYY-MM-DD format ?
    *
    * return true if the string represent date in above format
    */
    protected boolean _isDate(String s)
    {
        try
        {
            SimpleDateFormat  dateFormatter = new SimpleDateFormat();
            dateFormatter.applyPattern(_defaultDateFormatString);
            dateFormatter.parse(s);
            return true;
        }
        catch (ParseException e)
        {
        }
        return false;
    }


   /**
   * Helper method to layout the UI using GridBagLayout
   */
   private GridBagConstraints _setConstr(int gridx, int gridy,
            int gridwidth, int gridheight, Insets insets, int ipadx, int ipady,
            int fill, int anchor, double weightx, double weighty)
   {
         GridBagConstraints gc = new GridBagConstraints();

         gc.gridx = gridx;
         gc.gridy = gridy;

         gc.gridwidth = gridwidth;
         gc.gridheight = gridheight;

         gc.insets = insets;

         gc.ipadx = ipadx;
         gc.ipady = ipady;

         gc.fill = fill;

         gc.anchor = anchor;

         gc.weightx = weightx;
         gc.weighty = weighty;

         return gc;
   }
}

class FindInvoker implements ActionListener
{   
	JButton button;

	FindInvoker(JButton b)
	{
		button = b;
	}

	public void actionPerformed(java.awt.event.ActionEvent event) 
	{
		button.doClick();
	}
}

