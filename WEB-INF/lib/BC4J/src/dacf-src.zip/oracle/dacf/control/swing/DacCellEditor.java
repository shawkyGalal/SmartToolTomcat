/*
 * @(#)DacCellEditor.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.dacf.control.swing;

import java.awt.Component;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.MouseEvent;
import java.util.EventObject;
import javax.swing.JComponent;
import javax.swing.JTable;
import javax.swing.event.CellEditorListener;
import javax.swing.event.ChangeEvent;
import javax.swing.event.EventListenerList;
import javax.swing.table.TableCellEditor;

/**
 * Helper class which allows DAC controls to be used as an editor
 * in the grid.
 */
public class DacCellEditor implements TableCellEditor
{
    private int _clickCountToStart = 1;
    private EventListenerList _listenerList = new EventListenerList();
    transient protected ChangeEvent changeEvent = null;
    private JComponent _editorComponent;
    protected DacEditorDelegate _delegate;


    /**
     * Constructs a DacCellEditor object that uses a DAC CheckBoxControl
     *
     * @param x  a CheckBoxControl object ...
     */
    public DacCellEditor(CheckBoxControl x)
    {
        this._editorComponent = x;
        this._delegate = new DacEditorDelegate()
        {
             public void setValue(Object x)
             {
                super.setValue(x);
                System.out.println("editor checkbox setVal " + x);
            		if (x instanceof Boolean)
             		    ((CheckBoxControl)_editorComponent).setSelected(((Boolean)x).booleanValue());
             		else if (x instanceof String)
                {
                    String selectionValue = ((CheckBoxControl)_editorComponent).getSelectionValue();
                    if (selectionValue.compareTo((String)x) == 0 )
              		      ((CheckBoxControl)_editorComponent).setSelected(true);
                    else
                        ((CheckBoxControl)_editorComponent).setSelected(false);
              	}
            }

            public Object getCellEditorValue()
            {
                  CheckBoxControl editor = (CheckBoxControl)_editorComponent;
                  if ( editor.isSelected())
                        return editor.getSelectionValue();
                  else
                        return editor.getDeselectionValue();
            }

            public boolean shouldSelectCell(EventObject anEvent)
            {
                  return false;
            }

            public boolean startCellEditing(EventObject anEvent)
            {
  	            return false;
          	}

        };
        ((CheckBoxControl)_editorComponent).addActionListener(_delegate);
    }

  public Component getTableCellEditorComponent(JTable table, Object value, boolean isSelected, int row, int column)
  {
      return _editorComponent;
  }

  public Object getCellEditorValue()
  {
       return _delegate.getCellEditorValue();
  }

  public boolean isCellEditable(EventObject anEvent)
  {
    	if (anEvent instanceof MouseEvent)
      {
	        if (((MouseEvent)anEvent).getClickCount() < _clickCountToStart)
         		return false;
    	}
    	return _delegate.isCellEditable(anEvent);
  }

  public boolean shouldSelectCell(EventObject anEvent)
  {
      return false;
  }

  public boolean stopCellEditing()
  {
      	boolean stopped = _delegate.stopCellEditing();
       	if (stopped)
       	    fireEditingStopped();
      	return stopped;
  }

  public void cancelCellEditing()
  {
    	_delegate.cancelCellEditing();
	    fireEditingCanceled();
  }

  public void addCellEditorListener(CellEditorListener l)
  {
	    _listenerList.add(CellEditorListener.class, l);
  }

  // implements javax.swing.CellEditor
  public void removeCellEditorListener(CellEditorListener l)
  {
	    _listenerList.remove(CellEditorListener.class, l);
  }


   /**
    * Specifies the number of clicks needed to start editing.
    *
    * @param count  an int specifying the number of clicks needed to start editing
    * @see #getClickCountToStart
    */
   public void setClickCountToStart(int count)
   {
    	 _clickCountToStart = count;
   }

   /**
    *  clickCountToStart controls the number of clicks required to start
    *  editing if the event passed to isCellEditable() or startCellEditing() is
    *  a MouseEvent.  For example, by default the clickCountToStart for
    *  a JTextField is set to 2, so in a JTable the user will need to
    *  double click to begin editing a cell.
   */
    public int getClickCountToStart()
    {
       	return _clickCountToStart;
    }

    /*
    * Notify all listeners that have registered interest for
    * notification on this event type.  The event instance
    * is lazily created using the parameters passed into
    * the fire method.
    * @see EventListenerList
    */
     protected void fireEditingStopped()
     {
	      // Guaranteed to return a non-null array
       	Object[] listeners = _listenerList.getListenerList();
      	// Process the listeners last to first, notifying
      	// those that are interested in this event
        for (int i = listeners.length-2; i>=0; i-=2)
        {
      	    if (listeners[i]==CellEditorListener.class)
            {
            		// Lazily create the event:
            		if (changeEvent == null)
            		    changeEvent = new ChangeEvent(this);
            		((CellEditorListener)listeners[i+1]).editingStopped(changeEvent);
     	      }
     	  }
     }

     /*
     * Notify all listeners that have registered interest for
     * notification on this event type.  The event instance
     * is lazily created using the parameters passed into
     * the fire method.
     * @see EventListenerList
     */
      protected void fireEditingCanceled()
      {
        	// Guaranteed to return a non-null array
        	Object[] listeners = _listenerList.getListenerList();
      	  // Process the listeners last to first, notifying
        	// those that are interested in this event
        	for (int i = listeners.length-2; i>=0; i-=2)
          {
     	        if (listeners[i]==CellEditorListener.class)
              {
              		// Lazily create the event:
              		if (changeEvent == null)
            	  	    changeEvent = new ChangeEvent(this);
            		  ((CellEditorListener)listeners[i+1]).editingCanceled(changeEvent);
              }
          }
      }


      //
      //  Protected DacEditorDelegate class
      //

      protected class DacEditorDelegate implements ActionListener, ItemListener
      {
          protected Object value;

          public Object getCellEditorValue()
          {
             return value;
          }

          public void setValue(Object x)
          {
              this.value = x;
          }

          public boolean isCellEditable(EventObject anEvent)
          {
      	      return true;
      	  }

          public boolean startCellEditing(EventObject anEvent)
          {
              return true;
          }

          public boolean stopCellEditing()
          {
         	    return true;
        	}

          public void cancelCellEditing()
          {
      	  }

      	  // Implementing ActionListener interface
          public void actionPerformed(ActionEvent e)
          {
      	      fireEditingStopped();
          }

        	// Implementing ItemListener interface
          public void itemStateChanged(ItemEvent e)
          {
         	    fireEditingStopped();
       	  }
      }
}

