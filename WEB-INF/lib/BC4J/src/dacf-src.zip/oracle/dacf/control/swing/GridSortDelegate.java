/*
 * @(#)GridSortDelegate.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.dacf.control.swing;

import java.sql.SQLException;
import javax.infobus.DataItem;
import javax.infobus.DbAccess;
import javax.infobus.RowsetAccess;
import javax.infobus.RowsetValidationException;
import javax.infobus.ScrollableRowsetAccess;
import javax.swing.JOptionPane;
import oracle.dacf.dataset.DataItemProperties;
import oracle.dacf.dataset.ResultSetInfo;

/**
 *  Sort by changing the order by clause
 *
 *  @version SDK
 *
 */
public class GridSortDelegate implements SortDelegate
{
   boolean _bPostAlways = true;

   private static final int DO_POST = 0;
   private static final int DO_ROLLBACK = 1;
   private static final int DO_COMMIT = 2;

   private static final String SEPERATOR = " ";

   public GridSortDelegate()
   {
   }


   /**
	 * GridControl invokes this method, so that the implementation can
	 * prepare to sort. The implementation for example may post changes
	 * to the database or prompt the user
	 *
	 * The return value of this method determines if sorting should
	 * continue
	 *
	 * @return true if sorting should continue
	 */
	 public boolean preSort(ScrollableRowsetAccess scr)
	 {
      if (isPostAlways())
          return _applyChanges(scr, DO_POST);
      else
	  	{
  	  		if ( _isDirty(scr))
          {
              String title = Res.getString(Res.NBAR_SAVE_CHANGES_DLG_TITLE);
        	  	String msg =   Res.getString(Res.NBAR_SAVE_CHANGES_DLG_MSG);
		      	  int opt = JOptionPane.showConfirmDialog(null, msg, title,
													JOptionPane.YES_NO_CANCEL_OPTION);

              switch( opt )
		    	    {
    		        	case JOptionPane.YES_OPTION:
		    	      		  return _applyChanges(scr, DO_COMMIT);
    	      		 	case JOptionPane.NO_OPTION:
                      return _applyChanges(scr, DO_ROLLBACK);
  			    		  default:
                      return false;
              }
  	    	}
          else
              return true;
      }
	 }

	 /**
	 * GridControl invokes this method to perform the actual sorting. The
 	 * return value is used by the GridControl to decide if the icon in the
	 * table header should change
	 *
	 * Irrespective of the value returned by this method, the postSort method
	 * is always invoked
	 *
	 * return true if sort was succsessful
	 */
	 public boolean sort(ScrollableRowsetAccess scr, String columnName,
	 					String orderBy)
	 {
    		ResultSetInfo resultSetInfo =
                (ResultSetInfo)((DataItem)scr).getProperty(
					                    DataItemProperties.INFO_OBJECT);

 	    	StringBuffer orderByClause = new StringBuffer();
  		  orderByClause.append(columnName);
  	  	orderByClause.append(SEPERATOR);
  		  orderByClause.append(orderBy);

        resultSetInfo.setQueryOrderbyClause(orderByClause.toString());
        try
        {
  	     		resultSetInfo.executeQuery();
	  	     	return true;
  		  }
	  	  catch( Exception exc)
		    {
           JOptionPane.showMessageDialog(null, exc.getMessage());
			     return false;
  		  }
	 }

	 /**
	 * Implementation may use this method to cleanup
	 */
	 public void postSort(ScrollableRowsetAccess scr)
	 {
   }

   /**
   * If this flag is true, the transaction changes are posted and the
   * rowset sorted by changing orderby clause.
   *
   * If this flag is false and transaction is dirty, user is prompted to
   * either rollback or commit the transaction.
   *
   * The default value is false
   *
   * @bflag set to true, if the transaction changes should be posted
   */
   public void setPostAlways(boolean bflag)
   {
       _bPostAlways = bflag;
   }

   /**
   * indicates if the transaction changes are posted always when
   * sorting. The alternative is to commit/rollback.
   */
   public boolean isPostAlways()
   {
      return _bPostAlways;
   }

   /**
   *  Propogate changes to the DbAccess. Overrider this method to
   *  process the exception
   */
   protected boolean _applyChanges(ScrollableRowsetAccess scr, int doWhat)
   {
        try
        {
            _applyChangesToDbAccess(scr, doWhat);
            return true;
        }
        catch(Exception exc)
        {
            JOptionPane.showMessageDialog(null, exc.getMessage());
            return false;
        }
   }

   protected void _applyChangesToDbAccess(ScrollableRowsetAccess scr, int doWhat)
            throws SQLException, RowsetValidationException
   {
        switch(doWhat)
        {
            case DO_POST:
                 scr.getDb().flush();
                 break;
            case DO_ROLLBACK:
                 scr.getDb().rollbackTransaction();
                 break;
            case DO_COMMIT:
                 scr.getDb().commitTransaction();
                 break;
        }
   }

 	 private boolean _isDirty(RowsetAccess rowset)
   {
        DbAccess db = rowset.getDb();
        Object dirty = (Boolean)((DataItem)db).
            getProperty(DataItemProperties.PENDING_CHANGES);
        if (dirty != null && dirty instanceof Boolean)
            return ((Boolean)dirty).booleanValue();
        return true;
   }

}
