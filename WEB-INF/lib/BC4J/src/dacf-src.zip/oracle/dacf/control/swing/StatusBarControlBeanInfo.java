/*
 * @(#)StatusBarControlBeanInfo.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.dacf.control.swing;

import java.beans.EventSetDescriptor;
import java.beans.IntrospectionException;
import java.beans.PropertyDescriptor;

// imports
/**
 **    StatusBarControlBeanInfo<P>
 **
 ** @version SDK
 */
public class StatusBarControlBeanInfo
     extends ControlBeanInfoHelper
{
    private static int NAME = 0;
    private static int GETTER = 1;
    private static int SETTER = 2;
    private static int EDITOR = 3;

    private static Class beanClass =
        oracle.dacf.control.swing.StatusBarControl.class;

    private String[][] propertyList = new String[][]
    {
        // name, getter, setter, editor class
        {
          "dataItemName", "getDataItemName", "setDataItemName",
                       "oracle.jdeveloper.daceditors.DataItemNameEditor"
        },
        {
            "layout", "getLayout", "setLayout", null
        },
        {
            "hasCurrentRow", "getHasCurrentRow", "setHasCurrentRow", null
        },
        {
            "hasHighWaterMark", "getHasHighWaterMark", "setHasHighWaterMark",
                null
        },
        {
            "hasRowCount", "getHasRowCount", "setHasRowCount", null
        },
        {
            "hasModifiedFlag", "getHasModifiedFlag", "setHasModifiedFlag", null
        },
        {
            "hasMessageArea", "getHasMessageArea", "setHasMessageArea", null
        },
    };

    /**
    ** Simple, null constructor
    */
    public StatusBarControlBeanInfo()
    {
        super();
    } // StatusBarControlBeanInfo


    /**
    * get the Class object for the bean described by this beaninfo class
    *
    * @return the Class object for the bean
    */
    protected Class getBeanClass()
    {
        return(beanClass);
    } // getBeanClass

    /**
    * get property descriptors for the bean
    *
    * @return PropertyDescriptors specific to this bean
    */
    public PropertyDescriptor[] getPropertyDescriptors()
    {
        PropertyDescriptor[] pdarr =
            new PropertyDescriptor[propertyList.length];

        try
        {
            for (int i = 0 ; i < propertyList.length ; i++)
            {
                pdarr[i] = new PropertyDescriptor(propertyList[i][NAME],
                                                  beanClass,
                                                  propertyList[i][GETTER],
                                                  propertyList[i][SETTER]);

                String editorName = propertyList[i][EDITOR];
                if (editorName != null)
                {
                    try
                    {
                        pdarr[i].setPropertyEditorClass(Class.forName(editorName));
                    }
                    catch(ClassNotFoundException ex)
                    {
                        ex.printStackTrace(System.err);
                    }
                }
            }
            // hide the layout property
            pdarr[0].setHidden(true);
            pdarr[1].setHidden(true);
        }
        catch (IntrospectionException e)
        {
            e.printStackTrace(System.err);
            pdarr = null;
        }
        return(pdarr);
    }
    public EventSetDescriptor[] getEventSetDescriptors()
    {
        return(new EventSetDescriptor[0]);
    }

}  // StatusBarControlBeanInfo


//
//   StatusBarControlBeanInfo.java
//
//   Copyright (c) 1998 by  Oracle Corporation
//   All rights reserved.
//
