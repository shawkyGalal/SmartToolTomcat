/*
 * @(#)SingleSelector.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.dacf.control.swing;

import javax.swing.DefaultListSelectionModel;
import oracle.dacf.control.Control;
import oracle.dacf.control.NavigationManager;

/**
 * ListSelectionModel implementation that supports single selections
 * only. A selection change request is validated before changing the
 * selection
 *
 * @version INTERNAL
 */
class SingleSelector
    extends DefaultListSelectionModel
{
    private int _anchor ;
    private int _lead;
    private boolean _changePending;
    private Control _control ;
    private boolean _isAdjusting;
    private int _selected ;
	 private boolean _setSelectionInterval;

    /**
    * Constructs a selector for the given control
    */
    public SingleSelector(Control control)
    {
        _control = control;
        setSelectionMode(SINGLE_SELECTION);
    }

    public int getAnchorSelectionIndex()
    {
        return _anchor;
    }

	 public boolean isSetSelectionInterval()
	 {
		 return _setSelectionInterval;
	 }

    public int getLeadSelectionIndex()
    {
        return _lead;
    }

    public void setAnchorSelectionIndex(int anchor)
    {
        _anchor = anchor;
    }

    public void setLeadSelectionIndex(int lead)
    {
        _lead = lead;
    }


    public boolean isSelectedIndex(int index)
    {
        return(_selected != -1 && _selected == index);
    }

    public boolean isSelectionEmpty(int index)
    {
        return(_selected == -1);
    }

    public int getMinSelectionIndex()
    {
        return _selected;
    }

    public int getMaxSelectionIndex()
    {
        return _selected;
    }

    public void clearSelection()
    {
        if (_selected != -1)
        {
            int oldSelection = _selected;
            _selected = -1;
            super.fireValueChanged(oldSelection, oldSelection);
        }
    }


    /**
    *  Sets the selection mode
    * @param mode the desired selection mode. Only SINGLE_SELECTION modes
    *        are supported
    * @exception IllegalArgumentException if mode other than SINGLE_SELECTION
    */
    public void setSelectionMode(int mode)
    {
        if (mode != SINGLE_SELECTION)
        {
            throw new IllegalArgumentException(Res.getString(Res.UNSUPPORTED_MODE) + mode);
        }

        super.setSelectionMode(mode);
    }


    /**
    *  Sets the new selection interval. Change in the selection
    *  is validated
    */
    public void setSelectionInterval(int anchor, int lead)
    {
        if (anchor != lead)
        {
            throw new IllegalArgumentException(Res.getString(Res.SINGLE_SELECTIONS_ONLY));
        }

        //Cache selection change
        _anchor = anchor;
        _lead = lead;

        if (getValueIsAdjusting())
        {
            _changePending = true ;
        }
        else
        {
			  _setSelectionInterval = true;
            _changeSelection(anchor);
        }
    }

    public boolean getValueIsAdjusting()
    {
        return _isAdjusting;
    }

    public void setValueIsAdjusting(boolean isAdjusting)
    {
        if (isAdjusting != _isAdjusting)
        {
            _isAdjusting = isAdjusting;
            //fireValueChanged(isAdjusting);
        }

        // Is this the last event
        if (_changePending && !isAdjusting)
        {
            _changePending = false;
			  _setSelectionInterval = false;
            _changeSelection(_anchor);
        }
    }

    protected boolean validateSelectionChange(int fromRow, int toRow)
    {
        NavigationManager fm = NavigationManager.getNavigationManager();
        if (fm.getFocusedControl() != _control)
        {
            return fm.validateFocusChange(_control);
        }

        String dataItemName = _control.getDataItemName();

        return (fm.validateFocusChange(_control, dataItemName, dataItemName,
                                       !(fromRow == toRow)));
    }

    private void _changeSelection(int newSelection)
    {

        int oldSelection = getMinSelectionIndex();
        if (!isSelectedIndex(newSelection))
        {
            if (validateSelectionChange(oldSelection, newSelection))
            {
                _selected = newSelection;
                if (oldSelection <= newSelection)
                    super.fireValueChanged(oldSelection, newSelection);
                else
                    super.fireValueChanged(newSelection, oldSelection);

            }
        }
    }
}

