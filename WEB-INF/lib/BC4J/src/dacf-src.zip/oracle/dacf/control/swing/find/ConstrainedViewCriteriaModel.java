/*
 * @(#)ConstrainedViewCriteriaModel.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.dacf.control.swing.find;

import javax.infobus.DataItem;
import javax.infobus.ScrollableRowsetAccess;
import oracle.dacf.dataset.DataItemProperties;

/**
 *  This class provides a constrained view of the ViewCriteriaModel.
 *  Some of the columns which are either marked 'non-queryable' by the user
 *  or not queryable (for some SQL type) are hidden from the ViewCriteria.
 *
 *  @see FindPanel
 *  @see ViweCriteriaModel
 *  @see ViweCriteriaModelImpl
 *  @see ResultSetInfo
 *  @see oracle.jbo.ViewCriteria
 *  @see oracle.jbo.ViewCriteriaRow
 *  @version Internal
 */
public class ConstrainedViewCriteriaModel
           extends ViewCriteriaModelImpl
{

     String _columnDataItemName[] = null;

     // store column indices., store as 0 based indices
     // the only time it gets converted to 1 based index is
     // when the call is made to rsacess ., see ViewCriteriaModelImpl
     int _columnMap[] = null;

     /**
     * Constructor
     */
     public ConstrainedViewCriteriaModel()
     {

     }

      /**
      *  Specify the query column data item name.  This name will be
      *  use to get the Column name and the SQL type which in turn will
      *  be used to build the query condition
      *
      *  @param dataItemName of the column
      */
      public void setColumnDataItemName(String[] dataItemName)
      {
          _columnDataItemName = dataItemName;
          _computeColumnIndices();
      }

      /**
      *  @return the data item names for all the columns
      */
       public String[] getColumnDataItemName()
       {
           return _columnDataItemName;
       }

       public void setRowsetAccess(ScrollableRowsetAccess rsAccess)
       {
           super.setRowsetAccess(rsAccess);
           _computeColumnIndices();
       }

      // column attributes

      /**
      *  @return the number of columns
      */
      public int getColumnCount()
      {
         return ((_columnDataItemName != null ) ? _columnDataItemName.length : 0);
      }


      /**
      * return the column display name for a particular column
      */
      public String getColumnDisplayLabel(int colIndex)
      {
         return super.getColumnDisplayLabel(_mapColumnIndex(colIndex));
      }


      /**
      * get the column name., zero based index.
      *
      * @return name of the column to use in the query
      */
      public String getColumnName(int colIndex)
      {
         return super.getColumnName(_mapColumnIndex(colIndex));
      }


      /**
      * get SQL type for this column., zero based index.
      *
      */
      public int getSQLType(int colIndex)
      {
         return super.getSQLType(_mapColumnIndex(colIndex));
      }


      /**
      * return the column value for a particular column
      *
      * @param colIndex column index whose column value we are interested in.,
      *                 zero based index used
      *
      * @return column value
      *
      */
      public Object getColumnValue(int colIndex)
      {
          return super.getColumnValue(_mapColumnIndex(colIndex));
      }


     /**
     * specify the column value for a particular column
     *
     * @param colIndex column index whose value has to be set
     *                 zero based index used
     *
     */
     public void setColumnValue(int colIndex, Object value)
     {
         super.setColumnValue(_mapColumnIndex(colIndex), value);
     }

	 public Object getUserData(int colIndex)
	 {
		 return super.getUserData(_mapColumnIndex(colIndex));
	 }


	 public void setUserData(int colIndex, Object value)
	 {
		super.setUserData(_mapColumnIndex(colIndex), value);		 
	 }

     protected int _mapColumnIndex(int originalIndex)
     {
          if ( _columnMap[originalIndex] == -1)
              _computeColumnIndices();
          return _columnMap[originalIndex];
     }

     /**
     * map queryable column name to their index
     */
     protected void _computeColumnIndices()
     {
         if (_rsAccess != null )
         {
             _columnMap = new int[_columnDataItemName.length];
             for ( int i=0; i < _columnMap.length; i++)
                 _columnMap[i] = findColumnIndex(_columnDataItemName[i]);
         }
     }

     protected int findColumnIndex(String dataItemName)
     {
         int colCount = _rsAccess.getColumnCount();
         for ( int i=1; i <= colCount; i++)
         {
              try
              {
                  Object o = _rsAccess.getColumnItem(i);
                  if  ((o != null ) && ( o instanceof DataItem))
                  {
                      DataItem di = (DataItem)o;
                      String name = (String)di.getProperty(DataItemProperties.NAME);
                      String attrName = getAttributeName(dataItemName);
                      String qattrName = getAttributeName(name);
                      if ( attrName.equals(qattrName))
                          return (i-1); // store as 0 based index
                  }
              }
              catch (Exception e)
              {
                   e.printStackTrace();
              }
         }
         return -1;
     }

     /**
     * get Attribute name from the dataitem name
     */
     private String getAttributeName(String s)
     {
         int i = s.lastIndexOf('/');
         return (( i == -1) ? "" : s.substring(i+1));
     }
}
