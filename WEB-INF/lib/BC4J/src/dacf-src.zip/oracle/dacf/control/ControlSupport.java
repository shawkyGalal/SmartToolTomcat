/*
 * @(#)ControlSupport.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.dacf.control;

import java.beans.PropertyChangeEvent;
import java.beans.PropertyVetoException;
import java.util.Vector;
import javax.infobus.DataItem;
import javax.infobus.DataItemChangeManager;
import javax.infobus.DataItemValueChangedEvent;
import javax.infobus.InfoBus;
import javax.infobus.InfoBusDataConsumer;
import javax.infobus.InfoBusItemAvailableEvent;
import javax.infobus.InfoBusItemRevokedEvent;
import javax.infobus.InfoBusMembershipException;
import oracle.dacf.dataset.InfoObject;
import oracle.dacf.rp.Consumer;
import oracle.dacf.rp.ObjectBroker;
import oracle.dacf.util.DesignTime;

/**
 * This class provides default implementations for most of the methods in
 * the <TT>Control</TT> interface. <P>
 * Data aware controls must implement the <TT>Control</TT> interface in order
 * to plug into the runtime framework. <P>
 * Data aware controls should delegate the methods in the <TT>Control</TT>
 * interface to this class, which provides a standard implementation. <P>
 * This class also implements the <TT>InfoBusMember</TT> and
 * <TT>InfoBusDataConsumer</TT> interfaces, and manages the connection to
 * the InfoBus as well as the DataItem rendezvous. <P>
 * The control will automatically be registered for <TT>DataItemChange</TT>
 * events with the bound data item if the data item supports the
 * <TT>DataItemChangeManager</TT> interface. <P>
 *
 */
public class ControlSupport
    extends ConsumerSupport
    implements InfoBusDataConsumer, InfoBusManagerListener, Consumer
{
    private static boolean _DEBUG = false;

    protected Control _control;
    protected String _infoBusName;

    protected Vector _navigatedListeners;
    protected Vector _navigatingListeners;
    protected Vector _enabledListeners;
    protected String _dataItemName;

    private Object _dataItem = null;
    private boolean _enabled = true;
    private boolean _focusValidated = true;


    /**
    * Constructs the support object for a given data aware control. <P>
    * @param control   The data aware control.
    */
    public ControlSupport(Control control)
    {
        super(null);
        _control = control;
        Object obj = _control;

        _navigatedListeners = new Vector();
        _navigatingListeners = new Vector();
        _enabledListeners = new Vector();

        setInfoBusName(Control.DEFAULT_INFOBUS_NAME);

        addInfoBusPropertyListener(this);
        // control.setEnabled(isEnabled());
        InfoBusManager.getInstance().addInfoBusManagerListener(this);
    }

    /**
    ** Adds a ControlEnabledListener. <P>
    **
    ** The listener will be notified when the enabled state of the control
    ** changes. <P>
    **
    ** @param listener  The listener to add.
    */
    public final void addControlEnabledListener(ControlEnabledListener l)
    {
        _enabledListeners.addElement(l);
    }

    /**
    ** Removes a ControlEnabledListener. <P>
    **
    ** @param listener  The listener to remove.
    */
    public final void removeControlEnabledListener(ControlEnabledListener l)
    {
        _enabledListeners.removeElement(l);
    }

    /**
    * Disconnects from the InfoBus. <P>
    * @exception Throwable If fatal error.
    */
    protected void finalize() throws Throwable
    {
        _dropInfoBus();
        super.finalize();
    }

    private void _findDataItem()
    {
        if (_dataItemName != null)
        {
            InfoBus infoBus = getInfoBus();
            if (infoBus != null)
            {
                _setDataItem(infoBus.findDataItem(_dataItemName, null,
                                                  this));
            }
        }
    }

    private void _releaseDataItem()
    {
        if (_dataItemName != null)
        {
            _setDataItem(null);
        }
    }

    // InfoBusManagerListener interface implementation
    public void releaseResources(InfoBusManagerReleaseEvent e)
    {
        if (_control != null && e.appliesTo(_control.getComponent()))
        {
            removeInfoBusPropertyListener(this);
            InfoBusManager.getInstance().removeInfoBusManagerListener(this);
            _dropInfoBus();
            _navigatedListeners.removeAllElements();
            _enabledListeners.removeAllElements();
            _navigatingListeners.removeAllElements();
            clearRef();
            _control = null;
        }
    }

    // Control Interface

    /**
    ** An override of java.awt.Component.setEnabled. <P>
    **
    ** This method is used to track the intentions of the programmer.  With it
    ** we can insure that when the DataItem is available, the control reflects
    ** his wishes.
    **
    ** @param b boolean flag indicating whether the control is enabled
    */
    public void setEnabled(boolean b)
    {
        _enabled = b;
        _updateEnabled();
    } // setEnabled

    public boolean isEnabled()
    {
        if (DesignTime.inDesignTime())
           return _enabled;
        else
           return(_enabled && (_control == null || _dataItem != null));
    } // _setEnabled

    /**
    * Returns the name of the InfoBus this control is connected to. <P>
    * @return  The name of the InfoBus this control is connected to.
    * @see Control#getInfoBusName
    */
    public final String getInfoBusName()
    {
        return (_infoBusName);
    }

    /**
    * Sets the name of the InfoBus this control is connected to. <P>
    * By default, the control is connected to the default InfoBus,
    * named <TT>Control.DEFAULT_INFOBUS_NAME</TT>. <P>
    * If the named InfoBus does not exist, it is created automatically. <P>
    * If the control is already connected to an InfoBus, it is disconnected
    * first. <P>
    * @param infoBusName   The name of the InfoBus to connect to.
    * @see Control#DEFAULT_INFOBUS_NAME
    * @see Control#setInfoBusName
    */
    public synchronized void setInfoBusName(String infoBusName)
    {
        if (infoBusName == _infoBusName ||
            (infoBusName != null && infoBusName.equals(_infoBusName)))
        {
            return;
        }

        if (_infoBusName != null)
        {
            _dropInfoBus();
        }
        _infoBusName = infoBusName;

        if (infoBusName != null)
        {
            try
            {
                joinInfoBus(infoBusName);
                InfoBus infoBus = getInfoBus();
                if (infoBus == null)
                {
                    // XXX - throw exception?
                    return;
                }

                infoBus.addDataConsumer(this);
                _findDataItem();
            }
            catch (InfoBusMembershipException e)
            {
                // XXX - Do something useful here
            }
            catch (PropertyVetoException e)
            {
                // XXX - Do something useful here
            }
        }
    }


    /**
    * Returns the name of the InfoBus DataItem this control is bound to. <P>
    * @return  The name of the InfoBus DataItem this control is bound to,
    *          or <TT>null</TT> if the control is unbound.
    * @see #getDataItem
    * @see Control#getDataItemName
    */
    public String getDataItemName()
    {
        return (_dataItemName);
    }

    /**
    * Sets the name of the InfoBus DataItem this control is bound to. <P>
    * The DataItem with the given name is searched for on the InfoBus, and
    * if found, is bound to this control. <P>
    * If the control is already bound to a DataItem, it is unbound first. <P>
    * @param dataItemName  The name of the DataItem to bind to.
    * @see #getDataItem
    * @see Control#setDataItemName
    */
    public synchronized void setDataItemName(String dataItemName)
    {
        // If no change
        if (dataItemName == _dataItemName ||
            (dataItemName != null && dataItemName.equals(_dataItemName)))
        {
            return;
        }

        if (_dataItemName != null)
        {
            ObjectBroker.unsubscribe(this, _dataItemName);
        }
        
        _dataItemName = dataItemName;

        // If unbinding
        if (dataItemName == null || dataItemName.length() <= 0)
        {
            _setDataItem(null);
        }
        else
        {
            _findDataItem();
        }
    }


    /**
    * Returns the InfoBus DataItem this control is bound to. <P>
    * @return  The InfoBus DataItem this control is bound to, or
    *          <TT>null</TT> if the control is unbound.
    * @see Control#getDataItem
    */
    public Object getDataItem()
    {
        return (_dataItem);
    }


    /**
    * Determines whether setting focus to this control causes validation. <P>
    *
    * @return  <TT>true</TT> if focus into this control causes validation to
    *          occur, <TT>false</TT> otherwise.
    * @see Control#isFocusValidated
    */
    public final boolean isFocusValidated()
    {
        return (_focusValidated);
    }

    /**
    * Sets whether focus into this control causes validation to occur. <P>
    *
    * @param focusValidated    If <TT>true</TT>, focus into this control will
    *                          cause validation to occur.
    * @see Control#setFocusValidated
    */
    public final void setFocusValidated(boolean focusValidated)
    {
        _focusValidated = focusValidated;
    }


    /**
    * Adds a navigated listener to this control. <P>
    *
    * The listener will be notified of NavigateIn and NavigateOut events. <P>
    *
    * @param listener  The listener to add.
    * @see Control#addNavigatedListener
    */
    public final void addNavigatedListener(NavigatedListener listener)
    {
        _navigatedListeners.addElement(listener);
    }

    /**
    * Removes a navigated listener from this control. <P>
    *
    * @param listener  The listener to remove.
    * @see Control#removeNavigatedListener
    */
    public final void removeNavigatedListener(NavigatedListener listener)
    {
        _navigatedListeners.removeElement(listener);
    }

    /**
    * Processes a navigated event for this control. <P>
    *
    * This method is for use by the NavigationManager only. <P>
    *
    * @param event The navigated event.
    * @see Control#processNavigatedEvent
    */
    public void processNavigatedEvent(NavigatedEvent event)
    {
        NavigatedListener listeners[];
        int count = 0;
        synchronized (_navigatedListeners)
        {
            count = _navigatedListeners.size();
            listeners = new NavigatedListener[count];
            _navigatedListeners.copyInto(listeners);
        }

        boolean inEvent = (event.getType() == NavigatedEvent.NAVIGATE_IN);
        int level = event.getLevel();
        for (int i = 0; (i < count); i++)
        {
            NavigatedListener l = listeners[i];
            if (inEvent)
            {
                switch (level)
                {
                case InfoObject.LEVEL_COLUMN:
                    l.navigatedInColumn(event);
                    break;
                case InfoObject.LEVEL_ROW:
                    l.navigatedInRow(event);
                    break;
                case InfoObject.LEVEL_QUERY_VIEW:
                    l.navigatedInQueryView(event);
                    break;
                case InfoObject.LEVEL_SESSION:
                    l.navigatedInSession(event);
                    break;
                }
            }
            else // outEvent
            {
                switch (level)
                {
                case InfoObject.LEVEL_COLUMN:
                    l.navigatedOutColumn(event);
                    break;
                case InfoObject.LEVEL_ROW:
                    l.navigatedOutRow(event);
                    break;
                case InfoObject.LEVEL_QUERY_VIEW:
                    l.navigatedOutQueryView(event);
                    break;
                case InfoObject.LEVEL_SESSION:
                    l.navigatedOutSession(event);
                    break;
                }
            }
        }
    }


    /**
    * Adds a navigating listener to this control. <P>
    *
    * The listener will be notified of NavigateIn and NavigateOut events. <P>
    *
    * @param listener  The listener to add.
    * @see Control#addNavigatingListener
    */
    public final void addNavigatingListener(NavigatingListener listener)
    {
        _navigatingListeners.addElement(listener);
    }

    /**
    * Removes a navigating listener from this control. <P>
    *
    * @param listener  The listener to remove.
    * @see Control#removeNavigatingListener
    */
    public final void removeNavigatingListener(NavigatingListener listener)
    {
        _navigatingListeners.removeElement(listener);
    }

    /**
    * Processes a navigating event for this control. <P>
    *
    * This method is for use by the NavigationManager only. <P>
    *
    * @param event The navigating event.
    * @exception NavigatingException   If the navigation is redirected to a
    *                                  different control.
    * @see Control#processNavigatingEvent
    */
    public void processNavigatingEvent(NavigatingEvent event)
        throws NavigatingException
    {
        NavigatingListener listeners[];
        int count = 0;
        synchronized (_navigatingListeners)
        {
            count = _navigatingListeners.size();
            listeners = new NavigatingListener[count];
            _navigatingListeners.copyInto(listeners);
        }

        for (int i = 0; (i < count); i++)
        {
            listeners[i].navigatingOut(event);
        }
    }

    // InfoBusDataConsumer Interface

    /**
    * This method is called by the <TT>InfoBus</TT> class on behalf of a data
    * producer that is announcing the availability of a new data item by
    * name. <P>
    *
    * If the control is not currently bound to a data item, and the name of the
    * new data item matches the control's data item name, then the control is
    * bound to the new data item. <P>
    *
    * If the control is not currently bound to a data item, and the name of the
    * new data item is a prefix for the control's data item name, then the
    * InfoBus is searched for a matching data item, and the control is bound
    * to it if one is found.  For example, if the item <TT>A.B.C</TT> is
    * announced as available, and the control's data item name is set to
    * <TT>A.B.C.D.E</TT>, the control will ask the InfoBus to find the
    * data item <TT>A.B.C.D.E</TT> in response to the announcement of
    * <TT>A.B.C</TT> -- this means that producers only need to publish their
    * root prefix, and allows them to create child producers on demand. <P>
    * @param event The event.
    */
    public void dataItemAvailable(InfoBusItemAvailableEvent event)
    {
        // _debug(event.getDataItemName() + " dataItemAvailable");
        if (_dataItem == null)
        {
            if (_dataItemName != null)
            {
                String name = event.getDataItemName();

                if (_dataItemName.startsWith(name))
                {
                    int len = name.length();
                    Object dataItem = null;

                    // _debug("startWith passed: " + name);
                    if (_dataItemName.length() == len)
                    {
                        // _debug("exact match");
                        dataItem = event.requestDataItem(this, null);
                    }
                    else
                    {
                        if ( _dataItemName.charAt(len) == 
                             InfoObject.ITEMNAME_DELIMITER.charAt(0))
                        {
                            InfoBus infoBus = getInfoBus();

                            // _debug("its the parent; look for child");
                            if (infoBus != null)
                            {
                                dataItem = infoBus.findDataItem(_dataItemName,
                                                                null,
                                                                this);
                            }
                        }
                    }
                    if (dataItem != null)
                    {
                        // _debug("dataitem found; set it");
                        _setDataItem(dataItem);
                    }
                }
            }
        }
    }

    /**
    * This method is called by the <TT>InfoBus</TT> class on behalf of a data
    * producer that is revoking the availability of a previously announced
    * data item. <P>
    * If the name of the data item in the event matches the control's data
    * item name, the control is unbound from its data item. <P>
    * @param event The event.
    */
    public void dataItemRevoked(InfoBusItemRevokedEvent event)
    {
        // _debug(event.getDataItemName() + " dataItemRevoked");
        if (_dataItemName != null &&
            _dataItemName.equals(event.getDataItemName()))
        {
            _setDataItem(null);
        }
    }

    /**
    * This method gets called when the object's <TT>InfoBus</TT> property
    * is changed. <P>
    * The object is removed as a data consumer from its previous InfoBus,
    * and is added as a consumer to its new InfoBus. <P>
    * @param event The event.
    */
    public void propertyChange(PropertyChangeEvent event)
    {
        if (event.getPropertyName().equals("InfoBus"))
        {
            Object oldVal = event.getOldValue();
            Object newVal = event.getNewValue();

            if (oldVal != newVal)
            {
                if (oldVal != null && oldVal instanceof InfoBus)
                {
                    ((InfoBus)oldVal).removeDataConsumer(this);
                }

                if (newVal != null && newVal instanceof InfoBus)
                {
                    ((InfoBus)newVal).addDataConsumer(this);
                }
            }
        }
    }



    // Other Helpers

    /**
    * Delegates focus changes to the <TT>NavigationManager</TT>. <P>
    * UI controls should override the <TT>requestFocus()</TT> method of
    * <TT>Component</TT> and invoke this method after invoking
    * <TT>super.requestFocus()</TT>. <P>
    */
    public void handleRequestFocus()
    {
        if (_focusValidated)
        {
            NavigationManager fm = NavigationManager.getNavigationManager();
            fm.validateFocusChange(_control);
        }
    }



    // Private Methods

    /**
    * Removes this object from its currently bound InfoBus and dataitem.
    */
    private synchronized void _dropInfoBus()
    {
        _setDataItem(null);

        InfoBus infoBus = getInfoBus();
        if (infoBus != null)
        {
            infoBus.removeDataConsumer(this);
        }

        try
        {
            leaveInfoBus();
        }
        catch (InfoBusMembershipException e)
        {
            // Ignore
        }
        catch (PropertyVetoException e)
        {
            // Ignore
        }
    }

    /**
    * Binds the control to a data item. <P>
    * If the new data item implements the <TT>DataItemChangeManager</TT>
    * interface, the control is added as a <TT>DataItemChangeListener</TT> for
    * the data item. <P>
    * The control's <TT>dataItemChanged</TT> and <TT>dataItemValueChanged</TT>
    * methods are invoked after the control has been bound to the new data
    * item. <P>
    * @param dataItem  The new data item to bind to.
    */
    protected synchronized void _setDataItem(Object dataItem)
    {
        Object oldDataItem = _dataItem;
        if (dataItem != oldDataItem)
        {
            if (oldDataItem != null)
            {
                if (oldDataItem instanceof DataItemChangeManager)
                {
                    ((DataItemChangeManager)oldDataItem).removeDataItemChangeListener(_control);
                }
            }

            _dataItem = dataItem;

            if (dataItem != null)
            {
                if (dataItem instanceof DataItemChangeManager)
                {
                    ((DataItemChangeManager)dataItem).addDataItemChangeListener(_control);
                }
            }

            _control.dataItemChanged(oldDataItem, _dataItem);

            DataItemValueChangedEvent event =
                new DataItemValueChangedEvent(this, _dataItem, null);
            _control.dataItemValueChanged(event);
            
            if (oldDataItem != null && oldDataItem instanceof DataItem)
            {
                ((DataItem)oldDataItem).release();
            }
            _updateEnabled();
        }
    }

    protected void _updateEnabled()
    {
        boolean enabled = isEnabled();
        ControlEnabledListener listeners[];
        int count = 0;

        synchronized(_enabledListeners)
        {
            count = _enabledListeners.size();
            listeners = new ControlEnabledListener[count];
            _enabledListeners.copyInto(listeners);
        }

        for (int i = 0; (i < count); i++)
        {
            listeners[i].enabledChanged(enabled);
        }
    }

    private void _debug(String msg)
    {
        if (_DEBUG)
        {
            System.out.println("ControlSupport: " + _dataItemName + ": "+ msg);
        }
    }
}  // ControlSupport
