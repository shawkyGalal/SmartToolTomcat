/*
 * @(#)LOVBeanInfo.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.dacf.control.swing;

import java.beans.PropertyDescriptor;
import java.beans.SimpleBeanInfo;

/**
 * bean info class for the find panel control
 *
 * @version SDK
 */
public class LOVBeanInfo extends SimpleBeanInfo
{

   /**
   * LOV property list
   */
   private String [][] propertyList = new String[][]
   {
     {"automaticRefresh", "getAutomaticRefresh", "setAutomaticRefresh", null},
     {"title", "getTitle", "setTitle", null},
     {"automaticRefresh", "getAutomaticRefresh", "setAutomaticRefresh", null},
     {"dataItemName", "getDataItemName", "setDataItemName", "oracle.jdeveloper.daceditors.DataItemNameEditor"},
   };

  /**
  * Constructor
  */
  public LOVBeanInfo()
  {
    super();
  }

  /**
  * get the Class object for the bean
  *
  * @return class object for the bean
  */
  protected Class getBeanClass()
  {
    return LOV.class;
  }


  /**
  * get list of property descriptors for the bean
  *
  * @return list of property descriptors
  */
  public PropertyDescriptor[] getPropertyDescriptors()
  {
    try
    {
       PropertyDescriptor[] pdarr = new PropertyDescriptor[propertyList.length];

       for (int i = 0 ; i < propertyList.length ; i++)
       {
          pdarr[i] = new PropertyDescriptor(propertyList[i][0],
                                            getBeanClass(),
                                            propertyList[i][1],
                                            propertyList[i][2]);

          if(propertyList[i][3] != null)
          {
             try
             {
               pdarr[i].setPropertyEditorClass(Class.forName(propertyList[i][3]));
             }
             catch(ClassNotFoundException ex)
             {
               ex.printStackTrace(System.err);
             }
          }
       }

       return pdarr;

    }
    catch (Exception e)
    {
       e.printStackTrace(System.err);
       return null;
    }
  }
}
