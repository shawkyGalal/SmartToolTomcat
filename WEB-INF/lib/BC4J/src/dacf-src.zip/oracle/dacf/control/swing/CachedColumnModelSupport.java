/*
 * @(#)CachedColumnModelSupport.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.dacf.control.swing;

import java.util.Enumeration;
import java.util.Vector;
import javax.infobus.ImmediateAccess;
import oracle.dacf.control.Control;
import oracle.dacf.control.InfoBusManagerReleaseEvent;

/**
 * List Column Model which supports caching of attribute values.
 *
 * The ImmediateAccess returned from RowsetAccess is wrapped with a 
 * CachedImmediateAccess item. This is done to reduce the number 
 * of getAttribute calls on the ViewObject.
 * 
 * This class manages the lifetime of cached items by responding 
 * to the data item change events
 *
 */
public class CachedColumnModelSupport
extends ColumnModelSupport
{
	Vector _elements;
	boolean _cachingEnabled = true;

	static boolean _DEBUG = true;


	public CachedColumnModelSupport(Control c)
	{
		super(c);
		_elements = new Vector(10);
	} 

	public void setCachingEnabled(boolean flag)
	{
		_cachingEnabled = flag;
	}

	public boolean isCachingEnabled()
	{
		return _cachingEnabled;
	}


	/**
	* Get the item at the specifed 0 based index
	* @return the item
	*/
	public Object getElementAt(int index)
	{
		try
		{
			if ( isCachingEnabled() )
			      return(_elements.elementAt(index));
			else
				  return super.getElementAt(index);

		} 
		catch (Exception exc)
		{
			return null;
		}
	}

	protected void rowsAvailable()
	{
		if ( isCachingEnabled() )
		{
			int count = super.getSize();
 
         	addItems(0, count);
		}

		super.rowsAvailable();
	}

	protected void rowsRevoked()
	{   
		if ( isCachingEnabled() )
		{
		
			Enumeration elem = _elements.elements();
	
			while (elem.hasMoreElements())
			{
				CachedImmediateAccess cia = (CachedImmediateAccess)elem.nextElement();
				cia.releaseResources();
			}
	
			_elements.removeAllElements();
		}

		super.rowsRevoked();

	}

	protected void rowsAdded(int startIndex, int count)
	{
		if ( isCachingEnabled() )
		{
			refresh();
		}

		super.rowsAdded(startIndex, count);
	}
	

	protected void rowsChanged(int startIndex, int count)
	{
		if ( isCachingEnabled() )
		{
			refresh();
		}

		super.rowsChanged(startIndex, count);
	}

	private void refresh()
	{
		revokeAllRows();

		int count = super.getSize();

		addItems(0, count);
	}

	protected void revokeAllRows()
	{
		if ( isCachingEnabled() )
		{
		
			Enumeration elem = _elements.elements();
	
			while (elem.hasMoreElements())
			{
				CachedImmediateAccess cia = (CachedImmediateAccess)elem.nextElement();
	
				cia.releaseResources();
			}
	
			_elements.removeAllElements();
		}

	}

	protected Object findCachedItem(Object x)
	{
		Enumeration elem = _elements.elements();

		while (elem.hasMoreElements())
		{

			CachedImmediateAccess cia = (CachedImmediateAccess)elem.nextElement();

			Object wia = cia.getWrappedIA();

			if (wia == x )
				return cia;
		}

		return null;
	}

	// notification to drop dataitem refernces
    protected void _releaseResourcesInternal(InfoBusManagerReleaseEvent e)
    {
		_elements = null;
		super._releaseResourcesInternal(e);
    }

	// startIndex is zero based
	private void addItems(int startIndex, int count)
	{
		for (int i=0; i < count; i++)
		{
			ImmediateAccess ia = (ImmediateAccess)super.getElementAt(startIndex + i);

			CachedImmediateAccess cia = new CachedImmediateAccess(ia);

			_elements.insertElementAt(cia,startIndex + i);
		}
	}

	

}


