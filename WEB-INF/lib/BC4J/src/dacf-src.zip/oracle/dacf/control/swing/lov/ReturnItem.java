/*
 * @(#)ReturnItem.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.dacf.control.swing.lov;

import javax.infobus.InvalidDataException;

/**
 *  Interface definiton for return item facility.
 *
 *  @version SDK
 *
 */
public interface ReturnItem
{
   /**
   *  Define the 'return item ' identifier for a particular column.
   *
   * @param columnIndex column for which the 'return item' identifier is being
   *                    set
   * @param returnItemIndentifier  an identifier to return items
   */
   public void setReturnItemName(int columnIndex, Object returnItemName);


   /**
   *  Return the 'return item' for a particular column
   *
   * @param columnIndex column index
   */
   public Object getReturnItemName(int columnIndex);

   /**
   *  remove all 'return item' identifiers
   *
   */
   public void removeAll();

   /**
   * set the value to be returned for a particular column index.
   */
   public void setValue(int columnIndex, Object value)
           throws InvalidDataException;

   /**
   *  make use of the return item names to actually return item values
   */
   public void executeReturnItems();
}
