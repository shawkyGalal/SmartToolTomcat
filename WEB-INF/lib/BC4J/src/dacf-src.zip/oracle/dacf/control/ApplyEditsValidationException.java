/*
 * @(#)ApplyEditsValidationException.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.dacf.control;

// imports
/**
 ** This exception is used by implemented of the ApplyEditsListener
 ** interface to abort navigation when a validation exception is thrown
 ** by the InfoBus producers.
 **
 ** @version PUBLIC
 */
public class ApplyEditsValidationException
    extends java.lang.RuntimeException
{
    /**
    ** This exception is thrown when a validation exception is raised. <P>
    **
    ** This exception is used by implemented of the ApplyEditsListener
    ** interface to abort navigation when a validation exception is thrown
    ** by the InfoBus producers.
    */
    public ApplyEditsValidationException()
    {
        this(null);
    } // ApplyEditsValidationException

    /**
    ** This exception is thrown when a validation exception is raised. <P>
    **
    ** This exception is used by implemented of the ApplyEditsListener
    ** interface to abort navigation when a validation exception is thrown
    ** by the InfoBus producers.
    **
    ** @param s message text for the exception
    */
    public ApplyEditsValidationException(String s)
    {
        super(s);
    } // AppyEditsValidationException
    
}  // ApplyEditsValidationException


//
//   oracle/dacf/control/ApplyEditsValidationException.java
//   Oracle JDeveloper
//   Copyright (c) 1999 by Oracle Corporation
//   All rights reserved. 
//
