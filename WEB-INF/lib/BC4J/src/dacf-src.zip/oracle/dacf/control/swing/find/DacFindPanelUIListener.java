/*
 * @(#)DacFindPanelUIListener.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.dacf.control.swing.find;

import oracle.dacf.control.swing.FindPanel;

/**
 *  The DacFindPanelUIListener interface is used by the DacFindPanelUI class to
 *  notify various button clicks.
 *
 *  A class which implements this interface will typically call appropriate 
 *  methods in response to the button click. It may use FindPanel methods to 
 *  implement the action associated with button click.
 *
 *  @version   INTERNAL
 *  @see       DacFindPanelUI
 *  @see       FindPanel
 */
public interface DacFindPanelUIListener
{
   /**
   *  A notification that the Find button was clicked
   */
   public void findButtonClicked();

   /**
   *  A notification that the Close button was clicked
   */
   public void closeButtonClicked();

   /**
   * A notification that the Reset button was clicked
   */
   public void resetButtonClicked();

   /**
   * A notification that the Help button was clicked
   */
   public void helpButtonClicked();

   /**
   * A notification that the OR button was clicked
   */
   public void orButtonClicked();

   /**
   * A notification that the Remove button was clicked
   */
   public void removeButtonClicked();

   /**
   * A notification that the Remove All button was clicked
   */
   public void removeAllButtonClicked();
}
