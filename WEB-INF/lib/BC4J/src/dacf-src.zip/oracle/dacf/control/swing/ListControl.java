/*
 * @(#)ListControl.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.dacf.control.swing;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.util.Vector;
import javax.infobus.DataItem;
import javax.infobus.DataItemAddedEvent;
import javax.infobus.DataItemChangeListener;
import javax.infobus.DataItemDeletedEvent;
import javax.infobus.DataItemRevokedEvent;
import javax.infobus.DataItemValueChangedEvent;
import javax.infobus.ImmediateAccess;
import javax.infobus.RowsetCursorMovedEvent;
import javax.infobus.ScrollableRowsetAccess;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.ListCellRenderer;
import javax.swing.ListModel;
import javax.swing.ListSelectionModel;
import oracle.dacf.control.Control;
import oracle.dacf.control.ControlEnabledListener;
import oracle.dacf.control.ControlSupport;
import oracle.dacf.control.DualBindingControl;
import oracle.dacf.control.InfoBusManager;
import oracle.dacf.control.InfoBusManagerListener;
import oracle.dacf.control.InfoBusManagerReleaseEvent;
import oracle.dacf.control.NavigatedEvent;
import oracle.dacf.control.NavigatedListener;
import oracle.dacf.control.NavigatingEvent;
import oracle.dacf.control.NavigatingException;
import oracle.dacf.control.NavigatingListener;
import oracle.dacf.dataset.DataItemProperties;
import oracle.dacf.dataset.InfoObject;

/**
 * ListControl is a data aware listbox. In it's default configuration
 * a ListControl provides a read only view of all the values of a column in a
 * <TT>ScrollableRowsetAccess</TT><P>
 *
 * ListControl is a composite control comprising of a JList
 * and a JScrollPane.<P>
 *
 * ListControl, by default is used as a navigational control. The 
 * <TT>_dataItemUsageMode</TT> property is set to <TT>FOR_NAVIGATION</TT> 
 * and the the ListControl navigates through the rowset that is associated 
 * with the attribute that is bound via the <TT>_dataItemName</TT> property.<P>
 *
 * The ListControl can also be used to update values like a ComboBoxControl.
 * When <TT>_dataItemUsageMode</TT> is set to <TT>FOR_UPDATE</TT> the ListBox 
 * ceases to navigate and is used instead to update the value that is bound via 
 * the <TT>_dataItemNameForUpdate</TT> property.<P>
 *
 * Using the <TT>_updateControlSupport</TT> we maintain a binding to the 
 * <TT>ImmediateAccess</TT> you want to update. In that way our model always
 * contains the current <TT>ImmediateAccess</TT> value.<P>
 *
 * When a value is chosen via the ListControl and we are in an updatable state
 * that value is updated.
 *
 * @version PUBLIC
 */
public class ListControl
    extends JPanel
    implements Control, ControlEnabledListener, DualBindingControl,
               InfoBusManagerListener
{
    private ControlSupport _navigationControlSupport;
    private ControlSupport _updateControlSupport;
    private JScrollPane _scrollPane = new JScrollPane();
    private JList _listView;
    private ListDataSource _dataSource;
    private int _dataItemUsageMode;

    /**
    *  Constructs a default ListControl. The
    *  renderer property of the constructed instance
    *  is set to ListCellPainter.
    */
    public ListControl()
    {
        _listView = new JList();
        _init();
    }

    /**
    *  Constructs a ListControl that displays the elements in the specified
    *  vector. The renderer property of the constructed instance
    *  is set to ListCellPainter.
    *
    *  @param listData vector to be displayed
    */

    public ListControl(Vector listData)
    {
        _listView = new JList(listData);
        _init();
    }

    /**
    *  Constructs a ListControl that displays the elements in the specified
    *  array. The renderer property of the constructed instance
    *  is set to ListCellPainter.
    *
    *  @param listData array to be displayed
    */
    public ListControl(Object listData[])
    {
        _listView = new JList(listData);
        _init();
    }

    /**
    *  Constructs a ListControl that displays the elements in the specified
    *  model. The renderer property of the constructed instance
    *  is set to ListCellPainter.
    *
    *  @param dataModel  data model to be displayed
    */
    public ListControl(ListModel dataModel)
    {
        _listView = new JList(dataModel);
        _init();
    }



    /**
    *  Delegates to underlying JList
    *  @see javax.swing.JList
    */

    public void setListData(Object listData[])
    {
        _listView.setListData(listData);
    }


    /**
    * Gets the underlying JList used by this control. <P>
    * @return JList being used by this control
    */
    public final JList getList()
    {
        return _listView;
    }

    // InfoBusManagerListener interface implementation
    public void releaseResources(InfoBusManagerReleaseEvent e)
    {
        if (e.appliesTo(this))
        {
            InfoBusManager.getInstance().removeInfoBusManagerListener(this);
            _navigationControlSupport.removeControlEnabledListener(this);
            _navigationControlSupport = null;
            _updateControlSupport = null;
        }
    }
    // ControlEnabledListener interface
    public void enabledChanged(boolean b)
    {
        _listView.setEnabled(b);
    }

    // Control Interface
    /**
    ** An override of java.awt.Component.setEnabled. <P>
    **
    ** @param b boolean flag indicating whether the control is enabled
    */
    public void setEnabled(boolean b)
    {
        if (_navigationControlSupport!= null)
        {
            _navigationControlSupport.setEnabled(b);
        }
    } // setEnabled

    /**
    * Returns the name of the InfoBus this control is connected to. <P>
    * Most controls should delegate this method to <TT>ControlSupport</TT>. <P>
    * @return  The name of the InfoBus this control is connected to.
    * @see ControlSupport#getInfoBusName
    */
    public final String getInfoBusName()
    {
        return (_dataSource.getInfoBusName());
    }

    /**
    * Sets the name of the InfoBus this control is connected to. <P>
    * If the named InfoBus does not exist, it is created automatically. <P>
    * If the control is already connected to an InfoBus, it is disconnected
    * first. <P>
    * Most controls should delegate this method to <TT>ControlSupport</TT>. <P>
    * @param infoBusName   The name of the InfoBus to connect to.
    * @see ControlSupport#setInfoBusName
    */

    public final void setInfoBusName(String infoBusName)
    {
        _dataSource.setInfoBusName(infoBusName);
    }

    /**
    * Returns the name of the InfoBus DataItem this control is bound to. <P>
    * Most controls should delegate this method to <TT>ControlSupport</TT>. <P>
    * @return  The name of the InfoBus DataItem this control is bound to,
    *          or <TT>null</TT> if the control is unbound.
    * @see #getDataItem
    * @see ControlSupport#getDataItemName
    */
    public final String getDataItemName()
    {
        if ( _dataSource != null )
        {
            return (_dataSource.getDataItemName());
        }
        return(null);
    }

    /**
    * Sets the name of the InfoBus DataItem this control is bound to. <P>
    * The DataItem with the given name is searched for on the InfoBus, and
    * if found, is bound to this control. <P>
    * If the control is already bound to a DataItem, it is unbound first. <P>
    * Most controls should delegate this method to <TT>ControlSupport</TT>. <P>
    * @param dataItemName  The name of the DataItem to bind to.
    * @see #getDataItem
    * @see ControlSupport#setDataItemName
    */
    public final void setDataItemName(String dataItemName)
    {
        _initDataSource();
        _dataSource.setDataItemName(dataItemName);

        if (dataItemName != null)
        {
            // by default we bind to the roswet associated with this
            // attribute for navigation 
            int i = dataItemName.lastIndexOf(InfoObject.ITEMNAME_DELIMITER) ;
            if (i > 0 && _navigationControlSupport != null)
            {
                // Listen on rowset
                _navigationControlSupport.setDataItemName(dataItemName.substring(0, i));
            }
        }
    }

    /**
    * Returns the InfoBus DataItem this control is bound to. <P>
    * @return  The InfoBus DataItem this control is bound to, or
    *          <TT>null</TT> if the control is unbound.
    * @see ControlSupport#getDataItem
    */

    public final Object getDataItem()
    {
        ControlSupport cs =
            _dataItemUsageMode == DualBindingControl.FOR_NAVIGATION
              ? _navigationControlSupport : _updateControlSupport;
        // this is wrong
        return(cs == null ? null : cs.getDataItem());
    }

    /**
    * Notifies the control that the bound InfoBus DataItem has changed. <P>
    * The control can safely ignore this notification. <P>
    * @param oldDataItem   The formerly bound DataItem (can be <TT>null</TT>).
    * @param newDataItem   The newly bound DataItem (can be <TT>null</TT>).
    */
    public final void dataItemChanged(Object oldDataItem, Object newDataItem)
    {
        // this is a navigational update
        if (_dataItemUsageMode == DualBindingControl.FOR_NAVIGATION)
        {
            _updateSelection(newDataItem) ;
        }

        // this is a value changing update
        else
        {
            if (_dataSource != null)
            {
                                // Notify our dataSource
                _dataSource._selectedItemChanged(oldDataItem, newDataItem);
            }

        }
    }

    /**
    * Returns the AWT component associated with this control. <P>
    * @return  The AWT component for this control.
    */
    public final Component getComponent()
    {
        return (this);
    }

    /**
    * Determines whether focus into this control causes validation to
    * occur. <P>
    * Most controls should delegate this method to <TT>ControlSupport</TT>. <P>
    * @return  <TT>true</TT> if focus into this control causes validation to
    *          occur, <TT>false</TT> otherwise.
    * @see ControlSupport#isFocusValidated
    */
    public final boolean isFocusValidated()
    {
        return(_navigationControlSupport == null ?
               false : _navigationControlSupport.isFocusValidated());
    }

    /**
    * Sets whether focus into this control causes validation to occur. <P>
    * Delegates to <TT>ControlSupport</TT>. <P>
    * @param focusValidated    If <TT>true</TT>, focus into this control will
    *                          cause validation to occur.
    * @see ControlSupport#setFocusValidated
    */
    public final void setFocusValidated(boolean focusValidated)
    {
        if (_navigationControlSupport != null)
        {
            _navigationControlSupport.setFocusValidated(focusValidated);
        }
    }

    /**
    * Adds a navigated listener to this control. <P>
    * The listener will be notified of NavigateIn and NavigateOut events. <P>
    * Delegates to <TT>ControlSupport</TT>. <P>
    * @param listener  The listener to add.
    * @see ControlSupport#addNavigatedListener
    */

    public final void addNavigatedListener(NavigatedListener listener)
    {
        if (_navigationControlSupport != null)
        {
            _navigationControlSupport.addNavigatedListener(listener);
        }
    }

    /**
    * Removes a navigated listener from this control. <P>
    * @param listener  The listener to remove.
    */
    public final void removeNavigatedListener(NavigatedListener listener)
    {
        if (_navigationControlSupport != null)
        {
            _navigationControlSupport.removeNavigatedListener(listener);
        }
    }

    /**
    * Processes a navigated event for this control. <P>
    * This method is for use by the NavigationManager only. <P>
    * @param event The navigated event.
    * @see ControlSupport#processNavigatedEvent
    */
    public final void processNavigatedEvent(NavigatedEvent event)
    {
        if (_navigationControlSupport != null)
        {
            _navigationControlSupport.processNavigatedEvent(event);
        }
    }

    /**
    * Adds a navigating listener to this control. <P>
    * The listener will be notified of NavigatingEvents. <P>
    * @param listener  The listener to add.
    */
    public final void addNavigatingListener(NavigatingListener listener)
    {
        if (_navigationControlSupport != null)
        {
            _navigationControlSupport.addNavigatingListener(listener);
        }
    }

    /**
    * Removes a previusly added navigating listener <P>
    * @param listener  The listener to remove.
    */

    public final void removeNavigatingListener(NavigatingListener listener)
    {
        if (_navigationControlSupport != null)
        {
            _navigationControlSupport.removeNavigatingListener(listener);
        }
    }

    /**
    * Processes a navigating event for this control. <P>
    * This method is for use by the NavigationManager only. <P>
    * @param event The navigating event.
    * @see ControlSupport#processNavigatedEvent
    * @exception   NavigatingException    Indicates navigation rejected.
    */
    public final void processNavigatingEvent(NavigatingEvent event)
        throws NavigatingException
    {
        if (_navigationControlSupport != null)
        {
            _navigationControlSupport.processNavigatingEvent(event);
        }
    }

    //DataItemChangeListener Interface
    /**
    * Indicates a changed value in the bound data item. <P>
    * A reference to the data item that changed can be obtained from the
    * event. <P>
    * @param event Contains change information.
    * @see javax.infobus.DataItemChangeListener#dataItemValueChanged
    */
    public final void dataItemValueChanged(DataItemValueChangedEvent event)
    {
        // The navigation is handled by data source, we handle the update here
        if (_dataItemUsageMode == DualBindingControl.FOR_UPDATE)
        {
            Object item = event.getChangedItem();

            if (item instanceof DataItem)
            {
                Boolean updateable =
                    (Boolean)((DataItem)item).getProperty(DataItemProperties.UPDATEABLE);
                
                if (updateable != null)
                {
                    // only enable the control if it is updateable
                    setEnabled(updateable.booleanValue());
                }
            }
            if (_dataSource != null)
            {
                _dataSource.selectionChanged(event.getChangedItem());
            }
        }
    }

    /**
    * Indicates that a new item was added to the bound aggregate data item
    * (e.g. <TT>ArrayAccess</TT>, a JDK Collection, etc). <P>
    * A reference to the data item that was added, and a reference to the one
    * that gained it, can be obtained from the event. <P>
    * @param event Contains details of the addition.
    * @see javax.infobus.DataItemChangeListener#dataItemAdded
    */

    public final void dataItemAdded(DataItemAddedEvent event)
    {
        // Handled by data source
    }

    /**
    * Indicates that an item was deleted from the bound aggregate data item
    * (e. g. <TT>ArrayAccess</TT>, a JDK Collection, etc). <P>
    * A reference to the data item that was deleted, and a reference to the
    * one that lost it, can be obtained from the event. <P>
    * @param event Contains details of the deletion.
    * @see javax.infobus.DataItemChangeListener#dataItemDeleted
    */

    public final void dataItemDeleted(DataItemDeletedEvent event)
    {
        // Handled by data source
    }

    /**
    * Indicates that the bound data item (and its sub-items, if any) has been
    * revoked, and is temporarily unavailable. <P>
    * A reference to the data item that was revoked can be obtained from
    * the event. <P>
    * @param event Contains details of the revoked data.
    * @see javax.infobus.DataItemChangeListener#dataItemRevoked
    */
    public final void dataItemRevoked(DataItemRevokedEvent event)
    {
        // Handled by data source
    }

    /**
    * Indicates that the cursor for the bound <TT>RowsetAccess</TT> data item
    * has changed rows. <P>
    * A reference to the rowset data item can be obtained from the event. <P>
    * @param event Contains details of the cursor move.
    * @see javax.infobus.DataItemChangeListener#rowsetCursorMoved
    */
    public final void rowsetCursorMoved(RowsetCursorMovedEvent event)
    {
        // Update selection
        _updateSelection(event.getSource());
    }

    /**
    * String represntation of this object <P>
    * @return String describing this object
    */
    public String toString()
    {
        return(_listView + "[" + getDataItemName() + "]");
    }

    /**
    *  Called by the constructor to create the selection model
    *  to be used by this control. <P>
    *  @return an implementation of ListSelectionModel that allows
    *          single selections only
    */
    protected ListSelectionModel createSelectionModel()
    {
        return(new SingleSelector(this));
    }

    public String getMode()
    {
        String s = new String("UPDATE");
        
        if (getDataItemUsageMode() == DualBindingControl.FOR_NAVIGATION)
        {
            s = new String("NAVIGATION");
        }
        return(s);
    }

    /**
    * get value of the dataitem as a string
    *
    * @param newDataItem data item
    */
    public String getName(Object newDataItem)
    {
        String n = "";
        if (newDataItem instanceof ImmediateAccess)
        {
            if (newDataItem != null)
            {
                n = ((ImmediateAccess)newDataItem).getValueAsString();
            }
        }
        return(n);
    }
 
    /**
    * update the current selection 
    *
    * @param dataitem 
    */
    private void _updateSelection(Object dataItem)
    {
        if (getDataItemUsageMode() == DualBindingControl.FOR_NAVIGATION)
        {
            if (dataItem != null && dataItem instanceof ScrollableRowsetAccess)
            {
                ScrollableRowsetAccess rowset =
                    (ScrollableRowsetAccess)dataItem;
                int newSelection = rowset.getRow() - 1;
                _listView.setSelectedIndex(newSelection) ;
            }
        }
    }

    // DualBindingControl interface

    /**
    * Sets the dataItemName to be used for updating the values via the ListBox
    *
    * @param  valueDataItemName  Fully qaulified name of the
    *                            name of the dataitem
    */
    public void setDataItemNameForUpdate(String valueDataItemName)
    {
        if (null == _dataSource)
        {
            _initDataSource();
        }
        if (_updateControlSupport != null)
        {
            _updateControlSupport.setDataItemName(valueDataItemName);
        }
    }


    /**
    *  Get the name of the dataItem being used for updating the values in the 
    *  the list
    *  @return  modelDataItemName property
    */
    public String getDataItemNameForUpdate()
    {
        return(_updateControlSupport == null ?
               null : _updateControlSupport.getDataItemName());
    }


    /**
    *  Determines whether the values that are selected in the ListBox
    *  are used to navigate through the dataItem<P>
    *
    * @param navigable if true the values that are selected in the ListBox 
    *  are used to navigate through the dataItem.
    */
    public void setDataItemUsageMode(int usage)
    {
        _dataItemUsageMode = usage;

        // if we want this to be able to update dynamicly while running when 
        // they switch between modes then we are going to have to do something
        // like we do in the ComboBox control for this method
    }


    /**
    * get the data item usage mode. Possible values include Navigation and 
    * Update
    *
    * @return the mode in which the ListControl is configured to work
    */
    public int getDataItemUsageMode()
    {
        return(_dataItemUsageMode);
    }

    /**
    * initialize the data source
    */
    private void _initDataSource()
    {
        if (_dataSource == null)
        {
            // Initialize dataSource with our current model
            _dataSource = new ListDataSource(_listView, this);
            _listView.setModel(_dataSource);
            _listView.setCellRenderer(ListCellPainter.getPainter());
            _listView.setSelectionModel(createSelectionModel());
        }
    }

    /**
    * initialize
    */
    private void _init()
    {
        setLayout(new BorderLayout());
        _scrollPane.getViewport().setView(_listView);
        add(_scrollPane, BorderLayout.CENTER);
        _navigationControlSupport = new ControlSupport(this);
        _navigationControlSupport.addControlEnabledListener(this);
        _updateControlSupport = new ControlSupport(this);
        InfoBusManager.getInstance().addInfoBusManagerListener(this);
        setDataItemUsageMode(DualBindingControl.FOR_NAVIGATION);

        // set the JPanel to the jList default
        setBackground(_listView.getBackground());
        setForeground(_listView.getForeground());
        setFont(_listView.getFont());
    }


    // start overrides for composite dacs
    public void setOpaque(boolean isOpaque)
    {
        if (_listView != null)
        {
            super.setOpaque(isOpaque);
            _listView.setOpaque(isOpaque);
        }
    }


    public void setToolTipText(String text)
    {
        if (_listView != null)
        {
            super.setToolTipText(text);
            _listView.setToolTipText(text);
        }
    }                  

    // end overrides for composite dacs



    // start properties of JList exposed
    public ListCellRenderer getCellRenderer()
    {
        return _listView.getCellRenderer();
    }

    public void setCellRenderer(ListCellRenderer cellRenderer)
    {
        _listView.setCellRenderer(cellRenderer);
    }

    /**
    *  Sets the fixedCellHeight of underlying JList
    *  @see javax.swing.JList
    */
    public final void setFixedCellHeight(int fixedCellHeight)
    {
        _listView.setFixedCellHeight(fixedCellHeight);
    }


    /**
    *  Gets the fixedCellHeight of underlying JList
    *  @see javax.swing.JList
    */
    public final int getFixedCellHeight()
    {
        return _listView.getFixedCellHeight();
    }

    /**
    *  Sets the fixedCellWidth of underlying JList
    *  @see javax.swing.JList
    */
    public final void setFixedCellWidth(int fixedCellWidth)
    {
        _listView.setFixedCellWidth(fixedCellWidth);
    }

    /**
    *  Gets the fixedCellWidth of underlying JList
    *  @see javax.swing.JList
    */
    public final int getFixedCellWidth()
    {
        return _listView.getFixedCellWidth();
    }


    public void setModel(ListModel model)
    {
        _listView.setModel(model);
    }

    public ListModel getModel()
    {
        return _listView.getModel();
    }

    public void setPrototypeCellValue(Object prototypeCellValue)
    {
        _listView.setPrototypeCellValue(prototypeCellValue);
    }

    public Object getPrototypeCellValue()
    {
        return _listView.getPrototypeCellValue();
    }


    /**
    * Moves the selected index to the specfied index. If the
    * control is bound to a dataItem the currency of the
    * bound ScrollableRowsetAccess is moved as well. <P>
    * @param index the position where the selection should be
    *              moved
    */
    public void setSelectedIndex(int index)
    {
        _listView.setSelectedIndex(index);
    }

    public int getSelectedIndex()
    {
        return  _listView.getSelectedIndex();
    }



    public void setSelectedIndices(int[] indices)
    {
        _listView.setSelectedIndices(indices);
    }                                       

    public int[] getSelectedIndices()
    {
        return  _listView.getSelectedIndices();
    }

    /**
    *  Sets the background color used for painting the selected
    *  cell
    *  @see javax.swing.JList
    */
    public final void setSelectionBackground(Color selectionBackground)
    {
        _listView.setSelectionBackground(selectionBackground);
    }

    /**
    *  Gets the background color used for painting the selected
    *  cell
    *  @see javax.swing.JList
    */
    public final Color getSelectionBackground()
    {
        return(_listView.getSelectionBackground());
    }

    /**
    *  Sets the foreground color used for painting the selected
    *  cell
    *  @see javax.swing.JList
    */
    public final void setSelectionForeground(Color selectionForeground)
    {
        _listView.setSelectionForeground(selectionForeground);
    }

    /**
    *  Gets the foreground color used for painting the selected
    *  cell
    *  @see javax.swing.JList
    */
    public final Color getSelectionForeground()
    {
        return(_listView.getSelectionForeground());
    }

    public void setSelectionMode(int selectionMode)
    {
        _listView.setSelectionMode(selectionMode);
    }


    public int getSelectionMode()
    {
        return(_listView.getSelectionMode());
    }

    public void setSelectionModel(ListSelectionModel selectionModel)
    {
        _listView.setSelectionModel(selectionModel);
    }

    public ListSelectionModel getSelectionModel()
    {
        return(_listView.getSelectionModel());
    }


    public void setValueIsAdjusting(boolean b)
    {
        _listView.setValueIsAdjusting(b);
    }

    public boolean getValueIsAdjusting()
    {
        return(_listView.getValueIsAdjusting());
    }


    /**
    *  Sets the visibleRowCount property of underlying JList
    *  @see javax.swing.JList
    */
    public void setVisibleRowCount(int rows)
    {
        _listView.setVisibleRowCount(rows);
        _listView.invalidate();
        _listView.revalidate();
    }

    /**
    *  Gets the visibleRowCount property of underlying JList
    *  @see javax.swing.JList
    */
    public int getVisibleRowCount()
    {
        return(_listView.getVisibleRowCount());

    }

    // end properties of JList exposed
}


