/*
 * @(#)NavigationBarButtonClickEvent.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.dacf.control.swing;

import java.awt.event.ActionEvent;
import java.util.EventObject;

/**
 * Defines the event delivered to the listeners of
 *  NavigationBarButtonClickListeners, when a button on the NavBar is clicked
 *
 * @version SDK
 */
public class NavigationBarButtonClickEvent extends EventObject
{
    private ActionEvent   _actionEvent;
    private int           _buttonClicked;
    protected NavigationBarButtonClickEvent(Object source, int buttonClicked,
                                               ActionEvent event)
    {
        super(source);
        _actionEvent = event;
        _buttonClicked = buttonClicked;
    }

    /**
    *  get the button id clicked. The value could be one of the following constants
       <UL>
           <LI>NavigationBar.BUTTON_FIRST
           <LI>NavigationBar.BUTTON_PREV
           <LI>NavigationBar.BUTTON_NEXT
           <LI>NavigationBar.BUTTON_LAST
           <LI>NavigationBar.BUTTON_INSERT
           <LI>NavigationBar.BUTTON_DELETE
           <LI>NavigationBar.BUTTON_COMMIT
           <LI>NavigationBar.BUTTON_ROLLBACK
           <LI>NavigationBar.BUTTON_FIND
       </UL>
    *
    */
    public int getButtonClicked()
    {
        return _buttonClicked;
    }
    /**
    *  get the ActionEvent which triggered the NavigationBarButtonClick
    *  event
    */
    public ActionEvent getActionEvent()
    {
        return _actionEvent;
    }
}
