/*
 * @(#)DefaultValueLocator.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.dacf.control.swing;

import javax.infobus.ArrayAccess;
import javax.infobus.DataItem;
import javax.infobus.DataItemView;
import javax.infobus.ImmediateAccess;
import javax.infobus.ScrollableRowsetAccess;
import oracle.dacf.dataset.DacObject;
import oracle.dacf.dataset.DataItemProperties;
import oracle.dacf.dataset.SearchableRowsetAccess;

// imports
/**
 ** Helper class used by ComboBox control. 
 **
 */
public class DefaultValueLocator
    implements ComboBoxDataSource.ValueLocator
{
	
	boolean  _refreshColumnName = true;

	// name of the list value column in the srch (master) rowset
	String _listValueColumnName = null;

	// zero based index of the above column
    int    _listValueColumnIndex = -1;
	
	public DefaultValueLocator()
	{

	}

        // bug 2382729
        private boolean _nullValuesAllowed = true;

        public boolean getNullValuesAllowed()
        {
           return _nullValuesAllowed;
        }

        public void setNullValuesAllowed(boolean nullValuesAllowed)
        {
           _nullValuesAllowed = nullValuesAllowed;
        }

	/**
	*  When the list value data item name on the Control is
	*  changed, the locator class is notified, so that the 
	*  column names can be changed. By default the DefaultValueLocator
	*  updates the list value column name. 
	*/
	public void setRefreshColumnName(boolean flag)
	{
		_refreshColumnName = flag;
	}

	public boolean getRefreshColumnName( )
	{
		return _refreshColumnName ;
	}

	public void setListValueColumnName(String name)
	{
		_listValueColumnName = name;
		_listValueColumnIndex = -1;
	}

	public String getListValueColumnName()
	{
		return _listValueColumnName;
	}
	
	// Implement ComboBoxControl.ValueLocator

    public int findIndexInMaster(ImmediateAccess searchFor, 
                                 ScrollableRowsetAccess masterRowset,
								 ScrollableRowsetAccess detailRowset)
	{
		int ret = 0;

		if (masterRowset instanceof SearchableRowsetAccess)
		{
			ret = _lookup(searchFor, masterRowset, detailRowset);
		}

		return ret;
	}

	public void updateKeyColumnName(String newListValueDataItemName, 
											ComboBoxControl c)
	{
		if (getRefreshColumnName())
		{
			String name = _getColumnNameFromDataItemName(newListValueDataItemName);
			
			setListValueColumnName(name);
		}
	}

    protected String _getColumnNameFromDataItemName(String dataItemName)
	{
		int i = dataItemName.lastIndexOf(DacObject.ITEMNAME_DELIMITER);

		if (i != -1)
			return dataItemName.substring(i+1);

		return null;
	}
    	
    protected int _lookup(ImmediateAccess searchFor, 
						   ScrollableRowsetAccess srchRowset,
						   ScrollableRowsetAccess detailRowset)
	{
		String name = getListValueColumnName();

		Object value = searchFor.getValueAsObject();

		if (name != null) 
		{
			if (srchRowset instanceof DataItemView) 
			{
				DataItemView diView = (DataItemView)srchRowset;

				ArrayAccess arrayAccess = diView.getView(-1);

				if (_listValueColumnIndex == -1) 
				{
					_listValueColumnIndex = _findColumnIndex(srchRowset, name);
				}

				if (_listValueColumnIndex != -1) 
				{
					int rc = getRowCount(arrayAccess);

					for (int i=0; i < rc; i++) 
					{
						Object colValue = getValueFromArrayAccess(arrayAccess, i,
											_listValueColumnIndex );

						if (_isEqual(searchFor, colValue))
							return i;
					}
				}
			}
		}

		return -1;
	}

	boolean _isEqual(Object x, Object y)
	{
		if ((x == null) && (y == null))
			return true;

		if ((x == null) || ( y == null))
			return false;

		if ((x instanceof ImmediateAccess) && 
			     (y instanceof ImmediateAccess)) 
		{
			Object xVal = ((ImmediateAccess)x).getValueAsObject();

			Object yVal = ((ImmediateAccess)y).getValueAsObject();

			if ( (xVal != null) && (yVal != null ))
				 return xVal.equals(yVal);
			
			if ((xVal == null) && (yVal == null))
				 return true;

			return false;
		}
		
		return x.equals(y);

	}

	int getRowCount(ArrayAccess acc)
	{
		int[] dim = acc.getDimensions();

		return dim[0]; 
	}

	Object getValueFromArrayAccess(ArrayAccess view, int row, int column)
	{
	  
		if (view != null)
        {
			int coord[] = new int[] { row, column };

            try
            {
				Object item = view.getItemByCoordinates(coord);
                if (item != null)
                {
                     return (item);
                }
            }
            catch (IndexOutOfBoundsException e)
            {

            }
        }

		return null;
	}


	// return zero base index of the column.,
	int _findColumnIndex(ScrollableRowsetAccess scr, String name)
	{
        
		int n = scr.getColumnCount();

        for (int i = 0; i < n; i++)
        {
           String colName = null;

           try
           {
			  DataItem di = (DataItem)scr.getColumnItem(i+1);

              colName =
                    (String)di.getProperty(DataItemProperties.DATASOURCE_NAME);
           }
           catch(Exception e)
           {
                return -1;
           }

           if  ((colName != null) && (colName.equalsIgnoreCase(name)))
               return i;
        }

        return -1;
    }


	
}  // DefaultValueLocator
    


