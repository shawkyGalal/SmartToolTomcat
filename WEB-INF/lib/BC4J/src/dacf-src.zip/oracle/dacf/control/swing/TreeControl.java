/*
 * @(#)TreeControl.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.dacf.control.swing;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.Point;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.beans.PropertyChangeListener;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Stack;
import java.util.StringTokenizer;
import java.util.Vector;
import javax.infobus.DataItem;
import javax.infobus.DataItemAddedEvent;
import javax.infobus.DataItemDeletedEvent;
import javax.infobus.DataItemRevokedEvent;
import javax.infobus.DataItemValueChangedEvent;
import javax.infobus.ImmediateAccess;
import javax.infobus.RowsetCursorMovedEvent;
import javax.infobus.ScrollableRowsetAccess;
import javax.swing.AbstractAction;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTree;
import javax.swing.KeyStroke;
import javax.swing.SwingUtilities;
import javax.swing.border.BevelBorder;
import javax.swing.event.MouseInputAdapter;
import javax.swing.event.TreeSelectionEvent;
import javax.swing.tree.DefaultTreeCellRenderer;
import javax.swing.tree.DefaultTreeModel;
import javax.swing.tree.DefaultTreeSelectionModel;
import javax.swing.tree.TreeModel;
import javax.swing.tree.TreeNode;
import javax.swing.tree.TreePath;
import javax.swing.tree.TreeSelectionModel;
import oracle.dacf.control.Control;
import oracle.dacf.control.ControlEnabledListener;
import oracle.dacf.control.ControlSupportHC;
import oracle.dacf.control.CurrencyChangedEvent;
import oracle.dacf.control.CurrencyListener;
import oracle.dacf.control.InfoBusManager;
import oracle.dacf.control.InfoBusManagerListener;
import oracle.dacf.control.InfoBusManagerReleaseEvent;
import oracle.dacf.control.NavigatedEvent;
import oracle.dacf.control.NavigatedListener;
import oracle.dacf.control.NavigatingEvent;
import oracle.dacf.control.NavigatingException;
import oracle.dacf.control.NavigatingListener;
import oracle.dacf.control.NavigationManager;
import oracle.dacf.dataset.AttributeInfo;
import oracle.dacf.dataset.DataItemProperties;
import oracle.dacf.dataset.InfoObject;
import oracle.dacf.dataset.RowSetInfo;
import oracle.dacf.dataset.SearchableRowsetAccess;

/**
 **      A JTree based data aware control.<P>
 **
 **      The TreeControl will, within the context of the DataItems that it is
 **      observing, maintain a synchronized representation of the underlying
 **      DataItems. When the focus is moved from one control to another and
 **      the TreeControl is observing the underlying DataItems, it will move
 **      its selection indicator so that the DataItem being manipulated by the
 **      focused control is selected in the tree.  The TreeControl will move
 **      the current row in the DataItems that it is observing so that the
 **      path of nodes from the root node to the selected node selects the
 **      current row in the appropriate DataItems when the user selects a
 **      new node in the tree.<p>
 **
 **      Operational constraints:
 **      <ul>
 **      <li>The current row in all of the appropriate observed DataItems 
 **          will alway be contained within the current selection provided 
 **          that the keyboard focus is on a control that is bound to one of
 **          the DataItems that the TreeControl is observing.</li>
 **      <li>The selection model for the TreeControl can not be changed. Any
 **          request to change the selection model will be ignored.</li>
 **      </ul>
 **
 ** @version PUBLIC
 */
public class TreeControl
    extends JPanel
    implements Control, InfoBusManagerListener, ControlEnabledListener,
               CurrencyListener, FocusListener
{
    private String _rootNodeLabel;
    private JTree _tree;
    private ControlSupportHC _controlSupport;
    private Dimension preferredSize = new Dimension(400, 150);
    private JScrollPane _treeAggregate;
    private TreeNodeDef[] _nodeDefs;
    private boolean _selfReferential = false;
    private TreeDataSource _dataSource = null;
    private boolean _dataSourceInitialized = false;
    private NavigationManager _navmgr;
    private TreeQueryListener _queryListener;
    private TreePath _prevSelectedNode;
    private TreePath _currentRowPath;
    private volatile Object _recursionGate = new Object();
    private volatile int _updateMode = UPDATE_INACTIVE;
    private Color _textNonSelectionColor;
    private Color _textSelectionColor;
    private Color _backgroundSelectionColor;
    private boolean _currentRowIndicated = true;

    private static final boolean _DEBUG = false;
    private static final int UPDATE_INACTIVE = 0;
    private static final int TREE_UPDATING = 1;
    private static final int DATAITEM_UPDATING = 2;
    
    /**
    ** Constructs a TreeControl that uses a TreeDataSource data model.<P>
    **
    ** This form of TreeControl will be InfoBus enabled.  The data used
    ** to populate the tree will be extracted from the database.  The client
    ** object will not be responsible for supplying the data displayed in the
    ** tree.
    */
    public TreeControl()
    {
        this(new TreeDataSource(new TreeControlNode()));
    }

    /**
    ** Returns a Tree with each element of the specified array as the
    ** child of a new root node which is not displayed. <P>
    **
    ** This form of TreeControl will <b>NOT</b> be InfoBus enabled. The client
    ** object will be responsible for supplying the data displayed in the
    ** tree.  In addition, the tree will use the default data model as it's
    ** data model.
    **
    ** @param value  an array of Objects
    ** @return a Tree with the contents of the array as children of
    **         the root node
    */
    public TreeControl(Object[] value)
    {
        _tree = new TreeControlTree(value);
        _init();
    }

    /**
    ** Returns a Tree with each element of the specified Vector as the
    ** child of a new root node which is not displayed.
    **
    ** This form of TreeControl will <b>NOT</b> be InfoBus enabled. The client
    ** object will be responsible for supplying the data displayed in the
    ** tree.  In addition, the tree will use the default data model as it's
    ** data model.
    **
    ** @param value  a Vector
    ** @return a Tree with the contents of the Vector as children of
    **         the root node
    */
    public TreeControl(Vector value)
    {
        _tree = new TreeControlTree(value);
        _init();
    }

    /**
    ** Returns a Tree create from a Hashtable which does not display
    ** the root. Each value-half of the key/value pairs in the HashTable
    ** becomes a child of the new root node. By default, the tree defines
    ** a leaf node as any node without children.
    **
    ** This form of TreeControl will <b>NOT</b> be InfoBus enabled. The client
    ** object will be responsible for supplying the data displayed in the
    ** tree.  In addition, the tree will the default data model as it's
    ** data model.
    **
    ** @param value  a Hashtable
    ** @return a Tree with the contents of the Hashtable as children of
    **         the root node
    */
    public TreeControl(Hashtable value)
    {
        _tree = new TreeControlTree(value);
        _init();
    }

    /**
    ** Returns a Tree with the specified TreeNode as its root which is
    ** not displayed. By default, the tree defines a leaf node as any node
    ** without children.
    **
    ** This form of TreeControl will <b>NOT</b> be InfoBus enabled. The client
    ** object will be responsible for supplying the data displayed in the
    ** tree.  In addition, the tree will use the default data model as it's
    ** data model.
    **
    ** @param root  a TreeNode object
    ** @return a Tree with the specified root node
    ** @see javax.swing.tree.DefaultTreeModel#asksAllowsChildren
    */
    public TreeControl(TreeNode root)
    {
        _tree = new TreeControlTree(root);
        _init();
    }

    /**
    ** Returns a Tree with the specified TreeNode as its root, which
    ** displays the root node and which decides whether a node is a
    ** leaf node in the specified manner.
    **
    ** This form of TreeControl will <b>NOT</b> be InfoBus enabled.  The client
    ** object will be responsible for supplying the data displayed in the
    ** tree.  In addition, the tree will use the default data model as it's
    ** data model.
    **
    ** @param root  a TreeNode object
    ** @param asksAllowsChildren  if false, any node without children is a
    **              leaf node. If true, only nodes that do not allow
    **              children are leaf nodes.
    ** @return a Tree with the specified root node
    ** @see javax.swing.tree.DefaultTreeModel#asksAllowsChildren
    */
    public TreeControl(TreeNode root, boolean asksAllowsChildren)
    {
        _tree = new TreeControlTree(root, asksAllowsChildren);
        _init();
    }

    /**
    ** Returns an instance of Tree which displays the root node
    ** -- the tree is created using the specified data model.
    **
    ** This form of TreeControl will be InfoBus enabled if the data model
    ** supplied is an instance of TreeDataModel.  In that case, the data used
    ** to populate the tree will be extracted from the database.  The client
    ** object will not be responsible for supplying the data displayed in the
    ** tree.<P>
    ** 
    ** When the supplied data model is not an instance of TreeDataModel, the
    ** TreeControl will <b>NOT</b> be InfoBus enabled.  The client object will
    ** be responsible for supplying the data displayed in the tree.  In
    ** addition, the tree will use the default data model as it's data model.
    **
    ** @param newModel  the TreeModel to use as the data model
    ** @return a Tree based on the TreeModel
    */
    public TreeControl(TreeModel newModel)
    {
        if (newModel instanceof TreeDataSource)
        {
            _dataSource = (TreeDataSource)newModel;
            _dataSource.setTreeControl(this);
        }
        else
        {
            _dataSource = null;
        }
        _tree = new TreeControlTree(newModel);
        _init();
    }

    private void _init()
    {
        _controlSupport = new ControlSupportHC(this);
        InfoBusManager.getInstance().addInfoBusManagerListener(this);
        _treeAggregate = new JScrollPane(_tree);
        _treeAggregate.setBorder(new BevelBorder(BevelBorder.LOWERED));
        _treeAggregate.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
        _treeAggregate.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
         _treeAggregate.setFont(null);
        setLayout(new BorderLayout());
        add(_treeAggregate, BorderLayout.CENTER);
        _tree.setLargeModel(false);
        _tree.setScrollsOnExpand(true);
        _hijackKeyStrokeActions();
        // when this is non-null a lot of code is executed when the mouse is
        // moved over the nodes in the tree
        setToolTipText(null);
        _tree.addFocusListener(this);
        _navmgr = NavigationManager.getNavigationManager();
        _navmgr.addCurrencyListener(this);
    }

    /**
    ** Sets whether the current row is indicated in the tree. <P>
    **
    ** A value of FALSE will result in backwards compatible display behavior.
    **
    ** @param currentRowIndicated if TRUE, then the current row will be
    **                            indicated.
    ** @see #isCurrentRowIndicated()
    */
    public void setCurrentRowIndicated(boolean currentRowIndicated)
    {
        _currentRowIndicated = currentRowIndicated;        
    } // setCurrentRowIndicated
    
    /**
    ** Return whether the current row is indicated in the tree. <P>
    **
    ** A value of FALSE indicates backwards compatible display behavior.
    **
    ** @return Return whether the current row is indicated in the tree.
    ** @see #setCurrentRowIndicated(boolean currentRowIndicated)
    */
    public boolean isCurrentRowIndicated()
    {
        return(_currentRowIndicated);        
    } // isCurrentRowIndicated
    
    /**
    ** Returns the color the text is drawn with when the node isn't selected.
    **
    ** @see #getTextNonSelectionColor()
    */
    public void setTextNonSelectionColor(Color color)
    {
        ((TreeControlTree.TreeControlNodeRenderer)_tree.getCellRenderer()).setTextNonSelectionColor(color);
    } // setTextNonSelectionColor
    
    /**
    ** Sets the color the text is drawn with when the node isn't selected.
    **
    ** @see #setTextNonSelectionColor(Color color)
    */
    public Color getTextNonSelectionColor()
    {
        return(((TreeControlTree.TreeControlNodeRenderer)_tree.getCellRenderer()).getTextNonSelectionColor());
    } // getTextNonSelectionColor
    
    /**
    ** Sets the color the text is drawn with when the node is selected.
    **
    ** @see #getTextSelectionColor()
    */
    public void setTextSelectionColor(Color color)
    {
        ((TreeControlTree.TreeControlNodeRenderer)_tree.getCellRenderer()).setTextSelectionColor(color);
    } // setTextSelectionColor
    
    /**
    ** Returns the color the text is drawn with when the node is selected.
    **
    ** @see #setTextSelectionColor(Color textSelectionColor)
    */
    public Color getTextSelectionColor()
    {
        return(((TreeControlTree.TreeControlNodeRenderer)_tree.getCellRenderer()).getTextSelectionColor());
    } // getTextSelectionColor
    
    /**
    ** Sets the color to use for the background if node is selected.
    **
    ** @see #getBackgroundSelectionColor()
    */
    public void setBackgroundSelectionColor(Color color)
    {
        ((TreeControlTree.TreeControlNodeRenderer)_tree.getCellRenderer()).setBackgroundSelectionColor(color);
    } // setBackgroundSelectionColor
    
    /**
    ** Returns the color to use for the background if node is selected.
    **
    ** @see #setBackgroundSelectionColor(Color color)
    */
    public Color getBackgroundSelectionColor()
    {
        return(((TreeControlTree.TreeControlNodeRenderer)_tree.getCellRenderer()).getBackgroundSelectionColor());
    } // getBackgroundSelectionColor
    
    /**
    ** Sets the color to use for the background if node is not selected.
    **
    ** @see #getBackgroundSelectionColor()
    */
    public void setBackgroundNonSelectionColor(Color color)
    {
        ((TreeControlTree.TreeControlNodeRenderer)_tree.getCellRenderer()).setBackgroundNonSelectionColor(color);
    } // setBackgroundNonSelectionColor
    
    /**
    ** Returns the color to use for the background if node is notselected.
    **
    ** @see #setBackgroundNonSelectionColor(Color backgroundNonSelectionColor)
    */
    public Color getBackgroundNonSelectionColor()
    {
        return(((TreeControlTree.TreeControlNodeRenderer)_tree.getCellRenderer()).getBackgroundNonSelectionColor());
    } // getBackgroundNonSelectionColor
    
    /**
    **  Set the background current row color.
    **
    **  The TreeControl always high-lights the current row using the
    **  CurrentRow colors.
    **
    **  @param currentRowBackground  The color to be used to display the
    **                               background of a node when it maps to
    **                               the current row
    **
    */
    public void setCurrentRowBackground(Color currentRowBackground)
    {
        ((TreeControlTree.TreeControlNodeRenderer)_tree.getCellRenderer()).setCurrentRowBackground(currentRowBackground);
    } // setCurrentRowBackground
    
    /**
    **  Return the background current row color.
    **
    **  The TreeControl always high-lights the current row using the
    **  CurrentRow colors.
    **
    **  @return The color to be used to display the background of a node when
    **          it maps to the current row
    **
    **  @see #setCurrentRowBackground(Color currentRowBackground)
    */
    public Color getCurrentRowBackground()
    {
        return(((TreeControlTree.TreeControlNodeRenderer)_tree.getCellRenderer()).getCurrentRowBackground());
    } // getCurrentRowBackground
    
    /**
    **  Set the foreground current row color.
    **
    **  The TreeControl always high-lights the current row using the
    **  CurrentRow colors.
    **
    **  @param currentRowForeground  The color to be used to display the
    **                               foreground of a node when it maps to
    **                               the current row
    **
    */
    public void setCurrentRowForeground(Color currentRowForeground)
    {
        ((TreeControlTree.TreeControlNodeRenderer)_tree.getCellRenderer()).setCurrentRowForeground(currentRowForeground);
    } // setCurrentRowForeground
    
    /**
    **  Return the Foreground current row color.
    **
    **  The TreeControl always high-lights the current row using the
    **  CurrentRow colors.
    **
    **  @return The color to be used to display the Foreground of a node when
    **          it maps to the current row
    **
    **  @see #setCurrentRowForeground(Color currentRowForeground)
    */
    public Color getCurrentRowForeground()
    {
        return(((TreeControlTree.TreeControlNodeRenderer)_tree.getCellRenderer()).getCurrentRowForeground());
    } // getCurrentRowForeground
    
    /**
    ** Sets the foreground color of the TreeControl. <P>
    **
    ** @param c the new color value for the foreground
    */
    public void setForeground(Color c)
    {
        super.setForeground(c);
        if (_treeAggregate!= null)
        {
            _treeAggregate.setForeground(c);
        }
        if (_tree != null)
        {
            _tree.setForeground(c);
        }
    } // setForeground
    
    /**
    ** Sets the background color of the TreeControl. <P>
    **
    ** @param c the new color value for the background
    */
    public void setBackground(Color c)
    {
        super.setBackground(c);
        if (_treeAggregate!= null)
        {
            _treeAggregate.setBackground(c);
        }
        if (_tree != null)
        {
            _tree.setBackground(c);
        }
    } // setBackground
    
    /**
    ** Set the label of the root node in the tree. <P>
    **
    ** @param nuRootNodeLabel label of the root node
    ** @see #getRootNodeLabel()
    */
    public void setRootNodeLabel(String nuRootNodeLabel)
    {
        _rootNodeLabel = nuRootNodeLabel;
        if (_dataSource != null)
        {
            _dataSource.setRootNodeLabel(_rootNodeLabel);
        }
    } // setRootNodeLabel
    
    /**
    ** Returns the label of the root node in the tree. <P>
    **
    ** @return the label of the root node
    ** @see #setRootNodeLabel(String nuRootNodeLabel)
    */
    public String getRootNodeLabel()
    {
        if (_dataSource != null)
        {
            _rootNodeLabel = _dataSource.getRootNodeLabel();
        }
        return(_rootNodeLabel);
    } // getRootNodeLabel
    
    /**
    ** Returns the node definitions. <P>
    **
    ** A node is defined by the DataItem supplying the data, the column linking
    ** to the child node and the column that is displayed. <p>
    **
    ** The node definitions is as follows:<br>
    ** <ul>
    ** <li> data item name           - the RowsetAccess supplying data
    ** <li> link column name         - the column linking to child nodes
    ** <li> display column name      - the column whose value is displayed
    ** <li> primary key column names - the list of primary key columns
    ** <li> foreign key column names - the list of foreign key columns
    ** </ul>
    **
    ** The primary and foreign key column lists are comma lists like: <br>
    ** Col1, Col2
    **
    ** @return an array of arrays of Strings listing the node definition
    ** @see #setNodeDefinitions(String[][5] defs)
    */
    public String[][] getNodeDefinitions()
    {
        StringBuffer colList;
        int size = _nodeDefs == null ? 0 : _nodeDefs.length;
        String[][] defs = new String[size][5];
        
        for(int i = 0; i < size; i++)
        {
            defs[i][0] = _nodeDefs[i].getRowsetName();
            defs[i][1] = _nodeDefs[i].getLinkColName();
            defs[i][2] = _nodeDefs[i].getDisplayColName();
            defs[i][3] = _buildKeyDef(_nodeDefs[i].getPrimaryKeyColNames());
            defs[i][4] = _buildKeyDef(_nodeDefs[i].getForeignKeyColNames());
        }
        return(defs);
    } // getNodeDefinitions
    
    /**
    ** Sets the node definitions. <P>
    **
    ** A node is defined by the DataItem supplying the data, the column linking
    ** to the child node and the column that is displayed.<p>
    **
    ** The node definitions is as follows:<br>
    ** <ul>
    ** <li> data item name        - the RowsetAccess supplying data
    ** <li> viewlink column name  - the column linking to child nodes
    ** <li> display column name   - the column whose value is displayed
    ** <li> primary key column names - the list of primary key columns
    ** <li> foreign key column names - the list of foreign key columns
    ** </ul>
    **
    ** The primary and foreign key column lists are comma lists like: <br>
    ** Col1, Col2<p>
    **
    ** The self-referential property will be set to false if the length of
    ** <tt>def</tt> is greater than 1.
    **
    ** @param defs an array of arrays of Strings listing the node definition
    ** @see #getNodeDefinitions()
    ** @see #setSelfReferential(boolean selfReferential)
    */
    public void setNodeDefinitions(String[][] defs)
    {
        if (_dataSource != null)
        {
            boolean selfref = _selfReferential;
            
            if (!selfref)
            {
               selfref = (defs != null &&
                          defs.length == 1 &&
                          !(defs[0][1].equals("")));
            }
            _selfReferential = selfref;
            
            int size = defs == null ? 0 : defs.length;
            _nodeDefs = new TreeNodeDef[size];
            String[] rowsetNames = new String[size];
            for(int i = 0; i < size; i++)
            {
                if (defs[i].length < 5)
                {
                    throw new IllegalArgumentException(Res.getString(Res.TREE_BAD_NODE_DEFINITION) + i);
                }
                _nodeDefs[i] = new TreeNodeDef();
                _nodeDefs[i].setRowsetName(defs[i][0]);
                _nodeDefs[i].setLinkColName(defs[i][1]);
                _nodeDefs[i].setDisplayColName(defs[i][2]);
                _nodeDefs[i].setPrimaryKeyColNames(_parseKeyDef(defs[i][3]));
                _nodeDefs[i].setForeignKeyColNames(_parseKeyDef(defs[i][4]));
                _nodeDefs[i].setSelfReferential(selfref);
                rowsetNames[i] =_nodeDefs[i].getRowsetName();
            }
            _controlSupport.setDataItemNames(rowsetNames);
            if (_findNodeDataItems())
            {
                _prevSelectedNode = null;
                // found them all, notify the model of def changes
                _dataSource.setNodeDefinitions(_nodeDefs);
            }
        }
    } // setNodeDefinitions
    
    private String[] _parseKeyDef(String keydef)
    {
        String[] keys = { "" };

        if (keydef != null)
        {
            StringTokenizer st = new StringTokenizer(keydef,", \t");
            
            keys = new String[st.countTokens()];
        
            for(int i = 0; st.hasMoreTokens(); i++)
            {
                keys[i] = st.nextToken();
            }
        }
        return(keys);
    }

    private String _buildKeyDef(String[] cols)
    {
        String def = "";

        if (cols != null)
        {
            StringBuffer buf = new StringBuffer();
            
            for(int i = 0; i < cols.length; i++)
            {
                if (i > 0)
                {
                    buf.append(",");
                }
                buf.append(cols[i]);
            }
            def = buf.toString();
        }
        return(def);
    }
    
    private boolean _findNodeDataItems()
    {
        int foundCount = 0;
        TreeNodeData data;
        ScrollableRowsetAccess sra;
        
        for(int i = 0; i < _nodeDefs.length; i++)
        {
            if (_nodeDefs[i].getRowsetItem() == null)
            {
                sra = _findSRA(_nodeDefs[i].getRowsetName());
                _setSRAOnDef(i, sra);
                foundCount += (sra != null ? 1 : 0);
            }
            else
            {
                foundCount++;
            }
        }
        return(foundCount == _nodeDefs.length);
    }

    private ScrollableRowsetAccess _findSRA(String name)
    {
        Object di = null;
        
        if (_controlSupport != null && name != null && !name.equals(""))
        {
            di = _controlSupport.getDataItem(name);
        }
        return((ScrollableRowsetAccess)(di instanceof ScrollableRowsetAccess ?
                                        di : null));
    }

    private void _setSRAOnDef(int defIndex, ScrollableRowsetAccess sra)
    {
        _nodeDefs[defIndex].setOriginalRowset(sra);
        if (sra != null)
        {
            if (defIndex == 0 && !_nodeDefs[defIndex].isSelfReferential())
            {
                sra = sra.newCursor();
                sra.setBufferSize(-1); // fetch all rows
            }
        }
        _nodeDefs[defIndex].setRowsetItem(sra);
    }

    /**
    ** Sets whether the nodes definitions are self-referential. <P>
    **
    ** A self-referential relationship is one where the link column points to
    ** another node of the same "shape".  Generally speaking, when the node
    ** definitions define a self-referential relationship, there should be only
    ** a single node definition.
    **
    ** @param selfReferential whether the nodes definitions are
    **                        self-referential.
    ** @see #isSelfReferential()
    ** @see #setNodeDefinitions(String[][5] defs)
    ** @see #getNodeDefinitions()
    */
    public void setSelfReferential(boolean selfReferential)
    {
        _selfReferential = selfReferential;
    } // setSelfReferential
    
    /**
    ** Returns whether the nodes definitions are self-referential. <P>
    **
    ** A self-referential relationship is one where the link column points to
    ** another node of the same "shape".  Generally speaking, when the node
    ** definitions define a self-referential relationship, there should be only
    ** a single node definition.
    **
    ** @return whether the nodes definitions are self-referential.
    ** @see #setSelfReferential(boolean selfReferential)
    ** @see #setNodeDefs(String[][5] defs)
    ** @see #getNodeDefs()
    */
    public boolean isSelfReferential()
    {
        return(_selfReferential);
    } // isSelfReferential
    
    /**
    ** returns the underlying JTree. <P>
    **
    ** @return the underlying JTree
    */
    public JTree getTree()
    {
        return(_tree);
    } // getTree

    /**
    ** Set the TreeModel to use for the tree. <P>
    **
    ** @param nuTreeModel the TreeModel to use for the tree
    ** @see #getTreeModel()
    */
    public void setTreeModel(TreeModel nuTreeModel)
    {
        if (nuTreeModel instanceof TreeDataSource)
        {
            _dataSource = (TreeDataSource)nuTreeModel;
        }
        else
        {
            _dataSource = null;
        }
        _tree.setModel(nuTreeModel);
    } // setTreeModel
    
    /**
    ** Return the TreeModel used by the tree. <P>
    **
    ** @return the TreeModel used by the tree.
    ** @see #setTreeModel(TreeModel nuTreeModel)
    */
    public TreeModel getTreeModel()
    {
        TreeModel tm = _tree.getModel();

        if (tm instanceof TreeDataSource &&
            !((TreeDataSource)tm).equals(_dataSource))
        {
            _dataSource = (TreeDataSource)tm;
        }
        return(tm);
    } // getTreeModel
    
    // There is a lot of code fired every time you move the mouse over a cell
    // in the grid when getToolTipText returns a non-null value
    public void setToolTipText(String text)
    {
        if (_tree != null)
        {
            super.setToolTipText(text);
            _treeAggregate.setToolTipText(text);
            _tree.setToolTipText(text);
        }
    }
    
    // InfoBusManagerListener interface implementation
    public void releaseResources(InfoBusManagerReleaseEvent e)
    {
        if (e.appliesTo(this))
        {
            _tree.removeFocusListener(this);
            _navmgr.removeCurrencyListener(this);
            InfoBusManager.getInstance().removeInfoBusManagerListener(this);
            _controlSupport = null;
        }
    }

    // Control interface implementation

    /**
    ** An override of java.awt.Component.setEnabled. <P>
    **
    ** @param b boolean flag indicating whether the control is enabled
    */
    public void setEnabled(boolean b)
    {
        super.setEnabled(b);
        // _treeAggregate.setEnabled(b);
        // _tree.setEnabled(b);
    }

    /**
    ** Returns the name of the InfoBus this control is connected to. <P>
    ** Delegated to <TT>ControlSupport</TT>. <P>
    **
    ** @return  The name of the InfoBus this control is connected to.
    ** @see ControlSupport#getInfoBusName
    */
    public String getInfoBusName()
    {
        return(_controlSupport == null ?
               null : _controlSupport.getInfoBusName());
    }

    /**
    ** Sets the name of the InfoBus this control is connected to. <P>
    ** By default, the control is connected to the default InfoBus,
    ** named <TT>DEFAULT_INFOBUS_NAME</TT>. <P>
    **
    ** If the named InfoBus does not exist, it is created automatically. <P>
    ** If the control is already connected to an InfoBus, it is disconnected
    ** first. <P>
    **
    ** Delegated to <TT>ControlSupport</TT>. <P>
    **
    ** @param infoBusName   The name of the InfoBus to connect to.
    ** @see #DEFAULT_INFOBUS_NAME
    ** @see ControlSupport#setInfoBusName
    */
    public void setInfoBusName(String infoBusName)
    {
        if (_controlSupport != null)
        {
            _controlSupport.setInfoBusName(infoBusName);
        }
        _dataSource.setInfoBusName(infoBusName);
    }


    /**
    ** Returns the name of the InfoBus DataItem bound to the root node.<P>
    **
    ** @return The name of the DataItem bound to the root node.
    ** @see #setNodeDefinitions(String[][5] defs)
    ** @see #getNodeDefinitions()
    ** @see #getDataItem
    ** @see ControlSupport#setDataItemName
    ** @see #getDataItem
    ** @see ControlSupport#getDataItemName
    */
    public String getDataItemName()
    {
        return(_nodeDefs[0].getRowsetName());
    }

    /**
    ** Sets the name of the InfoBus DataItem to which this control is bound.<P>
    **
    ** This method is ignored because the functionality is limited.  It has
    ** been replaced by <tt>setNodeDefinitions()</tt>.
    **
    ** @param dataItemName  The name of the DataItem to bind to.
    ** @see #setNodeDefinitions(String[][5] defs)
    ** @see #getNodeDefinitions()
    ** @see #getDataItem
    ** @see ControlSupport#setDataItemName
    */
    public void setDataItemName(String dataItemName)
    {
        // NOP -- ignored
    }

    /**
    ** Returns the InfoBus DataItem bound to selected node. <P>
    **
    ** To get the full list of DataItems, one should use
    ** <tt>getDataItems()</tt>.
    **
    ** @return  The InfoBus DataItem bound to the currently selected node, or
    **          <TT>null</TT> if there isn't a selected node.
    ** @see #getDataItems()
    ** @see ControlSupport#getDataItem
    */
    public Object getDataItem()
    {
        Object dataitem = null;
        TreePath tp = _tree.getSelectionPath();
        TreeControlNode node =
            (tp == null ||
             !(tp.getLastPathComponent() instanceof TreeControlNode))
            ? null : (TreeControlNode)tp.getLastPathComponent();

        if (node != null)
        {
            dataitem = _getNodeDataItem(node);
        }
        return(dataitem);
    }

    /**
    ** Returns a list of DataItems is bound to each level of the tree. <P>
    **
    ** @return  a list of InfoBus DataItems bound to each level of the tree, or
    **          <TT>null</TT> if the control is unbound.
    ** @see #getDataItem()
    ** @see ControlSupport#getDataItem
    */
    public Object[] getDataItems()
    {
        Object[] dataItems = new Object[_nodeDefs.length];
        
        for(int i = 0; i < _nodeDefs.length; i++)
        {
            dataItems[i] = _nodeDefs[i].getOriginalRowset();
        }
        return(dataItems);
    }

    /**
    ** Notifies the control that the bound InfoBus DataItem has changed. <P>
    **
    ** @param oldDataItem   The formerly bound DataItem (can be <TT>null</TT>).
    ** @param newDataItem   The newly bound DataItem (can be <TT>null</TT>).
    */
    public void dataItemChanged(Object oldDataItem, Object newDataItem)
    {
        ScrollableRowsetAccess oldSRA = null;
        ScrollableRowsetAccess newSRA = null;
        String targetName = null;

        if (oldDataItem != null &&
            oldDataItem instanceof ScrollableRowsetAccess)
        {
            oldSRA = (ScrollableRowsetAccess)oldDataItem;
        }
        if (newDataItem != null &&
            newDataItem instanceof ScrollableRowsetAccess)
        {
            newSRA = (ScrollableRowsetAccess)newDataItem;
        }

        if (oldSRA == null && newSRA == null)
        {
            return;
        }

        // get the names of the dataitems
        if (oldSRA != null)
        {
            targetName =
                (String)((DataItem)oldSRA).getProperty(DataItemProperties.NAME);
        }
        else
        {
            targetName =
                (String)((DataItem)newSRA).getProperty(DataItemProperties.NAME);
        }
        // find that one in the nodeDef list
        for(int i = 0; i < _nodeDefs.length; i++)
        {
            if (targetName.equals(_nodeDefs[i].getRowsetName()))
            {
                // _debug("calling _setSRAOnDef in DataItemChanged()");
                _setSRAOnDef(i, newSRA);
                break;
            }
        }
        if (_haveAllDataItems())
        {
            _prevSelectedNode= null;
            // notify the model that the defs changed
            _dataSource.setNodeDefinitions(_nodeDefs);
        }
    }

    // UI Control support

    /**
    * Returns the AWT component associated with this control. <P>
    * @return  The AWT component for this control.
    */
    public Component getComponent()
    {
        return(getTree());
    }

    // ValidationManager support

    /**
    ** Determines whether focus into this control causes validation to
    ** occur. <P>
    **
    ** Delegated to <TT>ControlSupport</TT>. <P>
    **
    ** @return  <TT>true</TT> if focus into this control causes validation to
    **          occur, <TT>false</TT> otherwise.
    ** @see ControlSupport#isFocusValidated
    */
    public boolean isFocusValidated()
    {
        return(_controlSupport == null ?
               false : _controlSupport.isFocusValidated());
    }

    /**
    ** Sets whether focus into this control causes validation to occur. <P>
    **
    ** Delegated to <TT>ControlSupport</TT>. <P>
    **
    ** @param focusValidated    If <TT>true</TT>, focus into this control will
    **                          cause validation to occur.
    ** @see ControlSupport#setFocusValidated
    */
    public void setFocusValidated(boolean focusValidated)
    {
        if (_controlSupport != null)
        {
            _controlSupport.setFocusValidated(focusValidated);
        }
    }


    private void _selectionChanged(TreeSelectionEvent tse)
    {
        // _debug("_selectionChanged: NewLeadSelectionPath: " +
        //        tse.getNewLeadSelectionPath());
        if (_updateModeTest(UPDATE_INACTIVE, TREE_UPDATING))
        {
            String oldName;
            String nuName;
            boolean rowChange;
            TreePath nuSelection = tse.getNewLeadSelectionPath();

            // _debug("_selectionChanged: through the gate");
            _prevSelectedNode = tse.getOldLeadSelectionPath();
            _selectionUpdated(nuSelection);
            if (nuSelection != null)
            {
                // _debug("_selectionChanged: _updateCurrentRowIndicator" );
                _updateCurrentRowIndicator(nuSelection);
            }
            _updateModeClear(TREE_UPDATING);
        }
        // _debug("_selectionChanged: end" );
    }

    private void _restoreSelection(final TreePath tp)
    {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                _tree.setSelectionPath(tp);
                _tree.scrollPathToVisible(tp);
            }
        });
    }
    
    private String _nodeDataItemName(TreePath tp)
    {
        String dataItemName = null;
        TreeControlNode node =
            (tp == null ||
             !(tp.getLastPathComponent() instanceof TreeControlNode))
            ? null : (TreeControlNode)tp.getLastPathComponent();

        if (node != null)
        {
            DataItem di = (DataItem)_getNodeDataItem(node);
            
            if (di != null)
            {
                dataItemName =
                    (String)di.getProperty(DataItemProperties.NAME);
            }
        }
        
        return(dataItemName);
    }

    private Object _getNodeDataItem(TreeControlNode node)
    {
        Object di = null;
        TreeNodeData d =
            (node == null ? null :node.getTreeNodeData());

        if (d != null)
        {
            TreeNodeDef def = d.def;
    
            if (def != null && def.isSelfReferential())
            {
                ScrollableRowsetAccess sra = def.getOriginalRowset();

                if (sra != null)
                {
                    try
                    {
                        di = sra.getColumnItem(def.getDisplayColName());
                    }
                    catch(Exception e)
                    {
                    }
                }
            }
            else
            {
                if (d.value != null)
                {
                    di = d.value;
                }
            }
        }
        return(di);
    }
    
    private void _selectionUpdated(TreePath tp)
    {
        Component comp = null;
        Cursor curCursor = null;
        Cursor ourCursor = null;

        // _debug("_selectionUpdated: " + tp);
        try
        {
            comp = _tree.getRootPane();
            if (comp != null)
            {
                while(comp.getParent() != null)
                {
                    comp = comp.getParent();
                }
                ourCursor = Cursor.getPredefinedCursor(Cursor.WAIT_CURSOR);
                synchronized(comp)
                {
                    curCursor = comp.getCursor();
                    if (curCursor.getType() != Cursor.WAIT_CURSOR)
                    {
                        comp.setCursor(ourCursor);
                    }
                    else
                    {
                        curCursor = null;
                    }
                }
            }

            if (tp != null &&
                tp.getLastPathComponent() instanceof TreeControlNode)
            {
                int r;
                String[] cols;
                Object[] vals;
                TreeNodeData data;
                TreeControlNode node;
                TreeControlNode parent;
                SearchableRowsetAccess sra;
                ImmediateAccess[] pKeys;
                TreeControlNode[] tn = new TreeControlNode[tp.getPathCount()];

                // _debug("_selectionUpdated: valid treepath");
                for(int k = tn.length-1, lim = tn.length; lim > 0; lim--, k--)
                {
                    tn[k] = (TreeControlNode)tp.getLastPathComponent();
                    tp = tp.getParentPath();
                }
                // _debug("_selectionUpdated: treepath length: " + tn.length);
                for(int i = 1; i < tn.length; i++)
                {
                    node = tn[i];
                    parent = (TreeControlNode)node.getParent();
                    data = node.getTreeNodeData();
                    if (data == null)
                    {
                        break;
                    }
                    else
                    {
                        if (data.def != null && data.def.isSelfReferential())
                        {
                            i = tn.length-1;
                            node = tn[i];
                            data = node.getTreeNodeData();
                            if (data == null || data.def == null)
                            {
                                break;
                            }
                        }
                    }
                
                    if (data.pKeys == null)
                    {
                        break;
                    }
                    pKeys = data.pKeys;
                    data = parent.getTreeNodeData();
                    sra = (SearchableRowsetAccess)data.def.getOriginalRowset();
                    cols = data.def.getPrimaryKeyColNames();
                    vals = new Object[cols.length];

                    for(int j = 0; j < vals.length; j++)
                    {
                        vals[j] = pKeys[j].getValueAsObject();
                    }

                    try
                    {
                        _findRow(sra, cols, vals);
                    }
                    catch(Exception ex)
                    {
                        break;
                    }
                }
            }
        }
        finally
        {
            if (curCursor != null)
            {
                synchronized(comp)
                {
                    if (ourCursor == comp.getCursor())
                    {
                        comp.setCursor(curCursor);
                    }
                }
            }
        }
        // _debug("_selectionUpdated: end");
    }
    
    // NavigationManager support

    /**
    ** Adds a navigating listener to this control. <P>
    **
    ** The listener will be notified of NavigateIn and NavigateOut events. <P>
    **
    ** Delegate to <TT>ControlSupport</TT>. <P>
    **
    ** @param listener  The listener to add.
    ** @see ControlSupport#addNavigatedListener
    */
    public void addNavigatingListener(NavigatingListener listener)
    {
        if (_controlSupport != null)
        {
            _controlSupport.addNavigatingListener(listener);
        }
    }

    /**
    ** Removes a navigating listener from this control. <P>
    **
    ** Delegated to <TT>ControlSupport</TT>. <P>
    **
    ** @param listener  The listener to remove.
    ** @see ControlSupport#removeNavigatedListener
    */
    public void removeNavigatingListener(NavigatingListener listener)
    {
        if (_controlSupport != null)
        {
            _controlSupport.removeNavigatingListener(listener);
        }
    }

    /**
    ** Processes a navigating event for this control. <P>
    **
    ** This method is for use by the NavigatedManager only. <P>
    **
    ** Delegated to <TT>ControlSupport</TT>. <P>
    **
    ** @param event The navigating event.
    ** @exception NavigatingException   If the navigation is redirected to a
    **                                  different control.
    ** @see ControlSupport#processNavigatedEvent
    */
    public void processNavigatingEvent(NavigatingEvent event)
        throws NavigatingException
    {
        if (_controlSupport != null)
        {
            _controlSupport.processNavigatingEvent(event);
        }
    }

    /**
    ** Adds a navigated listener to this control. <P>
    **
    ** The listener will be notified of NavigateIn and NavigateOut events. <P>
    **
    ** Delegated to <TT>ControlSupport</TT>. <P>
    **
    ** @param listener  The listener to add.
    ** @see ControlSupport#addNavigatedListener
    */
    public void addNavigatedListener(NavigatedListener listener)
    {
        if (_controlSupport != null)
        {
            _controlSupport.addNavigatedListener(listener);
        }
    }

    /**
    ** Removes a navigated listener from this control. <P>
    **
    ** Delegated to <TT>ControlSupport</TT>. <P>
    **
    ** @param listener  The listener to remove.
    ** @see ControlSupport#removeNavigatedListener
    */
    public void removeNavigatedListener(NavigatedListener listener)
    {
        if (_controlSupport != null)
        {
            _controlSupport.removeNavigatedListener(listener);
        }
    }

    /**
    ** Processes a navigated event for this control. <P>
    **
    ** This method is for use by the NavigationManager only. <P>
    **
    ** Delegated to <TT>ControlSupport</TT>. <P>
    **
    ** @param event The navigated event.
    ** @see ControlSupport#processNavigatedEvent
    */
    public void processNavigatedEvent(NavigatedEvent event)
    {
        if (_controlSupport != null)
        {
            _controlSupport.processNavigatedEvent(event);
        }
    }


    /**
    **  This method is used to track the change of keyboard focus.
    **
    **  @param event a CurrencyChangedEvent
    */
    public void currencyChanged(CurrencyChangedEvent e)
    {
        Control control = (Control)e.getCurrentControl();
        
        // _debug("currencyChanged");
        // ignore keyboard focus movement to the NavigationBar
        if (!(control instanceof NavigationBar) &&
            control != e.getPreviousControl())
        {
            // _debug("currencyChanged: selectionTrackControl");
            _selectionTrackControl(control);
        }
    }

    private void _selectionTrackControl(Control control)
    {
        if (_updateModeTest(UPDATE_INACTIVE, DATAITEM_UPDATING))
        {
            // place the current selection on the node that corresponds
            // to the dataitem of the control that currently has focus
            String name = _findCurrentRowset(control);
            TreePath tp = name == null ? null : _findNodeForDataItem(name);
            
            if (tp != null)
            {
                TreePath csp = _tree.getSelectionPath();

                if (csp == null || !tp.equals(csp))
                {
                    // _debug("_selectionTrackControl: selecting " + tp);
                    _tree.setSelectionPath(tp);
                    _tree.scrollPathToVisible(tp);
                }
            }
            else
            {
                // _debug("_selectionTrackControl: clearSelection");
                _tree.clearSelection();
                _markCurrentRowPath(_currentRowPath, true);
            }
            _updateModeClear(DATAITEM_UPDATING);
        }
    }
    
    // DataItemChangeListener interface implementation; inherited from Control

    /**
    ** Indicates a changed value in the bound data item. <P>
    ** A reference to the data item that changed can be obtained from the
    ** event. <P>
    ** @param event Contains change information.
    ** @see javax.infobus.DataItemChangeListener#dataItemValueChanged
    */
    public void dataItemValueChanged(final DataItemValueChangedEvent e)
    {
        DataItem di = (DataItem)e.getChangedItem();

        if (di != null)
        {
            // _debug("dataItemValueChanged: " + di + " e: " + e);
            _reflectRowsetCurrency((String)di.getProperty(DataItemProperties.NAME));
        }
    }

    /**
    ** Indicates that a new item was added to the bound aggregate data item
    ** (e.g. <TT>ArrayAccess</TT>, a JDK Collection, etc). <P>
    ** A reference to the data item that was added, and a reference to the one
    ** that gained it, can be obtained from the event. <P>
    ** @param event Contains details of the addition.
    ** @see javax.infobus.DataItemChangeListener#dataItemAdded
    */
    public void dataItemAdded(final DataItemAddedEvent e)
    {
        DataItem di = (DataItem)e.getChangedCollection();

        if (di != null)
        {
            // _debug("dataItemAdded()");
            _reflectRowsetCurrency((String)di.getProperty(DataItemProperties.NAME));
        }
    }

    /**
    ** Indicates that an item was deleted from the bound aggregate data item
    ** (e. g. <TT>ArrayAccess</TT>, a JDK Collection, etc). <P>
    ** A reference to the data item that was deleted, and a reference to the
    ** one that lost it, can be obtained from the event. <P>
    ** @param event Contains details of the deletion.
    ** @see javax.infobus.DataItemChangeListener#dataItemDeleted
    */
    public void dataItemDeleted(final DataItemDeletedEvent e)
    {
    }

    /**
    ** Indicates that the bound data item (and its sub-items, if any) has been
    ** revoked, and is temporarily unavailable. <P>
    ** A reference to the data item that was revoked can be obtained from
    ** the event. <P>
    ** @param event Contains details of the revoked data.
    ** @see javax.infobus.DataItemChangeListener#dataItemRevoked
    */
    public void dataItemRevoked(DataItemRevokedEvent e)
    {
        DataItem di = (DataItem)e.getChangedItem();

        for(int i = 0; i < _nodeDefs.length; i++)
        {
            if (_nodeDefs[i].getOriginalRowset() == di ||
                _nodeDefs[i].getRowsetItem() == di ||
                _nodeDefs[i].getSearchRowset() == di)
            {
                _nodeDefs[i].setRowsetItem(null);
                _nodeDefs[i].setOriginalRowset(null);
                _nodeDefs[i].setSearchRowset(null);
            }
        }
    }

    /**
    ** Indicates that the cursor for the bound <TT>RowsetAccess</TT> data item
    ** has changed rows. <P>
    ** A reference to the rowset data item can be obtained from the event. <P>
    ** @param event Contains details of the cursor move.
    ** @see javax.infobus.DataItemChangeListener#rowsetCursorMoved
    */
    public void rowsetCursorMoved(RowsetCursorMovedEvent e)
    {
        DataItem di = (DataItem)e.getChangedItem();

        if (di != null && _haveAllDataItems())
        {
            // _debug("rowsetCursorMoved: " + di + " e: " + e);
            _reflectRowsetCurrency((String)di.getProperty(DataItemProperties.NAME));
        }
    }

    private boolean _haveAllDataItems()
    {
        boolean haveAll = true;
        
        for(int i = 0; haveAll && i < _nodeDefs.length; i++)
        {
            haveAll = (_nodeDefs[i] != null &&
                       _nodeDefs[i].getRowsetItem() != null);
        }
        
        return(haveAll);
    }
    
    private void _reflectRowsetCurrency(String name)
    {
        TreePath tp = null;
        Component comp = null;
        Cursor curCursor = null;
        Cursor ourCursor = null;

        try
        {
            // _debug("_reflectRowsetCurrency: " + name);
            comp = _tree.getRootPane();
            if (comp != null)
            {
                while(comp.getParent() != null)
                {
                    comp = comp.getParent();
                }
                ourCursor = Cursor.getPredefinedCursor(Cursor.WAIT_CURSOR);
                synchronized(comp)
                {
                    curCursor = comp.getCursor();
                    if (curCursor.getType() != Cursor.WAIT_CURSOR)
                    {
                        comp.setCursor(ourCursor);
                    }
                    else
                    {
                        curCursor = null;
                    }
                }
            }
            if (name != null)
            {
                // _debug("_reflectRowsetCurrency: through the gate");

                // expand the tree so that the current row is visible
                tp = _findNodeForDataItem(name);
            
                if (tp != null &&
                    _updateModeTest(UPDATE_INACTIVE, DATAITEM_UPDATING))
                {
                    // _debug("_reflectRowsetCurrency: making visible " + tp);
                    _tree.makeVisible(tp);
                    _updateModeClear(DATAITEM_UPDATING);
                }
            
                if (isCurrentRowIndicated())
                {
                    if (tp != null)
                    {
                        // _debug("_reflectRowsetCurrency: marking: " + tp);
                        _updateCurrentRowIndicator(tp);
                    }
                }
            
                _selectionTrackControl(_navmgr.getFocusedControl());
            }
            else
            {
                // _debug("_reflectRowsetCurrency: clearSelection #2");
                _tree.clearSelection();
                _markCurrentRowPath(_currentRowPath, true);
            }
        }
        finally
        {
            if (curCursor != null)
            {
                synchronized(comp)
                {
                    if (ourCursor == comp.getCursor())
                    {
                        comp.setCursor(curCursor);
                    }
                }
            }
        }
        // _debug("_reflectRowsetCurrency: end");
    }

    private void _updateCurrentRowIndicator(TreePath tp)
    {
        // _debug("_updateCurrentRowIndicator: tp: " + tp);
        if (!_isParentPath(tp, _currentRowPath) || isSelfReferential())
        {
            // _debug("_updateCurrentRowIndicator: clear: " + _currentRowPath);
            _markCurrentRowPath(_currentRowPath, false);
            _currentRowPath = tp;
            // _debug("_updateCurrentRowIndicator: mark: " + _currentRowPath);
            _markCurrentRowPath(_currentRowPath, true);
        }
        // _debug("_updateCurrentRowIndicator: end");
    }

    private boolean _isParentPath(TreePath nu, TreePath old)
    {
        boolean res = false;
        
     	if (old != null && nu != null)
        {
            if (old != nu)
            {
                int oldLength = old.getPathCount();
                int newLength = nu.getPathCount();

                if (oldLength > newLength)
                {
                    while(oldLength-- > newLength)
                    {
                        old = old.getParentPath();
                    }
                    res = nu.equals(old);
                }
            }
        }
        // _debug("_isParentPath: old: "+old+" nu: "+nu+" res: "+res);
        return(res);
    }

    private void _markCurrentRowPath(TreePath tp, boolean isCurrent)
    {
        if (isCurrentRowIndicated())
        {
            Object[] path = tp == null ? null : tp.getPath();

            // _debug("_markCurrentRowPath: tp: "+tp+" isCurrent: "+isCurrent);
            if (path != null)
            {
                for(int i = 0; i < path.length; i++)
                {
                    if (path[i] instanceof TreeControlNode)
                    {
                        ((TreeControlNode)path[i]).setCurrentRow(isCurrent);
                        _dataSource.nodeChanged((TreeControlNode)path[i]);
                    }
                }
            }
        }
    }

    private TreePath _findNodeForDataItem(String name)
    {
        TreePath tp;
        TreeNode tn;
        TreeNodeDef def = null;
        TreeControlNode[] np = null;
        Vector nodes = new Vector();
        
        for(int i = 0; i < _nodeDefs.length; i++)
        {
            if (name.equals(_nodeDefs[i].getRowsetName()))
            {
                def = _nodeDefs[i];
                break;
            }
        }
        
        tn = (TreeControlNode)_dataSource.getRoot();
        nodes.addElement(tn);
        if (def != null)
        {
            np = _findCurrentNode((TreeControlNode)tn, def);
            if (np == null)
            {
                np = _buildNodePath((TreeControlNode)tn, def);
            }
        }
        return(np == null ? null : new TreePath(np));
    }
    

    /**
    **  Internal used by _reflectRowsetCurrency() when resolving
    **  a node in a self-referential section of the tree
    */
    private TreeControlNode[] _findCurrentNode(TreeControlNode rootNode,
                                               TreeNodeDef def)
    {
        ImmediateAccess keyItem;
        Object[] curRowKeyValues;
        String[] names;
        TreeControlNode[] np = null;
        ScrollableRowsetAccess sra = def.getOriginalRowset();

        try
        {
            names = def.getPrimaryKeyColNames();
            curRowKeyValues = new Object[names.length];

            for(int i = 0; i < names.length; i++)
            {
                keyItem = (ImmediateAccess)sra.getColumnItem(names[i]);
                curRowKeyValues[i] = keyItem.getValueAsObject();
            }
            np = _findNode(rootNode, names, curRowKeyValues);
        }
        catch(Exception e)
        {
        }
        return(np);
    }
    
    private TreeControlNode[] _findNode(TreeControlNode fromNode,
                                        String[] pKeyNames,
                                        Object[] pKeyVals)
    {
        boolean foundIt;
        TreeControlNode node;
        TreeControlNode parent;
        TreeNodeData data;
        String[] nodeKeyNames;
        Object[] nodeKeyVals;
        ImmediateAccess keyItem;
        Object keyVal;
        TreeControlNode[] np = null;
        Enumeration enum = fromNode.depthFirstEnumeration();

        while(enum.hasMoreElements())
        {
            node = (TreeControlNode)enum.nextElement();
            parent = (TreeControlNode)node.getParent();
            if (parent == null)
            {
                continue;
            }
            data = parent.getTreeNodeData();
            nodeKeyNames = data.def.getPrimaryKeyColNames();
            if (nodeKeyNames.length != pKeyNames.length)
            {
                continue;
            }
            foundIt = true;
            for(int i = 0; foundIt && i < nodeKeyNames.length; i++)
            {
                foundIt = nodeKeyNames[i].equals(pKeyNames[i]);
            }
            data = node.getTreeNodeData();
            for(int i = 0; foundIt && i < pKeyVals.length; i++)
            {
                keyItem = data.pKeys[i];
                keyVal = keyItem == null ? null : keyItem.getValueAsObject();
                if (pKeyVals[i] == null)
                {
                    foundIt = (keyVal == null);
                }
                else
                {
                    foundIt = pKeyVals[i].equals(keyVal);
                }
            }
            if (foundIt)
            {
                np = node.getPath();
                break;
            }
        }
        return(np);
    }

    private TreeControlNode[] _buildNodePath(TreeControlNode rootNode,
                                             TreeNodeDef def)
    {
        String[] names;
        ImmediateAccess[] pKeys;
        ImmediateAccess[] fKeys;
        Object[] vals;
        Object keyVal;
        String[] cols;
        TreeControlNode node;
        TreeNodeData data;
        ScrollableRowsetAccess sra = null;
        TreeControlNode[] np = null;
        Stack stack = new Stack();
        int defIndex = -1;
        int x = 0;

        for(int i = 0; i < _nodeDefs.length; i++)
        {
            if (def == _nodeDefs[i])
            {
                defIndex = i;
                break;
            }
        }

        if (defIndex == -1)
        {
            return(null);
        }

        def = _nodeDefs[defIndex];
        sra = def.getOriginalRowset();
                
        try
        {
            do
            {
                cols = def.getPrimaryKeyColNames();
                pKeys = new ImmediateAccess[cols.length];
                vals = new Object[pKeys.length];
                for(int i = 0; i < cols.length; i++)
                {
                    vals[i] = ((ImmediateAccess)sra.getColumnItem(cols[i])).getValueAsObject();
                }
                stack.push(vals);
                
                cols = def.getForeignKeyColNames();
                if (cols == null || cols.length == 0)
                {
                    break;
                }
                fKeys = new ImmediateAccess[cols.length];
                vals = new Object[fKeys.length];
                for(int i = 0; i < cols.length; i++)
                {
                    vals[i] = ((ImmediateAccess)sra.getColumnItem(cols[i])).getValueAsObject();
                }

                if (!_selfReferential)
                {
                    def = defIndex > 0 ? _nodeDefs[--defIndex] : null;
                    sra = def == null ? null : def.getOriginalRowset();
                }

                if (vals[0] == null || def == null)
                {
                    break;
                }

                cols = def.getPrimaryKeyColNames();
                if (sra == def.getOriginalRowset())
                {
                    sra = def.getSearchRowset();
                    if (sra == null)
                    {
                        sra = def.getOriginalRowset().newCursor();
                        def.setSearchRowset(sra);
                    }
                }
            }
            while(_findRow((SearchableRowsetAccess)sra, cols, vals));

            if (stack != null)
            {
                // the root of this subtree should be at the top of the stack
                // and it is a child of rootNode
                Enumeration kids;
                boolean foundIt;
                node = rootNode;
                while(!stack.empty() && node != null)
                {
                    vals = (Object[])stack.pop();
                    kids = node.children(true);
                    if (kids == null)
                    {
                        break;
                    }
                    while(kids.hasMoreElements())
                    {
                        node = (TreeControlNode)kids.nextElement();
                        data = node.getTreeNodeData();
                        foundIt = true;
                        for(int i = 0; i < data.pKeys.length && foundIt; i++)
                        {
                            keyVal =
                                (data.pKeys[i] != null
                                 ? data.pKeys[i].getValueAsObject() : null);
                            foundIt = keyVal != null && keyVal.equals(vals[i]);
                        }
                        if (foundIt)
                        {
                            break;
                        }
                        node = null;
                    }
                }
                if (node != null)
                {
                    np = node.getPath();
                }
            }
        }
        catch(Exception e)
        {
            // _debug("_buildNodePath: Exception: " + e);
        }
        return(np);
    }

    private boolean _findRow(SearchableRowsetAccess sra, String[] cols,
                             Object[] vals)
        throws javax.infobus.ColumnNotFoundException,
               javax.infobus.DuplicateColumnException,
               java.sql.SQLException
    {
        boolean foundIt = false;

        // _debug("_findRow: sra:" + sra);
        // for(int i=0; i < vals.length; i++) _debug("vals["+i+"]: " + vals[i]);
        foundIt = sra.findRow(cols, vals);
        // _debug("_findRow: end: sra:" + sra);
        return(foundIt);
    }

    // ControlEnabled interface implementation
    public void enabledChanged(boolean b)
    {
        setEnabled(b);
    }

    /**
    * This method is an implementaion side effect
    */
    public void focusLost(FocusEvent event)
    {
        _navmgr.focusedIsInvalid(false);
    }

    /**
    * This method is an implementaion side effect
    */
    public void focusGained(FocusEvent event)
    {
        if (isFocusValidated())
        {
            _navmgr.validateFocusChange(this);
        }
    }

    private String _findCurrentRowset(Control control)
    {
        String RowsetName = null;
        DataItem di = control == null ? null : (DataItem)control.getDataItem();
        
        if (di != null)
        {
            InfoObject dobj =
                (InfoObject)di.getProperty(DataItemProperties.INFO_OBJECT);

            if (dobj != null)
            {
                if (dobj instanceof AttributeInfo)
                {
                    RowsetName =
                        (String)di.getProperty(DataItemProperties.NAME);
                    int ndx =
                        RowsetName.lastIndexOf(InfoObject.ITEMNAME_DELIMITER);
                    RowsetName = RowsetName.substring(0,ndx);
                }
                else
                {
                    if (dobj instanceof RowSetInfo)
                    {
                        RowsetName =
                            (String)di.getProperty(DataItemProperties.NAME);
                    }
                }
            }
        }
        return(RowsetName);
    } // _findCurrentRowset
    
    private void _hijackKeyStrokeActions()
    {
        KeyStroke[] ks = _tree.getRegisteredKeyStrokes();
        
        if (ks != null)
        {
            int cond;
            ActionListener al;
            InterceptTreeKeyStrokeAction w;

            // _debug("hijacking keystrokes");
            for(int i = 0; i < ks.length; i++)
            {
                cond = _tree.getConditionForKeyStroke(ks[i]);
                al = _tree.getActionForKeyStroke(ks[i]);
                w = new InterceptTreeKeyStrokeAction(al);
                _tree.unregisterKeyboardAction(ks[i]);
                _tree.registerKeyboardAction(w, ks[i], cond);
            }
        }
    }

    private static void NotImplemented(String s)
    {
        String msg = "Unimplemented method called: " + s;
        
        // _debug(msg);
        throw new RuntimeException(msg);
    }

    private synchronized boolean _updateModeTest(int initialState,
                                                 int newState)
    {
        boolean doIt = (_updateMode == initialState);

        if (doIt)
        {
            _updateMode = newState;
        }
        return(doIt);
    }

    private synchronized void _updateModeClear(int curState)
    {
        if (_updateMode == curState)
        {
            _updateMode = UPDATE_INACTIVE;
        }
    }

    private synchronized void _updateModeClear()
    {
        _updateMode = UPDATE_INACTIVE;
    }
    
    private static void _debug(String s)
    {
        if (_DEBUG)
        {
            System.out.println("TreeControl: " + s);
            System.out.flush();
        }        
    } // _debug

    /**
    **  A subclass of JTree that only supports the
    **  TreeSelectionModel.SINGLE_TREE_SELECTION selection model.<P>
    */
    public class TreeControlTree
        extends JTree
    {
        private Vector _mouseListeners;
        private Vector _mouseMotionListeners;
        
        public TreeControlTree()
        {
            super();
            _init();
        }

        public TreeControlTree(Object[] value)
        {
            super(value);
            _init();
        }

        public TreeControlTree(Vector value)
        {
            super(value);
            _init();
        }

        public TreeControlTree(Hashtable value)
        {
            super(value);
            _init();
        }

        public TreeControlTree(TreeNode root)
        {
            super(root);
            _init();
        }

        public TreeControlTree(TreeNode root, boolean asksAllowsChildren)
        {
            super(root, asksAllowsChildren);
            _init();
        }

        public TreeControlTree(TreeModel newModel)
        {
            super(newModel);
            _init();
        }
        
        private void _init()
        {
            _hijackMouseListeners();
            super.setSelectionModel(new TreeControlSelectionModel());
            setCellRenderer(new TreeControlNodeRenderer());
        }

        private void _hijackMouseListeners()
        {
            TreeMouseMonitor mouselistener = new TreeMouseMonitor();
            super.addMouseListener(mouselistener);
            super.addMouseMotionListener(mouselistener);
        }
    
        public void addMouseListener(MouseListener l)
        {
            if (_mouseListeners == null)
            {
                _mouseListeners = new Vector(1);
            }
            _mouseListeners.addElement(l);
        }

        public void removeMouseListener(MouseListener l)
        {
            if (_mouseListeners != null)
            {
                _mouseListeners.removeElement(l);
            }
        }

        public void addMouseMotionListener(MouseMotionListener l)
        {
            if (_mouseMotionListeners == null)
            {
                _mouseMotionListeners = new Vector(1);
            }
            _mouseMotionListeners.addElement(l);
        }

        public void removeMouseMotionListener(MouseMotionListener l)
        {
            if (_mouseMotionListeners != null)
            {
                _mouseMotionListeners.removeElement(l);
            }
        }
    
        /**
        ** Overrides JTree.setSelectionModel()
        **
        ** all requests to changed the selection model are ignored
        **
        ** @param model ignored
        */
        public void setSelectionModel(TreeSelectionModel model)
        {
        }

        private synchronized MouseListener[] _getMouseListeners()
        {
            MouseListener[] listeners = null;

            if (_mouseListeners != null)
            {
                listeners = new MouseListener[_mouseListeners.size()];
                _mouseListeners.copyInto(listeners);
            }
            return(listeners);
        }
    
    
        private synchronized MouseMotionListener[] _getMouseMotionListeners()
        {
            MouseMotionListener[] listeners = null;

            if (_mouseMotionListeners != null)
            {
                listeners = 
                    new MouseMotionListener[_mouseMotionListeners.size()];
                _mouseMotionListeners.copyInto(listeners);
            }
            return(listeners);
        }

        private void _debug(String s)
        {
            if (_DEBUG)
            {
                System.out.println("TreeControlTree: " + s);
                System.out.flush();
            }        
        } // _debug

        public class TreeControlSelectionModel
            extends DefaultTreeSelectionModel
        {
            /**
            ** Sets the selection to the paths in paths.  If this represents a
            ** change the TreeSelectionListeners are notified.  Potentially
            ** paths will be held by the reciever, in other words don't change
            ** any of the objects in the array once passed in.
            **
            ** @param paths new selection.
            */
            public void setSelectionPaths(TreePath[] pPaths)
            {
                super.setSelectionPaths(pPaths);
            }

            /**
            ** Adds paths to the current selection.  If any of the paths in 
            ** paths are not currently in the selection the
            ** TreeSelectionListeners are notified.
            **
            ** @param path the new path to add to the current selection.
            */
            public void addSelectionPaths(TreePath[] paths)
            {
                super.addSelectionPaths(paths);
            }

            /**
            ** Removes paths from the selection.  If any of the paths in paths
            ** are in the selection the TreeSelectionListeners are notified.
            **
            ** @param path the path to remove from the selection.
            */
            public void removeSelectionPaths(TreePath[] paths)
            {
                super.removeSelectionPaths(paths);
            }

            protected void fireValueChanged(TreeSelectionEvent event)
            {
                _selectionChanged(event);
                super.fireValueChanged(event);
            }
        }

        public class TreeControlNodeRenderer
            extends DefaultTreeCellRenderer
        {
            private Color _currentRowForeground = Color.white;
            private Color _currentRowBackground = Color.gray;
            private boolean _isCurrent;
        
            /**
            **  Set the background current row color.
            **
            **  The TreeControl always high-lights the current row using the
            **  CurrentRow colors.
            **
            **  @param currentRowBackground  The color to be used to display
            **                               the background of a node when it 
            **                               maps to the current row
            **
            */
            public void setCurrentRowBackground(Color currentRowBackground)
            {
                _currentRowBackground = currentRowBackground;
            } // setCurrentRowBackground
    
            /**
            **  Return the background current row color.
            **
            **  The TreeControl always high-lights the current row using the
            **  CurrentRow colors.
            **
            **  @return The color to be used to display the background of a
            **          node when it maps to the current row
            **
            **  @see #setCurrentRowBackground(Color currentRowBackground)
            */
            public Color getCurrentRowBackground()
            {
                return(_currentRowBackground);
            } // getCurrentRowBackground
    
            /**
            **  Set the foreground current row color.
            **
            **  The TreeControl always high-lights the current row using the
            **  CurrentRow colors.
            **
            **  @param currentRowForeground  The color to be used to display
            **                               the foreground of a node when it
            **                               maps to the current row
            **
            */
            public void setCurrentRowForeground(Color currentRowForeground)
            {
                _currentRowForeground = currentRowForeground;
            } // setCurrentRowForeground
    
            /**
            **  Return the Foreground current row color.
            **
            **  The TreeControl always high-lights the current row using the
            **  CurrentRow colors.
            **
            **  @return The color to be used to display the Foreground of a
            **          node when it maps to the current row
            **
            **  @see #setCurrentRowForeground(Color currentRowForeground)
            */
            public Color getCurrentRowForeground()
            {
                return(_currentRowForeground);
            } // getCurrentRowForeground
            
            /**
            ** Sets the color the text is drawn with when the node isn't
            ** selected.
            **
            ** @see #setTextNonSelectionColor(Color color)
            */
            public Color getTextNonSelectionColor()
            {
                return(_isCurrent ?
                       _currentRowForeground :
                       super.getTextNonSelectionColor());
            } // getTextNonSelectionColor
    
            /**
            ** Returns the color to use for the background if node is not
            ** selected.
            **
            ** @see #setBackgroundNonSelectionColor(Color color)
            */
            public Color getBackgroundNonSelectionColor()
            {
                return(_isCurrent ?
                       _currentRowBackground :
                       super.getBackgroundNonSelectionColor());
            } // getBackgroundNonSelectionColor

            /**
            ** Configures the renderer based on the passed in components.
            ** The value is set from messaging value with toString().
            ** The foreground color is set based on the selection and the icon
            ** is set based on on leaf and expanded.
            **/
            public Component getTreeCellRendererComponent(JTree tree,
                                                          Object value,
                                                          boolean sel,
                                                          boolean expanded,
                                                          boolean leaf,
                                                          int row,
                                                          boolean hasFocus)
            {
                Component c;
                
                if (value instanceof TreeControlNode)
                {
                    _isCurrent =
                        (((TreeControlNode)value).isCurrentRow() &&
                         ((TreeControlNode)value).getParent() != null);
                }
                else
                {
                    _isCurrent = false;
                }
                c = super.getTreeCellRendererComponent(tree, value, sel,
                                                       expanded, leaf,
                                                       row, hasFocus);
                return(c);
            }
        }
        
        protected class TreeMouseMonitor
            extends MouseInputAdapter
        {
            public void mouseClicked(MouseEvent e)
            {
                MouseListener[] listeners = _getMouseListeners();

                if (listeners != null)
                {
                    for(int i = 0; i < listeners.length; i++)
                    {
                        listeners[i].mouseClicked(e);
                    }
                }
            }
        
            public void mouseDragged(MouseEvent e)
            {
                MouseMotionListener[] listeners =
                    _getMouseMotionListeners();

                if (listeners != null)
                {
                    for(int i = 0; i < listeners.length; i++)
                    {
                        listeners[i].mouseDragged(e);
                    }
                }
            }
        
            public void mouseEntered(MouseEvent e)
            {
                MouseListener[] listeners =
                    _getMouseListeners();

                if (listeners != null)
                {
                    for(int i = 0; i < listeners.length; i++)
                    {
                        listeners[i].mouseEntered(e);
                    }
                }
            }
        
            public void mouseExited(MouseEvent e)
            {
                MouseListener[] listeners =
                    _getMouseListeners();

                if (listeners != null)
                {
                    for(int i = 0; i < listeners.length; i++)
                    {
                        listeners[i].mouseExited(e);
                    }
                }
            }
        
            public void mouseMoved(MouseEvent e)
            {
                MouseMotionListener[] listeners =
                    _getMouseMotionListeners();

                if (listeners != null)
                {
                    for(int i = 0; i < listeners.length; i++)
                    {
                        listeners[i].mouseMoved(e);
                    }
                }
            }

            public void mousePressed(MouseEvent e)
            {
                // _debug("mousePressed()");
                try
                {
                    TreePath tp;

                    tp = getSelectionPath();
                    // _debug("SelectionPath:"+(tp==null?"none":tp.toString()));
                    if (_navmgr.validateFocusChange(TreeControl.this))
                    {
                        MouseListener[] listeners = _getMouseListeners();
                        if (listeners != null)
                        {
                            for(int i = 0; i < listeners.length; i++)
                            {
                                listeners[i].mousePressed(e);
                            }
                        }

                        Point pt = (e != null ? e.getPoint() : null);
                        tp = (pt != null ?
                              getPathForLocation(pt.x, pt.y) : null);

                        if (tp != null)
                        {
                            _selectionUpdated(tp);
                        }
                    }
                    else
                    {
                        // _debug("selecting previous node");
                        setSelectionPath(_prevSelectedNode);
                    }
                }
                catch(Exception ex)
                {
                    // _debug("exception caught; selecting previous: " + ex);
                    setSelectionPath(_prevSelectedNode);
                }
            }

            public void mouseReleased(MouseEvent e)
            {
                MouseListener[] listeners = _getMouseListeners();

                if (listeners != null)
                {
                    for(int i = 0; i < listeners.length; i++)
                    {
                        listeners[i].mouseReleased(e);
                    }
                }
            }
            
            private void _debug(String s)
            {
                if (_DEBUG)
                {
                    System.out.println("TreeMouseMonitor: " + s);
                    System.out.flush();
                }        
            } // _debug
        }
    }
    
    public class InterceptTreeKeyStrokeAction
            extends AbstractAction
    {
        private ActionListener _action;
        
        public InterceptTreeKeyStrokeAction(ActionListener action)
        {
            _action = action;
        }

        public void actionPerformed(ActionEvent e)
        {
            if (_action != null)
            {
                TreePath oTp = _tree.getSelectionPath();
                TreePath nTp = null;

                // _debug("action performed on hijacked keystroke");
                _action.actionPerformed(e);
                nTp = _tree.getSelectionPath();
                if (nTp != null && !nTp.equals(oTp))
                {
                    _selectionUpdated(nTp);
                }
            }
        }

        public Object getValue(String key)
        {
            Object val = null;
            if (_action != null && _action instanceof AbstractAction)
            {
                val = ((AbstractAction)_action).getValue(key);
            }
            return(val);
        }
        
        public void putValue(String key, Object val)
        {
            if (_action != null && _action instanceof AbstractAction)
            {
                ((AbstractAction)_action).putValue(key,val);
            }
        }

        public boolean isEnabled()
        {
            return(_action != null &&
                   _action instanceof AbstractAction &&
                   ((AbstractAction)_action).isEnabled());
        }

        public void setEnabled(boolean b)
        {
            if (_action != null && _action instanceof AbstractAction)
            {
                ((AbstractAction)_action).setEnabled(b);
            }
        }

        public void addPropertyChangeListener(PropertyChangeListener l)
        {
            if (_action != null && _action instanceof AbstractAction)
            {
                ((AbstractAction)_action).addPropertyChangeListener(l);
            }
        }

        public void removePropertyChangeListener(PropertyChangeListener l)
        {
            if (_action != null && _action instanceof AbstractAction)
            {
                ((AbstractAction)_action).removePropertyChangeListener(l);
            }
        }

        public Object clone()
            throws CloneNotSupportedException
        {
            InterceptTreeKeyStrokeAction c =
                (InterceptTreeKeyStrokeAction)super.clone();

            return(c);
        }
    }
}


//
// oracle/dacf/control/swing/TreeControl.java
// Oracle JDeveloper
// Copyright (c) 1997, 1999, Oracle Corporation.
// All rights reserved.
//
