/*
 * @(#)LoginFailureException.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.dacf.control;

/**
 * This exception is thrown to stop the the execution of a frame
 * or applet when a connection cannot be made.
 *
 */
public class LoginFailureException extends RuntimeException
{

   /**
    *  Constructs a LoginFailureException.
    *
    */

   public LoginFailureException()
   {
       this(Res.getString(Res.LOGIN_FAILURE_EXCEPTION));
   }

   /**
    *  Constructs a LoginFailureException.
    *
    * @param msg      Custom message describing the reason for
    *                 login failure
    */

   public LoginFailureException(String msg)
   {
       super(msg);
   }

}


