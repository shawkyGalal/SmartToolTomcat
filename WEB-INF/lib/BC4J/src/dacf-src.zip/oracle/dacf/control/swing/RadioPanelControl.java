/*
 * @(#)RadioPanelControl.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.dacf.control.swing;

import java.awt.Component;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.util.Enumeration;
import javax.infobus.DataItemAddedEvent;
import javax.infobus.DataItemChangeListener;
import javax.infobus.DataItemDeletedEvent;
import javax.infobus.DataItemRevokedEvent;
import javax.infobus.DataItemValueChangedEvent;
import javax.infobus.ImmediateAccess;
import javax.infobus.RowsetCursorMovedEvent;
import javax.swing.JPanel;
import oracle.dacf.control.Control;
import oracle.dacf.control.ControlEnabledListener;
import oracle.dacf.control.ControlSupport;
import oracle.dacf.control.InfoBusManager;
import oracle.dacf.control.InfoBusManagerListener;
import oracle.dacf.control.InfoBusManagerReleaseEvent;
import oracle.dacf.control.NavigatedEvent;
import oracle.dacf.control.NavigatedListener;
import oracle.dacf.control.NavigatingEvent;
import oracle.dacf.control.NavigatingException;
import oracle.dacf.control.NavigatingListener;

/**
 *  Data aware radio panel control that can be bound to
 *  an <TT>ImmediateAccess</TT> dataitem. Serves as a container for
 *  RadioButtonControls and ensures at the most one RadioButtonControl
 *  is selected at a time. if the dataitem's value equals any of the
 *  button, the button is selected and rest are deselected. If no match
 *  is found no button is selected
 *
 * @version PUBLIC
 */
public class RadioPanelControl
    extends JPanel
    implements Control, ControlEnabledListener, InfoBusManagerListener
{
    public static final int HORIZONTAL = 1;
    public static final int VERTICAL = 2;

    private GridLayout _layout = new GridLayout(0, 1);
    private RadioGroup _radioGroup;
    private int _orientation = VERTICAL;
    private ControlSupport _controlSupport;

    /**
    * Constructs a default RadioPanelControl
    */
    public RadioPanelControl()
    {
        setLayout(_layout);
        setPreferredSize(new Dimension(100, 100));
        _controlSupport = new ControlSupport(this);
        _radioGroup = new RadioGroup(this);
        _controlSupport.addControlEnabledListener(this);
        InfoBusManager.getInstance().addInfoBusManagerListener(this);
    }
    /**
    * Adds a RadioButtonControl to this. <P>
    * @param control RadioButtonControl to be added
    */
    public void addRadioButton(RadioButtonControl control)
    {
        add(control, null);
    }

    /**
    * Removes a previously added control to this panel. <P>
    * @param control RadioButtonControl to be removed
    */
    public void removeRadioButton(RadioButtonControl control)
    {
        remove(control);
    }

    /**
    * Adds a RadioButtonControl to this. <P>
    * @param control RadioButtonControl to be added
    */
    public void add(RadioButtonControl control)
    {
        add(control, null);
    }


    /**
    * Adds a RadioButtonControl to this. <P>
    * @param control RadioButtonControl to be added
    */
    public void add(RadioButtonControl control, Object constraints)
    {
        //if(_orientation == HORIZONTAL)
        //{
        //    _layout.setColumns(_layout.getColumns() + 1);
        //}
        //else if(_orientation == VERTICAL)
        //{
        //    _layout.setRows(_layout.getRows() + 1);
        //}

        _radioGroup.add(control);
        super.add(control, constraints);
    }

    /**
    * Removes a RadioButtonControl from this. <P>
    * @param control RadioButtonControl to be removed
    */
    public void remove(RadioButtonControl control)
    {
        // Remove the button from the group
        _radioGroup.remove(control);
        super.remove(control);
    }

    /**
    * Sets the layout of the RadioButtons.
    * @param orientation either HORIZONTAL or VERTICAL
    */
    public void setOrientation(int orientation)
    {
        if(orientation != _orientation)
        {
            int nbuttons = getComponentCount();
            if(orientation == HORIZONTAL)
            {
                _layout.setRows(1);
                _layout.setColumns(0);

            }
            else if(orientation == VERTICAL)
            {
                _layout.setColumns(1);
                _layout.setRows(0);
            }
            else
            {
                throw new IllegalArgumentException
                    ("Bad orientation value" + orientation);
            }
            _orientation = orientation;
            invalidate();
            validate();
        }
    }

    /**
    * Gets the layout of the RadioButtons.
    * @return  HORIZONTAL or VERTICAL
    */
    public int getOrientation()
    {
        return _orientation;
    }

    // ControlEnabledListener interface
    public void enabledChanged(boolean b)
    {
        RadioButtonControl rb;
        Enumeration e = _radioGroup.getElements();

        while(e.hasMoreElements())
        {
            ((RadioButtonControl)e.nextElement()).setEnabled(b);
        }
    }

    // InfoBusManagerListener interface implementation
    public void releaseResources(InfoBusManagerReleaseEvent e)
    {
        if (e.appliesTo(this))
        {
            InfoBusManager.getInstance().removeInfoBusManagerListener(this);
            _controlSupport.removeControlEnabledListener(this);
            _controlSupport = null;
        }
    }

    // Control Interface

    /**
    ** An override of java.awt.Component.setEnabled. <P>
    **
    ** @param b boolean flag indicating whether the control is enabled
    */
    public void setEnabled(boolean b)
    {
        super.setEnabled(b);
        if (_controlSupport != null)
        {
            _controlSupport.setEnabled(b);
        }
    }

    /**
    * Returns the name of the InfoBus this control is connected to. <P>
    * Most controls should delegate this method to <TT>ControlSupport</TT>. <P>
    * @return  The name of the InfoBus this control is connected to.
    * @see ControlSupport#getInfoBusName
    */
    public final String getInfoBusName()
    {
        return(_controlSupport == null ?
               null : _controlSupport.getInfoBusName());
    }

    /**
    * Sets the name of the InfoBus this control is connected to. <P>
    * If the named InfoBus does not exist, it is created automatically. <P>
    * If the control is already connected to an InfoBus, it is disconnected
    * first. <P>
    * Most controls should delegate this method to <TT>ControlSupport</TT>. <P>
    * @param infoBusName   The name of the InfoBus to connect to.
    * @see ControlSupport#setInfoBusName
    */
    public final void setInfoBusName(String infoBusName)
    {
        if (_controlSupport != null)
        {
            _controlSupport.setInfoBusName(infoBusName);
        }
    }

    /**
    * Returns the name of the InfoBus DataItem this control is bound to. <P>
    * Most controls should delegate this method to <TT>ControlSupport</TT>. <P>
    * @return  The name of the InfoBus DataItem this control is bound to,
    *          or <TT>null</TT> if the control is unbound.
    * @see #getDataItem
    * @see ControlSupport#getDataItemName
    */
    public final String getDataItemName()
    {
        return(_controlSupport == null ?
               null : _controlSupport.getDataItemName());
    }

    /**
    * Sets the name of the InfoBus DataItem this control is bound to. <P>
    * The DataItem with the given name is searched for on the InfoBus, and
    * if found, is bound to this control. <P>
    * If the control is already bound to a DataItem, it is unbound first. <P>
    * Most controls should delegate this method to <TT>ControlSupport</TT>. <P>
    * @param dataItemName  The name of the DataItem to bind to.
    * @see #getDataItem
    * @see ControlSupport#setDataItemName
    */
    public final void setDataItemName(String dataItemName)
    {
        if (_controlSupport != null)
        {
            _controlSupport.setDataItemName(dataItemName);
        }
    }

    /**
    * Returns the InfoBus DataItem this control is bound to. <P>
    * Most controls should delegate this method to <TT>ControlSupport</TT>. <P>
    * @return  The InfoBus DataItem this control is bound to, or
    *          <TT>null</TT> if the control is unbound.
    * @see ControlSupport#getDataItem
    */
    public final Object getDataItem()
    {
        return(_controlSupport == null ?
               null : _controlSupport.getDataItem());
    }

    /**
    * Notifies the control that the bound InfoBus DataItem has changed. <P>
    * The control can safely ignore this notification. <P>
    * @param oldDataItem   The formerly bound DataItem (can be <TT>null</TT>).
    * @param newDataItem   The newly bound DataItem (can be <TT>null</TT>).
    */
    public final void dataItemChanged(Object oldDataItem, Object newDataItem)
    {
        if (newDataItem instanceof ImmediateAccess)
        {
            _radioGroup.setDataItem(newDataItem);
        }
    }

    /**
    * Returns the AWT component associated with this control. <P>
    * @return  The AWT component for this control.
    */
    public final Component getComponent()
    {
        return(this);
    }

    /**
    * Determines whether focus into this control causes validation to
    * occur. <P>
    * Most controls should delegate this method to <TT>ControlSupport</TT>. <P>
    * @return  <TT>true</TT> if focus into this control causes validation to
    *          occur, <TT>false</TT> otherwise.
    * @see ControlSupport#isFocusValidated
    */
    public final boolean isFocusValidated()
    {
        return(_controlSupport == null ?
               false : _controlSupport.isFocusValidated());
    }

    /**
    * Sets whether focus into this control causes validation to occur. <P>
    * Most controls should delegate this method to <TT>ControlSupport</TT>. <P>
    * @param focusValidated    If <TT>true</TT>, focus into this control will
    *                          cause validation to occur.
    * @see ControlSupport#setFocusValidated
    */
    public final void setFocusValidated(boolean focusValidated)
    {
        if (_controlSupport != null)
        {
            _controlSupport.setFocusValidated(focusValidated);
        }
    }
    
    /**
    * Adds a navigated listener to this control. <P>
    * The listener will be notified of NavigateIn and NavigateOut events. <P>
    * Most controls should delegate this method to <TT>ControlSupport</TT>. <P>
    * @param listener  The listener to add.
    * @see ControlSupport#addNavigatedListener
    */
    public final void addNavigatedListener(NavigatedListener listener)
    {
        if (_controlSupport != null)
        {
            _controlSupport.addNavigatedListener(listener);
        }
    }

    /**
    * Removes a navigated listener from this control. <P>
    * Most controls should delegate this method to <TT>ControlSupport</TT>. <P>
    * @param listener  The listener to remove.
    * @see ControlSupport#removeNavigatedListener
    */
    public final void removeNavigatedListener(NavigatedListener listener)
    {
        if (_controlSupport != null)
        {
            _controlSupport.removeNavigatedListener(listener);
        }
    }

    /**
    * Processes a navigated event for this control. <P>
    * This method is for use by the NavigationManager only. <P>
    * Most controls should delegate this method to <TT>ControlSupport</TT>. <P>
    * @param event The navigated event.
    * @see ControlSupport#processNavigatedEvent
    */
    public final void processNavigatedEvent(NavigatedEvent event)
    {
        if (_controlSupport != null)
        {
            _controlSupport.processNavigatedEvent(event);
        }
    }

    /**
    * Adds a navigating listener to this control. <P>
    * The listener will be notified of NavigateIn and NavigateOut events. <P>
    * Most controls should delegate this method to <TT>ControlSupport</TT>. <P>
    * @param listener  The listener to add.
    * @see ControlSupport#addNavigatedListener
    */
    public final void addNavigatingListener(NavigatingListener listener)
    {
        if (_controlSupport != null)
        {
            _controlSupport.addNavigatingListener(listener);
        }
    }

    /**
    * Removes a navigating listener from this control. <P>
    * Most controls should delegate this method to <TT>ControlSupport</TT>. <P>
    * @param listener  The listener to remove.
    * @see ControlSupport#removeNavigatedListener
    */
    public final void removeNavigatingListener(NavigatingListener listener)
    {
        if (_controlSupport != null)
        {
            _controlSupport.removeNavigatingListener(listener);
        }
    }

    /**
    * Processes a navigating event for this control. <P>
    * This method is for use by the NavigatedManager only. <P>
    * Most controls should delegate this method to <TT>ControlSupport</TT>. <P>
    * @param event The navigating event.
    * @exception NavigatingException   If the navigation is redirected to a
    *                                  different control.
    * @see ControlSupport#processNavigatedEvent
    */
    public final void processNavigatingEvent(NavigatingEvent event)
        throws NavigatingException
    {
        if (_controlSupport != null)
        {
            _controlSupport.processNavigatingEvent(event);
        }
    }


    // DataItemChangeListener Interface

    /**
    * Indicates a changed value in the bound data item. <P>
    * A reference to the data item that changed can be obtained from the
    * event. <P>
    * @param event Contains change information.
    * @see javax.infobus.DataItemChangeListener#dataItemValueChanged
    */
    public final void dataItemValueChanged(DataItemValueChangedEvent event)
    {
        //Handled by RadioGroup
    }

    /**
    * Indicates that a new item was added to the bound aggregate data item
    * (e.g. <TT>ArrayAccess</TT>, a JDK Collection, etc). <P>
    * A reference to the data item that was added, and a reference to the one
    * that gained it, can be obtained from the event. <P>
    * @param event Contains details of the addition.
    * @see javax.infobus.DataItemChangeListener#dataItemAdded
    */
    public final void dataItemAdded(DataItemAddedEvent event)
    {
        // Not applicable
    }


    /**
    * Indicates that an item was deleted from the bound aggregate data item
    * (e. g. <TT>ArrayAccess</TT>, a JDK Collection, etc). <P>
    * A reference to the data item that was deleted, and a reference to the
    * one that lost it, can be obtained from the event. <P>
    * @param event Contains details of the deletion.
    * @see javax.infobus.DataItemChangeListener#dataItemDeleted
    */
    public final void dataItemDeleted(DataItemDeletedEvent event)
    {
        // Not applicable
    }

    /**
    * Indicates that the bound data item (and its sub-items, if any) has been
    * revoked, and is temporarily unavailable. <P>
    * A reference to the data item that was revoked can be obtained from
    * the event. <P>
    * @param event Contains details of the revoked data.
    * @see javax.infobus.DataItemChangeListener#dataItemRevoked
    */
    public final void dataItemRevoked(DataItemRevokedEvent event)
    {

    }

    /**
    * Indicates that the cursor for the bound <TT>RowsetAccess</TT> data item
    * has changed rows. <P>
    * A reference to the rowset data item can be obtained from the event. <P>
    * @param event Contains details of the cursor move.
    * @see javax.infobus.DataItemChangeListener#rowsetCursorMoved
    */
    public final void rowsetCursorMoved(RowsetCursorMovedEvent event)
    {
        // Not applicable
    }
}
