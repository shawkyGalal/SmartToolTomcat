/*
 * @(#)DataItemAccessHelper.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.dacf.control;

import java.beans.PropertyChangeEvent;
import java.beans.PropertyVetoException;
import javax.infobus.InfoBus;
import javax.infobus.InfoBusDataConsumer;
import javax.infobus.InfoBusItemAvailableEvent;
import javax.infobus.InfoBusItemRevokedEvent;
import javax.infobus.InfoBusMembershipException;
import oracle.dacf.dataset.InfoObject;

// Most of the functionality is avail in ControlSupport. But ControlSupport
// include code for Controls which you don't want when you just want InfoBus
// data access
/**
 *  This class provides support to help access a data item.
 *
 *  @version INTERNAL
 *
 */
public class DataItemAccessHelper
    extends ConsumerSupport
    implements InfoBusDataConsumer
{
    /**
    *  Name of the InfoBus we are part of
    */
    private String _infoBusName;
     
    /**
    *  name of the data item
    */
    private String _dataItemName;

    /**
    *  dataItem
    */
    private Object _dataItem;

    /**
    * Constructor
    */
    public DataItemAccessHelper()
    {
        super(null);
        addInfoBusPropertyListener(this);
        setInfoBusName(Control.DEFAULT_INFOBUS_NAME);
    }

    // InfoBusDataConsumer Interface

    /**
    * This method is called by the <TT>InfoBus</TT> class on behalf of a data
    * producer that is announcing the availability of a new data item by
    * name. <P>
    */

    public void dataItemAvailable(InfoBusItemAvailableEvent event)
    {
        if (_dataItem == null)
        {
            String dataItemName = _dataItemName;
            if (dataItemName != null)
            {
                String name = event.getDataItemName();
                if (dataItemName.equals(name))
                {
                    _setDataItem(event.requestDataItem(this, null));
                    if (_dataItem != null)
                        dataItemPublished(); // notification
                }
                else if (dataItemName.startsWith(name +
                                                 InfoObject.ITEMNAME_DELIMITER))
                {
                    InfoBus infoBus = getInfoBus();
                    if (infoBus != null)
                    {
                        _setDataItem(infoBus.findDataItem(dataItemName, null,
                                                          this));
                        if (_dataItem != null)
                            dataItemPublished(); // notification
                    }
                }
            }
        }
    }


    /**
    * This method is called by the <TT>InfoBus</TT> class on behalf of a data
    * producer that is revoking the availability of a previously announced
    * data item. <P>
    *
    * @param event The event.
    */
    public void dataItemRevoked(InfoBusItemRevokedEvent event)
    {
        String dataItemName = _dataItemName;
        if (dataItemName != null &&
            dataItemName.equals(event.getDataItemName()))
        {
            _setDataItem(null);
        }
    }

    /**
    * This method gets called when the object's <TT>InfoBus</TT> property
    * is changed. <P>
    * The object is removed as a data consumer from its previous InfoBus,
    * and is added as a consumer to its new InfoBus. <P>
    * @param event The event.
    */
    public void propertyChange(PropertyChangeEvent event)
    {
        if (event.getPropertyName().equals("InfoBus"))
        {
            Object oldVal = event.getOldValue();
            Object newVal = event.getNewValue();

            if (oldVal != newVal)
            {
                if (oldVal != null && oldVal instanceof InfoBus)
                {
                    ((InfoBus)oldVal).removeDataConsumer(this);
                }

                if (newVal != null && newVal instanceof InfoBus)
                {
                    ((InfoBus)newVal).addDataConsumer(this);
                }
            }
        }
    }


    /**
    * Sets the name of the InfoBus this transaction monitor is connected to. <P>
    * By default, the it is connected to the default InfoBus,
    * named <TT>Control.DEFAULT_INFOBUS_NAME</TT>. <P>
    * If the named InfoBus does not exist, it is created automatically. <P>

    * @param infoBusName   The name of the InfoBus to connect to.
    */
    public synchronized void setInfoBusName(String infoBusName)
    {
        if (infoBusName == _infoBusName ||
            (infoBusName != null && infoBusName.equals(_infoBusName)))
        {
            return;
        }

        if (_infoBusName != null)
        {
            _dropInfoBus();
        }
        _infoBusName = infoBusName;

        if (infoBusName != null)
        {
            try
            {
                joinInfoBus(infoBusName);
                InfoBus infoBus = getInfoBus();
                if (infoBus == null)
                {
                    // XXX - throw exception?
                    System.err.println("setInfoBusName(): stale InfoBus");
                    return;
                }

                infoBus.addDataConsumer(this);

                if (_dataItemName != null)
                {
                    _setDataItem(infoBus.findDataItem(_dataItemName, null,
                                                      this));
                }
            }
            catch (InfoBusMembershipException e)
            {
                // XXX - Do something useful here
                System.err.println("setInfoBusName() warning: " +
                                   "joinInfoBus failed because InfoBus already set: " + e);
            }
            catch (PropertyVetoException e)
            {
                // XXX - Do something useful here
                System.out.println("setInfoBusName() warning: " +
                                   "joinInfoBus failed because voter vetoed setInfoBus: "+ e);
            }
        }
    }

    public String getInfoBusName()
    {
        return _infoBusName;
    }

    /**
    *  This method gets called wheneve the data item is published. Derived class can 
    *  override this method to initialize. For ex., when the data item is published
    *  you can look at its SQL type (for ImmediateAccess/AttributeInfo's)
    *
    *  @see dataItemAvailable()
    *  @see oracle.dacf.control.swing.find.FindItemModelImpl
    *  
    */
    protected void dataItemPublished()
    {

    }

    /**
    * Removes this object from its currently bound InfoBus and data item. <P>
    */
    private synchronized void _dropInfoBus()
    {
        _setDataItem(null);

        InfoBus infoBus = getInfoBus();
        if (infoBus != null)
        {
            infoBus.removeDataConsumer(this);
        }

        try
        {
            leaveInfoBus();
        }
        catch (InfoBusMembershipException e)
        {
            // Ignore
        }
        catch (PropertyVetoException e)
        {
            // Ignore
        }
    }

    /**
    * Binds to a data item. <P>
    * @param dataItem  The new data item to bind to.
    */
    protected synchronized void _setDataItem(Object dataItem)
    {
        Object oldDataItem = _dataItem;
        if (dataItem != oldDataItem)
        {
            _dataItem = dataItem;
        }
    }

    /**
    * Sets the name of the InfoBus DataItem this object is bound to. <P>
    * The DataItem with the given name is searched for on the InfoBus, and
    * if found, is bound to this object. <P>
    * If the object is already bound to a DataItem, it is unbound first. <P>
     
    * @param dataItemName  The name of the DataItem to bind to.
    * @see #getDataItem
    */
    public synchronized void setDataItemName(String dataItemName)
    {
        if (dataItemName == _dataItemName ||
            (dataItemName != null && dataItemName.equals(_dataItemName)))
        {
            return;
        }

        _dataItemName = dataItemName;

        InfoBus infoBus = getInfoBus();
        if (infoBus != null)
        {
            _setDataItem(infoBus.findDataItem(dataItemName, null, this));
        }
    }

    public String getDataItemName()
    {
        if ( _dataItemName != null )
            return _dataItemName;
        else
            return "";
    }


    /**
    *  return the data item the object is currently bound to.
    *
    *  @return the data item which the object is currently bound to.
    */
    public synchronized Object getDataItem()
    {
    	return _dataItem;
    }


}
