/*
 * @(#)FindPanelBeanInfo.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.dacf.control.swing;

import java.beans.PropertyDescriptor;

/**
 * bean info class for the find panel control
 *
 * @version INTERNAL
 */
public class FindPanelBeanInfo extends ControlBeanInfoHelper
{
  /**
  * Constructor
  */
  public FindPanelBeanInfo()
  {
    super();
  }

  /**
  * get the Class object for the bean
  *
  * @return Class object for the bean
  */
  protected Class getBeanClass()
  {
    return FindPanel.class;
  }

  /**
  * get property descriptors for the bean
  *
  * @return PropertyDescriptors specific to this bean
  */
  public PropertyDescriptor[] getPropertyDescriptors()
  {
    try
    {
      PropertyDescriptor modelDataItemName =
            new PropertyDescriptor("findPanelUI", getBeanClass(),
                "getFindPanelUI", "setFindPanelUI");
      PropertyDescriptor dataItemName = new PropertyDescriptor("dataItemName", getBeanClass(),
            "getDataItemName", "setDataItemName");
      dataItemName.setPropertyEditorClass(Class.forName("oracle.jdeveloper.daceditors.DataItemNameEditor"));

      PropertyDescriptor labelPosition = new PropertyDescriptor("labelPosition", getBeanClass(),
            "getLabelPosition", "setLabelPosition");
      labelPosition.setPropertyEditorClass(Class.forName("oracle.jdeveloper.daceditors.LabelPositionEditor"));

      PropertyDescriptor itemDirection = new PropertyDescriptor("itemDirection", getBeanClass(),
            "getItemDirection", "setItemDirection");
      itemDirection.setPropertyEditorClass(Class.forName("oracle.jdeveloper.daceditors.ItemDirectionEditor"));

      PropertyDescriptor hasFindButton = new PropertyDescriptor("hasFindButton", getBeanClass(),
            "getHasFindButton", "setHasFindButton");

      PropertyDescriptor hasResetButton = new PropertyDescriptor("hasResetButton", getBeanClass(),
            "getHasResetButton", "setHasResetButton");

      PropertyDescriptor hasCloseButton = new PropertyDescriptor("hasCloseButton", getBeanClass(),
             "getHasCloseButton", "setHasCloseButton");

      PropertyDescriptor hasHelpButton = new PropertyDescriptor("hasHelpButton", getBeanClass(),
            "getHasHelpButton", "setHasHelpButton");

      PropertyDescriptor hasORButton = new PropertyDescriptor("hasORButton", getBeanClass(),
            "getHasORButton", "setHasORButton");

      PropertyDescriptor hasRemoveButton = new PropertyDescriptor("hasRemoveButton",
         getBeanClass(), "getHasRemoveButton", "setHasRemoveButton");

      PropertyDescriptor hasRemoveAllButton = new PropertyDescriptor("hasRemoveAllButton",
          getBeanClass(), "getHasRemoveAllButton", "setHasRemoveAllButton");


      PropertyDescriptor hasFindIcon  = new PropertyDescriptor("hasFindIcon", getBeanClass(),
            "getHasFindIcon", "setHasFindIcon");

      PropertyDescriptor hasStatusBar  = new PropertyDescriptor("hasStatusBar", getBeanClass(),
            "getHasStatusBar", "setHasStatusBar");

      PropertyDescriptor labelFont = new PropertyDescriptor("labelFont", getBeanClass(),
           "getLabelFont", "setLabelFont");

      PropertyDescriptor textFieldFont = new PropertyDescriptor("textFieldFont", getBeanClass(),
           "getTextFieldFont", "setTextFieldFont");

      PropertyDescriptor labelForeColor = new PropertyDescriptor("labelForegroundColor", getBeanClass(),
           "getLabelForegroundColor", "setLabelForegroundColor");

      PropertyDescriptor labelBackColor = new PropertyDescriptor("labelBackgroundColor", getBeanClass(),
           "getLabelBackgroundColor", "setLabelBackgroundColor");

      PropertyDescriptor textForeColor = new PropertyDescriptor("textFieldForegroundColor", getBeanClass(),
         "getTextFieldForegroundColor", "setTextFieldForegroundColor");

      PropertyDescriptor textBackColor = new PropertyDescriptor("textFieldBackgroundColor", getBeanClass(),
         "getTextFieldBackgroundColor", "setTextFieldBackgroundColor");

      PropertyDescriptor textColWidth  = new PropertyDescriptor("textFieldColumnWidth", getBeanClass(),
         "getTextFieldColumnWidth", "setTextFieldColumnWidth");

      PropertyDescriptor caseSensitiveSearch  = new PropertyDescriptor("caseSensitiveSearch", getBeanClass(),
         "isCaseSensitiveSearch", "setCaseSensitiveSearch");



      PropertyDescriptor[] ret = {
                                   dataItemName,
                                   labelPosition, hasFindButton,
                                   hasResetButton, hasFindIcon,
                                   hasCloseButton,
                                   hasHelpButton,
                                   //hasORButton,
                                   //hasRemoveButton,
                                   //hasRemoveAllButton,
                                   hasStatusBar,
                                   labelFont, textFieldFont,
                                   labelForeColor, labelBackColor,
                                   textForeColor, textBackColor,
                                   textColWidth,
                                   itemDirection,
                                   caseSensitiveSearch
                                 };
      return ret;
    }
    catch (Exception exc)
    {
      exc.printStackTrace();
      return null;
    }
  }
}
