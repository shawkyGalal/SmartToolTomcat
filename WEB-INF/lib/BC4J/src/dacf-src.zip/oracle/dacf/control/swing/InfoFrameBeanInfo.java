/*
 * @(#)InfoFrameBeanInfo.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.dacf.control.swing;

import java.beans.BeanInfo;
import java.beans.IntrospectionException;
import java.beans.Introspector;
import java.beans.PropertyDescriptor;
import java.beans.SimpleBeanInfo;

/**
 * BeanInfo implementation for InfoFrame.
 *
 * @version SDK
 */
public class InfoFrameBeanInfo extends SimpleBeanInfo
{
   /**
   * list of properties for the InfoFrame
   */
   private String [][] propertyList = new String[][] {
     { "infoBusName", "getInfoBusName", "setInfoBusName", null},
     {"dataItemName", "getDataItemName", "setDataItemName",
          "oracle.jdeveloper.daceditors.DataItemNameEditor"} };

   /**
    * Returns the property descriptors for the bean
    * @see java.beans.BeanInfo#getPropertyDescriptors()
    */
  public PropertyDescriptor[] getPropertyDescriptors()
  {

      try
      {
         PropertyDescriptor[] pdarr = new PropertyDescriptor[propertyList.length];

         for (int i = 0 ; i < propertyList.length ; i++)
         {
            pdarr[i] = new PropertyDescriptor(propertyList[i][0],
                                              getBeanClass(),
                                              propertyList[i][1],
                                              propertyList[i][2]);

            if(propertyList[i][3] != null && oracle.dacf.util.DesignTime.inDesignTime())
            {
               try
               {
                 pdarr[i].setPropertyEditorClass(Class.forName(propertyList[i][3]));
               }
               catch(ClassNotFoundException ex)
               {
                 ex.printStackTrace(System.err);
               }
            }
         }

         return pdarr;

      }
      catch (Exception e)
      {
         e.printStackTrace(System.err);
         return null;
      }

  }

  /**
   *  Returns the class of the bean this BeanInfo describes
   *  @return returns LoginDlg.class
   */
  protected Class getBeanClass()
  {
    return InfoFrame.class;
  }

   /**
    * Returns the property descriptors for the bean superclass
    * @see java.beans.BeanInfo#getAdditionalBeanInfo()
    */

   public BeanInfo[] getAdditionalBeanInfo()
   {
      try
      {
        BeanInfo bi = Introspector.getBeanInfo(getBeanClass().getSuperclass());
        BeanInfo[] biarr = {bi};
        return biarr;
      }
      catch(IntrospectionException e)
      {
         e.printStackTrace(System.err);
         return null;

      }
   }

 }
