/*
 * @(#)ControlBeanInfoHelper.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.dacf.control.swing;

import java.beans.BeanInfo;
import java.beans.EventSetDescriptor;
import java.beans.IntrospectionException;
import java.beans.Introspector;
import java.beans.PropertyDescriptor;
import java.beans.SimpleBeanInfo;
import java.lang.Class;
import oracle.dacf.control.NavigatedListener;
import oracle.dacf.control.NavigatingListener;

/**
 * BeanInfo helper class.
 *
 * @version SDK
 */
public abstract class ControlBeanInfoHelper
    extends SimpleBeanInfo
{
    // should getAdditionalBeanInfo return base class bean info?
    protected boolean exposeBaseClassBeanInfo = true;

    String navigatingListenerMethodNames[] =
    {
        "navigatingOut"
    };
    

    String navigatedListenerMethodNames[] =
    {
        "navigatedInColumn", "navigatedOutColumn",
        "navigatedInRow", "navigatedOutRow",
        "navigatedInQueryView", "navigatedOutQueryView"
    };


    public ControlBeanInfoHelper()
    {
    }

    /**
    * Returns the property descriptors for the bean
    * @see java.beans.BeanInfo#getPropertyDescriptors()
    */
    public PropertyDescriptor[] getPropertyDescriptors()
    {

        try
        {
            PropertyDescriptor _dataItemName =
                new PropertyDescriptor("dataItemName", getBeanClass(),
                                       "getDataItemName", "setDataItemName");
            PropertyDescriptor _infoBusName =
                new PropertyDescriptor("infoBusName", getBeanClass(),
                                       "getInfoBusName", "setInfoBusName");

            _dataItemName.setPropertyEditorClass(getDataItemNameEditorClass());

            PropertyDescriptor[] pdarr  = {_dataItemName, _infoBusName};
            PropertyDescriptor[] addDescr = getAdditionalPropertyDescriptors();

            if ( addDescr == null )
                return pdarr;
            else
            {
                PropertyDescriptor[] ret = new PropertyDescriptor[
                                         pdarr.length + addDescr.length];
                int j=0;
                for(int i=0; i < pdarr.length; i++)
                    ret[j++] = pdarr[i];
                for(int i=0 ; i < addDescr.length;i++)
                    ret[j++] = addDescr[i];
                return ret;
            }

        }
        catch(Exception e)
        {
            e.printStackTrace(System.err);
            return null;
        }
    }


    /**
    * Returns the event descriptors for the bean
    * @see java.beans.BeanInfo#getEventSetDescriptors
    */
    public EventSetDescriptor[] getEventSetDescriptors()
    {
        // Get default events
        try
        {
            EventSetDescriptor esd =
                new  EventSetDescriptor(getBeanClass(),
                                        "navigated",
                                        NavigatedListener.class,
                                        navigatedListenerMethodNames,
                                        "addNavigatedListener",
                                        "removeNavigatedListener");
            EventSetDescriptor esd2 =
                new  EventSetDescriptor(getBeanClass(),
                                        "navigating",
                                        NavigatingListener.class,
                                        navigatingListenerMethodNames,
                                        "addNavigatingListener",
                                        "removeNavigatingListener");
            EventSetDescriptor[] esarr = { esd2, esd };
            EventSetDescriptor[] addDescr = getAdditionalEventDescriptors();

            if (addDescr == null)
                return esarr;
            else
            {
                EventSetDescriptor[] ret = new EventSetDescriptor[
                                esarr.length + addDescr.length];
                int j=0;
                for(int i=0; i < esarr.length; i++)
                    ret[j++] = esarr[i];
                for(int i=0 ; i < addDescr.length;i++)
                    ret[j++] = addDescr[i];
                return ret;
            }
        }
        catch(Exception e)
        {
            e.printStackTrace(System.err);
            return null;
        }
    }

    protected void setExposeBaseClassBeanInfo(boolean nuState)
    {
        exposeBaseClassBeanInfo = nuState;
    }

    protected boolean getExposeBaseClassBeanInfo()
    {
        return exposeBaseClassBeanInfo;
    }

    /**
    * Returns information about the bean superclass.
    * @see java.beans.BeanInfo#getAdditionalBeanInfo()
    */
    public BeanInfo[] getAdditionalBeanInfo()
    {
        if ( exposeBaseClassBeanInfo )
        {
            try
            {
                BeanInfo bi =
                    Introspector.getBeanInfo(getBeanClass().getSuperclass());
                BeanInfo[] biarr = {bi};
                return biarr;
            }
            catch(IntrospectionException e)
            {
                e.printStackTrace(System.err);
                return null;
            }
        }
        else
            return null;
    }

    /**
    *  derived class may override this method to add new properties in
    * addition to data item name and infobus.
    */
    protected PropertyDescriptor[] getAdditionalPropertyDescriptors()
    {
        return null;
    }

    /**
    *  derived class may override this method to add new events in
    */
    protected EventSetDescriptor[] getAdditionalEventDescriptors()
    {
        return null;
    }

    /**
    *  derived class should return the Bean class
    */
    protected Class getDataItemNameEditorClass()
    {
        Class cls = null;

        if (oracle.dacf.util.DesignTime.inDesignTime())
        {
           try
           {
               cls = Class.forName("oracle.jdeveloper.daceditors.DataItemNameEditor");
           }
           catch(java.lang.ClassNotFoundException e)
           {
               cls = null;
           }
        }

        return(cls);
    }

    /**
    *  derived class should return the Bean class
    */
    abstract protected Class getBeanClass();
}
