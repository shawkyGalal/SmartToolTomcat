/*
 * @(#)ChartLabelDataSourceImpl.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.dacf.control.tdg.chart;

import oracle.dacf.control.DataItemAccessHelper;

class ChartLabelDataSourceImpl extends DataItemAccessHelper 
      implements ChartLabelDataSource
{
    private Object[]         _labels;
    private ChartDataSource  _parent;
    
    ChartLabelDataSourceImpl(ChartDataSource parent)
    {
       super();
       _parent = parent;
    }

    void setLabels(Object[] labels)
    {
         _labels = labels;
    }

    Object[] getLabels()
    {
        return _labels;
    }

    public String getLabel(int index)
    {
        if ((_labels == null) || (index < 0) || (index > (_labels.length-1) ))
           return "";
        return _labels[index].toString();
    }

    int getElementCount()
    {
        if ( _labels != null )
           return _labels.length;
        return 0;
    }

    
    void updateChart()
    {
       _parent._updateChart();
    }
}
