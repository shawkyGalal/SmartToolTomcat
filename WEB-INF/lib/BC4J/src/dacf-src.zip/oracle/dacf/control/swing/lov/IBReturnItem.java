/*
 * @(#)IBReturnItem.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.dacf.control.swing.lov;

import java.util.Hashtable;
import javax.infobus.InvalidDataException;

/**
 *  Return item facility implemented using InfoBus
 *
 *  @version SDK
 *
 */
public class IBReturnItem implements ReturnItem
{
   private Hashtable _returnItems = new Hashtable();

   /**
   *  Constructor
   */
   public IBReturnItem()
   {
   }
   /**
   *  Define the 'return item ' identifier for a particular column.
   *
   * @param columnIndex column for which the 'return item' identifier is being
   *                    set
   * @param returnItemIndentifier  an identifier to return items
   */
   public void setReturnItemName(int columnIndex, Object returnItemName)
   {
      Integer i  = new Integer(columnIndex);
      if ( _returnItems.containsKey(i))
      {
          // changing return item for this column
          IBReturnItemHelper helper = (IBReturnItemHelper)_returnItems.get(i);
          helper.setDataItemName((String)returnItemName);
      }
      else
      {
          IBReturnItemHelper helper = new IBReturnItemHelper();
          helper.setDataItemName((String)returnItemName);
         _returnItems.put(i, helper);
       }

   }


   /**
   *  Return the 'return item' for a particular column
   *
   * @param columnIndex column index
   */
   public Object getReturnItemName(int columnIndex)
   {
       IBReturnItemHelper helper = (IBReturnItemHelper)
                                                     getReturnItem(columnIndex);
       return ((helper==null) ? null : helper.getDataItemName());
   }

   /**
   * set the value to be returned for a particular column index.
   */
   public void setValue(int columnIndex, Object value)
        throws InvalidDataException
   {
       IBReturnItemHelper helper = (IBReturnItemHelper)
                                                     getReturnItem(columnIndex);
       if ( helper != null )
          helper.setValue(value);
       else
          System.out.println
                 ("Error : return item  undefined column  : " + columnIndex);

   }

   public void removeAll()
   {
   }

   /**
   *  make use of the return item names to actually return item values
   */
   public void executeReturnItems()
   {

   }

   private Object getReturnItem(int index)
   {
      Integer i  = new Integer(index);
      return _returnItems.get(i);
   }
}
