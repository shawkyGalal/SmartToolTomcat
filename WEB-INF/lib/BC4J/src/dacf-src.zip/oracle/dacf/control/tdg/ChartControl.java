/*
 * @(#)ChartControl.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.dacf.control.tdg;

import java.awt.Component;
import javax.infobus.DataItemAddedEvent;
import javax.infobus.DataItemDeletedEvent;
import javax.infobus.DataItemRevokedEvent;
import javax.infobus.DataItemValueChangedEvent;
import javax.infobus.RowsetCursorMovedEvent;
import oracle.dacf.control.Control;
import oracle.dacf.control.ControlSupport;
import oracle.dacf.control.NavigatedEvent;
import oracle.dacf.control.NavigatedListener;
import oracle.dacf.control.NavigatingEvent;
import oracle.dacf.control.NavigatingListener;
import oracle.dacf.control.tdg.chart.ChartLabelDataSource;
import oracle.dacf.control.tdg.chart.ColOrderChartDataSource;
import oracle.dacf.control.tdg.chart.LabelAwareChartDataSource;
import oracle.dacf.control.tdg.chart.MappedChartDataSource;
import oracle.dacf.control.tdg.chart.RowOrderChartDataSource;
import tdg.Perspective;

/**
 *  InfoBus enabled chart control. This control is based upon Perspective
 *  for Java (ThreeD Graphics). Please refer to Perspective for Java
 *  documentation on various features provided by the chart control.
 *  http://www.threedgraphics.com/javachart/doc_main.html
 *
 */
public class ChartControl extends Perspective implements Control
{
    /**
    * row order
    */
    public static final int ROW = 0;
    /**
    * column order
    */
    public static final int COLUMN=1;


    // constants for Graph Types.

    // 3d
    public final static int THREED_BARS = 0;
    public final static int THREED_PYRAMIDS = 1;
    public final static int THREED_OCTAGONS = 2;
    public final static int THREED_FLOATING_CUBES = 4;
    public final static int THREED_FLOATING_PYRAMIDS = 5;
    public final static int THREED_FLOATING_CONNECTED_SERIES_AREA = 6;
    public final static int THREED_FLOATING_CONNECTED_SERIES_RIBBON = 7;
    public final static int THREED_FLOATING_CONNECTED_GROUP_AREA = 9;
    public final static int THREED_FLOATING_CONNECTED_GROUP_RIBBON = 10;
    public final static int THREED_SURFACE = 12;
    public final static int THREED_SURFACE_WITH_SIDES = 13;
    public final static int THREED_HONEYCOMB_SURFACE = 14;


    //2d
    public final static int VERTICAL_CLUSTERED_BARS = 17;
    public final static int VERTICAL_STACKED_BARS = 18;
    public final static int VERTICAL_DUAL_AXIS_CLUSTERED_BARS = 19;
    public final static int VERTICAL_DUAL_AXIS_STACKED_BARS = 20;
    public final static int VERTICAL_BI_POLAR_CLUSTERED_BARS = 21;
    public final static int VERTICAL_BI_POLAR_STACKED_BARS = 22;
    public final static int VERTICAL_PERCENT_BARS = 23;

    public final static int HORIZONTAL_CLUSTERED_BARS = 24;
    public final static int HORIZONTAL_STACKED_BARS = 25;
    public final static int HORIZONTAL_DUAL_AXIS_CLUSTERED_BARS = 26;
    public final static int HORIZONTAL_DUAL_AXIS_STACKED_BARS = 27;
    public final static int HORIZONTAL_BI_POLAR_CLUSTERED_BARS = 28;
    public final static int HORIZONTAL_BI_POLAR_STACKED_BARS = 29;
    public final static int HORIZONTAL_PERCENT_BARS = 30;

    public final static int VERTICAL_ABSOLUTE_AREA = 31;
    public final static int VERTICAL_STACKED_AREA = 32;
    public final static int VERTICAL_BI_POLAR_ABSOLUTE_AREA = 33;
    public final static int VERTICAL_BI_POLAR_STACKED_AREA = 34;
    public final static int VERTICAL_PERCENT_AREA = 35;

    public final static int HORIZONTAL_ABSOLUTE_AREA = 36;
    public final static int HORIZONTAL_STACKED_AREA = 37;
    public final static int HORIZONTAL_BI_POLAR_ABSOLUTE_AREA = 38;
    public final static int HORIZONTAL_BI_POLAR_STACKED_AREA = 39;
    public final static int HORIZONTAL_PERCENT_AREA = 40;

    public final static int VERTICAL_ABSOLUTE_LINE = 41;
    public final static int VERTICAL_STACKED_LINE = 42;
    public final static int VERTICAL_DUAL_AXIS_ABSOLUTE_LINE = 43;
    public final static int VERTICAL_DUAL_AXIS_STACKED_LINE = 44;
    public final static int VERTICAL_BI_POLAR_ABSOLUTE_LINE = 45;
    public final static int VERTICAL_BI_POLAR_STACKED_LINE = 46;
    public final static int VERTICAL_PERCENT_LINE = 47;


    public final static int HORIZONTAL_ABSOLUTE_LINE = 48;
    public final static int HORIZONTAL_STACKED_LINE = 49;
    public final static int HORIZONTAL_DUAL_AXIS_ABSOLUTE_LINE = 50;
    public final static int HORIZONTAL_DUAL_AXIS_STACKED_LINE = 51;
    public final static int HORIZONTAL_BI_POLAR_ABSOLUTE_LINE = 52;
    public final static int HORIZONTAL_BI_POLAR_STACKED_LINE = 53;
    public final static int HORIZONTAL_PERCENT_LINE = 54;


    public final static int PIE = 55;
    public final static int RING_PIE = 56;
    public final static int MULTI_PIE = 57;
    public final static int MULTI_RING_PIE = 58;
    public final static int MULTI_PROPORTIONAL_PIE = 59;
    public final static int MULTI_PROPORTIONAL_RING_PIE = 60;
    public final static int PIE_BAR_CHART = 93;
    public final static int RING_PIE_BAR_CHART = 94;


    public final static int XY_SCATTER = 61;
    public final static int XY_SCATTER_DUAL_AXIS = 62;
    public final static int XY_SCATTER_WITH_LABELS = 63;
    public final static int XY_SCATTER_WITH_LABELS_DUAL_AXIS = 64;


    public final static int POLAR = 65;
    public final static int POLAR_DUAL_AXIS = 66;


    public final static int RADAR_LINE =  67;
    public final static int RADAR_AREA =  68;
    public final static int RADAR_LINE_DUAL_AXIS =  69;

    public final static int OPEN_HI_LO_CLOSE_CANDLE_STOCK_CHART = 70;
    public final static int OPEN_HI_LO_CLOSE_CANDLE_STOCK_CHART_VOLUME = 71;
    public final static int CANDLE_STOCK_HI_LO_OPEN_CLOSE = 72;
    public final static int STOCK_HI_LO = 73;
    public final static int STOCK_HI_LO_DUAL_AXIS = 74;
    public final static int STOCK_HI_LO_BI_POLAR = 75;
    public final static int STOCK_HI_LO_CLOSE = 76;
    public final static int STOCK_HI_LO_CLOSE_DUAL_AXIS = 77;
    public final static int STOCK_HI_LO_OPEN_CLOSE = 79;
    public final static int STOCK_HI_LO_OPEN_CLOSE_DUAL_AXIS = 80;
    public final static int STOCK_HI_LO_OPEN_CLOSE_BI_POLAR = 81;
    public final static int STOCK_HI_LO_VOLUME = 82;
    public final static int STOCK_HI_LO_OPEN_CLOSE_VOLUME = 83;
    public final static int CANDLE_STOCK_HI_LO_OPEN_CLOSE_VOLUME = 84;

    public final static int VERTICAL_HISTOGRAM = 85;
    public final static int HORIZONTAL_HISTOGRAM = 86;

    public final static int SPECTRAL_MAP = 87;

    public final static int BUBBLE_CHART = 89;
    public final static int BUBBLE_CHART_LABELS = 90;
    public final static int BUBBLE_CHART_DUAL_AXIS = 91;
    public final static int BUBBLE_CHART_LABELS_DUAL_AXIS = 92;


    /**
    * data source for the chart
    */
    protected MappedChartDataSource  _chartDataSource = null;

    protected ControlSupport   _controlSupport = new ControlSupport(this);

    protected int _chartOrder = ROW;

    /**
    * Constructor
    */
    public ChartControl()
    {
        super();
        setGraphSeriesOrder(ROW);
    }

    /**
    * Specify data source for row labels. The dataItemName
    * can either represent a column in a table or a rowset.
    *
    * If the dataitem name represents a column then the column
    * values will be used as labels.
    *
    * If the dataitem name represents a rowset then column names
    * of the rowset will be used as labels.
    *
    * @see setRowLabelDataSource()
    * @see setRowLabel()
    * @param dataitemName of the column values or the rowset
    */
    public void setRowLabelDataItemName(String dataItemName)
    {
        _chartDataSource.setRowLabelDataItemName(dataItemName);
    }

    /**
    *  data item name for the row labels, if used
    */
    public String getRowLabelDataItemName()
    {
        return  _chartDataSource.getRowLabelDataItemName();
    }

    /**
    * Specify the row label by implementing the ChartLabelDataSource
    * interface
    *
    * @param labelDataSource an object implementing the ChartLabelDataSource
    *        interface
    * @see setRowLabelDataItemName()
    * @see setRowLabel()
    */
    public void setRowLabelDataSource(ChartLabelDataSource labelDataSource)
    {
        _chartDataSource.setRowLabelDataSource(labelDataSource);
    }

    /**
    *  data item name for the row labels, if used
    */
    public ChartLabelDataSource getRowLabelDataSource()
    {
        return  _chartDataSource.getRowLabelDataSource();
    }

    /**
    * Specify the row labels through an array of objects
    *
    * @param labels
    * @see setRowLabelDataItemName()
    * @see setRowLabelDataSource()
    */
    public void setRowLabel(Object[]  labels)
    {
        _chartDataSource.setRowLabel(labels);
    }

    /**
    *  data item name for the row labels, if used
    *  @return an object implementing ChartDataSource interface
    */
    public Object[] getRowLabel()
    {
        return  _chartDataSource.getRowLabel();
    }


    /**
    * Specify data source for column labels. The dataItemName
    * can either represent a column in a table or a rowset.
    *
    * If the dataitem name represents a column then the column
    * values will be used as labels.
    *
    * If the dataitem name represents a rowset then column names
    * of the rowset will be used as labels.
    *
    * @see setColumnLabelDataSource()
    * @see setColumnLabel()
    *
    * @param dataitemName of the column values or the rowset
    */
    public void setColumnLabelDataItemName(String dataItemName)
    {
        _chartDataSource.setColumnLabelDataItemName(dataItemName);
    }

    /**
    *  data item name for the row labels, if used
    *  @return data item name used for the column labels
    */
    public String getColumnLabelDataItemName()
    {
        return _chartDataSource.getColumnLabelDataItemName();
    }


    /**
    * Specify the column label by implementing the ChartLabelDataSource
    * interface
    *
    * @param labelDataSource an object implementing the ChartLabelDataSource
    *        interface
    * @see setColumnLabelDataItemName()
    * @see setColumnLabel()
    */
    public void setColumnLabelDataSource(ChartLabelDataSource labelDataSource)
    {
        _chartDataSource.setColumnLabelDataSource(labelDataSource);
    }

    /**
    *  data item name for the row labels, if used
    */
    public ChartLabelDataSource getColumnLabelDataSource()
    {
        return  _chartDataSource.getColumnLabelDataSource();
    }

    /**
    * Specify the column labels through an array of objects
    *
    * @param labels
    * @see setColumnLabelDataItemName()
    * @see setColumnLabelDataSource()
    */
    public void setColumnLabel(Object[]  labels)
    {
        _chartDataSource.setColumnLabel(labels);
    }

    /**
    *  data item name for the row labels, if used
    */
    public Object[] getColumnLabel()
    {
        return  _chartDataSource.getColumnLabel();
    }

    /**
    * Specify if the data to be drawn should be in row major order
    * or column major order
    */
    public void setGraphSeriesOrder(int nuOrder)
    {
       _chartOrder = nuOrder;
       MappedChartDataSource dataSource = _chartDataSource;
       if ( nuOrder == ROW )
          _chartDataSource = new RowOrderChartDataSource(this);

       else
          _chartDataSource = new ColOrderChartDataSource(this);

       if ( dataSource instanceof LabelAwareChartDataSource)
       {
           LabelAwareChartDataSource labelDataSource =
                                    (LabelAwareChartDataSource) dataSource;
          //_chartDataSource.setDataItemName(labelDataSource.getDataItemName());
          _chartDataSource.setColumnLabelDataItemName(
                               labelDataSource.getColumnLabelDataItemName());
          if ( labelDataSource.getUseFirstColumnAsRowLabel() == false)
             _chartDataSource.setRowLabelDataItemName(
                               labelDataSource.getRowLabelDataItemName());
       }
    }

    public int getGraphSeriesOrder()
    {
       return _chartOrder;
    }

    // implement Control interface

    public String getInfoBusName()
    {
        return _controlSupport.getInfoBusName();
    }

    public void setInfoBusName(String infoBusName)
    {
        _controlSupport.setInfoBusName(infoBusName);
    }

    public String getDataItemName()
    {
        return _controlSupport.getDataItemName();
    }

    public void setDataItemName(String dataItemName)
    {
        _controlSupport.setDataItemName(dataItemName);
        String colDataItemName = _chartDataSource.getColumnLabelDataItemName();
        if (colDataItemName.equals(""))
            _chartDataSource.setColumnLabelDataItemName(dataItemName);

    }

    public Object getDataItem()
    {
        return _controlSupport.getDataItem();
    }

    public void dataItemChanged(Object oldDataItem, Object newDataItem)
    {
       _chartDataSource.dataItemChanged(oldDataItem, newDataItem);
       setDataFromDataGrid(_chartDataSource);
    }

    public Component getComponent()
    {
        return this;
    }

    public boolean isFocusValidated()
    {
        return _controlSupport.isFocusValidated();
    }

    public void setFocusValidated(boolean focusValidated)
    {
        _controlSupport.setFocusValidated(focusValidated);
    }

    public void addNavigatedListener(NavigatedListener listener)
    {
       _controlSupport.addNavigatedListener(listener);
    }

    public void removeNavigatedListener(NavigatedListener listener)
    {
       _controlSupport.removeNavigatedListener(listener);
    }

    public void processNavigatedEvent(NavigatedEvent event)
    {
       _controlSupport.processNavigatedEvent(event);
    }

    public void addNavigatingListener(NavigatingListener listener)
    {
        _controlSupport.addNavigatingListener(listener);
    }

    public void removeNavigatingListener(NavigatingListener listener)
    {
        _controlSupport.removeNavigatingListener(listener);
    }

    public void processNavigatingEvent(NavigatingEvent event)
           throws oracle.dacf.control.NavigatingException
    {
        _controlSupport.processNavigatingEvent(event);
    }

    public void dataItemValueChanged(DataItemValueChangedEvent event)
    {
    }

    public void dataItemAdded(DataItemAddedEvent event)
    {
    }

    public void dataItemDeleted(DataItemDeletedEvent event)
    {
    }

    public void dataItemRevoked(DataItemRevokedEvent event)
    {
    }

    public void rowsetCursorMoved(RowsetCursorMovedEvent event)
    {
    }
}



