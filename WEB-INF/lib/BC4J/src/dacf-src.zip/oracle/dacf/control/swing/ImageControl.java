/*
 * @(#)ImageControl.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.dacf.control.swing;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import javax.infobus.DataItem;
import javax.infobus.DataItemAddedEvent;
import javax.infobus.DataItemDeletedEvent;
import javax.infobus.DataItemRevokedEvent;
import javax.infobus.DataItemValueChangedEvent;
import javax.infobus.ImmediateAccess;
import javax.infobus.InvalidDataException;
import javax.infobus.RowsetCursorMovedEvent;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.SwingUtilities;
import javax.swing.filechooser.FileFilter;
import oracle.dacf.control.Control;
import oracle.dacf.control.ControlEnabledListener;
import oracle.dacf.control.ControlSupport;
import oracle.dacf.control.InfoBusManager;
import oracle.dacf.control.InfoBusManagerListener;
import oracle.dacf.control.InfoBusManagerReleaseEvent;
import oracle.dacf.control.NavigatedEvent;
import oracle.dacf.control.NavigatedListener;
import oracle.dacf.control.NavigatingEvent;
import oracle.dacf.control.NavigatingException;
import oracle.dacf.control.NavigatingListener;
import oracle.dacf.control.NavigationManager;
import oracle.dacf.dataset.DataItemProperties;
import oracle.dacf.util.DesignTime;

/**
 *  Data aware ImageControl. ImageControl can be bound to
 *  <TT>ImmediateAccess</TT> items. The ImageControl treats the data stream as
 *  image (JPEG or GIF) and displays it.
 *
 *  @version PUBLIC
 */
public class ImageControl
    extends JPanel
    implements Control, ControlEnabledListener, ActionListener,
               InfoBusManagerListener, FocusListener
{
    protected  ControlSupport _controlSupport;

    protected BorderLayout _mainPanelLayout = new BorderLayout();
    protected GridBagLayout _buttonPanelLayout = new GridBagLayout();

    protected JScrollPane _imageAggregate;
    protected JLabel  _imageDisplay = new JLabel();
    protected JPanel  _buttonPanel  = new JPanel();

    protected Dimension _buttonPreferredSize = new Dimension(80,25);

    protected JButton _newButton =
        new JButton( Res.getString(Res.IMAGE_CONTROL_CHANGE));
    protected JButton _clearButton =
        new JButton( Res.getString(Res.IMAGE_CONTROL_CLEAR));

    protected JFileChooser _fileChooser = new JFileChooser();
    private boolean _readOnly = false;
    private boolean _showUpdateButtons=true;


    /**
    * Constructs a ImageControl.
    */
    public ImageControl()
    {
        _controlSupport = new ControlSupport(this);
        InfoBusManager.getInstance().addInfoBusManagerListener(this);
        _controlSupport.addControlEnabledListener(this);
        _controlSupport.setFocusValidated(true);

        if (DesignTime.inDesignTime())
            return;

        setLayout(_mainPanelLayout);
        setBorder(BorderFactory.createEtchedBorder());

        _imageAggregate = new JScrollPane(_imageDisplay);
        _imageAggregate.setPreferredSize(_getDefaultPreferredSize());
        add(_imageAggregate, BorderLayout.CENTER);
        _buttonPanel = _createButtonPanel();
        add(_buttonPanel, BorderLayout.EAST);
        _fileChooser.setFileFilter( new ImageFileFilter());
        _imageDisplay.addFocusListener(this);
    }



    /**
    * get the panel used to display buttons
    */
    public JPanel getButtonsPanel()
    {
        return _buttonPanel;
    }

    /**
    * get the label control used to display the image
    */
    public JLabel getLabel()
    {
        return _imageDisplay;
    }

    /**
    *  Scroll pane used to display the image
    */
    public JScrollPane getScrollPane()
    {
        return _imageAggregate;
    }

    public void setShowUpdateButtons(boolean bShowButtons)
    {
        _showUpdateButtons = bShowButtons;
        if (_showUpdateButtons)
           add( _buttonPanel, BorderLayout.EAST );
        else
           remove(_buttonPanel);

    }

    public boolean getShowUpdateButtons()
    {
        return _showUpdateButtons;
    }

    public void setReadOnly(boolean readOnly)
    {
        _readOnly = readOnly;
        _enableButtons(!_readOnly);
    }

    public boolean getReadOnly()
    {
        return _readOnly;
    }

    //FocusListener implementation
    /**
    * This method is an implementaion side effect
    */
    public void focusLost(FocusEvent event)
    {
    }

    /**
    * This method is an implementaion side effect
    */
    public void focusGained(FocusEvent event)
    {
        if (isFocusValidated())
        {
            NavigationManager nm = NavigationManager.getNavigationManager();
            nm.validateFocusChange(this);
        }
    }

    // ControlEnabledListener interface
    public void enabledChanged(boolean b)
    {
        super.setEnabled(b);
    }

    // InfoBusManagerListener interface implementation
    public void releaseResources(InfoBusManagerReleaseEvent e)
    {
        if (e.appliesTo(this))
        {
            InfoBusManager.getInstance().removeInfoBusManagerListener(this);
            _imageDisplay.removeFocusListener(this);
            _newButton.removeActionListener(this);
            _clearButton.removeActionListener(this);
            _newButton.removeFocusListener(this);
            _clearButton.removeFocusListener(this);
            _controlSupport.removeControlEnabledListener(this);
            _controlSupport = null;
        }
    }

    // Control Interface

    /**
    ** An override of java.awt.Component.setEnabled. <P>
    **
    ** @param b boolean flag indicating whether the control is enabled
    */
    public void setEnabled(boolean b)
    {
        super.setEnabled(b);
        if (_controlSupport != null)
        {
            _controlSupport.setEnabled(b);
        }
        setReadOnly(!b);

    } // setEnabled

    /**
    * Returns the name of the InfoBus this control is connected to. <P>
    * @return  The name of the InfoBus this control is connected to.
    * @see Control#getInfoBusName
    */
    public final String getInfoBusName()
    {
        return(_controlSupport == null ?
               null : _controlSupport.getInfoBusName());
    }


    /**
    * Sets the name of the InfoBus this control is connected to. <P>
    * By default, the control is connected to the default InfoBus,
    * named <TT>Control.DEFAULT_INFOBUS_NAME</TT>. <P>
    * If the named InfoBus does not exist, it is created automatically. <P>
    * If the control is already connected to an InfoBus, it is disconnected
    * first. <P>
    * @param infoBusName   The name of the InfoBus to connect to.
    * @see Control#DEFAULT_INFOBUS_NAME
    * @see Control#setInfoBusName
    */
    public final void setInfoBusName(String infoBusName)
    {
        if (_controlSupport != null)
        {
            _controlSupport.setInfoBusName(infoBusName);
        }
    }


    /**
    * Returns the name of the InfoBus DataItem this control is bound to. <P>
    * @return  The name of the InfoBus DataItem this control is bound to,
    *          or <TT>null</TT> if the control is unbound.
    * @see #getDataItem
    * @see Control#getDataItemName
    */
    public final String getDataItemName()
    {
        return(_controlSupport == null ?
               null : _controlSupport.getDataItemName());
    }


    /**
    * Sets the name of the InfoBus DataItem this control is bound to. <P>
    * The DataItem with the given name is searched for on the InfoBus, and
    * if found, is bound to this control. <P>
    * If the control is already bound to a DataItem, it is unbound first. <P>
    * @param dataItemName  The name of the DataItem to bind to.
    * @see #getDataItem
    * @see Control#setDataItemName
    */
    public final void setDataItemName(String dataItemName)
    {
        if (_controlSupport != null)
        {
            _controlSupport.setDataItemName(dataItemName);
        }
    }


    /**
    * Returns the InfoBus DataItem this control is bound to. <P>
    * @return  The InfoBus DataItem this control is bound to, or
    *          <TT>null</TT> if the control is unbound.
    * @see Control#getDataItem
    */
    public final Object getDataItem()
    {
        return(_controlSupport == null ?
               null : _controlSupport.getDataItem());
    }

    /**
    * Notifies the control that the bound InfoBus DataItem has changed. <P>
    * @param oldDataItem   The formerly bound DataItem (can be <TT>null</TT>).
    * @param newDataItem   The newly bound DataItem (can be <TT>null</TT>).
    * @see Control#dataItemChanged
    */
    public final void dataItemChanged(Object oldDataItem, Object newDataItem)
    {
        // Don't care
    }

    /**
    * Returns the AWT component associated with this control. <P>
    * @return  The AWT component for this control.
    * @see Control#getComponent
    */
    public final Component getComponent()
    {
        return(this);
    }

    /**
    * Determines whether focus into this control causes validation to
    * occur. <P>
    * @return  <TT>true</TT> if focus into this control causes validation to
    *          occur, <TT>false</TT> otherwise.
    * @see Control#isFocusValidated
    */
    public final boolean isFocusValidated()
    {
        return(_controlSupport == null ?
               false : _controlSupport.isFocusValidated());
    }

    /**
    *  This method is a no-op that is it has no effect
    */
    public final void setFocusValidated(boolean focusValidated)
    {
        if (_controlSupport != null)
        {
            _controlSupport.setFocusValidated(focusValidated);
        }
    }

    /**
    *  This method is a no-op that is it has no effect
    */
    public final void addNavigatedListener(NavigatedListener listener)
    {
        if (_controlSupport != null)
        {
            _controlSupport.addNavigatedListener(listener);
        }
    }

    /**
    *  This method is a no-op that is it has no effect
    */
    public final void removeNavigatedListener(NavigatedListener listener)
    {
        if (_controlSupport != null)
        {
            _controlSupport.removeNavigatedListener(listener);
        }
    }

    /**
    *  This method is a no-op that is it has no effect
    */
    public final void processNavigatedEvent(NavigatedEvent event)
    {
        if (_controlSupport != null)
        {
            _controlSupport.processNavigatedEvent(event);
        }
    }

    /**
    *  This method is a no-op that is it has no effect
    */
    public final void addNavigatingListener(NavigatingListener listener)
    {
        if (_controlSupport != null)
        {
            _controlSupport.addNavigatingListener(listener);
        }
    }

    /**
    *  This method is a no-op in that it has no effect
    */
    public final void removeNavigatingListener(NavigatingListener listener)
    {
        if (_controlSupport != null)
        {
            _controlSupport.removeNavigatingListener(listener);
        }
    }


    public final void processNavigatingEvent(NavigatingEvent event)
        throws NavigatingException
    {
        if (_controlSupport != null)
        {
            _controlSupport.processNavigatingEvent(event);
        }
    }

    // DataItemChangeListener Interface

    /**
    * Indicates a changed value in the bound data item. <P>
    * A reference to the data item that changed can be obtained from the
    * event. <P>
    * @param event Contains change information.
    * @see javax.infobus.DataItemChangeListener#dataItemValueChanged
    */
    public final void dataItemValueChanged(DataItemValueChangedEvent event)
    {
        _updateImageLater(event.getChangedItem());
    }

    /**
    * Indicates that a new item was added to the bound aggregate data item
    * (e.g. <TT>ArrayAccess</TT>, a JDK Collection, etc). <P>
    * A reference to the data item that was added, and a reference to the one
    * that gained it, can be obtained from the event. <P>
    * Has no effect on the ImageControl.<P>
    *
    * @param event Contains details of the addition.
    * @see javax.infobus.DataItemChangeListener#dataItemAdded
    */
    public final void dataItemAdded(DataItemAddedEvent event)
    {
        // Not applicable
    }

    /**
    * Indicates that an item was deleted from the bound aggregate data item
    * (e. g. <TT>ArrayAccess</TT>, a JDK Collection, etc). <P>
    * A reference to the data item that was deleted, and a reference to the
    * one that lost it, can be obtained from the event. <P>
    * Has no effect on the ImageControl.<P>
    *
    * @param event Contains details of the deletion.
    * @see javax.infobus.DataItemChangeListener#dataItemDeleted
    */
    public final void dataItemDeleted(DataItemDeletedEvent event)
    {
        // Not applicable
    }

    /**
    * Indicates that the bound data item (and its sub-items, if any) has been
    * revoked, and is temporarily unavailable. <P>
    * A reference to the data item that was revoked can be obtained from
    * the event. <P>
    * @param event Contains details of the revoked data.
    * @see javax.infobus.DataItemChangeListener#dataItemRevoked
    */
    public final void dataItemRevoked(DataItemRevokedEvent event)
    {
        _updateImageLater(null);
    }

    /**
    * Indicates that the cursor for the bound <TT>RowsetAccess</TT> data item
    * has changed rows. <P>
    * A reference to the rowset data item can be obtained from the event. <P>
    * @param event Contains details of the cursor move.
    * @see javax.infobus.DataItemChangeListener#rowsetCursorMoved
    */
    public final void rowsetCursorMoved(RowsetCursorMovedEvent event)
    {
        // Not applicable
    }

    // ActionListener
    public void actionPerformed(ActionEvent e)
    {
        Object src = e.getSource();
        if (src == _clearButton)
        {
            _setImage(null);
        }
        else
        {
            int rc = _fileChooser.showOpenDialog(this);
            if (rc  == JFileChooser.APPROVE_OPTION)
            {
                File file = _fileChooser.getSelectedFile();
                byte[] imageData = _readImageData(file.getAbsolutePath());
                _setImage(imageData);
            }
        }
    }

    // protected methods
    /**
    *  get the preferred size for the image scroll pane
    */
    protected Dimension  _getDefaultPreferredSize()
    {
        return new Dimension(400,200);
    }

    // Private Methods
    /**
    * update the image based on the new value of the dataitem
    *
    * @param dataItem to which the control is bound to
    */
    private void _updateImageLater(final Object dataItem)
    {
        SwingUtilities.invokeLater(
                                   new Runnable()
                                   {
                                       public void run()
                                           {
                                               _updateImage(dataItem);
                                           }
                                   }
                                   );
    }

    /**
    * update the image now
    *
    * @param dataItem to which the control is bound
    */
    private void _updateImage(Object dataItem)
    {
        if (dataItem != null && dataItem instanceof ImmediateAccess)
        {
            // enable/disable buttons
            if ( dataItem instanceof DataItem)
            {
                Boolean updateable = (Boolean)((DataItem)dataItem).
                           getProperty(DataItemProperties.UPDATEABLE);
                if (updateable != null)
                {
                   // only enable the control if it is updateable
                   this.setReadOnly(!updateable.booleanValue());
                }
            }

            Object o = ((ImmediateAccess)dataItem).getValueAsObject();
            if ( o instanceof byte[])
            {
                _imageDisplay.setIcon( new ImageIcon( (byte[]) o));
                return;
            }
        }
        _imageDisplay.setIcon(null);
    }

    protected JPanel _createButtonPanel()
    {
        JPanel panel = new JPanel();
        panel.setLayout(_buttonPanelLayout);

        GridBagConstraints gc = new GridBagConstraints();
        gc.anchor = GridBagConstraints.NORTH;

        gc.gridx = gc.gridy = 0;
        panel.add(_newButton,gc);
        gc.gridx=0; gc.gridy=1;
        panel.add(_clearButton,gc);
        _newButton.setPreferredSize(_buttonPreferredSize);
        _clearButton.setPreferredSize(_buttonPreferredSize);

        _newButton.addActionListener(this);
        _clearButton.addActionListener(this);
        _newButton.addFocusListener(this);
        _clearButton.addFocusListener(this);

        return(panel);
    }

    protected void _enableButtons(boolean bEnable)
    {
        _newButton.setEnabled(bEnable);
        _clearButton.setEnabled(bEnable);
    }

    private byte[] _readImageData(String filename)
    {
        try
        {
            FileInputStream fi =  new FileInputStream(filename);
            BufferedInputStream bi = new  BufferedInputStream(fi);

            byte[] imageData = new byte[bi.available()];
            bi.read(imageData, 0, imageData.length);
            return imageData;
        }
        catch (Exception e)
        {
            return null;
        }

    }

    private void _setImage(byte[] data)
    {
        Object di = getDataItem();
        if ((di != null) && ( di instanceof ImmediateAccess))
        {
            ImmediateAccess i = (ImmediateAccess)di;

            try
            {
                i.setValue(data);
            }
            catch(InvalidDataException exc)
            {
                // exc.printStackTrace();
            }
        }
    }
}

class ImageFileFilter
    extends FileFilter
{
    private String _imageFileExt =
        Res.getString(Res.IMAGE_CONTROL_IMAGE_FILE_EXT);

    public ImageFileFilter()
    {
    }

    public boolean accept(File f)
    {
        if (f.isDirectory() ||
            _isImageFile(_getExtension(f)))
            return true;

        return false;
    }

    public String getDescription()
    {
        return _imageFileExt;
    }

    private String _getExtension(File f)
    {
        String ext = null;
        String s = f.getName();
        int i = s.lastIndexOf('.');

        if (i > 0 && i < s.length() - 1)
            ext = s.substring(i+1).toLowerCase();

        return ext;
    }

    private boolean _isImageFile(String ext)
    {

        if (ext != null)
        {
            if (ext.equals("gif") || ext.equals("jpeg"))
                return true;
        }
        return false;
    }
}

