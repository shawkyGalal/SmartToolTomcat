/*
 * @(#)StatusBarControl.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.dacf.control.swing;

import java.awt.Color;
import java.awt.Component;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Frame;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.LayoutManager;
import java.net.URL;
import java.util.Locale;
import javax.infobus.DataItem;
import javax.infobus.DataItemAddedEvent;
import javax.infobus.DataItemDeletedEvent;
import javax.infobus.DataItemRevokedEvent;
import javax.infobus.DataItemValueChangedEvent;
import javax.infobus.ImmediateAccess;
import javax.infobus.RowsetCursorMovedEvent;
import javax.swing.BorderFactory;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JProgressBar;
import javax.swing.SwingUtilities;
import javax.swing.border.Border;
import oracle.dacf.activity.ActivityEvent;
import oracle.dacf.activity.ActivityListener;
import oracle.dacf.activity.ActivityMonitor;
import oracle.dacf.control.Control;
import oracle.dacf.control.ControlSupport;
import oracle.dacf.control.ControlSupportHC;
import oracle.dacf.control.CurrencyChangedEvent;
import oracle.dacf.control.CurrencyListener;
import oracle.dacf.control.InfoBusManager;
import oracle.dacf.control.InfoBusManagerListener;
import oracle.dacf.control.InfoBusManagerReleaseEvent;
import oracle.dacf.control.NavigatedEvent;
import oracle.dacf.control.NavigatedListener;
import oracle.dacf.control.NavigatingEvent;
import oracle.dacf.control.NavigatingException;
import oracle.dacf.control.NavigatingListener;
import oracle.dacf.control.NavigationManager;
import oracle.dacf.dataset.AttributeInfo;
import oracle.dacf.dataset.DacObject;
import oracle.dacf.dataset.DataItemProperties;
import oracle.dacf.dataset.InfoObject;
import oracle.dacf.dataset.RowSetInfo;
import oracle.dacf.formatter.DefaultFormatManager;
import oracle.dacf.formatter.FormatManager;
import oracle.dacf.formatter.Formatter;
import oracle.dacf.formatter.UnknownFormatterException;

// imports
/**
 **    StatusBar<P>
 **
 **    The StatusBar Control can display the status of a rowset.<p>
 **
 **    When a dataItemName is specified, it tracks the status
 **    of the rowset it is bound to, otherwise, it tracks the
 **    status of the DAC control (Rowset) which currently has
 **    the focus.<p>
 **
 **    The StatusBar has six indicators:
 **    <ul>
 **    <li>Progress bar: current row's percent "through" the result set
 **    <li>Current row number: row number of the current row
 **    <li>Row count: number of rows in the result ser
 **    <li>Fetched count: number of rows fetched from the database
 **    <li>Modified flag: true if one or more rows has been changed
 **    <li>Message area: displays the name of the current result set
 **    <li>Working icon: a graphic that is display when a long running activity
 **                      begins
 **    </ul>
 **
 **    Each of these indicators can be hidden or shown by using the appropriate
 **    method call.  The format of text displayed in each indicator can be
 **    controlled setting the value of the appropriate format string and
 **    formatter.<p>
 **
 **    The default display state for each indicator is:
 **    <ul>
 **    <li>Progress bar: true
 **    <li>Current row number: true
 **    <li>Row count: true
 **    <li>Fetched count: false
 **    <li>Modified flag: true
 **    <li>Message area: true
 **    <li>Working icon: true
 **    </ul>
 **
 **    @version PUBLIC
 */
public class StatusBarControl
    extends JPanel
    implements Control, CurrencyListener, ActivityListener,
               InfoBusManagerListener
{
    public static final String WORKING_ICON_1 =
        "/oracle/dacf/images/working1.gif";
    public static final String WORKING_ICON_2 = 
        "/oracle/dacf/images/working2.gif";
    public static final String WORKING_ICON_3 = 
        "/oracle/dacf/images/working3.gif";
    public static final String WORKING_ICON_4 = 
        "/oracle/dacf/images/working4.gif";
    public static final String DEFAULT_WORKING_ICON = WORKING_ICON_1;
    private static final int CURRENT_ROW_INDEX = 0;
    private static final int ROW_COUNT_INDEX = 1;
    private static final int HIGH_WATER_INDEX = 2;
    private static final int MODIFIED_FLAG_INDEX = 3;
    private static final int PERCENT_DONE_INDEX = 4;
    private static final int MESSAGE_AREA_INDEX = 5;
    private static final int DEFAULT_PROGRESS_HEIGHT = 21; // pixels
    private static final int DEFAULT_PROGRESS_WIDTH = 100; // pixels
    private static final String BLANK = " ";

    private Color _foreGround = null;
    private Color _backGround = null;
    private Font _font = null;
    private Dimension _progressBarSize =
        new Dimension(DEFAULT_PROGRESS_WIDTH, DEFAULT_PROGRESS_HEIGHT);

    private boolean _hasMessageArea = true;
    private boolean _hasCurrentRow = true;
    private boolean _hasHighWaterMark = false;
    private boolean _hasRowCount = true;
    private boolean _hasModifiedFlag = true;
    private boolean _hasPercentDone = true;
    private boolean _hasWorkingIcon = true;
    private boolean _messageAreaShown = false;
    private boolean _currentRowShown = false;
    private boolean _highWaterMarkShown = false;
    private boolean _rowCountShown = false;
    private boolean _modifiedFlagShown = false;
    private boolean _percentDoneShown = false;
    private String _workingIconFileName;
    private Icon _workingIcon;
    private volatile int _activityCount = 0;
    private ControlSupport _controlSupport;
    private StatusBarLabelControl _currentRow;
    private StatusBarLabelControl _highWaterMark;
    private StatusBarLabelControl _rowCount;
    private StatusBarLabelControl _modifiedFlag;
    private StatusBarLabelControl _messageArea;
    private StatusBarProgressControl _percentDone;
    private String _currentRowFormatString;
    private String _highWaterMarkFormatString;
    private String _rowCountFormatString;
    private String _modifiedFlagFormatString;
    private String _messageAreaFormatString;
    private String _percentDoneFormatString;
    private Formatter _currentRowFormatter;
    private Formatter _highWaterMarkFormatter;
    private Formatter _rowCountFormatter;
    private Formatter _modifiedFlagFormatter;
    private Formatter _messageAreaFormatter;
    private Formatter _percentDoneFormatter;
    private Frame _myFrame;
    private String _activeRowset;
    private Border _labelBorder;
    private Border _barBorder;
    private GridBagLayout _barLayout;
    private int _preferredHeight = DEFAULT_PROGRESS_HEIGHT;

    private static final boolean _DEBUG = true;

    /**
    ** Create a new StatusBarControl. <P>
    **
    **
    */
    public StatusBarControl()
    {
        NavigationManager navmgr = NavigationManager.getNavigationManager();

        _controlSupport = new ControlSupport(this);
        InfoBusManager.getInstance().addInfoBusManagerListener(this);
        _barBorder = BorderFactory.createEmptyBorder();
        _labelBorder = BorderFactory.createLoweredBevelBorder();
        FormatManager fm =
            DefaultFormatManager.getInstance(Locale.getDefault());
        _barLayout = new GridBagLayout();
        _myFrame = null;
        navmgr.addCurrencyListener(this);
        setBorder(_barBorder);
        super.setLayout(_barLayout);
        _currentRowFormatString = Res.getString(Res.SBAR_CURRENT_ROW_FORMAT);
        _highWaterMarkFormatString =
            Res.getString(Res.SBAR_HIGH_WATER_MARK_FORMAT);
        _rowCountFormatString = Res.getString(Res.SBAR_ROW_COUNT_FORMAT);
        _modifiedFlagFormatString = Res.getString(Res.SBAR_MODIFIED_LABEL);
        _messageAreaFormatString = null;
        try
        {
            _currentRowFormatter = fm.getFormatter("DefaultNumberFormatter");
        }
        catch(UnknownFormatterException e)
        {
            ;
        }
        _highWaterMarkFormatter = _currentRowFormatter;
        _rowCountFormatter = _currentRowFormatter;
        _modifiedFlagFormatter = null;
        _messageAreaFormatter = null;
        _updateIndicators();
        JLabel t = new JLabel("test");
        if (t != null)
        {
            super.setForeground(t.getForeground());
            super.setBackground(t.getBackground());
        }
        setWorkingIconFileName(DEFAULT_WORKING_ICON);
        ActivityMonitor.addActivityListener(this);
        revalidate();
    } // StatusBar

    /**
    **  Returns the LayoutManger used by the StatusBarControl.<P>
    **
    **  The StatusBarControl only uses a GridBag layout manager defined in
    **  its constructor.
    **
    **  @return the LayoutManger used by the StatusBarControl.
    */
    public LayoutManager getLayout()
    {
        return(_barLayout);
    }

    /**
    **  An override of the setLayout() inherited from java.awt.Container.<P
    **
    **  The StatusBarControl uses a GridBag layout manager.  Any call to this
    **  method with a layout manager will be ignored.  The StatusBarControl
    **  only uses a GridBag layout manager defined in its constructor.
    **
    **  @param l a LayoutManger that will be ignored by the StatusBarControl.
    */
    public void setLayout(LayoutManager l)
    {
    }

    /**
    ** Sets the progress indicator's size. <P>
    **
    ** @param progressBarSize the desired size of the progress indicator
    ** @see #getProgressBarSize()
    */
    public void setProgressBarSize(Dimension progressBarSize)
    {
        _progressBarSize = progressBarSize;
        if (_percentDone != null)
        {
            _progressBarSize.height = _percentDone.getMinimumSize().height;
            _percentDone.setPreferredSize(_progressBarSize);
            _percentDone.setMinimumSize(_progressBarSize);
            _percentDone.setMaximumSize(_progressBarSize);
        }
    } // setProgressBarSize

    /**
    ** Returns the progress indicator's size. <P>
    **
    ** @return the progress indicator's size.
    ** @see #setProgressBarSize(Dimension progressBarSize)
    */
    public Dimension getProgressBarSize()
    {
        return(_progressBarSize);
    } // getProgressBarSize

    /**
    ** Sets the border sytle for the status bar's indicators.<P>
    **
    ** @param indicatorBorderStyle the border sytle for the status bar's
    **                             indicators
    ** @see #getIndicatorBorderStyle()
    */
    public void setIndicatorBorderStyle(Border indicatorBorderStyle)
    {
        _labelBorder = indicatorBorderStyle;
        if (_currentRow != null)
        {
            _currentRow.setBorder(_labelBorder);
        }
        if (_highWaterMark != null)
        {
            _highWaterMark.setBorder(_labelBorder);
        }
        if (_rowCount != null)
        {
            _rowCount.setBorder(_labelBorder);
        }
        if (_modifiedFlag != null)
        {
            _modifiedFlag.setBorder(_labelBorder);
        }
        if (_messageArea != null)
        {
            _messageArea.setBorder(_labelBorder);
        }
        if (_percentDone != null)
        {
            _percentDone.setBorder(_labelBorder);
        }
    } // setIndicatorBorderStyle

    /**
    ** Returns the border sytle used by the status bar's indicators.<P>
    **
    ** @return the border sytle used by the status bar's indicators.
    ** @see #setIndicatorBorderStyle(Border indicatorBorderStyle)
    */
    public Border getIndicatorBorderStyle()
    {
        return(_labelBorder);
    } // getIndicatorBorderStyle

    /**
    ** StatusBarControl override. <P>
    **
    ** Sets the font for the status bar and all contained conponents.
    **
    ** @param nuFont the font to use for the status bar and all contained
    **               components
    ** @see #getFont()
    */
    public void setFont(Font nuFont)
    {
        _font = nuFont;
        super.setFont(_font);

        if (_currentRow != null)
        {
            _currentRow.setFont(_font);
        }
        if (_highWaterMark != null)
        {
            _highWaterMark.setFont(_font);
        }
        if (_rowCount != null)
        {
            _rowCount.setFont(_font);
        }
        if (_modifiedFlag != null)
        {
            _modifiedFlag.setFont(_font);
        }
        if (_messageArea != null)
        {
            _messageArea.setFont(_font);
        }
    } // setFont

    /**
    ** StatusBarControl override. <P>
    **
    ** Returns the font for the status bar and all contained conponents.
    **
    ** @return the font used for the status bar and all contained components
    ** @see #setFont(Font nuFont)
    */
    public Font getFont()
    {
        return(_font);
    } // getFont

    /**
    ** StatusBarControl override. <P>
    **
    ** @param c The foreground color for the StatusBar
    */
    public void setForeground(Color c)
    {
        _foreGround = c;
        super.setForeground(c);
        if (_currentRow != null)
        {
            _currentRow.setForeground(c);
        }
        if (_highWaterMark != null)
        {
            _highWaterMark.setForeground(c);
        }
        if (_rowCount != null)
        {
            _rowCount.setForeground(c);
        }
        if (_modifiedFlag != null)
        {
            _modifiedFlag.setForeground(c);
        }
        if (_messageArea != null)
        {
            _messageArea.setForeground(c);
        }
    } // setForeground

    /**
    ** StatusBarControl override. <P>
    **
    ** @param c The background color for the StatusBar
    */
    public void setBackground(Color c)
    {
        _backGround = c;
        super.setBackground(c);
        if (_currentRow != null)
        {
            _currentRow.setBackground(c);
        }
        if (_highWaterMark != null)
        {
            _highWaterMark.setBackground(c);
        }
        if (_rowCount != null)
        {
            _rowCount.setBackground(c);
        }
        if (_modifiedFlag != null)
        {
            _modifiedFlag.setBackground(c);
        }
        if (_messageArea != null)
        {
            _messageArea.setBackground(c);
        }
    } // setBackground

    /**
    ** StatusBarControl override. <P>
    **
    ** @return the maximum Dimensions of the StatusBar
    */
    public Dimension getMaximumSize()
    {
        return(getPreferredSize());
    } // getPreferredSize

    public void setMaximumSize(Dimension dim)
    {
        dim.height = _preferredHeight;
        super.setMaximumSize(dim);
    }

    /**
    ** StatusBarControl override. <P>
    **
    ** @return the minimum Dimensions of the StatusBar
    */
    public Dimension getMinimumSize()
    {
        return(getPreferredSize());
    } // getPreferredSize

    public void setMinimumSize(Dimension dim)
    {
        dim.height = _preferredHeight;
        super.setMinimumSize(dim);
    } // getPreferredSize

    /**
    ** StatusBarControl override. <P>
    **
    ** @return the preferred Dimensions of the StatusBar
    */
    public Dimension getPreferredSize()
    {
        return(new Dimension(getParent().getSize().width, _preferredHeight));
    } // getPreferredSize

    public void setPreferredSize(Dimension dim)
    {
        dim.height = _preferredHeight;
        super.setPreferredSize(dim);
    } // getPreferredSize
    
    /**
    ** Sets the formatter for formatting the CurrentRow status label. <P>
    **
    ** @param currentRowFormatter formatter for formatting the CurrentRow
    **                            status label
    ** @see #getCurrentRowFormatter()
    */
    public void setCurrentRowFormatter(Formatter currentRowFormatter)
    {
        _currentRowFormatter = currentRowFormatter;
        _updateIndicatorsLater();
    } // setCurrentRowFormatter

    /**
    ** Returns the formatter for formatting the CurrentRow status label. <P>
    **
    ** @return the formatter for formatting the CurrentRow status label.
    ** @see #setCurrentRowFormatter(Formatter currentRowFormatter)
    */
    public Formatter getCurrentRowFormatter()
    {
        return(_currentRowFormatter);
    } // getCurrentRowFormatter

    /**
    ** Sets the formatter for formatting the HighWaterMark status label. <P>
    **
    ** @param highWaterMarkFormatter formatter for formatting the HighWaterMark
    **                            status label
    ** @see #getHighWaterMarkFormatter()
    */
    public void setHighWaterMarkFormatter(Formatter highWaterMarkFormatter)
    {
        _highWaterMarkFormatter = highWaterMarkFormatter;
        _updateIndicatorsLater();
    } // setHighWaterMarkFormatter

    /**
    ** Returns the formatter for formatting the HighWaterMark status label. <P>
    **
    ** @return the formatter for formatting the HighWaterMark status label.
    ** @see #setHighWaterMarkFormatter(Formatter highWaterMarkFormatter)
    */
    public Formatter getHighWaterMarkFormatter()
    {
        return(_highWaterMarkFormatter);
    } // getHighWaterMarkFormatter

    /**
    ** Sets the formatter for formatting the RowCount status label. <P>
    **
    ** @param rowCountFormatter formatter for formatting the RowCount
    **                            status label
    ** @see #getRowCountFormatter()
    */
    public void setRowCountFormatter(Formatter rowCountFormatter)
    {
        _rowCountFormatter = rowCountFormatter;
        _updateIndicatorsLater();
    } // setRowCountFormatter

    /**
    ** Returns the formatter for formatting the RowCount status label. <P>
    **
    ** @return the formatter for formatting the RowCount status label.
    ** @see #setRowCountFormatter(Formatter RowCountFormatter)
    */
    public Formatter getRowCountFormatter()
    {
        return(_rowCountFormatter);
    } // getRowCountFormatter

    /**
    ** Sets the formatter for formatting the ModifiedFlag status label. <P>
    **
    ** @param modifiedFlagFormatter formatter for formatting the ModifiedFlag
    **                            status label
    ** @see #getModifiedFlagFormatter()
    */
    public void setModifiedFlagFormatter(Formatter modifiedFlagFormatter)
    {
        _modifiedFlagFormatter = modifiedFlagFormatter;
        _updateIndicatorsLater();
    } // setModifiedFlagFormatter

    /**
    ** Returns the formatter for formatting the ModifiedFlag status label. <P>
    **
    ** @return the formatter for formatting the ModifiedFlag status label.
    ** @see #setModifiedFlagFormatter(Formatter ModifiedFlagFormatter)
    */
    public Formatter getModifiedFlagFormatter()
    {
        return(_modifiedFlagFormatter);
    } // getModifiedFlagFormatter

    /**
    ** Sets the formatter for formatting the MessageArea status label. <P>
    **
    ** @param messageAreaFormatter formatter for formatting the MessageArea
    **                            status label
    ** @see #getMessageAreaFormatter()
    */
    public void setMessageAreaFormatter(Formatter messageAreaFormatter)
    {
        _messageAreaFormatter = messageAreaFormatter;
        _updateIndicatorsLater();
    } // setMessageAreaFormatter

    /**
    ** Returns the formatter for formatting the MessageArea status label. <P>
    **
    ** @return the formatter for formatting the MessageArea status label.
    ** @see #setMessageAreaFormatter(Formatter messageAreaFormatter)
    */
    public Formatter getMessageAreaFormatter()
    {
        return(_messageAreaFormatter);
    } // getMessageAreaFormatter

    /**
    ** Sets the formatter for formatting the PercentDone status label. <P>
    **
    ** @param percentDoneFormatter formatter for formatting the PercentDone
    **                            status label
    ** @see #getPercentDoneFormatter()
    */
    public void setPercentDoneFormatter(Formatter percentDoneFormatter)
    {
        _percentDoneFormatter = percentDoneFormatter;
        _updateIndicatorsLater();
    } // setPercentDoneFormatter

    /**
    ** Returns the formatter for formatting the PercentDone status label. <P>
    **
    ** @return the formatter for formatting the PercentDone status label.
    ** @see #setPercentDoneFormatter(Formatter percentDoneFormatter)
    */
    public Formatter getPercentDoneFormatter()
    {
        return(_percentDoneFormatter);
    } // getPercentDoneFormatter

    /**
    ** Sets the format string for formatting the CurrentRow status label. <P>
    **
    ** @param currentRowFormatString format string for formatting the
    **                               CurrentRow status label
    ** @see #getCurrentRowFormatString()
    */
    public void setCurrentRowFormatString(String currentRowFormatString)
    {
        _currentRowFormatString = currentRowFormatString;
        _updateIndicatorsLater();
    } // setCurrentRowFormatString

    /**
    ** Returns the format string for formatting the CurrentRow status label.<P>
    **
    ** @return the format string for formatting the CurrentRow status label.
    ** @see #setCurrentRowFormatString(String currentRowFormatString)
    */
    public String getCurrentRowFormatString()
    {
        return(_currentRowFormatString);
    } // getCurrentRowFormatString

    /**
    ** Sets the format string for formatting the HighWaterMark status label.<P>
    **
    ** @param highWaterMarkFormatString format string for formatting the
    **                                  HighWaterMark status label
    ** @see #getHighWaterMarkFormatString()
    */
    public void setHighWaterMarkFormatString(String highWaterMarkFormatString)
    {
        _highWaterMarkFormatString = highWaterMarkFormatString;
        _updateIndicatorsLater();
    } // setHighWaterMarkFormatString

    /**
    ** Returns the format string for formatting the HighWaterMark status label.
    **
    ** @return the format string for formatting the HighWaterMark status label.
    ** @see #setHighWaterMarkFormatString(String highWaterMarkFormatString)
    */
    public String getHighWaterMarkFormatString()
    {
        return(_highWaterMarkFormatString);
    } // getHighWaterMarkFormatString

    /**
    ** Sets the format string for formatting the RowCount status label. <P>
    **
    ** @param rowCountFormatString format string for formatting the RowCount
    **                             status label
    ** @see #getRowCountFormatString()
    */
    public void setRowCountFormatString(String rowCountFormatString)
    {
        _rowCountFormatString = rowCountFormatString;
        _updateIndicatorsLater();
    } // setRowCountFormatString

    /**
    ** Returns the format string for formatting the RowCount status label. <P>
    **
    ** @return the format string for formatting the RowCount status label.
    ** @see #setRowCountFormatString(String RowCountFormatString)
    */
    public String getRowCountFormatString()
    {
        return(_rowCountFormatString);
    } // getRowCountFormatString

    /**
    ** Sets the format string for formatting the ModifiedFlag status label. <P>
    **
    ** @param modifiedFlagFormatString format string for formatting the
    **                                 ModifiedFlag status label
    ** @see #getModifiedFlagFormatString()
    */
    public void setModifiedFlagFormatString(String modifiedFlagFormatString)
    {
        _modifiedFlagFormatString = modifiedFlagFormatString;
        _updateIndicatorsLater();
    } // setModifiedFlagFormatString

    /**
    ** Returns the format string for formatting the ModifiedFlag status label.
    **
    ** @return the format string for formatting the ModifiedFlag status label.
    ** @see #setModifiedFlagFormatString(String ModifiedFlagFormatString)
    */
    public String getModifiedFlagFormatString()
    {
        return(_modifiedFlagFormatString);
    } // getModifiedFlagFormatString

    /**
    ** Sets the format string for formatting the MessageArea status label. <P>
    **
    ** @param messageAreaFormatString format string for formatting the
    **                                MessageArea status label
    ** @see #getMessageAreaFormatString()
    */
    public void setMessageAreaFormatString(String messageAreaFormatString)
    {
        _messageAreaFormatString = messageAreaFormatString;
        _updateIndicatorsLater();
    } // setMessageAreaFormatString

    /**
    ** Returns the format string for formatting the MessageArea status label.
    **
    ** @return the format string for formatting the MessageArea status label.
    ** @see #setMessageAreaFormatString(String messageAreaFormatString)
    */
    public String getMessageAreaFormatString()
    {
        return(_messageAreaFormatString);
    } // getMessageAreaFormatString

    /**
    ** Sets the format string for formatting the PercentDone status label. <P>
    **
    ** @param percentDoneFormatString format string for formatting the
    **                                PercentDone status label
    ** @see #getPercentDoneFormatString()
    */
    public void setPercentDoneFormatString(String percentDoneFormatString)
    {
        _percentDoneFormatString = percentDoneFormatString;
        _updateIndicatorsLater();
    } // setPercentDoneFormatString

    /**
    ** Returns the format string for formatting the PercentDone status label.
    **
    ** @return the format string for formatting the PercentDone status label.
    ** @see #setPercentDoneFormatString(String percentDoneFormatString)
    */
    public String getPercentDoneFormatString()
    {
        return(_percentDoneFormatString);
    } // getPercentDoneFormatString

    /**
    ** Reports whether the modified flag is shown. <P>
    **
    ** A status reporting method that informs the caller whether or not the
    ** message area of the StatusBar is displayed.
    **
    ** @return <TT>TRUE</TT> if the modified flag is displayed.
    ** @see #setHasModifiedFlag(boolean showIt)
    */
    public boolean getHasModifiedFlag()
    {
        return(_hasModifiedFlag);
    } // hasMessageArea

    /**
    ** Determines whether the modified flag is visible. <P>
    **
    ** Allows the caller to show or hide the message area in the StatusBar.
    **
    ** @param showIt If <TT>TRUE</TT> then the modified flag will be shown.
    ** @see #getHasModifiedFlag()
    */
    public void setHasModifiedFlag(boolean showIt)
    {
        if (_hasModifiedFlag != showIt)
        {
            _hasModifiedFlag = showIt;
            _updateIndicatorsLater();
        }
    } // showMessageArea

    /**
    ** Reports whether the Message Area is shown. <P>
    **
    ** A status reporting method that informs the caller whether or not the
    ** message area of the StatusBar is displayed.
    **
    ** @return <TT>TRUE</TT> if the message area is displayed.
    ** @see #setHasMessageArea(boolean showIt)
    */
    public boolean getHasMessageArea()
    {
        return(_hasMessageArea);
    } // hasMessageArea

    /**
    ** Determines whether the message are is visible. <P>
    **
    ** Allows the caller to show or hide the message area in the StatusBar.
    **
    ** @param showIt If <TT>TRUE</TT> then the message area will be shown.
    ** @see #getHasMessageArea()
    */
    public void setHasMessageArea(boolean showIt)
    {
        if (_hasMessageArea != showIt)
        {
            _hasMessageArea = showIt;
            _updateIndicatorsLater();
        }
    } // showMessageArea

    /**
    ** Indicates whether the Current Row indicator is shown. <P>
    **
    ** A status reporting method that informs the caller whether or not the
    ** Current Row indicator on the StatusBar is displayed.
    **
    ** @return <TT>TRUE</TT> if the current row indicator is shown.
    ** @see #setHasCurrentRow(boolean showIt)
    */
    public boolean getHasCurrentRow()
    {
        return(_hasCurrentRow);
    } // hasCurrentRow

    /**
    ** Determines whether the current row indicator is visible. <P>
    **
    ** Allows the caller to show or hide the current row indicator in the
    ** StatusBar.
    **
    ** @param showIt if <TT>TRUE</TT> then the current row indicator is shown
    ** @see #getHasCurrentRow()
    */
    public void setHasCurrentRow(boolean showIt)
    {
        if (_hasCurrentRow != showIt)
        {
            _hasCurrentRow = showIt;
            _updateIndicatorsLater();
        }
    } // showCurrentRow

    /**
    ** Indicates whether the High Water Mark indicator is shown. <P>
    **
    ** A status reporting method that informs the caller whether or not the
    ** High Water Mark indicator on the StatusBar is displayed.
    **
    ** @return <TT>TRUE</TT> if the High Water Mark indicator is shown.
    ** @see #setHasHighWaterMark(boolean showIt)
    */
    public boolean getHasHighWaterMark()
    {
        return(_hasHighWaterMark);
    } // hasHighWaterMark

    /**
    ** Determines whether the High Water Mark indicator is visible. <P>
    **
    ** Allows the caller to show or hide the High Water Mark indicator in the
    ** StatusBar.
    **
    ** @param showIt <TT>TRUE</TT> to show the High Water Mark indicator
    ** @see #getHasHighWaterMark()
    */
    public void setHasHighWaterMark(boolean showIt)
    {
        if (_hasHighWaterMark != showIt)
        {
            _hasHighWaterMark = showIt;
            _updateIndicatorsLater();
        }
    } // showHighWaterMark

    /**
    ** Indicates whether the Row Count indicator is shown. <P>
    **
    ** A status reporting method that informs the caller whether or not the
    ** Row Count indicator on the StatusBar is displayed.
    **
    ** @return <TT>TRUE</TT> if the row count indicator is shown.
    ** @see #setHasRowCount(boolean showIt)
    */
    public boolean getHasRowCount()
    {
        return(_hasRowCount);
    } // hasRowCount

    /**
    ** Determines whether the row count indicator is visible. <P>
    **
    ** Allows the caller to show or hide the row count indicator in the
    ** StatusBar.
    **
    ** @param showIt if <TT>TRUE</TT> then the row count indicator is shown
    ** @see #getHasRowCount()
    */
    public void setHasRowCount(boolean showIt)
    {
        if (_hasRowCount != showIt)
        {
            _hasRowCount = showIt;
            _updateIndicatorsLater();
        }
    } // showRowCount

    /**
    ** Indicates whether the Percent Done indicator is shown. <P>
    **
    ** A status reporting method that informs the caller whether or not the
    ** Percent Done indicator on the StatusBar is displayed.
    **
    ** @return <TT>TRUE</TT> if the percent done indicator is shown.
    ** @see #setHasPercentDone(boolean showIt)
    */
    public boolean getHasPercentDone()
    {
        return(_hasPercentDone);
    } // hasPercentDone

    /**
    ** Determines whether the percent done indicator is visible. <P>
    **
    ** Allows the caller to show or hide the percent done indicator in the
    ** StatusBar.
    **
    ** @param showIt if <TT>TRUE</TT> then the percent done indicator is shown
    ** @see #getHasPercentDone()
    */
    public void setHasPercentDone(boolean showIt)
    {
        if (_hasPercentDone != showIt)
        {
            _hasPercentDone = showIt;
            _updateIndicatorsLater();
        }
    } // showPercentDone

    /**
    ** Determines whether or not the working icon is shown. <P>
    **
    ** @param showWorkingIcon if true, then the working icon will be shown
    ** @see #hasWorkingIcon()
    */
    public void setShowWorkingIcon(boolean hasWorkingIcon)
    {
        _hasWorkingIcon = hasWorkingIcon;        
    } // setShowWorkingIcon
    
    /**
    ** Inquires whether the working icon is shown. <P>
    **
    ** @return True if the working icon will be shown.
    ** @see #setShowWorkingIcon(boolean showWorkingIcon)
    */
    public boolean hasWorkingIcon()
    {
        return(_hasWorkingIcon);        
    } // getShowWorkingIcon
    
    /**
    ** Sets the name of the icon shown when a long-running activity starts.<p>
    **
    ** This method selects the icon that is displayed when the ActivityMonitor
    ** notifies the StatusBar that a long running activity has started. 
    **
    ** @param workingIconFileName the name of the icon shown when a 
    **                    long-running activity starts
    ** @see #getWorkingIconFileName()
    ** @see ActivityMonitor
    */
    public void setWorkingIconFileName(String workingIconFileName)
    {
        _workingIconFileName = workingIconFileName;
        if (_workingIconFileName != null)
        {
            URL img = StatusBarControl.class.getResource(_workingIconFileName);

            if (img != null)
            {
                _workingIcon = new ImageIcon(img);
            }
        }
        else
        {
            _workingIcon = null;
        }
    } // setWorkingIconFileName
    
    /**
    ** Gets the name of the icon shown when a long-running activity starts.<p>
    **
    ** This method returns the icon that is displayed when the ActivityMonitor
    ** notifies the StatusBar that a long running activity has started. 
    **
    ** @return the name of the icon shown when a long-running activity starts
    ** @see #setWorkingIconFileName(String workingIconFileName)
    */
    public String getWorkingIconFileName()
    {
        return(_workingIconFileName);
    } // getWorkingIconFileName

    /**
    ** Returns the actual Icon that will be displayed when a long running
    ** activity begins.<P>
    **
    ** This method is intended to be used by subclasses that implement
    ** overrides to showWorkingIcon() and hideWorkingIcon().
    **
    ** @return The icon displayed when we need to indicate that its "working"
    ** @see #showWorkingIcon()
    ** @see #hideWorkingIcon()
    ** @see #setWorkingIconFileName(String workingIconFileName)
    ** @see #getWorkingIconFileName()
    */
    protected final Icon getWorkingIcon()
    {
        return(_workingIcon);        
    } // getWorkingIcon
    
    /**
    **  A "hook" so that subclasses can change how the working icon is
    **  displayed.  The default behavior is to display it in the message area.
    **  A subclass could choose to display the working icon someplace else
    **  such as a non-modal dialog.<p>
    **
    **  This method will be called when the working icon is to be displayed.
    */
    protected void showWorkingIcon()
    {
        _messageArea.setIcon(_workingIcon);
    }

    /**
    **  A "hook" so that subclasses can change how the working icon is
    **  hidden.  The default behavior is to display it in the message area.
    **  A subclass could choose to display the working icon someplace else
    **  such as a non-modal dialog.<p>
    **
    **  This method will be called when the working icon is to be hidden.
    */
    protected void hideWorkingIcon()
    {
        _messageArea.setIcon(null);
    }
    
    
    // InfoBusManagerListener interface implementation
    public void releaseResources(InfoBusManagerReleaseEvent e)
    {
        if (e.appliesTo(this))
        {
            NavigationManager navmgr =
                NavigationManager.getNavigationManager();
            
            InfoBusManager.getInstance().removeInfoBusManagerListener(this);
            navmgr.removeCurrencyListener(this);
            ActivityMonitor.removeActivityListener(this);
            _controlSupport = null;
        }
    }

    // ActivityListener Interface

    /**
    **  This method is called when a particular activity is started
    **
    **  @param event An ActivityEvent object describing the activity being
    **               started
    **  @see ActivityMonitor#activityStarted
    */
    public final void activityStarted(ActivityEvent event)
    {
        // _debug("activityStarted: " + event);
        if (_activityCount == 0 && _workingIcon != null)
        {
            _activityCount++;
            showWorkingIcon();
        }
    }

    /**
    **  This method is called when a particular activity is stopped
    **
    **  @param event An ActivityEvent object describing the activity being
    **               stopped
    **  @see ActivityMonitor#activityStopped
    */
    public final void activityStopped(ActivityEvent event)
    {
        // _debug("activityStopped: " + event);
        if (_activityCount > 0)
        {
            _activityCount--;
            hideWorkingIcon();
        }
    }

    // Control Interface

    /**
    ** An override of java.awt.Component.setEnabled. <P>
    **
    ** @param b boolean flag indicating whether the control is enabled
    */
    public void setEnabled(boolean b)
    {
        super.setEnabled(b);
    } // setEnabled

    /**
    ** Will be called back from ControlSupport to set the actual value.
    */
    void _doSetEnable(boolean b)
    {
    }

    /**
    ** Returns the name of the InfoBus this control is connected to. <P>
    ** @return  The name of the InfoBus this control is connected to.
    ** @see Control#getInfoBusName
    */
    public final String getInfoBusName()
    {
        return(_controlSupport == null ?
               null : _controlSupport.getInfoBusName());
    }

    /**
    ** Sets the name of the InfoBus this control is connected to. <P>
    ** By default, the control is connected to the default InfoBus,
    ** named <TT>Control.DEFAULT_INFOBUS_NAME</TT>. <P>
    ** If the named InfoBus does not exist, it is created automatically. <P>
    ** If the control is already connected to an InfoBus, it is disconnected
    ** first. <P>
    ** @param infoBusName   The name of the InfoBus to connect to.
    ** @see Control#DEFAULT_INFOBUS_NAME
    ** @see Control#setInfoBusName
    */
    public final void setInfoBusName(String infoBusName)
    {
        if (_controlSupport != null)
        {
            _controlSupport.setInfoBusName(infoBusName);
        }
    }

    /**
    ** Returns the name of the InfoBus DataItem this control is bound to. <P>
    ** @return  The name of the InfoBus DataItem this control is bound to,
    **          or <TT>null</TT> if the control is unbound.
    ** @see #getDataItem
    ** @see Control#getDataItemName
    */
    public final String getDataItemName()
    {
        return(_controlSupport == null ?
               null : _controlSupport.getDataItemName());
    }


    /**
    ** Sets the name of the InfoBus DataItem this control is bound to. <P>
    ** The DataItem with the given name is searched for on the InfoBus, and
    ** if found, is bound to this control. <P>
    ** If the control is already bound to a DataItem, it is unbound first. <P>
    **
    ** The StatusBar will now track the status of this rowset indicated by
    ** the dataItemName
    ** @param dataItemName  The name of the DataItem to bind to.
    ** @see #getDataItem
    ** @see Control#setDataItemName
    */
    public final void setDataItemName(String dataItemName)
    {
        if (_controlSupport != null)
        {
            _controlSupport.setDataItemName(dataItemName);
        }
        if ( dataItemName != null)
        {
            NavigationManager navmgr =
                NavigationManager.getNavigationManager();
            
            navmgr.removeCurrencyListener(this);
            if ( _activeRowset == null )
            {
                _updateIndicators();
            }
            _activeRowset = dataItemName;
        }
    }


    /**
    ** Returns the InfoBus DataItem this control is bound to. <P>
    ** @return  The InfoBus DataItem this control is bound to, or
    **          <TT>null</TT> if the control is unbound.
    ** @see Control#getDataItem
    */
    public final Object getDataItem()
    {
        return(_controlSupport == null ?
               null : _controlSupport.getDataItem());
    }

    /**
    ** Notifies the control that the bound InfoBus DataItem has changed. <P>
    ** @param oldDataItem   The formerly bound DataItem (can be <TT>null</TT>).
    ** @param newDataItem   The newly bound DataItem (can be <TT>null</TT>).
    ** @see Control#dataItemChanged
    */
    public final void dataItemChanged(Object oldDataItem, Object newDataItem)
    {
        // Don't care
        _updateIndicatorValues();
    }

    /**
    ** Returns the AWT component associated with this control. <P>
    ** @return  The AWT component for this control.
    ** @see Control#getComponent
    */
    public final Component getComponent()
    {
        return(this);
    }

    /**
    ** Determines whether focus into this control causes validation to
    ** occur. <P>
    ** @return  Always false
    ** @see Control#isFocusValidated
    */
    public final boolean isFocusValidated()
    {
        // StatusBars don't get focus
        return(false);
    }

    /**
    **  This method is a no-op; it has no effect
    */
    public final void setFocusValidated(boolean focusValidated)
    {
        // StatusBars don't get focus
    }

    /**
    **  This method is a no-op; it has no effect
    */
    public final void addNavigatedListener(NavigatedListener listener)
    {
        // Can't add Navigated listeners to StatusBars; they don't get
        // focus
    }

    /**
    **  This method is a no-op; it has no effect
    */
    public final void removeNavigatedListener(NavigatedListener listener)
    {
        // Can't remove Navigated listeners from StatusBars; they don't get
        // focus
    }

    /**
    **  This method is a no-op; it has no effect
    */
    public final void processNavigatedEvent(NavigatedEvent event)
    {
        // Can't add Navigating listeners to StatusBars; they don't get
        // focus
        // StatusBars don't get focus
    }

    /**
    **  This method is a no-op; it has no effect
    */
    public final void addNavigatingListener(NavigatingListener listener)
    {
        // Can't add Navigating listeners to StatusBars; they don't get
        // focus
        // StatusBars don't get focus
    }

    /**
    **  This method is a no-op; it has no effect
    */
    public final void removeNavigatingListener(NavigatingListener listener)
    {
        // Can't remove Navigating listeners from StatusBars; they don't get
        // focus
    }

    /**
    **  This method is a no-op in that it has no effect
    *   @exception  NavigatingException  Not relevant in this situation
    */
    public final void processNavigatingEvent(NavigatingEvent event)
        throws NavigatingException
    {
        // StatusBars don't get focus
    }

    // DataItemChangeListener Interface

    /**
    ** Indicates a changed value in the bound data item. <P>
    **
    ** A reference to the data item that changed can be obtained from the
    ** event. <P>
    **
    ** @param event Contains change information.
    ** @see javax.infobus.DataItemChangeListener#dataItemValueChanged
    */
    public final void dataItemValueChanged(DataItemValueChangedEvent event)
    {
        _updateIndicatorValues();
    }

    /**
    ** Indicates that a new item was added to the bound aggregate data item
    ** (e.g. <TT>ArrayAccess</TT>, a JDK Collection, etc). <P>
    **
    ** A reference to the data item that was added, and a reference to the one
    ** that gained it, can be obtained from the event. <P>
    **
    ** Has no effect on the StatusBar.<P>
    **
    ** @param event Contains details of the addition.
    ** @see javax.infobus.DataItemChangeListener#dataItemAdded
    */
    public final void dataItemAdded(DataItemAddedEvent event)
    {
        _updateIndicatorValues();
    }

    /**
    ** Indicates that an item was deleted from the bound aggregate data item
    ** (e. g. <TT>ArrayAccess</TT>, a JDK Collection, etc). <P>
    **
    ** A reference to the data item that was deleted, and a reference to the
    ** one that lost it, can be obtained from the event. <P>
    **
    ** Has no effect on the StatusBar.<P>
    **
    ** @param event Contains details of the deletion.
    ** @see javax.infobus.DataItemChangeListener#dataItemDeleted
    */
    public final void dataItemDeleted(DataItemDeletedEvent event)
    {
        _updateIndicatorValues();
    }

    /**
    ** Indicates that the bound data item (and its sub-items, if any) has been
    ** revoked, and is temporarily unavailable. <P>
    **
    ** A reference to the data item that was revoked can be obtained from
    ** the event. <P>
    **
    ** @param event Contains details of the revoked data.
    ** @see javax.infobus.DataItemChangeListener#dataItemRevoked
    */
    public final void dataItemRevoked(DataItemRevokedEvent event)
    {
        _updateIndicatorValues();
    }

    /**
    ** Indicates that the cursor for the bound <TT>RowsetAccess</TT> data item
    ** has changed rows. <P>
    **
    ** A reference to the rowset data item can be obtained from the event. <P>
    **
    ** @param event Contains details of the cursor move.
    ** @see javax.infobus.DataItemChangeListener#rowsetCursorMoved
    */
    public final void rowsetCursorMoved(RowsetCursorMovedEvent event)
    {
        _updateIndicatorValues();
    }

    // CurrencyListener interface

    /**
    **  This method is used to track which control on the screen gets focus
    **
    **  @param event a CurrencyChangedEvent
    */
    public void currencyChanged(CurrencyChangedEvent e)
    {
        // if it is an IN event and we are in the same frame,
        // lets track what has happened.
        if (_myFrame == null)
        {
            Container c = getParent();

            while(c != null)
            {
                if (c instanceof Frame)
                {
                    _myFrame = (Frame)c;
                    break;
                }
                c = c.getParent();
            }
        }
        if (_myFrame != null &&
            _myFrame.isAncestorOf((Component)(e.getCurrentControl())))
        {
            // find the rowset
            String evtRowset = _findCurrentRowset(e);
            // and update the name of the rowset
            if (_activeRowset == null || !_activeRowset.equals(evtRowset))
            {
                String oldActiveRowset = _activeRowset;
                _activeRowset = evtRowset;
                if (oldActiveRowset == null)
                {
                    _updateIndicators();
                }
                // queue the controls for update
                _updateIndicatorValues();
            }
        }
    }

    // Protected methods
    /**
    * Get the active rowset.
    *
    */
    protected String _getActiveRowset()
    {
        return _activeRowset;
    }

    // Private Methods
    private String _findCurrentRowset(CurrencyChangedEvent event)
    {
        String RowsetName = null;
        DataItem di =
            (DataItem)((Control)event.getCurrentControl()).getDataItem();

        if (di != null)
        {
            InfoObject dobj =
                (InfoObject)di.getProperty(DataItemProperties.INFO_OBJECT);

            if (dobj instanceof AttributeInfo)
            {
                RowsetName = (String)di.getProperty(DataItemProperties.NAME);
                int ndx =
                    RowsetName.lastIndexOf(InfoObject.ITEMNAME_DELIMITER);
                RowsetName = RowsetName.substring(0,ndx);
            }
            else
            {
                if (dobj instanceof RowSetInfo)
                {
                    RowsetName =
                        (String)di.getProperty(DataItemProperties.NAME);
                }
            }
        }
        return(RowsetName);
    } // _findNavigatedRowset

    private StatusBarLabelControl _createStatusLabel(String formatString,
                                                     Formatter formatter,
                                                     Border border)
    {
        StatusBarLabelControl label =
            new StatusBarLabelControl(formatString, formatter);

        label.setBorder(border);
        if (_font != null)
        {
            label.setFont(_font);
        }
        if (_foreGround != null)
        {
            label.setForeground(_foreGround);
        }
        if (_backGround != null)
        {
            label.setBackground(_backGround);
        }
        return(label);
    } // _createStatusLabel

    private StatusBarProgressControl _createProgressBar(String formatString,
                                                        Formatter formatter,
                                                        Border border)
    {
        StatusBarProgressControl progressBar =
            new StatusBarProgressControl(formatString, formatter);

        progressBar.setBorder(border);
        if (_font != null)
        {
            progressBar.setFont(_font);
        }
        if (_foreGround != null)
        {
            progressBar.setForeground(_foreGround);
        }
        if (_backGround != null)
        {
            progressBar.setBackground(_backGround);
        }
        return(progressBar);
    } // _createProgressBar

    private void _updateIndicatorsLater()
    {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                _updateIndicators();
            }
        });
    } // _updateIndicatorsLater

    protected void _updateIndicators()
    {
        int index = 0;
        boolean changedSome = false;

        if (_hasPercentDone)
        {
            if (_percentDone == null)
            {
                _percentDone =
                    _createProgressBar(_percentDoneFormatString,
                                       _percentDoneFormatter, _labelBorder);
            }
            if (!_percentDoneShown)
            {
                GridBagConstraints gbc = new GridBagConstraints();
                gbc.gridx = GridBagConstraints.RELATIVE;
                gbc.gridy = GridBagConstraints.RELATIVE;
                gbc.gridwidth = 1;
                gbc.gridheight = 1;
                gbc.weightx = 0;
                gbc.weighty = 1;
                gbc.anchor = GridBagConstraints.CENTER;
                gbc.fill = GridBagConstraints.HORIZONTAL;
                gbc.insets = new Insets(0,0,0,0);
                gbc.ipadx = 0;
                gbc.ipady = 0;
                add(_percentDone, gbc, index);
                changedSome = true;
                _percentDoneShown = true;
            }
            index++;
        }
        else
        {
            changedSome = true;
            remove(_percentDone);
            _percentDone.setDataItemNames(null);
            _percentDoneShown = false;
        }

        if (_hasCurrentRow)
        {
            if (_currentRow == null)
            {
                _currentRow =
                    _createStatusLabel(_currentRowFormatString,
                                       _currentRowFormatter, _labelBorder);
            }
            if (!_currentRowShown)
            {
                GridBagConstraints gbc = new GridBagConstraints();
                gbc.gridx = GridBagConstraints.RELATIVE;
                gbc.gridy = GridBagConstraints.RELATIVE;
                gbc.gridwidth = 1;
                gbc.gridheight = 1;
                gbc.weightx = 0;
                gbc.weighty = 1;
                gbc.anchor = GridBagConstraints.CENTER;
                gbc.fill = GridBagConstraints.NONE;
                gbc.insets = new Insets(0,0,0,0);
                gbc.ipadx = 0;
                gbc.ipady =0 ;
                add(_currentRow, gbc, index);
                changedSome = true;
                _currentRowShown = true;
            }
            index++;
        }
        else
        {
            if (_currentRow != null)
            {
                changedSome = true;
                remove(_currentRow);
                _currentRow.setDataItemName(null);
                _currentRowShown = false;
            }
        }
        if (_hasRowCount)
        {
            if (_rowCount == null)
            {
                _rowCount =
                    _createStatusLabel(_rowCountFormatString,
                                       _rowCountFormatter, _labelBorder);
            }
            if (!_rowCountShown)
            {
                GridBagConstraints gbc = new GridBagConstraints();
                gbc.gridx = GridBagConstraints.RELATIVE;
                gbc.gridy = GridBagConstraints.RELATIVE;
                gbc.gridwidth = 1;
                gbc.gridheight = 1;
                gbc.weightx = 0;
                gbc.weighty = 1;
                gbc.anchor = GridBagConstraints.CENTER;
                gbc.fill = GridBagConstraints.NONE;
                gbc.insets = new Insets(0,0,0,0);
                gbc.ipadx = 0;
                gbc.ipady = 0;
                add(_rowCount, gbc, index);
                changedSome = true;
                _rowCountShown = true;
            }
            index++;
        }
        else
        {
            if (_rowCount != null)
            {
                changedSome = true;
                remove(_rowCount);
                _rowCount.setDataItemName(null);
                _rowCountShown = false;
            }
        }
        if (_hasHighWaterMark)
        {
            if (_highWaterMark == null)
            {
                _highWaterMark =
                    _createStatusLabel(_highWaterMarkFormatString,
                                       _highWaterMarkFormatter, _labelBorder);
            }
            if (!_highWaterMarkShown)
            {
                GridBagConstraints gbc = new GridBagConstraints();
                gbc.gridx = GridBagConstraints.RELATIVE;
                gbc.gridy = GridBagConstraints.RELATIVE;
                gbc.gridwidth = 1;
                gbc.gridheight = 1;
                gbc.weightx = 0;
                gbc.weighty = 1;
                gbc.anchor = GridBagConstraints.CENTER;
                gbc.fill = GridBagConstraints.NONE;
                gbc.insets = new Insets(0,0,0,0);
                gbc.ipadx = 0;
                gbc.ipady = 0;
                add(_highWaterMark, gbc, index);
                changedSome = true;
                _highWaterMarkShown = true;
            }
            index++;
        }
        else
        {
            if (_highWaterMark != null)
            {
                changedSome = true;
                remove(_highWaterMark);
                _highWaterMark.setDataItemName(null);
                _highWaterMarkShown = false;
            }
        }
        if (_hasModifiedFlag)
        {
            if (_modifiedFlag == null)
            {
                _modifiedFlag =
                    _createStatusLabel(_modifiedFlagFormatString,
                                       _modifiedFlagFormatter, _labelBorder);
            }
            if (!_modifiedFlagShown)
            {
                GridBagConstraints gbc = new GridBagConstraints();
                gbc.gridx = GridBagConstraints.RELATIVE;
                gbc.gridy = GridBagConstraints.RELATIVE;
                gbc.gridwidth = 1;
                gbc.gridheight = 1;
                gbc.weightx = 0;
                gbc.weighty = 1;
                gbc.anchor = GridBagConstraints.CENTER;
                gbc.fill = GridBagConstraints.NONE;
                gbc.insets = new Insets(0,0,0,0);
                gbc.ipadx = 0;
                gbc.ipady = 0;
                add(_modifiedFlag, gbc, index);
                changedSome = true;
                _modifiedFlagShown = true;
            }
            index++;
        }
        else
        {
            if (_modifiedFlag != null)
            {
                changedSome = true;
                remove(_modifiedFlag);
                _modifiedFlag.setDataItemName(null);
                _modifiedFlagShown = false;
            }
        }

        if (_hasMessageArea)
        {
            if (_messageArea == null)
            {
                _messageArea =
                    _createStatusLabel(_messageAreaFormatString,
                                       _messageAreaFormatter, _labelBorder);
            }
            if (!_messageAreaShown)
            {
                GridBagConstraints gbc = new GridBagConstraints();
                gbc.gridx = GridBagConstraints.RELATIVE;
                gbc.gridy = GridBagConstraints.RELATIVE;
                gbc.gridwidth = GridBagConstraints.RELATIVE;
                gbc.gridheight = 1;
                gbc.weightx = 1;
                gbc.weighty = 1;
                gbc.anchor = GridBagConstraints.CENTER;
                gbc.fill = GridBagConstraints.HORIZONTAL;
                gbc.insets = new Insets(0,0,0,0);
                gbc.ipadx = 0;
                gbc.ipady = 0;
                add(_messageArea, gbc, index);
                changedSome = true;
                _messageAreaShown = true;
            }
            index++;
        }
        else
        {
            if (_messageArea != null)
            {
                changedSome = true;
                remove(_messageArea);
                _messageArea.setDataItemName(null);
                _messageAreaShown = false;
            }
        }

        if (changedSome)
        {
            // !!! might need to determine the focused Rowset...
            _updateIndicatorValuesLater();
        }
    } // _updateIndicators

    private void _updateIndicatorValuesLater()
    {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                _updateIndicatorValues();
            }
        });
    } // _updateIndicatorValuesLater

    protected void _updateIndicatorValues()
    {
        String diName;

        if (_currentRow != null)
        {
            if (_activeRowset != null )
            {
                _currentRow.setDataItemName(_activeRowset +
                                            DacObject.ITEMNAME_DELIMITER +
                                            RowSetInfo.CURROW_ATTR_NAME);
            }
            else
            {
                _currentRow.setDataItemName(null);
            }
        }
        if (_highWaterMark != null)
        {
            if (_activeRowset != null)
            {
                _highWaterMark.setDataItemName(_activeRowset +
                                               DacObject.ITEMNAME_DELIMITER +
                                               RowSetInfo.HIGH_ATTR_NAME);
            }
            else
            {
                _highWaterMark.setDataItemName(null);
            }
        }
        if (_rowCount != null)
        {
            if (_activeRowset != null)
            {
                _rowCount.setDataItemName(_activeRowset +
                                          DacObject.ITEMNAME_DELIMITER +
                                          RowSetInfo.ROWCNT_ATTR_NAME);
            }
            else
            {
                _rowCount.setDataItemName(null);
            }
        }
        if (_modifiedFlag != null)
        {
            if (_activeRowset != null)
            {
                _modifiedFlag.setDataItemName(_activeRowset +
                                              DacObject.ITEMNAME_DELIMITER +
                                              RowSetInfo.MODIFIED_ATTR_NAME);
            }
            else
            {
                _modifiedFlag.setText(_modifiedFlagFormatString +
                                      Res.getString(Res.SBAR_MODIFIED_FALSE_STATE));
                _modifiedFlag.setDataItemName(null);
            }
        }
        if (_messageArea != null)
        {
            if (_activeRowset != null)
            {
                _messageArea.setDataItemName(_activeRowset +
                                             DacObject.ITEMNAME_DELIMITER +
                                             RowSetInfo.CURMSG_ATTR_NAME);
            }
            else
            {
                _messageArea.setText(BLANK);
                _messageArea.setDataItemName(null);
            }
        }
        if (_percentDone != null)
        {
            if (_activeRowset != null)
            {
                String[] names = new String[]
                    {
                        _activeRowset + DacObject.ITEMNAME_DELIMITER +
                            RowSetInfo.ROWCNT_ATTR_NAME,
                            _activeRowset + DacObject.ITEMNAME_DELIMITER +
                            RowSetInfo.CURROW_ATTR_NAME
                            };

                _percentDone.setDataItemNames(names);
            }
            else
            {
                _percentDone.setDataItemNames(null);
            }
        }

        revalidate();
    } // _updateIndicatorValues

    private void _debug(String s)
    {
        if (_DEBUG)
        {
            System.out.println("StatusBarControl: " + s);
        }
    } // _debug

    public class StatusBarLabelControl
        extends JLabel
        implements Control, InfoBusManagerListener
    {
        private final boolean _DEBUG = false;

        private ControlSupport _controlSupport;
        String _formatString;
        Formatter _formatter;

        /**
        ** Constructs a StatusBarLabelControl.
        **
        ** The label's contents, once set, will be displayed at the left
        ** of the label's display area.
        */
        public StatusBarLabelControl()
        {
            this(null, JLabel.LEFT, null, null);
        }

        /**
        **  Creates a LabelControl instance with the specified image. The
        **  label is centered vertically and horizontally in display area
        **
        ** @param image the image to be displayed by the label
        */
        public StatusBarLabelControl(Icon image)
        {
            this(image, JLabel.CENTER, null, null);
        }

        /**
        **  Creates a LabelControl instance with the specified image. The
        **  label is centered vertically and horizontally in display area
        **
        ** @param image the image to be displayed by the label
        */
        public StatusBarLabelControl(String formatString, Formatter formatter)
        {
            this(null, JLabel.LEFT, formatString, formatter);
        }

        /**
        ** Creates a <code>LabelControl</code> instance with the specified
        ** image, and horizontal alignment.
        **
        ** @param icon  The image to be displayed by the label.
        ** @param horizontalAlignment  One of the following constants
        **           defined in <code>SwingConstants</code>:
        **           <code>LEFT</code>,
        **           <code>CENTER</code>, or
        **           <code>RIGHT</code>.
        ** @param formatString The format string to use when displaying the
        **                     value.
        */
        public StatusBarLabelControl(Icon icon, int horizontalAlignment,
                                     String formatString, Formatter formatter)
        {
            super("", icon, horizontalAlignment);
            _controlSupport = new ControlSupport(this);
            InfoBusManager.getInstance().addInfoBusManagerListener(this);
            // Labels don't get focus
            _controlSupport.setFocusValidated(false);
            _formatString = formatString;
            _formatter = formatter;
            _updateValue(_controlSupport.getDataItem());
        }

        /**
        ** Sets the format string to be used when displaying the value. <P>
        **
        ** The format string should be a format string as supported by the
        ** DefaultNumberFormatter.
        **
        ** @param nuFormatString The format string
        ** @see #getFormatString()
        ** @see oracle.dacf.formatter.DefaultNumberFormatter
        */
        public void setFormatString(String nuFormatString)
        {
            _formatString = nuFormatString;
            if (_controlSupport != null)
            {
                _updateValueLater(_controlSupport.getDataItem());
            }
        } // setFormatString

        /**
        ** Returns the format string to be used when displaying the value. <P>
        **
        ** The format string should be a format string as supported by the
        ** DefaultNumberFormatter.
        **
        ** @return a reference to the format string.
        ** @see #setFormatString(String nuFormatString)
        ** @see oracle.dacf.formatter.DefaultNumberFormatter
        */
        public String getFormatString()
        {
            return(_formatString);
        } // getFormatString

        /**
        **  Sets the formatter for the LabelControl
        **
        **  @param formatter the new formatter for the label control
        */
        public void setFormatter(Formatter formatter)
        {
            _formatter = formatter;
            if (_controlSupport != null)
            {
                _updateValueLater(_controlSupport.getDataItem());
            }
        } // setFormatter

        /**
        **  Returns the formatter for the LabelControl
        **
        **  @return the new formatter for the label control
        */
        public Formatter getFormatter()
        {
            return(_formatter);
        } // getFormatter

        // InfoBusManagerListener interface implementation
        public void releaseResources(InfoBusManagerReleaseEvent e)
        {
            if (e.appliesTo(this))
            {
                InfoBusManager.getInstance().removeInfoBusManagerListener(this);
                _controlSupport = null;
            }
        }

        // Control Interface

        /**
        ** Returns the name of the InfoBus this control is connected to. <P>
        **
        ** @return  The name of the InfoBus this control is connected to.
        ** @see Control#getInfoBusName
        */
        public final String getInfoBusName()
        {
            return(_controlSupport == null ?
                   null : _controlSupport.getInfoBusName());
        }


        /**
        ** An override of java.awt.Component.setEnabled. <P>
        **
        ** @param b boolean flag indicating whether the control is enabled
        */
        public void setEnabled(boolean b)
        {
            super.setEnabled(b);
        } // setEnabled

        /**
        ** Sets the name of the InfoBus this control is connected to. <P>
        **
        ** By default, the control is connected to the default InfoBus,
        ** named <TT>Control.DEFAULT_INFOBUS_NAME</TT>. <P>
        **
        ** If the named InfoBus does not exist, it is created automatically.<P>
        **
        ** If the control is already connected to an InfoBus, it is
        ** disconnected first. <P>
        **
        ** @param infoBusName   The name of the InfoBus to connect to.
        ** @see Control#DEFAULT_INFOBUS_NAME
        ** @see Control#setInfoBusName
        */
        public final void setInfoBusName(String infoBusName)
        {
            if (_controlSupport != null)
            {
                _controlSupport.setInfoBusName(infoBusName);
            }
        }


        /**
        ** Returns the name of the bound InfoBus DataItem.
        **
        ** @return  The name of the InfoBus DataItem this control is bound to,
        **          or <TT>null</TT> if the control is unbound.
        ** @see #getDataItem
        ** @see Control#getDataItemName
        */
        public final String getDataItemName()
        {
            return(_controlSupport == null ?
                   null : _controlSupport.getDataItemName());
        }


        /**
        ** Sets the name of the InfoBus DataItem this control is bound to. <P>
        **
        ** The DataItem with the given name is searched for on the InfoBus, and
        ** if found, is bound to this control. <P>
        **
        ** If the control is already bound to a DataItem, it is unbound first.
        **
        ** @param dataItemName  The name of the DataItem to bind to.
        ** @see #getDataItem
        ** @see Control#setDataItemName
        */
        public final void setDataItemName(String dataItemName)
        {
            if (_controlSupport != null)
            {
                _controlSupport.setDataItemName(dataItemName);
            }
        }


        /**
        ** Returns the InfoBus DataItem this control is bound to. <P>
        **
        ** @return  The InfoBus DataItem this control is bound to, or
        **          <TT>null</TT> if the control is unbound.
        ** @see Control#getDataItem
        */
        public final Object getDataItem()
        {
            return(_controlSupport == null ?
                   null : _controlSupport.getDataItem());
        }

        /**
        ** Notifies the control that the bound InfoBus DataItem has changed.<P>
        **
        ** @param oldDataItem The formerly bound DataItem (can be null).
        ** @param newDataItem The newly bound DataItem (can be null).
        ** @see Control#dataItemChanged
        */
        public final void dataItemChanged(Object oldDataItem,
                                          Object newDataItem)
        {
            // Don't care
        }

        /**
        ** Returns the AWT component associated with this control. <P>
        **
        ** @return  The AWT component for this control.
        ** @see Control#getComponent
        */
        public final Component getComponent()
        {
            return(this);
        }

        /**
        ** Determines whether focus into this control causes validation to
        ** occur. <P>
        **
        ** @return  Always false
        ** @see Control#isFocusValidated
        */
        public final boolean isFocusValidated()
        {
            // Labels don't get focus
            return(false);
        }

        /**
        **  This method is a no-op that is it has no effect
        */
        public final void setFocusValidated(boolean focusValidated)
        {
            // Labels don't get focus
        }

        /**
        **  This method is a no-op that is it has no effect
        */
        public final void addNavigatedListener(NavigatedListener listener)
        {
            // Labels don't get focus
        }

        /**
        **  This method is a no-op that is it has no effect
        */
        public final void removeNavigatedListener(NavigatedListener listener)
        {
            // Labels don't get focus
        }

        /**
        **  This method is a no-op that is it has no effect
        */
        public final void processNavigatedEvent(NavigatedEvent event)
        {
            // Labels don't get focus
        }

        /**
        **  This method is a no-op that is it has no effect
        */
        public final void addNavigatingListener(NavigatingListener listener)
        {
            // Labels don't get focus
        }

        /**
        **  This method is a no-op in that it has no effect
        */
        public final void removeNavigatingListener(NavigatingListener listener)
        {
            // Labels don't get focus
        }

        /**
        **  This method is a no-op in that it has no effect
        **  @exception  NavigatingException  Indicates navigation was rejected.
        */
        public final void processNavigatingEvent(NavigatingEvent event)
            throws NavigatingException
        {
            // Labels don't get focus
        }

        // DataItemChangeListener Interface

        /**
        ** Indicates a changed value in the bound data item. <P>
        **
        ** A reference to the data item that changed can be obtained from the
        ** event. <P>
        **
        ** @param event Contains change information.
        ** @see javax.infobus.DataItemChangeListener#dataItemValueChanged
        */
        public final void dataItemValueChanged(DataItemValueChangedEvent event)
        {
            _updateValueLater(event.getChangedItem());
        }

        /**
        ** Indicates that a new item was added to the bound aggregate data item
        ** (e.g. <TT>ArrayAccess</TT>, a JDK Collection, etc). <P>
        **
        ** A reference to the data item that was added, and a reference to the
        ** one that gained it, can be obtained from the event. <P>
        **
        ** Has no effect on the StatusBarLabelControl.<P>
        **
        ** @param event Contains details of the addition.
        ** @see javax.infobus.DataItemChangeListener#dataItemAdded
        */
        public final void dataItemAdded(DataItemAddedEvent event)
        {
            // Not applicable
        }

        /**
        ** Indicates that an item was deleted from the bound aggregate data
        ** item (e. g. <TT>ArrayAccess</TT>, a JDK Collection, etc). <P>
        **
        ** A reference to the data item that was deleted, and a reference to
        ** the one that lost it, can be obtained from the event. <P>
        **
        ** Has no effect on the StatusBarLabelControl.<P>
        *
        ** @param event Contains details of the deletion.
        ** @see javax.infobus.DataItemChangeListener#dataItemDeleted
        */
        public final void dataItemDeleted(DataItemDeletedEvent event)
        {
            // Not applicable
        }

        /**
        ** Indicates that the bound data item (and its sub-items, if any) has
        ** been revoked, and is temporarily unavailable. <P>
        **
        ** A reference to the data item that was revoked can be obtained from
        ** the event. <P>
        **
        ** @param event Contains details of the revoked data.
        ** @see javax.infobus.DataItemChangeListener#dataItemRevoked
        */
        public final void dataItemRevoked(DataItemRevokedEvent event)
        {
            _updateValueLater(null);
        }

        /**
        ** Indicates that the cursor for the bound <TT>RowsetAccess</TT> data
        ** item has changed rows. <P>
        **
        ** A reference to the rowset data item can be obtained from the event.
        **
        ** @param event Contains details of the cursor move.
        ** @see javax.infobus.DataItemChangeListener#rowsetCursorMoved
        */
        public final void rowsetCursorMoved(RowsetCursorMovedEvent event)
        {
            // Not applicable
        }

        // Private Methods

        private void _updateValueLater(final Object dataItem)
        {
            SwingUtilities.invokeLater(
                                       new Runnable()
                                       {
                                           public void run()
                                               {
                                                   _updateValue(dataItem);
                                               }
                                       }
                                       );
        }

        private void _updateValue(Object dataItem)
        {
            Object value = null;
            String txt = BLANK;

            if (dataItem != null && dataItem instanceof ImmediateAccess)
            {
                value = ((ImmediateAccess)dataItem).getValueAsObject();
            }
            if (_formatString != null)
            {
                if (_formatter != null)
                {
                    try
                    {
                        txt = _formatter.format(_formatString, value);
                    }
                    catch(Exception e)
                    {
                        // fall back to the case where there's no formatter
                        txt = _formatString.replace('#',' ') +
                            (value != null ? value.toString() : BLANK);
                    }
                }
                else
                {
                    txt = _formatString.replace('#',' ') +
                        (value != null ? value.toString() : BLANK);
                }
            }
            else
            {
                if (value != null)
                {
                    txt = value.toString();
                }
            }
            setText(txt);
        }

        private void _debug(String s)
        {
            if (_DEBUG)
            {
                System.out.println("StatusBarLabelControl: " + s);
            }
        } // _debug
    } // StatusBarLabelControl

    /**
    **  A derivative of JProgressBar that listens to three DataItems.
    **  The first DataItem is the Maximim value, the second DataItem is the
    **  current value and the third DataItem is the minimum value.  The third
    **  DataItem is option and if missing, the minimum value is assumed to be
    **  1.
    */
    public class StatusBarProgressControl
        extends JProgressBar
        implements Control, InfoBusManagerListener
    {
        private final int MAX_VAL_DI_NAME = 0;
        private final int CUR_VAL_DI_NAME = 1;
        private final int MIN_VAL_DI_NAME = 2;

        private ControlSupportHC _controlSupport;
        private final boolean _DEBUG = false;

        private transient Object _lockObj = new Object();

        String _formatString;
        Formatter _formatter;

        /**
        ** Constructs a StatusBarProgressControl.
        */
        public StatusBarProgressControl()
        {
            this(JProgressBar.HORIZONTAL, 0, 100, null, null);
        }

        public StatusBarProgressControl(int orient)
        {
            this(orient, 0, 100, null, null);
        }

        public StatusBarProgressControl(int min, int max)
        {
            this(JProgressBar.HORIZONTAL, min, max, null, null);
        }

        /**
        **  Creates a LabelControl instance with the specified image. The
        **  label is centered vertically and horizontally in display area
        **
        ** @param image the image to be displayed by the label
        */
        public StatusBarProgressControl(String formatString,
                                        Formatter formatter)
        {
            this(JProgressBar.HORIZONTAL, 0, 100, formatString, formatter);
        }

        public StatusBarProgressControl(int orient, int min, int max,
                                        String formatString,
                                        Formatter formatter)
        {
            super(orient, min, max);
            _controlSupport = new ControlSupportHC(this);
            InfoBusManager.getInstance().addInfoBusManagerListener(this);
            // JProgressBars don't get focus
            _controlSupport.setFocusValidated(false);
            _formatString = formatString;
            _formatter = formatter;
            setBorderPainted(true);
            setStringPainted(true);

            _updateAllValues(_controlSupport.getDataItems());
        }

        /**
        ** StatusBarProgressControl override. <P>
        **
        ** @return the maximum Dimensions of the StatusBarProgressControl
        */
        public Dimension getMaximumSize()
        {
            return(_progressBarSize);
        } // getPreferredSize

        public void setMaximumSize(Dimension dim)
        {
            dim.height = _progressBarSize.height;
            super.setMaximumSize(dim);
        }

        /**
        ** StatusBarProgressControl override. <P>
        **
        ** @return the minimum Dimensions of the StatusBarProgressControl
        */
        public Dimension getMinimumSize()
        {
            return(_progressBarSize);
        } // getPreferredSize

        public void setMinimumSize(Dimension dim)
        {
            dim.height = _progressBarSize.height;
            super.setMinimumSize(dim);
        } // setPreferredSize

        /**
        ** StatusBarProgressControl override. <P>
        **
        ** @return the preferred Dimensions of the StatusBarProgressControl
        */
        public Dimension getPreferredSize()
        {
            return(_progressBarSize);
        } // getPreferredSize

        public void setPreferredSize(Dimension dim)
        {
            dim.height = _progressBarSize.height;
            super.setPreferredSize(dim);
        }

        public void setSize(Dimension dim)
        {
            dim.height = _progressBarSize.height;
            super.setSize(dim);
        }
    
        public void setSize(int width, int height)
        {
            height = _progressBarSize.height;
            super.setSize(width, height);
        }
    
        /**
        ** Sets the format string to be used when displaying the value. <P>
        **
        ** The format string should be a format string as supported by the
        ** DefaultNumberFormatter.
        **
        ** @param nuFormatString The format string
        ** @see #getFormatString()
        ** @see oracle.dacf.formatter.DefaultNumberFormatter
        */
        public void setFormatString(String nuFormatString)
        {
            _formatString = nuFormatString;
            if (_controlSupport != null)
            {
                _updateAllValues(_controlSupport.getDataItems());
            }
        } // setFormatString

        /**
        ** Returns the format string to be used when displaying the value. <P>
        **
        ** The format string should be a format string as supported by the
        ** DefaultNumberFormatter.
        **
        ** @return a reference to the format string.
        ** @see #setFormatString(String nuFormatString)
        ** @see oracle.dacf.formatter.DefaultNumberFormatter
        */
        public String getFormatString()
        {
            return(_formatString);
        } // getFormatString

        /**
        **  Sets the formatter for the ProgressControl
        **
        **  @param formatter the new formatter for the progress control
        */
        public void setFormatter(Formatter formatter)
        {
            _formatter = formatter;
            if (_controlSupport != null)
            {
                _updateAllValues(_controlSupport.getDataItems());
            }
        }// setFormatter

        /**
        **  Returns the formatter for the ProgressControl
        **
        **  @return the new formatter for the progress control
        */
        public Formatter getFormatter()
        {
            return(_formatter);
        } // getFormatter

        // InfoBusManagerListener interface implementation
        public void releaseResources(InfoBusManagerReleaseEvent e)
        {
            if (e.appliesTo(this))
            {
                InfoBusManager.getInstance().removeInfoBusManagerListener(this);
                _controlSupport = null;
            }
        }
        
        // Control Interface

        /**
        ** Returns the name of the InfoBus this control is connected to. <P>
        **
        ** @return  The name of the InfoBus this control is connected to.
        ** @see Control#getInfoBusName
        */
        public final String getInfoBusName()
        {
            return(_controlSupport == null ?
                   null : _controlSupport.getInfoBusName());
        }

        /**
        ** An override of java.awt.Component.setEnabled. <P>
        **
        ** @param b boolean flag indicating whether the control is enabled
        */
        public void setEnabled(boolean b)
        {
            super.setEnabled(b);
        } // setEnabled

        /**
        ** Sets the name of the InfoBus this control is connected to. <P>
        **
        ** By default, the control is connected to the default InfoBus,
        ** named <TT>Control.DEFAULT_INFOBUS_NAME</TT>. <P>
        **
        ** If the named InfoBus does not exist, it is created automatically.<P>
        **
        ** If the control is already connected to an InfoBus, it is
        ** disconnected first. <P>
        **
        ** @param infoBusName   The name of the InfoBus to connect to.
        ** @see Control#DEFAULT_INFOBUS_NAME
        ** @see Control#setInfoBusName
        */
        public final void setInfoBusName(String infoBusName)
        {
            if (_controlSupport != null)
            {
                _controlSupport.setInfoBusName(infoBusName);
            }
        }

        /**
        ** Returns the name of the bound InfoBus DataItem.
        **
        ** @return  The name of the InfoBus DataItem this control is bound to,
        **          or <TT>null</TT> if the control is unbound.
        ** @see #getDataItem
        ** @see Control#getDataItemName
        */
        public final String getDataItemName()
        {
            return(_controlSupport == null ?
                   null : _controlSupport.getDataItemName());
        }

        /**
        ** Sets the name of the InfoBus DataItem this control is bound to. <P>
        **
        ** The DataItem with the given name is searched for on the InfoBus, and
        ** if found, is bound to this control. <P>
        **
        ** If the control is already bound to a DataItem, it is unbound first.
        **
        ** @param dataItemName  The name of the DataItem to bind to.
        ** @see #getDataItem
        ** @see Control#setDataItemName
        */
        public final void setDataItemName(String dataItemName)
        {
            if (_controlSupport != null)
            {
                _controlSupport.setDataItemName(dataItemName);
            }
        }

        /**
        ** Returns the InfoBus DataItem this control is bound to. <P>
        **
        ** @return  The InfoBus DataItem this control is bound to, or
        **          <TT>null</TT> if the control is unbound.
        ** @see Control#getDataItem
        */
        public final Object getDataItem()
        {
            return(_controlSupport == null ?
                   null : _controlSupport.getDataItem());
        }

        /**
        ** Returns the names of the bound InfoBus DataItem.
        **
        ** @return  The name of the InfoBus DataItem this control is bound to,
        **          or <TT>null</TT> if the control is unbound.
        ** @see #getDataItem
        ** @see Control#getDataItemName
        */
        public final String[] getDataItemNames()
        {
            return(_controlSupport == null ?
                   null : _controlSupport.getDataItemNames());
        }

        /**
        ** Sets the name of the InfoBus DataItems this control is bound to. <P>
        **
        ** The DataItem with the given name is searched for on the InfoBus, and
        ** if found, is bound to this control. <P>
        **
        ** If the control is already bound to a DataItem, it is unbound first.
        **
        ** @param dataItemName  The name of the DataItem to bind to.
        ** @see #getDataItem
        ** @see Control#setDataItemName
        */
        public final void setDataItemNames(String[] dataItemNames)
        {
            if (_controlSupport != null)
            {
                _controlSupport.setDataItemNames(dataItemNames);
            }
        }

        /**
        ** Returns the InfoBus DataItem this control is bound to. <P>
        **
        ** @return  The InfoBus DataItem this control is bound to, or
        **          <TT>null</TT> if the control is unbound.
        ** @see Control#getDataItem
        */
        public final Object[] getDataItems()
        {
            return(_controlSupport == null ?
                   null : _controlSupport.getDataItems());
        }

        /**
        ** Notifies the control that the bound InfoBus DataItem has changed.<P>
        **
        ** @param oldDataItem The formerly bound DataItem (can be null).
        ** @param newDataItem The newly bound DataItem (can be null).
        ** @see Control#dataItemChanged
        */
        public final void dataItemChanged(Object oldDataItem,
                                          Object newDataItem)
        {
            // Don't care
        }

        /**
        ** Returns the AWT component associated with this control. <P>
        **
        ** @return  The AWT component for this control.
        ** @see Control#getComponent
        */
        public final Component getComponent()
        {
            return(this);
        }

        /**
        ** Determines whether focus into this control causes validation to
        ** occur. <P>
        **
        ** @return  Always false
        ** @see Control#isFocusValidated
        */
        public final boolean isFocusValidated()
        {
            // ProgressBars don't get focus
            return(false);
        }

        /**
        **  This method is a no-op that is it has no effect
        */
        public final void setFocusValidated(boolean focusValidated)
        {
            // ProgressBars don't get focus
        }

        /**
        **  This method is a no-op that is it has no effect
        */
        public final void addNavigatedListener(NavigatedListener listener)
        {
            // ProgressBars don't get focus
        }

        /**
        **  This method is a no-op that is it has no effect
        */
        public final void removeNavigatedListener(NavigatedListener listener)
        {
            // ProgressBars don't get focus
        }

        /**
        **  This method is a no-op that is it has no effect
        */
        public final void processNavigatedEvent(NavigatedEvent event)
        {
            // ProgressBars don't get focus
        }

        /**
        **  This method is a no-op that is it has no effect
        */
        public final void addNavigatingListener(NavigatingListener listener)
        {
            // ProgressBars don't get focus
        }

        /**
        **  This method is a no-op in that it has no effect
        */
        public final void removeNavigatingListener(NavigatingListener listener)
        {
            // ProgressBars don't get focus
        }

        /**
        **  This method is a no-op in that it has no effect
        **  @exception  NavigatingException  Indicates navigation was rejected.
        */
        public final void processNavigatingEvent(NavigatingEvent event)
            throws NavigatingException
        {
            // ProgressBars don't get focus
        }

        // DataItemChangeListener Interface

        /**
        ** Indicates a changed value in the bound data item. <P>
        **
        ** A reference to the data item that changed can be obtained from the
        ** event. <P>
        **
        ** @param event Contains change information.
        ** @see javax.infobus.DataItemChangeListener#dataItemValueChanged
        */
        public final void dataItemValueChanged(DataItemValueChangedEvent event)
        {
            if (_controlSupport != null)
            {
                _updateAllValues(_controlSupport.getDataItems());
            }
        }

        /**
        ** Indicates that a new item was added to the bound aggregate data item
        ** (e.g. <TT>ArrayAccess</TT>, a JDK Collection, etc). <P>
        **
        ** A reference to the data item that was added, and a reference to the
        ** one that gained it, can be obtained from the event. <P>
        **
        ** Has no effect on the StatusBarLabelControl.<P>
        **
        ** @param event Contains details of the addition.
        ** @see javax.infobus.DataItemChangeListener#dataItemAdded
        */
        public final void dataItemAdded(DataItemAddedEvent event)
        {
            // Not applicable
        }

        /**
        ** Indicates that an item was deleted from the bound aggregate data
        ** item (e. g. <TT>ArrayAccess</TT>, a JDK Collection, etc). <P>
        **
        ** A reference to the data item that was deleted, and a reference to
        ** the one that lost it, can be obtained from the event. <P>
        **
        ** Has no effect on the StatusBarLabelControl.<P>
        *
        ** @param event Contains details of the deletion.
        ** @see javax.infobus.DataItemChangeListener#dataItemDeleted
        */
        public final void dataItemDeleted(DataItemDeletedEvent event)
        {
            // Not applicable
        }

        /**
        ** Indicates that the bound data item (and its sub-items, if any) has
        ** been revoked, and is temporarily unavailable. <P>
        **
        ** A reference to the data item that was revoked can be obtained from
        ** the event. <P>
        **
        ** @param event Contains details of the revoked data.
        ** @see javax.infobus.DataItemChangeListener#dataItemRevoked
        */
        public final void dataItemRevoked(DataItemRevokedEvent event)
        {
        }

        /**
        ** Indicates that the cursor for the bound <TT>RowsetAccess</TT> data
        ** item has changed rows. <P>
        **
        ** A reference to the rowset data item can be obtained from the event.
        **
        ** @param event Contains details of the cursor move.
        ** @see javax.infobus.DataItemChangeListener#rowsetCursorMoved
        */
        public final void rowsetCursorMoved(RowsetCursorMovedEvent event)
        {
            // Not applicable
        }

        // Private Methods


        private void _updateAllValuesLater(final Object[] dataItem)
        {
            SwingUtilities.invokeLater(new Runnable() {
                public void run() {
                    _updateAllValues(dataItem);
                }
            });
        }

        private void _updateAllValues(Object[] dataItems)
        {
            double percent;
            String txt;
            Object value = null;

            synchronized(_lockObj)
            {
                Object[] diList = getDataItems();

                if (diList != null && diList.length >= 2 &&
                    diList[0] != null && diList[1] != null)
                {
                    double d = 1;
                    double n = 0;
                    int v = 0;

                    value =
                        ((ImmediateAccess)diList[0]).getValueAsObject();
                    if (value != null)
                    {
                        d = ((Long)value).doubleValue();
                    }
                    value =
                        ((ImmediateAccess)diList[1]).getValueAsObject();
                    if (value != null)
                    {
                        n = ((Integer)value).doubleValue();
                    }
                    try
                    {
                        v = (int)((n/d)*100);
                    }
                    catch(Exception e)
                    {
                    }
                    setValue(v);
                }
                else
                {
                    setValue(0);
                }
            }

            percent = getPercentComplete();

            if (_formatString != null)
            {
                if (_formatter != null)
                {
                    try
                    {
                        txt = _formatter.format(_formatString,
                                                new Double(percent*100.0));
                    }
                    catch(Exception e)
                    {
                        // fall back to the case where there's no formatter
                        txt = (percent*100.0) + "%";
                    }
                }
                else
                {
                    txt = (percent*100.0) + "%";
                }
                if (txt != null && !txt.equals(""))
                {
                    setString(txt);
                }
            }
        }

        private void _debug(String s)
        {
            if (_DEBUG)
            {
                System.out.println("StatusBarLabelControl: " + s);
            }
        } // _debug
    } // StatusBarProgressControl
}  // StatusBar


/*
**   oracle/dacf/control/swing/StatusBar.java
**
**   Copyright (c) 1998 by Oracle Corporation
**   All rights reserved.
*/


