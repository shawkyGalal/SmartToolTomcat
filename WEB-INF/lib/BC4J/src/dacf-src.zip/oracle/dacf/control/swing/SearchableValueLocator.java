/*
 * @(#)SearchableValueLocator.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.dacf.control.swing;

import javax.infobus.ImmediateAccess;
import javax.infobus.ScrollableRowsetAccess;
import oracle.dacf.dataset.DacObject;
import oracle.dacf.dataset.SearchableRowsetAccess;

// imports
/**
 ** Locates value using Searchable RowsetAccess
 **
 */
public class SearchableValueLocator
    implements ComboBoxDataSource.ValueLocator
{
	String[] _keyColNames = null;

	boolean  _refreshKeyColumnNames = true;

	
	public SearchableValueLocator()
	{

	}

        // bug 2382729
        private boolean _nullValuesAllowed = true;

        public boolean getNullValuesAllowed()
        {
           return _nullValuesAllowed;
        }

        public void setNullValuesAllowed(boolean nullValuesAllowed)
        {
           _nullValuesAllowed = nullValuesAllowed;
        }

	/**
	*  When the list value data item name on the Control is
	*  changed, the locator class is notified, so that the 
	*  key column names can be changed. By default the DefaultValueLocator
	*  updates the key columns. But, if this behaviour is not desirable set 
	*  this flag to false. You may want to set this flag to false, when 
	*  you have set the key column name list through setKeyColumnNames
	*  method.
	*/
	public void setRefreshKeyColumnNames(boolean flag)
	{
		_refreshKeyColumnNames = flag;
	}

	public boolean getRefreshKeyColumnNames( )
	{
		return _refreshKeyColumnNames ;
	}

	/**
	*  Specify the key column names for the detail rowset
	*  
	*  The key column name is derived from the column name 
	*  of the ListValueDataItemName. If there are more key 
	*  columns involved specify the column names using this 
	*  method.
	*
	*/
	public void setKeyColumnNames(String[] names)
	{
		this._keyColNames = names;
	}

	public String[] getKeyColumnNames()
	{
		return _keyColNames;
	}

	
	// Implement ComboBoxControl.ValueLocator

    public int findIndexInMaster(ImmediateAccess searchFor, 
                                 ScrollableRowsetAccess masterRowset,
								 ScrollableRowsetAccess detailRowset)
	{
		int ret = 0;

		if (masterRowset instanceof SearchableRowsetAccess)
		{
			SearchableRowsetAccess srch = (SearchableRowsetAccess)masterRowset;

			ret = _doSearch(searchFor, srch, detailRowset);
		}

		return ret;
	}

	public void updateKeyColumnName(String newListValueDataItemName, 
											ComboBoxControl c)
	{
		if (_refreshKeyColumnNames)
		{
			String name = _getColumnNameFromDataItemName(newListValueDataItemName);
			
            setKeyColumnNames(new String[] { name });
		}
	}

    protected String _getColumnNameFromDataItemName(String dataItemName)
	{
		int i = dataItemName.lastIndexOf(DacObject.ITEMNAME_DELIMITER);

		if (i != -1)
			return dataItemName.substring(i+1);

		return null;
	}

	// search using SearchableRowsetAccess., which performs the search in
	// the middle tier
	protected int _doSearch(ImmediateAccess searchFor, 
						   SearchableRowsetAccess srchRowset,
						   ScrollableRowsetAccess detailRowset)
	{
		try
		{
			String colNames[] = getKeyColumnNames();

			Object values[] = getKeyColumnValues(colNames, detailRowset);

			return (srchRowset.findRangeIndexOf(colNames, values));
		}
		catch(Exception exc)
		{
			return -1;
		}
	}

	protected Object[] getKeyColumnValues(String[] colNames, 
								ScrollableRowsetAccess detailRowset)
		throws javax.infobus.ColumnNotFoundException,
			   javax.infobus.DuplicateColumnException,
			   java.sql.SQLException
	{
		Object[] values = new Object[colNames.length];
		
		for (int i=0; i < colNames.length; i++)
		{
			ImmediateAccess ia = (ImmediateAccess)detailRowset.getColumnItem(
												colNames[i]);
			values[i] = ia.getValueAsObject();
		}
		return values;
	}

			
}  // SearchableValueLocator
    


