/*
 * @(#)GridControlTable.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.dacf.control.swing;

import java.awt.Color;
import java.awt.Component;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.awt.event.KeyEvent;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.beans.PropertyChangeListener;
import java.util.EventObject;
import java.util.Vector;
import javax.infobus.ScrollableRowsetAccess;
import javax.swing.AbstractAction;
import javax.swing.DefaultListSelectionModel;
import javax.swing.JTable;
import javax.swing.KeyStroke;
import javax.swing.ListSelectionModel;
import javax.swing.event.ChangeEvent;
import javax.swing.event.MouseInputAdapter;
import javax.swing.event.TableModelEvent;
import javax.swing.table.TableCellEditor;
import javax.swing.table.TableColumn;
import javax.swing.table.TableColumnModel;
import oracle.dacf.control.NavigationManager;
import oracle.dacf.dataset.InfoObject;

// imports
/**
 * This class overrides methods in the JFC <TT>JTable</TT> class to intercept
 * focus, selection, and editing changes. <P>
 */
class GridControlTable
    extends JTable
    implements FocusListener
{
    private GridControl _gridControl;
    GridSelectionModel _rowSelectionModel = new GridSelectionModel();
    GridSelectionModel _colSelectionModel = new GridSelectionModel();
    private volatile boolean _tabNavigatesInSelection = true;
    private volatile boolean _isCompoundSelectionUpdate = false;
    private NavigationManager _navMgr;
    private int _newColumn;
    private Color _focusedSelectionForeground;
    private Color _focusedSelectionBackground;
    private Color _unfocusedSelectionForeground = Color.white;
    private Color _unfocusedSelectionBackground = Color.gray;
    private GridCellEditor _editor;
    private Vector _mouseListeners;
    private Vector _mouseMotionListeners;
    private static final boolean _DEBUG = false;

    private int mIsFocusTraversable = -1;
    
    // Our notion of currently focused/selected [row,column]
    // These may be different than the values stored in
    // in the selection models. Selection model values are destroyed
    // on clearSelection but these values are not cleared and are used
    // for validating selection change requests.

    
    /**
    * Contstructs a new table. <P>
    * @param gridControl   The control associated with this table.
    */
    GridControlTable(GridControl gridControl)
    {
        _gridControl = gridControl;
        _navMgr = NavigationManager.getNavigationManager();

        _rowSelectionModel.setOtherGSM(_colSelectionModel);
        _colSelectionModel.setOtherGSM(_rowSelectionModel);
        _colSelectionModel.setIsColumn(true);
        _focusedSelectionForeground = getSelectionForeground();
        _focusedSelectionBackground = getSelectionBackground();

        setSelectionModel(_rowSelectionModel);
        getColumnModel().setSelectionModel(_colSelectionModel);

        setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        addFocusListener(this);
        addFocusListener(_editor);
        setSelectionForeground(_unfocusedSelectionForeground);
        setSelectionBackground(_unfocusedSelectionBackground);
        sizeColumnsToFit(AUTO_RESIZE_ALL_COLUMNS);

        _hijackMouseListeners();
        _hijackKeyStrokeActions();
        
        addMouseListener(new GridMouseListener(gridControl));
    }

    protected void createDefaultEditors()
    {
        super.createDefaultEditors();
        
        _editor = new GridCellEditor(new GridCellField());
        setDefaultEditor(Object.class, _editor);
    }

    public boolean editCellAt(int row, int column, EventObject e)
    {
        // _debug("editCellAt: row: " + row + " col: " + column);
        return(super.editCellAt(row, column, e));
    }

    public void addMouseListener(MouseListener l)
    {
        if (_mouseListeners == null)
        {
            _mouseListeners = new Vector(1);
        }
        _mouseListeners.addElement(l);
    }

    public void removeMouseListener(MouseListener l)
    {
        if (_mouseListeners != null)
        {
            _mouseListeners.removeElement(l);
        }
    }
    
    public void addMouseMotionListener(MouseMotionListener l)
    {
        if (_mouseMotionListeners == null)
        {
            _mouseMotionListeners = new Vector(1);
        }
        _mouseMotionListeners.addElement(l);
    }

    public void removeMouseMotionListener(MouseMotionListener l)
    {
        if (_mouseMotionListeners != null)
        {
            _mouseMotionListeners.removeElement(l);
        }
    }
    
    public void focusGained(FocusEvent e)
    {
        // _debug("changing to the focused selection color");
        setSelectionForeground(_focusedSelectionForeground);
        setSelectionBackground(_focusedSelectionBackground);
        repaint();
    }

    public void focusLost(FocusEvent e)
    {
        // _debug("changing to the unfocused selection color");
        if (!isEditing())
        {
            setSelectionForeground(_unfocusedSelectionForeground);
            setSelectionBackground(_unfocusedSelectionBackground);
        }
        repaint();
    }
    
    
    /** Informs Swing that we are managing focus within the grid
    *
    * @return true
    */
    public boolean isManagingFocus()
    {
        return true;
    }
    
    /**
    * Override the focus traversable algorithm that is used
    * by Swing.
    */
    public void setFocusTraversable(boolean isFocusTraversable)
    {
       if (isFocusTraversable)
       {
          mIsFocusTraversable = 1;
       }
       else
       {
          mIsFocusTraversable = 0;
       }
    }

    public boolean isFocusTraversable()
    {
       boolean isFocusTraversable = true;

       // Accept the value as evaluated by Swing unless the developer has
       // explicitly overriden.
       if (mIsFocusTraversable == -1)
       {
          isFocusTraversable = super.isFocusTraversable();
       }
       else if (mIsFocusTraversable == 0)
       {
          isFocusTraversable = false;
       }

       return isFocusTraversable;
    }


    public void setColumnModel(TableColumnModel newModel)
    {
        TableColumn column;
        
        if (_colSelectionModel != null)
        {
            _colSelectionModel._reset();
            if (newModel != null)
            {
                newModel.setSelectionModel(_colSelectionModel);
            }
        }

        super.setColumnModel(newModel);
    }

    public void setSelectionMode(int mode)
    {
        super.setSelectionMode(mode);
        if ( mode == ListSelectionModel.MULTIPLE_INTERVAL_SELECTION )
        {
            _gridControl.setForceReadOnly(true);
        }
    }

    /**
    * Notification that the number of rows has changed in the table. <P>
    * This method fixes a bug in the Swing 1.0.1 <TT>JTable</TT> where it
    * does not repaint correctly when the number of rows decreases. <P>
    * @param event The event.
    */
    public void tableChanged(TableModelEvent event)
    {
        // XXX - repaint bug in grid in swing 1.0.1
        super.tableChanged(event);

        // DLK 1/29/99: commented out to resolve repaint problems in swing 1.1
        // Can you say regression?  Sure you can.  I knew you could
        // if (event.getType() == TableModelEvent.DELETE)
        {
            resizeAndRepaint();
        }
    }

    /**
    * Invoked when editing is finished. The changes are saved, the
    * editor object is discarded, and the cell is rendered once again.
    *
    * If the editor used is a DAC control then it is assumed that the
    * DAC control will by itself update the column and the table model
    * will be updated indirectly as a result of this update.
    *
    * @see CellEditorListener
    */
    public void editingStopped(ChangeEvent e)
    {
        // Take in the new value
        TableCellEditor editor = getCellEditor();

        // _debug("editingStopped");
        if (editor != null && !(editor instanceof DacCellEditor))
        {
            Object value = editor.getCellEditorValue();
            
            try
            {
                setValueAt(value, editingRow, editingColumn);
                removeEditor();
            }
            catch(RuntimeException exc)
            {
                removeEditor();
                throw exc;
            }
        }
    }

    /**
    **  Controls how Tab or Shift-Tab will cause the selection to move.<p>
    **
    **  When true the following rules apply:
    **  <ul>
    **  <li>Tab: if the selection anchor is on the last column of a row, the
    **      selection anchor will move to the first column within the current
    **      selection.</li>
    **  <li>Shift-Tab: if the selection anchor is on the last column of a row,
    **      the selection anchor will move to the first column within the
    **      current selection.</li>
    **  </ul>
    **  When false:
    **  <ul>
    **  <li>Tab: if the selection anchor is on the last column of a row, the
    **      selection anchor will move to the first column of the following
    **      row if that row exists.</li>
    **  <li>Shift-Tab: if the selection anchor is on the first column of a row,
    **      the selection anchor will move to the last column of the previous
    **      row if that row exists.</li>
    **  </ul>
    */
    boolean _getTabNavigatesInSelection()
    {
        return(_tabNavigatesInSelection);
    }

    /**
    **  Controls how Tab or Shift-Tab will cause the selection to move.<p>
    **
    **  When true the following rules apply:
    **  <ul>
    **  <li>Tab: if the selection anchor is on the last column of a row, the
    **      selection anchor will move to the first column within the current
    **      selection.</li>
    **  <li>Shift-Tab: if the selection anchor is on the last column of a row,
    **      the selection anchor will move to the first column within the
    **      current selection.</li>
    **  </ul>
    **  When false:
    **  <ul>
    **  <li>Tab: if the selection anchor is on the last column of a row, the
    **      selection anchor will move to the first column of the following
    **      row if that row exists.</li>
    **  <li>Shift-Tab: if the selection anchor is on the first column of a row,
    **      the selection anchor will move to the last column of the previous
    **      row if that row exists.</li>
    **  </ul>
    */
    void _setTabNavigatesInSelection(boolean tabNavigatesInSelection)
    {
        _tabNavigatesInSelection = tabNavigatesInSelection;
    }

    void _setFocusedSelectionForeground(Color focusedSelectionColor)
    {
        _focusedSelectionForeground = focusedSelectionColor;
        if (hasFocus())
        {
            setSelectionForeground(_focusedSelectionForeground);
        }
    } // _setFocusedSelectionColor
    
    Color _getFocusedSelectionForeground()
    {
        return(_focusedSelectionForeground);        
    } // _getFocusedSelectionColor
    
    void _setUnfocusedSelectionForeground(Color unfocusedSelectionColor)
    {
        _unfocusedSelectionForeground = unfocusedSelectionColor;        
        if (!hasFocus())
        {
            setSelectionForeground(_unfocusedSelectionForeground);
        }
    } // _setUnfocusedSelectionColor
    
    Color _getUnfocusedSelectionForeground()
    {
        return(_unfocusedSelectionForeground);        
    } // _getUnfocusedSelectionColor
    
    void _setFocusedSelectionBackground(Color focusedSelectionColor)
    {
        _focusedSelectionBackground = focusedSelectionColor;
        if (hasFocus())
        {
            setSelectionBackground(_focusedSelectionBackground);
        }
    } // _setFocusedSelectionBackground
    
    Color _getFocusedSelectionBackground()
    {
        return(_focusedSelectionBackground);        
    } // _getFocusedSelectionColor
    
    void _setUnfocusedSelectionBackground(Color unfocusedSelectionColor)
    {
        _unfocusedSelectionBackground = unfocusedSelectionColor;        
        if (!hasFocus())
        {
            setSelectionBackground(_unfocusedSelectionBackground);
        }
    } // _setUnfocusedSelectionBackground
    
    Color _getUnfocusedSelectionBackground()
    {
        return(_unfocusedSelectionBackground);        
    } // _getUnfocusedSelectionBackground
    
    // called out from rowsetCursorMoved() in GridControl.java
    void _updateSelectedRow(int row)
    {
        // Bypass validations because the current row was moved within the
        // dataitem as the grid is just responding to that movement which by
        // definition is valid.
        int[] rows = getSelectedRows();
            
        if (_rowSelectionModel.getSelectionMode() ==
            _rowSelectionModel.SINGLE_SELECTION || rows.length <= 1)
        {
            _rowSelectionModel._setSelectionInterval(row, row);
        }
        else
        {
            if (_rowSelectionModel.getAnchorSelectionIndex() != row)
            {
                int lead =
                    (_rowSelectionModel.getSelectionMode() ==
                     _rowSelectionModel.SINGLE_SELECTION ? row :
                     _rowSelectionModel.getLeadSelectionIndex());
                
                _rowSelectionModel._setAnchorAndLead(row, lead);
            }
        }

        if (_gridControl.isScrollToSelectedRow())
        {
            _ensureRowIsVisible(row);
        }
    }

    void _ensureRowIsVisible(int row)
    {
       scrollRectToVisible(getCellRect(row,0,false));
    }

    GridControl _getGridControl()
    {
        return(_gridControl);
    }
    
    private void _hijackMouseListeners()
    {
        GridMouseMonitor mouselistener = new GridMouseMonitor();
        super.addMouseListener(mouselistener);
        super.addMouseMotionListener(mouselistener);
    }

    private void _hijackKeyStrokeActions()
    {
        KeyStroke[] ks = getRegisteredKeyStrokes();
        
        if (ks != null)
        {
            int cond;
            ActionListener al;
            InterceptGridKeyStrokeAction w;

            // _debug("hijacking keystrokes");
            for(int i = 0; i < ks.length; i++)
            {
                cond = getConditionForKeyStroke(ks[i]);
                al = getActionForKeyStroke(ks[i]);
                if (ks[i].getKeyCode() == KeyEvent.VK_TAB)
                {
                    if (ks[i].getModifiers() == 0) // tab
                    {
                        w = new GridTabAction(al);
                    }
                    else
                    {
                        if (ks[i].getModifiers() == KeyEvent.SHIFT_MASK)
                        {
                            w = new GridShiftTabAction(al);
                        }
                        else
                        {
                            w = new InterceptGridKeyStrokeAction(al);
                        }
                    }
                }
                else
                {
                    w = new InterceptGridKeyStrokeAction(al);
                }
                unregisterKeyboardAction(ks[i]);
                registerKeyboardAction(w, ks[i], cond);
            }
        }
    }
    
    private synchronized void beginCompoundSelectionUpdate()
    {
        _isCompoundSelectionUpdate = true;
    }

    private synchronized void endCompoundSelectionUpdate()
    {
        _isCompoundSelectionUpdate = false;
    }

    private boolean isCompoundSelectionUpdate()
    {
        return(_isCompoundSelectionUpdate);
    }

    private void synchronizeToSelection()
    {
        int prevRow = -1;
        int prevCol = -1;
        int curRow = _rowSelectionModel.getAnchorSelectionIndex();
        int curCol = _colSelectionModel.getAnchorSelectionIndex();
        boolean hasFocus = (_navMgr.getFocusedControl() == _gridControl);

        // _debug("synchronizeToSelection: from " + prevRow + "," + prevCol +
        //        " to " + curRow + "," + curCol);
        // _debug("hasFocus: " + hasFocus);
        if (hasFocus)
        {
            prevRow = _rowSelectionModel.getPreviousAnchorSelectionIndex();
            prevCol = _colSelectionModel.getPreviousAnchorSelectionIndex();
        }
        if (curRow != prevRow || curCol != prevCol)
        {
            if (!_validateFocus(prevRow, prevCol, curRow, curCol))
            {
                // _debug("validateFocus failed");
                if (isEditing())
                {
                    getCellEditor().stopCellEditing();
                }

                _resetSelection(_colSelectionModel, prevCol);
                _resetSelection(_rowSelectionModel, prevRow);
            }
        }
    }

    boolean _moveCurrentRow()
    {
        // _debug("validateFocus succeeded; moving currency");
        Object di = _gridControl.getDataItem();
        int curRow = _rowSelectionModel.getAnchorSelectionIndex();
        boolean res = false;
        
        if (di != null &&
            di instanceof ScrollableRowsetAccess)
        {
            int diRow = ((ScrollableRowsetAccess)di).getRow();

            if (curRow+1 != diRow)
            {
                try
                {
                    // _debug("_moveCurrentRow: setting curRow");
                    ((ScrollableRowsetAccess)di).absolute(curRow+1);
                    res = true;
                }
                catch(Exception ex)
                {
                    return false;
                }
            }
            else
            {
                // _debug("rows already in sync: curRow: " + (curRow+1) +
                //        " diRow: " + diRow);
                res = true;
            }
        }
        return(res);
    }
    private void _resetSelection(GridSelectionModel gsm, int index)
    {
        if (gsm.isSelectedIndex(index))
        {
            gsm._setAnchorAndLead(index, gsm.getPreviousLeadSelectionIndex());
        }
        else
        {
            gsm._reset();
            gsm._setSelectionInterval(index, index);
        }
    }
    

    /**
    * Validates a change of focus within the grid using the
    * <TT>NavigationManager</TT>. <P>
    * For internal use only. <P>
    * @param fromRow       The row that used to have focus (-1 if none).
    * @param fromColumn    The column that used to have focus (-1 if none).
    * @param toRow         The new row requesting focus (-1 if none).
    * @param toColumn      The new column requesting focus (-1 if none).
    * @return              <TT>true</TT> if the focus change is allowed.
    */
    private boolean _validateFocus(int fromRow, int fromColumn, int toRow,
                                   int toColumn)
    {
        boolean result = true;

        // _debug("_validateFocus: (" + fromRow + "," + fromColumn + ") to (" +
        //        toRow + "," + toColumn + ")");
        if (_gridControl.isFocusValidated())
        {
            Object dataItem = _gridControl.getDataItem();
            if (dataItem != null && dataItem instanceof ScrollableRowsetAccess)
            {
                String srcItemName =
                    fromColumn == -1 ? null :
                    _gridControl.getColumnDataItemName(convertColumnIndexToModel(fromColumn));
                String tgtItemName =
                    toColumn == -1 ? null :
                    _gridControl.getColumnDataItemName(convertColumnIndexToModel(toColumn));

                result = _navMgr.validateFocusChange(_gridControl, srcItemName,
                                                     tgtItemName,
                                                     (fromRow != toRow));
            }
        }
        return(result);
    }

    private synchronized MouseListener[] _getMouseListeners()
    {
        MouseListener[] listeners =
            new MouseListener[_mouseListeners.size()];

        if (listeners != null)
        {
            _mouseListeners.copyInto(listeners);
        }
        return(listeners);
    }
    
    
    private synchronized MouseMotionListener[] _getMouseMotionListeners()
    {
        MouseMotionListener[] listeners =
            new MouseMotionListener[_mouseMotionListeners.size()];

        if (listeners != null)
        {
            _mouseMotionListeners.copyInto(listeners);
        }
        return(listeners);
    }

    /**
    * Prints debugging to <TT>System.out</TT> if debugging is enabled. <P>
    * @param s The string to output.
    */
    private void _debug(String s)
    {
        if (_DEBUG)
        {
            System.out.println("GridControlTable: " + s);
        }
    }


    /**
    *  This class serves as the row and column selection models for the grid.
    *  It validates a row selection change request before changing the
    *  selection.
    */
    class GridSelectionModel
        extends DefaultListSelectionModel
    {
        private int _oldAnchor = -1;
        private int _oldLead = -1;
        private GridSelectionModel _otherGSM;
        private volatile boolean _isColumn = false;
        private static final int NOCHANGE = -1;
        private static final int INVALID = 0;
        private static final int VALID = 1;
        
        
        public GridSelectionModel()
        {
            super();
            this.setSelectionMode(SINGLE_SELECTION);
            this.setLeadAnchorNotificationEnabled(false);
            _otherGSM = this;
        }

        public void addSelectionInterval(int anchor, int lead)
        {
            // _debug("addSelectionInterval(" + anchor + "," + lead + ")");
            if (getSelectionMode() == SINGLE_SELECTION)
            {
                setSelectionInterval(anchor, lead);
            }
            else
            {
                if (isCompoundSelectionUpdate())
                {
                    super.addSelectionInterval(anchor, lead);
                }
                else
                {
                    _saveAnchorAndLead();
                    _setAnchorAndLead(anchor, lead);
                }
            }
        }
        
        public void setSelectionInterval(int anchor, int lead)
        {
            int res;
            
            // _debug("setSelectionInterval(" + anchor + "," + lead + ") as " +
            //        (_isColumn ? "column" : "row"));
            _saveAnchorAndLead();
            if (isCompoundSelectionUpdate())
            {
                super.setSelectionInterval(anchor, lead);
            }
            else
            {
                res = _validateSelection(anchor, lead);
                if (res != NOCHANGE)
                {
                    if (res == VALID)
                    {
                        super.setSelectionInterval(anchor, lead);
                    }
                    else
                    {
                        if (res == INVALID)
                        {
                            super.setSelectionInterval(_oldAnchor, _oldLead);
                        }
                    }
                }
            }
        }

        public void setAnchorSelectionIndex(int anchor)
        {
            int res;
            int lead = getLeadSelectionIndex();
            
            // _debug("setAnchorSelectionIndex(" + anchor + ") as " +
            //        (_isColumn ? "column" : "row"));
            _saveAnchorAndLead();
            if (isCompoundSelectionUpdate())
            {
                super.setSelectionInterval(anchor, lead);
            }
            else
            {
                res = _validateSelection(anchor, lead);
                if (res != NOCHANGE)
                {
                    if (res == VALID)
                    {
                        super.setAnchorSelectionIndex(anchor);
                    }
                    else
                    {
                        if (res == INVALID)
                        {
                            super.setSelectionInterval(_oldAnchor, _oldLead);
                        }
                    }
                }
            }
        }

        public int getPreviousAnchorSelectionIndex()
        {
            return(_oldAnchor);
        }

        public int getPreviousLeadSelectionIndex()
        {
            return(_oldLead);
        }

        void setOtherGSM(GridSelectionModel other)
        {
            _otherGSM = other;
        }
        

        void setIsColumn(boolean isColumn)
        {
            _isColumn = isColumn;
        }
        
        /**
        ** Doesn't validate the selection interval;
        ** sets min to anchor, max to lead 
        */
        void _setSelectionInterval(int anchor, int lead)
        {
            super.setSelectionInterval(anchor, lead);
        }
        
        void _setAnchorAndLead(int anchor, int lead)
        {
             super.setAnchorSelectionIndex(anchor);
             super.setLeadSelectionIndex(lead);
        }

        void _reset()
        {
            _oldAnchor = -1;
            _oldLead = -1;
            super.clearSelection();
        }

        private void _saveAnchorAndLead()
        {
            _oldAnchor = getAnchorSelectionIndex();
            _oldLead = getLeadSelectionIndex();
        }

        /**
        ** @return -1: no change 0: invalid 1: valid
        */
        private int _validateSelection(int anchor, int lead)
        {
            int mode = getSelectionMode();
            int isValid = NOCHANGE;
            int oldRow = !_isColumn ? _oldAnchor :
                _otherGSM.getPreviousAnchorSelectionIndex();
            int oldCol = _isColumn ? _oldAnchor :
                _otherGSM.getPreviousAnchorSelectionIndex();
            int newRow =
                !_isColumn ? anchor : _otherGSM.getAnchorSelectionIndex();
            int newCol =
                _isColumn ? anchor : _otherGSM.getAnchorSelectionIndex();
            boolean hasFocus = (_navMgr.getFocusedControl() == _gridControl);

            // _debug("_validateSelection: " +
            //        oldRow + "," + oldCol + " to " + newRow + "," + newCol +
            //        " as " + (_isColumn ? "column" : "row"));

            if (oldRow != newRow || oldCol != newCol)
            {
                isValid =
                    (oldRow == -1 || oldCol == -1 || !hasFocus ||
                     _validateFocus(oldRow, oldCol, newRow, newCol)) ?
                    VALID : INVALID;
            }
            if (isValid == NOCHANGE &&
                (mode == ListSelectionModel.SINGLE_INTERVAL_SELECTION ||
                 mode == ListSelectionModel.MULTIPLE_INTERVAL_SELECTION))
            {
                isValid = VALID;
            }
            return(isValid);
        }
        
        private void _debug(String s)
        {
            if (_DEBUG)
            {
                System.out.println("GridSelectionModel: " + s);
            }
        }
    }


    /**
    **  Used to support the column context menu
    */
    class GridMouseListener
        extends MouseInputAdapter
    {
        GridControl  _gridControl;
        JTable  _table;
        ColumnPropertiesPopupMenu _popupMenu;
        
        public GridMouseListener(GridControl gridControl)
        {
            _gridControl = gridControl;
            _table = _gridControl.getTable();
            _popupMenu = _gridControl._getPopupMenu();
        }

        public void mouseClicked(MouseEvent e)
        {
            if ((e.getModifiers() & e.BUTTON3_MASK )== e.BUTTON3_MASK)
            {
                if (_popupMenu == null)
                {
                    _popupMenu = _gridControl._getPopupMenu();
                }
                if (_popupMenu != null)
                {
                    _popupMenu.showMenu((Component)e.getSource(),
                                        e.getX(), e.getY());
                }
                if (_table == null)
                {
                    _table = _gridControl.getTable();
                }
                _table.sizeColumnsToFit(true);
                _table.repaint();
            }
        }

        private String _getColumnDataItemName(int colIndex)
        {
            String srcItemName = "";
            Object di = _gridControl.getDataItem();

            if (di != null && di instanceof ScrollableRowsetAccess)
            {
                String prefix = _gridControl.getDataItemName() +
                    InfoObject.ITEMNAME_DELIMITER;
                srcItemName = prefix +
                    ((ScrollableRowsetAccess)di).getColumnName(colIndex+1);
            }
            return(srcItemName);
        }
    }


    class GridTabAction
        extends GridGenericTabAction
    {
        GridTabAction(ActionListener action)
        {
            super(action);
        }

        public void actionPerformed(ActionEvent e)
        {
            // _debug("GridTabAction: actionPerformed: " + e);
            if (!_tabNavigatesInSelection)
            {
                int columnCount = getColumnCount();
                int column = getSelectedColumn() + 1;
                int row = getSelectedRow();
                if (column >= columnCount)
                {
                    row = (row >= (getRowCount() - 1)) ? 0 : row + 1;
                    column = 0;
                }
                changeSelection(row, column);
            }
            else
            {
                super.actionPerformed(e);
            }
        }
    }

    class GridShiftTabAction
        extends GridGenericTabAction
    {
        GridShiftTabAction(ActionListener action)
        {
            super(action);
        }

        public void actionPerformed(ActionEvent e)
        {
            if (!_tabNavigatesInSelection)
            {
                int row = getSelectedRow();
                int column = getSelectedColumn() - 1;
                if (column < 0)
                {
                    column = getColumnCount() - 1;
                    row = ((row <= 0) ? getRowCount() - 1 : row - 1);
                }
                changeSelection(row, column);
            }
            else
            {
                super.actionPerformed(e);
            }
        }
    }

    class GridGenericTabAction
        extends InterceptGridKeyStrokeAction
    {
        GridGenericTabAction(ActionListener action)
        {
            super(action);
        }

        protected void changeSelection(int row, int column)
        {
            // _debug("GridGenericTabAction.changeSelection: (" + row + "," +
            //        column + ")");
            beginCompoundSelectionUpdate();
            setColumnSelectionInterval(column, column);
            setRowSelectionInterval(row, row);
            endCompoundSelectionUpdate();
            synchronizeToSelection();
        }
    }

    public class InterceptGridKeyStrokeAction
            extends AbstractAction
    {
        private ActionListener _action;
        
        public InterceptGridKeyStrokeAction(ActionListener action)
        {
            _action = action;
        }

        public void actionPerformed(ActionEvent e)
        {
            if (_action != null)
            {
                // _debug("action performed on hijacked keystroke");
                beginCompoundSelectionUpdate();
                _action.actionPerformed(e);
                endCompoundSelectionUpdate();
                synchronizeToSelection();
            }
        }

        public Object getValue(String key)
        {
            Object val = null;
            if (_action != null && _action instanceof AbstractAction)
            {
                val = ((AbstractAction)_action).getValue(key);
            }
            return(val);
        }
        
        public void putValue(String key, Object val)
        {
            if (_action != null && _action instanceof AbstractAction)
            {
                ((AbstractAction)_action).putValue(key,val);
            }
        }

        public boolean isEnabled()
        {
            return(_action != null);
        }

        public void setEnabled(boolean b)
        {
            if (_action != null && _action instanceof AbstractAction)
            {
                ((AbstractAction)_action).setEnabled(b);
            }
        }

        public void addPropertyChangeListener(PropertyChangeListener l)
        {
            if (_action != null && _action instanceof AbstractAction)
            {
                ((AbstractAction)_action).addPropertyChangeListener(l);
            }
        }

        public void removePropertyChangeListener(PropertyChangeListener l)
        {
            if (_action != null && _action instanceof AbstractAction)
            {
                ((AbstractAction)_action).removePropertyChangeListener(l);
            }
        }

        public Object clone()
            throws CloneNotSupportedException
        {
            InterceptGridKeyStrokeAction c =
                (InterceptGridKeyStrokeAction)super.clone();

            return(c);
        }
    }

    protected class GridMouseMonitor
        extends MouseInputAdapter
    {
        public void mouseClicked(MouseEvent e)
        {
            MouseListener[] listeners =
                _getMouseListeners();

            for(int i = 0; i < listeners.length; i++)
            {
                listeners[i].mouseClicked(e);
            }
        }
        
        public void mouseDragged(MouseEvent e)
        {
            MouseMotionListener[] listeners =
                _getMouseMotionListeners();

            for(int i = 0; i < listeners.length; i++)
            {
                listeners[i].mouseDragged(e);
            }
        }
        
        public void mouseEntered(MouseEvent e)
        {
            MouseListener[] listeners =
                _getMouseListeners();

            for(int i = 0; i < listeners.length; i++)
            {
                listeners[i].mouseEntered(e);
            }
        }
        
        public void mouseExited(MouseEvent e)
        {
            MouseListener[] listeners =
                _getMouseListeners();

            for(int i = 0; i < listeners.length; i++)
            {
                listeners[i].mouseExited(e);
            }
        }
        
        public void mouseMoved(MouseEvent e)
        {
            MouseMotionListener[] listeners =
                _getMouseMotionListeners();

            for(int i = 0; i < listeners.length; i++)
            {
                listeners[i].mouseMoved(e);
            }
        }

        public void mousePressed(MouseEvent e)
        {
            MouseListener[] listeners =
                _getMouseListeners();

            beginCompoundSelectionUpdate();
            for(int i = 0; i < listeners.length; i++)
            {
                listeners[i].mousePressed(e);
            }
            endCompoundSelectionUpdate();
        }

        public void mouseReleased(MouseEvent e)
        {
            MouseListener[] listeners =
                _getMouseListeners();

            beginCompoundSelectionUpdate();
            for(int i = 0; i < listeners.length; i++)
            {
                listeners[i].mouseReleased(e);
            }
            endCompoundSelectionUpdate();
            synchronizeToSelection();

        }
    }
}

//
//   oracle/dacf/control/swing/GridControlTable.java
//   Oracle JDeveloper
//   Copyright (c) 2000 by Oracle Corporation
//   All rights reserved. 
//
