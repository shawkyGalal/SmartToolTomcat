/*
 * @(#)TextAreaControlBeanInfo.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.dacf.control.swing;

import java.beans.PropertyDescriptor;

/**
 * bean info class for the text area control
 *
 * @version SDK
 */
public class TextAreaControlBeanInfo
    extends ControlBeanInfoHelper
{
    /**
    * Constructor
    */
    public TextAreaControlBeanInfo()
    {
        super();
    }

    /**
    * get property descriptors for the bean
    *
    * @return PropertyDescriptors specific to this bean
    */
    protected Class getBeanClass()
    {
        return TextAreaControl.class;
    }


    /**
    * get property descriptors for the bean
    *
    * @return PropertyDescriptors specific to this bean
    */
    protected PropertyDescriptor[] getAdditionalPropertyDescriptors()
    {
        try
        {
            // begin JTextArea exposed properties

            PropertyDescriptor caret =
                new PropertyDescriptor("caret", getBeanClass(),
                                       "getCaret", "setCaret");


            PropertyDescriptor caretColor =
                new PropertyDescriptor("caretColor", getBeanClass(),
                                       "getCaretColor", "setCaretColor");


            PropertyDescriptor caretPosition =
                new PropertyDescriptor("caretPosition", getBeanClass(),
                                       "getCaretPosition", "setCaretPosition");


            PropertyDescriptor columns  =
                new PropertyDescriptor("columns", getBeanClass(),
                                       "getColumns", "setColumns");


            PropertyDescriptor  disabledTextColor =
                new PropertyDescriptor("disabledTextColor", getBeanClass(),
                                       "getDisabledTextColor", "setDisabledTextColor");


            PropertyDescriptor document =
                new PropertyDescriptor("document", getBeanClass(),
                                       "getDocument", "setDocument");


            PropertyDescriptor editable =
                new PropertyDescriptor("editable", getBeanClass(),
                                       "isEditable", "setEditable");


            PropertyDescriptor focusAccelerator =
                new PropertyDescriptor("focusAccelerator", getBeanClass(),
                                       "getFocusAccelerator", "setFocusAccelerator");


            PropertyDescriptor highlighter =
                new PropertyDescriptor("highlighter", getBeanClass(),
                                       "getHighlighter", "setHighlighter");


            PropertyDescriptor keymap =
                new PropertyDescriptor("keymap", getBeanClass(),
                                       "getKeymap", "setKeymap");


            PropertyDescriptor lineWrap =
                new PropertyDescriptor("lineWrap", getBeanClass(),
                                       "getLineWrap", "setLineWrap");


            PropertyDescriptor margin =
                new PropertyDescriptor("margin", getBeanClass(),
                                       "getMargin", "setMargin");


            PropertyDescriptor rows =
                new PropertyDescriptor("rows", getBeanClass(),
                                       "getRows", "setRows");


            PropertyDescriptor selectedTextColor =
                new PropertyDescriptor("selectedTextColor", getBeanClass(),
                                       "getSelectedTextColor", "setSelectedTextColor");


            PropertyDescriptor selectionColor =
                new PropertyDescriptor("selectionColor", getBeanClass(),
                                       "getSelectionColor", "setSelectionColor");


            PropertyDescriptor selectionEnd =
                new PropertyDescriptor("selectionEnd", getBeanClass(),
                                       "getSelectionEnd", "setSelectionEnd");


            PropertyDescriptor selectionStart =
                new PropertyDescriptor("selectionStart", getBeanClass(),
                                       "getSelectionStart", "setSelectionStart");


            PropertyDescriptor tabSize =
                new PropertyDescriptor("tabSize", getBeanClass(),
                                       "getTabSize", "setTabSize");


            PropertyDescriptor text =
                new PropertyDescriptor("text", getBeanClass(),
                                       "getText", "setText");

            PropertyDescriptor wrapStyleWord =
                new PropertyDescriptor("wrapStyleWord", getBeanClass(),
                                       "getWrapStyleWord", "setWrapStyleWord");

            // end JTextArea exposed properties

            PropertyDescriptor revertValueOnError =
                new PropertyDescriptor("revertValueOnError", getBeanClass(),
                                       "getRevertValueOnError", "setRevertValueOnError");


            PropertyDescriptor[] ret = {caret, caretColor, caretPosition,
                                        columns, disabledTextColor, document,
                                        editable, focusAccelerator,
                                        highlighter, keymap, lineWrap, margin,
                                        rows, selectedTextColor,
                                        selectionColor, selectionEnd,
                                        selectionStart, tabSize, text,
                                        wrapStyleWord, revertValueOnError};
            return ret;
        }
        catch (Exception exc)
        {
            exc.printStackTrace();
            return null;
        }
    }

}
