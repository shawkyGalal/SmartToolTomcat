/*
 * @(#)DelayedRefreshScrollPane.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.dacf.control.swing;

import java.awt.Point;
import javax.swing.JScrollBar;
import javax.swing.JScrollPane;
import javax.swing.JViewport;

/**
 * A ScrollPane which delays notification of view port
 * change if the user is 'dragging' the scrollbar thumb.
 */
public class DelayedRefreshScrollPane extends JScrollPane
{
  public DelayedRefreshScrollPane()
  {
  }
  /**
  * customize the Swing ScrollPane by creatin our own
  * version of ViewPort instead of the standard Swing
  * version of  viewport. This let's us handle the
  * scroll notification from the scrollbar differently.
  */
  protected JViewport createViewport()
  {
        return new DelayedRefreshViewport(this);
  }
}

/**
* View port class which delays viewport start change
* notification, if the user is dragging.
*/
class DelayedRefreshViewport extends JViewport
{
    JScrollPane parent = null;
    JScrollBar hsb = null;
    JScrollBar vsb = null;
    public DelayedRefreshViewport(JScrollPane parent)
    {
        this.parent = parent;
    }

    public void setViewPosition(Point p)
    {
        // cache the scrollbars of the scroll pane
        if ( hsb == null || vsb == null)
        {
            hsb = parent.getHorizontalScrollBar();
            vsb = parent.getVerticalScrollBar();
        }

        if ( hsb != null  && vsb != null)
        {
            // check if the end user has made up his mind
            if ( hsb.getValueIsAdjusting() || vsb.getValueIsAdjusting())
                return; // delay view start change
        }
        super.setViewPosition(p); // user has decided
    }
}
