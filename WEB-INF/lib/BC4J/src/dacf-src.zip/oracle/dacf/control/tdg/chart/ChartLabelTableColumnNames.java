/*
 * @(#)ChartLabelTableColumnNames.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.dacf.control.tdg.chart;

import javax.infobus.DataItem;
import javax.infobus.RowsetAccess;
import oracle.dacf.dataset.DataItemProperties;

/**
 * chart labels derived from column names of the table
 */
class ChartLabelTableColumnNames extends ChartLabelDataSourceImpl
{
    
    ChartLabelTableColumnNames(ChartDataSource parent)
    {
       super(parent);
    }

    public void setDataItemName(String dataItemName)
    {
       super.setDataItemName(dataItemName);
       _updateLabels();
    }

    public void dataItemPublished()
    {
        super.dataItemPublished();
        _updateLabels();
    }

    private void _updateLabels()
    {
        Object dataItem = getDataItem();
        if (dataItem != null) 
        {
           if (dataItem instanceof RowsetAccess)
           {
              setLabels(_getColumnNamesFromRowset((RowsetAccess)dataItem));
              updateChart();
           }
        }
    }

    private Object[] _getColumnNamesFromRowset(RowsetAccess rs)
    {
         Object[] labels = (Object [])((DataItem)rs).getProperty(
                                  DataItemProperties.COLUMN_LABELS);
         if ( labels != null )
         {
             for ( int i=0 ; i < rs.getColumnCount(); i++)
             {
                if (labels[i] == null)
                    labels[i] = rs.getColumnName(i+1);
             }
         }
         return labels;
    }
 }
