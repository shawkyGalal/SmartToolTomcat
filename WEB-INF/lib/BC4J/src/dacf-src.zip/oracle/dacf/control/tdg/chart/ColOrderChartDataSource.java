/*
 * @(#)ColOrderChartDataSource.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.dacf.control.tdg.chart;

import oracle.dacf.control.tdg.ChartControl;

/**
 *  Data source for the chart control.
 *
 *  The table data is transposed and the transposed table is
 *  used as the data to present as a chart.
 *
 *  @see ChartLabelDataSource
 */
public class ColOrderChartDataSource extends LabelAwareChartDataSource

{
    /**
    *  Constructor
    */
    public ColOrderChartDataSource(ChartControl parent)
    {
        super(parent);
    }

    public String columnLabel(int i)
    {
        return super.rowLabel(i);
    }

    public int getColumns()
    {
        return super.getColumns();
    }

    public String rowLabel(int i)
    {
        return super.columnLabel(i);
    }

    public int getRows()
    {
        return super.getColumns();
    }

    public Object getValue(int row, int col)
    {
        return super.getValue(row, col);
    }
}

