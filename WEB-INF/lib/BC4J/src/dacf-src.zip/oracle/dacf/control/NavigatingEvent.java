/*
 * @(#)NavigatingEvent.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.dacf.control;

import java.util.EventObject;
import oracle.dacf.dataset.ValidationManager;

public class NavigatingEvent extends EventObject
{
    private Control _target ;
    private int _srcValidationResult ;


    public NavigatingEvent(Control source, Control target)
    {

        this(source, target, ValidationManager.VALID);
    }


    public NavigatingEvent(Control source, Control target,
                           int sourceValidationResult)
    {

        super(source);
        _target = target;
        _srcValidationResult = sourceValidationResult ;

    }

    public final Control getTargetControl()
    {
        return (_target);
    }

    public final Control getSourceControl()
    {
        return ((Control) getSource());
    }

    public final boolean isSourceValid()
    {
        return(_srcValidationResult == ValidationManager.VALID);
    }

    /**
    **  Return the validation result as reported by the ValidationManager.<p>
    **
    **  The return value will be one of:
    **  <ul>
    **  <li>ValidationManager.VALID</li>
    **  <li>ValidationManager.ATTRIBUTE_INVALID</li>
    **  <li>ValidationManager.ROW_INVALID</li>
    **  <li>ValidationManager.ROWSET_INVALID</li>
    **  <li>ValidationManager.SESSION_INVALID</li>
    **  </ul>
    */
    public final int getSourceValidationResult()
    {
        return(_srcValidationResult);
    }

    public String toString()
    {
        Control source = getSourceControl();
        return ("NavigatingEvent: [source=" +
                ((source == null) ? "null" : source.getDataItemName()) +
                " valid=" + isSourceValid() +
                " validationResult=" + _srcValidationResult  +
                "] _target=" +
                ((_target == null) ? "null" : _target.getDataItemName())) ;


    }

}
