/*
 * @(#)ButtonControl.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.dacf.control.swing;

import java.awt.Component;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.util.Locale;
import javax.infobus.DataItemAddedEvent;
import javax.infobus.DataItemDeletedEvent;
import javax.infobus.DataItemRevokedEvent;
import javax.infobus.DataItemValueChangedEvent;
import javax.infobus.ImmediateAccess;
import javax.infobus.RowsetCursorMovedEvent;
import javax.swing.Icon;
import javax.swing.JButton;
import javax.swing.SwingUtilities;
import oracle.dacf.control.Control;
import oracle.dacf.control.ControlEnabledListener;
import oracle.dacf.control.ControlSupport;
import oracle.dacf.control.InfoBusManager;
import oracle.dacf.control.InfoBusManagerListener;
import oracle.dacf.control.InfoBusManagerReleaseEvent;
import oracle.dacf.control.NavigatedEvent;
import oracle.dacf.control.NavigatedListener;
import oracle.dacf.control.NavigatingEvent;
import oracle.dacf.control.NavigatingException;
import oracle.dacf.control.NavigatingListener;
import oracle.dacf.control.NavigationManager;

/**
 * A data aware Button Control based on JButton control.
 *
 * @version PUBLIC
 */
public class ButtonControl extends JButton
    implements Control, ControlEnabledListener, FocusListener,
               InfoBusManagerListener
{
    private ControlSupport _controlSupport;

    /**
    * Creates a button with no set text or icon.
    */
    public ButtonControl()
    {
        this(null, null);
    }

    /**
    * Creates a button with an icon.
    *
    * @param icon  the Icon image to display on the button
    */
    public ButtonControl(Icon icon)
    {
        this(null, icon);
    }

    /**
    * Creates a button with text.
    *
    * @param text  the text of the button
    */
    public ButtonControl(String text)
    {
        this(text, null);
    }

    /**
    * Creates a button with initial text and an icon.
    *
    * @param text  the text of the button.
    * @param icon  the Icon image to display on the button
    */
    public ButtonControl(String text, Icon icon)
    {
        super(text, icon);
        _controlSupport = new ControlSupport(this);
        _controlSupport.addControlEnabledListener(this);
        InfoBusManager.getInstance().addInfoBusManagerListener(this);
        addFocusListener(this);
    }

    // ControlEnabledListener interface
    public void enabledChanged(boolean b)
    {
        super.setEnabled(b);
    }

    // InfoBusManagerListener interface implementation
    public void releaseResources(InfoBusManagerReleaseEvent e)
    {
        if (e.appliesTo(this))
        {
            InfoBusManager.getInstance().removeInfoBusManagerListener(this);
            removeFocusListener(this);
            _controlSupport.removeControlEnabledListener(this);
            _controlSupport = null;
        }
    }

    //FocusListener implementation
    /**
    * This method is an implementaion side effect
    */
    public void focusLost(FocusEvent event)
    {
    }

    /**
    * This method is an implementaion side effect
    */
    public void focusGained(FocusEvent event)
    {
       	if (isFocusValidated())
        {
            NavigationManager nm = NavigationManager.getNavigationManager();
            nm.validateFocusChange(this);
        }
    }

    // Control Interface
    /**
    ** An override of java.awt.Component.setEnabled. <P>
    **
    ** @param b boolean flag indicating whether the control is enabled
    */
    public void setEnabled(boolean b)
    {
        super.setEnabled(b);
        if (_controlSupport != null)
        {
            _controlSupport.setEnabled(b);
        }
    } // setEnabled

    /**
    * Returns the name of the InfoBus this control is connected to. <P>
    * @return  The name of the InfoBus this control is connected to.
    * @see Control#getInfoBusName
    */
    public final String getInfoBusName()
    {
        return(_controlSupport == null ?
               null : _controlSupport.getInfoBusName());
    }


    /**
    * Sets the name of the InfoBus this control is connected to. <P>
    * By default, the control is connected to the default InfoBus,
    * named <TT>Control.DEFAULT_INFOBUS_NAME</TT>. <P>
    * If the named InfoBus does not exist, it is created automatically. <P>
    * If the control is already connected to an InfoBus, it is disconnected
    * first. <P>
    * @param infoBusName   The name of the InfoBus to connect to.
    * @see Control#DEFAULT_INFOBUS_NAME
    * @see Control#setInfoBusName
    */
    public final void setInfoBusName(String infoBusName)
    {
        if (_controlSupport != null)
        {
            _controlSupport.setInfoBusName(infoBusName);
        }
    }


    /**
    * Returns the name of the InfoBus DataItem this control is bound to. <P>
    * @return  The name of the InfoBus DataItem this control is bound to,
    *          or <TT>null</TT> if the control is unbound.
    * @see #getDataItem
    * @see Control#getDataItemName
    */
    public final String getDataItemName()
    {
        return(_controlSupport == null ?
               null : _controlSupport.getDataItemName());
    }


    /**
    * Sets the name of the InfoBus DataItem this control is bound to. <P>
    * The DataItem with the given name is searched for on the InfoBus, and
    * if found, is bound to this control. <P>
    * If the control is already bound to a DataItem, it is unbound first. <P>
    * @param dataItemName  The name of the DataItem to bind to.
    * @see #getDataItem
    * @see Control#setDataItemName
    */
    public final void setDataItemName(String dataItemName)
    {
        if (_controlSupport != null)
        {
            _controlSupport.setDataItemName(dataItemName);
        }
    }


    /**
    * Returns the InfoBus DataItem this control is bound to. <P>
    * @return  The InfoBus DataItem this control is bound to, or
    *          <TT>null</TT> if the control is unbound.
    * @see Control#getDataItem
    */
    public final Object getDataItem()
    {
        return(_controlSupport == null ?
               null : _controlSupport.getDataItem());
    }

    /**
    * Notifies the control that the bound InfoBus DataItem has changed. <P>
    * @param oldDataItem   The formerly bound DataItem (can be <TT>null</TT>).
    * @param newDataItem   The newly bound DataItem (can be <TT>null</TT>).
    * @see Control#dataItemChanged
    */
    public final void dataItemChanged(Object oldDataItem, Object newDataItem)
    {
        // Don't care
    }

    /**
    * Returns the AWT component associated with this control. <P>
    * @return  The AWT component for this control.
    * @see Control#getComponent
    */
    public final Component getComponent()
    {
        return(this);
    }

    /**
    * Determines whether focus into this control causes validation to
    * occur. <P>
    * @return  <TT>true</TT> if focus into this control causes validation to
    *          occur, <TT>false</TT> otherwise.
    * @see Control#isFocusValidated
    */
    public final boolean isFocusValidated()
    {
        return(_controlSupport == null ?
               false : _controlSupport.isFocusValidated());
    }

    /**
    *  This method is a no-op that is it has no effect
    */
    public final void setFocusValidated(boolean focusValidated)
    {
        if (_controlSupport != null)
        {
            _controlSupport.setFocusValidated(focusValidated);
        }
    }

    /**
    *  This method is a no-op that is it has no effect
    */
    public final void addNavigatedListener(NavigatedListener listener)
    {
        if (_controlSupport != null)
        {
            _controlSupport.addNavigatedListener(listener);
        }
    }

    /**
    *  This method is a no-op that is it has no effect
    */
    public final void removeNavigatedListener(NavigatedListener listener)
    {
        if (_controlSupport != null)
        {
            _controlSupport.removeNavigatedListener(listener);
        }
    }

    /**
    *  This method is a no-op that is it has no effect
    */
    public final void processNavigatedEvent(NavigatedEvent event)
    {
        if (_controlSupport != null)
        {
            _controlSupport.processNavigatedEvent(event);
        }
    }

    /**
    *  This method is a no-op that is it has no effect
    */
    public final void addNavigatingListener(NavigatingListener listener)
    {
        if (_controlSupport != null)
        {
            _controlSupport.addNavigatingListener(listener);
        }
    }

    /**
    *  This method is a no-op in that it has no effect
    */
    public final void removeNavigatingListener(NavigatingListener listener)
    {
        if (_controlSupport != null)
        {
            _controlSupport.removeNavigatingListener(listener);
        }
    }

    /**
    *  This method is a no-op in that it has no effect
    *  @exception   NavigatingException    Indicates navigation rejected.
    */
    public final void processNavigatingEvent(NavigatingEvent event)
        throws NavigatingException
    {
        if (_controlSupport != null)
        {
            _controlSupport.processNavigatingEvent(event);
        }
    }

    // DataItemChangeListener Interface

    /**
    * Indicates a changed value in the bound data item. <P>
    * A reference to the data item that changed can be obtained from the
    * event. <P>
    * @param event Contains change information.
    * @see javax.infobus.DataItemChangeListener#dataItemValueChanged
    */
    public final void dataItemValueChanged(DataItemValueChangedEvent event)
    {
        _updateValueLater(event.getChangedItem());
    }

    /**
    * Indicates that a new item was added to the bound aggregate data item
    * (e.g. <TT>ArrayAccess</TT>, a JDK Collection, etc). <P>
    * A reference to the data item that was added, and a reference to the one
    * that gained it, can be obtained from the event. <P>
    * Has no effect on the ButtonControl.<P>
    *
    * @param event Contains details of the addition.
    * @see javax.infobus.DataItemChangeListener#dataItemAdded
    */
    public final void dataItemAdded(DataItemAddedEvent event)
    {
        // Not applicable
    }

    /**
    * Indicates that an item was deleted from the bound aggregate data item
    * (e. g. <TT>ArrayAccess</TT>, a JDK Collection, etc). <P>
    * A reference to the data item that was deleted, and a reference to the
    * one that lost it, can be obtained from the event. <P>
    * Has no effect on the ButtonControl.<P>
    *
    * @param event Contains details of the deletion.
    * @see javax.infobus.DataItemChangeListener#dataItemDeleted
    */
    public final void dataItemDeleted(DataItemDeletedEvent event)
    {
        // Not applicable
    }

    /**
    * Indicates that the bound data item (and its sub-items, if any) has been
    * revoked, and is temporarily unavailable. <P>
    * A reference to the data item that was revoked can be obtained from
    * the event. <P>
    * @param event Contains details of the revoked data.
    * @see javax.infobus.DataItemChangeListener#dataItemRevoked
    */
    public final void dataItemRevoked(DataItemRevokedEvent event)
    {
        _updateValueLater(null);
    }

    /**
    * Indicates that the cursor for the bound <TT>RowsetAccess</TT> data item
    * has changed rows. <P>
    * A reference to the rowset data item can be obtained from the event. <P>
    * @param event Contains details of the cursor move.
    * @see javax.infobus.DataItemChangeListener#rowsetCursorMoved
    */
    public final void rowsetCursorMoved(RowsetCursorMovedEvent event)
    {
        // Not applicable
    }


    // Private Methods
    /**
    * update the button text
    *
    * @param dataitem to which the button is bound to
    */
    private void _updateValueLater(final Object dataItem)
    {
        SwingUtilities.invokeLater(
                                   new Runnable()
                                   {
                                       public void run()
                                           {
                                               _updateValue(dataItem);
                                           }
                                   }
                                   );
    }

    /**
    * update the button text
    *
    * @param dataitem to which the button is bound to
    */
    private void _updateValue(Object dataItem)
    {
        String value = null;
        if (dataItem != null && dataItem instanceof ImmediateAccess)
        {
            value = ((ImmediateAccess)dataItem).getPresentationString(Locale.getDefault());
        }
        setText((value != null) ? value : "");
    }
}
