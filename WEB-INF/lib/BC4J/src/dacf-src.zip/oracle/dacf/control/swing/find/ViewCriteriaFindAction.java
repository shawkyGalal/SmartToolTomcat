/*
 * @(#)ViewCriteriaFindAction.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.dacf.control.swing.find;

import java.awt.event.ActionEvent;
import java.sql.SQLException;
import javax.infobus.DataItem;
import javax.infobus.DbAccess;
import javax.infobus.RowsetAccess;
import javax.infobus.RowsetValidationException;
import javax.infobus.ScrollableRowsetAccess;
import javax.swing.AbstractAction;
import javax.swing.Icon;
import javax.swing.JOptionPane;
import oracle.dacf.dataset.DataItemProperties;
import oracle.dacf.dataset.InfoObject;
import oracle.dacf.dataset.ResultSetInfo;
import oracle.dacf.dataset.RowSetInfo;
import oracle.dacf.dataset.RowSetManager;

/**
 *  An action object which makes use of ViewCriteria to execute a query
 *
 *  @see        FindItemModel
 *  @see        FindPanel
 *  @version    INTERNAL
 */
public class ViewCriteriaFindAction
    extends AbstractAction
{
   /**
   * You could specify a rowset thro' a data item name or directly
   * thro' a rowset
   */
   ScrollableRowsetAccess _rsAccess = null;
   private boolean _caseSensitive    = true;

   private static final boolean _DEBUG = true;

   // used in the save message dialog
   String _title = null;
   String _msg =   null;

   private static final int DO_POST = 0;
   private static final int DO_ROLLBACK = 1;
   private static final int DO_COMMIT = 2;



   /**
   * Create Action object with default text and icon
   */
   public ViewCriteriaFindAction()
   {
      super();
   }

   /**
   *  Create Action object with specified text
   *
   *  @param text to be used for the Action object
   */
   public ViewCriteriaFindAction(String text)
   {
      super(text);
   }

   /**
   * Create Action object with specified text and icon
   *
   * @param text to be used for the action object
   * @param icon to be used for the action object
   */
   public ViewCriteriaFindAction(String text, Icon icon)
   {
     super(text, icon);
   }

   /**
   *  An alternative way to specify a rowset
   *
   *  @param  rsAccess rowset to use
   *  @see    setDataItemName
   */
   public void setRowsetAccess(ScrollableRowsetAccess rsAccess)
   {
       _rsAccess  = rsAccess;
   }

   /**
   * get the rowset access currently in use
   *
   * @return rowset currently used to execute a query
   */
   public ScrollableRowsetAccess getRowsetAccess()
   {
       return _rsAccess;
   }

   /**
   * Specify if case sensitive search is to performed for Character data
   * types.
   *
   * By default this property is true.
   *
   * @param flag true if the search should be case sensitive
   */
   public void setCaseSensitiveSearch(boolean flag)
   {
       _caseSensitive = flag;
   }

   /**
   *  Return true, if the FindPanel does a case sensitive search for
   *  character data types.
   *
   *  @return true if the search is case sensitive for Character data types.
   */
   public boolean isCaseSensitiveSearch()
   {
       return _caseSensitive;
   }


   /**
   *  execute query in response to action performed
   *  event
   *
   *  @param evt ActionEvent
   */
   public void actionPerformed(ActionEvent evt)
   {
       executeQuery();
   }

   /**
   * execute the query. If the query condition is ignored, then the query will
   * be executed without a WHERE clause
   *
   */
   public void executeQuery()
   {
	  executeQuery(false);
   }

   /**
   * First post changes or commit/rollback and then execute query 
   *
   */
   public void executeQuery(boolean bPostAlways)
   {
	   ScrollableRowsetAccess rsAccess = getRowsetAccess();
  	   if (rsAccess == null)
	       return;

	   if ( _isDirty(rsAccess))
       {
		  if (bPostAlways)
              _applyChanges(rsAccess, DO_POST);
		  else
		  {
		      if (_title == null)
			  {
				_title = Res.getString(Res.VC_SAVE_CHANGES_DLG_TITLE);
				_msg =   Res.getString(Res.VC_SAVE_CHANGES_DLG_MSG);
			  }

			  int opt =  JOptionPane.showConfirmDialog(null, _msg, _title, 
											   JOptionPane.YES_NO_OPTION);
			  if (opt == JOptionPane.YES_OPTION)
				 _applyChanges(rsAccess, DO_COMMIT);
		  }
      }
	  
	  ResultSetInfo rsInfo = _getInfoObject((DataItem)rsAccess);
      _executeQuery(rsAccess, rsInfo);

   }

   /**
   * rollback if the dataproducer is dirty
   */
   public void rollback()
   {
      ScrollableRowsetAccess rsAccess = getRowsetAccess();
      if (rsAccess == null)
         return;

      ResultSetInfo rsInfo = _getInfoObject((DataItem)rsAccess);

      try
      {
          if ( _isDirty(rsInfo))
             (rsAccess.getDb()).rollbackTransaction();
      }
      catch(Exception e)
      {
         e.printStackTrace();
      }

   }

   /**
   *  Propogate changes to the DbAccess. Overrider this method to
   *  process the exception
   */
   protected boolean _applyChanges(ScrollableRowsetAccess scr, int doWhat)
   {
        try
        {
            _applyChangesToDbAccess(scr, doWhat);
            return true;
        }
        catch(Exception exc)
        {
            JOptionPane.showMessageDialog(null, exc.getMessage());
            return false;
        }
   }

   protected void _applyChangesToDbAccess(ScrollableRowsetAccess scr, int doWhat)
            throws SQLException, RowsetValidationException
   {
        switch(doWhat)
        {
            case DO_POST:
                 scr.getDb().flush();
                 break;
            case DO_ROLLBACK:
                 scr.getDb().rollbackTransaction();
                 break;
            case DO_COMMIT:
                 scr.getDb().commitTransaction();
                 break;
		    default:
				  break;
        }
   }



   /**
   * a helper function to execute the query
   *
   * @param rsAccess rowset access used to execute the query
   * @param rsInfo   rowset info object on which the query condition is set
   * @param queryCondition the WHERE clause
   */
   private void _executeQuery(ScrollableRowsetAccess rsAccess,
                              ResultSetInfo rsInfo)
   {
        try
        {
            if ( _isDirty(rsInfo))
                 (rsAccess.getDb()).rollbackTransaction();

            // assumes the query criteria is set elsewhere
            rsInfo.executeQuery();
            boolean hasRows = false;
            if (rsAccess instanceof RowSetManager)
            {
               hasRows = ((RowSetManager)rsAccess).hasRows();
            }
            else
            {
               hasRows = (rsAccess.getRowCount() > 0);
            }

            if (hasRows)
               rsAccess.first();
        }
        catch (Exception exc)
        {
            exc.printStackTrace();
        }
   }

   /**
   * get the data objet
   *
   * @return the data object
   */
   private ResultSetInfo _getInfoObject(DataItem di)
   {
       InfoObject  dataObj =
           (InfoObject)di.getProperty(DataItemProperties.INFO_OBJECT);
       if ((dataObj != null) &&( dataObj instanceof RowSetInfo))
       {
           ResultSetInfo rsInfo = (ResultSetInfo)dataObj;
           return rsInfo;
       }
       return null;
   }

    /**
    * check if the RowsetInfo is dirty
    *
    */
    private boolean _isDirty(InfoObject rowset)
    {
        return rowset.isDirty();
    }

    /**
    *  check if the transaction is dirty
    *
    *  @param rowset whose transaction status has to be checked
    */
    private boolean _isDirty(RowsetAccess rowset)
    {
        DbAccess db = rowset.getDb();
        Object dirty =
            (Boolean)((DataItem)db).getProperty(DataItemProperties.PENDING_CHANGES);
        if (dirty != null && dirty instanceof Boolean)
            return ((Boolean)dirty).booleanValue();
        return true;
    }
}


