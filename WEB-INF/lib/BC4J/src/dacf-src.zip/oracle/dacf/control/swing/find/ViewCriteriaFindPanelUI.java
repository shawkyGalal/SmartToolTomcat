/*
 * @(#)ViewCriteriaFindPanelUI.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.dacf.control.swing.find;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.net.URL;
import java.sql.Types;
import java.text.MessageFormat;
import java.util.Hashtable;
import java.util.Vector;
import javax.infobus.ScrollableRowsetAccess;
import javax.swing.BorderFactory;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.JTextArea;
import javax.swing.border.BevelBorder;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import oracle.dacf.control.swing.FindPanel;
import oracle.dacf.util.ViewCriteriaModifier;

/**
 *  The ViewCriteriaFindPanelUI implements the UI for the FindPanel. It lets
 *  the end user create multiple criteria's.
 *
 *  @version   INTERNAL
 *  @see       FindPanel
 *  @see       FindPanelUI
 *  @see       DacFindPanelUI
 *
 */
public class ViewCriteriaFindPanelUI implements FindPanelUI,
             ActionListener, ChangeListener
{
   /**
   * A handle to the parent so that we can delegate some of the functionality
   * like Find.
   */
   protected FindPanel _parent;

   /**
   * top level container
   */
   protected JPanel   _panel = new JPanel();

   /**
   * display icon here
   */
   protected JPanel   _iconPanel = new JPanel();

   /**
   * labels and text fields displayed in this panel
   */
   protected JPanel   _dataPanel = new JPanel();

   /**
   * outer panel which in turn houses _icon and _data panels.
   */
   protected JPanel   _contentPanel = new JPanel();

   /**
   * All our buttons go here.
   */
   protected JPanel   _buttonPanel = new JPanel();

   /**
   *  bottom panel contains the statusbar label and the button panels
   */
   protected JPanel _bottomPanel = new JPanel();

   /**
   *  title for the help dialog
   */
   private String   _helpDlgTitle = Res.getString(Res.FIND_DIALOG_TITLE);

   /**
   * help message
   */
   private String   _helpMessage = Res.getString(Res.FIND_HELP_MESSAGE);

   /**
   *  find button on the button panel
   */
   protected JButton _findButton = new JButton(Res.getString(Res.FIND_BUTTON_TEXT));

   /**
   *  reset button on the button panel
   */
   protected JButton _resetButton = new JButton(Res.getString(Res.RESET_BUTTON_TEXT));

   /**
   *  Close button on the button panel
   */
   protected JButton _closeButton = new JButton(Res.getString(Res.CLOSE_BUTTON_TEXT));

   /**
   *  help button on the button panel
   */
   protected JButton _helpButton = new JButton(Res.getString(Res.HELP_BUTTON_TEXT));

   /**
   *  OR button on the button panel
   */
   protected JButton _orButton = new JButton(Res.getString(Res.OR_BUTTON_TEXT));

   /**
   *  Remove button on the button panel
   */
   protected JButton _removeButton = new JButton(Res.getString(Res.REMOVE_BUTTON_TEXT));

   /**
   *  Remove button on the button panel
   */
   protected JButton _removeAllButton = new
                            JButton(Res.getString(Res.REMOVE_ALL_BUTTON_TEXT));


   /**
   * status bar control
   */
   protected JLabel _labelStatusBar = new JLabel(
                                 Res.getString(Res.FIND_STATUSBAR_INIT_TEXT));

   /**
   * List of properties DacFindPanelUI implements
   */
   protected Hashtable _properties  = new Hashtable();

   /**
   *  command to implement each property
   */
   protected Hashtable _commands    = new Hashtable();

   /**
   * Directory where the image file for the icon is located
   */
   private static final String _IMAGES_DIR = "/oracle/dacf/images/";

   /**
   * image file name for the icon
   */
   private static final String _IMAGE_NAME = "search.gif";

   /**
   * Are we in debug mode ?
   */
   private static final boolean _DEBUG = true;

   /**
   * button id's. This id is used to generate notifications
   * (see DacFindPanelUIListener).
   *
   * Find button id
   */
   private static final int FIND_BUTTON = 0;

   /*
   * Reset button id
   */
   private static final int RESET_BUTTON = 1;

   /*
   * Close button id
   */
   private static final int CLOSE_BUTTON = 2;

   /*
   * Help button id
   */
   private static final int HELP_BUTTON = 3;

   /*
   * OR button id
   */
   private static final int OR_BUTTON = 4;

   /*
   * Remove button id
   */
   private static final int REMOVE_BUTTON = 5;


   /*
   * Remove All button id
   */
   private static final int REMOVE_ALL_BUTTON = 6;

   /**
   * button click listeners
   */
   protected Vector _buttonListeners =  new Vector();

   /**
   *  font for label
   */
   protected String _defaultLabelFontName = Res.getString(Res.LABEL_FONT_NAME);

   /**
   *  font for text field
   */
   protected String _defaultTextFontName =  Res.getString(Res.TEXT_FONT_NAME);;

   /**
   *  button size
   */
   protected Dimension _preferredButtonSize = new Dimension(80,25);

   /**
   *  display find icon using this label
   */
   protected JLabel    _labelIcon = new JLabel();

   /**
   *  tooltip text
   */
   protected String  _tooltipText = new String( Res.getString(Res.FIND_FIELD_TOOLTIP_TEXT));

   /**
   *  property values
   */
   protected int     _labelPosition = FindPanel.LEFT;

   /**
   * direction in which the text fields are laid out
   */
   protected int     _itemDirection  = FindPanel.Y_AXIS;

   /**
   *  do we show the find icon ?
   */
   private boolean _showFindIcon = true;

   /**
   *  do we show the status bar ?
   */
   private boolean _showStatusBar = true;

   /**
   *  find icon
   */
   protected Icon    _findIcon = null;

   /**
   * FindPanel enabled/disabled
   */
   protected boolean _enabled = true;

   /**
   * order in which the find buttons are laid out
   */
   private static final int FIND_ORDER = 0;
   private static final int OR_ORDER = 1;
   private static final int REMOVE_ORDER = 2;
   private static final int REMOVE_ALL_ORDER = 3;
   private static final int RESET_ORDER =4;
   private static final int CLOSE_ORDER = 5;
   private static final int HELP_ORDER = 6;

   private static final int _buttonCount = 7;
   protected JButton _buttons[] =
        { _findButton, _orButton, _removeButton, _removeAllButton,
         _resetButton, _closeButton, _helpButton };

   protected boolean _buttonState[] = new boolean[_buttonCount];

   private static final String _findStatusBarExecFailed =
                                   Res.getString(Res.FIND_STATUSBAR_EXEC_FAILED);

   private static final String _findStatusBarExecSucc =
                                   Res.getString(Res.FIND_STATUSBAR_EXEC_SUCC);

   private int _currentViewCriteriaRow = 0;

   protected JTabbedPane _tabbedPane = new JTabbedPane();

       /**
   *  font for label
   */
   protected Font _labelFont = new Font(_defaultLabelFontName,Font.PLAIN, 12);

   /**
   *  font for text field
   */
   protected Font _textFont = new Font(_defaultLabelFontName,Font.PLAIN, 12);

   /**
   *  foreground color for the label
   */
   protected Color  _labelForeColor = new Color(0,0,0);

   /**
   *  background color for the label
   */
   protected Color   _labelBackColor = new Color(255,255,255);

   /**
   *  foreground color for the textfield
   */
   protected Color   _textForeColor = new Color(0,0,0);
   /**
   *  background color for the textfield
   */
   protected Color   _textBackColor = new Color(255,255,255);

   /**
   *  default column width for the text field
   */
   protected int     _textColumnWidth = 10;

   /**
   * last view criteria num
   */
   protected int _lastViewCriteriaNum = 1;

   /**
   * This is the conatainer object to which the FindPanel is added
   * to.
   *
   * The NavigationBar uses this property to set the dialog object
   * used to display the FindDialog. The findpanelUI implementation
   * can use this object to close the dialog.
   *
   * @see NavigationBar.setFindPanelUI
   */
   Object _parentContainer = null;

   /**
   *
   */
   private String _criteria = Res.getString(Res.FIND_CRITERIA_TEXT);

   protected ViewCriteriaModifier _modifier =  new ViewCriteriaModifier();

   protected JButton _buttonWidthCalculateHelper = new JButton();

   // custom editor support
   protected EditItemInvoker[] _editInvokers = null;
   protected FindItemEditor[]  _editors = null;

   
   /**
   * Constructor
   */
   public ViewCriteriaFindPanelUI()
   {
      _findIcon = _loadDefaultIcon();
      _bottomPanel =  _createBottomPanel();

      // content panel contains the text fields
      _contentPanel = _createContentPanel();

      // the find panel contains the content and the bottom panels
      _panel.setLayout(new BorderLayout());
      _panel.add(_bottomPanel, BorderLayout.SOUTH);
      _panel.add(_tabbedPane, BorderLayout.CENTER);

      _tabbedPane.addChangeListener(this);

      _setShowFindButton(new Boolean(true));
      _setShowORButton(new Boolean(true));
      _setShowRemoveButton(new Boolean(true));
      _setShowRemoveAllButton(new Boolean(true));
      _setShowCloseButton(new Boolean(true));
      _setShowResetButton(new Boolean(true));
      _setShowHelpButton(new Boolean(true));
      _setShowStatusBar(new Boolean(true));
    }

    /**
    *  set the parent which will use the customized UI panel.
    *  Implementors of this interface will make use of the 'parent' argument to
    *  retrive values to display and to execute query
    *
    *  @param parent
    */
    public void setParent(FindPanel parent)
    {
        _parent = parent;
    }

    /**
    * A notification from the parent that one or more data item names changed.
    * Implementation should rebuild the UI
    */
    public void itemChanged()
    {
        if ( _parent != null )
    		{
		        _destroyEditInvokers();
		        _initEditInvokers(_editors);
            _rebuildUI();
		    }
    }

    /**
    * A notification from the paraent that the column value changed.
    * Implementation should refresh the values for this column like the column
    * display label
    *
    * @param column whose value (some attribute) has changed
    */
    public void itemValueChanged(int column)
    {
		// not used
    }

    /**
    * return a Panel reflectiong the panel to be displayed.
    * @return Component built
    */
     public Component buildPanel()
     {
         return createPanel();
     }

     protected Component createPanel()
	 {
		 return _panel;
	 }

    /**
    * specify a property value to customize the UI
    *
    * @param property id for the property we are trying to set
    * @value property value
    */
    public void setProperty(int property, Object value)
    {
        switch (property)
        {
           case LABEL_POSITION:
                _labelPosition = ((Integer)value).intValue();
                _rebuildUI();
                break;

           case ITEM_DIRECTION :
                _itemDirection = ((Integer)value).intValue();
                _rebuildUI();
                break;

           case SHOW_FIND_BUTTON:
                _setShowFindButton(value);
                break;

           case SHOW_RESET_BUTTON:
                _setShowResetButton(value);
                break;

           case SHOW_CLOSE_BUTTON:
                _setShowCloseButton(value);
                break;

           case SHOW_HELP_BUTTON:
                _setShowHelpButton(value);
                break;

           case SHOW_FIND_ICON:
                _setShowFindIcon(value);
                break;

           case FIND_ICON:
                _setFindIcon(value);
                break;

           case INNER_PANEL_LYT_MGR:
                _rebuildUI();
                break;

           case INNER_PANEL:
                break;

           case LABEL_FONT:
                _labelFont = (Font)value;
                break;

           case TEXT_FONT:
                _textFont = (Font)value;
                break;

           case LABEL_FORE_CLR:
                _labelForeColor = (Color)value;
                break;

           case TEXT_FORE_CLR:
                _textForeColor = (Color)value;
                break;

           case LABEL_BACK_CLR:
                _labelBackColor = (Color)value;
                break;

           case TEXT_BACK_CLR:
                _textBackColor = (Color)value;
                break;

           case TEXT_COLUMN_WIDTH:
                _textColumnWidth = ((Integer)value).intValue();
                break;
           case ITEM_EDITORS:
                _setCustomEditors(value);
                break;

           case SHOW_STATUS_BAR:
                _setShowStatusBar(value);
                break;

           case ENABLED :
                _enabled = ((Boolean)value).booleanValue();
                _enableControls(_enabled);
                break;

           case SHOW_OR_BUTTON:
                _setShowORButton(value);
                break;

           case SHOW_REMOVE_BUTTON:
                _setShowRemoveButton(value);
                break;

           case SHOW_REMOVE_ALL_BUTTON:
                _setShowRemoveAllButton(value);
                break;

           case PARENT_CONTAINER :
                _parentContainer = value;
                break;
        }

        _notifyPropertyChange(property, value);
    }

    /**
    * get property value
    *
    * @param property id for the property we are interested in
    * @return property value
    */
    public Object getProperty(int property)
    {
        switch (property)
        {
          case LABEL_POSITION:
                return new Integer(_labelPosition);
           case ITEM_DIRECTION :
                return new Integer(_itemDirection);
           case SHOW_FIND_BUTTON:
                return new Boolean (_buttonState[FIND_ORDER]);
           case SHOW_RESET_BUTTON:
                return new Boolean (_buttonState[RESET_ORDER]);
           case SHOW_CLOSE_BUTTON:
                return new Boolean (_buttonState[CLOSE_ORDER]);
           case SHOW_HELP_BUTTON:
                return new Boolean (_buttonState[HELP_ORDER]);
           case SHOW_FIND_ICON:
                return new Boolean(_showFindIcon);
           case FIND_ICON:
                return _findIcon;
           case INNER_PANEL_LYT_MGR:
                break;
           case INNER_PANEL:
                return _panel;
           case LABEL_FONT:
                return _labelFont;
           case TEXT_FONT:
                return _textFont;
           case LABEL_FORE_CLR:
                return _labelForeColor;
           case TEXT_FORE_CLR:
                return _textForeColor;
           case LABEL_BACK_CLR:
                return _labelBackColor;
           case TEXT_BACK_CLR:
                return _textBackColor;
           case TEXT_COLUMN_WIDTH:
                return new Integer(_textColumnWidth);
           case ITEM_EDITORS:
                return _editors;
           case SHOW_STATUS_BAR:
                return new Boolean(_showStatusBar);
           case ENABLED :
                return new Boolean(_enabled);
           case SHOW_OR_BUTTON:
                return new Boolean (_buttonState[OR_ORDER]);
           case SHOW_REMOVE_BUTTON:
                return new Boolean (_buttonState[REMOVE_ORDER]);
           case SHOW_REMOVE_ALL_BUTTON:
                return new Boolean (_buttonState[REMOVE_ALL_ORDER]);
         }
         return null;
    }

    /**
    * Adds a button click listener to this control. <P>
    *
    * The listener will be notified when one of the button is clicked by
    * the user
    *
    * @param listener  The listener to add.
    * @see Control#addNavigatedListener
    */
    public final void addButtonClickListener(DacFindPanelUIListener listener)
    {
        _buttonListeners.addElement(listener);
    }

    /**
    * Removes a button listener  <P>
    *
    * @param listener  The listener to remove.
    */
    public final void removeButtonClickListener(DacFindPanelUIListener listener)
    {
        _buttonListeners.removeElement(listener);
    }

    // Action Listener interface
    /**
    * Button click occured
    *
    * @param e ActionEvent object with event details
    */
    public void actionPerformed(ActionEvent e)
    {
        Object source = e.getSource();
        if ( source == _findButton )
            _doButtonFind();
        else if ( source == _closeButton )
            _doButtonClose();
        else if ( e.getSource() == _helpButton)
           _doButtonHelp();
        else if (e.getSource() == _orButton)
           _doButtonOr();
        else if (e.getSource() == _removeButton)
           _doButtonRemove();
        else if (e.getSource() == _removeAllButton)
           _doButtonRemoveAll();
        else
           _doButtonReset();
    }

    // ChangeListener interface

    public void stateChanged(ChangeEvent e)
    {
        _currentViewCriteriaRow = _tabbedPane.getSelectedIndex();
    }

    /**
    *  get column value for specified column
    */
    protected String _getColumnValue(int column)
    {
        Object columnValue = _parent.getColumnValue(column);
        return (columnValue==null) ? "" : columnValue.toString();
    }

    /**
    *  set column value for specified column
    */
    protected void _setColumnValue(int column, Object val)
    {
        _parent.setColumnValue(column, val);
    }

    /**
    *  get colum display label for specified column
    *
    *  @param column index
    *  @return column display label
    */
    protected String _getColumnDisplayLabel(int column)
    {
       return _parent.getColumnDisplayLabel(column);
    }

    protected int _getViewCriteriaRowCount()
    {
        return _parent.getViewCriteriaRowCount();
    }

    protected void _newViewCriteriaRow()
    {
        _parent.newViewCriteriaRow();
    }

    protected void _deleteViewCriteriaRow()
    {
        _parent.deleteViewCriteriaRow();
    }

    protected void _deleteAllViewCriteriaRow()
    {
       _parent.deleteAllViewCriteriaRow();
    }

    protected void setCurrentViewCriteriaRow(int row)
    {
       _parent.setCurrentViewCriteriaRow(row);
    }

    protected int getCurrentViewCriteriaRow()
    {
       return _parent.getCurrentViewCriteriaRow();
    }

    protected int getColumnCount()
    {
       return _parent.getColumnCount();
    }

    protected int _getSQLType(int i)
    {
       ConstrainedViewCriteriaModel vcm = _parent.getViewCriteriaModel();
       if ( vcm != null )
           return vcm.getSQLType(i);
       return -1;
    }

    protected boolean isCaseSensitiveSearch()
    {
        return _parent.isCaseSensitiveSearch();
    }

    /**
    *  rebuild the UI
    */
    protected void _rebuildUI()
    {
        if ( _parent != null)
        {
           if ( !_isDataPublished())
               return;

           if (_getViewCriteriaRowCount() == 0 )
              _newViewCriteriaRow();

          _lastViewCriteriaNum = 1;
          _tabbedPane.removeAll();
          int rc = this._getViewCriteriaRowCount();
          for (int i=1; i <= rc; i++)
          {
              DataPanel d = _addViewCriteriaRowPanel(i);
              _refreshDataPanel(d, true);
          }

          _tabbedPane.setSelectedIndex(0);
          _updateButtonState();

  	  	  // clear the status bar
	  	    _labelStatusBar.setText(Res.getString(Res.FIND_STATUSBAR_INIT_TEXT));

        }

    }

    protected DataPanel _addViewCriteriaRowPanel(int asRow)
    {
        DataPanel dataPanel = new DataPanel(this, asRow);
        _tabbedPane.addTab(_criteria +" "+ _lastViewCriteriaNum++ , dataPanel);
        _tabbedPane.setSelectedComponent(dataPanel);
        if (_editInvokers != null)
       			 dataPanel.setEditInvoker(_editInvokers, false);
        return dataPanel;
    }

    protected void _refreshDataPanel(DataPanel d, boolean queryNewValues)
    {
        d._itemChanged(queryNewValues);
        d._rebuildUI();
    }


    protected void _removeViewCriteriaRowPanel(int curRow)
    {
        _tabbedPane.removeTabAt(curRow);
    }

    protected void _removeAllViewCriteriaRowPanel()
    {
        _tabbedPane.removeAll();

    }

    protected void _ensureMinimalRequiredRows()
    {
       if (_getViewCriteriaRowCount() == 0 )
       {
          _newViewCriteriaRow();
          DataPanel d = _addViewCriteriaRowPanel(1);
          _refreshDataPanel(d, true);
       }
    }

	protected void _changeFocusToFindButton()
	{
		if (_findButton != null )
			_findButton.requestFocus();
	}
      /**
      * Creates the button panel. The button panel contains Find, Help and
      * Reset buttons
      */
      protected JPanel _createButtonPanel()
      {
          JPanel panel = new JPanel();
          panel.setLayout( new FlowLayout());

          _findButton.addActionListener(this);
          _orButton.addActionListener(this);
          _removeButton.addActionListener(this);
          _removeAllButton.addActionListener(this);
          _resetButton.addActionListener(this);
          _closeButton.addActionListener(this);
          _helpButton.addActionListener(this);

           // button mnemonics
           _findButton.setMnemonic(Res.getString(Res.FIND_BUTTON_MNEMONIC).charAt(0));
           _orButton.setMnemonic(Res.getString(Res.OR_BUTTON_MNEMONIC).charAt(0));
           _removeButton.setMnemonic(Res.getString(Res.REMOVE_BUTTON_MNEMONIC).charAt(0));
           _removeAllButton.setMnemonic(Res.getString(Res.REMOVE_ALL_BUTTON_MNEMONIC).charAt(0));
           _resetButton.setMnemonic(Res.getString(Res.RESET_BUTTON_MNEMONIC).charAt(0));
           _closeButton.setMnemonic(Res.getString(Res.CLOSE_BUTTON_MNEMONIC).charAt(0));
           _helpButton.setMnemonic(Res.getString(Res.HELP_BUTTON_MNEMONIC).charAt(0));

           // preferred size
		   Dimension newPreferredSize = _determineMinButtonSize(
								_findButton, _preferredButtonSize);
           _findButton.setPreferredSize(newPreferredSize);

		   newPreferredSize = _determineMinButtonSize(_orButton, _preferredButtonSize);
           _orButton.setPreferredSize(newPreferredSize);

		   newPreferredSize = _determineMinButtonSize(_removeButton, _preferredButtonSize);
           _removeButton.setPreferredSize(newPreferredSize);

		   newPreferredSize = _determineMinButtonSize(_removeAllButton, new Dimension(100,25));
           _removeAllButton.setPreferredSize(newPreferredSize);

		   newPreferredSize = _determineMinButtonSize(_resetButton, _preferredButtonSize);
           _resetButton.setPreferredSize(newPreferredSize);

		   newPreferredSize = _determineMinButtonSize(_closeButton, _preferredButtonSize);
           _closeButton.setPreferredSize(newPreferredSize);

		   newPreferredSize = _determineMinButtonSize(_helpButton, _preferredButtonSize);
           _helpButton.setPreferredSize(newPreferredSize);

           // temporary
           _orButton.setEnabled(false);
           _removeButton.setEnabled(false);
           _removeAllButton.setEnabled(false);

           return panel;
      }

      /**
      *  create a panel which contains the icon panel and the data panel
      */
      protected JPanel _createContentPanel()
      {
          _iconPanel = new JPanel();
          _iconPanel.setLayout(new BorderLayout(10,10));
          _iconPanel.setBorder( BorderFactory.createEmptyBorder(10,10,10,10));
          _labelIcon.setIcon(_findIcon);
          _iconPanel.add( _labelIcon, BorderLayout.NORTH);

          _dataPanel = new JPanel();
          _dataPanel.setLayout(new GridBagLayout());

          JScrollPane scrollPane = new JScrollPane();
          scrollPane.setViewportView(_dataPanel);
          scrollPane.setBorder(null);


          _contentPanel = new JPanel();
          _contentPanel.setLayout( new BorderLayout());
          _contentPanel.add( _iconPanel, BorderLayout.WEST);
          _contentPanel.add( scrollPane, BorderLayout.CENTER);

          return _contentPanel;
      }

      protected JPanel _createBottomPanel()
      {
           JPanel panel = new JPanel();
           panel.setLayout(new BorderLayout());
           _labelStatusBar.setBorder( BorderFactory.createBevelBorder(
                                                    BevelBorder.LOWERED));
           _buttonPanel = _createButtonPanel();
           // bottomPanel contains the status bar and the buttonPanel
           panel.add( _labelStatusBar, BorderLayout.SOUTH);
           panel.add( _buttonPanel,BorderLayout.CENTER);
           return panel;
      }

      /**
      * Find button clicked
      */
      protected void _doButtonFind()
      {
          _notifyButtonClick(FIND_BUTTON);
          if ( _parent != null)
          {
              int c = _tabbedPane.getTabCount();
              for (int i=0; i < c; i++)
              {
                 DataPanel d = (DataPanel)_tabbedPane.getComponentAt(i);
                 d._applyValues();
              }

              _parent.runQuery();
              // update status bar
              ScrollableRowsetAccess rs = (ScrollableRowsetAccess)_parent.getDataItem();
              String status = "";
              if ( rs != null )
              {
                 int rc = rs.getRowCount();
                 if ( rc == -1)
                     status = _findStatusBarExecFailed;
                 else
                 {
                    String msg = _findStatusBarExecSucc;
                    Object arg[] = { new Integer( rc )};
                    status = MessageFormat.format(msg, arg);
                 }
                 _labelStatusBar.setText(status);
              }
          }
      }

      /**
      *  Reset button clicked
      */
      protected void _doButtonReset()
      {
          _notifyButtonClick(RESET_BUTTON);
          DataPanel d = (DataPanel)_tabbedPane.getComponentAt(
                                            _currentViewCriteriaRow);
          if ( d != null )
             d._resetFields();
      }

      /**
      * Close button clicked
      */
      protected void _doButtonClose()
      {
         if ((_parentContainer != null ) && ( _parentContainer instanceof JDialog))
         {
             JDialog dlg = (JDialog)_parentContainer;
             dlg.hide();
         }
         _notifyButtonClick(CLOSE_BUTTON);
      }

      /**
      *  Help button clicked
      */
      protected void _doButtonHelp()
      {
          _notifyButtonClick(HELP_BUTTON);
         _displayMessageDialog(_helpMessage,
                                 JOptionPane.INFORMATION_MESSAGE);
      }

      protected void _doButtonOr()
      {
         _notifyButtonClick(OR_BUTTON);
         _newViewCriteriaRow();
         DataPanel d = _addViewCriteriaRowPanel(_getViewCriteriaRowCount());
         _refreshDataPanel(d, false);
         _updateButtonState();

      }

      protected void _doButtonRemove()
      {
         _notifyButtonClick(REMOVE_BUTTON);
         setCurrentViewCriteriaRow(_currentViewCriteriaRow);
         _deleteViewCriteriaRow();
         _removeViewCriteriaRowPanel(_currentViewCriteriaRow);
         _ensureMinimalRequiredRows();
         _updateButtonState();
      }

      protected void _doButtonRemoveAll()
      {
         _notifyButtonClick(this.REMOVE_ALL_BUTTON);
         _deleteAllViewCriteriaRow();
         _removeAllViewCriteriaRowPanel();
         _lastViewCriteriaNum=1;
         _ensureMinimalRequiredRows();
         _updateButtonState();

      }

      protected void _updateButtonState()
      {
          if (_getViewCriteriaRowCount() > 1 )
          {
              _removeButton.setEnabled(true);
              _removeAllButton.setEnabled(true);
          }
          else
          {
              _removeButton.setEnabled(false);
              _removeAllButton.setEnabled(false);
          }
          _orButton.setEnabled(true);
      }

      /**
      * Helper method to display a message
      *
      * @param message to be displayed
      * @param style for the dialog
      */
      protected void _displayMessageDialog(String message, int style)
      {
          JPanel helpPanel = new JPanel(new BorderLayout(), false);
          JTextArea area = new JTextArea(message, 6, 40);
          area.setLineWrap(true);
          area.setWrapStyleWord(true);
          area.setEditable(false);
          helpPanel.add(new JScrollPane(area),
                      BorderLayout.CENTER);
          JOptionPane.showMessageDialog(null,
                           helpPanel,
                           _helpDlgTitle,
                           style);
      }


      /**
      * Initialize the Find Icon
      *
      * @return Icon for the find dialog
      */
      protected Icon _loadDefaultIcon()
      {
          Class cl = DacFindPanelUI.class;
          URL img =  cl.getResource(_IMAGES_DIR + _IMAGE_NAME);
          if ( img != null)
             return (new ImageIcon(img));
          else
          {
             return null;
          }
      }


      /**
      * Helper method which set the properties
      */
      protected void _applyProperties()
      {
         // delegate to the individual panels
      }

      /**
      * Get tool tip text for a column
      *
      * @param column index for which the tooltip should be obtained
      * @return the tooltip text for the column
      */
      protected String _getTooltipText(int column)
      {
           FindItemModel findItemModel = _parent.getFindItemModel(column);
           int sqlType = findItemModel.getSQLType();
           String tooltip =  null;

           if (( sqlType == Types.DATE) ||( sqlType == Types.TIME) ||
                                             ( sqlType == Types.TIMESTAMP))
           {
              tooltip = _tooltipText + " " + _getColumnDisplayLabel(column) +
                              "( " + findItemModel.getSQLFormatString() + " )";
           }
           else
              tooltip = _tooltipText + " " + _getColumnDisplayLabel(column);
           return tooltip;
      }

      /**
      * set the icon for the Find panel
      *
      * @param value icon for the find panel
      */
      protected void _setFindIcon(Object value)
      {
         if ( value instanceof Icon)
         {
              _findIcon = (Icon)value;
              _labelIcon.setIcon(_findIcon);
         }
      }

      /**
      * should the find icon be displayed ?
      *
      * @param value boolean value to indicate if the Find icon should be
      *              displayed
      */
      protected void _setShowFindIcon(Object value)
      {
         _showFindIcon = ((Boolean)value).booleanValue();
         if ( _showFindIcon )
            _contentPanel.add(_iconPanel, BorderLayout.WEST);
         else
            _contentPanel.remove(_iconPanel);
      }

      /**
      * should the Find button be displayed in the FindPanel
      *
      * @param value a boolean value to indicate if the Find button should be
      *              displayed
      */
      protected void _setShowFindButton(Object value)
      {
         _showButtonHelper(FIND_ORDER, value);
      }

      /**
      * should the Close button be displayed in the FindPanel
      *
      * @param value a boolean value to indicate if the Close button should be
      *              displayed
      */
      protected void _setShowCloseButton(Object value)
      {
         _showButtonHelper(CLOSE_ORDER, value);
      }

      /**
      * should the Reset button be displayed in the FindPanel
      *
      * @param value a boolean value to indicate if the Reset button should be
      *              displayed
      */
      protected void _setShowResetButton(Object value)
      {
         _showButtonHelper(RESET_ORDER, value);
      }

      /**
      * should the Help button be displayed in the FindPanel
      *
      * @param value a boolean value to indicate if the Help button should be
      *              displayed
      */
      protected void _setShowHelpButton(Object value)
      {
         _showButtonHelper(HELP_ORDER, value);
      }


      protected void _setCustomEditors(Object value)
      {
	  	    _editors = (FindItemEditor [])value;
  	  	  _destroyEditInvokers();
		      _initEditInvokers(_editors);
     	    _setEditorsOnDataPanel();
      }

	  protected void _destroyEditInvokers()
	  {
			 _editInvokers = null;
	  }

	  protected void _initEditInvokers(FindItemEditor[] editors)
	  {
  		  if (editors == null)
	    		  _editInvokers = null;
        else
        {
    		    _editInvokers = new EditItemInvoker[editors.length];
  	    	  for (int i=0; i < editors.length; i++)
    	  	  {
		    	      if (editors[i] != null)
		        	  	  _editInvokers[i] = new EditItemInvoker(this, i);
            }
    	  }
    }

	  protected void _setEditorsOnDataPanel()
	  {
		      int c = _tabbedPane.getTabCount();
          for (int i=0; i < c; i++)
          {
              DataPanel d = (DataPanel)_tabbedPane.getComponentAt(i);
      			  d.setEditInvoker(_editInvokers, true);
          }
	  }


      /**
      * should the Status bar displayed in the FindPanel
      *
      * @param value a boolean value to indicate if the status bar should be
      * displayed
      */
      protected void _setShowStatusBar(Object value)
      {
         _showStatusBar  = ((Boolean)value).booleanValue();
         if ( _showStatusBar )
            _bottomPanel.add(_labelStatusBar, BorderLayout.SOUTH);
         else
            _bottomPanel.remove(_labelStatusBar);

      }

      /**
      * should the OR button be displayed in the FindPanel
      *
      * @param value a boolean value to indicate if the OR button should be
      *              displayed
      */
      protected void _setShowORButton(Object value)
      {
         _showButtonHelper(OR_ORDER, value);
      }

      /**
      * should the REMOVE button be displayed in the FindPanel
      *
      * @param value a boolean value to indicate if the Remove button should be
      *              displayed
      */
      protected void _setShowRemoveButton(Object value)
      {
         _showButtonHelper(REMOVE_ORDER, value);
      }


      /**
      * should the Remove All button be displayed in the FindPanel
      *
      * @param value a boolean value to indicate if the RemoveAll button
      *              should be displayed
      */
      protected void _setShowRemoveAllButton(Object value)
      {
         _showButtonHelper(REMOVE_ALL_ORDER, value);
      }

	  protected boolean _isDisableAutomaticWildCardInSearch()
	  {
		  return _parent.isDisableAutomaticWildCardInSearch();
	  }

      protected void _enableControls(boolean flag)
      {

         _findButton.setEnabled(flag);
         _resetButton.setEnabled(flag);
     }

     /**
     * notification that the button click happened. The notification will be
     * passed to the button click listeners
     *
     * @param whichButton a constant indicating which button was clicked
     */
     public void _notifyButtonClick(int whichButton)
     {
        DacFindPanelUIListener listeners[];
        int count = 0;
        synchronized (_buttonListeners)
        {
            count = _buttonListeners.size();
            listeners = new DacFindPanelUIListener[count];
            _buttonListeners.copyInto(listeners);
        }

        for (int i = 0; (i < count); i++)
        {
            DacFindPanelUIListener l = listeners[i];
            switch (whichButton)
            {
                case FIND_BUTTON:
                       l.findButtonClicked();
                       break;
                case RESET_BUTTON:
                       l.resetButtonClicked();
                       break;
                case OR_BUTTON:
                       l.orButtonClicked();
                       break;
                case REMOVE_BUTTON:
                       l.removeButtonClicked();
                       break;
                case REMOVE_ALL_BUTTON:
                       l.removeAllButtonClicked();
                       break;
                case CLOSE_BUTTON:
                       l.closeButtonClicked();
                       break;
            }// switch
        }
    }


    /**
    * A helper method to show/hide button
    *
    */
    protected void _showButtonHelper(int order , Object val)
    {
       boolean state = ((Boolean)val).booleanValue();
       if ( state == _buttonState[order])
           return;
       else
       {
           if ( state )
              _buttonPanel.add(_buttons[order], _getButtonPosition(order));
           else
              _buttonPanel.remove(_buttons[order]);

           _buttonState[order] = state;
       }

    }

    protected int _getButtonPosition(int order)
    {
       if ( order == 0 )
           return 0;

       int pos = 0;
       for ( int i=0; i <= (order -1); i++)
       {
          if ( _buttonState[i] )
             pos++;
       }
       return pos;
   }

   protected boolean _isDataPublished()
   {
       ConstrainedViewCriteriaModel vcm = _parent.getViewCriteriaModel();
       if ( vcm.getRowsetAccess() != null)
            return true;
       return false;
   }

   protected void _notifyPropertyChange(int whichProperty, Object newValue)
   {
       int c = _tabbedPane.getTabCount();
       for ( int i=0; i < c ;i++)
       {
           DataPanel d = (DataPanel)_tabbedPane.getComponentAt(i);
           d._notifyPropertyChange(whichProperty, newValue);
       }
   }

   /**
   *  Query criteria changes your row index if there were any
   *  deletion/addition
   */
   protected int _getRefreshedRowIndex(DataPanel dataPanel)
   {
       for ( int i=1; i <= _tabbedPane.getTabCount(); i++)
       {
           DataPanel d = (DataPanel)_tabbedPane.getComponentAt(i-1);
           if ( d == dataPanel )
               return i;
       }
       return 0;
   }

   protected String _modifyQueryCriteriaValue(int sqlType,Object value, boolean
                      useSpecialChars, Object param)
   {
      return _modifier.modifyQueryCriteriaValue(sqlType,value,
                   useSpecialChars, param);
   }

   protected void _setUserData(int colIndex, Object value)
   {
       ConstrainedViewCriteriaModel vcm = _parent.getViewCriteriaModel();
       if ( vcm.getRowsetAccess() != null)
		   vcm.setUserData(colIndex, value);
   }

   protected Object _getUserData(int colIndex)
   {
       ConstrainedViewCriteriaModel vcm = _parent.getViewCriteriaModel();
       if ( vcm.getRowsetAccess() != null)
    		   return vcm.getUserData(colIndex);
	     return null;
   }

   /**
   *  make sure the entire button text can be displayed instead of ....
   */
   protected Dimension _determineMinButtonSize(JButton b, Dimension desiredSize)
   {
       _buttonWidthCalculateHelper.setText(b.getText());
  	   Dimension requiredSize = _buttonWidthCalculateHelper.getPreferredSize();
	     int minWidth = Math.max(desiredSize.width, requiredSize.width);
	     return new Dimension(minWidth, desiredSize.height);
   }

   // custom editor support
   // @see EditItemInvoker
   
   protected DataPanel getCurrentDataPanel()
   {
        DataPanel dp = (DataPanel)_tabbedPane.getSelectedComponent();
        return dp;
   }

   protected FindItemEditor getFindItemEditor(int col)
   {
        return _editors[col];
   }

   protected FindItemModel getFindItemModel(int row, int col)
   {
       ConstrainedViewCriteriaModel vcm = _parent.getViewCriteriaModel();
       return vcm.getFindItemModel(row, col);
   }
}


class EditItemInvoker implements ActionListener
{
    ViewCriteriaFindPanelUI _parent = null;
  	int _column;
    FindItemModel model = null;
	  EditItemInvoker(ViewCriteriaFindPanelUI parent, int whichColumn)
  	{
  	  	_parent = parent;
	  	  _column = whichColumn;
  	}

  	public void actionPerformed(java.awt.event.ActionEvent event)
	  {
        int panelIndex = _parent.getCurrentViewCriteriaRow();
        DataPanel d = (DataPanel)_parent.getCurrentDataPanel();
        FindItemModel m = _parent.getFindItemModel(panelIndex, _column);
        FindItemEditor e = _parent.getFindItemEditor(_column);

        if  (( d != null) && ( m != null) && (e != null))
        {
              String old = d.getTextFieldValue(_column);
              Object newVal = e.editItem(m, old);
              d.setTextFieldValue(_column, newVal.toString());
        }
    }
}

