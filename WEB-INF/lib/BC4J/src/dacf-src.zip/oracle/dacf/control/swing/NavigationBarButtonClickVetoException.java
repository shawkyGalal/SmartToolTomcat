/*
 * @(#)NavigationBarButtonClickVetoException.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.dacf.control.swing;

/**
 *   The NavigationBarButtonClickedException is thrown by
 *   NavigationBarButtonClickedListeners when they wish to veto the
 *   operation performed by the button click.
 *
 * @see NavigationBar
 * @version SDK
 */
public class NavigationBarButtonClickVetoException extends Exception
{
    public NavigationBarButtonClickVetoException(String s)
    {
        super(s);
    }
}
