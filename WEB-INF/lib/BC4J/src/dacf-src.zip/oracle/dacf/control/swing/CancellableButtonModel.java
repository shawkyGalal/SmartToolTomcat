/*
 * @(#)CancellableButtonModel.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.dacf.control.swing;

import javax.swing.ButtonModel;

/**
 * Extends the JFC ButtonModel to allow selection changes
 * to be vetoed. This model delivers a stateChanging
 * event before changing the models state.
 * </P>
 *
 * @version SDK
 */
public interface CancellableButtonModel extends ButtonModel
{
  /**
  * add selection changing listener 
  * 
  * @param listener event listener to be added
  */
  public void addSelectionChangingListener(SelectionChangingListener listener);

  /**
  * remove selection changing listener 
  * 
  * @param listener event listener to be removed
  */
  public void removeSelectionChangingListener(SelectionChangingListener listener);

}
