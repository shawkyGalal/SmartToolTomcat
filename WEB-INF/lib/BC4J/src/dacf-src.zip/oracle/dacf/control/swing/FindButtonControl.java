/*
 * @(#)FindButtonControl.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.dacf.control.swing;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.Icon;
import javax.swing.JButton;
import oracle.dacf.control.swing.find.FindAction;
import oracle.dacf.control.swing.find.FindItemModel;

/**
 *  FindButtonControl. A Button control to execute a parameterized query.
 *
 *  A data item name for a rowset has to be specified. This rowset will be used
 *  to execute the query.
 *
 *  This control creates a WHERE clause of form
 *     WHERE (  ( col1 = val1) AND (col2 = val2)....)
 * and sets this as a query condtion and executes the query.
 *
 *  For each column a FindItemModel has to be specified. This model is used 
 *  to  get the column name, type and value which is used to build the query.
 *
 *
 *  Usage   ( also see FindPanel implementation)
 *
 *   FindButtonControl  findButton = new FindAction();
 *
 *   FindTextFieldControl findText1 = new FindTextFieldControl();
 *   FindTextFieldControl findText2 = new FindTextFieldControl();
 *
 *   FindItemModel findModel[] = { findText1, findText2 }
 *
 *   // query to execute
 *   findButton.setDataItemName("infobus:/oracle/Sess1/EMP"); // rowset name
 *   findButton.setFindItemModel(findModel); // column names and value
 *
 *   this.add(findText1); // add field for the user to specify value for ENAME
 *   this.add(findText2); // add field for the user to specify value for MGR
 *   this.add(findButton); // find button picks values from findText1 and
 *                // findText2 fields, creates a WHERE clause and executes query
 *
 *
 *  @see FindItemModel
 *  @see FindAction
 *
 *  @version SDK
 */
public class FindButtonControl extends JButton
{
    /**
    *  Object which actually provides the functionality.
    */
    private FindAction _findAction = new FindAction();

    /**
    *  Constructor
    */
    public FindButtonControl()
    {
      this("",null);
    }

    /**
    *  Constructor
    *  @param text for the button
    */
    public FindButtonControl(String text)
    {
      this(text, null);
    }

    /**
    *  Constructor
    *  @param icon for the button
    */
    public FindButtonControl(Icon icon)
    {
       this("", icon);
    }

    /**
    *  Constructor
    *  @param text for the button
    *  @param icon for the button
    */

    public FindButtonControl(String text, Icon icon)
    {
        super(text, icon);
        this.addActionListener(new ActionListener(){
             public void actionPerformed(ActionEvent evt)
             {
                _findAction.actionPerformed(evt);
             }
          }
        );
    }

   /**
   * Specify the data item name for the rowset. The
   * Query condition will be specified on the rowset and
   * the query executed.
   *
   * @param data item name for the rowset
   */
   public void setDataItemName(String dataItemName)
   {
       _findAction.setDataItemName(dataItemName);
   }

   /**
   *  Return the data item name for the row set.
   *
   *  @return data item name for the row set
   */
   public String getDataItemName()
   {
     return _findAction.getDataItemName();
   }

   /**
   *  specify the FindItemModel to build the query
   *  @param findItemModel for each column
   */
   public void setFindItemModel( FindItemModel[] findItemModel)
   {
       _findAction.setFindItemModel(findItemModel);
   }

   /**
   *  @return FindItemModel
   */
   public FindItemModel[] getFindItemModel()
   {
     return _findAction.getFindItemModel();
   }
}
