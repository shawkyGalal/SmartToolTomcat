/*
 * @(#)LoginDlg.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.dacf.control.swing;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Frame;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;
import java.net.URL;
import java.sql.DriverPropertyInfo;
import java.util.Hashtable;
import java.util.Properties;
import javax.infobus.DataItem;
import javax.infobus.DataItemAddedEvent;
import javax.infobus.DataItemDeletedEvent;
import javax.infobus.DataItemRevokedEvent;
import javax.infobus.DataItemValueChangedEvent;
import javax.infobus.DbAccess;
import javax.infobus.RowsetCursorMovedEvent;
import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import oracle.dacf.control.Control;
import oracle.dacf.control.DbAccessSupport;
import oracle.dacf.control.InfoBusManager;
import oracle.dacf.control.InfoBusManagerListener;
import oracle.dacf.control.InfoBusManagerReleaseEvent;
import oracle.dacf.control.LoginFailureException;
import oracle.dacf.control.NavigatedEvent;
import oracle.dacf.control.NavigatedListener;
import oracle.dacf.control.NavigatingEvent;
import oracle.dacf.control.NavigatingException;
import oracle.dacf.control.NavigatingListener;
import oracle.dacf.dataset.DataItemProperties;
import oracle.dacf.dataset.ExceptionProcessor;
import oracle.jdeveloper.cm.ConnectionDescriptor;
import oracle.jdeveloper.cm.ConnectionManager;

/**
 * Class to fetch login information from the user
 *
 * @version PUBLIC
 */
public class LoginDlg
    extends JDialog
    implements ActionListener, Control, InfoBusManagerListener
{
    /**
    *  Parent panel. holds _topPanel and _bottomPanel
    */
    JPanel _dlgPanel    = new JPanel(); // panel which this dialog holds

    /**
    *  contains image, label and text fields
    */
    JPanel _topPanel    = new JPanel(); // everything excluding butons here.

    /**
    * Hold the three buttons here.
    */
    JPanel _bottomPanel = new JPanel();


    /**
    *  image gets displayed here.
    */
    Box _boxImage     = new Box(BoxLayout.Y_AXIS);

    /**
    *  icon to denote 'Login'
    */
    //ImageIcon _iconUser = new ImageIcon();

    /**
    *  display the Login Icon here
    */
    JLabel    _labelIcon = new JLabel(); // icon

    /**
    *  labels for user name, password, connectionURL, driver class,
    *  driver type, databaseURL, connection name,
    *  application module type, application module class, locking mode,
    *  server timeout, deployment platform, connection mode,
    *  remote host, remote host port, and remote application path
    *
    */
    JLabel _labelUser = new JLabel();
    JLabel _labelPassword = new JLabel();
    JLabel _labelConnectionURL = new JLabel();
    JLabel _labelDriverClass = new JLabel();
    JLabel _labelDatabaseURL = new JLabel();
    JLabel _labelDriverType = new JLabel();
    JLabel _labelConnectionName = new JLabel();
    JLabel _labelIIOPConnectionName = new JLabel();
    JLabel _labelApplicationModuleType = new JLabel();
    JLabel _labelApplicationModuleClass = new JLabel();
    JLabel _labelLockingMode = new JLabel();
    JLabel _labelServerTimeout = new JLabel();
    JLabel _labelDeploymentPlatform = new JLabel();
    JLabel _labelConnectionMode = new JLabel();
    JLabel _labelRemoteHost = new JLabel();
    JLabel _labelRemoteHostPort = new JLabel();
    JLabel _labelRemoteApplicationPath = new JLabel();
    JLabel _labelDbAccessDescriptor = new JLabel();

    /**
    *  controls for user name, password, connectionURL, driver class,
    *  driver type, databaseURL, connection name,
    *  application module type, application module class, locking mode,
    *  server timeout, deployment platform, connection mode,
    *  remote host, remote host port, and remote application path
    *
    */
    JTextField _textUser = new JTextField(40);
    JPasswordField _textPassword = new JPasswordField(40);
    JTextField _textConnectionURL = new JTextField(512);
    JTextField _textDriverClass = new JTextField(128);
    JComboBox _comboDatabaseURL = new JComboBox();
    JTextField _textDatabaseURL = new JTextField(512);
    JComboBox _comboDriverType = new JComboBox();
    JComboBox _comboConnectionName = new JComboBox();
    JComboBox _comboIIOPConnectionName = new JComboBox();
    JComboBox _comboApplicationModuleType = new JComboBox();
    JTextField _textApplicationModuleClass = new JTextField(128);
    JComboBox _comboLockingMode = new JComboBox();
    JTextField _textServerTimeout = new JTextField(10);
    JComboBox _comboDeploymentPlatform = new JComboBox();
    JComboBox _comboConnectionMode = new JComboBox();
    JTextField _textRemoteHost = new JTextField(128);
    JTextField _textRemoteHostPort = new JTextField(10);
    JTextField _textRemoteApplicationPath = new JTextField(256);
    JTextField _textDbAccessDescriptor = new JTextField(10);

    private JComponent _controlDatabaseURL;

    /**
    *  dialog title
    */
    String _title = Res.getString(Res.LOGIN_DIALOG_TITLE);

    /**
    *  OK, Cancel and help button
    */
    JButton _buttonOK = new JButton();
    JButton _buttonCancel = new JButton();
    JButton _buttonHelp = new JButton();

    /**
    *  layout things using...
    */
    GridBagLayout _g;
    GridBagConstraints _c;

    /**
    *  Strings for user name, password, connectionURL, driver class,
    *  driver type, databaseURL, connection name,
    *  application module type, application module class, locking mode,
    *  server timeout, deployment platform, connection mode,
    *  remote host, remote host port, and remote application path
    *
    */
    private String _user;
    private String _password;
    private String _connectionURL;
    private String _driverClass;
    private String _databaseURL;
    private String _driverType;
    private String _connectionName;
    private String _iiopConnectionName;
    private String _applicationModuleType;
    private String _applicationModuleClass;
    private String _lockingMode;
    private String _serverTimeout;
    private String _deploymentPlatform;
    private String _connectionMode;
    private String _remoteHost;
    private String _remoteHostPort;
    private String _remoteApplicationPath;
    private String _dbAccessDescriptor;

    /**
    *  what did the user choose to exit the dialog ? OK or CANCEL
    *  possible values
    *  JOptionPane.OK_OPTION
    *  JOptionPane.CANCEL_OPTION
    */
    private int _dialogExit;

    /**
    *  images located here
    */
    private static final String _IMAGES_DIR = "/oracle/dacf/images/";
    private static final String _loginImageName = "key.gif";

    /**
    * intial values for the dialog
    */
    private String _inputDatabaseURL[] = {""};
    private String _inputDriverType[] = {""};
    private String _inputApplicationModuleType[];
    private String _inputLockingMode[];
    private String _inputDeploymentPlatform[];
    private String _inputConnectionMode[];
    private String _inputConnectionName[];
    private String _inputIIOPConnectionName[];
    private String _inputUser = "";
    private String _inputPassword = "";

    /**
    * intial values for what to display in the dialog
    */
    private boolean _showUser = true;
    private boolean _showPassword = true;
    private boolean _showDatabaseURL = true;
    private boolean _showDriverType = false;
    private boolean _showConnectionURL = false;
    private boolean _showDriverClass = false;
    private boolean _showConnectionName = false;
    private boolean _showIIOPConnectionName=false;
    private boolean _showApplicationModuleType = false;
    private boolean _showApplicationModuleClass = false;
    private boolean _showLockingMode = false;
    private boolean _showServerTimeout = false;
    private boolean _showDeploymentPlatform = false;
    private boolean _showConnectionMode = false;
    private boolean _showRemoteHost = false;
    private boolean _showRemoteHostPort = false;
    private boolean _showRemoteApplicationPath = false;
    private boolean _showDbAccessDescriptor = false;

    /**
    * maximum retry count
    */
    private int _retryCount;
    private int _maxRetryCount = 2;

    /**
    * focus already requested indicator
    */
    private JComponent _focusRequested;

    /**
    * counter to set dialog size with
    */

    private int _fieldCount;

    /**
    * helper object to get dbAccess interface
    */
    private DbAccessSupport _dbAccessSupport = new DbAccessSupport();

    /**
    *  used to determine curr driver selection
    */
    private String _driverSelected = "";

    /**
    *  used to determine current connection properties
    */
    private DriverPropertyInfo[] _drvProp;
    private ConnectionManager _cm;

    /**
    *  default and maximum sizes for the edit fields
    */
    private Dimension _defaultFieldSize = new Dimension(80,20);
    private Dimension _maxFieldSize = new Dimension(300,20);
    private Dimension _preferredButtonSize = new Dimension(80,25);
    private int _dialogWidth = 325;
    private int _dialogHeight= 150;

    /**
    *  interlock to keep from looping on exit
    */

    private boolean _alreadyExiting = false;

    /**
    *  Hashtable to simplify driver property handling
    */
    private static final int PROPERTY_COUNT = 15;
    private static Hashtable _propIDTable = new Hashtable(PROPERTY_COUNT);

    static {
        _propIDTable.put(DataItemProperties.USERNAME,
                         new Integer(DataItemProperties.USERNAME_PROP));
        _propIDTable.put(DataItemProperties.PASSWORD,
                         new Integer(DataItemProperties.PASSWORD_PROP));
        _propIDTable.put(DataItemProperties.CONNECTION_URL,
                         new Integer(DataItemProperties.CONNECTION_URL_PROP));
        _propIDTable.put(DataItemProperties.DRIVER_CLASS,
                         new Integer(DataItemProperties.DRIVER_CLASS_PROP));
        _propIDTable.put(DataItemProperties.DRIVER_TYPE,
                         new Integer(DataItemProperties.DRIVER_TYPE_PROP));
        _propIDTable.put(DataItemProperties.DATABASE_URL,
                         new Integer(DataItemProperties.DATABASE_URL_PROP));
        _propIDTable.put(DataItemProperties.CONNECTION_NAME,
                        new Integer(DataItemProperties.CONNECTION_NAME_PROP));
        _propIDTable.put(DataItemProperties.IIOP_CONNECTION_NAME,
                         new Integer(DataItemProperties.IIOP_CONNECTION_NAME_PROP));
        _propIDTable.put(DataItemProperties.APPLICATION_MODULE_CLASS,
                         new Integer(DataItemProperties.APPLICATION_MODULE_CLASS_PROP));
        _propIDTable.put(DataItemProperties.LOCKING_MODE,
                         new Integer(DataItemProperties.LOCKING_MODE_PROP));
        _propIDTable.put(DataItemProperties.SERVER_TIMEOUT,
                         new Integer(DataItemProperties.SERVER_TIMEOUT_PROP));
        _propIDTable.put(DataItemProperties.DEPLOYMENT_PLATFORM,
                         new Integer(DataItemProperties.DEPLOYMENT_PLATFORM_PROP));
        _propIDTable.put(DataItemProperties.CONNECTION_MODE,
                         new Integer(DataItemProperties.CONNECTION_MODE_PROP));
        _propIDTable.put(DataItemProperties.REMOTE_HOST,
                         new Integer(DataItemProperties.REMOTE_HOST_PROP));
        _propIDTable.put(DataItemProperties.REMOTE_HOST_PORT,
                         new Integer(DataItemProperties.REMOTE_HOST_PORT_PROP));
        _propIDTable.put(DataItemProperties.REMOTE_APPLICATION_PATH,
                         new Integer(DataItemProperties.REMOTE_APPLICATION_PATH_PROP));
    }

    /**
    *  Constructor
    */
    public LoginDlg()
    {
        this("", new Frame(), null, null, null, null);
    }


    /**
    *  Constructor with a title
    *
    *  @param title for the dialog
    */
    public LoginDlg(String title)
    {
        this(title, new Frame(), null, null, null, null);
    }

    /**
    *  Constructor
    *
    *  Construct the login dialog, specify only the user and password
    *  fields
    *
    * @param title       title for our dialog
    * @param f           frame to use as dialog's parent
    * @param user        user name
    * @param password    password
    */
    public LoginDlg(String title, Frame f, String user, String password)
    {
        this(title, f, user, password, null, null);
    }

    /**
    *  Constructor
    *
    *  Construct the login dialog, specify only the connect string and dirver
    *  type fileds.
    *
    * @param title       title for our dialog
    * @param f           frame to use as dialog's parent
    * @databaseURL     array of connect string
    * @driverType        array of string one for each type of drivers
    */
    public LoginDlg(String title, Frame f, String[] databaseURL,
                    String[] driverType)
    {
        this(title, f, null, null, databaseURL, driverType);
    }


    /**
    *  Constructor
    *
    * @param title       title for our dialog
    * @param f           frame to use as dialog's parent
    * @param user        user name
    * @param password    password
    * @databaseURL     array of connect string
    */
    public  LoginDlg(String title, Frame f, String user, String password,
                     String[] databaseURL, String[] driverType)
    {
        super(f,true);
        if (databaseURL != null)
        {
            _inputDatabaseURL = databaseURL;
        }
        if (driverType != null)
        {
            _inputDriverType = driverType;
        }
        if (user != null)
        {
            _inputUser = user;
        }
        if (password != null)
        {
            _inputPassword = password;
        }
        if (title != null)
        {
            _title = title;
        }

        _createBottomPanel();
        setModal(true);
        setTitle(_title);
        setResizable(true);
        setLocationRelativeTo(this);

        _dialogExit = JOptionPane.CANCEL_OPTION;

        setDialogIcon(_loadImage(_IMAGES_DIR + _loginImageName));

        _dlgPanel.setLayout(new BorderLayout());
        _dlgPanel.add(_bottomPanel,BorderLayout.SOUTH);
        _dlgPanel.add(_topPanel,BorderLayout.CENTER);
        //_dlgPanel.setBorder(BorderFactory.createBevelBorder(1, Color.gray,
        //                                                    Color.gray));

        getContentPane().add(_dlgPanel);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        InfoBusManager.getInstance().addInfoBusManagerListener(this);
    }

    /**
    * display the dialog and ask input from user
    *
    * If user clicks OK, user, password and connect string will be set to
    * user specified values otherwise null
    *
    * @return  what the user chose to exit the dialog.  Possible values are
    *  JOptionPane.OK_OPTION and JOptionPane.CANCEL_OPTION
    *
    */
    public int showDialog()
    {
        show();
        return _dialogExit;
    }


    /**
    * display the dialog and ask input from user
    */
    public void show()
    {
        if ( getDataItem() != null )
        {
            _createTopPanel();
            setSize(_dialogWidth,_dialogHeight);

            super.show();

            if (_focusRequested != null)
            {
                _focusRequested.requestFocus();
            }
        }
        else
        {
           LoginFailureException lfe =
               new LoginFailureException(Res.getString(Res.LOGIN_DIALOG_NOT_BOUND));
           ExceptionProcessor.processException((DataItem) getDataItem(), -1, lfe);
        }
    }


    /**
    *  @deprecated showDialog() returns the final status
    */
    public int getDialogExitCode()
    {
        return _dialogExit;
    }

    /**
    * @deprecated no longer used
    */
    public String getUser()
    {
        return _user;
    }

    /**
    *  @deprecated no longer used
    */

    public String getPassword()
    {
        return _password;
    }

    /**
    *  @deprecated no longer used
    */

    public String getConnectString()
    {
        return _databaseURL;
    }

    /**
    *  @deprecated no longer used
    */
    public String getDriverType()
    {
        return _driverType;
    }

    /**
    *  @deprecated no longer used
    */
    public int getDriverTypeIndex()
    {
        return 0;
    }

    /**
    * Returns whether the LoginDlg displays a User entry field.
    * If <TT>true</TT>, the LoginDlg will display the current value
    * of User, allowing the value to be changed if desired.
    */
    public boolean isShowUser()
    {
        return _showUser;
    }

    /**
    * Sets whether the LoginDlg displays a Password entry field.<P>
    * If <TT>true</TT>, the LoginDlg will display the current value
    * of Password, allowing the value to be changed if desired.
    */
    public void setShowPassword(boolean display)
    {
        _showPassword = display;
    }

    /**
    * Returns whether the LoginDlg displays a Password entry field.
    * If <TT>true</TT>, the LoginDlg will display the current value
    * of Password, allowing the value to be changed if desired.
    */
    public boolean isShowPassword()
    {
        return _showPassword;
    }

    /**
    * Sets whether the LoginDlg displays a User entry field.<P>
    * If <TT>true</TT>, the LoginDlg will display the current value
    * of User, allowing the value to be changed if desired.
    */
    public void setShowUser(boolean display)
    {
        _showUser = display;
    }

    /**
    * Returns whether the LoginDlg displays a databaseURL field.
    * If <TT>true</TT>, the LoginDlg will display the current value
    * of databaseURL and the other selections, allowing the value to be
    * changed if desired.
    */
    public boolean isShowDatabaseURL()
    {
        return _showDatabaseURL;
    }

    /**
    * @deprecated superceded by #isShowDatabaseURL
    */
    public boolean isShowConnectString()
    {
        return _showDatabaseURL;
    }

    /**
    * Sets whether the LoginDlg displays a DatabaseURL entry field.<P>
    * If <TT>true</TT>, the LoginDlg will display the current value
    * of DatabaseURL and the other selections, allowing the value to be
    * changed if desired.
    * DatabaseURL works in conjunction with #setDriverType to define the
    * connectionURL for Oracle JDBC drivers.
    * DriverType is mutually exclusive of the ConnectionURL and DriverClass
    * fields.  Enabling the display of this field will disable those.
    */
    public void setShowDatabaseURL(boolean display)
    {
        _showDatabaseURL = display;
        _showConnectionURL = false;
        _showDriverClass   = false;
    }

    /**
    * @deprecated superceded by #setShowDatabaseURL
    */
    public void setShowConnectString(boolean display)
    {
        _showDatabaseURL = display;
    }

    /**
    * Returns whether the LoginDlg displays a DriverType entry field.
    * If <TT>true</TT>, the LoginDlg will display the current value
    * of DriverType, allowing the value to be changed if desired.
    */
    public boolean isShowDriverType()
    {
        return _showDriverType;
    }

    /**
    * Sets whether the LoginDlg displays a DriverType entry field.<P>
    * If <TT>true</TT>, the LoginDlg will display the current value
    * of DriverType, allowing the value to be changed if desired.
    * DriverType works in conjunction with #setDatabaseURL to define the
    * connectionURL for Oracle JDBC drivers.
    * DriverType is mutually exclusive of the ConnectionURL and DriverClass
    * fields.  Enabling the display of this field will disable those.
    */
    public void setShowDriverType(boolean display)
    {
        _showDriverType = display;
        _showConnectionURL = false;
        _showDriverClass   = false;
    }

    /**
    * Returns whether the LoginDlg displays a ConnectionURL entry field.
    * If <TT>true</TT>, the LoginDlg will display the current value
    * of ConnectionURL, allowing the value to be changed if desired.
    */
    public boolean isShowConnectionURL()
    {
        return _showConnectionURL;
    }

    /**
    * Sets whether the LoginDlg displays a ConnectionURL entry field.<P>
    * If <TT>true</TT>, the LoginDlg will display the current value
    * of ConnectionURL, allowing the value to be changed if desired.
    * ConnectionURL is mutually exclusive of the DatabaseURL and DriverType
    * fields.  Enabling the display of this field will disable those.
    */
    public void setShowConnectionURL(boolean display)
    {
        _showConnectionURL = display;
        _showDatabaseURL = false;
        _showDriverType  = false;
    }

    /**
    * Returns whether the LoginDlg displays a DriverClass entry field.
    * If <TT>true</TT>, the LoginDlg will display the current value
    * of DriverClass, allowing the value to be changed if desired.
    *
    * @deprecated
    */
    public boolean isShowDriverClass()
    {
        return _showDriverClass;
    }

    /**
    * Sets whether the LoginDlg displays a DriverClass entry field.<P>
    * If <TT>true</TT>, the LoginDlg will display the current value
    * of DriverClass, allowing the value to be changed if desired.
    * DriverClass is mutually exclusive of the DatabaseURL and DriverType
    * fields.  Enabling this field will disable those.
    *
    * @deprecated
    */
    public void setShowDriverClass(boolean display)
    {
        _showDriverClass = display;
        _showDatabaseURL = false;
        _showDriverType  = false;
    }

    /**
    * Returns whether the LoginDlg displays a ConnectionNames entry field.
    * If <TT>true</TT>, the LoginDlg will display the current value
    * of ConnectionName, allowing the value to be changed if desired.
    */
    public boolean isShowConnectionNames()
    {
        return _showConnectionName;
    }

    /**
    * Sets whether the LoginDlg displays a IIOP ConnectionNames selection
    * field.<P>
    * If <TT>true</TT>, the LoginDlg will display the available IIOP
    * connection names.
    */
    public void setShowIIOPConnectionNames(boolean display)
    {
        _showIIOPConnectionName = display;
    }

    /**
    * Returns whether the LoginDlg displays a IIOP ConnectionNames entry field.
    * If <TT>true</TT>, the LoginDlg will display the current value
    * of IIOP ConnectionName, allowing the value to be changed if desired.
    */
    public boolean isShowIIOPConnectionNames()
    {
        return _showIIOPConnectionName;
    }

    /**
    * Sets whether the LoginDlg displays a ConnectionNames selection field.<P>
    * If <TT>true</TT>, the LoginDlg will display the available connection names.
    */
    public void setShowConnectionNames(boolean display)
    {
        _showConnectionName = display;
    }



    /**
    * Returns whether the LoginDlg displays a ApplicationModuleType entry field.
    * If <TT>true</TT>, the LoginDlg will display the current value
    * of ApplicationModuleType, allowing the value to be changed if desired.
    *
    * @deprecated setting this no longer has any effect 
    */
    public boolean isShowApplicationModuleType()
    {
        return _showApplicationModuleType;
    }

    /**
    * Sets whether the LoginDlg displays a ApplicationModuleType entry field.<P>
    * If <TT>true</TT>, the LoginDlg will display the current value
    * of ApplicationModuleType, allowing the value to be changed if desired.
    *
    * @deprecated setting this no longer has any effect 
    */
    public void setShowApplicationModuleType(boolean display)
    {
        _showApplicationModuleType = display;
    }

    /**
    * Returns whether the LoginDlg displays a ApplicationModuleClass entry field.
    * If <TT>true</TT>, the LoginDlg will display the current value
    * of ApplicationModuleClass, allowing the value to be changed if desired.
    */
    public boolean isShowApplicationModuleClass()
    {
        return _showApplicationModuleClass;
    }

    /**
    * Sets whether the LoginDlg displays a ApplicationModuleClass entry field.<P>
    * If <TT>true</TT>, the LoginDlg will display the current value
    * of ApplicationModuleClass, allowing the value to be changed if desired.
    */
    public void setShowApplicationModuleClass(boolean display)
    {
        _showApplicationModuleClass = display;
    }

    /**
    * Returns whether the LoginDlg displays a LockingMode entry field.
    * If <TT>true</TT>, the LoginDlg will display the current value
    * of LockingMode, allowing the value to be changed if desired.
    */
    public boolean isShowLockingMode()
    {
        return _showLockingMode;
    }

    /**
    * Sets whether the LoginDlg displays a LockingMode entry field.<P>
    * If <TT>true</TT>, the LoginDlg will display the current value
    * of LockingMode, allowing the value to be changed if desired.
    */
    public void setShowLockingMode(boolean display)
    {
        _showLockingMode = display;
    }

    /**
    * Returns whether the LoginDlg displays a ServerTimeout entry field.
    * If <TT>true</TT>, the LoginDlg will display the current value
    * of ServerTimeout, allowing the value to be changed if desired.
    */
    public boolean isShowServerTimeout()
    {
        return _showServerTimeout;
    }

    /**
    * Sets whether the LoginDlg displays a ServerTimeout entry field.<P>
    * If <TT>true</TT>, the LoginDlg will display the current value
    * of ServerTimeout, allowing the value to be changed if desired.
    */
    public void setShowServerTimeout(boolean display)
    {
        _showServerTimeout = display;
    }

    /**
    * Returns whether the LoginDlg displays a DeploymentPlatform entry field.
    * If <TT>true</TT>, the LoginDlg will display the current value
    * of DeploymentPlatform, allowing the value to be changed if desired.
    *
    * @deprecated setting this no longer has any effect 
    */
    public boolean isShowDeploymentPlatform()
    {
        return _showDeploymentPlatform;
    }

    /**
    * Sets whether the LoginDlg displays a DeploymentPlatform entry field.<P>
    * If <TT>true</TT>, the LoginDlg will display the current value
    * of DeploymentPlatform, allowing the value to be changed if desired.
    *
    * @deprecated setting this no longer has any effect 
    */
    public void setShowDeploymentPlatform(boolean display)
    {
        _showDeploymentPlatform = display;
    }

    /**
    * Returns whether the LoginDlg displays a ConnectionMode entry field.
    * If <TT>true</TT>, the LoginDlg will display the current value
    * of ConnectionMode, allowing the value to be changed if desired.
    *
    * @deprecated setting this no longer has any effect 
    */
    public boolean isShowConnectionMode()
    {
        return _showConnectionMode;
    }

    /**
    * Sets whether the LoginDlg displays a ConnectionMode entry field.<P>
    * If <TT>true</TT>, the LoginDlg will display the current value
    * of ConnectionMode, allowing the value to be changed if desired.
    *
    * @deprecated setting this no longer has any effect 
    */
    public void setShowConnectionMode(boolean display)
    {
        _showConnectionMode = display;
    }

    /**
    * Returns whether the LoginDlg displays a RemoteHost entry field.
    * If <TT>true</TT>, the LoginDlg will display the current value
    * of RemoteHost, allowing the value to be changed if desired.
    *
    * This method is depreceated. Use isShowIIOPConnectionName
    * @deprecated
    */
    public boolean isShowRemoteHost()
    {
        return _showRemoteHost;
    }

    /**
    * Sets whether the LoginDlg displays a RemoteHost entry field.<P>
    * If <TT>true</TT>, the LoginDlg will display the current value
    * of RemoteHost, allowing the value to be changed if desired.
    *
    * This method is depreceated. Use setShowIIOPConnectionName
    *
    * @deprecated
    */
    public void setShowRemoteHost(boolean display)
    {
        _showRemoteHost = display;
    }

    /**
    * Returns whether the LoginDlg displays a RemoteHostPort entry field.
    * If <TT>true</TT>, the LoginDlg will display the current value
    * of RemoteHostPort, allowing the value to be changed if desired.
    *
    * This method is depreceated. Use isShowIIOPConnectionName
    *
    * @deprecated
    */
    public boolean isShowRemoteHostPort()
    {
        return _showRemoteHostPort;
    }

    /**
    * Sets whether the LoginDlg displays a RemoteHostPort entry field.<P>
    * If <TT>true</TT>, the LoginDlg will display the current value
    * of RemoteHostPort, allowing the value to be changed if desired.
    *
    * This method is depreceated. Use isShowIIOPConnectionName
    *
    * @deprecated
    */
    public void setShowRemoteHostPort(boolean display)
    {
        _showRemoteHostPort = display;
    }

    /**
    * Returns whether the LoginDlg displays a RemoteApplicationPath entry field.
    * If <TT>true</TT>, the LoginDlg will display the current value
    * of RemoteApplicationPath, allowing the value to be changed if desired.
    */
    public boolean isShowRemoteApplicationPath()
    {
        return _showRemoteApplicationPath;
    }

    /**
    * Sets whether the LoginDlg displays a RemoteApplicationPath entry field.<P>
    * If <TT>true</TT>, the LoginDlg will display the current value
    * of RemoteApplicationPath, allowing the value to be changed if desired.
    */
    public void setShowRemoteApplicationPath(boolean display)
    {
        _showRemoteApplicationPath = display;
    }


    /**
    * Sets whether the LoginDlg displays a DbAccess Descriptor entry field.<P>
    * If <TT>true</TT>, the LoginDlg will display the current value
    * of DbAccess Descriptor, allowing the value to be changed if desired.
    *
    * @deprecated setting this no longer has any effect 
    */
    public void setShowDbAccessDescriptor(boolean display)
    {
        _showDbAccessDescriptor = display;
    }

    /**
    * Returns whether the LoginDlg displays a DbAccess descriptor entry field.
    * If <TT>true</TT>, the LoginDlg will display the current value
    * of DbAccess Descriptor, allowing the value to be changed if desired.
    *
    * @deprecated setting this no longer has any effect 
    */
    public boolean isShowDbAccessDescriptor()
    {
        return _showDbAccessDescriptor;
    }


    /**
    * specify the name of the SessionInfo to connect to.
    *
    * The LoginDlg will use the corresponding SessionInfo object to connect to
    * the database.
    *
    * @param dataItemName  : name of the session to connect to
    */
    public void setDataItemName(String dataItemName)
    {
        if ( _dbAccessSupport != null )
        {
            _dbAccessSupport.setDataItemName(dataItemName);
            if ( _dbAccessSupport.getDataItem() != null )
            {
                _initFieldsFromDbAccess();
            }
        }
    }

    /**
    * @return name of the Session we are bound to
    */
    public String getDataItemName()
    {
        return (_dbAccessSupport.getDataItemName());
    }

    /**
    * Specify icon to be used in the dialog
    *
    * @param i icon to be used in the dialog
    */

    public void setDialogIcon(Icon i)
    {
        _labelIcon.setIcon(i);
    }

    /**
    *  get the icon currently in use
    *  @return icon currently in use
    */

    public Icon getImageIcon()
    {
        return _labelIcon.getIcon();
    }

    // InfoBusManagerListener interface implementation
    public void releaseResources(InfoBusManagerReleaseEvent e)
    {
        if (e.appliesTo(this))
        {
            InfoBusManager.getInstance().removeInfoBusManagerListener(this);
            _dbAccessSupport = null;
        }
    }

    /**
    ** An override of java.awt.Component.setEnabled. <P>
    **
    ** @param b boolean flag indicating whether the control is enabled
    */
    public void setEnabled(boolean b)
    {
        super.setEnabled(b);
    } // setEnabled

    /**
    ** Will be called back from ControlSupport to set the actual value.
    */
    void _doSetEnabled(boolean b)
    {
    }

    /**
    * Returns the name of the InfoBus this control is connected to. <P>
    */
    public String getInfoBusName()
    {
        return (_dbAccessSupport.getInfoBusName());
    }

    /**
    * Sets the name of the InfoBus this control is connected to. <P>
    * By default, the control is connected to the default InfoBus,
    * named <TT>DEFAULT_INFOBUS_NAME</TT>. <P>
    * If the named InfoBus does not exist, it is created automatically. <P>
    * If the control is already connected to an InfoBus, it is disconnected
    * first. <P>
    */
    public void setInfoBusName(String infoBusName)
    {
        _dbAccessSupport.setInfoBusName(infoBusName);
    }

    /**
    * Returns the InfoBus DataItem this control is bound to. <P>
    * Most controls should delegate this method to <TT>ControlSupport</TT>. <P>
    * @return  The InfoBus DataItem this control is bound to, or
    *          <TT>null</TT> if the control is unbound.
    * @see ControlSupport#getDataItem
    */
    public Object getDataItem()
    {
        return _dbAccessSupport.getDataItem();
    }

    /**
    * Notifies the control that the bound InfoBus DataItem has changed. <P>
    * The control can safely ignore this notification. <P>
    * @param oldDataItem   The formerly bound DataItem (can be <TT>null</TT>).
    * @param newDataItem   The newly bound DataItem (can be <TT>null</TT>).
    */
    public void dataItemChanged(Object oldDataItem, Object newDataItem)
    {
        // no op
    }



    // UI Control support

    /**
    * Returns the AWT component associated with this control. <P>
    * @return  The AWT component for this control.
    */
    public Component getComponent()
    {
        return this;
    }


    // ValidationManager support

    /**
    * Determines whether focus into this control causes validation to
    * occur. <P>
    * Most controls should delegate this method to <TT>ControlSupport</TT>. <P>
    * @return  <TT>true</TT> if focus into this control causes validation to
    *          occur, <TT>false</TT> otherwise.
    * @see ControlSupport#isFocusValidated
    */
    public boolean isFocusValidated()
    {
        return _dbAccessSupport.isFocusValidated();
    }

    /**
    * Sets whether focus into this control causes validation to occur. <P>
    * Most controls should delegate this method to <TT>ControlSupport</TT>. <P>
    * @param focusValidated    If <TT>true</TT>, focus into this control will
    *                          cause validation to occur.
    * @see ControlSupport#setFocusValidated
    */
    public void setFocusValidated(boolean focusValidated)
    {
        _dbAccessSupport.setFocusValidated(focusValidated);
    }


    // NavigationManager support

    /**
    * not supported
    * @param listener  The listener to add.
    */
    public void addNavigatedListener(NavigatedListener listener)
    {
        // no op
    }

    /**
    * not supported
    * @param listener  The listener to remove.
    */
    public void removeNavigatedListener(NavigatedListener listener)
    {
    }

    /**
    * not supported
    * @param event The navigated event.
    */
    public void processNavigatedEvent(NavigatedEvent event)
    {
    }

    /**
    * not supported
    * @param listener  The listener to add.
    */
    public void addNavigatingListener(NavigatingListener listener)
    {
    }

    /**
    * not supported
    * @param listener  The listener to remove.
    */
    public void removeNavigatingListener(NavigatingListener listener)
    {
    }

    /**
    * Not supported.
    * @param event The navigating event.
    * @exception NavigatingException   If the navigation is redirected to a
    *                                  different control.
    */
    public void processNavigatingEvent(NavigatingEvent event)
        throws NavigatingException
    {
    }

    /**
    * Not supported.
    * @param event Contains details of the cursor move.
    * @see javax.infobus.DataItemChangeListener#rowsetCursorMoved
    */
    public final void rowsetCursorMoved(RowsetCursorMovedEvent event)
    {
        // Not applicable
    }

    // DataItemChangeListener Interface

    /**
    * Not supported.
    * @param event Contains change information.
    * @see javax.infobus.DataItemChangeListener#dataItemValueChanged
    */
    public final void dataItemValueChanged(DataItemValueChangedEvent event)
    {
    }

    /**
    * Not supported.
    * @param event Contains details of the addition.
    * @see javax.infobus.DataItemChangeListener#dataItemAdded
    */
    public final void dataItemAdded(DataItemAddedEvent event)
    {
        // Not applicable
    }

    /**
    * Not supported.
    * @param event Contains details of the deletion.
    * @see javax.infobus.DataItemChangeListener#dataItemDeleted
    */
    public final void dataItemDeleted(DataItemDeletedEvent event)
    {
        // Not applicable
    }

    /**
    * Not supported.
    * @param event Contains details of the revoked data.
    * @see javax.infobus.DataItemChangeListener#dataItemRevoked
    */
    public final void dataItemRevoked(DataItemRevokedEvent event)
    {
        // not applicable
    }


    /**
    * This method is called when a window event occurs.
    *
    * @param  e  the event which caused this method to be called
    */
    protected void processWindowEvent(WindowEvent e)
    {
        super.processWindowEvent(e);

        if (e.getID() == WindowEvent.WINDOW_CLOSED && !_alreadyExiting)
        {
            _cancelButtonClicked();
        }
    }

    private void _buildTextField(JTextField field, String text, JLabel trim, String label)
    {
        field.setText(text);
        field.setPreferredSize(_defaultFieldSize);
        field.setMaximumSize(_maxFieldSize);
        field.addActionListener(this);
        trim.setText(label);
    }

    private JComboBox _buildComboBoxField(Object[] selections, String curr_selection, JLabel trim, String label)
    {
        JComboBox field = new JComboBox(selections);
        field.setSelectedItem(curr_selection);
        field.setPreferredSize(_defaultFieldSize);
        field.setMaximumSize(_maxFieldSize);
        field.setEditable(false);
        trim.setText(label);
        return field;
    }

    private void _addPairToGridBag(JLabel label, JComponent component)
    {
        _c.gridx = 1;
        _c.fill = GridBagConstraints.NONE;
        _c.weightx = 0;
        _c.anchor = GridBagConstraints.EAST;
        _g.setConstraints(label, _c);
        _topPanel.add(label);

        _c.gridx = 2;
        _c.fill = GridBagConstraints.HORIZONTAL;
        _c.weightx = 1;
        _c.anchor = GridBagConstraints.CENTER;
        _g.setConstraints(component, _c);
        _topPanel.add(component);
        if (_focusRequested == null)
        {
            _focusRequested = component;
        }
        _fieldCount++;
        _c.gridy = GridBagConstraints.RELATIVE;
    }

    private void _createTopPanel()
    {
        _topPanel.removeAll();
        _boxImage.add(_labelIcon); // display icon

        _g = new GridBagLayout();
        _topPanel.setLayout(_g);

        _c = new GridBagConstraints();

        _c.gridx=0; _c.gridy=0;
        _c.anchor = GridBagConstraints.NORTH;
        _c.insets = new Insets(1, 5, 1, 5);

        _c.gridheight = GridBagConstraints.REMAINDER; _c.gridwidth = 1;
        _g.setConstraints(_boxImage, _c);
        _topPanel.add(_boxImage);

        _c.gridheight = 1;

        _fieldCount = 0;
        _focusRequested = null;

        // named connections
        if (_showConnectionName)
        {
            _cm = ConnectionManager.getInstance();
            try
            {
               _inputConnectionName = _cm.getConnectionNames(ConnectionDescriptor.LEGACY_TYPE_JDBC, false);
               _comboConnectionName = _buildComboBoxField(_inputConnectionName,
                                                          _connectionName,
                                                          _labelConnectionName,
                                                          Res.getString(Res.LOGIN_CONNECTION_NAME_LABEL));
               _comboConnectionName.setActionCommand(Res.getString(Res.LOGIN_CONNECTION_NAME_LABEL));
               _addPairToGridBag(_labelConnectionName, _comboConnectionName);
            }
            catch (Exception exc)
            {
               //_displayMessageDialog(Res.getString(Res.NAMED_CONNECTIONS_NOT_FOUND), JOptionPane.ERROR_MESSAGE);
               LoginFailureException lfe =
                   new LoginFailureException(Res.getString(Res.NAMED_CONNECTIONS_NOT_FOUND) +
                                             " " + exc.getMessage());
               ExceptionProcessor.processException((DataItem) getDataItem(), -1, lfe);
            }
        }
        // named IIOP connections
        if (_showIIOPConnectionName)
        {
            _cm = ConnectionManager.getInstance();
            try
            {
               _inputIIOPConnectionName = _cm.getConnectionNames(ConnectionDescriptor.LEGACY_TYPE_IIOP, true);
               _comboIIOPConnectionName = _buildComboBoxField(_inputIIOPConnectionName,
                                                          _iiopConnectionName,
                                                          _labelIIOPConnectionName,
                                                          Res.getString(Res.LOGIN_IIOP_CONNECTION_NAME_LABEL));
               _comboConnectionName.setActionCommand(Res.getString(Res.LOGIN_IIOP_CONNECTION_NAME_LABEL));
               _addPairToGridBag(_labelIIOPConnectionName, _comboIIOPConnectionName);
            }
            catch (Exception exc)
            {
               //_displayMessageDialog(Res.getString(Res.NAMED_CONNECTIONS_NOT_FOUND), JOptionPane.ERROR_MESSAGE);
               LoginFailureException lfe =
                   new LoginFailureException(Res.getString(Res.NAMED_CONNECTIONS_NOT_FOUND) +
                                             " " + exc.getMessage());
               ExceptionProcessor.processException((DataItem) getDataItem(), -1, lfe);
            }
        }

        // user label and field
        if  (_showUser)
        {
            _buildTextField(_textUser, _user, _labelUser, Res.getString(Res.LOGIN_USER_LABEL));
            _addPairToGridBag(_labelUser, _textUser);
        }
        // password label and field
        if (_showPassword)
        {
            _buildTextField(_textPassword, _password, _labelPassword, Res.getString(Res.LOGIN_PASSWORD_LABEL));
            _addPairToGridBag(_labelPassword, _textPassword);
        }
        // database URL
        if (_showDatabaseURL)
        {
            if (_inputDatabaseURL.length > 1)
            {
                _comboDatabaseURL =
                    _buildComboBoxField(_inputDatabaseURL, _databaseURL, _labelDatabaseURL, Res.getString(Res.LOGIN_DATABASE_URL_LABEL));
                _comboDatabaseURL.setEditable(true);
                _controlDatabaseURL = _comboDatabaseURL;
            }
            else
            {
                _buildTextField(_textDatabaseURL, _databaseURL, _labelDatabaseURL, Res.getString(Res.LOGIN_DATABASE_URL_LABEL));
                _controlDatabaseURL = _textDatabaseURL;
            }
            _addPairToGridBag(_labelDatabaseURL, _controlDatabaseURL);
        }
        // driver type
        if (_showDriverType)
        {
            _comboDriverType =
                _buildComboBoxField(_inputDriverType, _driverType, _labelDriverType, Res.getString(Res.LOGIN_DRIVER_LABEL));
            _addPairToGridBag(_labelDriverType, _comboDriverType);
        }
        // connection URL
        if (_showConnectionURL)
        {
            _buildTextField(_textConnectionURL, _connectionURL, _labelConnectionURL, Res.getString(Res.LOGIN_CONNECTION_URL));
            _addPairToGridBag(_labelConnectionURL, _textConnectionURL);
        }
        // driver class
        if (_showDriverClass)
        {
            _buildTextField(_textDriverClass, _driverClass, _labelDriverClass, Res.getString(Res.LOGIN_DRIVER_CLASS));
            _addPairToGridBag(_labelDriverClass, _textDriverClass);
        }
        // application module class
        if (_showApplicationModuleClass)
        {
            _buildTextField(_textApplicationModuleClass, _applicationModuleClass, _labelApplicationModuleClass, Res.getString(Res.LOGIN_APPLICATION_MODULE_CLASS));
            _addPairToGridBag(_labelApplicationModuleClass, _textApplicationModuleClass);
        }
        // locking mode
        if (_showLockingMode)
        {
            _comboLockingMode =
                _buildComboBoxField(_inputLockingMode, _lockingMode, _labelLockingMode, Res.getString(Res.LOGIN_LOCKING_MODE));
            _addPairToGridBag(_labelLockingMode, _comboLockingMode);
        }
        // server timeout
        if (_showServerTimeout)
        {
            _buildTextField(_textServerTimeout, _serverTimeout, _labelServerTimeout, Res.getString(Res.LOGIN_SERVER_TIMEOUT));
            _addPairToGridBag(_labelServerTimeout, _textServerTimeout);
        }
        // deployment platform
        if (_showDeploymentPlatform)
        {
            _comboDeploymentPlatform =
                _buildComboBoxField(_inputDeploymentPlatform, _deploymentPlatform, _labelDeploymentPlatform, Res.getString(Res.LOGIN_DEPLOYMENT_PLATFORM));
            _addPairToGridBag(_labelDeploymentPlatform, _comboDeploymentPlatform);
        }
        // connection mode
        if (_showConnectionMode)
        {
            _comboConnectionMode =
                _buildComboBoxField(_inputConnectionMode, _connectionMode, _labelConnectionMode, Res.getString(Res.LOGIN_CONNECTION_MODE));
            _addPairToGridBag(_labelConnectionMode, _comboConnectionMode);
        }
        // remote host
        if (_showRemoteHost)
        {
            _buildTextField(_textRemoteHost, _remoteHost, _labelRemoteHost, Res.getString(Res.LOGIN_REMOTE_HOST));
            _addPairToGridBag(_labelRemoteHost, _textRemoteHost);
        }
        // remote host port
        if (_showRemoteHostPort)
        {
            _buildTextField(_textRemoteHostPort, _remoteHostPort, _labelRemoteHostPort, Res.getString(Res.LOGIN_REMOTE_HOST_PORT));
            _addPairToGridBag(_labelRemoteHostPort, _textRemoteHostPort);
        }
        // remote application path
        if (_showRemoteApplicationPath)
        {
            _buildTextField(_textRemoteApplicationPath, _remoteApplicationPath, _labelRemoteApplicationPath, Res.getString(Res.LOGIN_REMOTE_APPLICATION_PATH));
            _addPairToGridBag(_labelRemoteApplicationPath, _textRemoteApplicationPath);
        }

        // Db Access descriptor
        if (_showDbAccessDescriptor)
        {
            _buildTextField(_textDbAccessDescriptor, _dbAccessDescriptor, _labelDbAccessDescriptor, Res.getString(Res.LOGIN_DB_ACCESS_DESCRIPTOR));
            _addPairToGridBag(_labelDbAccessDescriptor, _textDbAccessDescriptor);
        }
        _topPanel.setBorder(BorderFactory.createEtchedBorder());
        _dialogHeight = (_fieldCount * 24) + 40;
        if (_fieldCount <= 1) _dialogHeight += 30;
        _topPanel.setPreferredSize(new Dimension(_dialogWidth,_dialogHeight));
        _dialogHeight = _dialogHeight + 40;
    }


    /**
    *  create the bottom panel for the dialog. The bottom panel holds
    *  the OK, CANCEL and HELP buttons
    */

    private void _createBottomPanel()
    {
        _bottomPanel.removeAll();
        // button labels
        _buttonOK.setText(Res.getString(Res.OK_BUTTON_TEXT));
        _buttonCancel.setText(Res.getString(Res.CANCEL_BUTTON_TEXT));
        _buttonHelp.setText(Res.getString(Res.HELP_BUTTON_TEXT));

        // button mnemonics
        _buttonOK.setMnemonic(Res.getString(Res.OK_BUTTON_MNEMONIC).charAt(0));
        _buttonCancel.setMnemonic(Res.getString(Res.CANCEL_BUTTON_MNEMONIC).charAt(0));
        _buttonHelp.setMnemonic(Res.getString(Res.HELP_BUTTON_MNEMONIC).charAt(0));

        // default button handling
        //_buttonOK.setDefaultCapable(true);
        getRootPane().setDefaultButton(_buttonOK);
        _buttonOK.setPreferredSize(_preferredButtonSize);
        _buttonCancel.setPreferredSize(_preferredButtonSize);
        _buttonHelp.setPreferredSize(_preferredButtonSize);

        _bottomPanel.setLayout( new FlowLayout());
        _bottomPanel.add(_buttonOK);
        _bottomPanel.add(_buttonCancel);
        _bottomPanel.add(_buttonHelp);

        _bottomPanel.setBorder(BorderFactory.createEmptyBorder());

        _bottomPanel.setPreferredSize(new Dimension(_dialogWidth,40));

        _buttonOK.addActionListener(this);
        _buttonOK.setActionCommand(Res.getString(Res.OK_BUTTON_TEXT));
        _buttonCancel.addActionListener(this);
        _buttonCancel.setActionCommand(Res.getString(Res.CANCEL_BUTTON_TEXT));
        _buttonHelp.addActionListener(this);
        _buttonHelp.setActionCommand(Res.getString(Res.HELP_BUTTON_TEXT));

    }

    private void _okButtonClicked()
    {
        Properties prop = new Properties();
        String value;
        boolean emptyField = false;
        if  (_showUser)
        {
            value = _textUser.getText();
            if (value == "")
                emptyField = true;
            else
                prop.put(DataItemProperties.USERNAME, value);
        }
        if (_showPassword)
        {
            value = _textPassword.getText();
            if (value == "")
                emptyField = true;
            else
                prop.put(DataItemProperties.PASSWORD, value);
        }
        if (_showDatabaseURL)
        {
            if (_inputDatabaseURL.length > 1)
            {
                value = (String)_comboDatabaseURL.getSelectedItem();
            }
            else
            {
                value = _textDatabaseURL.getText();
            }
            if (value == "")
                emptyField = true;
            else
                prop.put(DataItemProperties.DATABASE_URL, value);
        }
        if (_showConnectionName)
        {
           value = (String)_comboConnectionName.getSelectedItem();
           if ( value != null )
              prop.put(DataItemProperties.CONNECTION_NAME, value);
        }
        if (_showIIOPConnectionName)
        {
           value = (String)_comboIIOPConnectionName.getSelectedItem();
           if ( value != null)
              prop.put(DataItemProperties.IIOP_CONNECTION_NAME, value);
        }
        if (_showDriverType)
        {
            value = (String)_comboDriverType.getSelectedItem();
            prop.put(DataItemProperties.DRIVER_TYPE, value);
        }
        if (_showConnectionURL)
        {
            value = _textConnectionURL.getText();
            if (value == "")
                emptyField = true;
            else
                prop.put(DataItemProperties.CONNECTION_URL, value);
        }
        if (_showDriverClass)
        {
            value = _textDriverClass.getText();
            if (value == "")
                emptyField = true;
            else
                prop.put(DataItemProperties.DRIVER_CLASS, value);
        }
        if (_showApplicationModuleClass)
        {
            value = _textApplicationModuleClass.getText();
            if (value == "")
                emptyField = true;
            else
                prop.put(DataItemProperties.APPLICATION_MODULE_CLASS, value);
        }
        if (_showLockingMode)
        {
            value = (String)_comboLockingMode.getSelectedItem();
            if ( value != null )
               prop.put(DataItemProperties.LOCKING_MODE, value);
        }
        if (_showServerTimeout)
        {
            value = _textServerTimeout.getText();
            if (value == "")
                emptyField = true;
            else
                prop.put(DataItemProperties.SERVER_TIMEOUT, value);
        }
        if (_showDeploymentPlatform)
        {
            value = (String)_comboDeploymentPlatform.getSelectedItem();
            if ( value != null )
                prop.put(DataItemProperties.DEPLOYMENT_PLATFORM, value);
        }
        if (_showConnectionMode)
        {
            value = (String)_comboConnectionMode.getSelectedItem();
            if ( value != null)
               prop.put(DataItemProperties.CONNECTION_MODE, value);
        }
        if (_showRemoteHost)
        {
            value = _textRemoteHost.getText();
            if (value == "")
                emptyField = true;
            else
                prop.put(DataItemProperties.REMOTE_HOST, value);
        }
        if (_showRemoteHostPort)
        {
            value = _textRemoteHostPort.getText();
            if (value == "")
                emptyField = true;
            else
                prop.put(DataItemProperties.REMOTE_HOST_PORT, value);
        }
        if (_showRemoteApplicationPath)
        {
            value = _textRemoteApplicationPath.getText();
            if (value == "")
                emptyField = true;
            else
                prop.put(DataItemProperties.REMOTE_APPLICATION_PATH, value);
        }
        if (_showDbAccessDescriptor)
        {
            value = _textDbAccessDescriptor.getText();
            if (value == "")
                emptyField = true;
        }
        if (emptyField)
        {
            //_displayMessageDialog(Res.getString(Res.CONNECTION_FIELD_EMPTY), JOptionPane.ERROR_MESSAGE);
            LoginFailureException lfe =
                new LoginFailureException(Res.getString(Res.CONNECTION_FIELD_EMPTY));
            ExceptionProcessor.processException((DataItem) getDataItem(), -1, lfe);
        }
        else if ( _connectToDB(prop) == true )
        {
            _dialogExit = JOptionPane.OK_OPTION;
            _alreadyExiting = true;
            dispose();
        }
        else
        {
            if (++_retryCount > _maxRetryCount)
            {
               //LoginFailureException lfe =
               //    new LoginFailureException(Res.getString(Res.LOGIN_RETRY_LIMIT_EXCEEDED));

               //ExceptionProcessor.processException((DataItem) getDataItem(), -1, lfe);
               _displayMessageDialog(Res.getString(Res.LOGIN_RETRY_LIMIT_EXCEEDED), JOptionPane.ERROR_MESSAGE);
               _cancelButtonClicked();
            }
        }
    }

    private void _cancelButtonClicked()
    {
        _dialogExit = JOptionPane.CANCEL_OPTION;
        _alreadyExiting = true;
        dispose();
    }

    private void _helpButtonClicked()
    {
        _displayMessageDialog(Res.getString(Res.LOGIN_DIALOG_HELP_TEXT), JOptionPane.INFORMATION_MESSAGE);
    }

    private void _displayMessageDialog(String message, int style)
    {
        JPanel helpPanel = new JPanel(new BorderLayout(), false);
        JTextArea area = new JTextArea(message, 6, 40);
        area.setLineWrap(true);
        area.setWrapStyleWord(true);
        area.setEditable(false);
        helpPanel.add(new JScrollPane(area),
                      BorderLayout.CENTER);
        JOptionPane.showMessageDialog(null,
                                      helpPanel,
                                      _title,
                                      style);
    }

    public void actionPerformed(ActionEvent e)
    {
        if ( Res.getString(Res.CANCEL_BUTTON_TEXT).equals(e.getActionCommand()))
            _cancelButtonClicked();
        else if ( Res.getString(Res.HELP_BUTTON_TEXT).equals(e.getActionCommand()))
            _helpButtonClicked();
        else
            _okButtonClicked();
    }

    private boolean _connectToDB(Properties prop)
    {
        DbAccess dbAccess = (DbAccess)_dbAccessSupport.getDataItem();
        
        if ( dbAccess != null )
        {
            try
            {
                dbAccess.connect("", prop);
                return true;
            }
            catch (Exception exc)
            {
                // nothing to do.
            }
        }
        else
        {
            // nothing to do.
        }
        return false;

    }

    private ImageIcon _loadImage(String name)
    {
        Class cl = LoginDlg.class;
        URL img = cl.getResource(name);
        ImageIcon i =  new ImageIcon(img);
        return i;
    }

    /**
    **  Maps from the name of property to an int ID. <P>
    **
    **  @param propName The name of the property
    **  @return The ID of the property
    */
    private int _identifyProperty(String propName)
    {
        return(((Integer)(_propIDTable.get(propName))).intValue());
    } // _identifyProperty

    private void _initFieldsFromDbAccess()
    {
        DbAccess dbAccess = (DbAccess)_dbAccessSupport.getDataItem();
        Properties prop = new Properties();
        
        if (_inputUser != "")
            prop.put(DataItemProperties.USERNAME, _inputUser);
        if (_inputPassword != "")
            prop.put(DataItemProperties.PASSWORD, _inputPassword);
        if (_inputDatabaseURL[0] != "")
            prop.put(DataItemProperties.DATABASE_URL, _inputDatabaseURL[0]);
        if (_inputDriverType[0] != "")
            prop.put(DataItemProperties.DRIVER_TYPE, _inputDriverType[0]);
        if  ( dbAccess != null )
        {
            _drvProp = dbAccess.getPropertyInfo("", prop);

            for (int i=0 ; i < _drvProp.length; i++)
            {
                String val = _drvProp[i].value;
                if ( val == null )
                    val = "";
                boolean rqrd = _drvProp[i].required;
                switch (_identifyProperty(_drvProp[i].name))
                {
                case DataItemProperties.USERNAME_PROP:
                    if (_inputUser != "")
                    {
                        _user = _inputUser;
                    }
                    else
                    {
                       _user = val;
                    }
                    _showUser = (_showUser || rqrd);
                    break;
                case DataItemProperties.PASSWORD_PROP:
                    if (_inputPassword != "")
                    {
                        _password = _inputPassword;
                    }
                    else
                    {
                        _password = val;
                    }

                    _showPassword = (_showPassword || rqrd);
                    break;
                case DataItemProperties.CONNECTION_URL_PROP:
                    _connectionURL = val;
                    _showConnectionURL = (_showConnectionURL || rqrd);
                    break;
                case DataItemProperties.DRIVER_CLASS_PROP:
                    _driverClass = val;
                    _showDriverClass = (_showDriverClass || rqrd);
                    break;
                case DataItemProperties.DRIVER_TYPE_PROP:
                    if (_inputDriverType.length <= 1)
                    {
                        _inputDriverType = _drvProp[i].choices;
                    }
                    _driverType = val;
                    _showDriverType = (_showDriverType || rqrd);
                    break;
                case DataItemProperties.DATABASE_URL_PROP:
                    _databaseURL = val;
                    _showDatabaseURL = (_showDatabaseURL || rqrd);
                    break;
                case DataItemProperties.CONNECTION_NAME_PROP:
                    _connectionName = val;
                    _showConnectionName = (_showConnectionName || rqrd);
                    break;
                case DataItemProperties.IIOP_CONNECTION_NAME_PROP:
                    _iiopConnectionName = val;
                    _showIIOPConnectionName =
                        (_showIIOPConnectionName || rqrd);
                    break;
                case DataItemProperties.APPLICATION_MODULE_CLASS_PROP:
                    _applicationModuleClass = val;
                    _showApplicationModuleClass =
                        (_showApplicationModuleClass || rqrd);
                    break;
                case DataItemProperties.LOCKING_MODE_PROP:
                    _inputLockingMode = _drvProp[i].choices;
                    _lockingMode = val;
                    _showLockingMode = (_showLockingMode || rqrd);
                    break;
                case DataItemProperties.SERVER_TIMEOUT_PROP:
                    _serverTimeout = val;
                    _showServerTimeout = (_showServerTimeout || rqrd);
                    break;
                case DataItemProperties.DEPLOYMENT_PLATFORM_PROP:
                    _inputDeploymentPlatform = _drvProp[i].choices;
                    _deploymentPlatform = val;
                    _showDeploymentPlatform =
                        (_showDeploymentPlatform || rqrd);
                    break;
                case DataItemProperties.CONNECTION_MODE_PROP:
                    _inputConnectionMode = _drvProp[i].choices;
                    _connectionMode = val;
                    _showConnectionMode = (_showConnectionMode || rqrd);
                    break;
                case DataItemProperties.REMOTE_HOST_PROP:
                    _remoteHost = val;
                    _showRemoteHost = (_showRemoteHost || rqrd);
                    break;
                case DataItemProperties.REMOTE_HOST_PORT_PROP:
                    _remoteHostPort = val;
                    _showRemoteHostPort = (_showRemoteHostPort || rqrd);
                    break;
                case DataItemProperties.REMOTE_APPLICATION_PATH_PROP:
                    _remoteApplicationPath = val;
                    _showRemoteApplicationPath =
                        (_showRemoteApplicationPath || rqrd);
                    break;
                default:
                    break;
                }
            }

            if (_password == "") // password not included in deployment archive.
            {
               _user = "";
            }
        }
    }

}

