/*
 * @(#)SortDelegate.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.dacf.control.swing;

import javax.infobus.ScrollableRowsetAccess;

/**
 *  Interface for sorting, used by the GridControl.
 *
 *  
 *  @version SDK
 *
 */
public interface SortDelegate
{
	/**
	* GridControl invokes this method, so that the implementation can 
	* prepare to sort. The implementation for example may post changes 
	* to the database or prompt the user
	*
	* The return value of this method determines if sorting should 
	* continue
	*
	* @return true if sorting should continue
	*/
	public boolean preSort(ScrollableRowsetAccess scr);

	/**
	* GridControl invokes this method to perform the actual sorting. The 
	* return value is used by the GridControl to decide if the icon in the 
	* table header should change
	*
	* Irrespective of the value returned by this method, the postSort method
	* is always invoked
	*
	* @param columnName which column to sort
	* @sortOrder order of sort - ASC or DESC
	* return true if sort was succsessful
	*/
	public boolean sort(ScrollableRowsetAccess scr, String columnName, 
						String sortOrder);

	/**
	* Implementation may use this method to cleanup
	*/
	public void postSort(ScrollableRowsetAccess scr);
   
}
