/*
 * @(#)LOVInterface.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.dacf.control.swing.lov;

import oracle.dacf.dataset.ValidationException;

/**
 ** defines the LOV interface
 **
 **
 ** @version Internal
 */
public interface LOVInterface
{
   /**
   *  display the LOV Dialog
   */
   public void show();

   /**
   *  specify title for the LOV dialog
   */
   public void setTitle(String title);

   /**
   *  get title for the LOV dialog
   */
   public String getTitle();

   /**
   *  set Location for the dialog
   */
   public void setLocation(int x, int y);


   /**
   *  set size for the dialog
   */
   public void setSize(int w, int h);

   // specify data sets

   /**
	* specify a InfoBus based dataset. Specify a data item name
	* 
   * @param dataItemName - data item name to bind to
	*/
   public void setDataItemName(String dataItemName);


	/**
	* Return the data item name to which we are currently bound to
   *
   *
	*/
   public String getDataItemName();

    /**
    * define a restricted query ( a column value pair)
    *
    */
    public void setRestrictedQuery(String dataItemName, Object value);

    /**
    *
    * get Restricted query in use
    */
    public Object getRestrictedQuery();

   /**
   * run the query.
   */

   public void runQuery(boolean bIgnoreQueryCondition);

   /**
   *  determines if the dataset has to be Queried  before 
   *  displaying the LOV
   *
   *  @param bRefresh  boolean value to indicate if refresh should occur
   *                   or not
   */
   public void setAutomaticRefresh(boolean bRefresh);

   /**
   *
   * Return if the LOV has been configured to refresh before displaying
   */
   public boolean getAutomaticRefresh();

   /**
   * execute return items
   *
   * @param restrictedQuery - a query defenition, typically a
   *                          (column name, column value) pair
   */
   public void executeReturnItems();


   /**
   *  validate the data item.
   *
   *  Users may catch the Validation Exception and pop the
   *  LovDialog.
   *
   *   @param columnName - name of the column to validate
   *   @param value      - value to be validated
   */
   public void validate(String columnName, Object value)
              throws ValidationException;
}

