/*
 * @(#)LOVDialog.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.dacf.control.swing.lov;

import oracle.dacf.control.swing.find.FindItemModel;
import oracle.dacf.control.swing.lov.LOVInterface;

/**
 *  Interface to define the LOV dialog. LOV Dialog display can 
 *  be customized by implementing this interface.
 *
 *  @version SDK
 */
public interface LOVDialog
{

    /**
    *   display the dialog.
    */
    public void show();


    /**
    * display the dialog.
    *
    * @param initialValue to be displayed
    */
    public void show(Object intitalValue);


    /**
    *  set title for the dialog
    *
    *  @param title for the dialog
    */
    public void setTitle(String title) ;

    /**
    *  get title for the dialog
    *  @return title for the dialog
    */
    public String getTitle();
   
    /**
    *   pass through to JDialog's setSize;
    *
    *  @param w  width
    *  @param h  height
    */
    public void setSize(int w, int h);
    
    /**
    * set the data item name for the ScrollableRowset interface.
    * The LOV dialog should make use of the ScrollableRowsetAccess to 
    * display the data values.
    *
    * @param dataItemName  name of the data item
    */
    public void setDataItemName(String dataItemName);

    /**
    *  get the name of the data item currently in use
    *
    *  @return name of the data item currently in use
    */
    public String getDataItemName();

    /**
    *  specify the LOVInterface which uses this dialog
    */
    public void setParent(LOVInterface lov);

    /**
    * specify FindItemModel
    */
    public void setFindItemModel(FindItemModel findItemModel);


    // Selection related
    /**
    *  add's a selection Listener
    */
    public void setSelectionListener(LOVSelectionListener listener);

}


