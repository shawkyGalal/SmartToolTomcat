/*
 * @(#)FindPanel.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.dacf.control.swing;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Container;
import java.awt.Cursor;
import java.awt.Font;
import java.sql.Types;
import java.util.Vector;
import javax.infobus.DataItem;
import javax.infobus.DataItemAddedEvent;
import javax.infobus.DataItemDeletedEvent;
import javax.infobus.DataItemRevokedEvent;
import javax.infobus.DataItemValueChangedEvent;
import javax.infobus.ImmediateAccess;
import javax.infobus.RowsetAccess;
import javax.infobus.RowsetCursorMovedEvent;
import javax.infobus.ScrollableRowsetAccess;
import javax.swing.Icon;
import javax.swing.JPanel;
import oracle.dacf.control.Control;
import oracle.dacf.control.ControlSupport;
import oracle.dacf.control.InfoBusManager;
import oracle.dacf.control.InfoBusManagerListener;
import oracle.dacf.control.InfoBusManagerReleaseEvent;
import oracle.dacf.control.NavigatedEvent;
import oracle.dacf.control.NavigatedListener;
import oracle.dacf.control.NavigatingEvent;
import oracle.dacf.control.NavigatingException;
import oracle.dacf.control.NavigatingListener;
import oracle.dacf.control.swing.find.ConstrainedViewCriteriaModel;
import oracle.dacf.control.swing.find.FindItemEditor;
import oracle.dacf.control.swing.find.FindItemModel;
import oracle.dacf.control.swing.find.FindPanelUI;
import oracle.dacf.control.swing.find.ViewCriteriaFindAction;
import oracle.dacf.control.swing.find.ViewCriteriaFindPanelUI;
import oracle.dacf.dataset.DataItemProperties;
import oracle.dacf.dataset.RowSetInfo;
import oracle.dacf.dataset.ViewCriteriaRowProps;

/**
 *  FindPanel. A control to let specify a parameterized query and execute
 *  it.
 *
 *  The FindPanel displays a text control and a Find button. The user can specify
 *  a value and then click the Find button to restrict the resultset to the
 *  specified value.
 *
 *  Specify a rowset dataItemName which will be used to execute a query
 *  Specify an array of dataItemName one for each column.
 *
 *  Usage
 *
 *    JDialog dlg = new JDialog(); // dislay the FindPanel in this dialog
 *    FindPanel panel = new FindPanel("Find:");//Find Panel with button "Find :"
 *    dlg.getContentPane().add(panel);//also add  OK and Cancel button if needed
 *
 *    panel.setDataItemName("infobus:/oracle/Sess1/EMP"); // rowset name
 *
 *    //column name is ENAME., paramererized query will be of form
 *    // WHERE ( ENAME LIKE S%)
 *    panel.setColumnDataItemName(new String[]{"infobus:/oracle/Sess1/EMP/ENAME"});
 *
 *    dlg.setSize(200,75);
 *    dlg.show();
 *
 *  @version SDK
 */
public class FindPanel
    extends JPanel
    implements Control, InfoBusManagerListener
{
    /**
    *  position the label at LEFT
    */
    public static final int LEFT = 0;

    /**
    * position the label above the text field
    */
    public static final int ABOVE = 1;

    /**
    *  items (label and text field) should be laid left to right
    */
    public static final int X_AXIS = 0;

    /**
    *  items (label and text field) should be laid top down
    */
    public static final int Y_AXIS = 1;

    /**
    * Helper object which helps execute the query
    */
    private ViewCriteriaFindAction _findAction = new ViewCriteriaFindAction();

    /**
    * Abstracts View Criteria
    */
    private ConstrainedViewCriteriaModel _findViewCriteriaModel =
        new ConstrainedViewCriteriaModel();

    /**
    * Delegate the UI to this object
    */
    private FindPanelUI _findPanelUI = new ViewCriteriaFindPanelUI() ;

    /**
    * delegate data binding to this object
    */
    private ControlSupport _controlSupport;

    /**
    *  current view criteria row
    */
    private int _currentRow = 1;

    /**
    *
    */
    private String[] userDefinedColumnDataItemName = null;

	Cursor  _defaultCursor = new Cursor(Cursor.DEFAULT_CURSOR);
    Cursor  _busyCursor = new Cursor(Cursor.WAIT_CURSOR);

    boolean _isShowingBusyCursor = false;

	boolean _bPostAlways = true;

	boolean _disableAutoWildCardInSearch = false;

    /**
    *  Constructor
    */
    public FindPanel()
    {
        _controlSupport = new ControlSupport(this);
        InfoBusManager.getInstance().addInfoBusManagerListener(this);
        setFindPanelUI(_findPanelUI);
        setLayout(new BorderLayout());
    }

    // InfoBusManagerListener interface implementation
    public void releaseResources(InfoBusManagerReleaseEvent e)
    {
        if (e.appliesTo(this))
        {
            InfoBusManager.getInstance().removeInfoBusManagerListener(this);
            _controlSupport = null;
        }
    }

    /**
    * Sets the name of the InfoBus this control is connected to. <P>
    * By default, the control is connected to the default InfoBus,
    * named <TT>DEFAULT_INFOBUS_NAME</TT>. <P>
    * If the named InfoBus does not exist, it is created automatically. <P>
    * If the control is already connected to an InfoBus, it is disconnected
    * first. <P>
    */
    public void setInfoBusName(String infoBusName)
    {
        if (_controlSupport != null)
        {
            _controlSupport.setInfoBusName(infoBusName);
        }
    }

    /**
    * Returns the name of the InfoBus this control is connected to. <P>
    */
    public String getInfoBusName()
    {
        return(_controlSupport == null ?
               null : _controlSupport.getInfoBusName());
    }

    /**
    * Specify the data item name for the rowset. The
    * Query condition will be specified on the rowset and
    * the query executed.
    *
    * @param data item name for the rowset
    */
    public void setDataItemName(String dataItemName)
    {
        if (_controlSupport != null)
            _controlSupport.setDataItemName(dataItemName);
    }

    /**
    *  Return the data item name for the row set.
    *
    *  @return data item name for the row set
    */
    public String getDataItemName()
    {
        return(_controlSupport == null ?
               null : _controlSupport.getDataItemName());
    }

    /**
    * Returns the InfoBus DataItem this control is bound to. <P>
    * @return  The InfoBus DataItem this control is bound to, or
    *          <TT>null</TT> if the control is unbound.
    * @see Control#getDataItem
    */
    public final Object getDataItem()
    {
        return(_controlSupport == null ?
               null : _controlSupport.getDataItem());
    }

    /**
    *  Specify the query column data item name.  This name will be
    *  use to get the Column name and the SQL type which in turn will
    *  be used to build the query condition
    *
    *  @param dataItemName of the column
    */
    public void setColumnDataItemName(String[] dataItemName)
    {
      	userDefinedColumnDataItemName = dataItemName;
        setColumnDataItemNameInternal(userDefinedColumnDataItemName);
        if ( _findPanelUI != null )
            _notifyDataItemNameChange();
    }

    /**
    *  @return the data item names for all the columns
    */
    public String[] getColumnDataItemName()
    {
      	return ( (userDefinedColumnDataItemName == null) ?
	         _findViewCriteriaModel.getColumnDataItemName() :  
	                              userDefinedColumnDataItemName);
    }

    /**
    * set the custom editor for each item in the FindPanel. One or
    * more values could be null to indicate that no custom editor is
    * used
    *
    * @param editor used for each item in the FindPanel
    */
    public void setFindItemEditor(FindItemEditor[] editor)
    {
        _findPanelUI.setProperty(FindPanelUI.ITEM_EDITORS, editor);
    }

    /**
    * get the custom editor for each item in the FindPanel. One or
    * more values could be null to indicate that no custom editor is
    * used
    *
    * @return custom editors used
    */
    public FindItemEditor[] getFindItemEditor()
    {
        return((FindItemEditor[])_findPanelUI.getProperty(FindPanelUI.ITEM_EDITORS));
    }


    /**
    *  Specify the label position relative to the text field used to display
    *  the value of the column. Possible values are
    * <UL>
    * <LI> FindPanel.LEFT  Place the label to the left of the textfield</LI>
    * <LI> FindPanel.ABOVE Place the label above the textfield </LI>
    * </UL>
    *
    * @param pos where should the label be relative to the textfield
    */
    public void setLabelPosition(int pos)
    {
        if (( pos  == FindPanel.LEFT) || ( pos == FindPanel.ABOVE))
        {
            _findPanelUI.setProperty(FindPanelUI.LABEL_POSITION,
                                     new Integer(pos));
        }
        else
            throw new IllegalArgumentException(
                                               Res.getString(Res.FIND_PANEL_ILLEGAL_LABEL_POSITION ));
    }

    /**
    *  get the label position
    *
    * @return label position
    */
    public int getLabelPosition()
    {
        Integer i = (Integer)_findPanelUI.getProperty(FindPanelUI.LABEL_POSITION);
        if (i != null)
            return i.intValue();
        return LEFT;
    }

    /**
    * Arrange the items in one direction
    */
    public void setItemDirection(int direction)
    {
        if (( direction == FindPanel.X_AXIS) ||
            (direction == FindPanel.Y_AXIS))
        {
            _findPanelUI.setProperty(FindPanelUI.ITEM_DIRECTION,
                                     new Integer(direction));
        }
        else
            throw new IllegalArgumentException(
                                               Res.getString(Res.FIND_PANEL_ILLEGAL_ITEM_DIRECTION ));
    }

    /**
    *  get the current direction in which the items are arranged
    */
    public int getItemDirection()
    {
        Integer i = (Integer)_findPanelUI.getProperty(FindPanelUI.ITEM_DIRECTION);
        if (i != null)
            return i.intValue();
        return Y_AXIS;
    }

    /**
    * Specify, if the FindPanel should display the 'Find' button. If
    * <TT>true</TT>, the FindPanel will display the Find button.
    *
    * @param flag to specify if the Find button should be displayed
    */
    public void setHasFindButton(boolean flag)
    {
        _findPanelUI.setProperty(FindPanelUI.SHOW_FIND_BUTTON, new Boolean(flag));
    }

    /**
    * Determine if the FindPanel has been configured to display the Find
    * button
    *
    * @return true if the Find button will be displayed
    */
    public boolean getHasFindButton()
    {
        Boolean b = (Boolean)_findPanelUI.getProperty(FindPanelUI.SHOW_FIND_BUTTON);
        if (b != null)
            return b.booleanValue();
        return true;

    }

    /**
    * Specify, if the FindPanel should display the 'Close' button. If
    * <TT>true</TT>, the FindPanel will display the Close button.
    *
    * @param flag to specify if the Find button should be displayed
    */
    public void setHasCloseButton(boolean flag)
    {
        _findPanelUI.setProperty(FindPanelUI.SHOW_CLOSE_BUTTON, new Boolean(flag));
    }

    /**
    * Determine if the FindPanel has been configured to display the Close
    * button
    *
    * @return true if the Close button will be displayed
    */
    public boolean getHasCloseButton()
    {
        Boolean b = (Boolean)_findPanelUI.getProperty(FindPanelUI.SHOW_CLOSE_BUTTON);
        if (b != null)
            return b.booleanValue();
        return true;
    }


    /**
    * Specify, if the FindPanel should display the 'Help' button. If
    * <TT>true</TT>, the FindPanel will display the Help button.
    *
    * @param flag to specify if the Help button should be displayed
    */
    public void setHasHelpButton(boolean flag)
    {
        _findPanelUI.setProperty(FindPanelUI.SHOW_HELP_BUTTON, new Boolean(flag));
    }

    /**
    * Determine if the FindPanel has been configured to display the Help
    * button
    *
    * @return true if the Help button will be displayed
    */
    public boolean getHasHelpButton()
    {
        Boolean b = (Boolean)_findPanelUI.getProperty(FindPanelUI.SHOW_HELP_BUTTON);
        if (b != null)
            return b.booleanValue();
        return true;
    }


    /**
    * Specify, if the FindPanel should display the 'Reset' button. If
    * <TT>true</TT>, the FindPanel will display the Reset button.
    *
    * @param flag to specify if the Reset button should be displayed
    */
    public void setHasResetButton(boolean flag)
    {
        _findPanelUI.setProperty(FindPanelUI.SHOW_RESET_BUTTON, new Boolean(flag));
    }

    /**
    * Determine if the FindPanel has been configured to display the 'Reset'
    * button
    *
    * @return true if the 'Reset' button will be displayed
    */
    public boolean getHasResetButton()
    {
        Boolean b = (Boolean)_findPanelUI.getProperty(
                                                      FindPanelUI.SHOW_RESET_BUTTON);
        if (b != null)
            return b.booleanValue();
        return true;
    }

    /**
    * Specify, if the FindPanel should display the 'OR' button. If
    * <TT>true</TT>, the FindPanel will display the 'OR>>' button.
    *
    * @param flag to specify if the 'OR>>' button should be displayed
    */
    public void setHasORButton(boolean flag)
    {
        _findPanelUI.setProperty(FindPanelUI.SHOW_OR_BUTTON,
                                 new Boolean(flag));
    }

    /**
    * Determine if the FindPanel has been configured to display the 'OR>>'
    * button
    *
    * @return true if the 'OR>>'button will be displayed
    */
    public boolean getHasORButton()
    {
        Boolean b = (Boolean)_findPanelUI.getProperty(
                                                      FindPanelUI.SHOW_OR_BUTTON);
        if (b != null)
            return b.booleanValue();
        return true;

    }

    /**
    * Specify, if the FindPanel should display the 'Remove' button. If
    * <TT>true</TT>, the FindPanel will display the 'Remove' button.
    *
    * @param flag to specify if the 'Remove'button should be displayed
    */
    public void setHasRemoveButton(boolean flag)
    {
        _findPanelUI.setProperty(FindPanelUI.SHOW_REMOVE_BUTTON,
                                 new Boolean(flag));
    }

    /**
    * Determine if the FindPanel has been configured to display the 'Remove'
    * button
    *
    * @return true if the 'Remove' button will be displayed
    */
    public boolean getHasRemoveButton()
    {
        Boolean b = (Boolean)_findPanelUI.getProperty(
                                                      FindPanelUI.SHOW_REMOVE_BUTTON);
        if (b != null)
            return b.booleanValue();
        return true;
    }

    /**
    * Specify, if the FindPanel should display the 'RemoveAll' button. If
    * <TT>true</TT>, the FindPanel will display the 'RemoveAll' button.
    *
    * @param flag to specify if the 'RemoveAll'button should be displayed
    */
    public void setHasRemoveAllButton(boolean flag)
    {
        _findPanelUI.setProperty(FindPanelUI.SHOW_REMOVE_ALL_BUTTON,
                                 new Boolean(flag));
    }

    /**
    * Determine if the FindPanel has been configured to display the
    * 'RemoveAll'button
    *
    * @return true if the 'RemoveAll' button will be displayed
    */
    public boolean getHasRemoveAllButton()
    {
        Boolean b = (Boolean)_findPanelUI.getProperty(
                                                      FindPanelUI.SHOW_REMOVE_BUTTON);
        if (b != null)
            return b.booleanValue();
        return true;
    }

    /**
    * Specify, if the FindPanel should display the 'Find' icon. If
    * <TT>true</TT>, the FindPanel will display the Find icon.
    *
    * @param flag to specify if the Find icon should be displayed
    * @see setFindIcon
    */
    public void setHasFindIcon(boolean flag)
    {
        _findPanelUI.setProperty(FindPanelUI.SHOW_FIND_ICON, new Boolean(flag));
    }

    /**
    * Determine if the FindPanel has been configured to display the 'Find'
    * icon
    *
    * @return true if the Find icon will be displayed
    */

    public boolean getHasFindIcon()
    {
        Boolean b = (Boolean)_findPanelUI.getProperty(FindPanelUI.SHOW_FIND_ICON);
        if (b != null)
            return b.booleanValue();
        return true;
    }

    /**
    * Specify, if the FindPanel should display the 'Status bar'. If
    * <TT>true</TT>, the FindPanel will display the status bar.
    *
    * @param flag to specify if the status bar should be displayed
    */
    public void setHasStatusBar(boolean flag)
    {
        _findPanelUI.setProperty(FindPanelUI.SHOW_STATUS_BAR, new Boolean(flag));
    }

    /**
    * Determine if the FindPanel has been configured to display the status
    * bar
    *
    * @return true if the Find icon will be displayed
    */
    public boolean getHasStatusBar()
    {
        Boolean b = (Boolean)_findPanelUI.getProperty(FindPanelUI.SHOW_STATUS_BAR);
        if (b != null)
            return b.booleanValue();
        return false;
    }


    /**
    *  Specify the Find icon to be used. The Find panel will use a default
    *  icon if one is not specified.
    *
    *  @param icon FindIcon
    *  @see setHasFindIcon
    */
    public void setIcon(Icon icon)
    {
        _findPanelUI.setProperty(FindPanelUI.FIND_ICON, icon);
    }

    /**
    *  Get the current 'Find' icon displayed by the FindPanel
    */
    public Icon getIcon()
    {
        return (Icon)_findPanelUI.getProperty(FindPanelUI.FIND_ICON);
    }

    /**
    *  Specify the font to be used for the label. The Label displays the
    * column name.
    *
    *  @param font for the label
    */
    public void setLabelFont(Font f)
    {
        _findPanelUI.setProperty(FindPanelUI.LABEL_FONT, f);
    }

    /**
    *  Get the font currently used for the label.
    *
    *  @return font used for the label
    */
    public Font getLabelFont()
    {
        return (Font)_findPanelUI.getProperty(FindPanelUI.LABEL_FONT);
    }

    /**
    *  Specify the font to be used for the text field. The text field
    *  displays the column value.
    *
    *  @param font for the text field
    */
    public void setTextFieldFont(Font f)
    {
        _findPanelUI.setProperty(FindPanelUI.LABEL_FONT,f);
    }

    /**
    *  Get the font currently used for the text field.
    *
    *  @return font used for the text field
    */
    public Font getTextFieldFont()
    {
        return (Font)_findPanelUI.getProperty(FindPanelUI.TEXT_FONT);
    }

    /**
    *  Specify the foreground color for the label
    *
    *  @param c label color
    */
    public void setLabelForegroundColor(Color c)
    {
        _findPanelUI.setProperty(FindPanelUI.LABEL_FORE_CLR, c);
    }

    /**
    *  get the current label color
    */
    public Color getLabelForegroundColor()
    {
        return (Color)_findPanelUI.getProperty(FindPanelUI.LABEL_FORE_CLR);
    }

    /**
    *  Specify the label background color
    *
    * @paran c label background color
    */
    public void setLabelBackgroundColor(Color c)
    {
        _findPanelUI.setProperty(FindPanelUI.LABEL_BACK_CLR, c);
    }

    /**
    *  get the current label background color
    *
    *  @return label background color
    */
    public Color getLabelBackgroundColor()
    {
        return (Color)_findPanelUI.getProperty(FindPanelUI.LABEL_BACK_CLR);
    }

    /**
    *  specify the textfield foreground color
    *
    *  @param c textfield foreground color
    */
    public void setTextFieldForegroundColor(Color c)
    {
        _findPanelUI.setProperty(FindPanelUI.TEXT_FORE_CLR, c);
    }

    /**
    *  get the current textfield foreground color
    *
    *  @return textfield foreground color
    */

    public Color getTextFieldForegroundColor()
    {
        return (Color)_findPanelUI.getProperty(FindPanelUI.TEXT_FORE_CLR);
    }

    /**
    *  specify the textfield background color
    *
    *  @param c textfield background color
    */
    public void setTextFieldBackgroundColor(Color c)
    {
        _findPanelUI.setProperty(FindPanelUI.TEXT_BACK_CLR, c);
    }

    /**
    *  get the textfield background color
    *
    *  @return textfield background color
    */
    public Color getTextFieldBackgroundColor()
    {
        return (Color)_findPanelUI.getProperty(FindPanelUI.TEXT_BACK_CLR);
    }

    /**
    *  Specify column width for the text field
    *
    *  @param w text field column width
    */
    public void setTextFieldColumnWidth(int w)
    {
        _findPanelUI.setProperty(FindPanelUI.TEXT_COLUMN_WIDTH, new Integer(w));
    }

    /**
    * get the text field column width
    */
    public int  getTextFieldColumnWidth()
    {
        Integer i = (Integer)_findPanelUI.getProperty(FindPanelUI.TEXT_COLUMN_WIDTH);
        if (i != null)
            return i.intValue();
        return 10; // arbitary default
    }

    /**
    *  Enable/Disable Find Panel controls.
    *
    *  @param enabled flag indicating if the controls should be enabled/disabled
    */
    public void setEnabled(boolean enabled)
    {
        _findPanelUI.setProperty(FindPanelUI.ENABLED, new Boolean(enabled));
    }

    /**
    * get the text field column width
    */
    public boolean  isEnabled()
    {
        Boolean b = (Boolean)_findPanelUI.getProperty(FindPanelUI.ENABLED);
        return ((b != null) ? b.booleanValue() : true);
    }

    /**
    * Specify if case sensitive search is to performed for Character data
    * types.
    *
    * By default this property is true.
    *
    * @param flag true if the search should be case sensitive
    */
    public void setCaseSensitiveSearch(boolean flag)
    {
        _findAction.setCaseSensitiveSearch(flag);
    }

    /**
    *  Return true, if the FindPanel does a case sensitive search for
    *  character data types.
    *
    *  @return true if the search is case sensitive for Character data
    *               types.
    */
    public boolean isCaseSensitiveSearch()
    {
        return _findAction.isCaseSensitiveSearch();
    }

	/**
	*  By default, for character datatypes, wildcard character (%) is 
	*  added to the search value (ex., 'Miller' is modified to LIKE 'Miller%'.
	*  If you wish to override this behaviour  set this flag  to true. 
	*
    *
	*  The default value for this flag is false.
	*
	*
	*/
	public void setDisableAutomaticWildCardInSearch(boolean b)
	{
		_disableAutoWildCardInSearch = b;
	}

	public boolean isDisableAutomaticWildCardInSearch()
	{
        return _disableAutoWildCardInSearch;
	}
	

	/**
    * Change the cursor used to indicate busy status
    *
    * @param busyCursor cursor to indicated busy status
    */
    public void setBusyCursor(Cursor busyCursor)
    {
        _busyCursor = busyCursor;
    }

    /**
    * get the cursor currently used to indicated busy status
    *
    * @return get the busy cursor
    */
    public Cursor getBusyCursor()
    {
        return _busyCursor;
    }

   /**
   * If this flag is true, the transaction changes are posted and the
   * query re-executed. 
   *
   * If this flag is false and transaction is dirty, user is prompted to
   * commit the transaction.
   *
   * The default value is true
   *
   * @bflag set to true, if the transaction changes should be posted
   */
   public void setPostAlways(boolean bflag)
   {
       _bPostAlways = bflag;
   }

   /**
   * indicates if the transaction changes are posted before re-executing
   * the query.
   */
   public boolean isPostAlways()
   {
      return _bPostAlways;
   }


    /**
    *  get the inner panel
    *
    * @return inner panel
    */
    public JPanel getInnerPanel()
    {
        return (JPanel)_findPanelUI.getProperty(FindPanelUI.INNER_PANEL);
    }

    /**
    *  Clear all the text fields for the current view criteria row
    *  @seeCurrentViewCriteriaRoww
    */
    public void resetFields()
    {
        int columnCount = _findViewCriteriaModel.getColumnCount();
        for ( int i=0; i< columnCount; i++)
            _findViewCriteriaModel.setColumnValue(i,"");
    }

    /**
    *  customize the UI used to display the Find Panel
    *  @param findPanelUI
    */
    public void setFindPanelUI(FindPanelUI findPanelUI)
    {
        _findPanelUI = findPanelUI;
        if ( _findPanelUI != null )
        {
            _findPanelUI.setParent(this);
            _notifyDataItemNameChange();
        }
    }

    /**
    *  return the FindPanelUI currently in use
    *
    *  @return FindPanelUI
    */
    public FindPanelUI getFindPanelUI()
    {
        return _findPanelUI;
    }

    // helper functions which let the FindPanelUI to execute query and
    // build the UI

    /**
    * sets the current view criteria row
    */
    public void setCurrentViewCriteriaRow(int row)
    {
        _currentRow = row;
        _findViewCriteriaModel.absolute(row);
    }

    public int getCurrentViewCriteriaRow()
    {
        return _currentRow;
    }


    /**
    *  number of columns used to parameterize the query
    *
    *  @return the number of columns
    */
    public int getColumnCount()
    {
        return _findViewCriteriaModel.getColumnCount();
    }

    /**
    * return the column display name for a particular column
    *
    * @param colIndex column index whose display name we are interested in.,
    *                 zero based index used
    *
    * @return column display name
    *
    */
    public String getColumnDisplayLabel(int colIndex)
    {
        return _findViewCriteriaModel.getColumnDisplayLabel(colIndex);
    }

    /**
    * return the column value for a particular column
    *
    * @param colIndex column index whose column value we are interested in.,
    *                 zero based index used
    *
    * @return column value
    *
    */
    public Object getColumnValue(int colIndex)
    {
        return _findViewCriteriaModel.getColumnValue(colIndex);
    }

    /**
    * specify the column value for a particular column
    *
    * @param colIndex column index whose value has to be set
    *                 zero based index used
    *
    */
    public void setColumnValue(int colIndex, Object value)
    {
        _findViewCriteriaModel.setColumnValue(colIndex, value);
    }

    /**
    * get the number of rows in the ViewCriteria. This method is useful
    * in implementing the FindPanel UI
    *
    * @return number of row in the ViewCriteria
    * @see ViewCriteriaFindPanelUI
    */
    public int getViewCriteriaRowCount()
    {
        return _findViewCriteriaModel.getRowCount();
    }

    /**
    * create a new view criteria row. This method is useful
    * in implementing the FindPanel UI
    *
    * @see ViewCriteriaFindPanelUI
    */
    public void newViewCriteriaRow()
    {
        _findViewCriteriaModel.newRow();
    }

    /**
    * delete the current view criteria row. This method is useful
    * in implementing the FindPanel UI
    *
    * @see ViewCriteriaFindPanelUI
    */
    public void deleteViewCriteriaRow()
    {
        _findViewCriteriaModel.deleteRow();
    }

    /**
    * delete all view criteria rows.
    */
    public void deleteAllViewCriteriaRow()
    {
        int rowCount = _findViewCriteriaModel.getRowCount();
        for ( int i=rowCount; i >=1 ;i--)
        {
            _findViewCriteriaModel.absolute(i);
            _findViewCriteriaModel.deleteRow();
        }
    }

    /**
    * run the query
    */
    public void runQuery()
    {
	    _applyQueryCriteriaProps(_findViewCriteriaModel.getRowsetAccess(), 
				     isCaseSensitiveSearch());
	    _showBusyCursor();
		try
		{
			_findAction.executeQuery(isPostAlways());
		}
		catch(Exception e)
		{
		}
		finally
		{
			_restoreDefaultCursor();
		}
        
    }

    /**
    * obtain the ViewCriteria Find action used by the FindPanel.
    */
    public ViewCriteriaFindAction getViewCriteriaFindAction()
    {
        return _findAction;
    }

	/**
    * Specify the ViewCriteriaFind action to be used by the FindPanel.
	*
	* @param vc ViewCriteriaFindAction object
    */
    public void  setViewCriteriaFindAction(ViewCriteriaFindAction vc)
    {
        _findAction = vc;
    }

    /**
    * get the item model for the specified column
    *
    * @param column whose model we need
    */
    public FindItemModel getFindItemModel(int column)
    {
        return _findViewCriteriaModel.getFindItemModel(_currentRow, column);
    }

    /**
    * get the ViewCriteriaModel
    *
    * @param column whose model we need
    */
    public ConstrainedViewCriteriaModel getViewCriteriaModel()
    {
        return _findViewCriteriaModel;
    }


    /**
    * Notifies the control that the bound InfoBus DataItem has changed. <P>
    * @param oldDataItem   The formerly bound DataItem (can be <TT>null</TT>).
    * @param newDataItem   The newly bound DataItem (can be <TT>null</TT>).
    * @see Control#dataItemChanged
    */
    public final void dataItemChanged(Object oldDataItem, Object newDataItem)
    {
        // clear the rowset stored in the FindAction &&
        // the ViewCriterialModel
        _findAction.setRowsetAccess(null);
        _findViewCriteriaModel.setRowsetAccess(null);

        if ( newDataItem != null &&
             (newDataItem instanceof ScrollableRowsetAccess))
        {
  	        String[] queryableColumns = userDefinedColumnDataItemName;
            if (queryableColumns == null )
                queryableColumns = _getQueryableColumns(
		                                  (RowsetAccess)newDataItem);
	          setColumnDataItemNameInternal(queryableColumns);

            ScrollableRowsetAccess scr =
                (ScrollableRowsetAccess)_getQueryCriteriaRowset();
            if ( scr != null )
            {
                _findAction.setRowsetAccess((ScrollableRowsetAccess)getDataItem());
                _findViewCriteriaModel.setRowsetAccess(scr);
           		//deleteAllViewCriteriaRow(); // remove any old vc rows
            }
        }
        if ( _findPanelUI != null )
        {
            if (_isDataItemNameChanged((DataItem)oldDataItem,
                                              (DataItem)newDataItem))
                _findPanelUI.setProperty(FindPanelUI.ITEM_EDITORS, null);
                
           _notifyDataItemNameChange();
        }
    }

    /**
    * Determines whether focus into this control causes validation to
    * occur. <P>
    * @return  Always false
    * @see Control#isFocusValidated
    */
    public final boolean isFocusValidated()
    {
        // FindPanel  cannot get focus
        return(false);
    }

    /**
    *  This method is a no-op that is it has no effect
    */
    public final void setFocusValidated(boolean focusValidated)
    {
        // FindPanel  cannot t get focus
    }

    /**
    * Returns the AWT component associated with this control. <P>
    * @return  The AWT component for this control.
    */
    public Component getComponent()
    {
        return this;
    }


    /**
    *  This method is a no-op
    */
    public final void addNavigatedListener(NavigatedListener listener)
    {
        // FindPanel cannot get focus
    }

    /**
    *  This method is a no-op that is it has no effect
    */
    public final void removeNavigatedListener(NavigatedListener listener)
    {
        // FindPanel cannot get focus
    }

    /**
    *  This method is a no-op
    */
    public final void processNavigatedEvent(NavigatedEvent event)
    {
        // FindPanel cannot get focus
    }

    /**
    *  This method is a no-op
    */
    public final void addNavigatingListener(NavigatingListener listener)
    {
    }

    /**
    *  This method is a no-op
    */
    public final void removeNavigatingListener(NavigatingListener listener)
    {
        // FindPanel cannot get focus
    }

    /**
    *  This method is a no-op in that it has no effect
    *  @exception   NavigatingException    Indicates navigation rejected.
    */
    public final void processNavigatingEvent(NavigatingEvent event)
        throws NavigatingException
    {
        // FindPanel cannot get focus
    }

    // DataItemChangeListener Interface

    /**
    * Indicates a changed value in the bound data item. <P>
    * A reference to the data item that changed can be obtained from the
    * event. <P>
    * @param event Contains change information.
    * @see javax.infobus.DataItemChangeListener#dataItemValueChanged
    */
    public final void dataItemValueChanged(DataItemValueChangedEvent event)
    {
    }

    /**
    * Indicates that a new item was added to the bound aggregate data item
    * (e.g. <TT>ArrayAccess</TT>, a JDK Collection, etc). <P>
    * A reference to the data item that was added, and a reference to the one
    * that gained it, can be obtained from the event. <P>
    *
    * @param event Contains details of the addition.
    * @see javax.infobus.DataItemChangeListener#dataItemAdded
    */
    public final void dataItemAdded(DataItemAddedEvent event)
    {
        // Not applicable
    }

    /**
    * Indicates that an item was deleted from the bound aggregate data item
    * (e. g. <TT>ArrayAccess</TT>, a JDK Collection, etc). <P>
    * A reference to the data item that was deleted, and a reference to the
    * one that lost it, can be obtained from the event. <P>
    *
    * @param event Contains details of the deletion.
    * @see javax.infobus.DataItemChangeListener#dataItemDeleted
    */
    public final void dataItemDeleted(DataItemDeletedEvent event)
    {
        // Not applicable
    }

    /**
    * Indicates that the bound data item (and its sub-items, if any) has been
    * revoked, and is temporarily unavailable. <P>
    * A reference to the data item that was revoked can be obtained from
    * the event. <P>
    * @param event Contains details of the revoked data.
    * @see javax.infobus.DataItemChangeListener#dataItemRevoked
    */
    public final void dataItemRevoked(DataItemRevokedEvent event)
    {
    }

    /**
    * Indicates that the cursor for the bound <TT>RowsetAccess</TT> data item
    * has changed rows. <P>
    * A reference to the rowset data item can be obtained from the event. <P>
    * @param event Contains details of the cursor move.
    * @see javax.infobus.DataItemChangeListener#rowsetCursorMoved
    */
    public final void rowsetCursorMoved(RowsetCursorMovedEvent event)
    {
        // Not applicable
    }

    protected void setColumnDataItemNameInternal(String[] dataItemName)
    {
        _findViewCriteriaModel.setColumnDataItemName(dataItemName);
    }

	/**
    * displays a busy cursor
    */
    protected void _showBusyCursor()
    {
        if (!_isShowingBusyCursor)
        {
            Container p = getTopLevelAncestor();
            if ( p != null )
            {
               _defaultCursor = p.getCursor();
               _isShowingBusyCursor = true;
               p.setCursor(_busyCursor);
            }
        }
    }

    /**
    * show default cursor
    *
    */
    protected void _restoreDefaultCursor()
    {
        if (_isShowingBusyCursor)
        {
            Container p = getTopLevelAncestor();
            if ( p != null )
            {
               _isShowingBusyCursor = false;
                p.setCursor(_defaultCursor);
             }
        }
    }

    /**
    * notify the data item name change to the UI object
    */
    private void _notifyDataItemNameChange()
    {
        if ( getDataItem() != null )
        {
            setCurrentViewCriteriaRow(1);
            _findPanelUI.itemChanged();
            this.removeAll();
            add(_findPanelUI.buildPanel(), BorderLayout.CENTER);
        }
    }

    /**
    *  builds a list of queryable column.
    *
    * @return array of data item names - one for each query able column
    */
    private String[] _getQueryableColumns(RowsetAccess rowset)
    {
        Object[] queryable = new String[] {  };
    
        queryable = (Object [])((DataItem)rowset).getProperty(
                                 DataItemProperties.QUERYABLE_COLUMNS);
        if ( queryable != null)
        {
            Vector vec = new Vector();
            for (int i=0 ; i < queryable.length; i++)
            {
                int sqlType = _getSQLType(rowset, i);
                if (_isSearchableType(sqlType))
                    vec.addElement((String)queryable[i]);
            }
            String[] ret = new String[vec.size()];
            vec.copyInto(ret);
            return ret;
        }
	return (String[])queryable;
    }

    /**
    * Helper function to get the SQL type of a particular column
    *
    * @param rowset to which the column object belongs
    * @param colIndex index of the column whose SQL type is required
    *
    * @return the SQL type of the column
    */
    private int _getSQLType(RowsetAccess rowset, int colIndex)
    {
        return rowset.getColumnDatatypeNumber(colIndex + 1);
    }

    /**
    * query if it is possible to search a column whose SQL type is
    * specified
    *
    * @param  sqlType of the column
    * @return true if the column is searchable
    */
    private boolean _isSearchableType(int sqlType)
    {
        if (
            (sqlType == Types.BINARY) ||
            (sqlType == Types.VARBINARY ) ||
            (sqlType == Types.LONGVARBINARY)||
            (sqlType == Types.LONGVARCHAR) ||
            (sqlType == Types.OTHER) ||
            (sqlType == Types.NULL)
            )
            return false;
        return true;

    }

    /**
    * get query criteria rowset
    */
    protected ScrollableRowsetAccess _getQueryCriteriaRowset()
    {
        DataItem di = (DataItem)getDataItem();
        if ( di != null )
        {
            ScrollableRowsetAccess rs = ( ScrollableRowsetAccess ) di;
            try
            {
                DataItem defqc = (DataItem)rs.getColumnItem(
                                                            RowSetInfo.DEFAULT_QUERYCRITERIA_ATTR_NAME);
                DataItem qc = (DataItem)rs.getColumnItem(
                                                         RowSetInfo.QUERYCRITERIA_ATTR_NAME);

                if (( qc == null ) && ( defqc == null ))
                {
                    throw new RuntimeException("DefaultQueryCriteria missing");

                }

                ScrollableRowsetAccess qcrs = null;
                if ( qc != null )
                {
                    ImmediateAccess ia = (ImmediateAccess)qc;
                    qcrs = (ScrollableRowsetAccess)ia.getValueAsObject();

                    // use default query criteria if needed
                    if ( qcrs == null )
                    {
                        qcrs =  (ScrollableRowsetAccess)
                            ((ImmediateAccess)defqc).getValueAsObject();

                        ia.setValue(qcrs);
                    }
                    return qcrs;
                }
            }
            catch( Exception e)
            {
                e.printStackTrace();
            }
        }
        return null;
    }

    protected void _applyQueryCriteriaProps(ScrollableRowsetAccess rsAccess, 
					      boolean isCaseSensitive)
    {
      	if (rsAccess == null)
  	        return;

      	// case sensitive ?
      	if ( rsAccess instanceof ViewCriteriaRowProps)
      	{
	          ViewCriteriaRowProps vcProps = (ViewCriteriaRowProps)rsAccess;
      	    for (int i=1; i <= rsAccess.getRowCount();i++)
	          {
      	        try
            		{
            		    rsAccess.absolute(i);
            		    vcProps.setUpperColumns(!isCaseSensitive);
            		}
            		catch(Exception exc)
            		{
              			// XXX
            		}
            }
        } // if
    }

    protected boolean _isDataItemNameChanged(DataItem oldDataItem,
                DataItem newDataItem)
    {
        if (( oldDataItem != null) && (newDataItem != null))
        {
            String oldName = (String)oldDataItem.getProperty(DataItemProperties.NAME);
            String newName = (String)newDataItem.getProperty(DataItemProperties.NAME);
            return ( (oldName.equalsIgnoreCase(newName)) ? false : true);
        }
        return false;
    }
}

