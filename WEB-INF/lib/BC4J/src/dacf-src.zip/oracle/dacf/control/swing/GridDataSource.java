/*
 * @(#)GridDataSource.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.dacf.control.swing;

import java.awt.Component;
import java.awt.Point;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.lang.Class;
import java.net.URL;
import java.sql.SQLException;
import java.sql.Types;
import java.util.Enumeration;
import java.util.Locale;
import javax.infobus.ArrayAccess;
import javax.infobus.DataItem;
import javax.infobus.DataItemAddedEvent;
import javax.infobus.DataItemChangeListener;
import javax.infobus.DataItemChangeManager;
import javax.infobus.DataItemDeletedEvent;
import javax.infobus.DataItemRevokedEvent;
import javax.infobus.DataItemValueChangedEvent;
import javax.infobus.DataItemView;
import javax.infobus.ImmediateAccess;
import javax.infobus.RowsetAccess;
import javax.infobus.RowsetCursorMovedEvent;
import javax.infobus.RowsetValidationException;
import javax.infobus.ScrollableRowsetAccess;
import javax.swing.ImageIcon;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.JViewport;
import javax.swing.SwingConstants;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.event.TableModelEvent;
import javax.swing.table.AbstractTableModel;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableColumnModel;
import javax.swing.table.JTableHeader;
import javax.swing.table.TableColumn;
import javax.swing.table.TableColumnModel;
import oracle.dacf.control.ApplyEditsValidationException;
import oracle.dacf.control.Control;
import oracle.dacf.dataset.DataItemProperties;
import oracle.dacf.dataset.ResultSetInfo;

/**
 * This class provides data to the JFC <TT>GridControl</TT>. <P>
 * The data is obtained from a bound InfoBus data item that implements the
 * <TT>ScrollableRowsetAccess</TT> interface.  Other access interfaces
 * (such as <TT>ArrayAccess</TT>) are not supported. <P>
 * If the data item also implements the <TT>DataItemView</TT> interface,
 * data retrieval will be much faster.  Since the JTable object frequently
 * requests data (for example, whenever it repaints a cell), performance of
 * the JTable will be unacceptable unless the data item implements the
 * <TT>DataItemView</TT> interface.
 */
public class GridDataSource
    extends AbstractTableModel
    implements DataItemChangeListener, ChangeListener
{
    private static final boolean _DEBUG = false;

    protected GridControl _gridControl;
    protected JTable _table;
    protected ScrollableRowsetAccess _rowset; // Bound rowset
    protected ScrollableRowsetAccess _cursor; // Private cursor on rowset
    protected DataItemView _view;             // Bound view
    protected int _rowCount;                  // Cached row count
    private   boolean _forceReadOnly;         // force table as readonly?
    protected String[] _columnLabels;         // labels for our columns
    protected JViewport _viewPort;
    protected int _rangeStart;
    protected int _rangeSize;

    /**
    * Creates the data source. <P>
    * @param gridControl   The JFC GridControl.
    */
    public GridDataSource(GridControl gridControl, boolean forceReadOnly)
    {
        _gridControl = gridControl;
        _table = gridControl.getTable();
        _forceReadOnly = forceReadOnly;
    }

    public void init()
    {
        _viewPort = _gridControl.getTableAggregate().getViewport();
        _rangeStart = 0;
        _rangeSize = _getRecommendedRangeSize();
		_viewPort.addChangeListener(this);
    }

    // ChangeListener interface

    public void stateChanged(ChangeEvent e)
    {
        if (_viewPort == null || _table == null || _rowset == null
            || e.getSource() != _viewPort)
        {
            return;
        }
        int visibleRowCount = _getRecommendedRangeSize();
        Point viewPortPosition = _viewPort.getViewPosition();
        int viewPortStart = _table.rowAtPoint(viewPortPosition);
        // _debug("stateChanged: visibleRowCount: " + visibleRowCount);
        // _debug("stateChanged: viewPortPoistion: " + viewPortPoistion);
        // _debug("stateChanged: viewPortStart: " + viewPortStart);
        // _debug("stateChanged: _rangeStart: " + _rangeStart);
        // _debug("stateChanged: _rangeSize: " + _rangeSize);
        if (viewPortStart != -1 && visibleRowCount > 0)
        {
            if (_rangeStart != viewPortStart)
            {
                // _debug("setViewStart: " + viewPortStart);
                _rangeStart = viewPortStart;
                ((DataItemView)_rowset).setViewStart(_rangeStart);
            }
            if (_rangeSize != visibleRowCount)
            {
                // _debug("setBufferSize: " + visibleRowCount);
                _rangeSize = visibleRowCount;
                _rowset.setBufferSize(_rangeSize);
            }
        }
    } // stateChanged


    /**
    * should the grid be forced to work in read only mode
    */
    protected boolean isForceReadOnly()
    {
        return _forceReadOnly;
    }

    /**
    * set the grid to work in read only mode
    *
    * @param forceReadOnly true if the grid should work in read only mode
    */
    protected void setForceReadOnly(boolean forceReadOnly)
    {
        _forceReadOnly = forceReadOnly;
    }

    /**
    * Notifies the data source that the bound data item has changed. <P>
    * This method is invoked by the <TT>GridControl</TT>. <P>
    * @param oldDataItem   The previously bound data item.
    * @param newDataItem   The new data item to bind to.
    */
    public synchronized void dataItemChanged(Object oldDataItem,
                                             Object newDataItem)
    {
        if (_rowset != null)
        {
            if (_rowset instanceof DataItemChangeManager)
            {
                ((DataItemChangeManager)_rowset).removeDataItemChangeListener(this);
            }
            if (_table != null)
            {
                TableColumnModel gtcm = _table.getColumnModel();

                if (gtcm != null && gtcm instanceof GridTableColumnModel)
                {
                    JTableHeader header = _table.getTableHeader();
                    SortableHeaderRenderer headerRenderer =
                        ((GridTableColumnModel)gtcm).getHeaderRenderer();
                    if (header != null)
                    {
                        header.removeMouseListener(headerRenderer);
                    }
                    if (headerRenderer != null)
                    {
                        headerRenderer.setRowSet(null);
                    }
                    _table.setColumnModel(new DefaultTableColumnModel());
                }
            }

            _rowset = null;
            _cursor = null;
            _view = null;
            _cursor = null;
            _rowCount = 0;
            _rangeStart = 0;
        }
        _view = null;

        if (newDataItem != null)
        {
            if (newDataItem instanceof ScrollableRowsetAccess)
            {
                _rowset = (ScrollableRowsetAccess)newDataItem;

                // _cursor is used for obtaining data outside the current
                // view of the rowset (or if the rowset doesn't support views)

                //_cursor = _rowset.newCursor();

                // Cache the row count -- JTable requests it a lot.
                // _rowCount = _rowset.getHighWaterMark();
                _rowCount = getRowCountFromRowsetAccess(_rowset);

                if (newDataItem instanceof DataItemView)
                {
                    _view = (DataItemView)newDataItem;
                }

                if (newDataItem instanceof DataItemChangeManager)
                {
                    ((DataItemChangeManager)newDataItem).addDataItemChangeListener(this);
                }

                _getColumnLabels(_rowset);
                _rowset.setBufferSize(_rangeSize);
                if (_table != null)
                {
                    TableColumnModel gtcm = _table.getColumnModel();

                    _table.setColumnModel(_buildColumnModel(_rowset));
                    _table.sizeColumnsToFit(-1);

                    if (gtcm != null && gtcm instanceof GridTableColumnModel)
                    {
                        SortableHeaderRenderer headerRenderer =
                            ((GridTableColumnModel)gtcm).getHeaderRenderer();
                        if (headerRenderer != null)
                        {
                            headerRenderer.setRowSet(_rowset);
                        }
                    }
                }
            }
        }

        // Tell the grid control that all the data has changed.
        _fireTableStructureAndDataChangedLater();
    }


    // DataItemChangedListener Interface

    /**
    * Indicates a changed value in the bound data item. <P>
    * A reference to the data item that changed can be obtained from the
    * event. <P>
    * @param event Contains change information.
    * @see javax.infobus.DataItemChangeListener#dataItemValueChanged
    */
    public void dataItemValueChanged(final DataItemValueChangedEvent e)
    {
        // _debug("dataItemValueChanged ");
        SwingUtilities.invokeLater(
                                   new Runnable()
                                   {
                                       public void run()
                                       {
                                           _handleDataItemValueChanged(e);
                                       }
                                   }
                                   );
    }

    /**
    * Indicates that a new item was added to the bound aggregate data item
    * (e.g. <TT>ArrayAccess</TT>, a JDK Collection, etc). <P>
    * A reference to the data item that was added, and a reference to the one
    * that gained it, can be obtained from the event. <P>
    * @param event Contains details of the addition.
    * @see javax.infobus.DataItemChangeListener#dataItemAdded
    */
    public void dataItemAdded(final DataItemAddedEvent e)
    {
        // Invoke in event dispatch thread to be Swing thread-safe.
        SwingUtilities.invokeLater(
                                   new Runnable()
                                   {
                                       public void run()
                                       {
                                           _handleDataItemAdded(e);
                                       }
                                   }
                                   );
    }

    /**
    * Indicates that an item was deleted from the bound aggregate data item
    * (e. g. <TT>ArrayAccess</TT>, a JDK Collection, etc). <P>
    * A reference to the data item that was deleted, and a reference to the
    * one that lost it, can be obtained from the event. <P>
    * @param event Contains details of the deletion.
    * @see javax.infobus.DataItemChangeListener#dataItemDeleted
    */
    public void dataItemDeleted(final DataItemDeletedEvent e)
    {
        // _debug("dataItemDeleted ");
        // Invoke in event dispatch thread to be Swing thread-safe.
        SwingUtilities.invokeLater(
                                   new Runnable()
                                   {
                                       public void run()
                                       {
                                           _handleDataItemDeleted(e);
                                       }
                                   }
                                   );
    }

    /**
    * Indicates that the bound data item (and its sub-items, if any) has been
    * revoked, and is temporarily unavailable. <P>
    * A reference to the data item that was revoked can be obtained from
    * the event. <P>
    * @param event Contains details of the revoked data.
    * @see javax.infobus.DataItemChangeListener#dataItemRevoked
    */
    public void dataItemRevoked(DataItemRevokedEvent e)
    {
        // Tell the grid control that all the data has changed.
        _fireTableStructureAndDataChangedLater();
    }

    /**
    * Indicates that the cursor for the bound <TT>RowsetAccess</TT> data item
    * has changed rows. <P>
    * A reference to the rowset data item can be obtained from the event. <P>
    * @param event Contains details of the cursor move.
    * @see javax.infobus.DataItemChangeListener#rowsetCursorMoved
    */
    public void rowsetCursorMoved(RowsetCursorMovedEvent e)
    {
        // Handled by GridControl directly.
    }


    // TableModel Interface

    /**
    * Returns the name of the column at <I>columnIndex</I>. <P>
    * This is used to initialize the table's column header name.
    * Note, this name does not need to be unique.  Two columns on a table
    * can have the same name. <P>
    * @param columnIndex   The column index.
    * @return              The name of the column.
    */
    public String getColumnName(int columnIndex)
    {
        return ((_columnLabels == null) ? "" : _columnLabels[columnIndex]);
    }

    /**
    * Returns the lowest common denominator Class in the column. <P>
    * This is used by the table to set up a default renderer and editor
    * for the column. <P>
    * @param columnIndex   The column index.
    * @return              The common ancestor class of the object values
    *                      in the model.
    */
    public Class getColumnClass(int columnIndex)
    {
        Object col =
            getValueAt(_table.rowAtPoint(_viewPort.getViewPosition()),
                       columnIndex);
        return(col == null ? String.class : col.getClass());
    }

    /**
    * Returns true if the cell at <I>rowIndex</I> and <I>columnIndex</I>
    * is editable. <P>
    * Otherwise, setValueAt() on the cell will not change the value
    * of that cell. <P>
    * @param rowIndex    The row whose value is to be looked up.
    * @param columnIndex The column whose value is to be looked up.
    * @return              <TT>true</TT> if the cell is editable.
    * @see #setValueAt()
    */
    public boolean isCellEditable(int rowIndex, int columnIndex)
    {
        return((!_forceReadOnly && _rowset != null)
                ? _rowset.canUpdate(columnIndex+1) : false);
    }

    /**
    * Returns the number of columns managed by the data source object. <P>
    * A <TT>JTable</TT> uses this method to determine how many columns it
    * should create and display on initialization. <P>
    * @return  The number of columns in the model.
    * @see #getRowCount()
    */
    public int getColumnCount()
    {
        return ((_rowset != null) ? _rowset.getColumnCount() : 0);
    }

    /**
    * Returns the number of records managed by the data source object. <P>
    * A <TT>JTable</TT> uses this method to determine how many rows it
    * should create and display. <P>
    * This method should be quick, as it is called by <TT>JTable</TT>
    * quite frequently. <P>
    * @return  The number or rows in the model.
    * @see #getColumnCount()
    */
    public int getRowCount()
    {
        // Cached for speed.
        return (_rowCount);
    }

	protected int getRowCountFromRowsetAccess(ScrollableRowsetAccess scr)
	{
		return scr.getRowCount();
	}

    /**
    * Returns an attribute value for the cell at <I>columnIndex</I>
    * and <I>rowIndex</I>. <P>
    * @param rowIndex      The row whose value is to be looked up.
    * @param columnIndex       The column whose value is to be looked up.
    * @return              The value Object at the specified cell.
    */
    public synchronized Object getValueAt(int rowIndex, int columnIndex)
    {
        // _debug("getValueAt("+rowIndex+","+columnIndex+")");
        // XXX - Currently, this always returns a String representation.
        Object item = _getItemAt(rowIndex, columnIndex);
        if (item != null)
        {
            if (item instanceof ImmediateAccess)
            {
                String presStr =
                    (((ImmediateAccess)item).getPresentationString(
                                                  Locale.getDefault()));
                return(presStr.trim());
            }
            else
            {
                return(item.toString());
            }
        }
        else
        {
            return(null);
        }
    }

    /**
    * Sets an attribute value for the record in the cell at
    * <I>columnIndex</I> and <I>rowIndex</I>.
    * @param value                 The new value.
    * @param rowIndex      The row whose value is to be changed.
    * @param columnIndex   The column whose value is to be changed.
    * @see #getValueAt()
    * @see #isCellEditable()
    */
    public void setValueAt(Object value, int rowIndex, int columnIndex)
    {
        if (_rowset != null)
        {
            synchronized(_rowset)
            {
                try
                {
                    if (_rowset.absolute(rowIndex + 1))
                    {
                        // Don't set value if it hasn't changed.
                        Object oldValue = getValueAt(rowIndex, columnIndex);
                        if (oldValue == value ||
                            (oldValue != null && value != null &&
                             (oldValue.equals(value) ||
                              oldValue.toString().equals(value.toString()))))
                        {
                            return;
                        }

                        _rowset.setColumnValue(columnIndex + 1, value);
                        fireTableCellUpdated(rowIndex, columnIndex);
                    }
                }
                catch (RowsetValidationException e)
                {
                    fireTableCellUpdated(rowIndex, columnIndex);
                    throw(new ApplyEditsValidationException(e.getMessage()));
                }
                catch (SQLException e)
                {
                    fireTableCellUpdated(rowIndex, columnIndex);
                    throw(new ApplyEditsValidationException(e.getMessage()));
                }
            }
        }
    }


    /**
    * Returns the data item value for the cell at <I>columnIndex</I>
    * and <I>rowIndex</I>. <P>
    * This method is used internally and is invoked by the
    * <TT>GridControl</TT> directly for validation support. <P>
    * @param rowIndex      The row whose value is to be looked up.
    * @param columnIndex       The column whose value is to be looked up.
    * @return              The data item value at the specified cell.
    */
    protected synchronized Object _getItemAt(int rowIndex, int columnIndex)
    {
        // XXX - If rowIndex >= last row when hasMoreRows() is true,
        //       should fetch more rows from the rowset.

        // First, see if the row is inside the current view.
        int firstRow = _table.rowAtPoint(_viewPort.getViewPosition());
        int rowCount = _getRecommendedRangeSize();


        if (rowIndex >= firstRow && rowIndex < (firstRow + rowCount))
        {
            // First, try to use DataItemView -- much faster
            DataItemView itemView = _view;
            if (itemView != null)
            {
                // Need to make sure the view size/start is current...
                if (itemView.getViewStart() != firstRow)
                {
                    itemView.setViewStart(firstRow);
                }

                ArrayAccess view = itemView.getView(rowCount);
                if (view != null)
                {
                    int coord[] = new int[] { rowIndex - firstRow,
                                                  columnIndex };
                    try
                    {
                        Object item = view.getItemByCoordinates(coord);
                        if (item != null)
                        {
                            return (item);
                        }
                    }
                    catch (IndexOutOfBoundsException e)
                    {
                        // Do nothing... falls through to slow way below.
                    }
                }
            }
        }

        // The slow way, using our private cursor.
        ScrollableRowsetAccess cursor = _cursor;
        if (cursor != null)
        {
            // _debug("using ScrollableRowsetAccess");
            synchronized (cursor)
            {
                try
                {
                    if (cursor.absolute(rowIndex + 1))
                    {
                        return (cursor.getColumnItem(columnIndex + 1));
                    }
                }
                catch (RowsetValidationException e)
                {
                    // XXX - Do something useful
                }
                catch (SQLException e)
                {
                    // XXX - Do something useful
                }
            }
        }

        return (null);
    }

	protected int _getRecommendedRangeSize()
	{
   		return ( _computeVisibleRowcount() + 5);
	}

    protected int _computeVisibleRowcount()
    {
        int height = _viewPort.getExtentSize().height;
        int rowCount = (height / (_table.getRowHeight() +
                                  _table.getIntercellSpacing().height)) + 1;
        return(rowCount);
    } // _computeVisibleRowcount

    /**
    * Indicates a changed value in the bound data item. <P>
    * Does the real work of handling the DataItemValueChanged event.
    * A reference to the data item that changed can be obtained from the
    * event. <P>
    * @param event Contains change information.
    * @see javax.infobus.DataItemChangeListener#dataItemValueChanged
    */
    protected void _handleDataItemValueChanged(DataItemValueChangedEvent e)
    {
        // _debug("_handleDataItemValueChanged()");
        if (_rowset != null)
        {
            int endRow;
            int row = 0;
            int oldRowCount = _rowCount;


            // update row count
			if ( _shouldUpdateRowcount(e))
			{
			    _rowCount = getRowCountFromRowsetAccess(_rowset);
			}
            
            // XXX - Check hasMoreRows() and add an extra row at the bottom...
            endRow = _rowCount;

            if (oldRowCount != _rowCount)
            {
                endRow = Math.max(oldRowCount, _rowCount);
                if (endRow > 0)
                {
                    endRow--;
                }
                // Tell JTable to repaint the changed rows.
                _fireTableChangedLater(new TableModelEvent(this, row, endRow));
            }
            else
            {
                // check to see if this event was send in response to a change
                // in the composition of the view; skip it if is was just a
                // row change
                boolean isVuChange = false;
                int rowCount = -1;
                Object objp;

                // Check for properties
                objp = e.getProperty(Control.EVENT_PROPERTY_VIEW_CHANGE);
                if (objp != null && objp instanceof Boolean)
                {
                    isVuChange = ((Boolean)objp).booleanValue();
                }
                row = -1;
                objp = e.getProperty(Control.EVENT_PROPERTY_ROW);
                if (objp != null && objp instanceof Integer)
                {
                    row = ((Integer)objp).intValue();
                }
                objp = e.getProperty(Control.EVENT_PROPERTY_ROW_COUNT);
                if (objp != null && objp instanceof Integer)
                {
                    rowCount = ((Integer)objp).intValue();
                }


                // check if rowchange
                objp = e.getProperty(Control.EVENT_PROPERTY_ROW_CHANGE);
                boolean isRowChange = false;
                if (objp != null && objp instanceof Boolean)
                {
                    isRowChange = ((Boolean)objp).booleanValue();
                }

                if (isVuChange)
                {
                    if (row != -1)
                    {
                        if (rowCount != -1)
                        {
                            endRow = row + ((rowCount > 0) ? rowCount - 1 : 0);
                        }
                        else
                        {
                            endRow = row;
                        }
                    }
                    else
                    {
                        if (endRow > 0)
                        {
                            endRow--;
                        }
                    }
                    // Tell JTable to repaint the changed rows.
                    _fireTableChangedLater(new TableModelEvent(this, row,
                                                               endRow));
                }
                else if( isRowChange )
                {
                    _fireTableChangedLater(new TableModelEvent(this, row,
                                                               row));
                }

            }
            row = _rowset.getRow(); // origin 1
            if (row-- <= 0)
            {
                // no current row currently; clear the selection
                _table.clearSelection();
            }
        }
    }

	protected boolean _shouldUpdateRowcount(DataItemValueChangedEvent e)
	{
		boolean bScrolled = false;

		Object objp = e.getProperty(Control.EVENT_PROPERTY_VIEW_SCROLLED);
        if (objp != null && objp instanceof Boolean)
        {
             bScrolled = ((Boolean)objp).booleanValue();
        }

		return !bScrolled;
	}

    /**
    * Indicates that a new item was added to the bound aggregate data item
    * (e.g. <TT>ArrayAccess</TT>, a JDK Collection, etc). <P>
    * A reference to the data item that was added, and a reference to the one
    * that gained it, can be obtained from the event. <P>
    * @param event Contains details of the addition.
    * @see javax.infobus.DataItemChangeListener#dataItemAdded
    */
    protected void _handleDataItemAdded(DataItemAddedEvent e)
    {
        // _debug("handleDataItemAdded: " + e);
        // Get the currently selected row in the table.
        // Must be done before any notifications are sent to the table.
		int rc = getRowCountFromRowsetAccess(_rowset);

        int currentRow = (_rowset != null && rc != 0)
            ? (_rowset.getRow()-1) : 0;

        // Check for properties indicating the starting row and row count
        // to minimize the repaints necessary.
        boolean gotProperties = false;
        Object rowp = e.getProperty(Control.EVENT_PROPERTY_ROW);
        if (rowp != null && rowp instanceof Integer)
        {
            int row = ((Integer)rowp).intValue() - 1;
            Object countp = e.getProperty(Control.EVENT_PROPERTY_ROW_COUNT);
            if (countp != null && countp instanceof Integer)
            {
                int rowCount = ((Integer)countp).intValue();
                if (rowCount > 0)
                {
                    fireTableRowsInserted(row, row + rowCount - 1);
                    gotProperties = true;
                }
            }
        }

        // If didn't find properties, refresh the whole grid.
        if (!gotProperties)
        {
            fireTableDataChanged();
        }
    }

    /**
    * Indicates that an item was deleted from the bound aggregate data item
    * (e. g. <TT>ArrayAccess</TT>, a JDK Collection, etc). <P>
    * A reference to the data item that was deleted, and a reference to the
    * one that lost it, can be obtained from the event. <P>
    * @param event Contains details of the deletion.
    * @see javax.infobus.DataItemChangeListener#dataItemDeleted
    */
    protected void _handleDataItemDeleted(DataItemDeletedEvent e)
    {
        // Get the currently selected row in the table.
        // Must be done before any notifications are sent to the table.
		int rc = getRowCountFromRowsetAccess(_rowset);
        int currentRow = (_rowset != null && rc != 0)
            ? (_rowset.getRow()-1) : 0;

        // Check for properties indicating the starting row and row count
        // to minimize the repaints necessary.
        boolean gotProperties = false;
        Object rowp = e.getProperty(Control.EVENT_PROPERTY_ROW);
        if (rowp != null && rowp instanceof Integer)
        {
            int row = ((Integer)rowp).intValue() - 1;
            Object countp = e.getProperty(Control.EVENT_PROPERTY_ROW_COUNT);
            if (countp != null && countp instanceof Integer)
            {
                int rowCount = ((Integer)countp).intValue();
                if (rowCount > 0)
                {
                    fireTableRowsDeleted(row, row + rowCount - 1);
                    gotProperties = true;
                }
            }
        }

        // If didn't find properties, refresh the whole grid.
        if (!gotProperties)
        {
            fireTableDataChanged();
        }
    }

    /**
    * Fires the <TT>TableStructureChanged</TT> and <TT>TableDataChanged</TT>
    * events to the table from the Event Dispatch thread. <P>
    * This will be thread-safe for Swing. <P>
    */
    private void _fireTableStructureAndDataChangedLater()
    {
        SwingUtilities.invokeLater(
                                   new Runnable()
                                   {
                                       public void run()
                                       {
                                          _fireTableStructureAndDataChanged();
                                       }
                                   }
                                   );
    }

    /**
    * Fires the <TT>TableStructureChanged</TT> and <TT>TableDataChanged</TT>
    * events to the table. <P>
    * This class is not thread-safe for Swing. <P>
    * @see #_fireTableStructureAndDataChangedLater
    */
    private void _fireTableStructureAndDataChanged()
    {
        fireTableStructureChanged();
        fireTableDataChanged();
    }

    /**
    * Fires the <TT>TableChanged</TT> event to the table from the Event
    * Dispatch thread. <P>
    * This will be thread-safe for Swing. <P>
    * @param event The event.
    */
    private void _fireTableChangedLater(final TableModelEvent event)
    {
        SwingUtilities.invokeLater(
                                   new Runnable()
                                   {
                                       public void run()
                                       {
                                           _fireTableChanged(event);
                                       }
                                   }
                                   );
    }

    /**
    * Fires the <TT>TableChanged</TT> event to the table. <P>
    * This class is not thread-safe for Swing. <P>
    * @see #_fireTableChangedLater
    */
    protected void _fireTableChanged(TableModelEvent event)
    {
        fireTableChanged(event);
    }

    protected void _getColumnLabels(ScrollableRowsetAccess rowset)
    {
        Object[] columnLabels =
            (Object [])((DataItem)rowset).getProperty(DataItemProperties.COLUMN_LABELS);
        if ( columnLabels != null )
        {
            String name;
            DataItem di;
            int columnCount = getColumnCount();
            _columnLabels = new String[columnCount];
            for ( int i=0 ; i < columnCount; i++)
            {
                if (columnLabels[i] == null)
                {
                    // use table column name as column heading as a backup
                    // in case an exception is thrown
                    name = _rowset.getColumnName(i+1);
                    try
                    {
                        di = (DataItem)rowset.getColumnItem(i+1);
                        name = (String)di.getProperty(DataItemProperties.DATASOURCE_NAME);
                    }
                    catch(Exception e)
                    {
                    }
                    _columnLabels[i] = name;
                }
                else
                {
                    _columnLabels[i] = (String)columnLabels[i];
                }
            }
        }
    }

    /**
    *  build a table column model, based on the widths specified.
    *
    *  @param rowset for which the table column model has to be built
    *  @return TableColumnModel built from the rowset
    *
    */
    protected  GridTableColumnModel
        _buildColumnModel(ScrollableRowsetAccess rowset)
    {
        int thisColumnAlignment;
        int thisColumnWidth;
        boolean displayAttribute;
        SortableTableColumn thisColumn;
        JTextField textField;
        GridTableCellRenderer label;
        DataItem di;
        String name;
        GridTableColumnModel columnModel = new GridTableColumnModel(_table);
        Component comp = null;
        int headerWidth = 0;
        boolean autoSize = true;

        Object columnWidths[] = (Object [])((DataItem)rowset).getProperty(
                                             DataItemProperties.COLUMN_WIDTHS);
        Object columnAlignments[] = (Object [])((DataItem)rowset).getProperty(
                                             DataItemProperties.COLUMN_ALIGNMENTS);
        Object sortingEnabled[] = (Object [])((DataItem)rowset).getProperty(
                                             DataItemProperties.SORTING_ENABLED);

        // set table header renderer and mouse listener for sorting
        JTableHeader header = _table.getTableHeader();
        ResultSetInfo rsInfo = (ResultSetInfo)((DataItem)rowset).getProperty(DataItemProperties.INFO_OBJECT);
		SortDelegate sortDelegate = _gridControl.getSortDelegate();

        SortableHeaderRenderer headerRenderer =
            new SortableHeaderRenderer(_rowset, _table, sortDelegate);
        columnModel.setHeaderRenderer(headerRenderer);
        header.addMouseListener(headerRenderer);

        for ( int i=0; i < getColumnCount(); i++)
        {
            thisColumnWidth = ((Integer)columnWidths[i]).intValue();

            if (!_isColumnDispayable((RowsetAccess)rowset, i) ||
                                        (thisColumnWidth == 0))
            {
                continue;
            }

            displayAttribute = true;
            displayAttribute = _isColumnDisplayed((RowsetAccess)rowset, i);

            thisColumn = new SortableTableColumn(i);
            thisColumn.setHeaderValue(this.getColumnName(i));

            columnModel.addColumn(thisColumn, displayAttribute);

            // renderer
            label = new GridTableCellRenderer(_gridControl);
            thisColumn.setCellRenderer(label);

            textField = new GridCellField(); // see GridCellEditor.java

            thisColumnAlignment = ((Integer)columnAlignments[i]).intValue();
            if (thisColumnAlignment != -1 ||
                _isANumber(rowset.getColumnDatatypeNumber(i+1)))
            {
                if (thisColumnAlignment == -1)
                {
                   thisColumnAlignment = SwingConstants.RIGHT;
                }
                label.setHorizontalAlignment(thisColumnAlignment);
                // JTextFields currently don't know how to deal with the new
                // directional constants
                if (thisColumnAlignment == SwingConstants.LEADING)
                {
                    thisColumnAlignment = SwingConstants.LEFT;
                }
                else if (thisColumnAlignment == SwingConstants.TRAILING)
                {
                    thisColumnAlignment = SwingConstants.RIGHT;
                }
                textField.setHorizontalAlignment(thisColumnAlignment);
            }
            thisColumn.setCellEditor(new GridCellEditor(textField));

            thisColumn.setHeaderRenderer(headerRenderer);
            if ( ((Boolean)sortingEnabled[i]).booleanValue() &&
                   _isSortable(rowset.getColumnDatatypeNumber(i+1)))
            {
               try
               {
                  di = ((DataItem)rowset.getColumnItem(i+1));
                  name =
                      ((String)di.getProperty(DataItemProperties.COLUMN_NAME));
                  thisColumn.setColumnName(name);
               }
               catch (java.sql.SQLException e)
               {
                  thisColumn.setColumnName("");
               }
            }
            else
            {
                thisColumn.setSortOrder(SortableTableColumn.SORT_DISABLED);
            }

            if (thisColumnWidth > 0)
            {
                autoSize = false;
                comp = thisColumn.getHeaderRenderer().
                   getTableCellRendererComponent(
                         null, thisColumn.getHeaderValue(),false, false, 0, 0);

                headerWidth = comp.getPreferredSize().width;

                //comp = _table.getDefaultRenderer(this.getColumnClass(i)).
                //             getTableCellRendererComponent(
                //                 _table, this.longValues[i],
                //                 false, false, 0, i);
                //cellWidth = comp.getPreferredSize().width;

                thisColumn.setPreferredWidth(Math.max(headerWidth,
                                                      thisColumnWidth));

            }
        }
        return(columnModel);
    }

    /**
    *  determine if the column is displayable
    *
    *  colIndex is zero based
    */
    private boolean _isColumnDispayable(RowsetAccess rsAccess, int colIndex)
    {
        Object dataitem= _getColumnItem(rsAccess, colIndex);
        return _getColumnAttribute((DataItem)dataitem, DataItemProperties.DISPLAYABLE);
    }

    /**
    *  return true if the column is displayed
    *
    */
    private boolean _isColumnDisplayed(RowsetAccess rsAccess, int colIndex)
    {
        Object dataitem= _getColumnItem(rsAccess, colIndex);
        return _getColumnAttribute((DataItem)dataitem, DataItemProperties.DISPLAYED);
    }

    private boolean _getColumnAttribute(DataItem dataitem, String name)
    {
        if ( dataitem != null )
        {
             Object  displayable = ((DataItem)dataitem).getProperty(name);
             if (displayable != null)
                 return  ((Boolean)displayable).booleanValue();
        }
        return true;
    }

    // colIndex 0 based
    protected Object _getColumnItem(RowsetAccess rsAccess, int colIndex)
    {
        try
        {
            Object dataitem= rsAccess.getColumnItem(colIndex+1);
            return dataitem;
       }
       catch( Exception e)
       {
           return null;
       }

    }



    private boolean _isANumber(int SQLtype)
    {
       switch(SQLtype)
       {
       case Types.BIT:
       case Types.TINYINT:
       case Types.SMALLINT:
       case Types.INTEGER:
       case Types.BIGINT:
       case Types.FLOAT:
       case Types.REAL:
       case Types.NUMERIC:
       case Types.DECIMAL:
            return true;
       default:
          return false;
       }
    }
    private boolean _isSortable(int type)
    {
       switch (type)
       {
          case Types.BINARY:
          case Types.LONGVARBINARY:
          case Types.LONGVARCHAR:
          case Types.NULL:
          case Types.OTHER:
          case Types.VARBINARY:
               return false;
          default :
               return true;
       }
    }


    private void _debug(String s)
    {
        if (_DEBUG)
        {
            System.out.println("GridDataSource: " + s);
        }
    } // _debug
}

/**
*  A TableColumn object which stores the sort order for this column and the
*  underlying column name
*/
class SortableTableColumn extends TableColumn
{
    private int _sortOrder = SORT_NONE;
    private String _columnName;

    public static final int SORT_ASC   = 0;
    public static final int SORT_DESC  = 1;
    public static final int SORT_NONE  = 2;
    public static final int SORT_DISABLED  = 3;

    SortableTableColumn(int modelIndex)
    {
        super(modelIndex);
    }

    /**
    * change the sort order.
    *
    * @return the new sort order
    */
    public int changeSortOrder()
    {
        if ( _sortOrder == SORT_NONE )
           _sortOrder = SORT_ASC;
        else if (_sortOrder == SORT_ASC )
           _sortOrder = SORT_DESC;
        else if (_sortOrder == SORT_DESC )
           _sortOrder = SORT_ASC;
        else
           _sortOrder = SORT_DISABLED;
        return _sortOrder;
    }

    public void setSortOrder(int nuSortOrder)
    {
        _sortOrder = nuSortOrder;
    }

    /**
    * get the current sort order
    */
    public int getSortOrder()
    {
        return _sortOrder;
    }

    /**
    * what is the next possible sort order
    */
    public int getNextSortOrder(int oldSortOrder)
    {
        if ( oldSortOrder == SORT_NONE )
           return SORT_ASC;
        else if (oldSortOrder == SORT_ASC )
           return SORT_DESC;
        else if (oldSortOrder == SORT_DESC )
           return SORT_ASC;
        else
           return SORT_DISABLED;
    }

    /**
    * set the column name this column represents. used in specifying the
    * sort order
    */
    public void setColumnName(String s)
    {
        _columnName = s;
    }

    /**
    * get the column name
    */
    public String getColumnName()
    {
        return  _columnName;
    }
}



/**
*  A Table renderer which listens for mouse clicks and sorts. Each mouse
*  click toggles the previous sort order (ascending to descending). The
*  renderer check if we are working with the SortableTableColumn to determine
*  the sort order and the icon to display in the label
*/
class SortableHeaderRenderer  extends DefaultTableCellRenderer
    implements MouseListener
{
    private static final String _IMAGES_DIR = "/oracle/dacf/images/";
    private static final String _ASCENDING_ICON_NAME = "ascsort.gif";
    private static final String _DESCENDING_ICON_NAME = "descsort.gif";
    static final ImageIcon _ascendingIcon =
        _loadImage(_IMAGES_DIR + _ASCENDING_ICON_NAME);
    static final ImageIcon _descendingIcon =
        _loadImage(_IMAGES_DIR + _DESCENDING_ICON_NAME);
    private JTable _table;
    private ScrollableRowsetAccess  _rowset;
	private SortDelegate _sortDelegate;


    SortableHeaderRenderer(ScrollableRowsetAccess rowset, JTable table, 
						   SortDelegate sortDelegate)
    {
        super();
        _table = table;
        setRowSet(rowset);
		_sortDelegate=sortDelegate;
    }

    public Component getTableCellRendererComponent(JTable table,
                                                   Object value,
                                                   boolean isSelected,
                                                   boolean hasFocus,
                                                   int row, int column)
    {
        if (table != null)
        {
            JTableHeader header = table.getTableHeader();
            if (header != null)
            {
                setForeground(header.getForeground());
                setBackground(header.getBackground());
                setFont(header.getFont());
            }

            TableColumnModel tcModel = table.getColumnModel();
            TableColumn tc = tcModel.getColumn(column);
            if ( tc instanceof SortableTableColumn)
            {
                int sortOrder = ((SortableTableColumn)tc).getSortOrder();
                switch (sortOrder)
                {
                case SortableTableColumn.SORT_ASC:
                    setIcon(_ascendingIcon);
                    break;
                case SortableTableColumn.SORT_DESC:
                    setIcon(_descendingIcon);
                    break;
                default:
                    setIcon(null);
                    break;
                }
            }
        }

        setText((value == null) ? "" : value.toString());
        setBorder(UIManager.getBorder("TableHeader.cellBorder"));
        return this;
    }

    void setRowSet(ScrollableRowsetAccess rs)
    {
        _rowset = rs;
    }

    // implement MouseListener interface
    public void mouseClicked(MouseEvent e)
    {
        int c = _table.getTableHeader().columnAtPoint(e.getPoint());
        TableColumnModel tcModel = _table.getColumnModel();
        TableColumn tc = tcModel.getColumn(c);

        if ( tc instanceof SortableTableColumn)
        {
            SortableTableColumn stc = (SortableTableColumn)tc;
            if (stc.getSortOrder() == stc.SORT_DISABLED)
                return;

			if (_sortDelegate.preSort(_rowset))
			{
				String order = null;
				int oldSortOrder = stc.getSortOrder();
				int nextSortOrder = stc.getNextSortOrder(oldSortOrder);
				switch (nextSortOrder)
				{
					case SortableTableColumn.SORT_ASC :
					order = "ASC";
						break;
					case SortableTableColumn.SORT_DESC:
						order = "DESC";
						break;
					default :
						break;
				}

				boolean isSortSuccessful  = _sortDelegate.sort(_rowset, 
									stc.getColumnName(), order);

				if (isSortSuccessful)
				{
					_resetSortOrderForAllColumns(tcModel);
                    stc.setSortOrder(nextSortOrder);
				}
				else
				{
					stc.setSortOrder(oldSortOrder);
				}
				_sortDelegate.postSort(_rowset);
			}
            _table.getTableHeader().repaint();
        }
    }

    public void mousePressed(MouseEvent e)
    {
    }

    public void mouseReleased(MouseEvent e)
    {
    }

    public void mouseEntered(MouseEvent e)
    {
    }

    public void mouseExited(MouseEvent e)
    {
    }

    /**
    *  reset the sort order to none for all columns
    */
    private void _resetSortOrderForAllColumns(TableColumnModel tcm)
    {
        Enumeration colEnumeration = tcm.getColumns();
        while (  colEnumeration.hasMoreElements())
        {
            Object o = colEnumeration.nextElement();
            if ( o instanceof SortableTableColumn)
            {
                SortableTableColumn stc = (SortableTableColumn)o;
                if (stc.getSortOrder() !=  SortableTableColumn.SORT_DISABLED)
                    stc.setSortOrder(SortableTableColumn.SORT_NONE);
            }
        }
    }

    private static ImageIcon _loadImage(String name)
    {
        Class cl = GridDataSource.class;
        URL img = cl.getResource(name);
        ImageIcon i =  new ImageIcon(img);
        return i;
    }
}

class GridTableCellRenderer extends DefaultTableCellRenderer
{
    protected GridControl _gridControl;
    GridTableCellRenderer(GridControl gridControl)
    {
        super();
        _gridControl = gridControl;
    }
}
