/*
 * @(#)TextAreaControl.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.dacf.control.swing;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.Insets;
import java.awt.LayoutManager;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.util.Locale;
import javax.infobus.DataItem;
import javax.infobus.DataItemAddedEvent;
import javax.infobus.DataItemDeletedEvent;
import javax.infobus.DataItemRevokedEvent;
import javax.infobus.DataItemValueChangedEvent;
import javax.infobus.ImmediateAccess;
import javax.infobus.InvalidDataException;
import javax.infobus.RowsetCursorMovedEvent;
import javax.infobus.UnsupportedOperationException;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.SwingUtilities;
import javax.swing.border.Border;
import javax.swing.text.Caret;
import javax.swing.text.Document;
import javax.swing.text.Highlighter;
import javax.swing.text.Keymap;
import oracle.dacf.control.ApplyEditsListener;
import oracle.dacf.control.ApplyEditsValidationException;
import oracle.dacf.control.Control;
import oracle.dacf.control.ControlEnabledListener;
import oracle.dacf.control.ControlSupport;
import oracle.dacf.control.InfoBusManager;
import oracle.dacf.control.InfoBusManagerListener;
import oracle.dacf.control.InfoBusManagerReleaseEvent;
import oracle.dacf.control.NavigatedEvent;
import oracle.dacf.control.NavigatedListener;
import oracle.dacf.control.NavigatingEvent;
import oracle.dacf.control.NavigatingException;
import oracle.dacf.control.NavigatingListener;
import oracle.dacf.control.NavigationManager;
import oracle.dacf.dataset.DataItemProperties;

/**
 * A data aware control to display and text in multiple lines. TextAreaControl
 * can be bound to an ImmediateAccess dataitem. <P>
 * TextAreaControl is a composite control comprising of a JTextArea
 * and a JScrollPane.
 *
 *
 * @version PUBLIC
 */
public class TextAreaControl
    extends JPanel
    implements Control, ImmediateAccess, FocusListener, ControlEnabledListener,
               ApplyEditsListener, InfoBusManagerListener
{
    private boolean _revertValueOnError = false;
    private ControlSupport _controlSupport;
    private TextAreaView _textView;
    private JScrollPane _scrollPane;
    private Document _document; // document model we use

    private static int _rows = 3;
    private static int _columns = 10;


    /**
    * Constructs a default TextAreaControl
    */
    public TextAreaControl()
    {
        this(null, "", _rows, _columns);
    }


    /**
    * Constructs a new TextAreaControl with the specified text displayed.
    *
    * @param text the text to be displayed
    */
    public TextAreaControl(String text)
    {
        this(null, "", _rows, _columns);
    }

    /**
    * Constructs a new empty TextAreaControl with the specified number of
    * rows and columns.
    *
    * @param rows the number of rows
    * @param columns the number of columns
    */
    public TextAreaControl(int rows, int columns)
    {
        this(null, "", rows, columns);
    }

    /**
    * Constructs a new TextAreaControl with the specified text and number
    * of rows and columns.
    *
    * @param text the text to be displayed
    * @param rows the number of rows
    * @param columns the number of columns
    */
    public TextAreaControl(String text, int rows, int columns)
    {
        this(null, text, rows, columns);
    }

    /**
    * Constructs a new TextAreaControl with the given document model, and
    * defaults for all of the other arguments.
    *
    * @param doc  the model to use
    */
    public TextAreaControl(Document doc)
    {
        this(doc, "", _rows, _columns);
    }

    /**
    * Constructs a new TextAreaControl with the specified number of rows
    * and columns, and the given model.
    *
    * @param doc the model to use
    * @param text the text to be displayed
    * @param rows the number of rows
    * @param columns the number of columns
    */
    public TextAreaControl(Document doc, String text, int rows, int columns)
    {
        _textView = new TextAreaView(doc, text, rows, columns);
        _init();
    }


    /**
    *  initialization method used by all constructors.
    */
    private void _init()
    {
        _scrollPane = new JScrollPane();
        _controlSupport = new ControlSupport(this);
        _controlSupport.addControlEnabledListener(this);
        InfoBusManager.getInstance().addInfoBusManagerListener(this);
        _scrollPane.getViewport().setView(_textView);
        setLayout(new BorderLayout());
        add(_scrollPane, BorderLayout.CENTER);
        _textView.addFocusListener(this);

        // set the JPanel to the jTextArea default
		
        setBackground(_textView.getBackground());
        setForeground(_textView.getForeground());
        setFont(_textView.getFont());
    }


    /**
    **  Sets the value for the RevertValueOnError property
    **
    **  When this property is set to <tt>true</tt> then the TextFieldControl
    **  will revert to the value displayed prior to being edited.
    **
    ** @param revertIt the value for the RevertValueOnError property
    ** @see #<method>(<sig>)
    ** @see <Class>#<method>(<sig>)
    */
    public void setRevertValueOnError(boolean revertIt)
    {
        _revertValueOnError = revertIt;
    } // setRevertValueOnError
    
    /**
    **  Returns the value for the RevertValueOnError property
    **
    **  When this property is set to <tt>true</tt> then the TextFieldControl
    **  will revert to the value displayed prior to being edited.
    **
    ** @return the value for the RevertValueOnError property
    ** @see #<method>(<sig>)
    ** @see <Class>#<method>(<sig>)
    */
    public boolean getRevertValueOnError()
    {
        return(_revertValueOnError);
    } // getRevertValueOnError
    
    /**
    * Get the Cursor of this object.
    *
    * @return the Cursor, if supported, of the object; otherwise, null
    */
    public Cursor getCursor()
    {
        return _textView.getCursor();
    }

    /**
    * Set the Cursor of this object.
    *
    * @param c the new Cursor for the object
    */
    public void setCursor(Cursor cursor)
    {
        _textView.setCursor(cursor);
    }

    // InfoBusManagerListener interface implementation
    public void releaseResources(InfoBusManagerReleaseEvent e)
    {
        if (e.appliesTo(this))
        {
            InfoBusManager.getInstance().removeInfoBusManagerListener(this);
            _textView.removeFocusListener(this);
            _controlSupport.removeControlEnabledListener(this);
            _controlSupport = null;
        }
    }

    /**
    * Determine if the object is enabled.
    *
    * @return true if object is enabled; otherwise, false
    */
    public boolean isEnabled()
    {
        return(_textView.isEnabled());
    }

    /**
    * Set the enabled state of the object.
    *
    * @param b if true, enables this object; otherwise, disables it
    */
    public void setEnabled(boolean b)
    {
        super.setEnabled(b);
        if (_controlSupport != null)
        {
            _controlSupport.setEnabled(b);
        }
    }

    // ControlEnabledListener interface
    public void enabledChanged(boolean b)
    {
        _textView.setEnabled(b);
    }

    /**
    * Determine if the object is visible.  Note: this means that the
    * object intends to be visible; however, it may not in fact be
    * showing on the screen because one of the objects that this object
    * is contained by is not visible.  To determine if an object is
    * showing on the screen, use isShowing().
    *
    * @return true if object is visible; otherwise, false
    */
    public boolean isVisible()
    {
        return(_textView.isVisible());
    }

    /**
    * Set the visible state of the object.
    *
    * @param b if true, shows this object; otherwise, hides it
    */
    public void setVisible(boolean b)
    {
        _textView.setVisible(b);
    }

    /**
    * Gets the layout manager for this container.
    * @see #setLayout
    */
    public LayoutManager getLayout()
    {
        return(_textView.getLayout());
    }


    //  /**
    //  * Sets the layout manager for this container.
    //  * @param mgr the specified layout manager
    //  * @see #getLayout
    //  */
    //  public void setLayout(LayoutManager mgr)
    //  {
    //
    //      if (null == _textView)
    //      {
    //             _textView = new TextAreaView();
    //      }
    //
    //      _textView.setLayout(mgr);
    //  }



    /**
    * Sets the maximumSize of this component to a constant
    * value.  Subsequent calls to getMaximumSize will always
    * return this value, the components UI will not be asked
    * to compute it.  Setting the maximumSize to null
    * restores the default behavior.
    *
    * @see #getMaximumSize
    * @beaninfo
    *   preferred: true
    * description: The maximum size of the component.
    */
    public void setMaximumSize(Dimension maximumSize)
    {
        _textView.setMaximumSize(maximumSize);
    }

    /**
    * If the maximumSize has been set to a non-null value
    * just return it.  If the UI delegates getMaximumSize()
    * method returns a non null value then return that, otherwise
    * defer to the components layout manager.
    *
    * @return the value of the maximumSize property.
    * @see #setMaximumSize
    */
    public Dimension getMaximumSize()
    {
        return(_textView.getMaximumSize());
    }


    /**
    * Sets the minimumSize of this component to a constant
    * value.  Subsequent calls to getMinimumSize will always
    * return this value, the components UI will not be asked
    * to compute it.  Setting the minimumSize to null
    * restores the default behavior.
    *
    * @see #getMinimumSize
    * @beaninfo
    *   preferred: true
    * description: The minimum size of the component.
    */
    public void setMinimumSize(Dimension minimumSize)
    {
        _textView.setMinimumSize(minimumSize);
    }

    /**
    * If the minimumSize has been set to a non-null value
    * just return it.  If the UI delegates getMinimumSize()
    * method returns a non null value then return that, otherwise
    * defer to the components layout manager.
    *
    * @return the value of the minimumSize property.
    * @see #setMinimumSize
    */
    public Dimension getMinimumSize()
    {
        return(_textView.getMinimumSize());
    }

    /**
    * Specifies the next component to get the focus after this one,
    * for example, when the tab key is pressed. Invoke this method
    * to override the default focus-change sequence.
    * @beaninfo
    *      expert: true
    * description: The next component to get focus after this one.
    */
    public void setNextFocusableComponent(Component aComponent)
    {
        _textView.setNextFocusableComponent(aComponent);
    }

    /**
    * Return the next focusable component or null if the focus manager
    * should choose the next focusable component automatically
    */
    public Component getNextFocusableComponent()
    {
        return(_textView.getNextFocusableComponent());
    }


    /**
    * Set the preferred size of the receiving component.
    * if <code>preferredSize</code> is null, the UI will
    * be asked for the preferred size
    */
    public void setPreferredSize(Dimension preferredSize)
    {
        _textView.setPreferredSize(preferredSize);
    }

    /**
    * If the preferredSize has been set to a non-null value
    * just return it.  If the UI delegates getPreferredSize()
    * method returns a non null then value return that, otherwise
    * defer to the components layout manager.
    *
    * @return the value of the preferredSize property.
    * @see #setPreferredSize
    */
    public Dimension getPreferredSize()
    {
        return(_textView.getPreferredSize());
    }


    /**
    *  Set whether the receiving component can obtain the focus by
    *  calling requestFocus. The default value is true.
    *  Note: Setting this property to false will not prevent the focus
    *  manager from setting the focus to this component, it will prevent
    *  the component from getting the focus when the focus is requested
    *  explicitly. Override isFocusTraversable and return false if the
    *  component should never get the focus.
    */
    public void setRequestFocusEnabled(boolean aFlag)
    {
        _textView.setRequestFocusEnabled(aFlag);
    }

    /** Return whether the receiving component can obtain the focus by
    *  calling requestFocus
    *  @see #setRequestFocusEnabled()
    */
    public boolean isRequestFocusEnabled()
    {
        return(_textView.isRequestFocusEnabled());
    }


    /**
    * Sets the border of this component.  The Border object is
    * responsible for defining the insets for the component
    * (overriding any insets set directly on the component) and
    * for optionally rendering any border decorations within the
    * bounds of those insets.  Borders should be used (rather
    * than insets) for creating both decorative and non-decorative
    * (e.g. margins and padding) regions for a swing component.
    * Compound borders can be used to nest multiple borders within a
    * single component.
    * <p>
    * This is a bound property.
    *
    * @param border the border to be rendered for this component
    */
    public void setControlBorder(Border border)
    {
        _textView.setBorder(border);
    }

    /**
    * Returns the border of this component or null if no border is
    * currently set.
    *
    * @return the border object for this component
    * @see setBorder
    */
    public Border getControlBorder()
    {
        return(_textView.getBorder());
    }



    /**
    * Gets the underlying JTextArea used by this control
    * @return JTextArea being used by this control
    */
    public JTextArea getTextArea()
    {
        return(_textView);
    }



    // start overrides for composite dacs
    public void setOpaque(boolean isOpaque)
    {
        if (_textView != null)
        {
            super.setOpaque(isOpaque);
            _textView.setOpaque(isOpaque);
        }
    }

    /**
    * Registers the text to display in a tool tip.
    * The text displays when the cursor lingers over the component.
    * <p>
    * See <a href="http://java.sun.com/docs/books/tutorial/ui/swing/tooltip.html">How to Use Tool Tips</a>
    * in <a href="http://java.sun.com/Series/Tutorial/index.html"><em>The Java Tutorial</em></a>
    * for further documentation.
    *
    * @param text  The string to display. If the text is null,
    *              the tool tip is turned off for this component.
    * @see #TOOL_TIP_TEXT_KEY
    * @beaninfo
    *   preferred: true
    * description: The text to display in a tool tip.
    */
    public void setToolTipText(String text)
    {
        if (_textView != null)
        {
            super.setToolTipText(text);
            _textView.setToolTipText(text);
        }
    }
    // end overrides for composite dacs


    // start expose the JTextArea properties

    /**
    * Fetches the caret that allows text-oriented navigation over
    * the view.
    *
    * @return the caret
    */
    public Caret getCaret()
    {
        return(_textView.getCaret());
    }

    /**
    * Sets the caret to be used.  By default this will be set
    * by the UI that gets installed.  This can be changed to
    * a custom caret if desired.  Setting the caret results in a
    * PropertyChange event ("caret") being fired.
    *
    * @param c the caret
    * @see #getCaret
    */
    public void setCaret(Caret c)
    {
        _textView.setCaret(c);
    }


    /**
    * Fetches the current color used to render the
    * caret.
    *
    * @return the color
    */
    public Color getCaretColor()
    {
        return(_textView.getCaretColor());
    }

    /**
    * Sets the current color used to render the
    * caret.  Setting to null effectively restores the default color.
    * Setting the color results in a PropertyChange event ("caretColor")
    * being fired.
    *
    * @param c the color
    * @see #getCaretColor
    */
    public void setCaretColor(Color c)
    {
        _textView.setCaretColor(c);
    }

    /**
    * Sets the position of the text insertion caret for the TextComponent.
    * Note that the caret tracks change, so this may move if the underlying
    * text of the component is changed.  If the document is null, does
    * nothing.
    *
    * @param position the position
    */
    public void setCaretPosition(int position)
    {
        _textView.setCaretPosition(position);
    }

    /**
    * Returns the position of the text insertion caret for the
    * text component.
    *
    * @return the position of the text insertion caret for the
    *  text component >= 0
    */
    public int getCaretPosition()
    {
        return(_textView.getCaretPosition());
    }


    /**
    * Sets the number of columns to be displayed in the underlying
    * JTextArea
    *
    * @param columns  the new rowcount
    * @see javax.swing.JTextArea#setColumns()
    */
    public void setColumns(int columns)
    {
        _textView.setColumns(columns);
    }

    /**
    * Gets the number of columns to displayed in the underlying
    * JTextArea
    *
    * @return the rowcount
    * @see javax.swing.JTextArea#getColumns()
    */
    public int getColumns()
    {
        return(_textView.getColumns());
    }


    /**
    * Fetches the current color used to render the
    * selected text.
    *
    * @return the color
    */
    public Color getDisabledTextColor()
    {
        return(_textView.getDisabledTextColor());
    }

    /**
    * Sets the current color used to render the
    * disabled text.  Setting the color fires off a
    * PropertyChange event ("disabledTextColor").
    *
    * @param c the color
    * @see #getDisabledTextColor
    */
    public void setDisabledTextColor(Color c)
    {
        _textView.setDisabledTextColor(c);
    }


    /**
    * Associates the editor with a text document.
    * The currently registered factory is used to build a view for
    * the document, which gets displayed by the editor after revalidation.
    * A PropertyChange event ("document") is propagated to each listener.
    *
    * @param doc  the document to display/edit
    * @see #getDocument
    */
    public void setDocument(Document doc)
    {
        _textView.setDocument(doc);
    }

    /**
    * Fetches the model associated with the editor.  This is
    * primarily for the UI to get at the minimal amount of
    * state required to be a text editor.  Subclasses will
    * return the actual type of the model which will typically
    * be something that extends Document.
    *
    * @return the model
    */
    public Document getDocument()
    {
        return(_textView.getDocument());
    }

    /**
    * Returns the boolean indicating whether this TextComponent is
    * editable or not.
    *
    * @return the boolean value
    * @see #setEditable
    */
    public boolean isEditable()
    {
        return(_textView.isEditable());
    }

    /**
    * Sets the specified boolean to indicate whether or not this
    * TextComponent should be editable.  A PropertyChange event ("editable")
    * is fired when the state is changed.
    *
    * @param b the boolean to be set
    * @see #isEditable
    */
    public void setEditable(boolean b)
    {
        _textView.setEditable(b);
    }


    /**
    * Sets the key accelerator that will cause the receiving text
    * component to get the focus.  The accelerator will be the
    * key combination of the <em>alt</em> key and the character
    * given (converted to upper case).  By default, there is no focus
    * accelerator key.  Any previous key accelerator setting will be
    * superseded.  A '\0' key setting will be registered, and has the
    * effect of turning off the focus accelerator.  When the new key
    * is set, a PropertyChange event (FOCUS_ACCELERATOR_KEY) will be fired.
    *
    * @param aKey the key
    */
    public void setFocusAccelerator(char aKey)
    {
        _textView.setFocusAccelerator(aKey);
    }

    /**
    * Returns the key accelerator that will cause the receiving
    * text component to get the focus.  Return '\0' if no focus
    * accelerator has been set.
    *
    * @return the key
    */
    public char getFocusAccelerator()
    {
        return(_textView.getFocusAccelerator());
    }

    /**
    * Fetches the object responsible for making highlights.
    *
    * @return the highlighter
    */
    public Highlighter getHighlighter()
    {
        return(_textView.getHighlighter());
    }

    /**
    * Sets the highlighter to be used.  By default this will be set
    * by the UI that gets installed.  This can be changed to
    * a custom highlighter if desired.  The highlighter can be set to
    * null to disable it.  A PropertyChange event ("highlighter") is fired
    * when a new highlighter is installed.
    *
    * @param h the highlighter
    * @see #getHighlighter
    */
    public void setHighlighter(Highlighter h)
    {
        _textView.setHighlighter(h);
    }

    /**
    * Sets the keymap to use for binding events to
    * actions.  Setting to null effectively disables keyboard input.
    * A PropertyChange event ("keymap") is fired when a new keymap
    * is installed.
    *
    * @param map the keymap
    * @see #getKeymap
    */
    public void setKeymap(Keymap map)
    {
        _textView.setKeymap(map);
    }

    /**
    * Fetches the keymap currently active in this text
    * component.
    *
    * @return the keymap
    */
    public Keymap getKeymap()
    {
        return(_textView.getKeymap());
    }

    /**
    * Sets the line-wrapping policy of the text area.  If set
    * to true the lines will be wrapped if they are too long
    * to fit within the allocated width.  If set to false,
    * the lines will always be unwrapped.  A PropertyChange event ("LineWrap")
    * is fired when the policy is changed.
    *
    * @param wrap indicates if lines should be wrapped.
    * @see #getLineWrap
    */
    public void setLineWrap(boolean wrap)
    {
        _textView.setLineWrap(wrap);
    }

    /**
    * Gets the line-wrapping policy of the text area.  If set
    * to true the lines will be wrapped if they are too long
    * to fit within the allocated width.  If set to false,
    * the lines will always be unwrapped.
    *
    * @returns if lines will be wrapped.
    */
    public boolean getLineWrap()
    {
        return(_textView.getLineWrap());
    }


    /**
    * Sets margin space between the text component's border
    * and its text. Setting it to null will cause the text component
    * to use a default margin.  The text component's default Border
    * object will use this value to create the proper margin.
    * However, if a non-default border is set on the text component,
    * it is that Border object's responsibility to create the
    * appropriate margin space (else this property will effectively
    * be ignored).  This causes a redraw of the component.
    * A PropertyChange event ("margin") is sent to all listeners.
    *
    * @param m the space between the border and the text
    */
    public void setMargin(Insets m)
    {
        _textView.setMargin(m);
    }

    /**
    * Returns the margin between the text component's border and
    * its text.  If no margin has been set, a default value from the UI
    * is returned.
    *
    * @return the margin
    */
    public Insets getMargin()
    {
        return(_textView.getMargin());
    }

    /**
    * Gets the number of rows to displayed in the underlying
    * JTextArea
    *
    * @return the rowcount
    * @see javax.swing.JTextArea#getRows()
    */
    public int getRows()
    {
        return(_textView.getRows());
    }

    /**
    * Sets the number of rows to be displayed in the underlying
    * JTextArea
    *
    * @param rows  the new rowcount
    * @see javax.swing.JTextArea#setRows()
    */
    public void setRows(int rows)
    {
        _textView.setRows(rows);
    }

    /**
    * Fetches the current color used to render the
    * selected text.
    *
    * @return the color
    */
    public Color getSelectedTextColor()
    {
        return(_textView.getSelectedTextColor());
    }

    /**
    * Sets the current color used to render the
    * selected text.  Setting the color to null is the same as Color.black.
    * Setting the color results in a PropertyChange event
    * ("selectedTextColor") being fired.
    *
    * @param c the color
    * @see #getSelectedTextColor
    */
    public void setSelectedTextColor(Color c)
    {
        _textView.setSelectedTextColor(c);
    }


    /**
    * Fetches the current color used to render the
    * selection.
    *
    * @return the color
    */
    public Color getSelectionColor()
    {
        return(_textView.getSelectionColor());
    }

    /**
    * Sets the current color used to render the
    * selection.  Setting the color to null is the same as setting
    * Color.white.  Setting the color results in a PropertyChange event
    * ("selectionColor").
    *
    * @param c the color
    * @see #getSelectionColor
    */
    public void setSelectionColor(Color c)
    {
        _textView.setSelectionColor(c);
    }


    /**
    * Returns the selected text's end position.  Return 0 if the document
    * is empty, or the value of dot if there is no selection.
    *
    * @return the end position >= 0
    */
    public int getSelectionEnd()
    {
        return(_textView.getSelectionEnd());
    }

    /**
    * Sets the selection end to the specified position.  The new
    * end point is constrained to be at or after the current
    * selection start.
    * <p>
    * This is available for backward compatiblitity to code
    * that called this method on java.awt.TextComponent.  This is
    * implemented to forward to the Caret implementation which
    * is where the actual selection is maintained.
    *
    * @param selectionEnd the end position of the text >= 0
    */
    public void setSelectionEnd(int selectionEnd)
    {
        _textView.setSelectionEnd(selectionEnd);
    }


    /**
    * Returns the selected text's start position.  Return 0 for an
    * empty document, or the value of dot if no selection.
    *
    * @return the start position >= 0
    */
    public int getSelectionStart()
    {
        return(_textView.getSelectionStart());
    }

    /**
    * Sets the selection start to the specified position.  The new
    * starting point is constrained to be before or at the current
    * selection end.
    * <p>
    * This is available for backward compatiblitity to code
    * that called this method on java.awt.TextComponent.  This is
    * implemented to forward to the Caret implementation which
    * is where the actual selection is maintained.
    *
    * @param selectionStart the start position of the text >= 0
    */
    public void setSelectionStart(int selectionStart)
    {
        _textView.setSelectionStart(selectionStart);
    }


    /**
    * Sets the number of characters to expand tabs to.
    * This will be multiplied by the maximum advance for
    * variable width fonts.  A PropertyChange event ("TabSize") is fired
    * when the tab size changes.
    *
    * @param size number of characters to expand to
    * @see #getTabSize
    */
    public void setTabSize(int size)
    {
        _textView.setTabSize(size);
    }

    /**
    * Gets the number of characters used to expand tabs.  If the document is
    * null or doesn't have a tab setting, return a default of 8.
    *
    * @return the number of characters
    */
    public int getTabSize()
    {
        return(_textView.getTabSize());
    }


    /**
    * Sets the text of this TextAreaControl to the specified text.  If the
    * text is null or empty, has the effect of simply deleting the old text.
    * @param t the new text to be set
    * @see #getText
    */
    public void setText(String t)
    {
        _textView.setText(t);
    }

    /**
    * Returns the text contained in this TextAreaControl.  If the underlying
    * document is null, will give a NullPointerException.
    *
    * @return the text
    * @see #setText
    */
    public String getText()
    {
        return(_textView.getText());
    }

    /**
    * Set the style of wrapping used if the text area is wrapping
    * lines.  If set to true the lines will be wrapped at word
    * boundries (ie whitespace) if they are too long
    * to fit within the allocated width.  If set to false,
    * the lines will be wrapped at character boundries.
    *
    * @param word indicates if word boundries should be used
    *   for line wrapping.
    * @see #getWrapStyle
    */
    public void setWrapStyleWord(boolean word)
    {
        _textView.setWrapStyleWord(word);
    }

    /**
    * Get the style of wrapping used if the text area is wrapping
    * lines.  If set to true the lines will be wrapped at word
    * boundries (ie whitespace) if they are too long
    * to fit within the allocated width.  If set to false,
    * the lines will be wrapped at character boundries.
    *
    * @returns if the wrap style should be word boundries
    *  instead of character boundries.
    */
    public boolean getWrapStyleWord()
    {
        return _textView.getWrapStyleWord();
    }

    // end expose the JTextArea properties


    // Control Interface
    /**
    * Returns the name of the InfoBus this control is connected to. <P>
    * Most controls should delegate this method to <TT>ControlSupport</TT>. <P>
    * @return  The name of the InfoBus this control is connected to.
    * @see ControlSupport#getInfoBusName
    */
    public final String getInfoBusName()
    {
        return(_controlSupport == null ?
               null : _controlSupport.getInfoBusName());
    }

    /**
    * Sets the name of the InfoBus this control is connected to. <P>
    * If the named InfoBus does not exist, it is created automatically. <P>
    * If the control is already connected to an InfoBus, it is disconnected
    * first. <P>
    * Most controls should delegate this method to <TT>ControlSupport</TT>. <P>
    * @param infoBusName   The name of the InfoBus to connect to.
    * @see ControlSupport#setInfoBusName
    */

    public final void setInfoBusName(String infoBusName)
    {
        if (_controlSupport != null)
        {
            _controlSupport.setInfoBusName(infoBusName);
        }
    }

    /**
    * Returns the name of the InfoBus DataItem this control is bound to. <P>
    * Most controls should delegate this method to <TT>ControlSupport</TT>. <P>
    * @return  The name of the InfoBus DataItem this control is bound to,
    *          or <TT>null</TT> if the control is unbound.
    * @see #getDataItem
    * @see ControlSupport#getDataItemName
    */

    public final String getDataItemName()
    {
        return(_controlSupport == null ?
               null : _controlSupport.getDataItemName());
    }

    /**
    * Sets the name of the InfoBus DataItem this control is bound to. <P>
    * The DataItem with the given name is searched for on the InfoBus, and
    * if found, is bound to this control. <P>
    * If the control is already bound to a DataItem, it is unbound first. <P>
    * Most controls should delegate this method to <TT>ControlSupport</TT>. <P>
    * @param dataItemName  The name of the DataItem to bind to.
    * @see #getDataItem
    * @see ControlSupport#setDataItemName
    */
    public final void setDataItemName(String dataItemName)
    {
        if (_document == null)
        {
            _document  = ( new TextAreaView()).getDocument();
            _textView.setDocument(_document);
        }
        if (_controlSupport != null)
        {
            _controlSupport.setDataItemName(dataItemName);
        }
    }

    /**
    * Returns the InfoBus DataItem this control is bound to. <P>
    * @return  The InfoBus DataItem this control is bound to, or
    *          <TT>null</TT> if the control is unbound.
    * @see ControlSupport#getDataItem
    */

    public final Object getDataItem()
    {
        return(_controlSupport == null ?
               null : _controlSupport.getDataItem());
    }



    /**
    * Notifies the control that the bound InfoBus DataItem has changed. <P>
    * The control can safely ignore this notification. <P>
    * @param oldDataItem   The formerly bound DataItem (can be <TT>null</TT>).
    * @param newDataItem   The newly bound DataItem (can be <TT>null</TT>).
    */
    public final void dataItemChanged(Object oldDataItem, Object newDataItem)
    {
        // Don't care
    }


    /**
    * Returns the AWT component associated with this control. <P>
    * @return  The AWT component for this control.
    */
    public final Component getComponent()
    {
        return(_textView);
    }

    /**
    * Returns  the scrollpane used by the textarea control
    * @return  JScrollPane
    */
    public final JScrollPane getScrollPane()
    {
        return(_scrollPane);
    }

    /**
    * Determines whether focus into this control causes validation to
    * occur. <P>
    * Most controls should delegate this method to <TT>ControlSupport</TT>. <P>
    * @return  <TT>true</TT> if focus into this control causes validation to
    *          occur, <TT>false</TT> otherwise.
    * @see ControlSupport#isFocusValidated
    */
    public final boolean isFocusValidated()
    {
        return(_controlSupport == null ?
               false : _controlSupport.isFocusValidated());
    }

    /**
    * Sets whether focus into this control causes validation to occur. <P>
    * Delegates to <TT>ControlSupport</TT>. <P>
    * @param focusValidated    If <TT>true</TT>, focus into this control will
    *                          cause validation to occur.
    * @see ControlSupport#setFocusValidated
    */
    public final void setFocusValidated(boolean focusValidated)
    {
        if (_controlSupport != null)
        {
            _controlSupport.setFocusValidated(focusValidated);
        }
    }

    /**
    * Adds a navigated listener to this control. <P>
    * The listener will be notified of NavigateIn and NavigateOut events. <P>
    * Delegates to <TT>ControlSupport</TT>. <P>
    * @param listener  The listener to add.
    * @see ControlSupport#addNavigatedListener
    */

    public final void addNavigatedListener(NavigatedListener listener)
    {
        if (_controlSupport != null)
        {
            _controlSupport.addNavigatedListener(listener);
        }
    }

    /**
    * Removes a navigated listener from this control. <P>
    * @param listener  The listener to remove.
    */
    public final void removeNavigatedListener(NavigatedListener listener)
    {
        if (_controlSupport != null)
        {
            _controlSupport.removeNavigatedListener(listener);
        }
    }

    /**
    * Processes a navigated event for this control. <P>
    * This method is for use by the NavigationManager only. <P>
    * @param event The navigated event.
    * @see ControlSupport#processNavigatedEvent
    */
    public final void processNavigatedEvent(NavigatedEvent event)
    {
        if (_controlSupport != null)
        {
            _controlSupport.processNavigatedEvent(event);
        }
    }

    /**
    * Adds a navigating listener to this control. <P>
    * The listener will be notified of NavigatingEvents. <P>
    * @param listener  The listener to add.
    */
    public final void addNavigatingListener(NavigatingListener listener)
    {
        if (_controlSupport != null)
        {
            _controlSupport.addNavigatingListener(listener);
        }
    }

    /**
    * Removes a previusly added navigating listener <P>
    * @param listener  The listener to remove.
    */

    public final void removeNavigatingListener(NavigatingListener listener)
    {
        if (_controlSupport != null)
        {
            _controlSupport.removeNavigatingListener(listener);
        }
    }

    /**
    * Processes a navigating event for this control. <P>
    * This method is for use by the NavigationManager only. <P>
    * @param event The navigating event.
    * @exception   NavigatingException   Indicates navigation was rejected.
    * @see ControlSupport#processNavigatedEvent
    */
    public final void processNavigatingEvent(NavigatingEvent event)
        throws NavigatingException
    {
        if (_controlSupport != null)
        {
            _controlSupport.processNavigatingEvent(event);
        }
    }



    // DataItemChangeListener Interface

    /**
    * Indicates a changed value in the bound data item. <P>
    * A reference to the data item that changed can be obtained from the
    * event. <P>
    * @param event Contains change information.
    * @see javax.infobus.DataItemChangeListener#dataItemValueChanged
    */
    public final void dataItemValueChanged(DataItemValueChangedEvent event)
    {
        if ( SwingUtilities.isEventDispatchThread())
        {
            _textView._updateValue(event.getChangedItem());
        }
        else
        {
            _textView._updateValueNow(event.getChangedItem());
        }
    }

    /**
    * Indicates that a new item was added to the bound aggregate data item
    * (e.g. <TT>ArrayAccess</TT>, a JDK Collection, etc). <P>
    * A reference to the data item that was added, and a reference to the one
    * that gained it, can be obtained from the event. <P>
    * @param event Contains details of the addition.
    * @see javax.infobus.DataItemChangeListener#dataItemAdded
    */

    public final void dataItemAdded(DataItemAddedEvent event)
    {
        // Not applicable
    }

    /**
    * Indicates that an item was deleted from the bound aggregate data item
    * (e. g. <TT>ArrayAccess</TT>, a JDK Collection, etc). <P>
    * A reference to the data item that was deleted, and a reference to the
    * one that lost it, can be obtained from the event. <P>
    * @param event Contains details of the deletion.
    * @see javax.infobus.DataItemChangeListener#dataItemDeleted
    */
    public final void dataItemDeleted(DataItemDeletedEvent event)
    {
        // Not applicable
    }

    /**
    * Indicates that the bound data item (and its sub-items, if any) has been
    * revoked, and is temporarily unavailable. <P>
    * A reference to the data item that was revoked can be obtained from
    * the event. <P>
    * @param event Contains details of the revoked data.
    * @see javax.infobus.DataItemChangeListener#dataItemRevoked
    */
    public final void dataItemRevoked(DataItemRevokedEvent event)
    {
        // Not applicable
    }

    /**
    * Indicates that the cursor for the bound <TT>RowsetAccess</TT> data item
    * has changed rows. <P>
    * A reference to the rowset data item can be obtained from the event. <P>
    * @param event Contains details of the cursor move.
    * @see javax.infobus.DataItemChangeListener#rowsetCursorMoved
    */
    public final void rowsetCursorMoved(RowsetCursorMovedEvent event)
    {
        // Not applicable
    }


    // ImmediateAccess Interface
    /**
    * Gets the entered text as a String. <P>
    * @return Text entered in the control
    */

    public String getValueAsString()
    {
        return (_textView.getText());
    }

    /**
    * Gets the entered text as an Object. <P>
    * @return Text entered in the control
    */
    public Object getValueAsObject()
    {
        return (_textView.getText());
    }

    /**
    * Gets the entered text as an String. <P>
    * @return Text entered in the control
    */
    public String getPresentationString(Locale locale)
    {
        // XXX
        return (_textView.getText());
    }

    /**
    *  This method is not supported and always throws an exception
    *  @exception InvalidDataException Always thrown
    */
    public void setValue(Object newValue)
        throws InvalidDataException
    {
        throw (new UnsupportedOperationException(Res.getString(Res.SETVALUE_NOT_SUPPORTED)));
    }

    // Focus Listener implementation
    /**
    * This method is an implementaion side effect
    */
    public void focusLost(FocusEvent event)
    {
    }

    /**
    * This method is an implementaion side effect
    */
    public void focusGained(FocusEvent event)
    {
        if(isFocusValidated())
        {
            NavigationManager fm = NavigationManager.getNavigationManager();
            fm.validateFocusChange(this);
        }
    }

    // ApplyEditsListener implementation
    public void applyEdits()
    {
        try
        {
            _applyEdits();
        }
        catch(InvalidDataException e)
        {
            throw new ApplyEditsValidationException(e.getMessage());
        }
    }
    
    public void cancelEdits()
    {
        if ( SwingUtilities.isEventDispatchThread())
        {
            _textView._updateValue(getDataItem());
        }
        else
        {
            _textView._updateValueNow(getDataItem());
        }
    }
    
    private void _applyEdits()
        throws InvalidDataException
    {
        Object dataItem = getDataItem();
        
        if (dataItem != null && dataItem instanceof ImmediateAccess)
        {
            ImmediateAccess ia = (ImmediateAccess)dataItem;
            String oldValue = ia.getPresentationString(Locale.getDefault());
            if(! oldValue.equals(_textView.getText()))
            {
                try
                {
                    ia.setValue(this);
                }
                catch(InvalidDataException e)
                {
                    if (_revertValueOnError)
                    {
                        _textView._updateValueLater(dataItem);
                    }
                    throw e;
                }
            }
        }
    }

    class TextAreaView
        extends JTextArea
    {

        TextAreaView()
        {
            this(6, 15);
        }

        TextAreaView(int rows, int columns)
        {
            super(rows, columns);
        }

        TextAreaView(String text)
        {
            super(text);
        }

        TextAreaView(String text, int rows, int columns)
        {
            super(text, rows, columns);
        }

        TextAreaView(Document doc)
        {
            super(doc);
        }

        TextAreaView(Document doc, String text, int rows, int columns)
        {
            super(doc, text, rows, columns);
        }

        // Private Methods

        void _updateValueLater(final Object dataItem)
        {
            SwingUtilities.invokeLater(
                                       new Runnable()
                                       {
                                           public void run()
                                               {
                                                   _updateValue(dataItem);
                                               }
                                       }
                                       );
        }

        private void _updateValueNow(final Object item)
        {
            try
            {
                SwingUtilities.invokeAndWait(
                                             new Runnable()
                                             {
                                                 public void run()
                                                     {
                                                         _updateValue(item);
                                                     }
                                             }
                                             );
            }
            catch(Exception e)
            {
            }
        }
        
        void _updateValue(Object dataItem)
        {
            String value = null;
            
            if (dataItem != null && dataItem instanceof ImmediateAccess)
            {
                Boolean updateable = null;
                
                value = ((ImmediateAccess)dataItem).getPresentationString(Locale.getDefault());

                if (dataItem instanceof DataItem)
                {
                    updateable =
                        (Boolean)((DataItem)dataItem).getProperty(DataItemProperties.UPDATEABLE);
                }
                if (updateable != null)
                {
                    // only enable the control if it is updateable
                    this.setEditable(updateable.booleanValue());
                }
            }
            this.setText((value != null) ? value.trim() : "");
        }
    }
}
