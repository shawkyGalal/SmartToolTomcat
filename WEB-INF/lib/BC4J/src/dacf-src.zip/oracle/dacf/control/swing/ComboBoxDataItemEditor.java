/*
 * @(#)ComboBoxDataItemEditor.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.dacf.control.swing;

import java.awt.Component;
import java.awt.event.ActionListener;
import java.util.Locale;
import javax.infobus.ImmediateAccess;
import javax.infobus.InvalidDataException;
import javax.infobus.UnsupportedOperationException;
import javax.swing.ComboBoxEditor;
import javax.swing.JTextField;

/**
 * ComboBoxEditor capable of editing <TT>ImmediateAccess</TT> text items.<P>
 *
 * @version INTERNAL
 */
public class ComboBoxDataItemEditor extends JTextField implements
                                                       ComboBoxEditor,
                                                       ImmediateAccess
{
  /**
   * Constructs an instance of the editor
   */
  public ComboBoxDataItemEditor()
  {

    super();
    setColumns(9);
  }

  /**
   * Get the editor component used for editing
   * @return the component
   * @see javax.swing.ComboBoxEditor#getEditorComponent
   */
  public Component getEditorComponent()
  {
        return this;
  }

    /**
     * Get the edited item
     * @return  ImmediateAccess dataItem
     * @see javax.swing.ComboBoxEditor#getItem()
     */

    public Object getItem()
    {
        return this;
    }

    /**
     * Ask the editor to start editing and select everything
     * @see javax.swing.ComboBoxEditor#getItem()
     */
    public void selectAll()
    {
        selectAll();
        requestFocus();
    }

    /**
     * Add an ActionListener
     * @param l the listener to be added
     * @see javax.swing.ComboBoxEditor#addActionListener
     */

    public void addActionListener(ActionListener l)
    {
        super.addActionListener(l);
    }


    /**
     * Add an ActionListener
     * @param l the listener to be added
     * @see javax.swing.ComboBoxEditor#addActionListener
     */
    public void removeActionListener(ActionListener l)
    {
        super.removeActionListener(l);
    }

    /**
     * Specifies the ImmediateAccess item to be edited
     * @param anObject the ImmediateAccess item to be edited
     * @see javax.swing.ComboBoxEditor#addActionListener
     */
    public void setItem(Object anObject)
    {
        String value = "";
        if(anObject != null)
        {
            if(anObject instanceof ImmediateAccess)
            {
               value = ((ImmediateAccess) anObject).
                               getPresentationString(Locale.getDefault());
            }
            else
            {
              value = anObject.toString();
            }
        }
        setText(value);
    }

    // ImmediateAccess Interface

    /**
     * Get the edited value as an String
     * @return the edited String object
     */
    public String getValueAsString()
    {
        return (getText());
    }

    /**
     * Get the edited value as an Object.
     * @return the edited object
     */
    public Object getValueAsObject()
    {
        return (getText());
    }

    /**
     * Get the edited value as an string in the given locale
     * @param the locale
     * @return the String presentation of the edited value in the given locale
     */
    public String getPresentationString(Locale locale)
    {
        return (getText());
    }

    /**
     * Editor's value can be set directly. Always throws an exeption.
     *
     * @param the new value
     * @exception InvalidDataException  Invalid data not accepted.
     */
    public void setValue(Object newValue) throws InvalidDataException
    {
        throw (new UnsupportedOperationException(Res.getString(Res.LOGIN_DIALOG_NOT_BOUND)));
    }

}


