/*
 * @(#)TreeControlBeanInfo.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.dacf.control.swing;

import java.beans.BeanInfo;
import java.beans.IntrospectionException;
import java.beans.Introspector;
import java.beans.PropertyDescriptor;

// imports
/**
 ** BeanInfo implementation for TreeControl.
 **
 ** @version SDK
 */
public class TreeControlBeanInfo
    extends ControlBeanInfoHelper
{
    private static int NAME = 0;
    private static int GETTER = 1;
    private static int SETTER = 2;
    private static int EDITOR = 3;
    
    private String [][] propertyList = new String[][] {
        {"nodeDefinitions", "getNodeDefinitions", "setNodeDefinitions",
             "oracle.jdeveloper.daceditors.TreeControlEditor"},
        {"rootNodeLabel", "getRootNodeLabel", "setRootNodeLabel",
             null },
        { "textNonSelectionColor", "getTextNonSelectionColor",
              "setTextNonSelectionColor",null },
        { "textSelectionColor", "getTextSelectionColor",
              "setTextSelectionColor",null },
        { "backgroundSelectionColor", "getBackgroundSelectionColor",
              "setBackgroundSelectionColor",null },
        { "backgroundNonSelectionColor", "getBackgroundNonSelectionColor",
              "setBackgroundNonSelectionColor",null },
        { "currentRowBackground", "getCurrentRowBackground",
              "setCurrentRowBackground",null },
        { "currentRowForeground", "getCurrentRowForeground",
              "setCurrentRowForeground",null },
        { "foreground", "getForeground",
              "setForeground",null },
        { "background", "getBackground",
              "setBackground",null },
        { "currentRowIndicated", "isCurrentRowIndicated",
              "setCurrentRowIndicated",null },
        {"selfReferential", "isSelfReferential", "setSelfReferential",
             null }
    };
    
    private static Class beanClass =
        oracle.dacf.control.swing.TreeControl.class;
    
    public TreeControlBeanInfo()
    {
        super();
    }
    
    protected Class getBeanClass()
    {
        return TreeControl.class;
    }
    
    /**
    ** Returns the property descriptors for the bean
    ** @see java.beans.BeanInfo#getPropertyDescriptors()
    */
    public PropertyDescriptor[] getPropertyDescriptors()
    {
        try
        {
            PropertyDescriptor[] pdarr =
                new PropertyDescriptor[propertyList.length];
            
            for (int i = 0 ; i < propertyList.length ; i++)
            {
                pdarr[i] = new PropertyDescriptor(propertyList[i][NAME],
                                                  beanClass,
                                                  propertyList[i][GETTER],
                                                  propertyList[i][SETTER]);
                
                if(propertyList[i][EDITOR] != null)
                {
                    try
                    {
                        pdarr[i].setPropertyEditorClass(Class.forName(propertyList[i][EDITOR]));
                    }
                    catch(ClassNotFoundException ex)
                    {
                        ex.printStackTrace(System.err);
                    }
                }
            }
            return pdarr;
        }
        catch (IntrospectionException e)
        {
            e.printStackTrace(System.err);
            return null;
        }
    }
    
    /**
    ** Returns the property descriptors for the superclass bean
    ** @see java.beans.BeanInfo#getAdditionalBeanInfo()
    */
    public BeanInfo[] getAdditionalBeanInfo()
    {
        try
        {
            BeanInfo bi = Introspector.getBeanInfo(beanClass.getSuperclass());
            BeanInfo[] biarr = {bi};
            return biarr;
        }
        catch(IntrospectionException e)
        {
            e.printStackTrace(System.err);
            return null;
        }
    }
}


