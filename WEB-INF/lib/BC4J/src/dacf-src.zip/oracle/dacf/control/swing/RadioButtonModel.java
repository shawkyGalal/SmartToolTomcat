/*
 * @(#)RadioButtonModel.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.dacf.control.swing;

/**
 *  Extension of a ButtonModel that can hold a value for determining
 *  button state. <P>
 *
 * @version SDK
 * @see javax.swing.ButtonModel
 */
public class RadioButtonModel extends CancellableButtonModelImpl
{
  private String _value ;

  /**
   * Constructs a default RadioButtonModel
   */
  public RadioButtonModel()
  {
    this(null);
  }

  /**
   * Constructs a RadioButtonModel with the given value
   * @param value Value to be used for determining the state of this model
   */
  public RadioButtonModel(String value)
  {
     _value = value;
  }

  /**
   * Gets the value used this model to determine the selection state
   * @return the value used this model to determine the selection state
   */
  public String getValue()
  {
    return _value;
  }

  /**
   * Sets the value to be used to determine the selection state of this model
   * @param value the value used this model to determine the selection state
   */

  public void setValue(String value)
  {
     _value = value;
  }

}

