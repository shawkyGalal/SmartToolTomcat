/*
 * @(#)RadioGroup.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.dacf.control.swing;

import java.util.Locale;
import javax.infobus.DataItem;
import javax.infobus.DataItemAddedEvent;
import javax.infobus.DataItemChangeListener;
import javax.infobus.DataItemChangeManager;
import javax.infobus.DataItemDeletedEvent;
import javax.infobus.DataItemRevokedEvent;
import javax.infobus.DataItemValueChangedEvent;
import javax.infobus.ImmediateAccess;
import javax.infobus.InvalidDataException;
import javax.infobus.RowsetCursorMovedEvent;
import javax.swing.AbstractButton;
import javax.swing.ButtonGroup;
import javax.swing.ButtonModel;
import oracle.dacf.control.NavigationManager;
import oracle.dacf.dataset.DataItemProperties;

/**
 * This class is used to provide the multiple exclusion behaviour for a set
 * of radio button models. RadioGroup works with a RadioPanelControl to
 * ensure that a selection request is always validated before changing
 * the state of a radio button model to selected. <P>
 *
 * @version SDK
 */
public class RadioGroup
    extends ButtonGroup
    implements DataItemChangeListener
{
    private  ImmediateAccess _dataItem;
    private RadioPanelControl _radioControl;
    boolean _updatingSelection;

    /**
    * Construcor
    * 
    * @param radioControl to add
    */
    public RadioGroup(RadioPanelControl radioControl)
    {
        _radioControl = radioControl;
    }

    /**
    * set selected state
    *
    * @param model    data model for the button
    * @param selected boolean value to indicate if the button is selected
    */
    public void setSelected(ButtonModel model, boolean selected)
    {
        boolean updateIt = true;
        
        // Do not validate if this is a dataItem driven change
        if (!_canChangeSelection())
            return;


        if (!_updatingSelection && selected &&
            (model instanceof RadioButtonModel))
        {
            Object item = ((RadioButtonModel) model).getValue();
            if (_dataItem != null)
            {
                try
                {
                    NavigationManager nm =
                        NavigationManager.getNavigationManager();
                        
                    nm.focusedIsInvalid(true);
                    //Update bound item to new value
                    _dataItem.setValue(item);
                    nm.focusedIsInvalid(false);
                }
                catch(InvalidDataException e)
                {
                    updateIt = false;
                    // e.printStackTrace(System.err);
                }
            }
        }
        if (updateIt)
        {
            super.setSelected(model, selected);
        }
    }

    /**
    * set the data item 
    *
    * @param dataitem data item
    */
    public void setDataItem(Object dataItem)
    {
        if (_dataItem != null && _dataItem instanceof DataItemChangeManager)
        {
            ((DataItemChangeManager)_dataItem).
                removeDataItemChangeListener(this);
        }

        if (dataItem != null && dataItem instanceof ImmediateAccess)
        {
            _dataItem = (ImmediateAccess)dataItem;
            if (_dataItem instanceof DataItemChangeManager)
            {
                ((DataItemChangeManager)_dataItem).
                    addDataItemChangeListener(this);
            }
            _updatingSelection = true;
            _updateSelection(_dataItem);
            _updatingSelection = false;
        }
    }


    // DataItemChangeListener implementation
    /**
    * Indicates a changed value in the bound data item. <P>
    * A reference to the data item that changed can be obtained from the
    * event. <P>
    * @param event Contains change information.
    * @see javax.infobus.DataItemChangeListener#dataItemValueChanged
    */
    public void dataItemValueChanged(DataItemValueChangedEvent e)
    {
        Object item = e.getChangedItem();

        if (item instanceof ImmediateAccess)
        {
            _updatingSelection = true;
            _updateSelection((ImmediateAccess)item);
            _updatingSelection = false;
        }
    }

    /**
    * Indicates that a new item was added to the bound aggregate data item
    * (e.g. <TT>ArrayAccess</TT>, a JDK Collection, etc). <P>
    * A reference to the data item that was added, and a reference to the one
    * that gained it, can be obtained from the event. <P>
    * @param event Contains details of the addition.
    * @see javax.infobus.DataItemChangeListener#dataItemAdded
    */
    public final void dataItemAdded(final DataItemAddedEvent e)
    {
        //Don't care
    }


    /**
    * Indicates that an item was deleted from the bound aggregate data item
    * (e. g. <TT>ArrayAccess</TT>, a JDK Collection, etc). <P>
    * A reference to the data item that was deleted, and a reference to the
    * one that lost it, can be obtained from the event. <P>
    * @param event Contains details of the deletion.
    * @see javax.infobus.DataItemChangeListener#dataItemDeleted
    */
    public final void dataItemDeleted(final DataItemDeletedEvent e)
    {
        //Don't care
    }

    /**
    * Indicates that the bound data item (and its sub-items, if any) has been
    * revoked, and is temporarily unavailable. <P>
    * A reference to the data item that was revoked can be obtained from
    * the event. <P>
    * @param event Contains details of the revoked data.
    * @see javax.infobus.DataItemChangeListener#dataItemRevoked
    */
    public final void dataItemRevoked(DataItemRevokedEvent e)
    {

        if (e.getChangedItem() == _dataItem)
            setSelected(null, true);
    }

    /**
    * Indicates that the cursor for the bound <TT>RowsetAccess</TT> data item
    * has changed rows. <P>
    * A reference to the rowset data item can be obtained from the event. <P>
    * @param event Contains details of the cursor move.
    * @see javax.infobus.DataItemChangeListener#rowsetCursorMoved
    */
    public final void rowsetCursorMoved(RowsetCursorMovedEvent e)
    {
        //Don't Care
    }

    /**
    * update the selection
    *
    * @param item immediate access item to update from
    */
    private void _updateSelection(ImmediateAccess item)
    {
        ButtonModel m;
        Boolean updateable = null;
        String value = item.getPresentationString(Locale.getDefault());
        int n = buttons.size();

        if (item instanceof DataItem)
        {
            updateable =
                (Boolean)((DataItem)item).getProperty(DataItemProperties.UPDATEABLE);
        }
        if (updateable != null)
        {
            boolean u = updateable.booleanValue();

            // Make sure to set the RadioPanelControl as not enabled
            _radioControl.setEnabled(u);
            for(int i = 0 ; i < n ; i++)
            {
                // only enable the control if it is updateable
                ((AbstractButton)buttons.elementAt(i)).setEnabled(u);
            }
        }
        
        for(int i = 0 ; i < n ; i++)
        {
            m = ((AbstractButton)buttons.elementAt(i)).getModel();
            if (m != null && m instanceof RadioButtonModel)
            {
                Object modelValue = ((RadioButtonModel)m).getValue();
                if ( modelValue != null && modelValue.equals(value))
                {
                    m.setSelected(true);
                    return;
                }
            }
        }
        // No match. No model is selected
        setSelected(null, true);
    }

    /**
    * determine if selection change can occur
    *
    * @return boolean value indicating if selection change can occur
    */
    private boolean _canChangeSelection()
    {
        if (!_updatingSelection)
            return(NavigationManager.getNavigationManager().validateFocusChange(_radioControl));
        return true;
    }
}
