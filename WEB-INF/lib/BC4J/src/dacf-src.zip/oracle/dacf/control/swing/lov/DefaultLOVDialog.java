/*
 * @(#)DefaultLOVDialog.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.dacf.control.swing.lov;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.Frame;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.TableModel;
import oracle.dacf.control.swing.GridControl;
import oracle.dacf.control.swing.find.FindItemModel;
import oracle.dacf.control.swing.lov.LOVInterface;

/**
 *  A default implementation for the LOV dialog.
 *
 *  @version Internal
 */
public class DefaultLOVDialog extends JDialog
       implements LOVDialog
{
    private LOVInterface _parent = null;
    private FindItemModel _findItemModel = null;

    private JPanel _topPanel;
    private JPanel _centerPanel;
    private JPanel _bottomPanel;

    private Dimension _preferredButtonSize = new Dimension(80,25);

    // top panel
    JLabel _labelFind = new JLabel(Res.getString(Res.FIND_LABEL_TEXT));
    JTextField _textFieldFind = new JTextField(15);
    JButton _buttonFind = new JButton(Res.getString(Res.FIND_BUTTON_TEXT));


    // middle panel
    GridControl _gridControl = new GridControl();

    // bottom panel

    // button labels
    private JButton _buttonOK = new JButton(Res.getString(Res.OK_BUTTON_TEXT));
    private JButton _buttonCancel =
        new JButton(Res.getString(Res.CANCEL_BUTTON_TEXT));
    private JButton _buttonHelp =
        new JButton(Res.getString(Res.HELP_BUTTON_TEXT));

    private LOVSelectionListener _lovSelectionListener = null;

    private ButtonListener _buttonListener = new ButtonListener();

    /**
    *  default size for our dialog
    */
    static private Dimension _defaultDialogSize = new Dimension(650, 300);


    public DefaultLOVDialog()
    {
        this(null);
    }

    public DefaultLOVDialog(String title)
    {
        super(new Frame(), title, true);
        this.setSize(_defaultDialogSize);
        _setLocationToDefault();
        _initPanels();
        ListSelectionModel lsm = _gridControl.getTable().getSelectionModel();
        _gridControl.setForceReadOnly(true);
        _gridControl.setFocusValidated(false);
    }


    public void setTitle(String title)
    {
        super.setTitle(title);
    }

    /**
    *  get title for the dialog
    *  @return title for the dialog
    */
    public String getTitle()
    {
        return super.getTitle();
    }


    /**
    *  specify the LOVInterface which uses this dialog
    */
    public void setParent(LOVInterface lov)
    {
        _parent = lov;
    }

    /**
    * specify FindItemModel
    */
    public void setFindItemModel(FindItemModel findItemModel)
    {
        _findItemModel = findItemModel;
        if ( _textFieldFind != null )
        {
            Object val = findItemModel.getItemValue();
            if ( val != null )
                _textFieldFind.setText(val.toString());
        }
        if (_labelFind != null)
        {
            String label = findItemModel.getColumnDisplayName();
            _labelFind.setText(label);
        }
    }

    /**
    *   display the dialog.
    */
    public void show()
    {
        getContentPane().removeAll();
        _addChildPanels();
        Dimension size = getSize();
        this.setSize(size.width+1, size.height);
        super.show();
    }


    /**
    * display the dialog.
    *
    * @param initialValue to be displayed
    */
    public void show(Object intitalValue)
    {
        this.show();
    }


    /**
    *   pass through to JDialog's setSize;
    *
    *  @param w  width
    *  @param h  height
    */
    public void setSize(int w, int h)
    {
        super.setSize(w, h);
    }

    /**
    * set the data item name for the ScrollableRowset interface.
    * The LOV dialog should make use of the ScrollableRowsetAccess to
    * display the data values.
    *
    * @param dataItemName  name of the data item
    */
    public void setDataItemName(String dataItemName)
    {
        _gridControl.setDataItemName(dataItemName);
    }

    /**
    *  get the name of the data item currently in use
    *
    *  @return name of the data item currently in use
    */
    public String getDataItemName()
    {
        return _gridControl.getDataItemName();
    }


    // Selection related
    /**
    *  define a selection Listener
    */
    public void setSelectionListener(LOVSelectionListener listener)
    {
        _lovSelectionListener = listener;
    }

    private void _initPanels()
    {
        _topPanel = _initTopPanel();
        _centerPanel = _initCenterPanel();
        _bottomPanel = _initBottomPanel();

        getContentPane().setLayout(new BorderLayout(10,5));
    }

    private JPanel _initTopPanel()
    {
        JPanel topPanel = new JPanel();
        topPanel.setLayout( new BorderLayout(5,5));
        topPanel.add(_labelFind, BorderLayout.WEST);
        topPanel.add(_buttonFind, BorderLayout.EAST);
        topPanel.add(_textFieldFind, BorderLayout.CENTER);
        _labelFind.setBorder(BorderFactory.createEmptyBorder(3,10,3,3));
        return topPanel;
    }

    public JPanel _initCenterPanel()
    {
        JPanel centerPanel = new JPanel();
        centerPanel.setLayout( new BorderLayout());
        centerPanel.add(_gridControl, BorderLayout.CENTER);
        return centerPanel;
    }

    public JPanel _initBottomPanel()
    {
        JPanel bottomPanel = new JPanel();


        // button mnemonics
        _buttonOK.setMnemonic((char) Res.getString(Res.OK_BUTTON_MNEMONIC).charAt(0));
        _buttonCancel.setMnemonic((char) Res.getString(Res.CANCEL_BUTTON_MNEMONIC).charAt(0));
        _buttonHelp.setMnemonic((char) Res.getString(Res.HELP_BUTTON_MNEMONIC).charAt(0));
        _buttonFind.setMnemonic((Res.getString(Res.FIND_BUTTON_MNEMONIC)).charAt(0));

        // default button handling
        //_buttonOK.setDefaultCapable(true);
        getRootPane().setDefaultButton(_buttonOK);

        // set buttons to consistent size
        _buttonOK.setPreferredSize(_preferredButtonSize);
        _buttonCancel.setPreferredSize(_preferredButtonSize);
        _buttonHelp.setPreferredSize(_preferredButtonSize);
        _buttonFind.setPreferredSize(_preferredButtonSize);

        bottomPanel.add(_buttonOK);
        bottomPanel.add(_buttonCancel);
        bottomPanel.add(_buttonHelp);
        _buttonOK.addActionListener(_buttonListener);
        _buttonCancel.addActionListener(_buttonListener);
        _buttonFind.addActionListener(_buttonListener);
        _buttonHelp.addActionListener(_buttonListener);
        return bottomPanel;
    }

    private void _addChildPanels()
    {
        getContentPane().add(_topPanel, BorderLayout.NORTH);
        getContentPane().add(_centerPanel, BorderLayout.CENTER);
        getContentPane().add(_bottomPanel, BorderLayout.SOUTH);
    }

    private void _doButtonOK()
    {
        JTable gridTable = _gridControl.getTable();
        if ( gridTable.getSelectedRow() != -1)
            _fireLOVSelectionEvent(gridTable.getSelectedRow());
        setVisible(false);

    }

    private void _doButtonFind()
    {
        if ((_parent != null) && (_findItemModel != null))
        {
            _findItemModel.setItemValue(_textFieldFind.getText());
            _parent.runQuery(false);
        }
    }

    private void _doButtonHelp()
    {
        _displayMessageDialog(Res.getString(Res.LOV_DIALOG_HELP_TEXT),
                              JOptionPane.INFORMATION_MESSAGE);
    }

    private void _displayMessageDialog(String message, int style)
    {
        JPanel helpPanel = new JPanel(new BorderLayout(), false);
        JTextArea area = new JTextArea(message, 6, 40);
        area.setLineWrap(true);
        area.setWrapStyleWord(true);
        area.setEditable(false);
        helpPanel.add(new JScrollPane(area),
                      BorderLayout.CENTER);
        JOptionPane.showMessageDialog(null,
                                      helpPanel,
                                      getTitle(),
                                      style);
    }

    /**
    * get default location for the dialog. The default location will be the
    * center of the screen
    *
    */
    private void  _setLocationToDefault()
    {

        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
        Dimension dlgSize = this.getSize();
        if (dlgSize.height > screenSize.height)
            dlgSize.height = screenSize.height;
        if (dlgSize.width > dlgSize.width)
            dlgSize.width = screenSize.width;
        setLocation( (screenSize.width - dlgSize.width)/2,
                     (screenSize.height - dlgSize.height)/2);
    }

    private void _fireLOVSelectionEvent(int rowIndex)
    {
        TableModel model = _gridControl.getModel();
        Object[] columnValues = new Object[model.getColumnCount()];
        for ( int i = 0 ; i < model.getColumnCount(); i++)
            columnValues[i] = model.getValueAt(rowIndex, i);
        LOVSelectionEvent evt = new LOVSelectionEvent(this,columnValues );
        _lovSelectionListener.itemSelected( evt );
    }

    class ButtonListener implements ActionListener
    {
        public ButtonListener()
        {
        }
        public void actionPerformed(ActionEvent e)
        {
            Object src = e.getSource();
            if ( src == _buttonOK )
                _doButtonOK();
            else if ( src == _buttonCancel )
                setVisible(false);
            else if ( src == _buttonFind )
                _doButtonFind();
            else if ( src == _buttonHelp )
                _doButtonHelp();

        }
    }

    class GridSelectionListener implements ListSelectionListener
    {
        public GridSelectionListener()
        {
            System.out.println("grid sel list");
        }

        public void valueChanged(ListSelectionEvent e)
        {
            ListSelectionModel lsm = (ListSelectionModel)e.getSource();
            System.out.println("gvalue changed");
            if ( !lsm.isSelectionEmpty())
            {
                int selectedRow = lsm.getMinSelectionIndex();
                _fireLOVSelectionEvent(selectedRow);
            }

        }

    }

}
