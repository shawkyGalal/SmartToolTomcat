/*
 * @(#)NavigationBarButtonClickListener.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.dacf.control.swing;

import java.util.EventListener;

/**
 * Defines the interface for receiving button click events from the
 * NavigationBar
 *
 * @version SDK
 */
public interface NavigationBarButtonClickListener extends EventListener
{
    /*
     * Notification from the source that a navigation button was clicked
     */
    void navigationBarButtonClicked(NavigationBarButtonClickEvent event)
        throws NavigationBarButtonClickVetoException ;
}
