/*
 * @(#)DacFindPanelUIAdapter.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.dacf.control.swing.find;

import oracle.dacf.control.swing.FindPanel;

/**
 *  The DacFindPanelUIAdapter is an adapter class for the DacFindPanelUI 
 *  interface.
 *
 *  @version   INTERNAL
 *  @see       DacFindPanelUI
 *  @see       FindPanel
 */
public class DacFindPanelUIAdapter implements DacFindPanelUIListener
{
   /**
   * A notification that the Find button was clicked.
   */
   public void findButtonClicked()
   {
   }

   /**
   * A notification that the Close button was clicked.
   */
   public void closeButtonClicked()
   {
   }

   /**
   * A notification that the Reset button was clicked.
   */
   public void resetButtonClicked()
   {
   }

   /**
   *  A notification that the help button was clicked.
   */
   public void helpButtonClicked()
   {
   }

   /**
   * A notification that the OR button was clicked
   */
   public void orButtonClicked()
   {
   }

   /**
   * A notification that the Remove button was clicked
   */
   public void removeButtonClicked()
   {
   }

   /**
   * A notification that the Remove All button was clicked
   */
   public void removeAllButtonClicked()
   {
   }
}
