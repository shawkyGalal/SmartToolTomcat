/*
 * @(#)CheckBoxControl.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.dacf.control.swing;

import java.awt.Color;
import java.awt.Component;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.util.Locale;
import javax.infobus.DataItem;
import javax.infobus.DataItemAddedEvent;
import javax.infobus.DataItemChangeListener;
import javax.infobus.DataItemDeletedEvent;
import javax.infobus.DataItemRevokedEvent;
import javax.infobus.DataItemValueChangedEvent;
import javax.infobus.ImmediateAccess;
import javax.infobus.InvalidDataException;
import javax.infobus.RowsetCursorMovedEvent;
import javax.swing.BorderFactory;
import javax.swing.ButtonModel;
import javax.swing.Icon;
import javax.swing.JCheckBox;
import javax.swing.JTable;
import javax.swing.UIManager;
import javax.swing.table.TableCellRenderer;
import oracle.dacf.control.Control;
import oracle.dacf.control.ControlEnabledListener;
import oracle.dacf.control.ControlSupport;
import oracle.dacf.control.InfoBusManager;
import oracle.dacf.control.InfoBusManagerListener;
import oracle.dacf.control.InfoBusManagerReleaseEvent;
import oracle.dacf.control.NavigatedEvent;
import oracle.dacf.control.NavigatedListener;
import oracle.dacf.control.NavigatingEvent;
import oracle.dacf.control.NavigatingException;
import oracle.dacf.control.NavigatingListener;
import oracle.dacf.control.NavigationManager;
import oracle.dacf.dataset.DataItemProperties;

/**
 * A data aware checkbox control. Checkbox can be bound to infobus
 * <TT>ImmediateAccess</TT> item.
 *
 * @version PUBLIC
 */
public class CheckBoxControl
    extends JCheckBox
    implements Control, ControlEnabledListener, TableCellRenderer,
               InfoBusManagerListener
{
    /**
    *  If both 'selectionValue' and 'deselectionValue' property are
    *  set, the 'mode' property indicates whether the selectionValue or
    *  the 'deselectionValue' property should be used to enable/disable
    *  the checkbox.
    *
    * <BR> The constants below constants define possible values for
    * 'mode' property.
    *
    * @see setMode
    */

    /**
    * When mode property is set to this value the 'selectionValue' property
    * will be used to enable/disable the checkbox
    */
    public static final int USE_SELECTION_VALUE = 0;

    /**
    * When mode property is set to this value the 'deselectionValue' property
    * will be used to enable/disable the checkbox
    */
    public static final int USE_DESELECTION_VALUE=1;

    private ControlSupport _controlSupport;
    private String _selectionValue ;
    private String _deselectionValue ;
    private boolean _updatingValue = false;
    private boolean _DEBUG = false;
    private SelectionValidator _selectionValidator = new SelectionValidator();
    private ValueUpdater _valueUpdater = new ValueUpdater();
    private CancellableButtonModel _model;

    // We need a place to store the color the JLabel should be returned
    // to after its foreground and background colors have been set
    // to the selection background color.
    // These ivars will be made protected when their names are finalized.
    private Color unselectedForeground;
    private Color unselectedBackground;

    private int _mode = USE_SELECTION_VALUE;

    /**
    *  Constructs a deselected CheckBoxControl.
    */
    public CheckBoxControl()
    {
        this("", null, false);
    }

    /**
    * Creates an initially unselected CheckboxControl with an icon.
    *
    * @param icon  the Icon image to display
    */
    public CheckBoxControl(Icon icon)
    {
        this(null, icon, false);
    }

    /**
    * Creates a CheckboxControl with an icon and specifies whether
    * or not it is initially selected.
    *
    * @param icon  the Icon image to display
    * @param selected a boolean value indicating the initial selection
    *        state. If <code>true</code> the checkbox is selected
    */
    public CheckBoxControl(Icon icon, boolean selected)
    {
        this(null, icon, selected);
    }

    /**
    * Creates an initially unselected CheckboxControl with text.
    *
    * @param text the text of the checkbox.
    */
    public CheckBoxControl (String text)
    {
        this(text, null, false);
    }

    /**
    * Creates a CheckboxControl with text and specifies whether
    * or not it is initially selected.
    *
    * @param text the text of the checkbox.
    * @param selected a boolean value indicating the initial selection
    *        state. If <code>true</code> the checkbox is selected
    */
    public CheckBoxControl(String text, boolean selected)
    {
        this(text, null, selected);
    }

    /**
    * Creates an initially unselected CheckboxControl with
    * the specified text and icon.
    *
    * @param text the text of the checkbox.
    * @param icon  the Icon image to display
    */
    public CheckBoxControl(String text, Icon icon)
    {
        this(text, icon, false);
    }

    /**
    * Creates a Checkbox control with text, icon,
    * and specifies whether or not it is initially selected.
    *
    * @param text the text of the checkbox.
    * @param icon  the Icon image to display
    * @param selected a boolean value indicating the initial selection
    *        state. If <code>true</code> the checkbox is selected
    */
    public CheckBoxControl( String text, Icon icon, boolean selected)
    {
        super(text, icon, selected);
        _controlSupport = new ControlSupport(this);
        _controlSupport.addControlEnabledListener(this);
        InfoBusManager.getInstance().addInfoBusManagerListener(this);
    }

    /**
    *  Called by the constructor to create the CancellableButtonModel to be
    *  used by this checkbox. Default implementation constructs an instance
    *  CancellableButtonModelImpl. </P>
    *  @return  instance of ButtonModelSupport
    */
    protected CancellableButtonModel createButtonModel()
    {
        return (new CancellableButtonModelImpl());
    }

    /**
    * specify if the 'selectionValue' or the 'deselectionValue' property
    * should be used to disable/enable the checkbox
    *
    * <BR>
    * The following values can be used
    *
    * <UL>
    * <LI> USE_SELECTION_VALUE - if the 'selectionValue' should be used
    * <LI> USE_DESELECTION_VALUE - if the 'deselectionValue' should be used
    * </UL>
    *
    * @param nuMode new mode
    */
    public void setMode(int nuMode)
    {
        if (( nuMode == USE_SELECTION_VALUE) ||
                                          (nuMode == USE_DESELECTION_VALUE))
        {
            _mode = nuMode;
            _updateValue(getDataItem());
        }
        else
            throw new IllegalArgumentException();
    }

    /**
    * get the current mode used by the checkbox
    *
    * @return the current mode
    */
    public int getMode()
    {
       return _mode;
    }

    /**
    * set the string which should enable the check box when the value equals
    * that of the dataitem.
    *
    * @param selectionValue string specifying selection value
    */
    public void setSelectionValue(String selectionValue)
    {
        _selectionValue = selectionValue;
    }

    /**
    * get the selection string
    *
    * @return selection string
    */
    public String getSelectionValue()
    {
        return  _selectionValue;
    }


    /**
    * set the string which should disbable the check box when the value equals
    * that of the dataitem.
    *
    * @param DeselectionValue string specifying deselection value
    */
    public void setDeselectionValue(String deselectionValue)
    {
        _deselectionValue = deselectionValue;
    }

    /**
    * get the deselection string
    *
    * @return deselection string
    */
    public String getDeselectionValue()
    {
        return  _deselectionValue;
    }


    // ControlEnabledListener interface
    public void enabledChanged(boolean b)
    {
        super.setEnabled(b);
    }

    // InfoBusManagerListener interface implementation
    public void releaseResources(InfoBusManagerReleaseEvent e)
    {
        if (e.appliesTo(this))
        {
            ButtonModel model = getModel();
            
            if (model != null && model instanceof CancellableButtonModel)
            {
                ((CancellableButtonModel)model).removeSelectionChangingListener(_selectionValidator);
                ((CancellableButtonModel)model).removeItemListener(_valueUpdater);

            }
            InfoBusManager.getInstance().removeInfoBusManagerListener(this);
            _controlSupport.removeControlEnabledListener(this);
            _controlSupport = null;
        }
    }

    // Control Interface

    /**
    ** An override of java.awt.Component.setEnabled. <P>
    **
    ** @param b boolean flag indicating whether the control is enabled
    */
    public void setEnabled(boolean b)
    {
        super.setEnabled(b);
        if (_controlSupport != null)
        {
            _controlSupport.setEnabled(b);
        }
    } // setEnabled

    /**
    * Returns the name of the InfoBus this control is connected to. <P>
    * Most controls should delegate this method to <TT>ControlSupport</TT>. <P>
    * @return  The name of the InfoBus this control is connected to.
    * @see ControlSupport#getInfoBusName
    */
    public final String getInfoBusName()
    {
        return(_controlSupport == null ?
               null : _controlSupport.getInfoBusName());
    }

    /**
    * Sets the name of the InfoBus this control is connected to. <P>
    * If the named InfoBus does not exist, it is created automatically. <P>
    * If the control is already connected to an InfoBus, it is disconnected
    * first. <P>
    * Most controls should delegate this method to <TT>ControlSupport</TT>. <P>
    * @param infoBusName   The name of the InfoBus to connect to.
    * @see ControlSupport#setInfoBusName
    */
    public final void setInfoBusName(String infoBusName)
    {
        if (_controlSupport != null)
        {
            _controlSupport.setInfoBusName(infoBusName);
        }
    }

    /**
    * Returns the name of the InfoBus DataItem this control is bound to. <P>
    * Most controls should delegate this method to <TT>ControlSupport</TT>. <P>
    * @return  The name of the InfoBus DataItem this control is bound to,
    *          or <TT>null</TT> if the control is unbound.
    * @see #getDataItem
    * @see ControlSupport#getDataItemName
    */
    public final String getDataItemName()
    {
        return(_controlSupport == null ?
               null : _controlSupport.getDataItemName());
    }

    /**
    * Sets the name of the InfoBus DataItem this control is bound to. <P>
    * The DataItem with the given name is searched for on the InfoBus, and
    * if found, is bound to this control. <P>
    * If the control is already bound to a DataItem, it is unbound first. <P>
    * Most controls should delegate this method to <TT>ControlSupport</TT>. <P>
    * @param dataItemName  The name of the DataItem to bind to.
    * @see #getDataItem
    * @see ControlSupport#setDataItemName
    */
    public final void setDataItemName(String dataItemName)
    {
        _model = createButtonModel();
        _setModel(_model);
        if (_controlSupport != null)
        {
            _controlSupport.setDataItemName(dataItemName);
        }
    }


    /**
    * Returns the InfoBus DataItem this control is bound to. <P>
    * Most controls should delegate this method to <TT>ControlSupport</TT>. <P>
    * @return  The InfoBus DataItem this control is bound to, or
    *          <TT>null</TT> if the control is unbound.
    * @see ControlSupport#getDataItem
    */
    public final Object getDataItem()
    {
        return(_controlSupport == null ?
               null : _controlSupport.getDataItem());
    }

    /**
    * Notifies the control that the bound InfoBus DataItem has changed. <P>
    * The control can safely ignore this notification. <P>
    * @param oldDataItem   The formerly bound DataItem (can be <TT>null</TT>).
    * @param newDataItem   The newly bound DataItem (can be <TT>null</TT>).
    */
    public final void dataItemChanged(Object oldDataItem, Object newDataItem)
    {
        _updateValue(newDataItem);
    }

    /**
    * Returns the AWT component associated with this control. <P>
    * @return  The AWT component for this control.
    */
    public final Component getComponent()
    {
        return(this);
    }

    /**
    * Determines whether focus into this control causes validation to
    * occur. <P>
    * Most controls should delegate this method to <TT>ControlSupport</TT>. <P>
    * @return  <TT>true</TT> if focus into this control causes validation to
    *          occur, <TT>false</TT> otherwise.
    * @see ControlSupport#isFocusValidated
    */
    public final boolean isFocusValidated()
    {
        return(_controlSupport == null ?
               false : _controlSupport.isFocusValidated());
    }

    /**
    * Sets whether focus into this control causes validation to occur. <P>
    * Most controls should delegate this method to <TT>ControlSupport</TT>. <P>
    * @param focusValidated    If <TT>true</TT>, focus into this control will
    *                          cause validation to occur.
    * @see ControlSupport#setFocusValidated
    */
    public final void setFocusValidated(boolean focusValidated)
    {
        if (_controlSupport != null)
        {
            _controlSupport.setFocusValidated(focusValidated);
        }
    }

    /**
    * Adds a navigated listener to this control. <P>
    * The listener will be notified of NavigateIn and NavigateOut events. <P>
    * Most controls should delegate this method to <TT>ControlSupport</TT>. <P>
    * @param listener  The listener to add.
    * @see ControlSupport#addNavigatedListener
    */
    public final void addNavigatedListener(NavigatedListener listener)
    {
        if (_controlSupport != null)
        {
            _controlSupport.addNavigatedListener(listener);
        }
    }

    /**
    * Removes a navigated listener from this control. <P>
    * Most controls should delegate this method to <TT>ControlSupport</TT>. <P>
    * @param listener  The listener to remove.
    * @see ControlSupport#removeNavigatedListener
    */
    public final void removeNavigatedListener(NavigatedListener listener)
    {
        if (_controlSupport != null)
        {
            _controlSupport.removeNavigatedListener(listener);
        }
    }

    /**
    * Processes a navigated event for this control. <P>
    * This method is for use by the NavigationManager only. <P>
    * Most controls should delegate this method to <TT>ControlSupport</TT>. <P>
    * @param event The navigated event.
    * @see ControlSupport#processNavigatedEvent
    */
    public final void processNavigatedEvent(NavigatedEvent event)
    {
        if (_controlSupport != null)
        {
            _controlSupport.processNavigatedEvent(event);
        }
    }

    /**
    * Adds a navigating listener to this control. <P>
    * The listener will be notified of NavigateIn and NavigateOut events. <P>
    * Most controls should delegate this method to <TT>ControlSupport</TT>. <P>
    * @param listener  The listener to add.
    * @see ControlSupport#addNavigatedListener
    */
    public final void addNavigatingListener(NavigatingListener listener)
    {
        if (_controlSupport != null)
        {
            _controlSupport.addNavigatingListener(listener);
        }
    }

    /**
    * Removes a navigating listener from this control. <P>
    * Most controls should delegate this method to <TT>ControlSupport</TT>. <P>
    * @param listener  The listener to remove.
    * @see ControlSupport#removeNavigatedListener
    */
    public final void removeNavigatingListener(NavigatingListener listener)
    {
        if (_controlSupport != null)
        {
            _controlSupport.removeNavigatingListener(listener);
        }
    }

    /**
    * Processes a navigating event for this control. <P>
    * This method is for use by the NavigatedManager only. <P>
    * Most controls should delegate this method to <TT>ControlSupport</TT>. <P>
    * @param event The navigating event.
    * @exception NavigatingException   If the navigation is redirected to a
    *                                  different control.
    * @see ControlSupport#processNavigatedEvent
    */
    public final void processNavigatingEvent(NavigatingEvent event)
        throws NavigatingException
    {
        if (_controlSupport != null)
        {
            _controlSupport.processNavigatingEvent(event);
        }
    }


    // DataItemChangeListener Interface

    /**
    * Indicates a changed value in the bound data item. <P>
    * A reference to the data item that changed can be obtained from the
    * event. <P>
    * @param event Contains change information.
    * @see javax.infobus.DataItemChangeListener#dataItemValueChanged
    */
    public final void dataItemValueChanged(DataItemValueChangedEvent event)
    {
        _updateValue(event.getChangedItem());
    }

    /**
    * Indicates that a new item was added to the bound aggregate data item
    * (e.g. <TT>ArrayAccess</TT>, a JDK Collection, etc). <P>
    * A reference to the data item that was added, and a reference to the one
    * that gained it, can be obtained from the event. <P>
    * @param event Contains details of the addition.
    * @see javax.infobus.DataItemChangeListener#dataItemAdded
    */
    public final void dataItemAdded(DataItemAddedEvent event)
    {
        // Not applicable
    }


    /**
    * Indicates that an item was deleted from the bound aggregate data item
    * (e. g. <TT>ArrayAccess</TT>, a JDK Collection, etc). <P>
    * A reference to the data item that was deleted, and a reference to the
    * one that lost it, can be obtained from the event. <P>
    * @param event Contains details of the deletion.
    * @see javax.infobus.DataItemChangeListener#dataItemDeleted
    */
    public final void dataItemDeleted(DataItemDeletedEvent event)
    {
        // Not applicable
    }

    /**
    * Indicates that the bound data item (and its sub-items, if any) has been
    * revoked, and is temporarily unavailable. <P>
    * A reference to the data item that was revoked can be obtained from
    * the event. <P>
    * @param event Contains details of the revoked data.
    * @see javax.infobus.DataItemChangeListener#dataItemRevoked
    */
    public final void dataItemRevoked(DataItemRevokedEvent event)
    {

    }

    /**
    * Indicates that the cursor for the bound <TT>RowsetAccess</TT> data item
    * has changed rows. <P>
    * A reference to the rowset data item can be obtained from the event. <P>
    * @param event Contains details of the cursor move.
    * @see javax.infobus.DataItemChangeListener#rowsetCursorMoved
    */
    public final void rowsetCursorMoved(RowsetCursorMovedEvent event)
    {
        // Not applicable
    }

    // Implements javax.swing.table.TableCellRenderer

    /**
    * Used internally by a JTable to render a cell.  Should not be called directly.
    * has changed rows. <P>
    * A reference to the rowset data item can be obtained from the event. <P>
    * @param event Contains details of the cursor move.
    * @see javax.swing.table.TableCellRenderer#getTableCellRendererComponent
    */
    public Component getTableCellRendererComponent(JTable table, Object value,
                                                   boolean isSelected, boolean hasFocus, int row, int column)
    {
        if (hasFocus)
        {
            setBorder( UIManager.getBorder("Table.focusCellHighlightBorder") );
            if (table.isCellEditable(row, column))
            {
                super.setForeground( UIManager.getColor("Table.focusCellForeground") );
                super.setBackground( UIManager.getColor("Table.focusCellBackground") );
            }
        }
        else
        {
            setBorder(BorderFactory.createEmptyBorder(1, 2, 1, 2));
        }

        if (isSelected)
        {
            super.setForeground(table.getSelectionForeground());
            super.setBackground(table.getSelectionBackground());
        }
        else
        {
            super.setForeground((unselectedForeground != null) ? unselectedForeground
                                : table.getForeground());
            super.setBackground((unselectedBackground != null) ? unselectedBackground
                                : table.getBackground());
        }

        setFont(table.getFont());

        _valueUpdater.setDirty(false);
        _selectionValidator.setEnabled(false);
        setValue(value);
        _valueUpdater.setDirty(true);
        _selectionValidator.setEnabled(true);

        return this;
    }


    protected void setValue(Object value)
    {
        Object v = getSelectionValue();

        if (v != null && (v.equals(value.toString()) || v.toString().equals(value.toString())))
            setSelected(true);
        else
            setSelected(false);

    }

    /**
    * Overrides <code>JComponent.setForeground</code> to specify
    * the unselected-foreground color using the specified color.
    */
    public void setForeground(Color c) {
        super.setForeground(c);
        unselectedForeground = c;
    }

    /**
    * Overrides <code>JComponent.setForeground</code> to specify
    * the unselected-background color using the specified color.
    */
    public void setBackground(Color c) {
        super.setBackground(c);
        unselectedBackground = c;
    }

    /**
    * Notification from the UIManager that the L&F has changed.
    * Replaces the current UI object with the latest version from the
    * UIManager.
    *
    * @see JComponent#updateUI
    */
    public void updateUI()
    {
        super.updateUI();
        setForeground(null);
        setBackground(null);
    }

    /**
    * Specify the cancellable button model
    *
    * @param model cancellable button model
    */
    void _setModel(CancellableButtonModel model)
    {
        CancellableButtonModel oldModel = _model;
        if (oldModel != null)
        {
            oldModel.removeSelectionChangingListener(_selectionValidator);
            oldModel.removeItemListener(_valueUpdater);
        }
        _model = model;
        if (model != null)
        {
            model.addSelectionChangingListener(_selectionValidator);
            model.addItemListener(_valueUpdater);

        }
        super.setModel(_model);
    }


    /**
    * update the checkbox based on the updated value from the data item
    *
    * @param dataitem to which this control is bound to
    */
    private void _updateValue(Object dataItem)
    {
        if (dataItem != null && dataItem instanceof ImmediateAccess)
        {
            Boolean updateable = null;

            if (dataItem instanceof DataItem)
            {
                updateable =
                    (Boolean)((DataItem)dataItem).getProperty(DataItemProperties.UPDATEABLE);
            }

            // Notify
            _valueUpdater.setDirty(false);
            _selectionValidator.setEnabled(false);

            String s = ((ImmediateAccess) dataItem).
                getPresentationString(Locale.getDefault());
            Object v = null;

            if (getMode() == USE_SELECTION_VALUE)
            {
                v = getSelectionValue();
                if ( v != null )
                {
                    if (v.equals(s) || v.toString().equals(s))
                        setSelected(true);
                    else
                        setSelected(false);
                }
            }
            else
            {
                v = getDeselectionValue();
                if ( v != null )
                {
                    if (v.equals(s) || v.toString().equals(s))
                        setSelected(false);
                    else
                        setSelected(true);
                }
            }

            _selectionValidator.setEnabled(true);
            _valueUpdater.setDirty(true);
            if (updateable != null)
            {
                if (isEnabled())
                    setEnabled(updateable.booleanValue());
            }
        }
    }

    private void _setCheckBox(Object v, Object s)
    {
        if (v.equals(s) || v.toString().equals(s))
            setSelected(true);
        else
            setSelected(false);
    }


    private class SelectionValidator
        implements SelectionChangingListener
    {
        private boolean _enabled = true;
        public void selectionChanging(SelectionChangingEvent e)
            throws ChangeVetoException
        {
            Control c = CheckBoxControl.this;
            if (isEnabled())
            {
                if (!NavigationManager.getNavigationManager().validateFocusChange(c))
                    throw new ChangeVetoException("");
            }
        }

        void setEnabled(boolean enabled)
        {
            _enabled = enabled;
        }

        boolean isEnabled()
        {
            return _enabled;
        }
    }

    private class ValueUpdater implements ItemListener
    {
        private boolean _dirty = true;

        void setDirty(boolean dirty)
        {
            _dirty = dirty;
        }

        boolean isDirty()
        {
            return _dirty;
        }

        /**
        * Notification from the UI about the change in selection.
        *
        */
        public void itemStateChanged(ItemEvent e)
        {
            if (isDirty())
            {
                CheckBoxControl c =  CheckBoxControl.this;
                Object newValue;
                _debug("ValueUpdater  " + e) ;
                if (e.getStateChange() == ItemEvent.SELECTED)
                    newValue = c.getSelectionValue();
                else if (e.getStateChange() == ItemEvent.DESELECTED)
                    newValue = c.getDeselectionValue() ;
                else
                    return;

                Object o = getDataItem();
                if (o != null && o instanceof ImmediateAccess)
                {
                    try
                    {
                        NavigationManager nm =
                            NavigationManager.getNavigationManager();

                        nm.focusedIsInvalid(true);
                        ((ImmediateAccess)o).setValue(newValue);
                        nm.focusedIsInvalid(false);
                    }
                    catch(InvalidDataException ex)
                    {
                        _updateValue(getDataItem());
                    }
                }
            }
        }
    }

    private void _debug(String msg)
    {
        if (_DEBUG)
        {
            System.out.println(msg);
        }
    }
}
