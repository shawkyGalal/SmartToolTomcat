/*
 * @(#)ChartControlBeanInfo.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.dacf.control.tdg;

import java.beans.PropertyDescriptor;
import oracle.dacf.control.swing.ControlBeanInfoHelper;

/**
 * bean info class for the Chart control
 *
 * @version SDK
 */
public class ChartControlBeanInfo extends ControlBeanInfoHelper
{
    /**
    * Constructor
    */
    public ChartControlBeanInfo()
    {
        super();
    }

    /**
    * get the Class object for the bean described by this beaninfo class
    *
    * @return the Class object for the bean
    */
    protected Class getBeanClass()
    {
        return oracle.dacf.control.tdg.ChartControl.class;
    }

    /**
    * get property descriptors specific to the combo box
    *
    * @return property descriptors for the combo box
    */
    protected PropertyDescriptor[] getAdditionalPropertyDescriptors()
    {
        try
        {
            Class cls;
            
            PropertyDescriptor rowLabelDataItemName=
                new PropertyDescriptor("rowLabelDataItemName",
                                       getBeanClass(),
                                       "getRowLabelDataItemName",
                                       "setRowLabelDataItemName");

            PropertyDescriptor columnLabelDataItemName=
                new PropertyDescriptor("columnLabelDataItemName",
                                       getBeanClass(),
                                       "getColumnLabelDataItemName",
                                       "setColumnLabelDataItemName");

            PropertyDescriptor graphSeriesOrder=
                new PropertyDescriptor("graphSeriesOrder",
                                       getBeanClass(),
                                       "getGraphSeriesOrder",
                                       "setGraphSeriesOrder");

            try
            {
                cls = Class.forName("oracle.jdeveloper.daceditors.ChartLabelDataItemNameEditor");
            }
            catch(ClassNotFoundException e)
            {
                cls = null;
            }
            rowLabelDataItemName.setPropertyEditorClass(cls);

            try
            {
                cls = Class.forName("oracle.jdeveloper.daceditors.ChartLabelDataItemNameEditor");
            }
            catch(ClassNotFoundException e)
            {
                cls = null;
            }
            columnLabelDataItemName.setPropertyEditorClass(cls);

            try
            {
                cls = Class.forName("oracle.jdeveloper.daceditors.GraphSeriesTypeEditor");
            }
            catch(ClassNotFoundException e)
            {
                cls = null;
            }
            graphSeriesOrder.setPropertyEditorClass(cls);

            PropertyDescriptor graphType =
                new PropertyDescriptor("graphType", getBeanClass(),
                                       "getGraphType", "setGraphType");

            try
            {
                cls = Class.forName("oracle.jdeveloper.daceditors.ChartGraphTypeEditor");
            }
            catch(ClassNotFoundException e)
            {
                cls = null;
            }
            graphType.setPropertyEditorClass(cls);


            PropertyDescriptor[] ret = { rowLabelDataItemName,
                                         columnLabelDataItemName,
                                         graphSeriesOrder, graphType};
            return ret;
        }
        catch (Exception exc)
        {
            return null;
        }
    }

}
