/*
 * @(#)FindItemModel.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.dacf.control.swing.find;

/**
 *  FindItemModel serves as a model for FindAction object. The value
 *  returned by getItemValue will be used to build the WHERE clause.
 *  The model further provides information about the SQL type.
 *
 *  @version    INTERNAL
 *  @see        FindAction
 *
 */
public interface FindItemModel
{
    /**
    *  value to be used in building the WHERE clause
    *
    *  @return value to be used in the WHERE clause
    */
    public Object getItemValue();

    /**
    *  specify the value to be used in the WHERE clause
    *
    *  @param value
    */
    public void setItemValue(Object value);

    /**
    * get the column name
    *
    * @return name of the column to use in the query
    */
    public String getColumnName();

    /**
    * get SQL type for this column
    *
    */
    public int getSQLType();

    /**
    * get column name for display purpose.
    */
    public String getColumnDisplayName();

    /**
    *  return the format string used. ( Special case used
    *  in association with Date datatype)
    */
    public String getFormatString();

    /**
    *  return the SQL format string used (for ex., in TO_DATE function)
    *
    */
    public String getSQLFormatString();

}
