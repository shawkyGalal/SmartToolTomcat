/*
 * @(#)InfoBusManager.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.dacf.control;

import java.awt.Container;
import java.util.Vector;

// imports
/**
 **      The InfoBusManager serves to track active controls.  The primary
 **      purpose is so that controls can be notified when they are about to be
 **      destroy so that they can disconnect from the InfoBus and perform any
 **      other cleanup tasks and thus avoid any memory leaks due to zombie
 **      objects.
 **
 */
public class InfoBusManager
{
    private static InfoBusManager _sManager;
    private Vector _listeners;
    private static final boolean _DEBUG = true;

    /**
    ** InfoBusManager is implemented as a singleton and cannot be
    ** instantiated directly. Clients must use the getInfoBusManager()
    ** method to get an instance</P>
    **
    ** @see InfoBusManager#getInfoBusManager()
    */
    protected InfoBusManager()
    {
        _listeners = new Vector(3);
    } // InfoBusManager

    /**
    **  Register a InfoBusManagerListener with the InfoBusManager
    */
    public void addInfoBusManagerListener(InfoBusManagerListener l)
    {
        _listeners.addElement(l);
    } // setControl
    
    /**
    **  Rremove a InfoBusManagerListener from the InfoBusManager
    */
    public void removeInfoBusManagerListener(InfoBusManagerListener l)
    {
        _listeners.removeElement(l);
    } // getControl
    
    /**
    * Gets an instance of the InfoBusManager. <P>
    * @return  the InfoBusManager
    */
    public static InfoBusManager getInstance()
    {
        if (_sManager == null)
        {
            _sManager = new InfoBusManager();
        }

        return(_sManager);
    }

    public void fireReleaseResources(Object src, Container c)
    {
        InfoBusManagerReleaseEvent e =
            new InfoBusManagerReleaseEvent(src, c);
        InfoBusManagerListener[] listeners =
            getInfoBusManagerListeners();

        for(int i = 0; i < listeners.length; i++)
        {
            listeners[i].releaseResources(e);
        }
    }

    /**
    **  Returns all the registered InfoBusManagerListeners
    **
    ** @return an array of the registered InfoBusManagerListeners.
    */
    protected InfoBusManagerListener[] getInfoBusManagerListeners()
    {
        InfoBusManagerListener[] listeners = null;

        synchronized(_listeners)
        {
            int nListeners = _listeners.size();
            listeners = new InfoBusManagerListener[nListeners];
            _listeners.copyInto(listeners);
        }
        return(listeners);
    } // getInfoBusManagerListeners

    private void _debug(String s)
    {
        if (_DEBUG)
        {
            System.out.println("InfoBusManager: " + s);
        }        
    } // _debug
    
}  // InfoBusManager

