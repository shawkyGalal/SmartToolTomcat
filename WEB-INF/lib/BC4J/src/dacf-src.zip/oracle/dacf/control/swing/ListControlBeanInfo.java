/*
 * @(#)ListControlBeanInfo.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.dacf.control.swing;

import java.beans.PropertyDescriptor;

/**
 * bean info class for the list control
 *
 * @version SDK
 */
public class ListControlBeanInfo extends ControlBeanInfoHelper
{
  /**
  * Constructor
  */
  public ListControlBeanInfo()
  {
     super();
  }

  /**
  * get the Class object for the bean described by this beaninfo class
  *
  * @return the Class object for the bean
  */
  protected Class getBeanClass()
  {
    return ListControl.class;
  }

  /**
  * get property descriptors for the bean
  *
  * @return PropertyDescriptors specific to this bean
  */
   protected PropertyDescriptor[] getAdditionalPropertyDescriptors()
   {
      try
      {
         // begin exposed JList Properties

         PropertyDescriptor  cellRenderer  =
         new PropertyDescriptor("cellRenderer", getBeanClass(),
                                "getCellRenderer", "setCellRenderer");


         PropertyDescriptor  fixedCellHeight  =
         new PropertyDescriptor("fixedCellHeight", getBeanClass(),
                                "getFixedCellHeight", "setFixedCellHeight");
         

         PropertyDescriptor fixedCellWidth  =
         new PropertyDescriptor("fixedCellWidth", getBeanClass(),
                                "getFixedCellWidth", "setFixedCellWidth");


         PropertyDescriptor model   =
         new PropertyDescriptor("model", getBeanClass(),
                                "getModel", "setModel");


         PropertyDescriptor  prototypeCellValue  =
         new PropertyDescriptor("prototypeCellValue", getBeanClass(),
                                "getPrototypeCellValue", "setPrototypeCellValue");


         PropertyDescriptor selectedIndex   =
         new PropertyDescriptor("selectedIndex", getBeanClass(),
                                "getSelectedIndex", "setSelectedIndex");


         PropertyDescriptor selectedIndices   =
         new PropertyDescriptor("selectedIndices", getBeanClass(),
                                "getSelectedIndices", "setSelectedIndices");


         PropertyDescriptor  selectionBackground  =
         new PropertyDescriptor("selectionBackground", getBeanClass(),
                                "getSelectionBackground", "setSelectionBackground");


         PropertyDescriptor  selectionForeground  =
         new PropertyDescriptor("selectionForeground", getBeanClass(),
                                "getSelectionForeground", "setSelectionForeground");

         
         PropertyDescriptor selectionMode   =
         new PropertyDescriptor("selectionMode", getBeanClass(),
                                "getSelectionMode", "setSelectionMode");


         PropertyDescriptor selectionModel   =
         new PropertyDescriptor("selectionModel", getBeanClass(),
                                "getSelectionModel", "setSelectionModel");


         PropertyDescriptor  valueIsAdjusting  =
         new PropertyDescriptor("valueIsAdjusting", getBeanClass(),
                                "getValueIsAdjusting", "setValueIsAdjusting");


         PropertyDescriptor  visibleRowCount  =
         new PropertyDescriptor("visibleRowCount", getBeanClass(),
                                "getVisibleRowCount", "setVisibleRowCount");

         // end exposed JList Properties


         PropertyDescriptor dataItemNameForUpdate  =
         new PropertyDescriptor("dataItemNameForUpdate", getBeanClass(),
                                "getDataItemNameForUpdate", "setDataItemNameForUpdate");

         dataItemNameForUpdate.setPropertyEditorClass(getDataItemNameEditorClass());

         PropertyDescriptor dataItemUsageMode  =
         new PropertyDescriptor("dataItemUsageMode", getBeanClass(),
                                "getDataItemUsageMode", "setDataItemUsageMode");

         dataItemUsageMode.setPropertyEditorClass(Class.forName("oracle.jdeveloper.daceditors.DataItemUsageModeEditor"));


         PropertyDescriptor[] ret = { cellRenderer, fixedCellHeight, fixedCellWidth,
                                      model, prototypeCellValue, selectedIndex, selectedIndices,
                                      selectionBackground, selectionForeground, selectionMode,
                                      selectionModel, valueIsAdjusting, visibleRowCount,
                                      dataItemNameForUpdate, dataItemUsageMode};
         return ret;
      }
      catch (Exception exc)
      {
         System.out.println("Exception "+exc);
         return null;
      }
   }
}
