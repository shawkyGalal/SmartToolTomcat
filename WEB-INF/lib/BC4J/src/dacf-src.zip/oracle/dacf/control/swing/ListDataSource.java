/*
 * @(#)ListDataSource.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.dacf.control.swing;

import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.lang.Exception;
import javax.infobus.ImmediateAccess;
import javax.infobus.InfoBusItemRevokedEvent;
import javax.swing.JList;
import javax.swing.ListModel;
import javax.swing.ListSelectionModel;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import oracle.dacf.control.DualBindingControl;
import oracle.dacf.control.NavigationManager;

/**
 *  ListDataSource provides a JFC's ListModel implementation which gets
 *  its items from a infobus <TT>ScrollableRowsetAccess</TT>.<P>
 *  ListDataSource binds itself to the given column
 *  in a <TT>ScrollableRowsetAccess</TT> dataItem and provides a read-only
 *  access to all the column values. <P>
 *  ListDataSource works with a JList. It listens on the JList's
 *  selection model and keeps the list selection and
 *  <TT>ScrollableRowsetAccess</TT> currency in sync. <P>
 *
 * @version SDK
 */
public class ListDataSource
    extends ColumnModelSupport
    implements ListSelectionListener, PropertyChangeListener
{

    private static boolean _DEBUG = false;
    private JList _list ;
    private ListControl _listBox;
    private ImmediateAccess _selectedItem;


    /**
    * Constructs a default ListDataSource for the given list
    */
    public ListDataSource(JList list, ListControl control)
    {
        super(control);
        list.addPropertyChangeListener(this);
        list.getSelectionModel().addListSelectionListener(this);
        _list = list;
        _listBox = control;
    }


    /**
    *  Called when JList's selectionModel changes.
    */
    public void propertyChange(PropertyChangeEvent e)
    {
        if (e.getPropertyName().equals("ancestor"))
        {
            // the data has just become available, set the selection
            selectionChanged(_selectedItem);
        }
        else if (e.getPropertyName().equals("selectionModel"))
        {
            Object newModel = e.getNewValue();
            Object oldModel = e.getOldValue();

            if (oldModel != null &&
                oldModel instanceof ListSelectionModel)
            {
                ((ListSelectionModel)oldModel).removeListSelectionListener(this);
            }

            if (newModel != null &&
                newModel instanceof ListSelectionModel)
            {
                ((ListSelectionModel)newModel).addListSelectionListener(this);
            }
        }
    }

    /**
    * This method is called by the <TT>InfoBus</TT> class on behalf of a data
    * producer that is revoking the availability of a previously announced
    * data item. <P>
    * @param event The event.
    */
    public void dataItemRevoked(InfoBusItemRevokedEvent event)
    {
       // handled by Navigation Control support
    }



    //ListSelectionListener Interface

    /**
    *  Notification from a ListSelectionModel about the change
    *  in a selection.
    *  @param ListSelectionEvent event describing the change
    */
    public void valueChanged(ListSelectionEvent event)
    {
        if ((_selectedItem != null) && (null !=_list) && (null != _listBox) &&
            (_listBox.getDataItemUsageMode() == DualBindingControl.FOR_UPDATE))
        {
            // we are changing values

            Object source = event.getSource();
            if (source instanceof SingleSelector)
            {
                if (((SingleSelector)source).isSetSelectionInterval())
                {
                    return;
                }
            }
            try
            {
                if (_list.getSelectedValue() != null)
                {
                    NavigationManager nm =
                        NavigationManager.getNavigationManager();

                    nm.focusedIsInvalid(true);
                    _selectedItem.setValue(_list.getSelectedValue());
                    nm.focusedIsInvalid(false);
                }
            }
            catch(Exception e)
            {
                // debug("RowsetValidationException "+ e);
            }
            fireContentsChanged(this, -1, -1);
        }
        else
        {
            // we are navigating
            if (!event.getValueIsAdjusting())
            {
                int selectedIndex = _list.getSelectedIndex();
                if (selectedIndex != getSelection())
                {
                    // move the rowset cursor to this index
                    setSelection(selectedIndex);

                    // make sure that the selection is visible
                    _list.ensureIndexIsVisible(selectedIndex);
                }
            }
        }
    }

    /**
    * notification that the selected item changed
    *
    * @param oldDataItem old data item
    * @param newDataItem new data item
    */
    void _selectedItemChanged(Object oldDataItem, Object newDataItem)
    {

        if (newDataItem == null)
        {
            _selectedItem = null;
        }
        else if (newDataItem instanceof ImmediateAccess)
        {
            _selectedItem = (ImmediateAccess)newDataItem;
        }
        fireContentsChanged(this, -1, -1);
    }

    /**
    * get index of the object from the model
    *
    * @param anObject    get index of this object
    * @param listModel   search here
    */
    private int _getIndex(Object anObject, ListModel listModel)
    {
        if ((anObject != null) && (listModel != null) &&
            (anObject instanceof ImmediateAccess))
        {
            ImmediateAccess comparer;
            String value;
            ImmediateAccess comparee = (ImmediateAccess)anObject;
            String reference = comparee.getValueAsString();
            int _size = listModel.getSize();

            for(int i = 0; i < _size; i++)
            {
                comparer = (ImmediateAccess)getElementAt(i);
                value = comparer != null ? comparer.getValueAsString() : null;
                if (value != null && value.equals(reference))
                {
                    return i;
                }
            }
        }
        return -1;
    }

    /**
    *  Notification from a ListSelectionModel about the change
    *  in a selection.Used when it is thie to update
    *  @param ListSelectionEvent event describing the change
    */
    public void selectionChanged(Object anObject)
    {

        if ((_selectedItem != null) && (anObject != null) &&
            (anObject instanceof ImmediateAccess))
        {
            ImmediateAccess accessObject = (ImmediateAccess)anObject;
            int _newIndex = _getIndex(accessObject, this);

            if (_newIndex >=0)
            {
                _list.setSelectedIndex(_newIndex);
                _list.ensureIndexIsVisible(_newIndex);
                fireContentsChanged(this, _newIndex, _newIndex);
            }
            else
            {
                _list.clearSelection();
            }
        }
    }

    /**
    * obtain a string representation
    *
    * @return a string representation
    */
    public String toString()
    {
        return(getClass().getName());
    }

    /**
    * get the value of the data item as a string
    *
    * @param newDataItem data item whose string value has to be obtained
    * @return string value of the data item
    */
    public String getName(Object newDataItem)
    {
        if (newDataItem instanceof ImmediateAccess)
        {
            if (newDataItem != null)
            {
                return ((ImmediateAccess)newDataItem).getValueAsString();
            }
        }
        return "";
    }

    /**
    * debug message
    *
    * @param msg debug message
    */
    private void _debug(String msg)
    {
        if (_DEBUG)
        {
            System.out.println("ListDataSource: " + msg) ;
        }
    }
}


