/*
 * @(#)CachedImmediateAccess.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.dacf.control.swing;

import java.util.Locale;
import javax.infobus.ImmediateAccess;
import javax.infobus.InvalidDataException;

class CachedImmediateAccess 
	implements ImmediateAccess 
{
	// an atribute value could be null., therefore maintain an auxillary
	// flag to indicate if the value was already cached., 
	boolean _bObjectValueCached = false; 
	Object _value = null;
	String _valueAsString = null;
	String _presString = null;
	static final String _emptyString = "";
	Locale _locale = null;


	ImmediateAccess _ia = null;

	public CachedImmediateAccess(ImmediateAccess ia)
	{
		_ia = ia;
	}

	protected ImmediateAccess getWrappedIA()
	{
		return _ia;
	}

	public String getValueAsString()
	{
		if (_valueAsString == null)
		{
			if (_ia != null)
			{
				_valueAsString = _ia.getValueAsString();
			}
			else
				return _emptyString;
		}
		return _valueAsString;
	}

	public Object getValueAsObject()
	{
		if (!_bObjectValueCached)
		{
			_bObjectValueCached = true;
			
			if (_ia == null) 
			{
				_value = null;
			}
			else
			    _value = _ia.getValueAsObject();
		}
		return _value;

	}

	public String getPresentationString(Locale locale)
	{
		boolean bRefresh = false;

		if (_locale != locale)
		{
			_locale = locale;
			bRefresh = true;
		}

		if ((bRefresh ) || (_presString == null))
		{
			if (_ia != null )
				_presString = _ia.getPresentationString(_locale);
			else
				_presString = _emptyString;
		}

		return _presString;
	}

	public void setValue(Object newValue)
	   throws InvalidDataException
	{

		_ia.setValue(newValue);
	}

	public void releaseResources()
	{
		clear();
		_ia = null;
	}

	public void markDirty()
	{
		clear();
	}

	private void clear()
	{
		_value = null;
		_valueAsString = null;
		_presString = null;
		_locale = null;
		_bObjectValueCached = false;
	}

	public String toString()
	{
		StringBuffer s = new StringBuffer();
		s.append("ValueAsString : " + getValueAsString());
		return s.toString();
	}

	public boolean equals(Object o)
	{
		if (this == o)
			return true;

		if (o instanceof ImmediateAccess)
		{
			String s = getValueAsString();
			if (s != null)
			{
				boolean b = s.equals( ((ImmediateAccess)o).getValueAsString());
				return b;
			}
		}
		return false;
	}
}

