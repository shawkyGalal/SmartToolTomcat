/*
 * @(#)MappedComboBoxDataSource.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.dacf.control.swing;

import javax.infobus.DataItemValueChangedEvent;
import javax.infobus.RowsetCursorMovedEvent;
import oracle.dacf.control.DualBindingControl;

/**
 * ComboBox datasource. Provides mapping support
 *
 * @version Internal
 * @see ComboBoxDataSource
 */
public class MappedComboBoxDataSource
    extends ComboBoxDataSource
{

    /**
    * Constructor
    *
    * @param comboBox a handle to the parent control
    */
    public MappedComboBoxDataSource(ComboBoxControl comboBox)
    {
        this(comboBox, null);
    }

    /**
    * Constructor
    *
    * @param comboBox a handle to the parent control
    * @param listDataItemName data item name for the combo
    */
    public MappedComboBoxDataSource(ComboBoxControl comboBox,
                                    String listDataItemName)
    {
        super(comboBox, listDataItemName);
    }

    public void dataItemValueChanged(DataItemValueChangedEvent e)
    {
		if (_comboBox.getDataItemUsageMode() ==
			 DualBindingControl.FOR_NAVIGATION)
			clear();

        bDisableEvent = true;

        if (_isViewRefreshed(e))
           bDisableEvent = false;

        super.dataItemValueChanged(e);

        bDisableEvent = false;
    }

    public void rowsetCursorMoved(RowsetCursorMovedEvent e)
    {
        
		if (_comboBox.getDataItemUsageMode() ==
            DualBindingControl.FOR_NAVIGATION)
		{
    		clear();
			super.rowsetCursorMoved(e);
		}
		else
		{
		    bDisableEvent = true;
			super.rowsetCursorMoved(e);
			bDisableEvent = false;
		}
    }

	public void available(String name, Object publishedObject)
    {
		bDisableEvent = true;
		super.available(name,publishedObject);
		bDisableEvent = false;
    }

	private void clear()
	{
		Object sel = super.getSelectedItem();
		if  ((sel != null) && (sel instanceof CachedImmediateAccess))
		{
			CachedImmediateAccess cia = (CachedImmediateAccess)sel;
			cia.markDirty();
		}
	}
}


