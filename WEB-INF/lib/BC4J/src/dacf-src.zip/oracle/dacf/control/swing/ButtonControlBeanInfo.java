/*
 * @(#)ButtonControlBeanInfo.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.dacf.control.swing;


/**
 * bean info class for the button control
 *
 * @version SDK
 */
public class ButtonControlBeanInfo extends ControlBeanInfoHelper
{
  /**
  * Constructor
  */
  public ButtonControlBeanInfo()
  {
     super();
  }

  /**
  * get the bean class object for the bean
  *
  * @return bean class for the bean
  */
  protected Class getBeanClass()
  {
    return ButtonControl.class;
  }

}
