/*
 * @(#)ChartLabelTableColumnValues.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.dacf.control.tdg.chart;

import javax.infobus.DataItemAddedEvent;
import javax.infobus.DataItemChangeListener;
import javax.infobus.DataItemChangeManager;
import javax.infobus.DataItemDeletedEvent;
import javax.infobus.DataItemRevokedEvent;
import javax.infobus.DataItemValueChangedEvent;
import javax.infobus.RowsetCursorMovedEvent;
import javax.infobus.ArrayAccess;
import javax.infobus.DataItem;
import javax.infobus.DataItemChangeListener;
import javax.infobus.DataItemView;
import javax.infobus.ImmediateAccess;
import javax.infobus.RowsetAccess;
import javax.infobus.ScrollableRowsetAccess;
import oracle.dacf.dataset.DataItemProperties;
import oracle.dacf.dataset.InfoObject;

/**
 * chart labels derived from column names of the table
 */
class ChartLabelTableColumnValues extends ChartLabelDataSourceImpl implements DataItemChangeListener
{
    private int     _colIndex = -1;
    private String  _columnName = null;
    private String  _rowsetItemName = null;
    private String  _columnItemName = null;

    ChartLabelTableColumnValues(ChartDataSource parent)
    {
       super(parent);
    }

    public void setDataItemName(String dataItemName)
    {
       _columnItemName = dataItemName;
       _bind(dataItemName);

       DataItem di = (DataItem)getDataItem();
       if ((di !=null) && ( di instanceof RowsetAccess))
       {
          RowsetAccess rs = (RowsetAccess)di;
          _colIndex = _getColumnIndex(rs);
          _updateLables(rs);
       }
       if ( di instanceof DataItemChangeManager)
             ((DataItemChangeManager)di).addDataItemChangeListener(this);
    }

    public String getDataItemName()
    {
        return _columnItemName;
    }

    public void dataItemPublished()
    {
        super.dataItemPublished();
        DataItem di = (DataItem)getDataItem();
        if ((di !=null) && ( di instanceof RowsetAccess))
        {

           RowsetAccess rs = (RowsetAccess)di;
           _colIndex = _getColumnIndex(rs);
           _updateLables(rs);
        }
        if ( di instanceof DataItemChangeManager)
             ((DataItemChangeManager)di).addDataItemChangeListener(this);
    }

   private void _bind(String dataItemName)
   {
      if (dataItemName != null)
      {
         int i = dataItemName.lastIndexOf(InfoObject.ITEMNAME_DELIMITER);
         if (i > 0)
         {
            _columnName = dataItemName.substring(i+1);
            _rowsetItemName = dataItemName.substring(0, i);
            super.setDataItemName(_rowsetItemName);
         }
      }
      else
      {
         _columnName = null;
         _rowsetItemName = null;
      }
   }

   private void _updateLables(Object dataItem)
   {
      if (dataItem != null)
      {
           int rowCount= -1;
           if (dataItem instanceof ScrollableRowsetAccess)
           {
               ScrollableRowsetAccess rs = (ScrollableRowsetAccess)dataItem;
               rowCount = rs.getRowCount();
           }

           if (dataItem instanceof DataItemView)
           {
              DataItemView view = (DataItemView)dataItem;
              if ((_colIndex != -1) && ( rowCount > 0))
              {
                  setLabels(_getColumnValues(view, rowCount, _colIndex));
                  updateChart();
              }
           }
      }
   }

   private int _getColumnIndex(RowsetAccess rowset)
   {
      if (rowset != null  && _columnName != null)
      {
         int n = rowset.getColumnCount();
         for (int i = 0 ; i < n ; i++)
         {
            try
            {
                Object colItem = rowset.getColumnItem(i+1);
                if ( colItem != null )
                {
                    if ( colItem instanceof ImmediateAccess)
                    {
                        String name =(String)((DataItem)colItem).getProperty(
                                     DataItemProperties.NAME);

                        if ((name !=null) && (name.equals(getDataItemName())))
                            return i;
                    }
                }
            }
            catch(Exception exc)
            {
            }
         }

      }
      return -1;
   }

   private Object[] _getColumnValues(DataItemView view, int rowCount,
                                                                int colIndex)
   {
       if ( view instanceof ScrollableRowsetAccess)
       {
          ScrollableRowsetAccess rsAccess = (ScrollableRowsetAccess) view;
          int rc = rsAccess.getRowCount();
          if ( rc >= 1)
             rsAccess.setBufferSize(rc);
       }

       ArrayAccess access = view.getView(rowCount);
       Object[] labels = new Object[rowCount];
       int coord[] = null;
       for (int i=0; i < rowCount; i++)
       {
          coord = new int[]{ i, colIndex};
          Object item = access.getItemByCoordinates(coord);
          if ((item != null) &&  (item instanceof ImmediateAccess))
              labels[i] = ((ImmediateAccess)item).getValueAsObject();

          if (labels[i] == null)
             labels[i] = "";
       }
       return labels;
   }

   // DataItemChangeListener Interface

    /**
    * Indicates a changed value in the bound data item. <P>
    * A reference to the data item that changed can be obtained from the
    * event. <P>
    * @param event Contains change information.
    * @see javax.infobus.DataItemChangeListener#dataItemValueChanged
    */
    public final void dataItemValueChanged(DataItemValueChangedEvent event)
    {
         if (event.getChangedItem() instanceof RowsetAccess)
         {
             RowsetAccess rs = (RowsetAccess) event.getChangedItem();
            _updateLables(rs);
         }
    }

    /**
    * Indicates that a new item was added to the bound aggregate data item
    * (e.g. <TT>ArrayAccess</TT>, a JDK Collection, etc). <P>
    * A reference to the data item that was added, and a reference to the one
    * that gained it, can be obtained from the event. <P>
    * @param event Contains details of the addition.
    * @see javax.infobus.DataItemChangeListener#dataItemAdded
    */

    public final void dataItemAdded(DataItemAddedEvent event)
    {
    }

    /**
    * Indicates that an item was deleted from the bound aggregate data item
    * (e. g. <TT>ArrayAccess</TT>, a JDK Collection, etc). <P>
    * A reference to the data item that was deleted, and a reference to the
    * one that lost it, can be obtained from the event. <P>
    * @param event Contains details of the deletion.
    * @see javax.infobus.DataItemChangeListener#dataItemDeleted
    */

    public final void dataItemDeleted(DataItemDeletedEvent event)
    {
    }

    /**
    * Indicates that the bound data item (and its sub-items, if any) has been
    * revoked, and is temporarily unavailable. <P>
    * A reference to the data item that was revoked can be obtained from
    * the event. <P>
    * @param event Contains details of the revoked data.
    * @see javax.infobus.DataItemChangeListener#dataItemRevoked
    */
    public final void dataItemRevoked(DataItemRevokedEvent event)
    {
       if (event.getChangedItem() instanceof DataItemChangeManager)
            ((DataItemChangeManager)event.getChangedItem()).
                                removeDataItemChangeListener(this);
    }

    /**
    * Indicates that the cursor for the bound <TT>RowsetAccess</TT> data item
    * has changed rows. <P>
    * A reference to the rowset data item can be obtained from the event. <P>
    * @param event Contains details of the cursor move.
    * @see javax.infobus.DataItemChangeListener#rowsetCursorMoved
    */
    public final void rowsetCursorMoved(RowsetCursorMovedEvent event)
    {
    }

 }
