/*
 * @(#)IncompleteTransactionAlertImpl.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.dacf.control;

import java.awt.Dimension;
import javax.swing.JOptionPane;

/**
 ** IncompleteTransactionAlertImpl <P>
 **
 ** @version SDK
 */
/**
 * IncompleteTransactionAlertImpl 
 *
 * Implements the InccompleteTransactionAlert interface
 */
public class IncompleteTransactionAlertImpl
       implements IncompleteTransactionAlert
{

  /**
  * Constructor
  */
  IncompleteTransactionAlertImpl()
  {
  }

  /**
  *  prompt the user to save changes. The user can either choose to
  *  1) save and exit
  *  2) do not save but exit
  *  3) don't save nor exit.
  *
  *  This method will be called  when there is a pending transaction and the
  *  caller would like to prompt the user on how to proceed
  *
  *  @param nameOfTransaction name of the transaction
  *  @return value indicating what should be done with the transaction
  *
  *          Possible return values are   SAVE_AND_EXIT, DO_NOT_SAVE_BUT_EXIT,
  *          CANCEL_SAVE_AND_EXIT
  */

  public int promptUser(boolean forceExit)
  {
    JOptionPane optPane = new JOptionPane();
    optPane.setPreferredSize(new Dimension(500,500));
    int optPaneOption = ((forceExit) ?JOptionPane.YES_NO_OPTION :
                                      JOptionPane.YES_NO_CANCEL_OPTION);
    int result = optPane.showConfirmDialog(null,  
                                           Res.getString(Res.SAVE_CHANGES_PROMPT),
                                           Res.getString(Res.SAVE_CHANGES_TITLE),
                                           optPaneOption);
    int ret = CANCEL_SAVE_AND_EXIT;
    switch (result)
    {
      case JOptionPane.YES_OPTION:
            ret = SAVE_AND_EXIT;
            break;
      case JOptionPane.NO_OPTION:
            ret = DO_NOT_SAVE_BUT_EXIT;
            break;
      case JOptionPane.CANCEL_OPTION:
      case JOptionPane.CLOSED_OPTION:
           ret = CANCEL_SAVE_AND_EXIT;
           break;
    }
    return ret;
  }
}
