/*
 * @(#)ControlSupportHC.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.dacf.control;

import java.beans.PropertyVetoException;
import java.util.Vector;
import javax.infobus.DataItem;
import javax.infobus.DataItemChangeManager;
import javax.infobus.DataItemValueChangedEvent;
import javax.infobus.InfoBus;
import javax.infobus.InfoBusDataConsumer;
import javax.infobus.InfoBusItemAvailableEvent;
import javax.infobus.InfoBusItemRevokedEvent;
import javax.infobus.InfoBusMembershipException;
import oracle.dacf.rp.Consumer;

/**
 **      A variant of ControlSupport to support controls that utilize a
 **      hierarchy of DataItems.  The assumption is that DataItem[n+1] is
 **      dependent upon DataItem[n] for all n >= 0.
 */
public class ControlSupportHC
    extends ControlSupport
    implements InfoBusDataConsumer, Consumer
{
    private static boolean _DEBUG = false;

    private Vector _dataItemNames;
    private Vector _dataItems;

    /**
    * Constructs the support object for a given data aware control. <P>
    * @param control   The data aware control.
    */
    public ControlSupportHC(Control control)
    {
        super(control);

        _dataItems = new Vector(3);
        _dataItemNames = new Vector(3);
    }

    // Public methods
    
    /**
    ** Sets the name of the InfoBus this control is connected to. <P>
    ** By default, the control is connected to the default InfoBus,
    ** named <TT>Control.DEFAULT_INFOBUS_NAME</TT>. <P>
    ** If the named InfoBus does not exist, it is created automatically. <P>
    ** If the control is already connected to an InfoBus, it is disconnected
    ** first. <P>
    ** @param infoBusName   The name of the InfoBus to connect to.
    ** @see Control#DEFAULT_INFOBUS_NAME
    ** @see Control#setInfoBusName
    */
    public synchronized void setInfoBusName(String infoBusName)
    {
        if (infoBusName == _infoBusName ||
            (infoBusName != null && infoBusName.equals(_infoBusName)))
        {
            return;
        }

        if (_infoBusName != null)
        {
            _dropInfoBus();
        }
        _infoBusName = infoBusName;

        if (infoBusName != null)
        {
            try
            {
                joinInfoBus(infoBusName);
                InfoBus infoBus = getInfoBus();
                if (infoBus == null)
                {
                    // XXX - throw exception?
                    return;
                }

                infoBus.addDataConsumer(this);

                _findAllDataItems(0);
            }
            catch (InfoBusMembershipException e)
            {
                // XXX - Do something useful here
            }
            catch (PropertyVetoException e)
            {
                // XXX - Do something useful here
            }
        }
    }


    /**
    ** Returns the name of the first InfoBus DataItem bound to this control.<P>
    ** @return  The name of the first InfoBus DataItem bound to this control,
    **          or <TT>null</TT> if the control is unbound.
    ** @see #getDataItem
    ** @see Control#getDataItemName
    */
    public String getDataItemName()
    {
        return((String)_dataItemNames.elementAt(0));
    }

    /**
    ** Returns the names of all InfoBus DataItems bound to this control.<P>
    ** @return  The names of all InfoBus DataItems bound to this control,
    **          or <TT>null</TT> if the control is unbound.
    ** @see #getDataItem
    ** @see Control#getDataItemName
    */
    public String[] getDataItemNames()
    {
        String[] n = new String[_dataItemNames.size()];
        _dataItemNames.copyInto(n);
        return(n.length > 0 ? n : null);
    }

    /**
    ** Sets the name of the first InfoBus DataItem bound to this control. <P>
    ** The DataItem with the given name is searched for on the InfoBus, and
    ** if found, is bound to this control.<P>
    ** If the control is already bound to one or more DataItems, it is first
    ** unbound to those dataitems. <P>
    ** @param dataItemName  The name of the DataItem to bind to.
    ** @see #setDataItemNames
    ** @see #getDataItemNames
    ** @see #getDataItem
    ** @see #getDataItems
    ** @see Control#setDataItemName
    */
    public synchronized void setDataItemName(String dataItemName)
    {
        // If no change
        if (dataItemName == _dataItemNames.elementAt(0))
        {
            return;
        }

        // disconnect from all dataitems
        _releaseAllDataItems(0);
        _dataItemNames.removeAllElements();

        if (dataItemName != null && (dataItemName.length() > 0))
        {
            InfoBus infoBus = getInfoBus();
            
            if (infoBus != null)
            {
                _dataItemNames.addElement(dataItemName);
                _setDataItem(0, infoBus.findDataItem(dataItemName,null,this));
            }
        }
    }

    public synchronized void setDataItemNames(String[] dataItemNames)
    {
        // disconnect from all dataitems
        _releaseAllDataItems(0);
        _dataItemNames.removeAllElements();

        if (dataItemNames != null)
        {
            for(int i = 0; i < dataItemNames.length; i++)
            {
                addDataItemName(dataItemNames[i]);
            }
        }
    }
    
    public synchronized void addDataItemNames(String[] dataItemNames)
    {
        if (dataItemNames != null)
        {
            for(int i = 0; i < dataItemNames.length; i++)
            {
                addDataItemName(dataItemNames[i]);
            }
        }
    }
    
    public synchronized void addDataItemName(String dataItemName)
    {
        if (dataItemName != null && (dataItemName.length() > 0))
        {
            InfoBus infoBus = getInfoBus();
            
            if (infoBus != null)
            {
                _setDataItem(_dataItemNames.size(),
                             infoBus.findDataItem(dataItemName,null,this));
                _dataItemNames.addElement(dataItemName); // must be last
            }
        }
    }
    
    /**
    ** Returns the first InfoBus DataItem bound to this control. <P>
    ** @return  The InfoBus DataItem bound to this control, or
    **          <TT>null</TT> if the control is unbound.
    ** @see Control#getDataItem
    */
    public final Object getDataItem()
    {
        return(_dataItems.elementAt(0));
    }

    /**
    ** Returns the InfoBus DataItem specified by name. <P>
    ** @param name the name of the requested dataitem
    ** @return  The InfoBus DataItem bound to this control, or
    **          <TT>null</TT> if the dataitem is not bound.
    ** @see Control#getDataItem
    */
    public final Object getDataItem(String name)
    {
        Object di = null;
        
        int ndx = _dataItemNames.indexOf(name);

        if (ndx >= 0 && ndx < _dataItemNames.size())
        {
            di = _dataItems.elementAt(ndx);
        }
        return(di);
    }

    /**
    ** Returns the InfoBus DataItems bound to this control. <P>
    ** @return  The InfoBus DataItems bound to this control, or
    **          <TT>null</TT> if the control is unbound.
    ** @see Control#getDataItem
    */
    public final Object[] getDataItems()
    {
        Object[] o = new Object[_dataItems.size()];
        _dataItems.copyInto(o);
        return(o.length > 0 ? o : null);
    }
    
    // InfoBusManagerListener interface implementation
    public void releaseResources(InfoBusManagerReleaseEvent e)
    {
        if (e.appliesTo(_control.getComponent()))
        {
            removeInfoBusPropertyListener(this);
            InfoBusManager.getInstance().removeInfoBusManagerListener(this);
            _dropInfoBus();
            _navigatedListeners.removeAllElements();
            _enabledListeners.removeAllElements();
            _navigatingListeners.removeAllElements();
            _control = null;
        }
    }

    // Consumer methods
    public void available(String name, Object publishedObject)
    {
        // _debug(name + " announced as available");
        if (publishedObject instanceof DataItem)
        {
            if (_dataItemNames != null)
            {
                int ndx = _dataItemNames.indexOf(name);

                if (ndx >= 0 &&
                    (ndx >= _dataItems.size() || 
                     _dataItems.elementAt(ndx) == null))
                {
                    _setDataItem(ndx, publishedObject);
                }
            }
        }
    }

    public void revoked(String name, Object publishedObject)
    {
        // _debug(name + " revoked");
        if (publishedObject instanceof DataItem)
        {
            int ndx = _dataItemNames.indexOf(name);

            if (ndx >= 0)
            {
                _releaseAllDataItems(ndx);
            }
        }
    }

    // InfoBusDataConsumer Interface

    /**
    * This method is called by the <TT>InfoBus</TT> class on behalf of a data
    * producer that is announcing the availability of a new data item by
    * name. <P>
    *
    * If the control is not currently bound to a data item, and the name of the
    * new data item matches the control's data item name, then the control is
    * bound to the new data item. <P>
    *
    * If the control is not currently bound to a data item, and the name of the
    * new data item is a prefix for the control's data item name, then the
    * InfoBus is searched for a matching data item, and the control is bound
    * to it if one is found.  For example, if the item <TT>A.B.C</TT> is
    * announced as available, and the control's data item name is set to
    * <TT>A.B.C.D.E</TT>, the control will ask the InfoBus to find the
    * data item <TT>A.B.C.D.E</TT> in response to the announcement of
    * <TT>A.B.C</TT> -- this means that producers only need to publish their
    * root prefix, and allows them to create child producers on demand. <P>
    * @param event The event.
    */
    public void dataItemAvailable(InfoBusItemAvailableEvent event)
    {
        // _debug(event.getDataItemName() + " dataItemAvailable");
        if (_dataItemNames != null)
        {
            int ndx = _dataItemNames.indexOf(event.getDataItemName());

            if (ndx >= 0 &&
                (ndx >= _dataItems.size() || 
                 _dataItems.elementAt(ndx) == null))
            {
                _setDataItem(ndx, event.requestDataItem(this, null));
            }
        }
    }

    /**
    * This method is called by the <TT>InfoBus</TT> class on behalf of a data
    * producer that is revoking the availability of a previously announced
    * data item. <P>
    * If the name of the data item in the event matches the control's data
    * item name, the control is unbound from its data item. <P>
    * @param event The event.
    */
    public void dataItemRevoked(InfoBusItemRevokedEvent event)
    {
        // _debug(event.getDataItemName() + " dataItemRevoked");
        if (_dataItemNames != null)
        {
            int ndx = _dataItemNames.indexOf(event.getDataItemName());

            if (ndx >= 0)
            {
                _releaseAllDataItems(ndx);
            }
        }
    }

    // private methods
    
    /**
    * Removes this object from its currently bound InfoBus and data item. <P>
    */
    private synchronized void _dropInfoBus()
    {
        _releaseAllDataItems(0);
        _dataItemNames.removeAllElements();
        
        InfoBus infoBus = getInfoBus();
        if (infoBus != null)
        {
            infoBus.removeDataConsumer(this);
        }

        try
        {
            leaveInfoBus();
        }
        catch(InfoBusMembershipException e)
        {
            // Ignore
        }
        catch(PropertyVetoException e)
        {
            // Ignore
        }
    }

    private void _findAllDataItems(int start)
    {
        if (_dataItemNames != null)
        {
            InfoBus infoBus = getInfoBus();
            if (infoBus != null)
            {
                String name;

                for(int i = start, lim = _dataItemNames.size(); i < lim; i++)
                {
                    name = (String)_dataItemNames.elementAt(i);
                    _setDataItem(i, infoBus.findDataItem(name, null, this));
                }
            }
        }
    }
    
    private void _releaseAllDataItems(int start)
    {
        if (_dataItemNames != null)
        {
            int nSize = _dataItemNames.size();
            int iSize = _dataItems.size();
            int lim = nSize < iSize ? nSize : iSize;
            String name;
                
            for(int i = start; i < lim; i++)
            {
                _setDataItem(i, null);
            }
        }
    }

    /**
    * Binds the control to a data item. <P>
    * If the new data item implements the <TT>DataItemChangeManager</TT>
    * interface, the control is added as a <TT>DataItemChangeListener</TT> for
    * the data item. <P>
    * The control's <TT>dataItemChanged</TT> and <TT>dataItemValueChanged</TT>
    * methods are invoked after the control has been bound to the new data
    * item. <P>
    * @param dataItem  The new data item to bind to.
    */
    private synchronized void _setDataItem(int ndx, Object dataItem)
    {
        Object oldDataItem = null;
        
        if (ndx >= _dataItems.size())
        {
            _dataItems.addElement(dataItem);
            if (dataItem instanceof DataItemChangeManager)
            {
                ((DataItemChangeManager)dataItem).addDataItemChangeListener(_control);
            }
        }
        else
        {
            oldDataItem = _dataItems.elementAt(ndx);
            if (dataItem != oldDataItem)
            {
                if (oldDataItem != null)
                {
                    if (oldDataItem instanceof DataItemChangeManager)
                    {
                        ((DataItemChangeManager)oldDataItem).removeDataItemChangeListener(_control);
                    }
                }

                _dataItems.setElementAt(dataItem, ndx);

                if (dataItem != null)
                {
                    if (dataItem instanceof DataItemChangeManager)
                    {
                        ((DataItemChangeManager)dataItem).addDataItemChangeListener(_control);
                    }
                }
            }
        }
        _control.dataItemChanged(oldDataItem, dataItem);
        _control.dataItemValueChanged(new DataItemValueChangedEvent(this, dataItem, null));
        if (oldDataItem != null)
        {
            ((DataItem)oldDataItem).release();
        }
        _updateEnabled();
    }

    private void _debug(String msg)
    {
        if (_DEBUG)
        {
            System.out.println("ControlSupportHC: " + _dataItemName + ": " +
                               msg);
        }
    }
}
