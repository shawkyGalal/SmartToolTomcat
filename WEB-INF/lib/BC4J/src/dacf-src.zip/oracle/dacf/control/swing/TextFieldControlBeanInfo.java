/*
 * @(#)TextFieldControlBeanInfo.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.dacf.control.swing;

import java.beans.PropertyDescriptor;

/**
 * bean info class for the text field control
 *
 * @version SDK
 */
public class TextFieldControlBeanInfo
    extends ControlBeanInfoHelper
{
    /**
    * Constructor
    */
    public TextFieldControlBeanInfo()
    {
        super();
    }

    /**
    * get the Class object for the bean
    *
    * @return Class object for the bean
    */
    protected Class getBeanClass()
    {
        return TextFieldControl.class;
    }

    protected PropertyDescriptor[] getAdditionalPropertyDescriptors()
    {
        try
        {
            PropertyDescriptor revertValueOnError =
                new PropertyDescriptor("revertValueOnError", getBeanClass(),
                                       "getRevertValueOnError",
                                       "setRevertValueOnError");
            PropertyDescriptor[] ret = { revertValueOnError };
            return ret;
        }
        catch (Exception exc)
        {
            exc.printStackTrace();
            return null;
        }
    }
}
