/*
 * @(#)IncompleteTransactionAlert.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.dacf.control;


/**
 ** IncompleteTransactionAlert <P>
 **
 ** @version SDK
 */
public interface IncompleteTransactionAlert
{

  /**
  *  indicate that the transaction should be saved and exit
  *
  *  @see promptUser
  */
  public static final int SAVE_AND_EXIT = 0;

  /**
  *  indicate that the transaction should not be saved but exit
  *
  *  @see promptUser
  */
  public static final int DO_NOT_SAVE_BUT_EXIT = 1;

  /**
  *  indicate that the transaction should not be saved but exit
  *
  *  @see promptUser
  */
  public static final int CANCEL_SAVE_AND_EXIT = 2;


  /**
  *  prompt the user to save changes. The user can either choose to
  *  1) save and exit
  *  2) do not save but exit
  *  3) don't save nor exit.
  *
  *  This method will be called  when there is a pending transaction and the
  *  caller would like to prompt the user on how to proceed
  *
  *  @param forceExit a true value indicates that the UI displayed should not
  *                   include UI elements which will let the user not terminate
  *                   the application. ex., do not include cancel button
  *  @return value indicating what should be done with the transaction
  *
  *          Possible return values are   SAVE_AND_EXIT, DO_NOT_SAVE_BUT_EXIT,
  *          CANCEL_SAVE_AND_EXIT
  */
   public int promptUser(boolean forceExit);
}
