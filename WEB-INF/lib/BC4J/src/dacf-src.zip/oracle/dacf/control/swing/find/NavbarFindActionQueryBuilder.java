/*
 * @(#)NavbarFindActionQueryBuilder.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.dacf.control.swing.find;

import java.sql.Types;
import oracle.dacf.control.swing.find.FindItemModel;
import oracle.dacf.util.WhereClauseBuilder;

/**
 *  Implements a query builder poicy for the NavigationBar. This class constructs
 *  query in two phases. In the first phase the query uses exact values specified
 *  for string datatypes in the query. In the second phase of query construction,
 *  wildcard characters are added to string data types.
 *
 *  @version   INTERNAL
 *  @see       FindAction
 */
public class  NavbarFindActionQueryBuilder implements FindActionQueryBuilder
{
   /**
   * get column name, SQL type and value from the FindItemModel
   */
   private FindItemModel[] _findItemModel = null;

   /**
   * internally used to decide if the query construction requires two phases or
   * one phase. If one of the column type is STRING then a two phase query
   * execution may be needed.
   */
   private boolean _canReExecuteQuery =false;

   /**
   *  Should we perform case sensitive search for Character data types ?
   */
   private boolean _isCaseSensitiveSearch = true;

   /**
   * Do we emit debug messages
   */
   private boolean _DEBUG = true;

   /**
   *  specify the model used to construct WHERE clause
   *
   *  @param model FindItem model from which column name, SQL type will be
   *               retrieved
   *
   */
   public void setFindItemModel(FindItemModel[] model)
   {
       _findItemModel = model;
   }

   /**
   *  get the model used to construct WHERE clause
   *
   *  @return the column model used
   */
   public FindItemModel[]  getFindItemModel()
   {
      return _findItemModel;
   }


   /**
   *  The query can be modified and re-executed. Return a true value
   *  if the query has to executed again
   *
   *  @return true if query has to be reexecuted
   */
   public boolean canReExecuteQuery()
   {
      return _canReExecuteQuery;
   }


   /**
   * Build the WHERE clause for the query
   *
   * @return WHERE clause for the query
   */
   public String buildQuery()
   {
      _canReExecuteQuery = _isTwoPhaseExecRequired();
      return _buildQueryCondition( (_canReExecuteQuery== true) ? false : true);
   }

   /**
   * modify the WHERE clause
   *
   * @return modified query
   */
   public String modifyQuery()
   {
      _canReExecuteQuery = false;
      return _buildQueryCondition(true);
   }

   /**
   *  set property value. This implementation is independent of any property
   *  values and therefore does not implement it.
   *
   *  @param name  of the property
   *  @param value to be used for the property
   */
   public void setProperty(String name, Object value)
   {
       if ( name.equals(FindActionQueryBuilder.CASE_SENSITIVE_SEARCH))
          if ( ( value != null)  && ( value instanceof Boolean))
             _isCaseSensitiveSearch = ((Boolean)value).booleanValue();
   }

   /**
   *  get property value
   *
   * @param name of the property
   * @param value to be used to set the property
   */
   public Object getProperty(String name)
   {
       if ( name.equals(FindActionQueryBuilder.CASE_SENSITIVE_SEARCH))
          return new Boolean(_isCaseSensitiveSearch);
       return null;
   }


   /**
   *  build the query condition
   *
   *  @param useSpecialChars - should wildcard be used in formulating the query
   *  @return the queryCondition (without WHERE )
   */
   private String _buildQueryCondition(boolean useSpecialChars)
   {
       String queryCondition = "";
       if ( _findItemModel == null )
           return "";

       boolean firstClause = true;// is this the first part in the WHERE clause
       for ( int i=0 ; i < _findItemModel.length; i++)
       {
           String queryClause = "";
           queryClause = _buildWhereClause(_findItemModel[i], useSpecialChars);
           if (!WhereClauseBuilder.isEmptyString(queryClause))
           {
               if ( firstClause)
               {
                   queryCondition = queryClause;
                   firstClause = false;
               }
               else
                   queryCondition = queryCondition + "AND" + queryClause;
           }
       }
       return queryCondition;
  }

  /**
  *  build part of the query condtition - for one column
  *
  *  @param findItemModel from which column attributes are retrieved
  *  @param useSpecialChars - should wildcard be used in formulating the query
  *
  *  @return part of the query condition for this column
  */
  private String _buildWhereClause(FindItemModel findItemModel,
                                   boolean useSpecialChars)
  {
      String whereClause = "";
      WhereClauseBuilder helper = new WhereClauseBuilder();

      if ( findItemModel != null)
      {
          int sqlType = findItemModel.getSQLType();
          String name = findItemModel.getColumnName();
          Object value = findItemModel.getItemValue();
          switch (sqlType)
          {
              case Types.DATE :
              case Types.TIME :
              case Types.TIMESTAMP :

                   whereClause = helper.buildWhereClause(name, sqlType,value,
                      useSpecialChars, findItemModel.getSQLFormatString());
                   break;

              case Types.CHAR:
              case Types.LONGVARCHAR:
              case Types.VARCHAR :

                   whereClause = helper.buildWhereClause(name, sqlType,value,
                      useSpecialChars, getProperty(CASE_SENSITIVE_SEARCH));
                   break;

              default :
                   whereClause = helper.buildWhereClause(name, sqlType,
                                     value, useSpecialChars, null);

          }
      }
      return whereClause;
  }

  /**
  *  Determines if the query needs to be executed in two phases
  *
  *  The query execution requires only one phase
  *   a) if non-string data type is specified or
  *   b) string is specified but is empty
  *   c) string is specified and it include wild card chars
  *
  * The query execution require two phase
  *   a) if string data type is specified and does not contain
  *      wild card char
  */
  private boolean _isTwoPhaseExecRequired()
  {
     boolean nonEmptyStringFound = false;
     boolean wildCharFound = false;

     for (int i=0 ; i < _findItemModel.length; i++)
     {
          int sqlType = _findItemModel[i].getSQLType();
          Object value = _findItemModel[i].getItemValue();
          if (value != null)
          {
             if(((sqlType == Types.CHAR) || (sqlType == Types.VARCHAR) ||
             (sqlType == Types.LONGVARCHAR)) &&
             (!WhereClauseBuilder.isEmptyString(value.toString())))
             {
                 nonEmptyStringFound = true;
                 if (WhereClauseBuilder.isStringWildCardSpecified(
                                                                 value.toString()))
                 {
                    wildCharFound = true;
                    break;
                 }
             }
          }
     }
     if ( nonEmptyStringFound)
        return !wildCharFound;

     return false;
  }

}
