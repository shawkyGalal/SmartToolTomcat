/*
 * @(#)LOV.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.dacf.control.swing;

import javax.infobus.ImmediateAccess;
import javax.infobus.RowsetAccess;
import javax.swing.JDialog;
import oracle.dacf.control.swing.find.FindAction;
import oracle.dacf.control.swing.find.FindItemModel;
import oracle.dacf.control.swing.find.FindItemModelImpl;
import oracle.dacf.control.swing.lov.DefaultLOVDialog;
import oracle.dacf.control.swing.lov.IBReturnItem;
import oracle.dacf.control.swing.lov.LOVDialog;
import oracle.dacf.control.swing.lov.LOVInterface;
import oracle.dacf.control.swing.lov.LOVSelectionEvent;
import oracle.dacf.control.swing.lov.LOVSelectionListener;
import oracle.dacf.control.swing.lov.ReturnItem;
import oracle.dacf.control.swing.lov.ReturnItemNameListener;
import oracle.dacf.dataset.ValidationException;

/**
 * LOV (List of values dialog)
 *
 * LOV displays a dialog which lets the user to search for a data item from a
 * list of values. The dialog displays a textfield where the end user  can
 * enter a value and click the Find button to search for it. The results of the
 * search are displayed in a Grid. The LOV can be configured to 'return values'
 * to the original FORM when the user selects a row and clicks OK.
 *
 * The LOV dialog usage requires the following attributes to be defined.
 *
 * 1) The query used in the LOV
 * 2) setting up 'return items'
 * 3) controlling when the LOV is displayed
 * 4) Setting up the LOV dialog itself
 *
 * Some of the above attributes have to be set on the LOV data producer objects
 * instead of the LOV itself.
 *
 * The LOV data producer object includes the
 *
 * a) oracle.dacf.dataset.LOVRowsetInfo - defines the query to be used by
 *                                        the LOV
 * b) oracle.dacf.dataset.LOVAttrributeInfo - represents the column objects
 *
 * The LOV itself is a DAC control and should be bound to LOVRowSetInfo. The
 * LOVRowsetInfo and LOVAttributeInfo objects respectively play the role of
 * RowsetInfo and AttributeInfo's.
 *
 * <P>
 * <B> 1. Query used in the LOV </B>
 *
 * The query used in the LOV dialog should be defined on the LOVRowsetInfo
 * object. The LOVRowsetInfo unlike RowsetInfo object are not updatable.
 * The query can be specified using the QueryInfoEditor in the design time.
 *
 * <P>
 * <B> 2. Return items </B>
 *
 * The objetive of using an LOV is to let the user search and choose a
 * value and 'return' that value to the original FORM.
 *
 * Each column (in the Grid) displayed by the LOV can be configured to
 * return value to the original FORM. The return item is specified as a
 * data item name which represents the control in the original FORM.
 *
 * Each column (in the query) is represented by LOVAttributeInfo object.
 * The LOVAttributeInfo controls different attributes of the columns,
 * including the 'return item name'.
 *
 * The LOVAttributeInfo's gets generated automatically by the QueryInfoEditor
 * when desgning the LOVRowsetInfo object.
 *
 * <P>
 * <B> 3. Displaying the LOV dialog </B>
 * The LOV's can be displayed by calling the show method in response to
 * a menu or button click.
 *
 * The DAC framework also provides support to display the LOV dialog
 * automatically in response
 * 1) changing focus to a DAC control
 * 2) in response to a validation failure
 *
 * The LOV can be associated with an AttributInfo by setting the 'LOV'
 * property. Whenever focus changes to a control bound to this AttributeInfo
 * the LOV dialog will be displayed.
 *
 * The LOV dialog will also be displayed when the validation fails in a
 * control bound to this AttributeInfo
 *
 * <B> 4. Binding the LOV </B>
 *
 *  The LOV dialog is  the UI component and should be bound to a LOVRowsetInfo.
 *
 * @version PUBLIC
 */
public class LOV implements LOVInterface,
                            LOVSelectionListener
{
    /**
     *  for ui
     */
    private LOVDialog _dlg = new DefaultLOVDialog( );

    /**
    *  return item facility
    */
    private ReturnItem _returnItem = new IBReturnItem();

    /**
    *  return item name listener - read from rowset access
    */
    private ReturnItemNameListener _returnItemNameListener =
                        new ReturnItemNameListener(_returnItem);

    /**
    *  automatic refresh enabled ?
    */
    private boolean _automaticRefresh = true;

    /**
    *  to execute query for validation
    */
    private FindAction _findAction = new FindAction();

    /**
    * Model for FindAction
    */
    private FindItemModel _findItemModel = new LOVFindItemModel();

    /**
    *
    */
    private boolean _DEBUG = true;

    /**
    *  For validation
    */
    public LOV()
    {
        _dlg.setSelectionListener(this);
        _dlg.setParent(this);
        _findAction.setFindItemModel(new FindItemModel[]{_findItemModel});
    }

    /**
    *  display the LovDialog
    */
    public void show()
    {
        if (getAutomaticRefresh())
            runQuery(false);
        _dlg.setFindItemModel(_findItemModel);
        _dlg.show();
    }

    /**
    * set the size of the LOV dialog
    *
    * @param w width of the dialog
    * @param h height of the dialog
    */
    public void setSize(int w,  int h)
    {
        _dlg.setSize(w,h);
    }

    /**
    * specify the location for the LOV dialog
    *
    * @param x position
    * @param y posotion
    */
    public void setLocation(int x,  int y)
    {
        ((JDialog)_dlg).setLocation(x,y);
    }

    /**
    * set the title for the LOV dialog
    *
    * @param dialogTitle
    */
    public void setTitle(String dialogTitle)
    {
        _dlg.setTitle(dialogTitle);
    }

    /**
    * get the dialog title
    *
    * @return dialog title
    */
    public String getTitle()
    {
      return _dlg.getTitle();
    }

    // specify data sets

    /**
    * specify a InfoBus based dataset. Specify a data item name
    *
    * @param dataItemName - data item name to bind to
    */
    public void setDataItemName(String dataItemName)
    {
        _dlg.setDataItemName(dataItemName);
        _returnItemNameListener.setDataItemName(dataItemName);
        _findAction.setDataItemName(dataItemName);
    }

    /**
    * Return the data item name to which we are currently bound to
    *
    *
    */
    public String getDataItemName()
    {
        return _dlg.getDataItemName();
    }


    /**
    *  determines if the dataset has to be Queried  before
    *  displaying the LOV
    *
    *  @param bRefresh  boolean value to indicate if refresh should occur
    *                   or not
    */
    public void setAutomaticRefresh(boolean bRefresh)
    {
       _automaticRefresh  = bRefresh;
    }

    /**
    *
    * Return if the LOV has been configured to refresh before displaying
    */
    public boolean getAutomaticRefresh()
    {
        return _automaticRefresh ;
    }

    /**
    * define a restricted query ( a column value pair)
    *
    * @param dataitemName which will be used to restrict the query
    * @param value used in building the WHERE clause
    */
    public void setRestrictedQuery(String dataItemName, Object value)
    {
       _findItemModel.setItemValue(value);
       ((LOVFindItemModel)_findItemModel).setDataItemName(dataItemName);
       _dlg.setFindItemModel(_findItemModel);
    }

    /**
    * get Restricted query in use
    *
    * @return restricted query in use
    */
    public Object getRestrictedQuery()
    {
        return ((LOVFindItemModel)_findItemModel).getDataItemName();
    }


    /**
    * run query
    *
    * @param bIgnoreQueryCondition should the WHERE clause be built
    */
    public void runQuery(boolean bIgnoreQueryCondition)
    {
        _findAction.executeQuery(bIgnoreQueryCondition);
    }


    /**
    * execute return items
    *
    * @param restrictedQuery - a query defenition, typically a
    *                          (column name, column value) pair
    */
    public void executeReturnItems()
    {
        RowsetAccess rowset = _findAction.getDataItem();
        if ( rowset.getHighWaterMark() == 1 )
        {
           int columnCount = rowset.getColumnCount();
           Object[] colVals = new Object[ columnCount];
           for ( int i=0; i < columnCount; i++)
           {
              try
              {
                  Object item = rowset.getColumnItem(i + 1);
                  if (  (item != null) && ( item instanceof ImmediateAccess))
                     colVals[i] = ((ImmediateAccess)item).getValueAsObject();
              }
              catch (Exception exc)
              {
                  colVals[i] = null;
              }
           }
           _returnValues(colVals);
        }
        else
        {
           if (_DEBUG)
           {
              String msg = "Return items : restrict the query to return one item";
              System.out.println(msg);
           }
        }
    }

    /**
    *  validate the data item.
    *
    *  Users may catch the Validation Exception and pop the
    *  LovDialog.
    *
    *   @param columnName - name of the column to validate
    *   @param value      - value to be validated
    */
    public void validate(String columnDataItemName, Object value)
        throws ValidationException
    {
        setRestrictedQuery(columnDataItemName, value);
        runQuery(false);

        RowsetAccess rowset = _findAction.getDataItem();
        if (( rowset != null) &&( rowset.getHighWaterMark() != 1 ))
        {
           String msg = Res.getString(Res.VALIDATION_FAILED) + columnDataItemName;
           throw new ValidationException(msg , 0);
        }
    }

     /*
     * LovSelectionListener Implementation
     *
     * @param evt event describing the LOV selection
     */
      public void itemSelected(LOVSelectionEvent evt)
      {
          Object[] colVals = evt.getColumnValues();
          _returnValues(colVals);
      }

      /**
      * return values to the form
      *
      * @param colVals column values to return
      */
      private void _returnValues(Object[] colVals)
      {
          for ( int i=0; i < colVals.length; i++)
          {
             if (_returnItem.getReturnItemName(i) != null )
             {
               try
               {
                _returnItem.setValue(i, colVals[i]);
               }
               catch (Exception e)
               {
                 if (_DEBUG) System.out.println("LOV : Unable to 'return items'");
               }
             }
          }
      }

}


/**
* LOV specific FindItemModel Implementation
*/
class LOVFindItemModel extends FindItemModelImpl
{
    /**
    * Constructor
    */
    LOVFindItemModel()
    {
       super();
    }

    /*
    * get the column name
    *
    * @return name of the column to use in the query
    */
    public String getColumnName()
    {
       return _getLOVForeignKeyName(_getInfoObject());
    }
}

