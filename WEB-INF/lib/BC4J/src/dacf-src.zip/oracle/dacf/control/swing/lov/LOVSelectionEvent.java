/*
 * @(#)LOVSelectionEvent.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.dacf.control.swing.lov;

import java.util.EventObject;

/**
 *  Defines the LovSelection event
 *
 *  @version SDK
 *
 */
public class LOVSelectionEvent extends EventObject
{
  private Object[] _columnValues;
    
  /**
  *  Constructor
  */
  public LOVSelectionEvent(LOVDialog src, Object[] columnValues)
  {
     super(src);
     _columnValues = columnValues;
  }

  /**
  *  Return list of column values 
  *  
  *  @return column values         
  */
  public Object[] getColumnValues()
  {
     return _columnValues;
  }

  /**
  * Return column value of particular index 
  *
  * @return column value
  */
  public Object getColumnValue(int i)
  {
    return _columnValues[i];
  }
}
