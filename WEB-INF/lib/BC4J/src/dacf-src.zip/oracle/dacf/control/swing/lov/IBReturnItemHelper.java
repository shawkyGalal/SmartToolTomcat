/*
 * @(#)IBReturnItemHelper.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.dacf.control.swing.lov;

import javax.infobus.DataItem;
import javax.infobus.ImmediateAccess;
import javax.infobus.InvalidDataException;
import oracle.dacf.control.DataItemAccessHelper;

public class IBReturnItemHelper
    extends DataItemAccessHelper
{
    /**
    * Constructor
    */
    public IBReturnItemHelper()
    {

    }

    /**
    *  specify the name of the column and its retutn value
    *
    *  String columnName     name of the column
    *  String dataItemName   name of the data item
    */

    public void setDataItemName( String dataItemName)
    {
        super.setDataItemName(dataItemName);
    }

    public String getDataItemName()
    {
        return super.getDataItemName();
    }


    /**
    * set the return value for this column
    *
    * This method will obtain the data item associated with this column
    * and set the value.
    */
    public void setValue(Object value)
        throws InvalidDataException
    {
        DataItem di = (DataItem)getDataItem();
        if ( di != null )
        {
            if ( di instanceof ImmediateAccess)
            {
                ImmediateAccess ia = (ImmediateAccess)di;
                ia.setValue(value);
            }
            else
            {
                throw new InvalidDataException(Res.getString(Res.INVALID_DATA_BINDING));
            }
        }
    }

    /**
    * get value for this column
    *
    * This method will obtain the data item associated with this column
    * and set the value.
    */
    public Object getValue()
        throws InvalidDataException
    {
        return null; // not supported
    }

    private void _debug(String s)
    {
        System.out.println(s);
    }

}



