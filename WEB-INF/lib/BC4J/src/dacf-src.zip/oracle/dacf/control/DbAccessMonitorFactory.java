/*
 * @(#)DbAccessMonitorFactory.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.dacf.control;

import java.util.Hashtable;

/**
 * This factory object keeps track of DbAccesMonitor object.
 *
 * It creates one DbAccessMonitor object for each session to track.
 * When there are multiple request to track the same session, this object returns
 * the same DbAccessMonitor object.
 *
 * @version INTERNAL
 */
public class  DbAccessMonitorFactory
{
   /**
   *  a table of DbAccessMonitor objects, one for each session we track.
   */
   static private Hashtable _monitorList = new Hashtable(3);

   private static final boolean _DEBUG = false;

   /**
   *  Constructor
   */
   private DbAccessMonitorFactory()
   {
   }

   /**
   *  clients use this method to create a DbAccessMonitor object.
   *  @param  nameOfSession - name of the session we want to track
   */
   static public DbAccessMonitor createDbAccessMonitor(String nameOfSession)
   {
      if ( _monitorList.containsKey(nameOfSession))
      {
        if (_DEBUG) System.out.println("DbAccessMonitorFactory: " +
                           nameOfSession + " found.\n");
        return (DbAccessMonitor)_monitorList.get(nameOfSession);
      }
      else
      {
          if (_DEBUG) System.out.println("DbAccessMonitorFactory: " +
                             nameOfSession + " not found; creating.\n");
          DbAccessMonitor o = new DbAccessMonitor();
          _monitorList.put(nameOfSession, o);
          o.setDataItemName(nameOfSession);
          return o;
      }
   }
}
