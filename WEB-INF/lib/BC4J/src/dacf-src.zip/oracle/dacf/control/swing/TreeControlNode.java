/*
 * @(#)TreeControlNode.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.dacf.control.swing;

import java.beans.PropertyChangeEvent;
import java.beans.PropertyVetoException;
import java.util.Enumeration;
import java.util.NoSuchElementException;
import java.util.Vector;
import javax.infobus.DataItemAddedEvent;
import javax.infobus.DataItemChangeListener;
import javax.infobus.DataItemChangeManager;
import javax.infobus.DataItemDeletedEvent;
import javax.infobus.DataItemRevokedEvent;
import javax.infobus.DataItemValueChangedEvent;
import javax.infobus.DataItemView;
import javax.infobus.ImmediateAccess;
import javax.infobus.InfoBus;
import javax.infobus.InfoBusDataConsumer;
import javax.infobus.InfoBusItemAvailableEvent;
import javax.infobus.InfoBusItemRevokedEvent;
import javax.infobus.InfoBusMembershipException;
import javax.infobus.RowsetCursorMovedEvent;
import javax.infobus.ScrollableRowsetAccess;
import javax.swing.tree.MutableTreeNode;
import javax.swing.tree.TreeNode;
import oracle.dacf.control.Control;
import oracle.dacf.control.InfoBusManagerListener;
import oracle.dacf.control.InfoBusManagerReleaseEvent;
import oracle.dacf.control.InfoBusManager;
import oracle.dacf.dataset.RowSetManager;
import oracle.dacf.util.InfoBusMemberHelper;

// imports
/**
 ** @version PUBLIC
 */
public class TreeControlNode
    extends InfoBusMemberHelper
    implements MutableTreeNode, DataItemChangeListener, InfoBusDataConsumer, InfoBusManagerListener
{
    private String _name;
    private TreeControlNode _parent;
    private Vector _kids;
    private TreeNodeData _data;
    private TreeDataSource _treeDataSource;
    private String _infoBusName = Control.DEFAULT_INFOBUS_NAME;
    private static final Object _seme = new Object();
    private static int _count = 0;
    private boolean _currentRow;
    private Object _object; // user object
    private static final boolean _DEBUG = false;

    /**
    ** An enumeration that is always empty. This is used when an enumeration
    ** of a leaf node's children is requested.
    */
    static public final Enumeration EMPTY_ENUMERATION
        = new Enumeration() {
            public boolean hasMoreElements() { return false; }
            public Object nextElement() {
                throw new NoSuchElementException("No more elements");
            }
    };


    TreeControlNode()
    {
        this(null, null, null, null);
    } // TreeControlNode

    TreeControlNode(TreeDataSource treeDataSource)
    {
        this(null, null, null, treeDataSource);
    } // TreeControlNode

    // not automatically using the TreeNodeData in the TreeNodeDef because
    // the non root nodes will use different DataItems.
    TreeControlNode(TreeControlNode parent, TreeNodeDef def,
                    ScrollableRowsetAccess sra, TreeDataSource ds)
    {
        String name;
        synchronized(_seme)
        {
            _name = "node_"+_count++;
        }
        _data = new TreeNodeData();
        _data.def = def;
        _data.details = sra;
        _parent = parent;
        setTreeDataSource(ds);
        joinInfoBusInt();
    } // TreeControlNode

    public TreeNodeData getTreeNodeData()
    {
        return(_data);
    }

    public void setTreeNodeData(TreeNodeData data)
    {
        _data = data;
    }

    public String getName()
    {
        return(_name);
    }

    public void setName(String name)
    {
        _name = name == null ? " " : name;
        if (_treeDataSource != null)
        {
            _treeDataSource.fireTreeNodeChanged(this);
        }
    }
    
    public synchronized void setInfoBusName(String infoBusName)
    {
        if (infoBusName == _infoBusName ||
            (infoBusName != null && infoBusName.equals(_infoBusName)))
        {
            return;
        }

        if (_infoBusName != null)
        {
            dropInfoBusInt();
        }
        _infoBusName = infoBusName;

        if (_infoBusName != null)
        {
            joinInfoBusInt();
            if (_kids != null)
            {
                TreeControlNode[] kids = new TreeControlNode[_kids.size()];
                _kids.copyInto(kids);
                for(int i = 0; i < kids.length; i++)
                {
                    kids[i].setInfoBusName(infoBusName);
                }
            }
        }
    }

    protected void joinInfoBusInt()
    {
        try
        {
            joinInfoBus(_infoBusName);
            InfoBus infoBus = getInfoBus();
            if (infoBus == null)
            {
                // XXX - throw exception?
                return;
            }
            infoBus.addDataConsumer(this);
            addDataItemListeners();
            InfoBusManager.getInstance().addInfoBusManagerListener(this); 
        }
        catch (InfoBusMembershipException e)
        {
            // XXX - Do something useful here
        }
        catch (PropertyVetoException e)
        {
            // XXX - Do something useful here
        }
    }

    public void releaseResources(InfoBusManagerReleaseEvent e)
    {
        if (_treeDataSource != null)
        {
           if (e.appliesTo(_treeDataSource.getTreeControl()))
           {
              dropInfoBusInt();
           }
        }
    }

    /**
    * Removes this object from its currently bound InfoBus and data item. <P>
    */
    protected synchronized void dropInfoBusInt()
    {
        InfoBusManager.getInstance().removeInfoBusManagerListener(this);
        removeDataItemListeners();
        InfoBus infoBus = getInfoBus();
        if (infoBus != null)
        {
            infoBus.removeDataConsumer(this);
        }
        try
        {
            leaveInfoBus();
        }
        catch (InfoBusMembershipException e)
        {
            // Ignore
        }
        catch (PropertyVetoException e)
        {
            // Ignore
        }
    }

    public void setTreeDataSource(TreeDataSource nuTreeDataSource)
    {
        _treeDataSource = nuTreeDataSource;
    } // setTreeDataSource
    
    public TreeDataSource getTreeDataSource()
    {
        return(_treeDataSource);
    } // getTreeDataSource
    
    /**
    **
    */
    public void setUserObject(Object object)
    {
        _object = object;
    }

    void destroy()
    {
        removeAllChildNodes();
        removeDataItemListeners();
        setInfoBusName(null);
        setTreeDataSource(null);
        _data.clear();
        setName(_name + "_DELETED");
    }
    
    
    void removeAllChildNodes()
    {
        if (_kids != null)
        {
            int cnt = _kids.size();
            for(int i = cnt-1; i >= 0; i--)
            {
                remove(i);
            }
        }
    }
    
    void createAllChildNodes()
    {
        int rowCnt = 0;

        // _debug(_name + ".createAllChildNodes");
        if (_data.details == null && _data.detailsCol != null)
        {
            _initDetailRowSet();
        }
        
        if (_data.details != null)
        {
            rowCnt = _data.details.getRowCount();
        }
        if (_data.array == null && _data.details != null)
        {
            // fetch all rows
            _data.details.setBufferSize(-1);
            _data.array = ((DataItemView)_data.details).getView(-1);
        }
        if (_data.array != null)
        {
            _kids = new Vector(rowCnt);
            _kids.setSize(rowCnt);
            for(int i = 0; i < rowCnt; i++)
            {
                _kids.setElementAt(createChildNode(i), i);
            }
        }
    } // createAllChildNodes
    
    TreeControlNode createChildNode(int childIndex)
    {
        Object obj;
        TreeControlNode child = new TreeControlNode(_treeDataSource);
        TreeNodeData childData;

        childData = child.getTreeNodeData();
        childData.def = _treeDataSource.getChildNodeDef(_data.def);
        if (_initChildNodeData(childData, childIndex))
        {
            String name = childData.value.getValueAsString();
            child._name = (name == null ? "" : name);
            child.setParent(this);
            child.setInfoBusName(_infoBusName);
            child.addDataItemListeners();
        }
        else
        {
            child.dropInfoBusInt();
            child = null;
        }
        return(child);
    } // _createChildNode

    private boolean _initChildNodeData(TreeNodeData childData, int childIndex)
    {
        Object obj;
        boolean retval = true;
        int[] colIndices;
        int[] coords = { childIndex, 0 };
        
        try
        {
            coords[1] = _data.def.getDisplayColIndex() - 1;
            obj = _data.array.getItemByCoordinates(coords);
            if (obj != null && obj instanceof ImmediateAccess)
            {
                childData.value = (ImmediateAccess)obj;
            }
        }
        catch(Exception e)
        {
            childData.value = null;
            retval = false;
        }
            
        if (childData.value != null)
        {
            colIndices = _data.def.getPrimaryKeyColIndices();
            if (colIndices != null)
            {
                childData.pKeys = new ImmediateAccess[colIndices.length];
                try
                {
                    for(int i = 0; i < colIndices.length; i++)
                    {
                        coords[1] = colIndices[i] - 1;
                        obj = _data.array.getItemByCoordinates(coords);
                        if (obj != null && obj instanceof ImmediateAccess)
                        {
                            childData.pKeys[i] = (ImmediateAccess)obj;
                        }
                    }
                }
                catch(Exception e)
                {
                    childData.pKeys = null;
                }
            }
            
            colIndices = _data.def.getForeignKeyColIndices();
            if (colIndices != null)
            {
                childData.fKeys = new ImmediateAccess[colIndices.length];
                try
                {
                    for(int i = 0; i < colIndices.length; i++)
                    {
                        coords[1] = colIndices[i] - 1;
                        obj = _data.array.getItemByCoordinates(coords);
                        if (obj != null && obj instanceof ImmediateAccess)
                        {
                            childData.fKeys[i] = (ImmediateAccess)obj;
                        }
                    }
                }
                catch(Exception e)
                {
                    childData.fKeys = null;
                }
            }

            if (_data.def.getLinkColName() != null)
            {
                try
                {
                    coords[1] = _data.def.getLinkColIndex() - 1;
                    obj = _data.array.getItemByCoordinates(coords);
                    if (obj instanceof ImmediateAccess)
                    {
                        childData.detailsCol = (ImmediateAccess)obj;
                    }
                }
                catch(Exception e)
                {
                }
            }
        }
        else
        {
            retval = false;
        }
        return(retval);
    } // _initChildNodeData

    void _initDetailRowSet()
    {
        Object obj = _data.detailsCol.getValueAsObject();
        
        if (obj != null && obj instanceof ScrollableRowsetAccess)
        {
            _data.details = (ScrollableRowsetAccess)obj;
            _data.details.setBufferSize(-1);
            _data.array = ((DataItemView)_data.details).getView(-1);
            if (_data.details instanceof DataItemChangeManager)
            {
                ((DataItemChangeManager)_data.details).addDataItemChangeListener(this);
            }
        }
    }
    
    
    void removeTreesListeners()
    {
        if (_kids != null)
        {
            int cnt = _kids.size();
            
            for(int i = 0; i < cnt; i++)
            {
                ((TreeControlNode)_kids.elementAt(i)).removeTreesListeners();
            }
        }
        removeDataItemListeners();
    }
    

    void removeDataItemListeners()
    {
        if (_data.value != null &&
            _data.value instanceof DataItemChangeManager)
        {
            ((DataItemChangeManager)_data.value).removeDataItemChangeListener(this);
        }
        if (_data.details != null &&
            _data.details instanceof DataItemChangeManager)
        {
            ((DataItemChangeManager)_data.details).removeDataItemChangeListener(this);
        }
        if (_data.details != null &&
            _data.details instanceof RowSetManager &&
            ((RowSetManager)_data.details).isFromLinkAccessor())
        {
            ((RowSetManager)_data.details).destroy();
        }
    }

    void addDataItemListeners()
    {
        if (_data.value != null &&
            _data.value instanceof DataItemChangeManager)
        {
            ((DataItemChangeManager)_data.value).addDataItemChangeListener(this);
        }
        if (_data.details != null &&
            _data.details instanceof DataItemChangeManager)
        {
            ((DataItemChangeManager)_data.details).addDataItemChangeListener(this);
        }
    }

    // InfoBusDataConsumer interface implementation
    public void dataItemAvailable(InfoBusItemAvailableEvent event)
    {
    }
    
    public void dataItemRevoked(InfoBusItemRevokedEvent event)
    {
    }

    /**
    * This method gets called when the object's <TT>InfoBus</TT> property
    * is changed. <P>
    * The object is removed as a data consumer from its previous InfoBus,
    * and is added as a consumer to its new InfoBus. <P>
    * @param event The event.
    */
    public void propertyChange(PropertyChangeEvent event)
    {
        if (event.getPropertyName().equals("InfoBus"))
        {
            Object oldVal = event.getOldValue();
            Object newVal = event.getNewValue();

            if (oldVal != newVal)
            {
                if (oldVal != null && oldVal instanceof InfoBus)
                {
                    ((InfoBus)oldVal).removeDataConsumer(this);
                }

                if (newVal != null && newVal instanceof InfoBus)
                {
                    ((InfoBus)newVal).addDataConsumer(this);
                }
            }
        }
    }
    
    // DataItemChangeListener interface implementation

    /**
    ** Indicates that the cursor for the bound <TT>RowsetAccess</TT> data item
    ** has changed rows. <P>
    ** A reference to the rowset data item can be obtained from the event. <P>
    ** @param event Contains details of the cursor move.
    ** @see javax.infobus.DataItemChangeListener#rowsetCursorMoved
    */
    public void rowsetCursorMoved(RowsetCursorMovedEvent e)
    {
        // nop
    }

    /**
    ** Indicates a changed value in the bound data item. <P>
    ** A reference to the data item that changed can be obtained from the
    ** event. <P>
    ** @param event Contains change information.
    ** @see javax.infobus.DataItemChangeListener#dataItemValueChanged
    */
    public void dataItemValueChanged(final DataItemValueChangedEvent e)
    {
        Integer t;
        int[] indices;
        int rowIndex;
        int rowCount = 0;
        Boolean r = (Boolean)e.getProperty(Control.EVENT_PROPERTY_ROW_CHANGE);
        Boolean v =
            (Boolean)e.getProperty(Control.EVENT_PROPERTY_VIEW_REFRESHED);

        // get the index of the added row; it's 1 based
        t = (Integer)e.getProperty(Control.EVENT_PROPERTY_ROW);
        rowIndex = (t != null ? (t.intValue() > 0 ? t.intValue()-1 : 0) : -1);
        t = (Integer)e.getProperty(Control.EVENT_PROPERTY_ROW_COUNT);
        rowCount = t != null ? t.intValue() : -1;

        if (_kids == null || rowIndex == -1 || rowCount == -1)
        {
            return;
        }
        
        // _debug(_name + ".dataItemValueChanged event=" + e);
        if (v.booleanValue())
        {
            int kidCount = (_kids == null ? -1 : _kids.size());

            _updateViewData();
            if (kidCount > 0)
            {
                TreeControlNode[] nodes = new TreeControlNode[kidCount];

                indices = new int[kidCount];
                for(int i = kidCount-1; i >= 0; i--)
                {
                    indices[i] = i;
                    nodes[i] = (TreeControlNode)_kids.elementAt(i);
                    remove(i);
                }
                _treeDataSource.fireTreeNodesRemoved(this, indices, nodes);
            }
            _updateChildData();
            createAllChildNodes();
            kidCount = (_kids == null ? -1 : _kids.size());
            if (kidCount > 0)
            {
                indices = new int[kidCount];
                for(int i = 0; i < kidCount; i++)
                {
                    indices[i] = i;
                }
                // _treeDataSource.nodesWereInserted(this, indices);
                _treeDataSource.fireTreeNodesInserted(this, indices);
            }
        }
        else
        {
            // String s = null;
            if (rowCount > 0)
            {
                indices = new int[rowCount];
                for(int i = 0, j = rowIndex; i < rowCount; i++, j++)
                {
                    // s = (s == null ? ("" + j) : (s + "," + j));
                    indices[i] = j;
                }
                // _debug(_name +".fireTreeNodesChanged(): indices: " + s);
                _treeDataSource.fireTreeNodesChanged(this, indices);
            }
        }
    }

    /**
    ** Indicates that a new item was added to the bound aggregate data item
    ** (e.g. <TT>ArrayAccess</TT>, a JDK Collection, etc). <P>
    ** A reference to the data item that was added, and a reference to the one
    ** that gained it, can be obtained from the event. <P>
    ** @param event Contains details of the addition.
    ** @see javax.infobus.DataItemChangeListener#dataItemAdded
    */
    public void dataItemAdded(final DataItemAddedEvent e)
    {
        Integer t;
        int rowIndex;
        int[] indices;
        int rowCount = 0;

        // get the index of the added row; it's 1 based
        t = (Integer)e.getProperty(Control.EVENT_PROPERTY_ROW);
        rowIndex = t != null ? t.intValue()-1 : -1;
        t = (Integer)e.getProperty(Control.EVENT_PROPERTY_ROW_COUNT);
        rowCount = t != null ? t.intValue() : -1;
        
        // _debug(_name + ".dataItemAdded event=" + e);
        if (_kids != null)
        {

            _updateViewData();

            // create space for the new child(ren)
            // _kids.setSize(_kids.size() + rowCount);

            // create the new child(ren)
            indices = new int[rowCount];
            for(int i = 0, j = rowIndex; i < rowCount; i++, j++)
            {
                indices[i] = j;
                _kids.insertElementAt(createChildNode(j), j);
            }

            _updateChildData();
        }
        else
        {
            indices = new int[rowCount];
            for(int i = 0, j = rowIndex; i < rowCount; i++, j++)
            {
                indices[i] = j;
            }
            createAllChildNodes();
        }
        // send the event
        _treeDataSource.fireTreeNodesInserted(this, indices);
    }

    /**
    ** Indicates that an item was deleted from the bound aggregate data item
    ** (e. g. <TT>ArrayAccess</TT>, a JDK Collection, etc). <P>
    ** A reference to the data item that was deleted, and a reference to the
    ** one that lost it, can be obtained from the event. <P>
    ** @param event Contains details of the deletion.
    ** @see javax.infobus.DataItemChangeListener#dataItemDeleted
    */
    public void dataItemDeleted(final DataItemDeletedEvent e)
    {
        Object obj;
        Integer t;
        int rowIndex;
        int[] indices;
        TreeControlNode[] nodes;
        int rowCount = 0;

        // _debug(_name + ".dataItemDeleted event=" + e);
        if (_kids != null)
        {
            // get the index of the deleted row; it's 1 based
            t = (Integer)e.getProperty(Control.EVENT_PROPERTY_ROW);
            rowIndex = t != null ? t.intValue()-1 : -1;
            t = (Integer)e.getProperty(Control.EVENT_PROPERTY_ROW_COUNT);
            rowCount = t != null ? t.intValue() : -1;

            _updateViewData();
        
            indices = new int[rowCount];
            nodes = new TreeControlNode[rowCount];
            for(int i = 0, k = rowIndex; i < rowCount; i++, k++)
            {
                indices[i] = k;
                nodes[i] = (TreeControlNode)_kids.elementAt(rowIndex);
                remove(rowIndex);
            }
        
            _updateChildData();
        
            // send the events
            _treeDataSource.fireTreeNodesRemoved(this, indices, nodes);
        }
    }

    private void _updateViewData()
    {
        // _debug(_name + "._updateViewData");
        int rc = (_data.details != null ? _data.details.getRowCount() : 0);

        _data.array =
            (rc > 0 ? ((DataItemView)_data.details).getView(rc) : null);
    }

    private void _updateChildData()
    {
        // _debug(_name + "._updateChildData");
        if (_kids != null)
        {
            TreeControlNode child;
        
            // update all the ImmediateAccess items for all child nodes
            for(int i = 0, lim = getChildCount(); i < lim; i++)
            {
                child = (TreeControlNode)_kids.elementAt(i);
                if (child != null)
                {
                    _initChildNodeData(child._data, i);
                }
            }
        }
    }

    /**
    ** Indicates that the bound data item (and its sub-items, if any) has been
    ** revoked, and is temporarily unavailable. <P>
    ** A reference to the data item that was revoked can be obtained from
    ** the event. <P>
    ** When this method is called, the node and all of it's children will be
    ** removed from the tree.
    ** @param event Contains details of the revoked data.
    ** @see javax.infobus.DataItemChangeListener#dataItemRevoked
    */
    public void dataItemRevoked(DataItemRevokedEvent e)
    {
        // _debug(_name + ".dataItemRevoked:" + e);
        Object revokedDI = e.getChangedItem();
        
        if (_data != null)
        {
            // _debug(getName() + ": valid _data");
            if (revokedDI == _data.detailsCol || 
                revokedDI == _data.details ||
                revokedDI == _data.array)
            {
                int kidCount = (_kids == null ? -1 : _kids.size());

                if (kidCount > 0)
                {
                    TreeControlNode[] nodes = new TreeControlNode[kidCount];
                    int[] indices = new int[kidCount];
                
                    for(int i = (kidCount-1); i >= 0; i--)
                    {
                        indices[i] = i;
                        nodes[i] = (TreeControlNode)_kids.elementAt(i);
                        remove(i);
                    }
                    // _debug(_name + ".fireTreeNodesRemoved");
                    _treeDataSource.fireTreeNodesRemoved(this, indices, nodes);
                }
                _data.detailsCol = null;
                _data.details = null;
                _data.array = null;
            }
            else
            {
                if (revokedDI == _data.value)
                {
                    // _debug(_name + ".fireTreeNodeChanged");
                    _data.value = null;
                    _treeDataSource.fireTreeNodeChanged(this);
                }
                else
                {
                    int pos = _getListPos(_data.pKeys, revokedDI);
                    
                    if (pos != -1)
                    {
                        _data.pKeys[pos] = null;
                    }
                    else
                    {
                        pos = _getListPos(_data.fKeys, revokedDI);
                        if (pos != -1)
                        {
                            _data.fKeys[pos] = null;
                        }
                    }
                }
            }
        }
    }

    private int _getListPos(ImmediateAccess[] list, Object item)
    {
        int listPos = -1;
        
        if (list != null)
        {
            for(int i= 0; i < list.length && listPos == -1; i++)
            {
                if (list[i] == item)
                {
                    listPos = i;
                }
            }
        }
        return(listPos);
    }

    // MutableTreeNode interface implementation

    /**
    **
    */
    public Object getUserObject()
    {
        return(_object);
    }

    /**
    **
    */
    public void insert(MutableTreeNode child, int index)
    {
        if (_kids != null)
        {
            _kids = new Vector(index+1);
        }
        if (index >= _kids.size())
        {
            _kids.setSize(index+1);
        }
        _kids.insertElementAt(child,index);
        child.setParent(this);
    }

    /**
    **
    */
    public void remove(int index)
    {
        if (_kids != null)
        {
            remove((MutableTreeNode)_kids.elementAt(index));
        }
    }
        
    /**
    **
    */
    public void remove(MutableTreeNode node)
    {
        if (node != null)
        {
            if (node instanceof TreeControlNode)
            {
                ((TreeControlNode)node).removeDataItemListeners();
                ((TreeControlNode)node).removeAllChildNodes();
                ((TreeControlNode)node).setInfoBusName(null);
                ((TreeControlNode)node).setTreeDataSource(null);
                ((TreeControlNode)node)._data.clear();
                ((TreeControlNode)node).setName(_name + "_DELETED");
            }
            node.setParent(null);
            if (_kids != null)  // shouldn't ever be null but we're paranoid
            {
                _kids.removeElement(node);
            }
        }
    }

    /**
    **
    */
    public void removeFromParent()
    {
        _parent.remove(this);
    }
    
    /**
    */
    public void setParent(MutableTreeNode newParent)
    {
        _parent = (TreeControlNode)newParent;
    }

    // TreeNode interface implementation

    /**
    **  Returns the children of the reciever as an Enumeration.<p>
    **
    **  Will not automatically load all child nodes.
    */
    public Enumeration children()
    {
        // _debug(_name + ".children()");
        return(children(false));
    }
    
    /**
    **  Returns the children of the reciever as an Enumeration.
    **
    **  May automatically load all child nodes depending upon the value
    **  of loadChildren.
    **
    **  @param  loadChildren    true: load children if not loaded
    */
    public Enumeration children(boolean loadChildren)
    {
        // _debug(_name + ".children("+loadChildren+")");
        if (loadChildren && _kids == null) 
        {
            createAllChildNodes(); // will allocate the _kids vector
        }
        return(_kids != null ? _kids.elements() : null);
    }

    /**
    ** Returns true if the receiver allows children.
    */
    public boolean getAllowsChildren() 
    {
        return(_data.details != null || _data.detailsCol != null);
    }
        
    /**
    ** Returns this node's first child.  If this node has no children,
    ** throws NoSuchElementException.
    **
    ** @return  the first child of this node
    ** @exception       NoSuchElementException  if this node has no children
    */
    public TreeNode getFirstChild()
    {
        // _debug(_name + ".getFirstChild()");
        if (_kids == null)
        {
            createAllChildNodes(); // will allocate the _kids vector
        }
        return(getChildAt(0));
    }


    /**
    ** Returns this node's last child.  If this node has no children,
    ** throws NoSuchElementException.
    **
    ** @return  the last child of this node
    ** @exception       NoSuchElementException  if this node has no children
    */
    public TreeNode getLastChild()
    {
        TreeNode node = null;

        // _debug(_name + ".getLastChild()");
        if (_kids == null)
        {
            createAllChildNodes(); // will allocate the _kids vector
        }
        if (getChildCount() > 0)
        {
            node = getChildAt(getChildCount()-1);
        }
        return(node);
    }


    /**
    **  Returns the child TreeNode at the specified index
    **
    **  @return  the requested node or null if the index is out of bounds
    */
    public TreeNode getChildAt(int index)
    {
        TreeNode node = null;

        // _debug(_name + ".getChildAt("+index+")");
        if (_kids == null)
        {
            createAllChildNodes(); // will allocate the _kids vector
        }
        if (_kids != null && index < _kids.size())
        {
            node = (TreeNode)_kids.elementAt(index);
        }
        return(node);
    }
        
    /**
    ** Returns the number of children TreeNodes the receiver contains.
    */
    public int getChildCount()
    {
        int rowCount = 0;

        if (_kids == null)
        {
            if (_data.details == null && _data.detailsCol != null)
            {
                _initDetailRowSet();
            }
            if (_data.details != null)
            {
                rowCount = _data.details.getRowCount();
            }
        }
        else
        {
            rowCount = _kids.size();
        }
        // _debug(_name + ".getChildCount(): " + rowCount);
        return(rowCount);
    }

    /**
    ** Returns the index of node in the receiver's children.  If the
    ** receiver does not contain node, -1 will be returned.
    */
    public int getIndex(TreeNode node)
    {
        return(_kids != null ? _kids.indexOf(node) : -1);
    }
        
    /**
    ** Returns the parent TreeNode of the receiver.
    */
    public TreeNode getParent()
    {
        return(_parent);
    }

    /**
    ** Returns true if the receiver is a leaf.
    */
    public boolean isLeaf()
    {
        boolean isleaf =
            (_data == null ||
             (_data.detailsCol == null && _data.details == null));
        
        return(isleaf);
    }

    /**
    ** Sets whether the node is displaying the current row.<p>
    **
    ** @param currentRow True if the node is displaying the current row.
    ** @see #isCurrentRow()
    */
    public void setCurrentRow(boolean currentRow)
    {
        _currentRow = currentRow;        
    } // setCurrentRow
    
    /**
    ** Returns whether the node is displaying the current row.<p>
    **
    ** @return True if the node is displaying the current row.
    ** @see #setCurrentRow(boolean currentRow)
    */
    public boolean isCurrentRow()
    {
        return(_currentRow);        
    } // getCurrentRow
    
    public String toString()
    {
        String s =
            (_data != null && _data.value != null)
                   ? _data.value.getValueAsString() : _name;

        if (s != null && !s.equals(_name))
        {
            _name = s;
        }
        return(s);
    }

    /**
    **  Returns the path from the root to this node.  The last
    **  element in the path is this node.
    **
    **  @return an array of TreeControlNodes listing the path, where the
    **          first element in the array is the root and the last
    **          element is this node.
    */
    public TreeControlNode[] getPath()
    {
        return(getPathToRoot(this, 0));
    }

    /**
    ** Builds the parents of node up to and including the root node,
    ** where the original node is the last element in the returned array.
    ** The length of the returned array gives the node's depth in the
    ** tree.
    ** 
    ** @param aNode  the TreeNode to get the path for
    ** @param depth  an int giving the number of steps already taken towards
    **        the root (on recursive calls), used to size the returned array
    ** @return an array of TreeNodes giving the path from the root to the
    **         specified node 
    */
    protected TreeControlNode[] getPathToRoot(TreeControlNode node, int depth)
    {
        TreeControlNode[] nodes;

        // Check for null, in case someone passed in a null node, or
        // they passed in an element that isn't rooted at root.
        if (node == null)
        {
            nodes = (depth == 0) ? null : new TreeControlNode[depth];
        }
        else
        {
            nodes = getPathToRoot((TreeControlNode)node.getParent(), ++depth);
            nodes[nodes.length - depth] = node;
        }
        return(nodes);
    }

    public Enumeration depthFirstEnumeration()
    {
        return(new DepthFirstEnumeration(this));
    }

    final class DepthFirstEnumeration
        implements Enumeration
    {
        protected TreeControlNode root;
        protected Enumeration children;
        protected Enumeration subtree;

        public DepthFirstEnumeration(TreeControlNode rootNode)
        {
            super();
            root = rootNode;
            children = root.children();
            subtree = EMPTY_ENUMERATION;
        }

        public boolean hasMoreElements()
        {
            return root != null;
        }

        public Object nextElement()
        {
            Object retval;

            if (subtree.hasMoreElements())
            {
                retval = subtree.nextElement();
            }
            else
            {
                if (children != null && children.hasMoreElements())
                {
                    subtree =
                        new DepthFirstEnumeration((TreeControlNode)children.nextElement());
                    retval = subtree.nextElement();
                }
                else
                {
                    retval = root;
                    root = null;
                }
            }
            return(retval);
        }
    }  // End of class DepthFirstEnumeration

    
    private void _debug(String msg)
    {
        if (_DEBUG)
        {
            System.out.println("TreeControlNode: "+ msg);
        }
    }
}  // TreeControlNode
    
