/*
 * @(#)ComboBoxControl.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.dacf.control.swing;

import java.awt.Component;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.util.Vector;
import javax.infobus.DataItem;
import javax.infobus.DataItemAddedEvent;
import javax.infobus.DataItemChangeListener;
import javax.infobus.DataItemDeletedEvent;
import javax.infobus.DataItemRevokedEvent;
import javax.infobus.DataItemValueChangedEvent;
import javax.infobus.ImmediateAccess;
import javax.infobus.RowsetCursorMovedEvent;
import javax.infobus.ScrollableRowsetAccess;
import javax.swing.ComboBoxEditor;
import javax.swing.ComboBoxModel;
import javax.swing.JComboBox;
import javax.swing.SwingUtilities;
import javax.swing.event.ListDataEvent;
import oracle.dacf.control.Control;
import oracle.dacf.control.ControlEnabledListener;
import oracle.dacf.control.ControlSupport;
import oracle.dacf.control.DualBindingControl;
import oracle.dacf.control.InfoBusManager;
import oracle.dacf.control.InfoBusManagerListener;
import oracle.dacf.control.InfoBusManagerReleaseEvent;
import oracle.dacf.control.NavigatedEvent;
import oracle.dacf.control.NavigatedListener;
import oracle.dacf.control.NavigatingEvent;
import oracle.dacf.control.NavigatingException;
import oracle.dacf.control.NavigatingListener;
import oracle.dacf.control.NavigationManager;
import oracle.dacf.dataset.DataItemProperties;
import oracle.dacf.dataset.InfoObject;

/**
 *
 * ComboBoxControl is a data aware combo box. It is comprised of a textfield
 * and a listbox. The textfield and listbox can be bound to different data items.
 *
 * ComboBoxControl, by default is used to update values. The
 * <TT>_dataItemUsageMode</TT> property is set to <TT>FOR_UPDATE</TT>
 * and the the ComboBoxControl updates the attribute that is bound via the
 * <TT>_dataItemNameForUpdate</TT> property. <P>
 *
 * The ComboBoxControl can also be used for navigation like a ListControl.
 * When <TT>_dataItemUsageMode</TT> is set to <TT>FOR_NAVIGATION</TT> the
 * ComboBoxControl ceases to update and is used instead to navigate
 * through the values that are bound via the <TT>_dataItemName</TT>
 * property.<P>
 *
 *
 *  Update mode :
 *  *************
 *
 *  The ComboBoxControl, when used in Update mode, assumes a master detail
 *  relationship.
 *
 *  The following three column attributes have to be defined
 *
 *  a) dataItemNameForUpdate  - this specifies which column in the detail table
 *                              should be updated
 *
 *  b) listKeyDataItemName    - this specifies which column in the master table
 *                              should be displayed in the popup list of the
 *                              the combo box.
 *
 *  c) listValueDataItemName  - this specifies which column 'value' in the
 *                              master table should be used for update.
 *
 *
 *  Consider DEPT (master), EMP (detail) tables and combo box used for updating
 *  the deptno field in the EMP table.
 *
 *  The attributes, for update should be set in the following way
 *
 *  dataItemNameForUpdate  - DEPTNO column in EMP
 *  listKeyDataItemName    - DNAME  column in DEPT
 *  listValueDataItemName  - DEPTNO column in DEPT
 *
 *  When the ComboBox is setup this way, the popup list will display the
 *  department names. When an update is done (changing selection in combo) the
 *  department name string is used as lookup string in the DNAME column of
 *  DEPT and the corresponding value in DEPTNO (from DEPT )is used to update
 *  the DEPTNO in EMP.
 *
 *   // sample usage
 *  comboBox.setListKeyDataItemName("infobus:/oracle/Session1/DeptView/Dname");
 *  comboBox.setListValueDataItemName("infobus:/oracle/Session1/DeptView/Deptno");
 *  comboBox.setDataItemNameForUpdate("infobus:/oracle/Session1/EmpView/Deptno");
 *
 *
 *  Navigate Mode :
 *  *****************
 *  The listKeyDataItemName is the only property that needs to be set. The
 *  popup list is populate with values in this column.
 *
 *  // sample usage
 *
 *  comboBox.setListKeyDataItemName("infobus:/oracle/Session1/DeptView/Dname");
 *
 *  @see Control
 *  @version PUBLIC
 */
public class ComboBoxControl
    extends JComboBox
    implements Control, FocusListener, ControlEnabledListener,
               DualBindingControl, InfoBusManagerListener
{
    private ControlSupport _updateControlSupport;
    private ControlSupport _navigationControlSupport;
    private ControlSupport _trackingControlSupport;
    private MappedComboBoxDataSource _dataSource;
    private StaticComboBoxDataSource _staticSource;
    private int _dataItemUsageMode;
    boolean editableState;

    /**
    *  Constructs a default ComboBoxControl. The renderer properties of the
    *  constructed instance is set to ListCellPainter
    */
    public ComboBoxControl()
    {
        this(new StaticComboBoxDataSource());
    }

    /**
    * Creates a ComboBoxControl that contains the elements in the specified
    * Vector.
    *
    * @param items elements picked from this vector
    */
    public ComboBoxControl(Vector items)
    {
        this(new StaticComboBoxDataSource(items));
    }

    /**
    * Creates a ComboBoxControl that contains the elements in the specified
    * array.
    *
    * @param items elements picked from this array
    */
    public ComboBoxControl(final Object items[])
    {
        this(new StaticComboBoxDataSource(items));
    }


    /**
    * Creates a ComboBoxControl that takes its items from an existing
    * ComboBoxDataModel.
    *
    * @param aModel the ComboBoxModel that provides the displayed list of items
    */
    public ComboBoxControl( ComboBoxModel aModel)
    {
        super(aModel);
        _init();
        InfoBusManager.getInstance().addInfoBusManagerListener(this);
        if (aModel instanceof MappedComboBoxDataSource)
        {
            _dataSource = (MappedComboBoxDataSource)aModel;
            _dataSource._selectedItemChanged(null, getDataItem(), true);
        }
        if (aModel instanceof StaticComboBoxDataSource)
        {
            _staticSource = (StaticComboBoxDataSource)aModel;
        }
        setDataItemUsageMode(DualBindingControl.FOR_UPDATE);
    }

    // InfoBusManagerListener interface implementation
    public void releaseResources(InfoBusManagerReleaseEvent e)
    {
        if (e.appliesTo(this))
        {
            if (_staticSource != null)
            {
               _staticSource.releaseResources(e);
            }

            InfoBusManager.getInstance().removeInfoBusManagerListener(this);
            removeFocusListener(this);
            _updateControlSupport.removeControlEnabledListener(this);
            _updateControlSupport = null;
            _trackingControlSupport.removeControlEnabledListener(this);
            _trackingControlSupport = null;
            _navigationControlSupport.removeControlEnabledListener(this);
            _navigationControlSupport = null;
        }
    }
    

    /**
    * Sets the dataItemName to be used for populating the list
    * of choices for the combobox
    *
    * @param  dataItemName  Fully qaulified name of the
    *                            name of the dataitem
    *
    * @deprecated use setListKeyDataItemName
    */
    public void setDataItemName(String dataItemName)
    {
        if (_dataItemUsageMode ==  DualBindingControl.FOR_UPDATE)
        {
            setDataItemNameForUpdate(dataItemName);
        }
        else
        {
            setListKeyDataItemName(dataItemName);
        }
    }

    /**
    *  Get the name of the dataItem being used for populating
    *  the list
    *  @return  dataItemName property
    *  @deprecated use getListKeyDataItemName
    */
    public String getDataItemName()
    {
        return(_dataItemUsageMode ==  DualBindingControl.FOR_UPDATE ?
               getDataItemNameForUpdate() : getListKeyDataItemName());
    }

    /**
    *  specify the list key data item name
    *
    *  This data item will be used to display the values in the popup list
    *  in the update mode and navigate mode
    *
    *  @param dataItemName for the values displayed in the popup list
    */
    public void setListKeyDataItemName(String dataItemName)
    {
        if ( _dataSource == null )
            _initDataSource();

        if ( dataItemName.equals(getDataItemNameForUpdate()))
            throw new IllegalArgumentException(Res.getString(Res.COMBO_BIND_ERROR_MSG));

        // they may be navigating from a static list, that is why there are
        // two "list" data sources
        // this is the columnModel support and will be presenting the

        // read-only view
        _dataSource.setListKeyDataItemName(dataItemName);
        //this is for tracking and will present the writableAccess


        _trackingControlSupport.setDataItemName(dataItemName);

        if (dataItemName != null)
        {
            // by default we bind to the roswet associated with this
            // attribute for navigation

			int i = dataItemName.lastIndexOf(InfoObject.ITEMNAME_DELIMITER);

            if (i > 0)
            {
                // listen on the rowset so we can track navigation changes
                _navigationControlSupport.setDataItemName(dataItemName.substring(0, i));
            }
			

            // by defaut set the listValueDataItemName to list key data item
            // name
            String listValueDataItemName = getListValueDataItemName();
            if ((listValueDataItemName == null ) ||
                listValueDataItemName.equals(""))
                setListValueDataItemName(dataItemName);
        }
    }

    /**
    *  get the list key data item name
    *
    *  return dataItemName for the values displayed in the popup list
    */
    public String getListKeyDataItemName()
    {
        return(_dataSource == null ? "" : _dataSource.getListKeyDataItemName());
    }

    /**
    *  specify the list value data item name
    *
    *  This data item will be used for update.
    *
    *  This property is used only in the update mode
    *
    *  @param dataItemName for update
    */
    public void setListValueDataItemName(String dataItemName)
    {
        if ( _dataSource == null )
            _initDataSource();
        _dataSource.setListValueDataItemName(dataItemName);
    }

    /**
    *  get the list value data item name
    *
    *  return dataItemName for the update value
    */
    public String getListValueDataItemName()
    {
        if ( _dataSource != null )
            return (_dataSource.getListValueDataItemName());
        return null;
    }


    /**
    * get the mode in which this ComboBox is configured to work
    *
    * @return a String indicating whenther the control is configured for
    *          navigation or update
    */
    public String getMode()
    {
        if (getDataItemUsageMode() == DualBindingControl.FOR_NAVIGATION)
            return new String("NAVIGATION");
        return new String("UPDATE");
    }


    static public String getName(Object newDataItem)
    {
        if (newDataItem instanceof ImmediateAccess)
        {
            if (newDataItem != null)
            {
                return ((ImmediateAccess)newDataItem).getValueAsString();
            }
        }
        return "";
    }

    /**
    *  Determines whether the values that are selected in the ListBox
    *  are used to navigate through the dataItem<P>
    *
    * @param navigable if true the values that are selected in the ListBox
    *  are used to navigate through the dataItem.
    */
    public void setDataItemUsageMode(int usage)
    {
        _dataItemUsageMode = usage;
        if (_dataItemUsageMode == DualBindingControl.FOR_NAVIGATION)
        {
            editableState = isEditable();
            setEditable(false);
            if (_dataSource != null)
            {
                _dataSource._selectedItemChanged(null,
                                                 _trackingControlSupport.getDataItem(),
                                                 true );
            }
        }
        else if (_dataItemUsageMode == DualBindingControl.FOR_UPDATE)
        {
            setEditable(editableState);
            if (_dataSource != null)
            {
                _dataSource._selectedItemChanged(null,
                                                 _updateControlSupport.getDataItem(),
                                                 true );
            }
        }
    }

    /**
    * get the mode in which the combobox is confiured to work - navigation or update
    *
    * @return the mode in which the combobox is configured to work
    */
    public int getDataItemUsageMode()
    {
        return _dataItemUsageMode;
    }

    /**
    *  Determines whether new values can be entered in the textfield or not <P>
    *  If editable is true installs a ComboBoxDataItemEditor as the editor
    *  for editing.
    *  @param editable if true then new values can be entered in the textfield
    *         else the value must be picked from the listbox
    */
    public void setEditable(boolean editable)
    {
        super.setEditable(editable);
        if (editable)
        {
            ComboBoxEditor editor = new ComboBoxDataItemEditor();
            setEditor(editor);
            if (editor instanceof Component)
            {
                ((Component)editor).addFocusListener(this);
            }
        }
        else
        {
            ComboBoxEditor editor = getEditor();
            if (editor != null && editor instanceof Component)
            {
                try
                {
                    ((Component)editor).removeFocusListener(this);
                }
                catch (Exception e)
                {
                    //Ignore

                }
            }
        }
    }


    /**
    *  A notification that the contents changed
    *
    *  @param e event object describing the event
    */
    public void contentsChanged(ListDataEvent e)
    {
        // This method is an implementation side effect
        // Override due to a bug in Swing. ContentsChanged
        // doesn't repaint
        // bug#4139078
        repaint();

        Object selectedItem = getModel().getSelectedItem();
        if ( selectedItem != null )
            selectedItemChanged();

    }

    /**
    * A notification that this control gained focus
    *
    * This method is an implementation side effect
    *
    * @param e focus gain event
    */
    public final void focusGained(FocusEvent e)
    {
        boolean allow = _validateFocus();
        if (!allow)
        {
            SwingUtilities.invokeLater(new Runnable(){
                public void run()
                    {
                        hidePopup();
                    }
            }
                                       );
        }
    }


    /**
    * A notification that this control lost focus
    *
    * This method is an implementation side effect
    *
    * @param e focus lost event
    */
    public final void focusLost(FocusEvent e)
    {
        // If we had focus and now we are loosing it
        if (NavigationManager.getNavigationManager().getFocusedControl() ==
            this)
        {
            ComboBoxEditor editor = getEditor();
            if (e.getSource() == editor)
            {
                getModel().setSelectedItem(editor.getItem());
            }
        }
    }

    // ControlEnabledListener interface
    public void enabledChanged(boolean b)
    {
        super.setEnabled(b);
    }

    // Control Interface

    /**
    ** An override of java.awt.Component.setEnabled. <P>
    **
    ** @param b boolean flag indicating whether the control is enabled
    */
    public void setEnabled(boolean b)
    {
        _trackingControlSupport.setEnabled(b);
    } // setEnabled


    /**
    * Returns the name of the InfoBus this control is connected to. <P>
    * Most controls should delegate this method to <TT>ControlSupport</TT>. <P>
    * @return  The name of the InfoBus this control is connected to.
    * @see ControlSupport#getInfoBusName
    */
    public final String getInfoBusName()
    {
        return (_trackingControlSupport.getInfoBusName());
    }

    /**
    * Sets the name of the InfoBus this control is connected to. <P>
    * If the named InfoBus does not exist, it is created automatically. <P>
    * If the control is already connected to an InfoBus, it is disconnected
    * first. <P>
    * Most controls should delegate this method to <TT>ControlSupport</TT>. <P>
    * @param infoBusName   The name of the InfoBus to connect to.
    * @see ControlSupport#setInfoBusName
    */
    public final void setInfoBusName(String infoBusName)
    {
        _trackingControlSupport.setInfoBusName(infoBusName);
        if (_staticSource != null)
        {
            _staticSource.setInfoBusName(infoBusName);
        }
    }

    /**
    * Returns the name of the InfoBus DataItem this control is bound to. <P>
    * Most controls should delegate this method to <TT>ControlSupport</TT>. <P>
    * @return  The name of the InfoBus DataItem this control is bound to,
    *          or <TT>null</TT> if the control is unbound.
    * @see #getDataItem
    * @see ControlSupport#getDataItemName
    */

    public final String getDataItemNameForUpdate()
    {
        return (_updateControlSupport.getDataItemName());
    }

    /**
    * Sets the name of the InfoBus DataItem this control is bound to. <P>
    * The DataItem with the given name is searched for on the InfoBus, and
    * if found, is bound to this control. <P>
    * If the control is already bound to a DataItem, it is unbound first. <P>
    * Most controls should delegate this method to <TT>ControlSupport</TT>. <P>
    * @param dataItemName  The name of the DataItem to bind to.
    * @see #getDataItem
    * @see ControlSupport#setDataItemName
    */
    public final void setDataItemNameForUpdate(String dataItemName)
    {
        if (dataItemName.equals(getListKeyDataItemName()))
        {
            throw new IllegalArgumentException(Res.getString(Res.COMBO_BIND_ERROR_MSG));
        }
        
        ComboBoxModel model = getModel();

        if (model instanceof StaticComboBoxDataSource)
        {
            ((StaticComboBoxDataSource)model).setDataItemName(dataItemName);
        }
        _updateControlSupport.setDataItemName(dataItemName);
        _trackingControlSupport.setDataItemName(dataItemName);
    }

    /**
    * Returns the InfoBus DataItem this control is bound to. <P>
    * @return  The InfoBus DataItem this control is bound to, or
    *          <TT>null</TT> if the control is unbound.
    * @see ControlSupport#getDataItem
    */
    public final Object getDataItem()
    {
		Object dataitem = null;

		if (_trackingControlSupport != null)
		{
			dataitem = _trackingControlSupport.getDataItem();
		}
        return dataitem;
    }

    /**
    * Notifies the control that the bound InfoBus DataItem has changed. <P>
    * The control can safely ignore this notification. <P>
    * @param oldDataItem   The formerly bound DataItem (can be <TT>null</TT>).
    * @param newDataItem   The newly bound DataItem (can be <TT>null</TT>).
    */
    public final void dataItemChanged(Object oldDataItem, Object newDataItem)
    {
        // this is a navigational update
        if (_dataItemUsageMode == DualBindingControl.FOR_NAVIGATION)
        {
            _updateSelection(newDataItem);
            if ((newDataItem !=null) && (newDataItem instanceof ImmediateAccess))
            {
                if (getModel().getSize() > 0)
                     setSelectedIndex(0);
            }

        }
        // this is a value changing update
        else
        {
            if (_dataSource != null)
            {
                // Notify our dataSource
                _dataSource._selectedItemChanged(oldDataItem, newDataItem,
                                                 false);
            }
        }
    }

    /**
    * Returns the AWT component associated with this control. <P>
    * @return  The AWT component for this control.
    */
    public final Component getComponent()
    {
        return (this);
    }

    /**
    * Determines whether focus into this control causes validation to
    * occur. <P>
    * Most controls should delegate this method to <TT>ControlSupport</TT>. <P>
    * @return  <TT>true</TT> if focus into this control causes validation to
    *          occur, <TT>false</TT> otherwise.
    * @see ControlSupport#isFocusValidated
    */
    public final boolean isFocusValidated()
    {
        return (_trackingControlSupport.isFocusValidated());
    }

    /**
    * Sets whether focus into this control causes validation to occur. <P>
    * Delegates to <TT>ControlSupport</TT>. <P>
    * @param focusValidated    If <TT>true</TT>, focus into this control will
    *                          cause validation to occur.
    * @see ControlSupport#setFocusValidated
    */
    public final void setFocusValidated(boolean focusValidated)
    {
        _trackingControlSupport.setFocusValidated(focusValidated);
    }

    /**
    * Adds a navigated listener to this control. <P>
    * The listener will be notified of NavigateIn and NavigateOut events. <P>
    * Delegates to <TT>ControlSupport</TT>. <P>
    * @param listener  The listener to add.
    * @see ControlSupport#addNavigatedListener
    */
    public final void addNavigatedListener(NavigatedListener listener)
    {
        _trackingControlSupport.addNavigatedListener(listener);
    }

    /**
    * Removes a navigated listener from this control. <P>
    * @param listener  The listener to remove.
    */
    public final void removeNavigatedListener(NavigatedListener listener)
    {
        _trackingControlSupport.removeNavigatedListener(listener);
    }

    /**
    * Processes a navigated event for this control. <P>
    * This method is for use by the NavigationManager only. <P>
    * @param event The navigated event.
    * @see ControlSupport#processNavigatedEvent
    */
    public final void processNavigatedEvent(NavigatedEvent event)
    {
        if (_trackingControlSupport != null)
		{
			_trackingControlSupport.processNavigatedEvent(event);
		}
    }

    /**
    * Adds a navigating listener to this control. <P>
    * The listener will be notified of NavigatingEvents. <P>
    * @param listener  The listener to add.
    */
    public final void addNavigatingListener(NavigatingListener listener)
    {
        _trackingControlSupport.addNavigatingListener(listener);
    }

    /**
    * Removes a previusly added navigating listener <P>
    * @param listener  The listener to remove.
    */
    public final void removeNavigatingListener(NavigatingListener listener)
    {
        _trackingControlSupport.removeNavigatingListener(listener);
    }

    /**
    * Processes a navigating event for this control. <P>
    * This method is for use by the NavigationManager only. <P>
    * @param event The navigating event.
    * @exception  NavigatingException   If the navigation is redirected to a
    *                                   different control.
    * @see ControlSupport#processNavigatedEvent
    */
    public final void processNavigatingEvent(NavigatingEvent event)
        throws NavigatingException
    {
		if (_trackingControlSupport != null)
		{
			_trackingControlSupport.processNavigatingEvent(event);
		}
    }


    //DataItemChangeListener Interface
    /**
    * Indicates a changed value in the bound data item. <P>
    * A reference to the data item that changed can be obtained from the
    * event. <P>
    * @param event Contains change information.
    * @see javax.infobus.DataItemChangeListener#dataItemValueChanged
    */
    public final void dataItemValueChanged(DataItemValueChangedEvent event)
    {
        Object item = event.getChangedItem();

        if ( item == null )
           return; // dataItemRevoked

        if ( _dataItemUsageMode == DualBindingControl.FOR_NAVIGATION)
        {
            if ( item instanceof ImmediateAccess)
                return;
        }

        if (_dataSource != null)
        {
            _dataSource._selectedItemValueChanged(event);
        }
        else
        {
            if (_staticSource != null)
            {
                _staticSource.dataItemValueChanged(event);
            }
            else
            {
                if (item != null && item instanceof ImmediateAccess)
                {
                    getModel().setSelectedItem(((ImmediateAccess)item).
                                               getValueAsObject());

                }
                // this is comming from a predefined list of choices
                if (item != null && item instanceof String)
                {
                    getModel().setSelectedItem(item);
                }
            }
        }

        if (item instanceof DataItem &&
            _dataItemUsageMode == DualBindingControl.FOR_UPDATE)
        {
            Boolean updateable = (Boolean)((DataItem)item).getProperty(DataItemProperties.UPDATEABLE);

            if (updateable != null)
            {
                // only enable the control if it is updateable
                setEnabled(updateable.booleanValue());
            }
        }
    }


    /**
    * Indicates that a new item was added to the bound aggregate data item
    * (e.g. <TT>ArrayAccess</TT>, a JDK Collection, etc). <P>
    * A reference to the data item that was added, and a reference to the one
    * that gained it, can be obtained from the event. <P>
    * @param event Contains details of the addition.
    * @see javax.infobus.DataItemChangeListener#dataItemAdded
    */
    public final void dataItemAdded(DataItemAddedEvent event)
    {
        // Don't care
    }

    /**
    * Indicates that an item was deleted from the bound aggregate data item
    * (e. g. <TT>ArrayAccess</TT>, a JDK Collection, etc). <P>
    * A reference to the data item that was deleted, and a reference to the
    * one that lost it, can be obtained from the event. <P>
    * @param event Contains details of the deletion.
    * @see javax.infobus.DataItemChangeListener#dataItemDeleted
    */

    public final void dataItemDeleted(DataItemDeletedEvent event)
    {
        // Don't care
    }

    /**
    * Indicates that the bound data item (and its sub-items, if any) has been
    * revoked, and is temporarily unavailable. <P>
    * A reference to the data item that was revoked can be obtained from
    * the event. <P>
    * @param event Contains details of the revoked data.
    * @see javax.infobus.DataItemChangeListener#dataItemRevoked
    */
    public final void dataItemRevoked(DataItemRevokedEvent event)
    {
        // Don't care
    }

    /**
    * Indicates that the cursor for the bound <TT>RowsetAccess</TT> data item
    * has changed rows. <P>
    * A reference to the rowset data item can be obtained from the event. <P>
    * @param event Contains details of the cursor move.
    * @see javax.infobus.DataItemChangeListener#rowsetCursorMoved
    */
    public void rowsetCursorMoved(RowsetCursorMovedEvent event)
    {
    }

    /**
    * get the control support object used for update's
    */
    public final ControlSupport getUpdateControlSupport()
    {
        return _updateControlSupport;
    }

    /**
    * validate the focus change
    *
    * @return validation status
    */
    private boolean _validateFocus()
    {
        if (isFocusValidated())
        {
            return (NavigationManager.getNavigationManager().validateFocusChange(this));
        }
        return (true);
    }

    /**
    * update the current selection in the combobox based on the new value of
    * the dataitem
    */
    private void _updateSelection(Object dataItem)
    {
        if (dataItem != null && dataItem instanceof ScrollableRowsetAccess)
        {
            ScrollableRowsetAccess rowset  = (ScrollableRowsetAccess)dataItem;
            int newSelection = rowset.getRow() - 1;
            _dataSource.setSelectedIndex(newSelection);
            if (( newSelection >= 0 ) && ( getModel().getSize() !=0))
                setSelectedIndex(newSelection);
        }
    }

	
    /**
    * intitalize the data source
    */
    private void _initDataSource()
    {
        _init();
        if (_dataSource == null)
        {
            // Initialize dataSource with our current model
            _dataSource = new MappedComboBoxDataSource(this);
            _dataSource._selectedItemChanged(null, getDataItem(), true);
            // Install dataSource as our current model now
            setModel(_dataSource);
        }
    }

    /**
    *  Initialize control. ...join Infobus etc.
    */
    private void _init()
    {
        if (_updateControlSupport == null)
        {
            _updateControlSupport = new ControlSupport(this);
            _updateControlSupport.addControlEnabledListener(this);
            _trackingControlSupport = new ControlSupport(this);
            _trackingControlSupport.addControlEnabledListener(this);
            _navigationControlSupport = new ControlSupport(this);
            _navigationControlSupport.addControlEnabledListener(this);
            setRenderer(ListCellPainter.getPainter());
            addFocusListener(this);
            setLightWeightPopupEnabled(true);
        }
    }

}
