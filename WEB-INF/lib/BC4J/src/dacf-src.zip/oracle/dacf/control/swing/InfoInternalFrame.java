/*
 * @(#)InfoInternalFrame.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.dacf.control.swing;

import java.awt.Component;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyVetoException;
import java.beans.VetoableChangeListener;
import javax.infobus.DataItemAddedEvent;
import javax.infobus.DataItemDeletedEvent;
import javax.infobus.DataItemRevokedEvent;
import javax.infobus.DataItemValueChangedEvent;
import javax.infobus.RowsetCursorMovedEvent;
import javax.swing.JInternalFrame;
import oracle.dacf.control.Control;
import oracle.dacf.control.ControlSupport;
import oracle.dacf.control.DbAccessMonitor;
import oracle.dacf.control.DbAccessMonitorFactory;
import oracle.dacf.control.IncompleteTransactionAlert;
import oracle.dacf.control.InfoBusManager;
import oracle.dacf.control.InfoBusManagerListener;
import oracle.dacf.control.InfoBusManagerReleaseEvent;
import oracle.dacf.control.NavigatedEvent;
import oracle.dacf.control.NavigatedListener;
import oracle.dacf.control.NavigatingEvent;
import oracle.dacf.control.NavigatingException;
import oracle.dacf.control.NavigatingListener;
import oracle.dacf.util.DesignTime;

/**
 *
 *  Frame which can track DbAccess (transactions).
 *
 *  The internal frame class starts tracking a session when
 *  setDbAccessMonitor method is invoked. When the frame window is closed
 *  a check is made for incomplete transactions and the user will be
 *  prompted to commit/rollback if the transaction is dirty.
 *
 *  @version PUBLIC
 */
public class InfoInternalFrame
    extends JInternalFrame
    implements Control, InfoBusManagerListener
{
    /**
    *  Monitor's DbAccess object
    */
    private DbAccessMonitor _dbAccessMonitor;

    /**
    *  which session are we bound to ?
    */
    private String _dataItemName;
    /**
    * info bus name
    */
    private String _infoBusName = Control.DEFAULT_INFOBUS_NAME;
    /**
    * has the focus been validated
    */
    private boolean _focusValidated;

    protected InternalFramePropertyChangeListener _intFramePropListener = null ;

    /**
    * Creates a non-resizable, non-closable, non-maximizable,
    * non-iconifiable InfoInternalFrame with no title.
    */
    public InfoInternalFrame()
    {
        this("", false, false, false, false);
    }

    /**
    * Creates a non-resizable, non-closable, non-maximizable,
    * non-iconifiable JInternalFrame with the specified title.
    *
    * @param title  the String to display in the title bar.
    */
    public InfoInternalFrame(String title)
    {
        this(title, false, false, false, false);
    }

    /**
    * Creates a non-closable, non-maximizable, non-iconifiable
    * InfoInternalFrame with the specified title and with resizability
    * specified.
    *
    * @param title      the String to display in the title bar.
    * @param resizable  if true, the frame can be resized
    */
    public InfoInternalFrame(String title, boolean resizable)
    {
        this(title, resizable, false, false, false);
    }

    /**
    * Creates a non-maximizable, non-iconifiable InfoInternalFrame with the
    * specified title and with resizability and closability specified.
    *
    * @param title      the String to display in the title bar.
    * @param resizable  if true, the frame can be resized
    * @param closable   if true, the frame can be closed
    */
    public InfoInternalFrame(String title, boolean resizable, boolean closable)
    {
        this(title, resizable, closable, false, false);
    }

    /**
    * Creates a non-iconifiable InfoInternalFrame with the specified title
    * and with resizability, closability, and maximizability specified.
    *
    * @param title       the String to display in the title bar.
    * @param resizable   if true, the frame can be resized
    * @param closable    if true, the frame can be closed
    * @param maximizable if true, the frame can be maximized
    */
    public InfoInternalFrame(String title, boolean resizable, boolean closable,
                          boolean maximizable)
    {
        this(title, resizable, closable, maximizable, false);
    }

    /**
     * Creates a InfoInternalFrame with the specified title and
     * with resizability, closability, maximizability, and iconifiability
     * specified.
     *
     * @param title       the String to display in the title bar.
     * @param resizable   if true, the frame can be resized
     * @param closable    if true, the frame can be closed
     * @param maximizable if true, the frame can be maximized
     * @param iconifiable if true, the frame can be iconified
     */
    public InfoInternalFrame(String title, boolean resizable, boolean closable,
                                boolean maximizable, boolean iconifiable)
    {
        super(title, resizable, closable, maximizable, iconifiable);
        InfoBusManager.getInstance().addInfoBusManagerListener(this);
    }

    // InfoBusManagerListener interface implementation
    public void releaseResources(InfoBusManagerReleaseEvent e)
    {
        if (e.appliesTo(this))
        {
            InfoBusManager.getInstance().removeInfoBusManagerListener(this);
            if (_dbAccessMonitor != null)
            {
                removeVetoableChangeListener(_intFramePropListener);
                _intFramePropListener = null;
                
                _dbAccessMonitor.removeDbAccessClient(this);
                _dbAccessMonitor = null;
            }
        }
    }

    /**
    *  set the name of the session to keep track of
    *
    *  @param nameOfSession  name of the session to monitor
    */
    public void setDataItemName(String nameOfSession)
    {
        if ( _dbAccessMonitor == null )
        {
            _intFramePropListener = new InternalFramePropertyChangeListener(this);
            addVetoableChangeListener(_intFramePropListener);
        }
        
        String oldDataItemName = getDataItemName();
        if ( nameOfSession.equals(oldDataItemName))
        {
            return;
        }
        else
        {
           if ( _dbAccessMonitor != null )
           {
              _dbAccessMonitor.removeDbAccessClient(this);
              _dbAccessMonitor = null;
           }
        }

        if (_dbAccessMonitor == null )
        {
            _dataItemName = nameOfSession;
            _dbAccessMonitor =
                DbAccessMonitorFactory.createDbAccessMonitor(nameOfSession);
            _dbAccessMonitor.addDbAccessClient(this);
        }
    }

    /**
    * get the name of the data item we are bound to
    *
    * @return name of the data item we are bound to
    */
    public String getDataItemName()
    {
        return ((_dataItemName == null ) ? "" : _dataItemName);
    }

    /**
    * Returns the name of the InfoBus this control is connected to. <P>
    */
    public String getInfoBusName()
    {
        return _infoBusName;
    }

    /**
    ** An override of java.awt.Component.setEnabled. <P>
    **
    ** @param b boolean flag indicating whether the control is enabled
    */
    public void setEnabled(boolean b)
    {
        super.setEnabled(b);
    } // setEnabled

    /**
    * Sets the name of the InfoBus this control is connected to. <P>
    * By default, the control is connected to the default InfoBus,
    * named <TT>DEFAULT_INFOBUS_NAME</TT>. <P>
    * If the named InfoBus does not exist, it is created automatically. <P>
    * If the control is already connected to an InfoBus, it is disconnected
    * first. <P>
    */
    public void setInfoBusName(String infoBusName)
    {
        _infoBusName = infoBusName;
        if (_dbAccessMonitor != null)
        {
            _dbAccessMonitor.setInfoBusName(infoBusName);
        }
    }

    /**
    * Returns the InfoBus DataItem this control is bound to. <P>
    * Most controls should delegate this method to <TT>ControlSupport</TT>. <P>
    * @return  The InfoBus DataItem this control is bound to, or
    *          <TT>null</TT> if the control is unbound.
    * @see ControlSupport#getDataItem
    */
    public Object getDataItem()
    {
        return null;
    }

    /**
    * Notifies the control that the bound InfoBus DataItem has changed. <P>
    * The control can safely ignore this notification. <P>
    * @param oldDataItem   The formerly bound DataItem (can be <TT>null</TT>).
    * @param newDataItem   The newly bound DataItem (can be <TT>null</TT>).
    */
    public void dataItemChanged(Object oldDataItem, Object newDataItem)
    {
    }



    // UI Control support

    /**
    * Returns the AWT component associated with this control. <P>
    * @return  The AWT component for this control.
    */
    public Component getComponent()
    {
        return this;
    }


    // ValidationManager support

    /**
    * Determines whether focus into this control causes validation to
    * occur. <P>
    * Most controls should delegate this method to <TT>ControlSupport</TT>. <P>
    * @return  <TT>true</TT> if focus into this control causes validation to
    *          occur, <TT>false</TT> otherwise.
    * @see ControlSupport#isFocusValidated
    */
    public boolean isFocusValidated()
    {
        return _focusValidated;
    }

    /**
    * Sets whether focus into this control causes validation to occur. <P>
    * Most controls should delegate this method to <TT>ControlSupport</TT>. <P>
    * @param focusValidated    If <TT>true</TT>, focus into this control will
    *                          cause validation to occur.
    * @see ControlSupport#setFocusValidated
    */
    public void setFocusValidated(boolean focusValidated)
    {
        _focusValidated = focusValidated;
    }


    // NavigationManager support

    /**
    * not supported
    * @param listener  The listener to add.
    */
    public void addNavigatedListener(NavigatedListener listener)
    {
        // no op
    }

    /**
    * not supported
    * @param listener  The listener to remove.
    */
    public void removeNavigatedListener(NavigatedListener listener)
    {
    }

    /**
    * not supported
    * @param event The navigated event.
    */
    public void processNavigatedEvent(NavigatedEvent event)
    {
    }

    /**
    * not supported
    * @param listener  The listener to add.
    */
    public void addNavigatingListener(NavigatingListener listener)
    {
    }

    /**
    * not supported
    * @param listener  The listener to remove.
    */
    public void removeNavigatingListener(NavigatingListener listener)
    {
    }

    /**
    * not supported
    * @param event The navigating event.
    * @exception NavigatingException   If the navigation is redirected to a
    *                                  different control.
    */
    public void processNavigatingEvent(NavigatingEvent event)
        throws NavigatingException
    {
    }

    /**
    * Indicates that the cursor for the bound <TT>RowsetAccess</TT> data item
    * has changed rows. <P>
    * Not supported
    * @param event Contains details of the cursor move.
    * @see javax.infobus.DataItemChangeListener#rowsetCursorMoved
    */
    public final void rowsetCursorMoved(RowsetCursorMovedEvent event)
    {
        // Not applicable
    }

    // DataItemChangeListener Interface

    /**
    * Indicates a changed value in the bound data item. <P>
    * A reference to the data item that changed can be obtained from the
    * event. <P>
    * @param event Contains change information.
    * @see javax.infobus.DataItemChangeListener#dataItemValueChanged
    */
    public final void dataItemValueChanged(DataItemValueChangedEvent event)
    {
    }

    /**
    * Indicates that a new item was added to the bound aggregate data item
    * (e.g. <TT>ArrayAccess</TT>, a JDK Collection, etc). <P>
    * A reference to the data item that was added, and a reference to the one
    * that gained it, can be obtained from the event. <P>
    *
    * @param event Contains details of the addition.
    * @see javax.infobus.DataItemChangeListener#dataItemAdded
    */
    public final void dataItemAdded(DataItemAddedEvent event)
    {
        // Not applicable
    }

    /**
    * Indicates that an item was deleted from the bound aggregate data item
    * (e. g. <TT>ArrayAccess</TT>, a JDK Collection, etc). <P>
    * A reference to the data item that was deleted, and a reference to the
    * one that lost it, can be obtained from the event. <P>
    *
    * Not applicable <P>
    * @param event Contains details of the deletion.
    * @see javax.infobus.DataItemChangeListener#dataItemDeleted
    */
    public final void dataItemDeleted(DataItemDeletedEvent event)
    {
        // Not applicable
    }

    /**
    * Indicates that the bound data item (and its sub-items, if any) has been
    * revoked, and is temporarily unavailable. <P>
    * not supported <P>
    * @param event Contains details of the revoked data.
    * @see javax.infobus.DataItemChangeListener#dataItemRevoked
    */
    public final void dataItemRevoked(DataItemRevokedEvent event)
    {
        // not applicable
    }

    /**
    *  customize the transaction alert dialog
    *
    * @param uiImpl an object which implements the IncompleteTransactionAlert
    *               interface
    * @throws IllegalArgumentException if the data item name has'nt been set yet
    */
    public void setIncompleteTransactionAlertUI(IncompleteTransactionAlert uiImpl)
        throws IllegalArgumentException
    {
        if ( _dbAccessMonitor != null )
        {
            _dbAccessMonitor.setIncompleteTransactionAlertUI(this, uiImpl);
        }
        else
        {
            throw new IllegalArgumentException(Res.getString(Res.DATAITEMNAME_UNDEFINED));
        }
    }

    /**
    * dispose the InfoInternalFrame
    */
    public void dispose()
    {
        if ( _dbAccessMonitor != null )
        {
            close(false);
        }
        super.dispose();
    }

    /**
    *  this method pops up the save changes dialog if needed and return's
    *  user's response.
    *
    *  The caller may terminate the application if this method returns true
    *  value.
    */
    public boolean close()
    {
        boolean canClose = true;
        
        if (_dbAccessMonitor != null )
        {
            canClose = close(true);
            if (canClose)
            {
                super.dispose();
            }
        }
        return(canClose);

    }

    /**
    * Calling this method with a true value closes the frame.
    * This method called will be invoked in the JDeveloper
    * Design time.
    *
    * @param b true, if the frame should be closed
    * @see JInternalFrame
    */
    public void setClosed(boolean b)
        throws PropertyVetoException
    {
        if (!DesignTime.inDesignTime())
        {
            super.setClosed(b);
        }
    }

    /**
    * Iconizes and deconizes the frame.
    * This method called will be invoked in the JDeveloper
    * Design time.
    *
    * @param b - true, if the frame should be iconified.
    * @see JInternalFrame
    */
    public void setIcon(boolean b)
               throws PropertyVetoException
    {
        if (!DesignTime.inDesignTime())
            super.setIcon(b);
    }

    /**
    * Close the frame.
    *
    * @param showCancelButton should the cancel button be displayed
    */
    protected boolean close(boolean showCancelButton)
    {

        return(_dbAccessMonitor == null ? true :
               _dbAccessMonitor.terminateTransaction(InfoInternalFrame.this,
                                                     !showCancelButton));
    }
}

class InternalFramePropertyChangeListener
      implements VetoableChangeListener
{
    InfoInternalFrame _frame;
    String cancelledMessage = null;

    InternalFramePropertyChangeListener(InfoInternalFrame frame)
    {
        _frame = frame;
    }

    public void vetoableChange(PropertyChangeEvent evt)
          throws PropertyVetoException
    {
        String s = evt.getPropertyName();
        Object value = evt.getNewValue();

        if (( s.equals(JInternalFrame.IS_CLOSED_PROPERTY)) &&
                ((Boolean)value == Boolean.TRUE))
        {
            if (!_frame.close(true))
            {
               if (cancelledMessage == null)
                   cancelledMessage = Res.getString(Res.INTERNAL_FRAME_CLOSE_CANCELLED);
                throw new PropertyVetoException(cancelledMessage, evt);
            }
        }
    }
}


