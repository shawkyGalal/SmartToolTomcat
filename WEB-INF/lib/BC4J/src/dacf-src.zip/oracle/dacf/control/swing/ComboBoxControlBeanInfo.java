/*
 * @(#)ComboBoxControlBeanInfo.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.dacf.control.swing;

import java.beans.PropertyDescriptor;

/**
 * bean info class for the combo box control
 *
 * @version SDK
 */
public class ComboBoxControlBeanInfo extends ControlBeanInfoHelper
{
  /**
  * Constuctor
  */
  public ComboBoxControlBeanInfo()
  {
    super();
  }

  /**
  * get the Class object for the bean
  *
  * @return Class object for the bean
  */
  protected Class getBeanClass()
  {
    return ComboBoxControl.class;
  }

  /**
  * get property descriptors specific to the combo box
  *
  * @return property descriptors for the combo box
  */
  public PropertyDescriptor[] getPropertyDescriptors()
  {
    try
    {

        PropertyDescriptor infoBusName =
                new PropertyDescriptor("infoBusName", getBeanClass(),
                                       "getInfoBusName", "setInfoBusName");

        PropertyDescriptor dataItemNameForUpdate  =
            new PropertyDescriptor("dataItemNameForUpdate", getBeanClass(),
                "getDataItemNameForUpdate", "setDataItemNameForUpdate");

        String editor = "oracle.jdeveloper.daceditors.ColDataItemNameEditor";

        PropertyDescriptor listKeyDataItemName  =
            new PropertyDescriptor("listKeyDataItemName", getBeanClass(),
                "getListKeyDataItemName", "setListKeyDataItemName");
        listKeyDataItemName.setPropertyEditorClass(Class.forName(editor));


        PropertyDescriptor listValueDataItemName  =
            new PropertyDescriptor("listValueDataItemName", getBeanClass(),
                "getListValueDataItemName", "setListValueDataItemName");
        listValueDataItemName.setPropertyEditorClass(Class.forName(editor));


        dataItemNameForUpdate.setPropertyEditorClass(getDataItemNameEditorClass());

        PropertyDescriptor dataItemUsageMode  =
            new PropertyDescriptor("dataItemUsageMode", getBeanClass(),
                "getDataItemUsageMode", "setDataItemUsageMode");

        dataItemUsageMode.setPropertyEditorClass(Class.forName(
                      "oracle.jdeveloper.daceditors.DataItemUsageModeEditor"));

        // hidden
        PropertyDescriptor selectedItem  =
            new PropertyDescriptor("selectedItem", getBeanClass(),
                "getSelectedItem", "setSelectedItem");

        PropertyDescriptor[] ret =
         {
                dataItemNameForUpdate, listValueDataItemName,
                listKeyDataItemName, dataItemUsageMode,
                selectedItem, infoBusName
         };
        selectedItem.setHidden(true);
        return ret;
    }
    catch (Exception exc)
    {
      return null;
    }
  }
}
