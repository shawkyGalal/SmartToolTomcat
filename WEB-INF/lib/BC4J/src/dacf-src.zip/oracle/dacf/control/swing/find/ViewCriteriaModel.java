/*
 * @(#)ViewCriteriaModel.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.dacf.control.swing.find;

/**
 *  An interface which allows the FindPanel to make use of ViewCriteriaRows
 *  and ViewCriteria to create and execute a parameterized query.
 *
 *
 *  @see FindPanel
 *  @see ResultSetInfo
 *  @version SDK
 */
public interface ViewCriteriaModel
{
     /**
     *  return the number of ViewCriteriaRows
     */
     public int getRowCount();

     /**
     *  get the row number of the current row.
     */
     public int getRow();

     /**
     *  move to a specific ViewCriteriaRow
     */
     public boolean absolute(int rowIndex);


     /**
     *  move to previous ViewCriteriaRow
     */
     public boolean previous();

     /**
     * move to the first ViewCriteriaRow
     */
     public boolean first();

     /**
     * move to the next ViewCriteriaRow
     */
     public boolean next();


     /**
     * move to the last ViewCriteriaRow
     */
     public boolean last();


     /**
     * create a new ViewCriteriaRow
     */
     public void newRow();


     /**
     * delete current ViewCriteriaRow
     */
     public void deleteRow();


     // column attributes

     /**
     *  @return the number of columns
     */
     public int getColumnCount();


     /**
     * return the column display name for a particular column
     */
     public String getColumnDisplayLabel(int colIndex);


     /**
     * get the column name., zero based index.
     *
     * @return name of the column to use in the query
     */
     public String getColumnName(int colIndex);


     /**
     * get SQL type for this column., zero based index.
     *
     */
     public int getSQLType(int colIndex);


     /**
     * return the column value for a particular column
     *
     * @param colIndex column index whose column value we are interested in.,
     *                 zero based index used
     *
     * @return column value
     *
     */
     public Object getColumnValue(int colIndex);


     /**
     * specify the column value for a particular column
     *
     * @param colIndex column index whose value has to be set
     *                 zero based index used
     *
     */
     public void setColumnValue(int colIndex, Object value);

	 
	 public void setUserData(int colIndex, Object value);

	 public Object getUserData(int colIndex);

}
