/*
 * @(#)ComboBoxDataSource.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.dacf.control.swing;

import javax.infobus.DataItem;
import javax.infobus.DataItemValueChangedEvent;
import javax.infobus.ImmediateAccess;
import javax.infobus.InvalidDataException;
import javax.infobus.ScrollableRowsetAccess;
import javax.swing.ComboBoxModel;
import oracle.dacf.control.DualBindingControl;
import oracle.dacf.control.InfoBusManagerReleaseEvent;
import oracle.dacf.control.NavigationManager;
import oracle.dacf.dataset.DacObject;
import oracle.dacf.util.SimpleInfoBusConsumer;

/**
 *  ComboBoxDataSource provides a JFC's ComboBoxModel implementation which gets
 *  its items from a infobus <TT>ScrollableRowsetAccess</TT>.<P>
 *
 *  The ComboBoxDataSource provides support for performing a lookup between
 *  what is displayed in the list to what is updated.
 *
 *  ColumnModelSupport - holds the 'value' item in update mode.
 *
 *  @version INTERNAL
 */
public class ComboBoxDataSource
    extends CachedColumnModelSupport
    implements ComboBoxModel
{
    private static boolean _DEBUG = false;
    protected ComboBoxControl _comboBox;
    protected ImmediateAccess _selectedItem; // in the list
	
	protected ImmediateAccess _detailItem; // ia used in update
    
	protected ScrollableRowsetAccess _rowsetForUpdateableItem = null;
	protected ValueLocator _valueLocator;
	protected String _listValueDataItemName;

	protected boolean _cachedSelectedItemInvalid = false;
	Object _oldSelectedItemValue = null;

    /**
    * Constructor
    *
    * @param comboBox a handle to the parent control
    */
    public ComboBoxDataSource(ComboBoxControl comboBox)
    {
        this(comboBox,null);
    }


    /**
    * Constructor
    *
    * @param comboBox a handle to the parent control
    * @param listDataItemName data item name for the combo
    */
    public ComboBoxDataSource(ComboBoxControl comboBox,
                              String listDataItemName)
    {
        super(comboBox);
        _comboBox = comboBox;
        setListDataItemName(listDataItemName);
		setValueLocator( new DefaultValueLocator());
    }

	public ValueLocator getValueLocator()
	{
		return _valueLocator;
	}

	/**
	*  ValueLocator is used to search in master rowset for a specific
	*  detail value
	*/
	public void setValueLocator(ValueLocator valueLocator)
	{
		_valueLocator = valueLocator;
        if ((_valueLocator != null) && (_listValueDataItemName != null))
		{
			_valueLocator.updateKeyColumnName(_listValueDataItemName, 
											  _comboBox);
		}
	}

    /**
    *  Set the name of the dataItem to be used for populating
    *  the list
    *  @return  modelDataItemName property
    */
    public void setListDataItemName(String modelDataItemName)
    {
        setListKeyDataItemName(modelDataItemName);
    }

    /**
    *  Get the name of the dataItem being used for populating
    *  the list
    *  @return  modelDataItemName property
    */
    public String getListDataItemName()
    {
        return(getListKeyDataItemName());
    }

	public void setListKeyDataItemName(String diName)
	{
		super.setDataItemName(diName);
	}

	public String getListKeyDataItemName()
	{
		return super.getDataItemName();
	}

	public void setListValueDataItemName(String name)
	{
		_listValueDataItemName = name;
		
		ValueLocator l = getValueLocator();
		if ((l != null) && (_listValueDataItemName != null))
		{
			l.updateKeyColumnName(_listValueDataItemName, _comboBox);
		}
	}

	public String getListValueDataItemName()
	{
		return _listValueDataItemName;
	}


    /**
    * get the value of the data item as a string
    *
    * @return dataitem value as string
    */
    public String getName(Object newDataItem)
    {
        String name = "";
        
        if (newDataItem != null && newDataItem instanceof ImmediateAccess)
        {
            name = ((ImmediateAccess)newDataItem).getValueAsString();
        }
        return(name);
    }


    // Navigatable ComboBoxModel Implementataion, this is called by the
    // combo box internals and is called with a ViewImmediateAccessImpl or
    // a string
    public void setSelectedItem(Object anObject)
    {
        if (anObject == null)
        {
            return;
        }

        // We are in navigate mode, move to a new index
        if (_comboBox.getDataItemUsageMode() ==
            DualBindingControl.FOR_NAVIGATION)
        {
            if (anObject instanceof ImmediateAccess)
            {
                ImmediateAccess accessObject = (ImmediateAccess) anObject;
                String s = accessObject.getValueAsString();
                int _newIndex = _getIndex(accessObject);

                if (_newIndex >= 0)
                {
                    // this selects an item from the list, causing the
                    // change in the dataItem,
                    setSelection(_newIndex);
                    // this sets the selectedItem to be the item at that
					setSelectedItemInternal((ImmediateAccess)_comboBox.getDataItem());
                }
            }
        }
        else    // We are in change mode, change the value of the selection
        {
            if (_canChangeSelection())
            {
                try
                {
                    if (_detailItem != null)
                    {
                        NavigationManager nm =
                            NavigationManager.getNavigationManager();
                        nm.focusedIsInvalid(true);
						
						int rowIndex = _itemToIndex(anObject);
						Object newValue = _getUpdateableValue(rowIndex);
                        _detailItem.setValue(newValue);

                        nm.focusedIsInvalid(false);
                    }
                }
                catch (InvalidDataException e)
                {
                    _debug("_selectedItem:"+_selectedItem.getValueAsString());
                    _debug("Invalid Data Exception " + e);
                }
            }
        }
    }

	protected Object _getUpdateableValue(int masterRowIndex)

	{
		String updMasterColDataItemName = getListValueDataItemName();
		ImmediateAccess ia = null;

		if (updMasterColDataItemName == null)
		{
			// use the key column
			ia = ((ImmediateAccess)_selectedItem);
		}
		else
		{
			// get update value from value column
			int col  = _getUpdateableColumnIndex(updMasterColDataItemName);
			int row  = masterRowIndex;
			ia = (ImmediateAccess)_getItemFromCursor(row, col);
		}

		if (ia != null)
			return ia.getValueAsObject();
		else 
			return null;
	}

	
	// notification to drop dataitem refernces
    protected void _releaseResourcesInternal(InfoBusManagerReleaseEvent e)
    {
		_comboBox = null;
        _selectedItem = null;
        _detailItem = null;
        _rowsetForUpdateableItem = null;
		_valueLocator = null;
		super._releaseResourcesInternal(e);
    }

	private int _getUpdateableColumnIndex(String dataItemName)
	{
		
		String updMasterColName = _getColumnNameFromDataItemName(dataItemName);
		int index = super._findColumnIndex(updMasterColName);
		return (index -1);
	}


    // Navigatable ComboBoxModel Implementataion
    /**
    * change the selected index
    *
    * @param _newIndex new index
    */
    public final void setSelectedIndex(int _newIndex)
    {
        // We are in navigate mode, move to a new index
        if (_comboBox.getDataItemUsageMode() ==
            DualBindingControl.FOR_NAVIGATION)
        {
            if (_newIndex >= 0)
            {
                setSelection(_newIndex);
            }
            fireContentsChanged(this, -1, -1);
        }
    }


    /**
    * get the selected item
    *
    * @return the selected item
    */
    public Object getSelectedItem()
    {
		return _selectedItem;
    }

	protected void setSelectedItemInternal(ImmediateAccess item)
	{
        _selectedItem = item;
	}

    private int _getIndex(Object anObject)
    {
        int _size = getSize();
        
        if ((null == anObject) || !(anObject instanceof ImmediateAccess))
        {
            return -1;
        }
        
        ImmediateAccess comparer;
        Object _testObject;
        ImmediateAccess comparee = (ImmediateAccess) anObject;
        for (int i = 0; i < _size; i++)
        {
            _testObject = getElementAt(i);
            if ((_testObject != null) &&
                (_testObject instanceof ImmediateAccess))
            {
                comparer = (ImmediateAccess)_testObject;
                if (comparee.getValueAsString().equals(comparer.getValueAsString()))
                {
                    return i;
                }
            }
        }
        return -1;
    }

    void _selectedItemChanged(Object oldDataItem, Object newDataItem,
                              boolean force)
    {
        if ((_comboBox.getDataItemUsageMode() ==
             DualBindingControl.FOR_NAVIGATION) || (force))
        {
            if (newDataItem != null && newDataItem instanceof ImmediateAccess)
            {
				setSelectedItemInternal((ImmediateAccess)newDataItem);
            }
            fireContentsChanged(this, -1, -1);
        }
    }

    /**
    * get the current mode
    *
    * @return  a string representing the mode - navigate/update
    */
    public String getMode()
    {
        if (_comboBox.getDataItemUsageMode() ==
            DualBindingControl.FOR_NAVIGATION)
        {
            return new String("NAVIGATION");
        }
        else
        {
            return new String("UPDATE");
        }
    }

    // track the changes made
    void _selectedItemValueChanged(DataItemValueChangedEvent event)
    {
        Object  newDataItem = event.getChangedItem();
		ImmediateAccess ia = null;

		if (newDataItem != null && newDataItem instanceof ImmediateAccess)
			ia = (ImmediateAccess)newDataItem;

		Object src = event.getSource();

		DataItem di = (DataItem) ia;
		if (di != null)
		{
			String diname = (String)di.getProperty(oracle.dacf.dataset.DataItemProperties.NAME);

		    if (diname.equals(_comboBox.getDataItemNameForUpdate()))
			{
				_detailItem = ia;
				_syncSelectionWithDetailColumnValue(ia);
				fireContentsChanged(this, -1, -1);
			}
		}
    }

	// update selection based on detail column value
    protected void _syncSelectionWithDetailColumnValue(ImmediateAccess item)
	{
		ScrollableRowsetAccess master = super.getRowsetAccess();
		ScrollableRowsetAccess detail= getRowsetAccessForUpdateableItem();

		ValueLocator loc = getValueLocator();
                if (item.getValueAsObject() == null && loc.getNullValuesAllowed(
))
                {
                   setSelectedItemInternal(item);
                }
                else
                {
                   int index = loc.findIndexInMaster(item, master, detail);

                   if (index != -1)
                   {
                      Object value = super.getElementAt(index);
                      setSelectedItemInternal((ImmediateAccess)value);
                   }
                }

	}

	protected ScrollableRowsetAccess getRowsetAccessForUpdateableItem()
	{
		if (_rowsetForUpdateableItem == null)
		{
			String diname = _comboBox.getDataItemNameForUpdate();
			String rsDataItemName = _getParentDataItemName(diname);

			SimpleInfoBusConsumer c = new SimpleInfoBusConsumer();
            _rowsetForUpdateableItem = c.findScrollableRowsetAccess(rsDataItemName);
		}
		return _rowsetForUpdateableItem;
	}


	// find the index of object in the list
	// Object o one of the items from the list
	protected int _itemToIndex(Object o)
	{
		for (int i=0; i < getSize(); i++)
		{
			Object x = super.getElementAt(i);

			if ( x == o)
				return i;
		}

		return -1;

	}

	protected void rowsAvailable()
	{
		super.rowsAvailable();

		boolean b = super.isCachingEnabled();

		if ( b)
	    {
			if (_cachedSelectedItemInvalid == true)
			{
				if (_oldSelectedItemValue != null) 
				{
					int rc = getSize();
	
					for (int i=0; i < rc; i++) 
					{
						Object o = getElementAt(i);
	
						if ((o != null)  && ( o instanceof ImmediateAccess))
						{
							ImmediateAccess ia = (ImmediateAccess)o;
							
							Object val = ia.getValueAsObject();
	
							if ( val.equals(_oldSelectedItemValue))
							{
								_selectedItem = (ImmediateAccess)o;
							}
						}
					}
				}
				_cachedSelectedItemInvalid = false;
			}
		}
	}

	protected void rowsRevoked()
	{
		boolean b = super.isCachingEnabled();

		if (b) 
		{
			_cachedSelectedItemInvalid = true;

			if (_selectedItem != null)
			{
				_oldSelectedItemValue = _selectedItem.getValueAsObject();
			}
			else
				_oldSelectedItemValue = null;
		}
		

		super.rowsRevoked();
	}

	
	private String _getParentDataItemName(String columnDataItemName)
	{
		int i = columnDataItemName.lastIndexOf(DacObject.ITEMNAME_DELIMITER);
		if (i != -1)
			return columnDataItemName.substring(0,i);

		return columnDataItemName;
		
	}


	private String _getColumnNameFromDataItemName(String dataItemName)
	{
		int i = dataItemName.lastIndexOf(DacObject.ITEMNAME_DELIMITER);

		if (i != -1)
			return dataItemName.substring(i+1);

		return null;
	}

    private boolean _canChangeSelection()
    {
        // _debug(" Can change Selection ");
        NavigationManager nm = NavigationManager.getNavigationManager();
        return nm.validateFocusChange(_comboBox);
    }


    /**
    * get string representation
    *
    * @return string representation
    */
    public String toString()
    {
        return (getClass().getName());
    }

    private void _debug(String msg)
    {
        if (_DEBUG)
        {
            synchronized(this)
            {
                System.out.println(Thread.currentThread().getName()+ " "+ msg);
            }
        }
    }

	public interface ValueLocator
	{
		public int findIndexInMaster(
                   ImmediateAccess searchFor
                   , ScrollableRowsetAccess masterRowset
                   , ScrollableRowsetAccess detailRowset);

		public void updateKeyColumnName(
                   String newListValueDataItemName, ComboBoxControl c);

                public boolean getNullValuesAllowed();
                public void setNullValuesAllowed(boolean nullValuesAllowed);
	}
}

