/*
 * @(#)DualBindingControl.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.dacf.control;

/**
 */
public interface DualBindingControl 
{
	// dataItemNameUsageMode constants
	static final public int FOR_UPDATE  									 = 0;
	static final public int FOR_NAVIGATION									 = 1;

    public void setDataItemNameForUpdate(String valueDataItemName);

    public String getDataItemNameForUpdate();

    public void setDataItemUsageMode(int usage);

    public int getDataItemUsageMode();
}
