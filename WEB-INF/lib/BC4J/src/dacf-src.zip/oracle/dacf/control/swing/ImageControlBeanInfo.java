/*
 * @(#)ImageControlBeanInfo.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.dacf.control.swing;

/**
 * bean info class for the Image control
 *
 * @version SDK
 */
public class ImageControlBeanInfo extends ControlBeanInfoHelper
{
  /**
  * Constructor
  */
  public ImageControlBeanInfo()
  {
    super();
  }

  /**
  * get the Class object for the bean described by this beaninfo class
  *
  * @return the Class object for the bean
  */
  protected Class getBeanClass()
  {
    return ImageControl.class;
  }

} 
