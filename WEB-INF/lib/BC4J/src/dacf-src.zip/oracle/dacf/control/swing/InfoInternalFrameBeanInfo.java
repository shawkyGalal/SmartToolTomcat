/*
 * @(#)InfoInternalFrameBeanInfo.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.dacf.control.swing;

import java.beans.BeanInfo;
import java.beans.IntrospectionException;
import java.beans.Introspector;
import java.beans.PropertyDescriptor;
import java.beans.SimpleBeanInfo;

/**
 * BeanInfo implementation for InfoFrame.
 *
 * @version SDK
 */
public class InfoInternalFrameBeanInfo extends SimpleBeanInfo
{
   /**
   * list of properties for the InfoFrame
   */
   private String [][] propertyList = new String[][] {
     { "infoBusName", "getInfoBusName", "setInfoBusName", null},
     {"dataItemName", "getDataItemName", "setDataItemName",
          "oracle.jdeveloper.daceditors.DataItemNameEditor"} };

   /**
    * Returns the property descriptors for the bean
    * @see java.beans.BeanInfo#getPropertyDescriptors()
    */
  public PropertyDescriptor[] getPropertyDescriptors()
  {
      try
      {
          PropertyDescriptor infoBusName =
                new PropertyDescriptor("infoBusName", getBeanClass(),
                                       "getInfoBusName", "setInfoBusName");
          PropertyDescriptor dataItemName  =
            new PropertyDescriptor("dataItemName", getBeanClass(),
                "getDataItemName", "setDataItemName");

          PropertyDescriptor closed  =
            new PropertyDescriptor("close", getBeanClass(),
                "isClosed", "setClosed");

          closed.setHidden(true);

         PropertyDescriptor[] pdarr = { infoBusName, dataItemName, closed };
         return pdarr;
      }
      catch (Exception e)
      {
         e.printStackTrace(System.err);
         return null;
      }

  }

  /**
   *  Returns the class of the bean this BeanInfo describes
   *  @return returns InfoInternalFrame.class
   */
  protected Class getBeanClass()
  {
    return InfoInternalFrame.class;
  }

   /**
    * Returns the property descriptors for the bean superclass
    * @see java.beans.BeanInfo#getAdditionalBeanInfo()
    */

   public BeanInfo[] getAdditionalBeanInfo()
   {
      try
      {
        BeanInfo bi = Introspector.getBeanInfo(getBeanClass().getSuperclass());
        BeanInfo[] biarr = {bi};
        return biarr;
      }
      catch(IntrospectionException e)
      {
         e.printStackTrace(System.err);
         return null;

      }
   }


}
