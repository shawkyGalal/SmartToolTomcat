/*
 * @(#)TreeQueryListener.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.dacf.control.swing;

import oracle.dacf.dataset.Query;
import oracle.dacf.dataset.QueryListener;
import oracle.dacf.dataset.RowSetInfo;

// imports
/**
 **      This class serves to synchronize changes to and execution of a query
 **      between between the original RowSet defining a node level in the tree
 **      and the one really used to produce the data.
 **
 **      @version SDK
 */
public class TreeQueryListener
    implements QueryListener
{
    RowSetInfo _des;
    RowSetInfo _src;
    String[] _fKeys;
    
    private static final boolean _DEBUG = true;
    
    public TreeQueryListener(RowSetInfo des, RowSetInfo src, String[] fKeys)
    {
        _des = des;
        _src = src;
        _fKeys = fKeys;
    } // TreeQueryListener

    public void register()
    {
        if (_src != null && _des != null)
        {
            _src.addQueryListener(this);
        }
    }

    public void unregister()
    {
        if (_src != null)
        {
           _src.removeQueryListener(this);
        }
    }

    public void whereClauseChanged(String nwc)
    {
        String wc = nwc;

        if (_fKeys != null)
        {
            if (wc != null)
            {
                wc = "(" + wc + ")";
            }
            for(int j = 0; j < _fKeys.length; j++)
            {
                if (wc != null)
                {
                    wc = wc + " and (" + _fKeys[j] + " is null)";
                }
                else
                {
                    wc = "(" + _fKeys[j] + " is null)";
                }
            }
        }
        _des.setQueryCondition(wc);
    }
    
    public void orderbyClauseChanged(String oc)
    {
        _des.setQueryOrderbyClause(oc);
    }
    
    public void queryParamsChanged(Object[] params)
    {
        _des.setQueryConditionParams(params);
    }
    
    public void queryDefChanged(Query q)
    {
        _des.setQueryInfo(q);
    }
    
    public void queryExecuted()
    {
        _des.executeQuery();
    }

    private static void _debug(String s)
    {
        if (_DEBUG)
        {
            System.out.println("TreeQueryListener: " + s);
        }        
    } // _debug
    
}  // TreeQueryListener


