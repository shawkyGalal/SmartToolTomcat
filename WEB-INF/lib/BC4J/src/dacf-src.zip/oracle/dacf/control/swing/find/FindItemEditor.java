/*
 * @(#)FindItemEditor.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.dacf.control.swing.find;

/**
 *  An interface which lets you use custom editors in the FindPanel
 *
 *  When custom editor is used, DacFindPanelUI will display a button 
 *  next to the find item textfield. The end user can either directly
 *  specify a value in the textfield or click  the button to bring up 
 *  an custom editor like an LOV.
 *
 *  @see FindPanel
 *  @see DacFindPanelUI
 */
public interface FindItemEditor
{
     /**
     *  use the custom editor. 
     *
     *  @param  model representing the column
     *  @param  initValue  initial value specified in the textfield
     *  @return the value the user specified in the custom editor
     */
     Object editItem(FindItemModel model, Object initValue);
}
