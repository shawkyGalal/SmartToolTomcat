/*
 * @(#)GridControlBeanInfo.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.dacf.control.swing;

import java.beans.PropertyDescriptor;

/**
 * bean info class for the grid control
 *
 * @version SDK
 */
public class GridControlBeanInfo extends ControlBeanInfoHelper
{
    /**
    * Constructor
    */
    public GridControlBeanInfo()
    {
        super();
    }

    /**
    * get property descriptors specific to the combo box
    *
    * @return property descriptors for the combo box
    */
    protected Class getBeanClass()
    {
        return GridControl.class;
    }

    /**
    * get property descriptors specific to the combo box
    *
    * @return property descriptors for the combo box
    */
    protected PropertyDescriptor[] getAdditionalPropertyDescriptors()
    {
        try
        {
            // begin JTable exposed properties

            PropertyDescriptor  autoCreateColumnsFromModel =
                new PropertyDescriptor("autoCreateColumnsFromModel",
                                       getBeanClass(),
                                       "getAutoCreateColumnsFromModel",
                                       "setAutoCreateColumnsFromModel");

            PropertyDescriptor autoResizeMode =
                new PropertyDescriptor("autoResizeMode",
                                       getBeanClass(),
                                       "getAutoResizeMode",
                                       "setAutoResizeMode");

            //      PropertyDescriptor cellEditor =
            //            new PropertyDescriptor("cellEditor", getBeanClass(),
            //                "getCellEditor", "setCellEditor");

            PropertyDescriptor  cellSelectionEnabled =
                new PropertyDescriptor("cellSelectionEnabled",
                                       getBeanClass(),
                                       "getCellSelectionEnabled",
                                       "setCellSelectionEnabled");

            PropertyDescriptor  columnModel =
                new PropertyDescriptor("columnModel",
                                       getBeanClass(),
                                       "getColumnModel",
                                       "setColumnModel");

            PropertyDescriptor  columnSelectionAllowed =
                new PropertyDescriptor("columnSelectionAllowed",
                                       getBeanClass(),
                                       "getColumnSelectionAllowed",
                                       "setColumnSelectionAllowed");

            PropertyDescriptor editingColumn =
                new PropertyDescriptor("editingColumn",
                                       getBeanClass(),
                                       "getEditingColumn",
                                       "setEditingColumn");

            PropertyDescriptor editingRow =
                new PropertyDescriptor("editingRow",
                                       getBeanClass(),
                                       "getEditingRow",
                                       "setEditingRow");

            PropertyDescriptor gridColor =
                new PropertyDescriptor("gridColor",
                                       getBeanClass(),
                                       "getGridColor",
                                       "setGridColor");

            PropertyDescriptor intercellSpacing =
                new PropertyDescriptor("intercellSpacing",
                                       getBeanClass(),
                                       "getIntercellSpacing",
                                       "setIntercellSpacing");

            PropertyDescriptor model =
                new PropertyDescriptor("model",
                                       getBeanClass(),
                                       "getModel",
                                       "setModel");

            PropertyDescriptor preferredScrollableViewportSize =
                new PropertyDescriptor("preferredScrollableViewportSize",
                                       getBeanClass(),
                                       "getPreferredScrollableViewportSize",
                                       "setPreferredScrollableViewportSize");

            PropertyDescriptor rowHeight =
                new PropertyDescriptor("rowHeight",
                                       getBeanClass(),
                                       "getRowHeight",
                                       "setRowHeight");

            PropertyDescriptor  rowMargin =
                new PropertyDescriptor("rowMargin",
                                       getBeanClass(),
                                       "getRowMargin",
                                       "setRowMargin");

            PropertyDescriptor rowSelectionAllowed =
                new PropertyDescriptor("rowSelectionAllowed",
                                       getBeanClass(),
                                       "getRowSelectionAllowed",
                                       "setRowSelectionAllowed");

            PropertyDescriptor selectionBackground =
                new PropertyDescriptor("selectionBackground",
                                       getBeanClass(),
                                       "getSelectionBackground",
                                       "setSelectionBackground");

            PropertyDescriptor selectionForeground =
                new PropertyDescriptor("selectionForeground",
                                       getBeanClass(),
                                       "getSelectionForeground",
                                       "setSelectionForeground");

            PropertyDescriptor selectionModel =
                new PropertyDescriptor("selectionModel",
                                       getBeanClass(),
                                       "getSelectionModel",
                                       "setSelectionModel");

            PropertyDescriptor showHorizontalLines =
                new PropertyDescriptor("showHorizontalLines",
                                       getBeanClass(),
                                       "getShowHorizontalLines",
                                       "setShowHorizontalLines");

            PropertyDescriptor showVerticalLines =
                new PropertyDescriptor("showVerticalLines",
                                       getBeanClass(),
                                       "getShowVerticalLines",
                                       "setShowVerticalLines");

            PropertyDescriptor tableHeader =
                new PropertyDescriptor("tableHeader",
                                       getBeanClass(),
                                       "getTableHeader",
                                       "setTableHeader");

            // end JTable exposed properties

            PropertyDescriptor focusedSelectionForeground =
                new PropertyDescriptor("focusedSelectionForeground",
                                       getBeanClass(),
                                       "getFocusedSelectionForeground",
                                       "setFocusedSelectionForeground");

            PropertyDescriptor focusedSelectionBackground =
                new PropertyDescriptor("focusedSelectionBackground",
                                       getBeanClass(),
                                       "getFocusedSelectionBackground",
                                       "setFocusedSelectionBackground");

            PropertyDescriptor unfocusedSelectionForeground =
                new PropertyDescriptor("unfocusedSelectionForeground",
                                       getBeanClass(),
                                       "getUnfocusedSelectionForeground",
                                       "setUnfocusedSelectionForeground");

            PropertyDescriptor unfocusedSelectionBackground =
                new PropertyDescriptor("unfocusedSelectionBackground",
                                       getBeanClass(),
                                       "getUnfocusedSelectionBackground",
                                       "setUnfocusedSelectionBackground");

            PropertyDescriptor autoRowNavigation =
                new PropertyDescriptor("autoRowNavigation",
                                       getBeanClass(),
                                       "isAutoRowNavigation",
                                       "setAutoRowNavigation");

            PropertyDescriptor scrollToSelectedRow =
                new PropertyDescriptor("scrollToSelectedRow",
                                       getBeanClass(),
                                       "isScrollToSelectedRow",
                                       "setScrollToSelectedRow");


            PropertyDescriptor tableBackground =
                new PropertyDescriptor("tableBackground",
                                       getBeanClass(),
                                       "getTableBackground",
                                       "setTableBackground");

            PropertyDescriptor tableForeground =
                new PropertyDescriptor("tableForeground",
                                       getBeanClass(),
                                       "getTableForeground",
                                       "setTableForeground");

            PropertyDescriptor[] ret = { autoCreateColumnsFromModel,
                                         autoResizeMode,/* cellEditor,*/
                                         cellSelectionEnabled,
                                         columnModel, columnSelectionAllowed,
                                         editingColumn,
                                         editingRow, gridColor,
                                         intercellSpacing, model,
                                         preferredScrollableViewportSize,
                                         rowHeight, rowMargin,
                                         rowSelectionAllowed,
                                         selectionBackground,
                                         selectionForeground,
                                         selectionModel, showHorizontalLines,
                                         showVerticalLines,
                                         tableHeader, autoRowNavigation,
                                         tableBackground,
                                         tableForeground,
                                         focusedSelectionForeground,
                                         focusedSelectionBackground,
                                         unfocusedSelectionForeground,
                                         unfocusedSelectionBackground,
                                         scrollToSelectedRow};
            return(ret);
        }
        catch(Exception exc)
        {
            exc.printStackTrace();
            return(null);
        }
    }


}
