/*
 * @(#)Control.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.dacf.control;

import java.awt.Component;
import javax.infobus.DataItemChangeListener;

/**
 * All data-aware controls that plug into the runtime framework
 * must implement this interface. <P>
 *
 * The <TT>ControlSupport</TT> class provides default implementations for
 * all of the methods in this interface, except for the following methods: <P>
 * <UL>
 * <LI><TT>dataItemChanged</TT>
 * <LI><TT>getComponent</TT>
 * <LI>all methods inherited from the <TT>DataItemChangeListener</TT> interface
 * </UL>
 * Those methods must be implemented directly by the data aware control
 * itself. <P>
 *
 */
public interface Control extends DataItemChangeListener
{
    // InfoBus support

    /**
    ** The name of the default InfoBus that controls will connect to
    ** if they do not have a different InfoBus specified via their
    ** <TT>setInfoBusName</TT> method. <P>
    ** @see #setInfoBusName
    */
    public static final String DEFAULT_INFOBUS_NAME = "oracle";


    /**
    ** The event property for the initial row affected by an event.
    ** @see javax.infobus.DataItemChangeEvent#getProperty
    */
    public static final String EVENT_PROPERTY_ROW = "Row";

    /**
    * The event property for the number of rows affected by an event.
    * @see javax.infobus.DataItemChangeEvent#getProperty
    */
    public static final String EVENT_PROPERTY_ROW_COUNT = "RowCount";

    public static final String EVENT_PROPERTY_VIEW_CHANGE = "ViewChange";
    public static final String EVENT_PROPERTY_ROW_CHANGE = "RowChange";
    public static final String EVENT_PROPERTY_VIEW_SCROLLED = "ViewScrolled";
    public static final String EVENT_PROPERTY_VIEW_REFRESHED = "ViewRefreshed";

    /**
    *  attribute to indicate a column should be displayed., when the
    *  control is initially displayed. The column can be however 'hidden',
    *  later if needed.
    *
    *  @see ColumnInfo setColumnDisplayAttribute
    */
    public static final int  SHOW=0;

    /**
    *  attribute to indicate a column should be hidden.,
    *  control is initially hidden. The column can be however 'displayed',
    *  later if needed.

    *  with the option of 'showind' it.
    *
    *  @see ColumnInfo setColumnDisplayAttribute
    */
    public static final int  HIDE=1;


    /**
    *  attribute to indicate a column should not be included.
    *  The behaviour is similair to hide attribute, except that the
    *  column cannot be 'displayed'.
    *
    *  @see ColumnInfo setColumnDisplayAttribute
    */
    public static final int  EXCLUDE=2;

    /**
    ** An override of java.awt.Component.setEnabled.<P>
    **
    ** A control implements this method and delegates the call to
    ** <tt>ControlSupport</tt>.
    **
    ** @param b boolean flag indicating whether the control is enabled
    */
    public void setEnabled(boolean b);

    /**
    ** Returns the name of the InfoBus this control is connected to. <P>
    **
    ** Most controls should delegate this method to <TT>ControlSupport</TT>.
    **
    ** @return  The name of the InfoBus this control is connected to.
    ** @see ControlSupport#getInfoBusName
    */
    public String getInfoBusName();

    /**
    ** Sets the name of the InfoBus this control is connected to. <P>
    **
    ** By default, the control is connected to the default InfoBus,
    ** named <TT>DEFAULT_INFOBUS_NAME</TT>. <P>
    **
    ** If the named InfoBus does not exist, it is created automatically. <P>
    ** If the control is already connected to an InfoBus, it is disconnected
    ** first. <P>
    **
    ** Most controls should delegate this method to <TT>ControlSupport</TT>.
    **
    ** @param infoBusName   The name of the InfoBus to connect to.
    ** @see #DEFAULT_INFOBUS_NAME
    ** @see ControlSupport#setInfoBusName
    */
    public void setInfoBusName(String infoBusName);

    /**
    * Returns the name of the InfoBus DataItem this control is bound to. <P>
    * Most controls should delegate this method to <TT>ControlSupport</TT>. <P>
    * @return  The name of the InfoBus DataItem this control is bound to,
    *          or <TT>null</TT> if the control is unbound.
    * @see #getDataItem
    * @see ControlSupport#getDataItemName
    */
    public String getDataItemName();

    /**
    ** Sets the name of the InfoBus DataItem this control is bound to. <P>
    **
    ** The DataItem with the given name is searched for on the InfoBus, and
    ** if found, is bound to this control. <P>
    **
    ** If the control is already bound to a DataItem, it is unbound first. <P>
    **
    ** Most controls should delegate this method to <TT>ControlSupport</TT>.
    ** @param dataItemName  The name of the DataItem to bind to.
    ** @see #getDataItem
    ** @see ControlSupport#setDataItemName
    */
    public void setDataItemName(String dataItemName);

    /**
    ** Returns the InfoBus DataItem this control is bound to. <P>
    **
    ** Most controls should delegate this method to <TT>ControlSupport</TT>.
    **
    ** @return  The InfoBus DataItem this control is bound to, or
    **          <TT>null</TT> if the control is unbound.
    ** @see ControlSupport#getDataItem
    */
    public Object getDataItem();

    /**
    ** Notifies the control that the bound InfoBus DataItem has changed. <P>
    **
    ** The control can safely ignore this notification.
    **
    ** @param oldDataItem   The formerly bound DataItem (can be <TT>null</TT>).
    ** @param newDataItem   The newly bound DataItem (can be <TT>null</TT>).
    */
    public void dataItemChanged(Object oldDataItem, Object newDataItem);


    // UI Control support

    /**
    ** Returns the AWT component associated with this control.
    **
    ** @return  The AWT component for this control.
    */
    public Component getComponent();


    // ValidationManager support

    /**
    ** Determines whether this control causes validation upon gaining focus.<P>
    **
    ** Most controls should delegate this method to <TT>ControlSupport</TT>.
    **
    ** @return  <TT>true</TT> if focus into this control causes validation to
    **          occur, <TT>false</TT> otherwise.
    ** @see ControlSupport#isFocusValidated
    */
    public boolean isFocusValidated();

    /**
    ** Sets whether focus into this control causes validation to occur. <P>
    **
    ** Most controls should delegate this method to <TT>ControlSupport</TT>.
    **
    ** @param focusValidated    If <TT>true</TT>, focus into this control will
    **                          cause validation to occur.
    ** @see ControlSupport#setFocusValidated
    */
    public void setFocusValidated(boolean focusValidated);


    // NavigationManager support

    /**
    ** Adds a navigated listener to this control. <P>
    **
    ** The listener will be notified of NavigateIn and NavigateOut events. <P>
    **
    ** Most controls should delegate this method to <TT>ControlSupport</TT>.
    **
    ** @param listener  The listener to add.
    ** @see ControlSupport#addNavigatedListener
    */
    public void addNavigatedListener(NavigatedListener listener);

    /**
    ** Removes a navigated listener from this control. <P>
    **
    ** Most controls should delegate this method to <TT>ControlSupport</TT>.
    **
    ** @param listener  The listener to remove.
    ** @see ControlSupport#removeNavigatedListener
    */
    public void removeNavigatedListener(NavigatedListener listener);

    /**
    ** Processes a navigated event for this control. <P>
    **
    ** This method is for use by the NavigationManager only. <P>
    **
    ** Most controls should delegate this method to <TT>ControlSupport</TT>.
    **
    ** @param event The navigated event.
    ** @see ControlSupport#processNavigatedEvent
    */
    public void processNavigatedEvent(NavigatedEvent event);

    /**
    ** Adds a navigating listener to this control. <P>
    **
    ** The listener will be notified of NavigateIn and NavigateOut events. <P>
    **
    ** Most controls should delegate this method to <TT>ControlSupport</TT>.
    **
    ** @param listener  The listener to add.
    ** @see ControlSupport#addNavigatedListener
    */
    public void addNavigatingListener(NavigatingListener listener);

    /**
    ** Removes a navigating listener from this control. <P>
    **
    ** Most controls should delegate this method to <TT>ControlSupport</TT>.
    **
    ** @param listener  The listener to remove.
    ** @see ControlSupport#removeNavigatedListener
    */
    public void removeNavigatingListener(NavigatingListener listener);

    /**
    ** Processes a navigating event for this control. <P>
    **
    ** This method is for use by the NavigatedManager only. <P>
    **
    ** Most controls should delegate this method to <TT>ControlSupport</TT>.
    **
    ** @param event The navigating event.
    ** @exception NavigatingException   If the navigation is redirected to a
    **                                  different control.
    ** @see ControlSupport#processNavigatedEvent
    */
    public void processNavigatingEvent(NavigatingEvent event)
        throws NavigatingException;
}
