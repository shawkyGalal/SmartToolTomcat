/*
 * @(#)DbAccessMonitor.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.dacf.control;

import java.awt.Component;
import java.util.Hashtable;
import java.util.Vector;
import javax.infobus.DataItem;
import javax.infobus.DbAccess;
import oracle.dacf.dataset.DataItemProperties;

/**
 * This class tracks a DbAccess item. More than one Component (frame, panel,
 * etc.) could depend on this object to track a DbAccess. The last Component
 * which call's terminate will cause this object to check if a transaction is
 * pending and alert user.
 *
 * @version INTERNAL
 */
public class DbAccessMonitor
    extends DbAccessSupport
    implements InfoBusManagerListener
{
    /**
    *  a list of Components interested in tracking this DbAccess item.
    */
    private static Vector  _componentList = new Vector(3);
    /**
    *  'alert' dialog to use for the component when terminated
    */
    private static Hashtable   _alertList = new Hashtable(3);

    private static final boolean _DEBUG = false;
    

    /**
    *  for those who don't want to use a custom alert
    */
    private IncompleteTransactionAlertImpl  _alert = 
        new IncompleteTransactionAlertImpl();
                       
    /**
    *  Constructor
    */
    protected DbAccessMonitor()
    {
        super();
        InfoBusManager.getInstance().addInfoBusManagerListener(this);
    }

    // InfoBusManagerListener interface implementation
    public void releaseResources(InfoBusManagerReleaseEvent e)
    {
        Component[] comps;

        synchronized(_componentList)
        {
            comps = new Component[_componentList.size()];

            _componentList.copyInto(comps);
        }

        if (comps == null || comps.length == 0 ||
            (comps.length == 1 && e.appliesTo(comps[0])))
        {
            InfoBusManager.getInstance().removeInfoBusManagerListener(this);
            removeInfoBusPropertyListener(this);
            dropInfoBus();
        }
        removeDbAccessClient(e.getContainer());
    }

    /**
    * addDbAccessClient - add a new object which is interested in tracking 
    *                     this DbAccess
    *
    * @param o          - object interested in our DbAccess item.
    *
    */
    public synchronized void addDbAccessClient(Object o)
    {
        addDbAccessClient(o, _alert);
    }

    /**
    * addDbAccessClient - add a new object which is interested in tracking 
    *                     this DbAccess
    *
    * @param o          - object interested in our DbAccess item.
    * @param alert      - user defined alert dialog
    *
    */
    public synchronized void
        addDbAccessClient(Object  o, IncompleteTransactionAlert alert)
    {
        _componentList.addElement(o);
        _alertList.put(o, alert);
    }

    /**
    * removeDbAccessClient - remove object which is no longer interested in
    *                        tracking this data item.
    *
    * @param o              - objected which no longer cares to track this 
    *                         DbAccess item.
    *
    */
    public void removeDbAccessClient(Object  o)
    {
        _alertList.remove(o);
        _componentList.removeElement(o);
    }

    /**
    * set the UI which should be used to alert
    *
    * @param o          - object interested in our DbAccess item.
    * @param alert      - user defined alert dialog
    */
    public void
        setIncompleteTransactionAlertUI(Object o,
                                        IncompleteTransactionAlert alert)
    {
        _alertList.put(o, alert);
    }

    /**
    *  terminateTransaction()
    *
    *  @param o - object which is terminating
    *  @param forceExit - force the user to exit ?. (do not show the cancel
    *                     button
    *
    *  clients would call this method to indicate that they want to terminate
    *  the transaction
    */
    // TODO : Once DbAccess.getProperty is implemented change this method
    // based on alert return value viz., commit/rollback
    public boolean terminateTransaction(Object  o, boolean forceExit)
    {
        DataItem di = (DataItem)getDataItem();
        boolean terminate = true;
        
        if ( _componentList.size() == 1)
        {
            // last element to remove, prompt user if needed
            if (di != null)
            {
                Boolean b =
                    (Boolean)di.getProperty(DataItemProperties.PENDING_CHANGES);
                if ( b.booleanValue() == true)
                {
                    IncompleteTransactionAlert alert =
                        (IncompleteTransactionAlert)_alertList.get(o);

                    if ( alert != null )
                    {
                        DbAccess dbAccess = (DbAccess)di;
                        boolean bContinue = false;

                        do
                        {
                            int userSelection = alert.promptUser(forceExit);

                            switch (userSelection)
                            {
                            case IncompleteTransactionAlert.SAVE_AND_EXIT :
                                {
                                    try
                                    {
                                        dbAccess.commitTransaction();
                                        terminate = true;
                                        bContinue = false;
                                    }
                                    catch(Exception exc)
                                    {
                                        bContinue = true;
                                    }
                                }
                                break;
                            case IncompleteTransactionAlert.DO_NOT_SAVE_BUT_EXIT :
                                try
                                {
                                    dbAccess.rollbackTransaction();
                                }
                                catch(Exception exc)
                                {
                                }
                                terminate = true;
                                bContinue = false;
                                break;
                            case IncompleteTransactionAlert.CANCEL_SAVE_AND_EXIT:
                                terminate = false;
                                bContinue=false;
                                break;
                            default :
                                _debug("DbAccessMonitor: bad prompt value");
                                terminate = false;
                                bContinue = false;
                            }
                        }
                        while (bContinue);
                    }
                }
            } 
        }
        
        if ( terminate )
        {
            _alertList.remove(o);
            _componentList.removeElement(o);
        }
        return terminate;
    }

    private void _debug(String msg)
    {
        if (_DEBUG)
        {
            System.out.println("DbAccessMonitor: " + msg);
        }
    }

}
