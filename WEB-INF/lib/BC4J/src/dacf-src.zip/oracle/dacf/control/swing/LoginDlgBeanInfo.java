/*
 * @(#)LoginDlgBeanInfo.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.dacf.control.swing;

import java.beans.BeanInfo;
import java.beans.PropertyDescriptor;
import java.beans.SimpleBeanInfo;

/**
 * BeanInfo implementation for LoginDlg.
 *
 * @version SDK
 */
public class LoginDlgBeanInfo extends SimpleBeanInfo
{
   /**
   * list of properties for the LoginDlg
   */
   private String [][] propertyList = new String[][]
   {
     // hidden attributes
     {"showDbAccessDescriptor", "isShowDbAccessDescriptor", "setShowDbAccessDescriptor", null},
     {"showDeploymentPlatform", "isShowDeploymentPlatform", "setShowDeploymentPlatform", null},
     {"showConnectionMode", "isShowConnectionMode", "setShowConnectionMode", null},
     {"showApplicationModuleType", "isShowApplicationModuleType", "setShowApplicationModuleType", null},
     //
     {"dataItemName", "getDataItemName", "setDataItemName","oracle.jdeveloper.daceditors.DataItemNameEditor"},
     {"infoBusName", "getInfoBusName", "setInfoBusName", null},
     {"showUser", "isShowUser", "setShowUser", null},
     {"showPassword", "isShowPassword", "setShowPassword", null},
     {"showDatabaseURL", "isShowDatabaseURL", "setShowDatabaseURL", null},
     {"showDriverType", "isShowDriverType", "setShowDriverType", null},
     {"showConnectionURL", "isShowConnectionURL", "setShowConnectionURL", null},
     {"showConnectionNames", "isShowConnectionNames", "setShowConnectionNames", null},
     {"showIIOPConnectionNames", "isShowIIOPConnectionNames", "setShowIIOPConnectionNames", null},
     {"showApplicationModuleClass", "isShowApplicationModuleClass", "setShowApplicationModuleClass", null},
     {"showLockingMode", "isShowLockingMode", "setShowLockingMode", null},
     {"showServerTimeout", "isShowServerTimeout", "setShowServerTimeout", null},
     {"showRemoteApplicationPath", "isShowRemoteApplicationPath", "setShowRemoteApplicationPath", null}
   };

   /**
    * Returns the property descriptors for the bean
    * @see java.beans.BeanInfo#getPropertyDescriptors()
    */
  public PropertyDescriptor[] getPropertyDescriptors()
  {

     int listLength = propertyList.length;
      try
      {
         PropertyDescriptor[] pdarr = new PropertyDescriptor[listLength];

         for (int i = 0 ; i < listLength ; i++)
         {
            pdarr[i] = new PropertyDescriptor(propertyList[i][0],
                                              getBeanClass(),
                                              propertyList[i][1],
                                              propertyList[i][2]);

            if(propertyList[i][3] != null)
            {
               try
               {
                 pdarr[i].setPropertyEditorClass(Class.forName(propertyList[i][3]));
               }
               catch(ClassNotFoundException ex)
               {
                 ex.printStackTrace(System.err);
               }
            }
         }

         pdarr[0].setHidden(true);
         pdarr[1].setHidden(true);
         pdarr[2].setHidden(true);
         pdarr[3].setHidden(true);

         return pdarr;

      }
      catch (Exception e)
      {
         e.printStackTrace(System.err);
         return null;
      }
  }

  /**
   *  Returns the class object of the bean this BeanInfo describes
   *  @return returns LoginDlg.class
   */
  protected Class getBeanClass()
  {
    return LoginDlg.class;
  }

 }
