/*
 * @(#)NavigationManager.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.dacf.control;

import java.awt.Component;
import java.util.Vector;
import javax.infobus.DataItem;
import javax.infobus.ImmediateAccess;
import javax.swing.SwingUtilities;
import oracle.dacf.activity.ActivityMonitor;
import oracle.dacf.activity.DacActivities;
import oracle.dacf.control.Control;
import oracle.dacf.control.swing.lov.LOVInterface;
import oracle.dacf.dataset.AttributeInfo;
import oracle.dacf.dataset.DacfSeverity;
import oracle.dacf.dataset.DacfType;
import oracle.dacf.dataset.DataSourceOperationException;
import oracle.dacf.dataset.ExceptionProcessor;
import oracle.dacf.dataset.InfoObject;
import oracle.dacf.dataset.ValidationException;
import oracle.dacf.dataset.ValidationManager;
import oracle.dacf.util.ItemNameTokenizer;

/**
 *  This class arbitrates the focus changes between Data aware controls
 *  <TT>Control</TT>. A control must ask the NavigationManager
 *  if it can receive focus or not. <P> NavigationManager keeps track of the
 *  currently focused control. Upon receiving a focus change request
 *  makes use of the <TT>ValidationManager</TT>
 *  to validate the dataitem bound to the currently focused control.
 *  If the dataitem is valid the request is approved else it is rejected.</P>
 *  Also, If the request is approved the requesting control is marked as
 *  current else focus is redirected to the current control. </P>
 *  The NavigationManager is implemented as a Singleton and the clients of this
 *  class must use the <code>getNavigationManager()</code> method to get an
 *  instance.
 *
 *  @version  PUBLIC
 *  @see ValidationManager
 */
public class NavigationManager
{
    private static final boolean _DEBUG = false;

    private Control _target;
    private Control _focused;
    private boolean _focusedIsInvalid;
    private String _focusedItemName;
    private String _targetItemName;
    private boolean _applyEditsFailed=false;
    private boolean _disableLOV = false;
    private Vector _currencyListeners;
    
    // Assuming dataItems names are of the form
    // infobus:/busName/Session/Iter/Col
    private static int MAX_ITEMNAME_COMPONENTS = 5;

    private static NavigationManager _sManager;

    protected static final String ERR_PROD_CODE =
        Res.getString(Res.ERR_PRODUCT_CODE);

    /**
    ** NavigationManager is implemented as a singleton and cannot be
    ** instantiated directly. Clients must use the getNavigationManager()
    ** method to get an instance</P>
    **
    ** @see NavigationManager#getNavigationManager()
    */
    protected NavigationManager()
    {
        _currencyListeners = new Vector();
        setDisableLOV(false);
    }

    //Public Methods

    /**
    **  Validation the current focused control. <P>
    **
    **  Validation is performed only at the Attribute level.  This means that
    **  only the Attribute validation listeners are called.
    **
    **  @return TRUE if the control validations at the ATTRIBUTE level
    */
    public boolean validateFocusedControl()
    {
        return(validateFocusedControl(InfoObject.LEVEL_COLUMN));
    }

    /**
    **  Validation the current focused control. <P>
    **
    **  Validation is performed only upto and including specified level.
    **  The allowed values are:
    **  <ul>
    **  <li>InfoObject.LEVEL_ATTRIBUTE
    **  <li>InfoObject.LEVEL_ROW
    **  <li>InfoObject.LEVEL_ROWSET
    **  <li>InfoObject.LEVEL_SESSION
    **  </ul>
    **
    **  @return TRUE if the control validations at the specified level
    */
    public boolean validateFocusedControl(int changeLevel)
    {
        boolean rc = true;

        if (_focused != null)
        {
            int scrValidationLevel = ValidationManager.VALID; // not used
            
            rc = _performValidation(changeLevel, scrValidationLevel);
        }
        return(rc);
    }

    /**
    **  Lets the NavigationManager know that the currently focused control
    **  is invalid and all requests to change focus should be ignored.
    */
    public void focusedIsInvalid(boolean isInvalid)
    {
        _focusedIsInvalid = isInvalid;
    }

    /**
    * This method validates a focus change request from a control</P>
    *
    * If the focus request can be honored and the target control has an
    * LOV associated with it and it is to be displayed upon navigation, then
    * the LOV will be displayed.
    *
    * @param newFocus  Control requesting to receive focus.
    * @return   true if the requesting control can receive focus else false
    */
    public boolean validateFocusChange(Control newFocus)
    {
        boolean result = true;
        Control oldFocused = _focused;
        String newFocusName =
            newFocus == null ? null : newFocus.getDataItemName();

        if (newFocus != null || _focused != null)
        {
            // Moving focus between
            // _debug("enter validateFocusChange " + _focusedItemName + "-->" +
            //        newFocusName);

            // Are we  receiving focus on a control
            // as a result of previuos target being revoked
            if (_focused != newFocus)
            {
                // Ask currently focused component to apply it's changes
                //_callApplyEdits();

                synchronized(this)
                {
                    _target = newFocus;
                    _targetItemName = newFocusName;
                }

                if (_focused != null && _target != null)
                {
                    result = _canChangeFocus(false);
                }

                if (result) // New current control
                {
                    _switchFocused();
                    // display LOV
                    if (getDisableLOV() == false)
                    {
                        displayLOV(_focusedItemName);
                    }
                }
                else
                {
                    synchronized(this)
                    {
                        _focusedIsInvalid = true;
                        if ( _applyEditsFailed )
                        {
                            _focusedIsInvalid = false;
                        }
                    }
                    _restoreFocus(result);
                }
            }
        }

        // _debug("exit validateFocusChange Focused: " + _focusedItemName);
        return(result);
    }

    /**
    * This method allows a Container to request a focus change amongst
    * it's child controls. <P>
    *
    * Containers are responsible for managing the display of LOVs after the
    * the tow currency has been changed.
    *
    * @param  container   Composite control requesting focus change
    * @param  fromItemName Name of dataItem bound to child loosing the focus
    * @param  toItemName   Name of dataItem bound to child receiving the focus
    * @param  rowChange    <TT>true</TT> if the source and target child are
    *                      currently bound to a different row otherwise
    *                      <TT>false</TT>
    * @return  <TT>true</TT> if the change is approved otherwise returns
    *          <TT>false</TT>
    */
    public boolean validateFocusChange(Control container, String fromItemName,
                                       String toItemName, boolean rowChange)
    {
        boolean result;
        Control oldFocused = _focused;


        synchronized(this)
        {
            _target = container;
            if (fromItemName != null)
            {
                _focusedItemName = fromItemName;
            }
            _targetItemName = toItemName;
        }
        
        // _debug("validateFocusChange Container (enter):" + fromItemName +
        //        "-->" + toItemName);

        //_callApplyEdits();
        if (_focusedItemName != null)
        {
            result = _canChangeFocus((fromItemName != null && rowChange));
        }
        else
        {
            result = (toItemName != null);
            if (result && _target != null &&
                _target instanceof ContainerControl)
            {
                result = ((ContainerControl)_target).changeCurrency();
            }
            if (result)
            {
                result =
                    _fireNavigationEvents(_getChangeLevel(_targetItemName,
                                                          _focusedItemName,
                                                          true),
                                          ValidationManager.VALID);
            }
        }
        
        if (result)
        {
            _switchFocused();
            // display LOV
            if (getDisableLOV() == false)
            {
                displayLOV(_focusedItemName);
            }
        }
        else
        {
            synchronized(this)
            {
                _focusedIsInvalid = true;
                if ( _applyEditsFailed )
                {
                    _focusedIsInvalid = false;
                }
            }
            // _restoreFocus(result);
        }

        // _debug("validateFocusChange Container (exit): " + _targetItemName);
        return(result);
    }

    /**
    * Gets an instance of the NavigationManager. <P>
    * @return  the NavigationManager
    */
    public static NavigationManager getNavigationManager()
    {
        if (_sManager == null)
        {
            _sManager = new NavigationManager();
        }

        return (_sManager);
    }

    /**
    * Returns the control requesting a focus change</P>
    * @return the control requesting a focus change
    */
    public Control getTargetControl()
    {
        return _target;
    }

    /**
    ** Returns the name of the DataItem associated with the target control. <P>
    ** @return the name of the DataItem associated with the target control
    */
    public String getTargetDataItemName()
    {
        return(_targetItemName);
    } // getTargetDataItemName

    /**
    * Returns the currently focused control </P>
    * @return the currently focused control
    */
    public Control getFocusedControl()
    {
        return(_focused);
    }

    /**
    ** Returns the name of the DataItem associated with the focused control <P>
    ** @return the name of the DataItem associated with the focused control
    */
    public String getFocusedDataItemName()
    {
        return(_focusedItemName);
    } // getFocusedDataItemName


    /**
    ** Adds a CurrencyListern as a listener on all CurrencyChanged events. <P>
    **
    ** @param control An instance of Control that inplements CurrencyListener
    ** @see #removeCurrencyListener(Control control)
    */
    public void addCurrencyListener(Control control)
    {
        if (control instanceof CurrencyListener)
        {
            _currencyListeners.addElement(control);
        }
    } // addCurrencyListener

    /**
    ** Removes a Control as a listener on all CurrencyChanged events. <P>
    **
    ** @param control An instance of Control that inplements CurrencyListener
    ** @see #addCurrencyListener(Control control)
    */
    public void removeCurrencyListener(Control control)
    {
        if (control instanceof CurrencyListener)
        {
            _currencyListeners.removeElement(control);
        }
    } // removeCurrencyListener


    /**
    * This property controls whether the Navigation manager
    * display the LOV dialog or not. By default the Navigation
    * manager checks for the LOV and displays it
    *
    * @disableLOV - if true the NavigationManager will not display the
    *               LOV dialog
    */
    public void setDisableLOV(boolean disableLOV)
    {
        _disableLOV = disableLOV;
    }

    /**
    * should the LOV dialog be displayed on navigation by the
    * Navigation manager
    *
    * @return true if the Navigation manager is not configured
    *              to display the LOV dialog.
    */
    public boolean getDisableLOV()
    {
       return _disableLOV;
    }

    /**
    *  display LOV if there is an LOV property set on the data object
    *
    *  @param toItemName - check LOV property on this data object
    */
    public void displayLOV(String toItemName)
    {
        ValidationManager vm = ValidationManager.getValidationManager();
        InfoObject InfoObject = vm.getInfoObject(toItemName);

        if ((InfoObject != null) && (InfoObject instanceof AttributeInfo))
        {
            AttributeInfo attrInfo = (AttributeInfo)InfoObject;
            LOVInterface lov = attrInfo.getLOV();
            if ( ( lov != null) && (attrInfo.isDisplayLOVOnNavigateIn()))
            {
                DataItem di = vm.getDataItem(attrInfo);
                if ( ( di != null ) && ( di instanceof ImmediateAccess))
                {
                    ImmediateAccess ia = (ImmediateAccess)di;
                    lov.setRestrictedQuery(toItemName, ia.getValueAsObject());
                    lov.show();
                }
            }
        }
    }

    public int getChangeLevel(Control srcControl, Control desControl)
    {
        String desDataItemName;
        String srcDataItemName;
        boolean rowChange;

        desDataItemName =
            desControl == null ? null : desControl.getDataItemName();
        srcDataItemName =
            srcControl == null ? null : srcControl.getDataItemName();
        rowChange = (desDataItemName != null && srcDataItemName != null &&
                     desDataItemName.equals(srcDataItemName));
        return(_getChangeLevel(srcDataItemName, desDataItemName, rowChange));
    }

    // Private Methods

    private void _notifyCurrencyListeners(CurrencyChangedEvent event)
    {
        CurrencyListener[] listeners;
        int count = 0;

        synchronized(_currencyListeners)
        {
            count = _currencyListeners.size();
            listeners = new CurrencyListener[count];
            _currencyListeners.copyInto(listeners);
        }
        try
        {
            for(int i = 0; i < count; i++)
            {
                listeners[i].currencyChanged(event);
            }
        }
        catch(Exception e)
        {
            if (_focused != null)
            {
                String msg =
                    Res.getString(Res.ERR_NAVMGR_STAT_UNEXPECTED_EXCEPTION);
                String errorCode =
                    Res.getString(Res.ERR_NAVMGR_STAT_UNEXPECTED_EXCEPTION_MSG);
                DataSourceOperationException dsoe =
                    new DataSourceOperationException(msg, errorCode,
                                                     ERR_PROD_CODE,
                                                     e);

                ExceptionProcessor.processException((DataItem)_focused.getDataItem(),
                                                    -1, dsoe,
                                                    DacfType.CLIENT_FRAMEWORK,
                                                    DacfSeverity.ERROR);
            }
        }
    }

    /**
    **  changes the NavigationManager's notion of the current control.
    */
    private void _switchFocused()
    {
        CurrencyChangedEvent event =
            new CurrencyChangedEvent(_target, _focused);
        
        synchronized(this)
        {
            _focused = _target;
            _focusedItemName = _targetItemName;
            _focusedIsInvalid = false;
            _target = null;
            _targetItemName = null;
        }
        _notifyCurrencyListeners(event);
    }

    /**
    * Restores the focus to original control
    */
    private void _restoreFocus(boolean validated)
    {
        if (!validated)
        {
            // _debug("NM: Restoring pending focus");
            if (_focused != null)
            {
                SwingUtilities.invokeLater(new DelayedFocus(_focused.getComponent()));
            }

            // _debug("NM: Restored");
        }
    }

    private boolean _canChangeFocus(boolean rowChange)
    {
        // _debug("_canChangeFocus: focusedItemName: "  + _focusedItemName +
        //        " targetItemName : " + _targetItemName);

        boolean res = true;
        int srcValidationLevel = ValidationManager.VALID;
        int changeLevel =
            _getChangeLevel(_focusedItemName, _targetItemName, rowChange);

        // work-around for Swing bug 4139078
        if (_focused != null && _focused instanceof ApplyEditsListener)
        {
            try
            {
                _applyEditsFailed = false;
                ((ApplyEditsListener)_focused).applyEdits();
            }
            catch(ApplyEditsValidationException aeve)
            {
                _applyEditsFailed = true;
                return(false);
            }
        }

        if (_target != null && _target.isFocusValidated() &&
            !_performValidation(changeLevel, srcValidationLevel))
        {
            res = false;
        }

        if (res && _target != null &&
            _target instanceof ContainerControl)
        {
            res = ((ContainerControl)_target).changeCurrency();
        }
        if (res)
        {
            res = _fireNavigationEvents(changeLevel, srcValidationLevel);
        }
        return(res);
    }

    /**
    ** Navigation change levels are computed by looking at the source and
    ** destination dataitem names.  If the source dataitem name is a substring
    ** of the destination dataitem name then the navigation is a drill-down.
    ** the change level is returned as a negative then to indicate this.  This
    ** has the desireable side-effect of preventing validation from occuring.
    ** this happens because the ValidationManager used the change level to
    ** determine how much needs to be validated.
    */
    private int _getChangeLevel(String srcDataItemName, String desDataItemName,
                                boolean rowChanged)
    {
        int changeLevel = MAX_ITEMNAME_COMPONENTS; // Assume max change

        if (srcDataItemName != null && desDataItemName != null)
        {
            if (srcDataItemName.equals(desDataItemName))
            {
                changeLevel = (rowChanged ? InfoObject.LEVEL_ROW : -1);
            }
            else
            {
                int i;
                String srcToken;
                String desToken;
            
                ItemNameTokenizer srcTokenizer =
                    new ItemNameTokenizer(srcDataItemName);
                ItemNameTokenizer desTokenizer =
                    new ItemNameTokenizer(desDataItemName);

                while(srcTokenizer.hasMore() && desTokenizer.hasMore())
                {
                    srcToken = srcTokenizer.next();
                    desToken = desTokenizer.next();

                    if (!srcToken.equals(desToken))
                    {
                        if (changeLevel == InfoObject.LEVEL_ROW && !rowChanged)
                        {
                            changeLevel = InfoObject.LEVEL_COLUMN;
                        }
                        break;
                    }
                    changeLevel--;
                }

                if (!rowChanged && desDataItemName.startsWith(srcDataItemName))
                {
                    // it's a drill-down
                    changeLevel = -changeLevel;
                }
            }
        }
        else
        {
            if (srcDataItemName == null) // coming from nowhere so don't test
            {
                changeLevel = 0;
            }
        }
        // _debug("_getChangeLevel: level: " + changeLevel);
        return(changeLevel);
    }

    private boolean _performValidation(int changeLevel, int srcValidationLevel)
    {
        String s;
        boolean res = true;
        DataItem di = (DataItem)_focused.getDataItem();

        // _debug("_performValidation: changeLevel: " + changeLevel +
        //        " srcValidationLevel: " + srcValidationLevel);
        try
        {
            // Validate current control
            _fireValidationEvent(_focusedItemName, changeLevel);
        }
        catch (ValidationException ve)
        {
            if (!ve.getContinueNavigation())
            {
                String errorCode =
                    Res.getString(Res.ERR_NAVMGR_NAV_VAL_EXCEPTION);
                String msg =
                    Res.getString(Res.ERR_NAVMGR_NAV_VAL_EXCEPTION_MSG);
                DataSourceOperationException dsoe =
                    new DataSourceOperationException(msg, errorCode,
                                                     ERR_PROD_CODE,
                                                     ve);

                ExceptionProcessor.processException(di, -1, dsoe,
                                                    DacfType.CLIENT_FRAMEWORK,
                                                    DacfSeverity.ERROR);
                res = false;
            }
            else
            {
                srcValidationLevel = ve.getReason();
            }
        }
        catch(Exception e) // something unexpected; keep 'em where they are
        {
            String errorCode =
                Res.getString(Res.ERR_NAVMGR_VAL_UNEXPECTED_EXCEPTION);
            String msg =
                Res.getString(Res.ERR_NAVMGR_VAL_UNEXPECTED_EXCEPTION_MSG);
            DataSourceOperationException dsoe =
                new DataSourceOperationException(msg, errorCode,
                                                 ERR_PROD_CODE,
                                                 e);

            ExceptionProcessor.processException(di, -1, dsoe,
                                                DacfType.CLIENT_FRAMEWORK,
                                                DacfSeverity.ERROR);
            res = false;
        }
        return(res);
    }

    private void _fireValidationEvent(String srcItemName, int level)
        throws ValidationException
    {
        // _debug("_fireValidationEvent: srcItemName: " + srcItemName +
        //        " level: " + level);
        Object sourceDataItem = _sManager.getFocusedControl().getDataItem();
        if (sourceDataItem instanceof DataItem)
        {
            ValidationManager vm = ValidationManager.getValidationManager();
            vm.validateDataItem(srcItemName,level);
        }
    }

    private boolean _fireNavigationEvents(int changeLevel,
                                          int srcValidationLevel)
    {
        boolean res = true;
        int activityID =
            ActivityMonitor.activityStarted(DacActivities.NAVIGATING,
                                            ActivityMonitor.DEFAULT_DELAY,
                                            ActivityMonitor.DEFAULT_TIMEOUT);
        
        try
        {
            // Fire pre-Navigation events
            _fireNavigatingEvent(_focused, _target, srcValidationLevel);

            ActivityMonitor.activityStopped(activityID);
            activityID =
                ActivityMonitor.activityStarted(DacActivities.NAVIGATED_OUT,
                                              ActivityMonitor.DEFAULT_DELAY,
                                              ActivityMonitor.DEFAULT_TIMEOUT);
            // Leaving current control
            for (int i = 0; (i <= changeLevel); i++)
            {
                _fireNavigatedEvent(_focused, NavigatedEvent.NAVIGATE_OUT, i);
            }

            ActivityMonitor.activityStopped(activityID);
            activityID =
                ActivityMonitor.activityStarted(DacActivities.NAVIGATED_OUT,
                                              ActivityMonitor.DEFAULT_DELAY,
                                              ActivityMonitor.DEFAULT_TIMEOUT);
            //Entering new control
            for (int i = changeLevel; (i >= 0); i--)
            {
                _fireNavigatedEvent(_target, NavigatedEvent.NAVIGATE_IN, i);
            }
        }
        catch(NavigatingException ne)
        {
            _redirectFocus(ne.getTarget());
            res = false;
        }
        ActivityMonitor.activityStopped(activityID);
        return(res);
    }

    private void _fireNavigatedEvent(Control control, int type, int level)
    {
        if (control != null)
        {
            NavigatedEvent event = new NavigatedEvent(control, type, level);
            control.processNavigatedEvent(event);
        }
    }


    private void _fireNavigatingEvent(Control fromControl, Control toControl,
                                      int srcValidationLevel)
        throws NavigatingException
    {
        if (fromControl != null)
        {
            NavigatingEvent event =
                new NavigatingEvent(fromControl, toControl,srcValidationLevel);

            fromControl.processNavigatingEvent(event);
        }
    }

    /**
    * Redirects focus to a different control than the original target
    */
    private void _redirectFocus(Control c)
    {
        synchronized(this)
        {
            _focused = c;
            _target = null;
        }

        // Change the focus to requested control
        ((Component)c).requestFocus();
    }

    private void _debug(String msg)
    {
        if (_DEBUG)
        {
            Thread t = Thread.currentThread();
            System.out.println("NavigationManager: " + t.toString() + ": "
                               + msg);
        }
    }

    class DelayedFocus
        implements Runnable
    {
        Component _pending;
        DelayedFocus(Component pending)
        {
            _pending = pending;
        }

        public void run()
        {
            if (_pending != null)
            {
                // Change this to keep focus
                _pending.requestFocus();
            }
        }
    }
}
