/*
 * @(#)ListCellPainter.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.dacf.control.swing;

import java.awt.Component;
import java.awt.Dimension;
import java.util.Locale;
import javax.infobus.ImmediateAccess;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JTextField;
import javax.swing.ListCellRenderer;
import javax.swing.border.Border;
import javax.swing.border.EmptyBorder;

/**
 * ListCellRender implementation capable of painting <TT>ImmediateAccess</TT>
 * text items in a list <P>
 *
 * @version SDK
 *
 */
public class ListCellPainter extends JLabel implements ListCellRenderer
{

    protected static Border focusborder = new EmptyBorder(1, 1, 1, 1);
    private static ListCellPainter _sPainter;
    private static JTextField _prefSizeCalc = new JTextField();
    private static int _preferredHeight = 10;

    /**
     * Protected constructor. Clients should use the <code>getPainter()</code>
     * method to get an instance.
     */
    protected ListCellPainter()
    {
           super();
           setOpaque(true);
           setBorder(focusborder);

           Dimension  prefSize = _prefSizeCalc.getPreferredSize();
           _preferredHeight = prefSize.height;

    }

    /**
     * Gets a instance of  ListCellRenderer <P>
     *
     * @return  a ListCellRenderer
     */
    public static ListCellRenderer getPainter()
    {
       if(_sPainter == null)
         _sPainter = new ListCellPainter();
       return _sPainter;
    }

    /**
     * Implementation of the ListCellRenderer interface. Called by the
     * JList to paint the given object. The item is painted using
     * ImmediateAccess presentation string <P>
     *
     * @see javax.infobus.ImmediateAccess#getPresentationString()
     * @see javax.swing.ListCellRenderer#getListCellRendererComponent()
     */
    public Component getListCellRendererComponent(JList list,
                                                  Object value,
                                                  int index,
                                                  boolean isSelected,
                                                  boolean cellHasFocus)
    {
        if(isSelected)
        {
            setBackground(list.getSelectionBackground());
            setForeground(list.getSelectionForeground());
        }
        else
        {
            setBackground(list.getBackground());
            setForeground(list.getForeground());
        }

        setFont(list.getFont());

        if(value instanceof ImmediateAccess)
        {
          setText(((ImmediateAccess)value).
                 getPresentationString(Locale.getDefault()));
            }
        else
        {
              setText((value == null) ? "" : value.toString());
        }
            return this;
    }

    public Dimension getPreferredSize()
    {
        Dimension d = super.getPreferredSize();
        return new Dimension (d.width, _preferredHeight);
    }
}
