/*
 * @(#)GridControl.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.dacf.control.swing;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import javax.infobus.DataItemAddedEvent;
import javax.infobus.DataItemDeletedEvent;
import javax.infobus.DataItemRevokedEvent;
import javax.infobus.DataItemValueChangedEvent;
import javax.infobus.RowsetCursorMovedEvent;
import javax.infobus.ScrollableRowsetAccess;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.SwingUtilities;
import javax.swing.border.BevelBorder;
import javax.swing.table.JTableHeader;
import javax.swing.table.TableCellEditor;
import javax.swing.table.TableColumnModel;
import javax.swing.table.TableModel;
import oracle.dacf.control.ApplyEditsListener;
import oracle.dacf.control.ContainerControl;
import oracle.dacf.control.Control;
import oracle.dacf.control.ControlEnabledListener;
import oracle.dacf.control.ControlSupport;
import oracle.dacf.control.InfoBusManager;
import oracle.dacf.control.InfoBusManagerListener;
import oracle.dacf.control.InfoBusManagerReleaseEvent;
import oracle.dacf.control.NavigatedEvent;
import oracle.dacf.control.NavigatedListener;
import oracle.dacf.control.NavigatingEvent;
import oracle.dacf.control.NavigatingException;
import oracle.dacf.control.NavigatingListener;
import oracle.dacf.control.NavigationManager;
import oracle.dacf.dataset.InfoObject;

/**
 * This class is a data-aware control based on the JFC <TT>JTable</TT>
 * class. <P>
 *
 * The grid control supports binding to data items which implements the
 * <TT>ScrollableRowsetAccess</TT> InfoBus interface. <P>
 * If the data item also implements the <TT>DataItemView</TT> InfoBus
 * interface, the performance of the grid will be vastly improved. <P>
 * The grid control does <B>not</B> support data items which only implement the
 * <TT>ArrayAccess</TT> or <TT>RowsetAccess</TT> InfoBus interfaces.  The
 * data item must implement the <TT>ScrollableRowsetAccess</TT> interface as
 * a minimum. <P>
 *
 * @see Control
 * @version PUBLIC
 */
public class GridControl
    extends JPanel
    implements Control, ControlEnabledListener, ApplyEditsListener,
               InfoBusManagerListener, FocusListener, ContainerControl
{
    protected ColumnPropertiesPopupMenu _popupMenu = null;
    protected boolean _showColumnPropertiesMenu = true;
    protected boolean _rebuildColumnModel = true;

    ControlSupport _controlSupport;

    private GridControlTable _table;
    private JScrollPane _tableAggregate;
    private GridDataSource _dataSource;
    private boolean _autoRowNavigation;
    private Dimension preferredSize = new Dimension(300, 150);
    private Color _readOnlyCellBackgroundColor = Color.lightGray;

    //    private Dimension minimumSize = new Dimension(10, 10);

    private boolean _scrollToSelectedRow = false;

    private NavigationManager _navMgr;
	
    private SortDelegate _sortDelegate;

    private static final boolean _DEBUG = true;


    /**
    * Creates a new grid data-aware control. <P>
    */
    public GridControl()
    {
        _navMgr = NavigationManager.getNavigationManager();
        _controlSupport = new ControlSupport(this);
        _controlSupport.addControlEnabledListener(this);
        InfoBusManager.getInstance().addInfoBusManagerListener(this);
        _table = new GridControlTable(this);
    		_sortDelegate = new GridSortDelegate();
        ((GridSortDelegate)_sortDelegate).setPostAlways(true);
        _dataSource = createTableDataSource(this); 
        _table.setModel(_dataSource);
        _table.setAutoCreateColumnsFromModel(false);
        _table.setColumnSelectionAllowed(false);
        _table.setPreferredScrollableViewportSize(preferredSize);
        //        _table.setPreferredSize(preferredSize);
        //        _table.setMinimumSize(minimumSize);
        //        _sorter = new GridSorter();
        //        _sorter.setModel(_dataSource);
        //        _sorter.addMouseListenerToHeaderInTable(_table);
        //        _table.setModel(_sorter);
        //        setPreferredSize(preferredSize);
        //        setMinimumSize(minimumSize);
        _tableAggregate = createScrollPane();
        _tableAggregate.setViewportView(_table);

        _tableAggregate.setBorder(new BevelBorder(BevelBorder.LOWERED));
        _tableAggregate.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
        _tableAggregate.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        setLayout(new BorderLayout());
        add(_tableAggregate, BorderLayout.CENTER);
        setAutoRowNavigation(true);
        // call only after the JScrollPane is set up
        _dataSource.init();

        // set the JPanel to the jList default
        setFont(_table.getFont());

        // set the jList to null so it inherits from the JPanel
        _tableAggregate.setFont(null);
        _table.setFont(null);

        // when this is non-null a lot of code is executed when the mouse is
        // moved over the cells in the grid
        setToolTipText(null);
        setMinimumSize(_standardSize(1));
        setPreferredSize(_standardSize(5));
        setMaximumSize(_standardSize(25));
        addFocusListener(this);
    }


    // Attributes

    /**
    **  Set the background selection color for when the GridControl has focus. 
    **
    **  The GridControl always high-lights the current row using the
    **  selection colors according its the focus state.  The GridControl uses
    **  the focusedSelectionForeground and focusedSelectionBackground colors
    **  when it has the keyboard focus.  Likewise, it used the
    **  unfocusedSelectionForeground and unfocusedSelectionBackground colors
    **  when it does not have the keyboard focus.
    **
    **  @param focusedSelectionColor The color to be used for the selection
    **                               background when the Grid has the
    **                               keyboard focus
    **
    **  @see #setFocusedSelectionBackground
    **  @see #getFocusedSelectionBackground
    **  @see #setFocusedSelectionForeground
    **  @see #getFocusedSelectionForeground
    **  @see #setUnfocusedSelectionBackground
    **  @see #getUnfocusedSelectionBackground
    **  @see #setUnfocusedSelectionForeground
    **  @see #getUnfocusedSelectionForeground
    */
    public void setFocusedSelectionBackground(Color focusedSelectionColor)
    {
        _table._setFocusedSelectionBackground(focusedSelectionColor);
    } // setFocusedSelectionBackground
    
    /**
    **  Return background selection color used when the GridControl has focus. 
    **
    **  The GridControl always high-lights the current row using the
    **  selection colors according its the focus state.  The GridControl uses
    **  the focusedSelectionForeground and focusedSelectionBackground colors
    **  when it has the keyboard focus.  Likewise, it used the
    **  unfocusedSelectionForeground and unfocusedSelectionBackground colors
    **  when it does not have the keyboard focus.
    **
    **  @return The color used for the selection background when the Grid has
    **          the keyboard focus
    **
    **  @see #setFocusedSelectionBackground
    **  @see #getFocusedSelectionBackground
    **  @see #setFocusedSelectionForeground
    **  @see #getFocusedSelectionForeground
    **  @see #setUnfocusedSelectionBackground
    **  @see #getUnfocusedSelectionBackground
    **  @see #setUnfocusedSelectionForeground
    **  @see #getUnfocusedSelectionForeground
    */
    public Color getFocusedSelectionBackground()
    {
        return(_table._getFocusedSelectionBackground());
    } // getFocusedSelectionBackground
    
    /**
    **  Set the background selection color for when the Grid looses focus. 
    **
    **  The GridControl always high-lights the current row using the
    **  selection colors according its the focus state.  The GridControl uses
    **  the focusedSelectionForeground and focusedSelectionBackground colors
    **  when it has the keyboard focus.  Likewise, it used the
    **  unfocusedSelectionForeground and unfocusedSelectionBackground colors
    **  when it does not have the keyboard focus.
    **
    **  @param unfocusedSelectionColor The color to be used for the selection
    **                                 background when the Grid doesn't have
    **                                 the keyboard focus
    **
    **  @see #setFocusedSelectionBackground
    **  @see #getFocusedSelectionBackground
    **  @see #setFocusedSelectionForeground
    **  @see #getFocusedSelectionForeground
    **  @see #setUnfocusedSelectionBackground
    **  @see #getUnfocusedSelectionBackground
    **  @see #setUnfocusedSelectionForeground
    **  @see #getUnfocusedSelectionForeground
    */
    public void setUnfocusedSelectionBackground(Color unfocusedSelectionColor)
    {
        _table._setUnfocusedSelectionBackground(unfocusedSelectionColor);
    } // setUnfocusedSelectionBackground
    
    /**
    **  Return the background selection color when the Grid looses focus. 
    **
    **  The GridControl always high-lights the current row using the
    **  selection colors according its the focus state.  The GridControl uses
    **  the focusedSelectionForeground and focusedSelectionBackground colors
    **  when it has the keyboard focus.  Likewise, it used the
    **  unfocusedSelectionForeground and unfocusedSelectionBackground colors
    **  when it does not have the keyboard focus.
    **
    **  @return The color used for the selection background when the Grid
    **          doesn't have the keyboard focus
    **
    **  @see #setFocusedSelectionBackground
    **  @see #getFocusedSelectionBackground
    **  @see #setFocusedSelectionForeground
    **  @see #getFocusedSelectionForeground
    **  @see #setUnfocusedSelectionBackground
    **  @see #getUnfocusedSelectionBackground
    **  @see #setUnfocusedSelectionForeground
    **  @see #getUnfocusedSelectionForeground
    */
    public Color getUnfocusedSelectionBackground()
    {
        return(_table._getUnfocusedSelectionBackground());        
    } // getUnfocusedSelectionBackground
    
    /**
    **  Set the foreground selection color for when the Grid has focus. 
    **
    **  The GridControl always high-lights the current row using the
    **  selection colors according its the focus state.  The GridControl uses
    **  the focusedSelectionForeground and focusedSelectionBackground colors
    **  when it has the keyboard focus.  Likewise, it used the
    **  unfocusedSelectionForeground and unfocusedSelectionBackground colors
    **  when it does not have the keyboard focus.
    **
    **  @param focusedSelectionColor The color to be used for the selection
    **                               foreground when the Grid has the keyboard
    **                               focus
    **
    **  @see #setFocusedSelectionBackground
    **  @see #getFocusedSelectionBackground
    **  @see #setFocusedSelectionForeground
    **  @see #getFocusedSelectionForeground
    **  @see #setUnfocusedSelectionBackground
    **  @see #getUnfocusedSelectionBackground
    **  @see #setUnfocusedSelectionForeground
    **  @see #getUnfocusedSelectionForeground
    */
    public void setFocusedSelectionForeground(Color focusedSelectionColor)
    {
        _table._setFocusedSelectionForeground(focusedSelectionColor);
    } // setFocusedSelectionForeground
    
    /**
    **  Return the foreground selection color when the GridControl has focus. 
    **
    **  The GridControl always high-lights the current row using the
    **  selection colors according its the focus state.  The GridControl uses
    **  the focusedSelectionForeground and focusedSelectionBackground colors
    **  when it has the keyboard focus.  Likewise, it used the
    **  unfocusedSelectionForeground and unfocusedSelectionBackground colors
    **  when it does not have the keyboard focus.
    **
    **  @return The color used for the selection foreground when the Grid
    **          has the keyboard focus
    **
    **  @see #setFocusedSelectionBackground
    **  @see #getFocusedSelectionBackground
    **  @see #setFocusedSelectionForeground
    **  @see #getFocusedSelectionForeground
    **  @see #setUnfocusedSelectionBackground
    **  @see #getUnfocusedSelectionBackground
    **  @see #setUnfocusedSelectionForeground
    **  @see #getUnfocusedSelectionForeground
    */
    public Color getFocusedSelectionForeground()
    {
        return(_table._getFocusedSelectionForeground());
    } // getFocusedSelectionForeground
    
    /**
    **  Set the foreground selection color when the Grid looses focus. 
    **
    **  The GridControl always high-lights the current row using the
    **  selection colors according its the focus state.  The GridControl uses
    **  the focusedSelectionForeground and focusedSelectionBackground colors
    **  when it has the keyboard focus.  Likewise, it used the
    **  unfocusedSelectionForeground and unfocusedSelectionBackground colors
    **  when it does not have the keyboard focus.
    **
    **  @param unfocusedSelectionColor The color to be used for the selection
    **                                 foreground when the Grid doesn't have
    **                                 the keyboard focus
    **
    **  @see #setFocusedSelectionBackground
    **  @see #getFocusedSelectionBackground
    **  @see #setFocusedSelectionForeground
    **  @see #getFocusedSelectionForeground
    **  @see #setUnfocusedSelectionBackground
    **  @see #getUnfocusedSelectionBackground
    **  @see #setUnfocusedSelectionForeground
    **  @see #getUnfocusedSelectionForeground
    */
    public void setUnfocusedSelectionForeground(Color unfocusedSelectionColor)
    {
        _table._setUnfocusedSelectionForeground(unfocusedSelectionColor);
    } // setUnfocusedSelectionForeground
    
    /**
    **  Return the foreground selection color when the Grid looses focus. 
    **
    **  The GridControl always high-lights the current row using the
    **  selection colors according its the focus state.  The GridControl uses
    **  the focusedSelectionForeground and focusedSelectionBackground colors
    **  when it has the keyboard focus.  Likewise, it used the
    **  unfocusedSelectionForeground and unfocusedSelectionBackground colors
    **  when it does not have the keyboard focus.
    **
    **  @return The color used for the selection foreground when the Grid 
    **          doesn't have the keyboard focus
    **
    **  @see #setFocusedSelectionBackground
    **  @see #getFocusedSelectionBackground
    **  @see #setFocusedSelectionForeground
    **  @see #getFocusedSelectionForeground
    **  @see #setUnfocusedSelectionBackground
    **  @see #getUnfocusedSelectionBackground
    **  @see #setUnfocusedSelectionForeground
    **  @see #getUnfocusedSelectionForeground
    */
    public Color getUnfocusedSelectionForeground()
    {
        return(_table._getUnfocusedSelectionForeground());        
    } // getUnfocusedSelectionForeground
    
    /**
    * Returns the underlying JFC <TT>JTable</TT> object. <P>
    * @return  The table.
    */
    public final JTable getTable()
    {
        return (_table);
    }

	protected GridDataSource createTableDataSource(GridControl g)
	{
		return new GridDataSource(g, false);
	}

    /**
    * Returns the data source being used by the underlying JFC <TT>JTable</TT>
    * object. </TT>
    * @return  The table data source.
    */
    public final GridDataSource getTableDataSource()
    {
        return (_dataSource);
    }

    /**
    * Returns the scroll pane being used by the underlying JFC <TT>JTable</TT>
    * object. </TT>
    * @return  The table scroll pane.
    */
    public final JScrollPane getTableAggregate()
    {
        return (_tableAggregate);
    }

    // ContainerControl interface
    public boolean changeCurrency()
    {
        return(_table._moveCurrentRow());
    }

    // ControlEnabledListener interface
    public void enabledChanged(boolean b)
    {
        _table.setEnabled(b);
    }

    // FocusListener interface

    public void focusGained(FocusEvent e)
    {
        _table.requestFocus();
    }

    public void focusLost(FocusEvent e)
    {
    }
    
    // InfoBusManagerListener interface implementation
    public void releaseResources(InfoBusManagerReleaseEvent e)
    {
        if (e.appliesTo(this))
        {
            // JRS
            if (_dataSource != null)
            {
               _dataSource.dataItemChanged(_controlSupport.getDataItem(), null);
            }
            // END JRS

            InfoBusManager.getInstance().removeInfoBusManagerListener(this);
            removeFocusListener(this);
            _controlSupport.removeControlEnabledListener(this);
            _controlSupport = null;
        }
    }

    // Control Interface

    /**
    ** An override of java.awt.Component.setEnabled. <P>
    **
    ** @param b boolean flag indicating whether the control is enabled
    */
    public void setEnabled(boolean b)
    {
        super.setEnabled(b);
        if (_controlSupport != null)
        {
            _controlSupport.setEnabled(b);
        }
    } // setEnabled

    /**
    * Returns the name of the InfoBus this control is connected to. <P>
    * @return  The name of the InfoBus this control is connected to.
    * @see Control#getInfoBusName
    */
    public final String getInfoBusName()
    {
        return(_controlSupport == null ?
               null : _controlSupport.getInfoBusName());
    }

    /**
    * Sets the name of the InfoBus this control is connected to. <P>
    * By default, the control is connected to the default InfoBus,
    * named <TT>Control.DEFAULT_INFOBUS_NAME</TT>. <P>
    * If the named InfoBus does not exist, it is created automatically. <P>
    * If the control is already connected to an InfoBus, it is disconnected
    * first. <P>
    * @param infoBusName   The name of the InfoBus to connect to.
    * @see Control#DEFAULT_INFOBUS_NAME
    * @see Control#setInfoBusName
    */
    public final void setInfoBusName(String infoBusName)
    {
        if (_controlSupport != null)
        {
            _controlSupport.setInfoBusName(infoBusName);
        }
    }

    /**
    * Returns the name of the InfoBus DataItem this control is bound to. <P>
    * @return  The name of the InfoBus DataItem this control is bound to,
    *          or <TT>null</TT> if the control is unbound.
    * @see #getDataItem
    * @see Control#getDataItemName
    */
    public final String getDataItemName()
    {
        return(_controlSupport == null ?
               null : _controlSupport.getDataItemName());
    }

    /**
    * Sets the name of the InfoBus DataItem this control is bound to. <P>
    * The DataItem with the given name is searched for on the InfoBus, and
    * if found, is bound to this control. <P>
    * If the control is already bound to a DataItem, it is unbound first. <P>
    * @param dataItemName  The name of the DataItem to bind to.
    * @see #getDataItem
    * @see Control#setDataItemName
    */
    public final void setDataItemName(String dataItemName)
    {
        if (_controlSupport != null)
        {
            _rebuildColumnModel = true;
            _controlSupport.setDataItemName(dataItemName);
        }
    }

    /**
    * Returns the InfoBus DataItem this control is bound to. <P>
    * @return  The InfoBus DataItem this control is bound to, or
    *          <TT>null</TT> if the control is unbound.
    * @see Control#getDataItem
    */
    public final Object getDataItem()
    {
        return(_controlSupport == null ? null : _controlSupport.getDataItem());
    }


    /**
    **  Controls how Tab or Shift-Tab will cause the selection to move.<p>
    **
    **  When true the following rules apply:
    **  <ul>
    **  <li>Tab: if the selection anchor is on the last column of a row, the
    **      selection anchor will move to the first column of the following
    **      row if that row exists.</li>
    **  <li>Shift-Tab: if the selection anchor is on the first column of a row,
    **      the selection anchor will move to the last column of the previous
    **      row if that row exists.</li>
    **  </ul>
    **  When false:
    **  <ul>
    **  <li>Tab: if the selection anchor is on the last column of a row, the
    **      selection anchor will move to the first column within the current
    **      selection.</li>
    **  <li>Shift-Tab: if the selection anchor is on the last column of a row,
    **      the selection anchor will move to the first column within the
    **      current selection.</li>
    **  </ul>
    */
    public boolean isAutoRowNavigation()
    {
        return(!_table._getTabNavigatesInSelection());
    }

    /**
    **  Controls how Tab or Shift-Tab will cause the selection to move.<p>
    **
    **  When true the following rules apply:
    **  <ul>
    **  <li>Tab: if the selection anchor is on the last column of a row, the
    **      selection anchor will move to the first column of the following
    **      row if that row exists.</li>
    **  <li>Shift-Tab: if the selection anchor is on the first column of a row,
    **      the selection anchor will move to the last column of the previous
    **      row if that row exists.</li>
    **  </ul>
    **  When false:
    **  <ul>
    **  <li>Tab: if the selection anchor is on the last column of a row, the
    **      selection anchor will move to the first column within the current
    **      selection.</li>
    **  <li>Shift-Tab: if the selection anchor is on the last column of a row,
    **      the selection anchor will move to the first column within the
    **      current selection.</li>
    **  </ul>
    */
    public void setAutoRowNavigation(boolean auto)
    {
        _table._setTabNavigatesInSelection(!auto);
    }


    /**
    * Exposes the JTable ShowGrid property in our subcomponent
    */
    public final void setShowGrid(boolean showGrid)
    {
        _table.setShowGrid(showGrid);
    }


    /**
    * Exposes the JTable Background color property in our subcomponent to the
    * property sheet
    */
    public final void setTableBackground(Color color)
    {
        _table.setBackground(color);
    }

    /**
    * Exposes the JTable Background color property in our subcomponent to the
    * property sheet
    */
    public final Color getTableBackground()
    {
        return _table.getBackground();
    }

    /**
    * Exposes the JTable Foreground color property in our subcomponent to the
    * property sheet
    */
    public final void setTableForeground(Color color)
    {
        _table.setForeground(color);
    }

    /**
    * Exposes the JTable Foreground color property in our subcomponent to the
    * property sheet
    */
    public final Color getTableForeground()
    {
        return _table.getForeground();
    }

    /**
    *  specify the background color used for cells which are read-only
    */
    public void setReadOnlyCellBackgroundColor(Color color)
    {
        _readOnlyCellBackgroundColor = color;
    }

    /**
    * get the current back color used for read only cells.
    */
    public Color getReadOnlyCellBackgroundColor()
    {
        return _readOnlyCellBackgroundColor;
    }

    /**
    *  force all the cells to be read only., irrespective of the underlying
    *  data object.
    *
    *  @param forceReadOnly - ignore the columns 'isUpdatable' flag when true
    */
    public void setForceReadOnly(boolean forceReadOnly)
    {
        _dataSource.setForceReadOnly(forceReadOnly);
    }

    /**
    * are all the cells be forced as read only cells ?
    *
    * @return true if all the cells are forced to be read only
    */
    public boolean isForceReadOnly()
    {
        return _dataSource.isForceReadOnly();
    }

   /**
    * In single selection mode, this flag controls whether
    * the grid should scroll to the selected row or not.
    *
    * By default this property is false and the grid will
    * not scroll to the selected row.
    *
    * @param bScroll true if the grid should scroll to the selected row
    */
    public void setScrollToSelectedRow(boolean bScroll)
    {
        _scrollToSelectedRow = bScroll;
    }


    /**
    * Returns whether the Grid has been configured to scroll automatically
    * to the selected row in single selection mode.
    *
    * @return true if the grid should scroll to selected row.
    */
    public boolean isScrollToSelectedRow()
    {
        return _scrollToSelectedRow;
    }

	/**
	* GridControl delegates 'sorting' to this helper object. 
	*
	* @param sortDelegate helper object to do the sort
	*/
	public void setSortDelegate(SortDelegate sortDelegate)
	{
		_sortDelegate = sortDelegate;
	}

	/**
	* Return the helper object currently used for sorting
	*
	* @return sort helper object
	*/
	public SortDelegate getSortDelegate()
	{
		return _sortDelegate;
	}

    /**
    * Notifies the control that the bound InfoBus DataItem has changed. <P>
    * @param oldDataItem   The formerly bound DataItem (can be <TT>null</TT>).
    * @param newDataItem   The newly bound DataItem (can be <TT>null</TT>).
    * @see Control#dataItemChanged
    */
    public void dataItemChanged(Object oldDataItem, Object newDataItem)
    {
        // _debug("dataItemChanged()");
        if (_rebuildColumnModel)
        {
            _rebuildColumnModel = false;
            _dataSource.dataItemChanged(oldDataItem, newDataItem);
            rowsetCursorMoved(null);
            if ( isShowColumnPropertiesPopupMenu())
               installColumnPropertiesPopupMenu();
        }
    }


    /**
    * Causes the control to close the cell editor, saving the value
    */
    public void applyEdits()
    {
        TableCellEditor editor = _table.getCellEditor();
        if (editor != null)
        {
            editor.stopCellEditing();
        }
    }

    /**
    * Causes the control to close the cell editor, loosing the value
    */
    public void cancelEdits()
    {
        TableCellEditor editor = _table.getCellEditor();
        if (editor != null)
        {
            editor.cancelCellEditing();
        }
    }

    /**
    * Returns the AWT component associated with this control. <P>
    * @return  The AWT component for this control.
    * @see Control#getComponent
    */
    public Component getComponent()
    {
        return (this);
    }

    /**
    * Determines whether focus into this control causes validation to
    * occur. <P>
    * @return  <TT>true</TT> if focus into this control causes validation to
    *          occur, <TT>false</TT> otherwise.
    * @see Control#isFocusValidated
    */
    public final boolean isFocusValidated()
    {
        return (_controlSupport == null ?
                false : _controlSupport.isFocusValidated());
    }

    /**
    * Sets whether focus into this control causes validation to occur. <P>
    * @param focusValidated    If <TT>true</TT>, focus into this control will
    *                          cause validation to occur.
    * @see Control#setFocusValidated
    */
    public final void setFocusValidated(boolean focusValidated)
    {
        if (_controlSupport != null)
        {
            _controlSupport.setFocusValidated(focusValidated);
        }
    }

    /**
     * Sets the underlying JTable as focus traversable.
     *
     * By default DAC removes tooltip text from the GridControl.  This causes
     * Swing to evaluate the GridControl's JTable as non-focus traversable.  The
     * application developer may use this method to override the algorithm
     * that is used by Swing to evaluate whether a control is focus traversable.
     * This will force the GridControl's JTable to evaluate as focus traversable
     * even though ToolTip text has been disabled.
     */
     public final void setFocusTraversable(boolean focusTraversable)
     {
         // See bug 1765216
        _table.setFocusTraversable(focusTraversable);
     }


    /**
    * Adds a navigated listener to this control. <P>
    * The listener will be notified of NavigateIn and NavigateOut events. <P>
    * @param listener  The listener to add.
    * @see Control#addNavigatedListener
    */
    public final void addNavigatedListener(NavigatedListener listener)
    {
        if (_controlSupport != null)
        {
            _controlSupport.addNavigatedListener(listener);
        }
    }

    /**
    * Removes a navigated listener from this control. <P>
    * @param listener  The listener to remove.
    * @see Control#removeNavigatedListener
    */
    public final void removeNavigatedListener(NavigatedListener listener)
    {
        if (_controlSupport != null)
        {
            _controlSupport.removeNavigatedListener(listener);
        }
    }

    /**
    * Processes a navigated event for this control. <P>
    * This method is for use by the NavigationManager only. <P>
    * @param event The navigated event.
    * @see Control#processNavigatedEvent
    */
    public final void processNavigatedEvent(NavigatedEvent event)
    {
        if (_controlSupport != null)
        {
            _controlSupport.processNavigatedEvent(event);
        }
    }

    /**
    * Adds a navigating listener to this control. <P>
    * The listener will be notified of NavigateIn and NavigateOut events. <P>
    * @param listener  The listener to add.
    * @see Control#addNavigatingListener
    */
    public final void addNavigatingListener(NavigatingListener listener)
    {
        if (_controlSupport != null)
        {
            _controlSupport.addNavigatingListener(listener);
        }
    }

    /**
    * Removes a navigating listener from this control. <P>
    * @param listener  The listener to remove.
    * @see Control#removeNavigatingListener
    */
    public final void removeNavigatingListener(NavigatingListener listener)
    {
        if (_controlSupport != null)
        {
            _controlSupport.removeNavigatingListener(listener);
        }
    }

    /**
    * Processes a navigating event for this control. <P>
    * This method is for use by the NavigationManager only. <P>
    * @param event The navigating event.
    * @exception NavigatingException   If the navigation is redirected to a
    *                                  different control.
    * @see Control#processNavigatingEvent
    */
    public final void processNavigatingEvent(NavigatingEvent event)
        throws NavigatingException
    {
        if (_controlSupport != null)
        {
            _controlSupport.processNavigatingEvent(event);
        }
    }


    // DataItemChangedListener Interface

    /**
    * Indicates a changed value in the bound data item. <P>
    * A reference to the data item that changed can be obtained from the
    * event. <P>
    * @param event Contains change information.
    * @see javax.infobus.DataItemChangeListener#dataItemValueChanged
    */
    public final void dataItemValueChanged(DataItemValueChangedEvent event)
    {
        // Handled by data source
    }

    /**
    * Indicates that a new item was added to the bound aggregate data item
    * (e.g. <TT>ArrayAccess</TT>, a JDK Collection, etc). <P>
    * A reference to the data item that was added, and a reference to the one
    * that gained it, can be obtained from the event. <P>
    * @param event Contains details of the addition.
    * @see javax.infobus.DataItemChangeListener#dataItemAdded
    */
    public final void dataItemAdded(DataItemAddedEvent event)
    {
        // Handled by data source
    }

    /**
    * Indicates that an item was deleted from the bound aggregate data item
    * (e. g. <TT>ArrayAccess</TT>, a JDK Collection, etc). <P>
    * A reference to the data item that was deleted, and a reference to the
    * one that lost it, can be obtained from the event. <P>
    * @param event Contains details of the deletion.
    * @see javax.infobus.DataItemChangeListener#dataItemDeleted
    */
    public final void dataItemDeleted(DataItemDeletedEvent event)
    {
        // Handled by data source
    }

    /**
    * Indicates that the bound data item (and its sub-items, if any) has been
    * revoked, and is temporarily unavailable. <P>
    * A reference to the data item that was revoked can be obtained from
    * the event. <P>
    * @param event Contains details of the revoked data.
    * @see javax.infobus.DataItemChangeListener#dataItemRevoked
    */
    public final void dataItemRevoked(DataItemRevokedEvent event)
    {
        // Handled by data source
        uninstallColumnPropertiesPopupMenu();
    }

    /**
    * Indicates that the cursor for the bound <TT>RowsetAccess</TT> data item
    * has changed rows. <P>
    * A reference to the rowset data item can be obtained from the event. <P>
    * @param event Contains details of the cursor move.
    * @see javax.infobus.DataItemChangeListener#rowsetCursorMoved
    */
    public final void rowsetCursorMoved(RowsetCursorMovedEvent event)
    {
        _updateSelectedRowLater();
    }


    private void _updateSelectedRowLater()
    {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                Object dataItem = getDataItem();

                if (dataItem != null &&
                    dataItem instanceof ScrollableRowsetAccess)
                {
                    int row = ((ScrollableRowsetAccess)dataItem).getRow() - 1;

                    if (row >= 0)
                    {
                        _table._updateSelectedRow(row);
                    }
                }
            }
        });
    }

    protected void installColumnPropertiesPopupMenu()
    {
        TableColumnModel tm = getTable().getColumnModel();

        if ( tm instanceof GridTableColumnModel)
        {
            _popupMenu =
                new ColumnPropertiesPopupMenu((GridTableColumnModel)tm);
        }
    }


    protected void uninstallColumnPropertiesPopupMenu()
    {
        _popupMenu = null;
    }

    /**
    * Override this method, if you wish to use a custom ScrollPane.
    *
    * A custom ScrollPane may be used, for example, if you wish to
    * change the way the scroll bar refreshes the View.
    */
    protected JScrollPane createScrollPane()
    {
        return new DelayedRefreshScrollPane();
    }

    private int _getCurrentRow()
    {
        Object dataItem = getDataItem();
        if (dataItem != null &&
            dataItem instanceof ScrollableRowsetAccess)
        {
            int row = ((ScrollableRowsetAccess)dataItem).getRow() - 1;
            return row;
        }
        return 0;
    }


    /**
    * This text field is our source of cell size information.
    *
    * @see #_standardSize
    */
    private JTextField _field = new JTextField();

    /**
    * This is the default number of rows which we use to determine the size
    * of the grid control.
    *
    * @see #_standardSize
    */
    private static int DEFAULT_ROWS = 8;

    /**
    * This is the default number of columns which we use to determine the size
    * of the grid control.
    *
    * @see #_standardSize
    */
    private static int DEFAULT_COLUMNS = 8;

    /**
    * This method provides a uniform calculation for the minimum, preferred
    * and maximum sizes of the grid control. From the behaviour of the control
    * without this calculation it would appear that relying on the layout
    * manager to determine these sizes correctly is a bad idea. Note that we
    * add one to the row count to allow room for the table header. Note also
    * that the number of columns used to calculate the minimum, preferred
    * and maximum dimensions were chosen solely for my amusement (and because
    * empirically they don't look too bad).
    *
    * @param columns the number of characters to appear in a cell of the table
    *
    * @return a Dimension object containing the size of the table if each cell
    * contains the requested number of characters
    */
    private Dimension _standardSize(int columns)
    {
        _field.setColumns(columns);
        Dimension d = _field.getPreferredSize();
        return(new Dimension(DEFAULT_COLUMNS*d.width,
                             (DEFAULT_ROWS+1)*d.height));
    }


    // start overrides for composite dacs
    public void setOpaque(boolean isOpaque)
    {
        if (_table != null)
        {
            super.setOpaque(isOpaque);
            _table.setOpaque(isOpaque);
        }
    }

    // There is a lot of code fired every time you move the mouse over a cell
    // in the grid when getToolTipText returns a non-null value
    public void setToolTipText(String text)
    {
        if (_table != null)
        {
            super.setToolTipText(text);
            _table.setToolTipText(text);
        }
    }

    // end overrides for composite dacs



    // start expose JTable sepcific properties
    public void setAutoCreateColumnsFromModel(boolean createColumns)
    {
        _table.setAutoCreateColumnsFromModel(createColumns);
    }

    public boolean getAutoCreateColumnsFromModel()
    {
        return _table.getAutoCreateColumnsFromModel();
    }

    public void setAutoResizeMode(int mode)
    {
        _table.setAutoResizeMode(mode);
    }

    public int getAutoResizeMode()
    {
        return _table.getAutoResizeMode();
    }

    public void setCellEditor(TableCellEditor anEditor)
    {
        _table.setCellEditor(anEditor);
    }

    public TableCellEditor getCellEditor(int row,int column)
    {
        return _table.getCellEditor(row, column);
    }

    public void setCellSelectionEnabled(boolean flag)
    {
        _table.setCellSelectionEnabled(flag);
    }

    public boolean getCellSelectionEnabled()
    {
        return _table.getCellSelectionEnabled();
    }

    public void setColumnModel(TableColumnModel newModel)
    {
        _table.setColumnModel(newModel);
    }

    public TableColumnModel getColumnModel()
    {
        return _table.getColumnModel();
    }

    public void setColumnSelectionAllowed(boolean flag)
    {
        _table.setColumnSelectionAllowed(flag);
    }

    public boolean getColumnSelectionAllowed()
    {
        return _table.getColumnSelectionAllowed();
    }

    public void setEditingColumn(int aColumn)
    {
        _table.setEditingColumn(aColumn);
    }

    public int getEditingColumn()
    {
        return _table.getEditingColumn();
    }

    public void setEditingRow(int aRow)
    {
        _table.setEditingRow(aRow);
    }

    public int getEditingRow()
    {
        return _table.getEditingRow();
    }

    public final void setGridColor(Color gridColor)
    {
        _table.setGridColor(gridColor);
    }

    public final Color getGridColor()
    {
        return _table.getGridColor();
    }

    public void setIntercellSpacing(Dimension newSpacing)
    {
        _table.setIntercellSpacing(newSpacing);
    }

    public Dimension getIntercellSpacing()
    {
        return _table.getIntercellSpacing();
    }

    public void setModel(TableModel newModel)
    {
        _table.setModel(newModel);
    }

    public TableModel getModel()
    {
        return _table.getModel();
    }

    public void setPreferredScrollableViewportSize(Dimension size)
    {
        _table.setPreferredScrollableViewportSize(size);
    }

    public Dimension getPreferredScrollableViewportSize()
    {
        return _table.getPreferredScrollableViewportSize();
    }

    public void setRowHeight(int newHeight)
    {
        _table.setRowHeight(newHeight);
    }

    public int getRowHeight()
    {
        return _table.getRowHeight();
    }

    public void setRowMargin(int rowMargin)
    {
        _table.setRowMargin(rowMargin);
    }

    public int getRowMargin()
    {
        return _table.getRowMargin();
    }

    public void setRowSelectionAllowed(boolean flag)
    {
        _table.setRowSelectionAllowed(flag);
    }

    public boolean getRowSelectionAllowed()
    {
        return _table.getRowSelectionAllowed();
    }

    /**
    * This will override the selection background setting currently in effect.
    * This setting is inherently temporary because when keyboard focus
    * changes, the appropriate value will be utilized.
    *
    * @see #setFocusedSelectionBackground
    * @see #setUnfocusedSelectionBackground
    */
    public final void setSelectionBackground(Color color)
    {
        _table.setSelectionBackground(color);
    }

    /**
    * This will return the current Color being used to indicate the current
    * selection background.   This setting is inherently temporary because
    * when keyboard focus changes, the appropriate value will be utilized.
    *
    * @see #getFocusedSelectionBackground
    * @see #getUnfocusedSelectionBackground
    */
    public final Color getSelectionBackground()
    {
        return(_table.getSelectionBackground());
    }


    /**
    * This will override the selection foreground setting currently in effect.
    * This setting is inherently temporary because when keyboard focus
    * changes, the appropriate value will be utilized.
    *
    * @see #setFocusedSelectionForeground
    * @see #setUnfocusedSelectionForeground
    */
    public final void setSelectionForeground(Color color)
    {
        _table.setSelectionForeground(color);
    }

    /**
    * This will return the current Color being used to indicate the current
    * selection foreground.  This setting is inherently temporary because
    * when keyboard focus changes, the appropriate value will be utilized.
    *
    * @see #getFocusedSelectionForeground
    * @see #getUnfocusedSelectionForeground
    */
    public final Color getSelectionForeground()
    {
        return(_table.getSelectionForeground());
    }


    public void setSelectionModel(ListSelectionModel newModel)
    {
        _table.setSelectionModel(newModel);
    }

    public ListSelectionModel getSelectionModel()
    {
        return _table.getSelectionModel();
    }

    /**
    * Exposes the JTable ShowHorizontalLines property in our subcomponent to
    * the property sheet
    */
    public final void setShowHorizontalLines(boolean showLines)
    {
        _table.setShowHorizontalLines(showLines);
    }

    /**
    * Exposes the JTable ShowHorizontalLines property in our subcomponent to
    * the property sheet
    */
    public final boolean getShowHorizontalLines()
    {
        return _table.getShowHorizontalLines();
    }

    /**
    * Exposes the JTable ShowVerticalLines property in our subcomponent to the
    * property sheet
    */
    public final void setShowVerticalLines(boolean showLines)
    {
        _table.setShowVerticalLines(showLines);
    }

    /**
    * Exposes the JTable ShowVerticalLines property in our subcomponent to
    * the property sheet
    */
    public final boolean getShowVerticalLines()
    {
        return _table.getShowVerticalLines();
    }

    public void setTableHeader(JTableHeader newHeader)
    {
        _table.setTableHeader(newHeader);
    }

    public JTableHeader getTableHeader()
    {
        return _table.getTableHeader();
    }
	// end expose JTable sepcific properties

	
    public int getVisibleRowCount()
	{
		return _dataSource._computeVisibleRowcount();
	}

	/**
	*  The vertical scroll can be removed by this method.
	*
	*  Application, will have to scroll by explicitly 
	*  changing the cursor for the dataitem.
	*/
    public void showVerticalScrollBar(boolean bShow)
	{
	   JScrollPane pane = getTableAggregate();

	   if (bShow)
	   {
		   pane.setVerticalScrollBarPolicy(
                   JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED );
		   setScrollToSelectedRow(false);
	   }
	   else
	   {
		   pane.setVerticalScrollBarPolicy(
                   JScrollPane.VERTICAL_SCROLLBAR_NEVER );
		   setScrollToSelectedRow(true);
	   }
	}

    protected void _displayLOV(int columnIndex)
    {
        _displayLOV(getColumnDataItemName(columnIndex));
    }

    protected void _displayLOV(String columnDataItemName)
    {
        _navMgr.displayLOV(columnDataItemName);
    }

    /**
    *  displays the Column properties menu on right click
    *
    *  @param showMenu true if the column show/hide properties menu
    *                  should be displayed
    */
    public void setShowColumnPropertiesPopupMenu(boolean showMenu)
    {
        _showColumnPropertiesMenu = showMenu;
        if ( showMenu )
             installColumnPropertiesPopupMenu();
        else
             uninstallColumnPropertiesPopupMenu();
    }

    public boolean isShowColumnPropertiesPopupMenu()
    {
        return _showColumnPropertiesMenu;
    }

    protected String getColumnDataItemName(int columnIndex)
    {
        Object dataItem = getDataItem();
        if (dataItem != null && dataItem instanceof ScrollableRowsetAccess)
        {
            ScrollableRowsetAccess rowset =
                (ScrollableRowsetAccess)dataItem;
            String prefix = getDataItemName() + InfoObject.ITEMNAME_DELIMITER;
            String srcItemName = prefix +
                rowset.getColumnName(columnIndex + 1);
            return srcItemName;
        }
        return "";
    }

    protected ColumnPropertiesPopupMenu _getPopupMenu()
    {
        return _popupMenu;
    }

    /**
    * Prints debugging to <TT>System.out</TT> if debugging is enabled. <P>
    * @param s The string to output.
    */
    private void _debug(String s)
    {
        if (_DEBUG)
        {
            System.out.println("GridControl: " + s);
        }
    }
}

