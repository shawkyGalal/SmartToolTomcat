/*
 * @(#)GridTableColumnModel.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.dacf.control.swing;

import java.awt.Component;
import java.awt.Dimension;
import java.awt.Point;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Enumeration;
import java.util.Vector;
import javax.swing.JCheckBoxMenuItem;
import javax.swing.JComponent;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JPopupMenu;
import javax.swing.JTable;
import javax.swing.SwingUtilities;
import javax.swing.table.DefaultTableColumnModel;
import javax.swing.table.TableColumn;

/**
 * Table column model which can dynamically hide/show columns of
 * JTable
 *
 * @version Internal
 */
class GridTableColumnModel extends DefaultTableColumnModel
{
    Vector _hiddenTableColumns = new Vector();
    Vector _headerValueList = new Vector();
    SortableHeaderRenderer _headerRenderer = null;
    JTable _owner;

    /**
    * Construct table model which can manage hide/show columns
    * of the table
    */
    public GridTableColumnModel(JTable owner)
    {
       _owner = owner;
    }

    SortableHeaderRenderer getHeaderRenderer()
    {
        return(_headerRenderer);
    }

    void setHeaderRenderer(SortableHeaderRenderer headerRenderer)
    {
        _headerRenderer = headerRenderer;
    }

    public void addColumn(TableColumn tc, boolean showColumn)
    {
        _headerValueList.addElement( tc.getHeaderValue());
        if (showColumn)
            super.addColumn(tc);
        else
           _hiddenTableColumns.addElement(tc);
    }

    public void addColumn(TableColumn tc)
    {
         this.addColumn(tc, true);
    }

    Object[] getColumnHeaderValues()
    {
        Object[] headerValues = new Object[_headerValueList.size()];
        _headerValueList.copyInto(headerValues);
        return headerValues;
    }

    protected boolean getColumnState(String headerValue)
    {
        TableColumn tc = _getFromHiddenColumnList(headerValue);
        if (tc != null )
            return false;
        tc = _getFromDisplayedColumnList(headerValue);
        if ( tc != null )
            return true;
        else
            throw new RuntimeException("column " + headerValue + " not found");
    }

    protected void  setColumnState(String headerValue, boolean showColumn)
    {
        if ( showColumn )
        {
            TableColumn tc = _getFromHiddenColumnList(headerValue);
            if ( tc != null )
            {
                 _hiddenTableColumns.removeElement(tc);
                 super.addColumn(tc);
                 _refreshTable();
            }
            else
            {
                 tc = _getFromDisplayedColumnList(headerValue);
                 if ( tc == null )
                      throw new RuntimeException("column " + headerValue + " not found");
            }
        }
        else
        {
            TableColumn tc = _getFromDisplayedColumnList(headerValue);
            if ( tc != null )
            {
                super.removeColumn(tc);
                _hiddenTableColumns.addElement(tc);
                _refreshTable();
            }
            else
            {
                tc = _getFromHiddenColumnList(headerValue);
                if ( tc == null )
                    throw new RuntimeException("column " + headerValue + " not found");
            }
        }
    }

    private TableColumn _getFromHiddenColumnList(String headerValue)
    {
       Enumeration e = _hiddenTableColumns.elements();
       while ( e.hasMoreElements())
       {
           TableColumn tc = (TableColumn)e.nextElement();
           if ( tc.getHeaderValue().equals(headerValue))
               return tc;
       }
             return null;
    }

    private TableColumn _getFromDisplayedColumnList(String headerValue)
    {
       Enumeration e = this.getColumns();
       while ( e.hasMoreElements())
       {
           TableColumn tc = (TableColumn)e.nextElement();
           if ( tc.getHeaderValue().equals(headerValue))
               return tc;
       }
             return null;
    }

    private void _refreshTable()
    {
       _owner.sizeColumnsToFit(-1);
    }
}

/*
* Implements support for a popup menu which lets end user dynamically
* show/hide columns.
*/
class ColumnPropertiesPopupMenu implements ActionListener
{
   GridTableColumnModel _tm;
   ScrollablePopupMenu _menu = new ScrollablePopupMenu();

   ColumnPropertiesPopupMenu( GridTableColumnModel tm)
   {
      _tm = tm;
      _buildMenu();

   }


   protected void _buildMenu()
   {
      Object cols[] = _tm.getColumnHeaderValues();
      for ( int i=0; i < cols.length; i++)
      {
         String columnName = (String)cols[i];
         boolean b = _tm.getColumnState(columnName);
         JCheckBoxMenuItem m = new JCheckBoxMenuItem(columnName, b);
         _menu.addMenuItem(m);
         m.addActionListener(this);
      }
   }

   public void show(String headerValue, boolean showColumn)
   {
       _tm.setColumnState(headerValue, showColumn);
   }

   public boolean getColumnState(String headerValue)
   {
        return _tm.getColumnState(headerValue);
   }

   public void actionPerformed(ActionEvent e)
   {
       JCheckBoxMenuItem m = (JCheckBoxMenuItem)e.getSource();
       String s = m.getText();
       boolean b = m.getState();
       _tm.setColumnState(s, b);

   }

   public void showMenu(Component c, int x, int y)
   {
       Point p = _menu.findMenuPos(x, y, _menu.getSize(), c);
       _menu.show(c, p.x, p.y);
   }
}

/**
* cascading popup menu
*/
class ScrollablePopupMenu extends JPopupMenu

{
  int _count = 20;

  int _numberOfItemInThisColumn = 0;
  JComponent _addTo = this;
  JMenu _cascadeMenu = null; // currently used cascade menu
  String _more = Res.getString(Res.MORE);

  public ScrollablePopupMenu()
  {
  }

  /**
  *  add a menu item and cascade it if needed
  */
  public void addMenuItem(JMenuItem menuItem)
  {
     if ( _numberOfItemInThisColumn >= getNumberOfMenuItemsToDisplay() )
     {
         _numberOfItemInThisColumn = 0;
         _cascadeMenu = new JMenu(_more);
         // cascade
         _addTo.add(_cascadeMenu);
         _addTo = _cascadeMenu; // add new menu items to the sub menu now
     }
     _addTo.add(menuItem);
     _numberOfItemInThisColumn++;
  }

  public void setNumberOfMenuItemsToDisplay(int count)
  {
        _count = count;
  }

  public int getNumberOfMenuItemsToDisplay()
  {
        return _count;
  }

  public Point findMenuPos(int x, int y, Dimension d, Component c)
  {
       Point p = new Point(x,y);
       SwingUtilities.convertPointToScreen(p, c);
       Dimension scrDim = Toolkit.getDefaultToolkit().getScreenSize();

       int newx = p.x;
       int newy = p.y;

       if ( p.y + d.height > scrDim.height )
           newy = ((p.y - d.height) < 0) ? 0 : p.y - d.height;

       if ( p.x + d.width > scrDim.width )
           newx = ((p.x - d.width) < 0) ? 0 : p.x - d.width;

       Point retvalue = new Point(newx, newy);
       SwingUtilities.convertPointFromScreen(retvalue, c);
       return retvalue;
  }
}



