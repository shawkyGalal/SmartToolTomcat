/*
 * @(#)TreeDataSource.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.dacf.control.swing;

import java.util.Hashtable;
import java.util.Vector;
import javax.infobus.DataItem;
import javax.infobus.ImmediateAccess;
import javax.infobus.ScrollableRowsetAccess;
import javax.swing.SwingUtilities;
import javax.swing.tree.DefaultTreeModel;
import javax.swing.tree.TreePath;
import oracle.dacf.control.Control;
import oracle.dacf.dataset.ColumnInfo;
import oracle.dacf.dataset.DacObject;
import oracle.dacf.dataset.DataItemProperties;
import oracle.dacf.dataset.LiteralRowFilter;
import oracle.dacf.dataset.RowFilterCriteria;
import oracle.dacf.dataset.RowSetInfo;
import oracle.dacf.dataset.RowSetManager;
import oracle.dacf.dataset.SessionInfo;
import oracle.jbo.Row;
import oracle.jbo.RowSet;
import oracle.jbo.ViewObject;

// imports
/**
 ** An InfoBus enabled TreeModel.
 **
 ** @version PUBLIC 
 */
public class TreeDataSource
    extends DefaultTreeModel
{
    private String _rootNodeLabel;
    private static volatile int _rootRowSetCount = 0;
    private static final boolean _DEBUG = true;
    private TreeControl _tree;
    private TreeNodeDef[] _nodeDefs;
    private boolean _selfReferential;
    private Vector _editingDI;
    private Vector _listeners;
    private String _infoBusName = Control.DEFAULT_INFOBUS_NAME;

    private TreeControlNode _root;

    public TreeDataSource(TreeControlNode root)
    {
        this(null, root);
    }
    
    public TreeDataSource(TreeControl tree, TreeControlNode root)
    {
        
        super(root);
        _root = root;
        _editingDI = new Vector(3);
        _listeners = new Vector(3);
        setTreeControl(tree);
        if (tree != null)
        {
            String n = tree.getRootNodeLabel();
            if (n != null)
            {
                _root.setName(n);
            }
        }
    } // TreeDataSource

    /**
    ** Set the label of the root node in the tree. <P>
    **
    ** @param nuRootNodeLabel label of the root node
    ** @see #getRootNodeLabel()
    */
    public void setRootNodeLabel(String nuRootNodeLabel)
    {
        _rootNodeLabel = nuRootNodeLabel;
        if (_root != null)
        {
            _root.setName(_rootNodeLabel);
            fireTreeNodeChanged(_root);
        }
    } // setRootNodeLabel
    
    /**
    ** Returns the label of the root node in the tree. <P>
    **
    ** @return the label of the root node
    ** @see #setRootNodeLabel(String nuRootNodeLabel)
    */
    public String getRootNodeLabel()
    {
        if (_root != null)
        {
            _rootNodeLabel = _root.getName();
        }
        return(_rootNodeLabel);
    } // getRootNodeLabel
    
    public void setTreeControl(TreeControl nuTreeControl)
    {
        _tree = nuTreeControl;
    } // setTreeControl
    
    public TreeControl getTreeControl()
    {
        return(_tree);
    } // getTreeControl
    
    void setInfoBusName(String name)
    {
        _infoBusName = name;
        // remove all children
        _root.removeAllChildNodes();
        _root.setInfoBusName(name);
        // get all children
        _root.createAllChildNodes();
    }

    TreeNodeDef getChildNodeDef(TreeNodeDef def)
    {
        TreeNodeDef childDef = null;

        if (_selfReferential)
        {
            childDef = _nodeDefs[0];
        }
        else
        {
            for(int i = 0; i < _nodeDefs.length-1; i++)
            {
                if (def == _nodeDefs[i])
                {
                    childDef = _nodeDefs[i+1];
                    break;
                }
            }
        }
        return(childDef);
    } // getChildNodeDef
    
    TreeNodeDef getParentNodeDef(TreeNodeDef def)
    {
        TreeNodeDef parentDef = null;
        
        if (_selfReferential)
        {
            parentDef = _nodeDefs[0];
        }
        else
        {
            for(int i = 1; i < _nodeDefs.length; i++)
            {
                if (def == _nodeDefs[i])
                {
                    parentDef = _nodeDefs[i-1];
                    break;
                }
            }
        }
        return(parentDef);
    } // getParentNodeDef
    
    /**
    ** Sets the node definitions. <P>
    **
    ** A node is defined by the DataItem supplying the data, the column linking
    ** to the child node and the column that is displayed.<p>
    **
    ** The node definitions is as follows:<br>
    ** <ul>
    ** <li> data item name      - the name of the RowsetAccess supplying data
    ** <li> link column name    - the column linking to child nodes
    ** <li> display column name - the column whose value is displayed
    ** </ul>
    **
    ** The self-referential property will be set to false if the length of
    ** <tt>def</tt> is greater than 1.
    **
    ** @param defs an array of arrays of Strings listing the node definition
    ** @see #getNodeDefinitions()
    ** @see #setSelfReferential(boolean selfReferential)
    */
    public void setNodeDefinitions(TreeNodeDef[] defs)
    {
        // gotta nuke the current tree
        _selfReferential =
            (defs != null && defs.length == 1 && defs[0].isSelfReferential());
        _nodeDefs = defs;

        if (_selfReferential && _nodeDefs != null)
        {
            _makeRootRowset();
        }
        
        // delete the tree and release all dataitems ("free" the trees...)
        _root.destroy();
        if (_nodeDefs != null && _nodeDefs.length > 0)
        {
            _root = new TreeControlNode(null, _nodeDefs[0],
                                        _nodeDefs[0].getRowsetItem(), this);
            _root.setInfoBusName(_infoBusName);
        }
        else
        {
            _root = new TreeControlNode();
        }
        _root.setName(_rootNodeLabel);
        setRoot(_root);
        // notify the TreeControl that the tree structure has changed
        nodeStructureChanged(_root);
    } // setNodeDefinitions
    
    /**
    ** Returns the node definitions. <P>
    **
    ** A node is defined by the DataItem supplying the data, the column linking
    ** to the child node and the column that is displayed. <p>
    **
    ** The node definitions is as follows:<br>
    ** <ul>
    ** <li> data item name      - the name of the RowsetAccess supplying data
    ** <li> link column name    - the column linking to child nodes
    ** <li> display column name - the column whose value is displayed
    ** </ul>
    **
    **
    ** @return an array of arrays of Strings listing the node definition
    ** @see #setNodeDefinitions(String[][3] defs)
    */
    public TreeNodeDef[] getNodeDefinitions()
    {
        return(_nodeDefs);
    } // getNodeDefinitions
    
    /**
    ** Sets whether the nodes definitions are self-referential. <P>
    **
    ** A self-referential relationship is one where the link column points to
    ** another node of the same "shape".  Generally speaking, when the node
    ** definitions define a self-referential relationship, there should be only
    ** a single node definition.
    **
    ** @param selfReferential whether the nodes definitions are
    **                        self-referential.
    ** @see #isSelfReferential()
    ** @see #setNodeDefinitions(String[][3] defs)
    ** @see #getNodeDefinitions()
    */
    public void setSelfReferential(boolean selfReferential)
    {
        _selfReferential = selfReferential;
    } // setSelfReferential
    
    /**
    ** Returns whether the nodes definitions are self-referential. <P>
    **
    ** A self-referential relationship is one where the link column points to
    ** another node of the same "shape".  Generally speaking, when the node
    ** definitions define a self-referential relationship, there should be only
    ** a single node definition.
    **
    ** @return whether the nodes definitions are self-referential.
    ** @see #setSelfReferential(boolean selfReferential)
    ** @see #setNodeDefs(String[][3] defs)
    ** @see #getNodeDefs()
    */
    public boolean isSelfReferential()
    {
        return(_selfReferential);
    } // isSelfReferential

    public void valueForPathChanged(TreePath tp, Object newValue)
    {
        Object last = tp.getLastPathComponent();

        super.valueForPathChanged(tp, newValue);
        if (last instanceof TreeControlNode)
        {
            TreeControlNode parent =
                (TreeControlNode)((TreeControlNode)last).getParent();
            TreeNodeData data = parent.getTreeNodeData();
            TreeNodeDef def =  data == null ? null : data.def;
            String dispName = def == null ? null : def.getDisplayColName();
            ScrollableRowsetAccess sra =
                def == null ? null : def.getOriginalRowset();

            if (sra != null)
            {
                try
                {
                    sra.setColumnValue(dispName, newValue);
                }
                catch(Exception ex)
                {
                    ;
                }
            }
        }
    }
    
    
    /**
    ** Fires the <TT>TreeStructureChanged</TT> and <TT>TreeDataChanged</TT>
    ** events to the Tree from the Event Dispatch thread. <P>
    ** This will be thread-safe for Swing. <P>
    */
    void fireTreeStructureChangedLater(final TreeControlNode node)
    {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                fireTreeStructureChanged(node);
            }
        });
    }

    /**
    ** Fires the <TT>TreeStructureChanged</TT> and <TT>TreeDataChanged</TT>
    */
    void fireTreeStructureChanged(TreeControlNode node)
    {
        nodeStructureChanged(node);
    }

    /**
    ** Fires the <TT>TreeChanged</TT> event to the Tree from the Event
    ** Dispatch thread. <P>
    ** This will be thread-safe for Swing. <P>
    */
    void fireTreeNodesChangedLater(final TreeControlNode node,
                                   final int[] changedIndices)
    {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                fireTreeNodesChanged(node, changedIndices);
            }
        });
    }

    /**
    ** Fires the <TT>TreeChanged</TT> event to the Tree.
    */
    void fireTreeNodesChanged(TreeControlNode node, int[] changedIndices)
    {
        nodesChanged(node, changedIndices);
    }

    /**
    ** Fires the <TT>TreeChanged</TT> event to the Tree from the Event
    ** Dispatch thread. <P>
    ** This will be thread-safe for Swing. <P>
    ** @param event The event.
    */
    void fireTreeNodeChangedLater(final TreeControlNode node)
    {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                fireTreeNodeChanged(node);
            }
        });
    }

    /**
    ** Fires the <TT>TreeChanged</TT> event to the Tree
    */
    void fireTreeNodeChanged(TreeControlNode node)
    {
        nodeChanged(node);
    }

    /**
    ** Fires the <TT>TreeNodesInserted</TT> event to the Tree from the Event
    ** Dispatch thread. <P>
    ** This will be thread-safe for Swing. <P>
    ** @param event The event.
    */
    void fireTreeNodesInsertedLater(final TreeControlNode node,
                                    final int[] addedIndices)
    {
        
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                fireTreeNodesInserted(node, addedIndices);
            }
        });
    }

    /**
    ** Fires the <TT>TreeNodesInserted</TT> event to the Tree
    */
    void fireTreeNodesInserted(TreeControlNode node, int[] addedIndices)
    {
        nodesWereInserted(node, addedIndices);
    }

    /**
    ** Fires the <TT>TreeNodesRemoved</TT> event to the Tree from the Event
    ** Dispatch thread. <P>
    ** This will be thread-safe for Swing. <P>
    ** @param event The event.
    */
    void fireTreeNodesRemovedLater(final TreeControlNode node,
                                   final int[] removedIndices,
                                   final Object[] removedNodes)
    {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                fireTreeNodesRemoved(node, removedIndices, removedNodes);
            }
        });
    }

    /**
    ** Fires the <TT>TreeNodesRemoved</TT> event to the Tree
    */
    void fireTreeNodesRemoved(TreeControlNode node, int[] removedIndices,
                              Object[] removedNodes)
    {
        nodesWereRemoved(node, removedIndices, removedNodes);
    }

    private void _makeRootRowset()
    {
        ImmediateAccess ia;
        ScrollableRowsetAccess nuSra = null;
        ScrollableRowsetAccess sra = _nodeDefs[0].getOriginalRowset();

        try
        {
            ia = (ImmediateAccess)sra.getColumnItem(_nodeDefs[0].getLinkColName());
            if (sra.getRow() < 1)
            {
                sra.first();
            }
            nuSra = (ScrollableRowsetAccess)ia.getValueAsObject();
            nuSra.setBufferSize(-1);
        }
        catch(Exception e)
        {
            nuSra = null;
        }
        if (nuSra != null && nuSra instanceof RowSetManager)
        {
            ScrollableRowsetAccess rootRsa;

            RowSetManager rsm = (RowSetManager)nuSra;
            RowSet rs = rsm.getRowSet();
            ViewObject vo = rs.getViewObject();
            String whereClause = null;
            String[] fkeys = _nodeDefs[0].getForeignKeyColNames();
            RowSetInfo rsi =
                (RowSetInfo)((DataItem)sra).getProperty(DataItemProperties.INFO_OBJECT);
            String rootRSName = _genRootRowSetName(rsi.getName());
            RowSetInfo rootRsi = (RowSetInfo)rsi.clone();
            RowSet rootRs = vo.createRowSet(rootRSName);
            String oldwc = rsi.getQueryCondition();
            Object[] queryParams = rootRs.getWhereClauseParams();

            // _debug("_makeRootRowset: name: " + rootRSName);
            // _debug("_makeRootRowset: rowset vo wc: " + wc);
            // _debug("_makeRootRowset: fk count: " + fkeys.length);
            // _debug("_makeRootRowset: queryParams count: " + queryParams);

            Object[] newQueryParams = new Object[queryParams.length + fkeys.length];
            System.arraycopy(queryParams, 0, newQueryParams, 0, queryParams.length);

            rootRs.setWhereClauseParams(newQueryParams);
            rootRs.setAssociationConsistent(true);
            rootRs.executeQuery();
            ((DacObject)rsm).setName(rootRSName);
            rsm.setRowSet(rootRs);

            for(int j = 0; j < fkeys.length; j++)
            {
                if (whereClause != null)
                {
                    whereClause = whereClause + " and (" +
                        _mapToColumn(sra, fkeys[j]) +
                        " is null)";
                }
                else
                {
                    whereClause = "(" + _mapToColumn(sra, fkeys[j]) +
                        " is null)";
                }
            }
            // _debug("whereClause: " + whereClause);
            if (oldwc != null && !oldwc.equals(""))
            {
                whereClause = "((" + oldwc + ") and " + whereClause + ")";
            }

            // _debug("clone's where clause: " + whereClause);
            rootRsi.setQueryCondition(whereClause);
            // force a new ViewObject instance
            rootRsi.setDataSourceName(rootRsi.getName());
            rootRsi.open(true);
            rootRsa = rootRsi.getRowsetAccess();
            rootRsa.setBufferSize(-1);
            
            try
            {
                // populate the rootRs
                Row[] rootRows =
                    ((RowSetManager)rootRsa).getRowSet().getAllRowsInRange();
                for(int i = rootRows.length-1; i >= 0; i--)
                {
                    rootRs.insertRow(rootRows[i]);
                }
            }
            catch(Exception e)
            {
                // _debug("Exception: " + e);
            }
            finally
            {
                // nuke the returned rowset
                rootRsi.close();
                SessionInfo session = rootRsi.getSession();
                if (session != null)
                {
                    session.removeRowSet(rootRsi);
                }
            }
            _nodeDefs[0].setRowsetItem(nuSra);
        }
    }

    private synchronized String _genRootRowSetName(String name)
    {
        return(name + "_root_" + _rootRowSetCount++);
    }
    
    private String _mapToColumn(ScrollableRowsetAccess sra, String attrName)
    {
        ImmediateAccess ia = null;
        String res = attrName;

        if (sra != null)
        {
            try
            {
                ia = (ImmediateAccess)sra.getColumnItem(attrName);
            }
            catch(Exception e)
            {
            }
        }
        
        if (ia != null)
        {
            res = (String)((DataItem)ia).getProperty(DataItemProperties.COLUMN_NAME);
        }
        return(res);
    }
    
    
    // this method know way too much about how DAC and JBO works
    private LiteralRowFilter _createRowFilter(ScrollableRowsetAccess src,
                                              ScrollableRowsetAccess des,
                                              String[] fkeys)
    {
        int index;
        String colName;
        LiteralRowFilter filter = null;
        Vector colNames = new Vector(1);
        RowSetInfo srcRSI =
            (RowSetInfo)((DataItem)src).getProperty(DataItemProperties.INFO_OBJECT);
        RowSetInfo desRSI = 
            (RowSetInfo)((DataItem)des).getProperty(DataItemProperties.INFO_OBJECT);
        ColumnInfo[] cols = srcRSI.getAttributeInfo();
        ColumnInfo[] cloneCols = desRSI.getAttributeInfo();
        Hashtable criteria = new Hashtable(1);

        
        for(int i = 0; i < fkeys.length; i++)
        {
            index = -1;
            for(int j = 0; index == -1 && j < cols.length; j++)
            {
                colName = cols[j].getName();
                if (fkeys[i].equals(colName))
                {
                    index = j;
                }
            }
            if (index != -1)
            {
                colNames.addElement(cloneCols[index].getName());
                criteria.put(cloneCols[index].getName(),
                             new RowFilterCriteria(RowFilterCriteria.IS_NULL,
                                                   null));
            }
        }
        if (colNames.size() > 0)
        {
            String[] names = new String[colNames.size()];

            filter = new LiteralRowFilter();
            colNames.copyInto(names);
            filter.setRowSet(desRSI);
            filter.setColumns(names);
            filter.setFilterCriteria(criteria);
        }
        
        return(filter);
    }

    private RowSetInfo _createRsiClone(int nodeDefIndex, RowSetInfo rsi,
                                       String[] fkeys)
    {
        TreeQueryListener tql;  
        RowSetInfo rsi_c;
        
        rsi_c = (RowSetInfo)rsi.clone();
        rsi_c.open(true);
        tql = new TreeQueryListener(rsi_c, rsi, fkeys);
        tql.register();
        _nodeDefs[nodeDefIndex].setQueryListener(tql);
        return(rsi_c);
    }

    private void _destroyRsiClone(int i)
    {
        SessionInfo session;
        DataItem di = (DataItem)_nodeDefs[i].getRowsetItem();
        RowSetInfo rsi =
            di == null ? null :
            (RowSetInfo)di.getProperty(DataItemProperties.INFO_OBJECT);
        TreeQueryListener tql =
            (TreeQueryListener)_nodeDefs[i].getQueryListener();
        
        if (tql != null)
        {
            tql.unregister();
        }
        if (rsi != null)
        {
            session = rsi.getSession();
            rsi.close();
            if (session != null)
            {
                session.removeRowSet(rsi);
            }
        }
    }
    
    // private static methods

    private static void NotImplemented(String s)
    {
        String msg = "Unimplemented method called: " + s;
        
        // _debug(msg);
        throw new RuntimeException(msg);
    }
    
    private static void _debug(String s)
    {
        if (_DEBUG)
        {
            System.out.println("TreeDataSource: " + s);
        }        
    } // _debug
    
}  // TreeDataSource


//
//   oracle/dacf/control/swing/TreeDataSource.java
//   Oracle JDeveloper
//   Copyright (c) 1999 by Oracle Corporation
//   All rights reserved. 
//
