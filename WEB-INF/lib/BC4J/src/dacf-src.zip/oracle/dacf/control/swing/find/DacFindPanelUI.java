/*
 * @(#)DacFindPanelUI.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.dacf.control.swing.find;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.net.URL;
import java.sql.Types;
import java.text.MessageFormat;
import java.util.Hashtable;
import java.util.Vector;
import javax.infobus.ScrollableRowsetAccess;
import javax.swing.BorderFactory;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.border.BevelBorder;
import oracle.dacf.control.swing.FindPanel;

/**
 *  The DacFindPanelUI implements the default UI for the FindPanel. It displays a
 *  text field for each queryable column along with a  label and tool tip text.
 *  It also displays buttons for find, reset etc., It delegates the find
 *  operation to the FindPanel.
 *
 *  @version   INTERNAL
 *  @see       FindPanel
 *
 */
public class DacFindPanelUI
    implements FindPanelUI, ActionListener
{
    /**
    * A handle to the parent so that we can delegate some of the functionality
    * like Find.
    */
    protected FindPanel _parent;

    /**
    * top level container
    */
    protected JPanel   _panel = new JPanel();

    /**
    * display icon here
    */
    protected JPanel   _iconPanel = new JPanel();

    /**
    * labels and text fields displayed in this panel
    */
    protected JPanel   _dataPanel = new JPanel();

    /**
    * outer panel which in turn houses _icon and _data panels.
    */
    protected JPanel   _contentPanel = new JPanel();

    /**
    * All our buttons go here.
    */
    protected JPanel   _buttonPanel = new JPanel();

    /**
    *  bottom panel contains the statusbar label and the button panels
    */
    protected JPanel _bottomPanel = new JPanel();

    /**
    *  title for the help dialog
    */
    private String   _helpDlgTitle = Res.getString(Res.FIND_DIALOG_TITLE);

    /**
    * help message
    */
    private String   _helpMessage = Res.getString(Res.FIND_HELP_MESSAGE);

    /**
    *  find button on the button panel
    */
    protected JButton _findButton =
        new JButton(Res.getString(Res.FIND_BUTTON_TEXT));

    /**
    *  reset button on the button panel
    */
    protected JButton _resetButton =
        new JButton(Res.getString(Res.RESET_BUTTON_TEXT));

    /**
    *  Close button on the button panel
    */
    protected JButton _closeButton =
        new JButton(Res.getString(Res.CLOSE_BUTTON_TEXT));

    /**
    *  help button on the button panel
    */
    protected JButton _helpButton =
        new JButton(Res.getString(Res.HELP_BUTTON_TEXT));

    /**
    *  OR button on the button panel
    */
    protected JButton _orButton =
        new JButton(Res.getString(Res.OR_BUTTON_TEXT));

    /**
    *  Remove button on the button panel
    */
    protected JButton _removeButton =
        new JButton(Res.getString(Res.REMOVE_BUTTON_TEXT));

    /**
    *  Remove button on the button panel
    */
    protected JButton _removeAllButton = new
        JButton(Res.getString(Res.REMOVE_ALL_BUTTON_TEXT));

    /**
    *  labels in the data panel. one label displayed for each queryable column
    */
    protected JLabel[] _label;

    /**
    *  text fields in the data panel. one text field displayed for each
    *  queryable column
    */
    protected JTextField[] _textField;

    /**
    * status bar control
    */
    protected JLabel _labelStatusBar =
        new JLabel(Res.getString(Res.FIND_STATUSBAR_INIT_TEXT));

    /**
    * buttons which bring up custom editors
    */
    protected JButton[] _buttonCustomEditor;

    /**
    * the actual editors used to edit a Find item
    */
    protected FindItemEditor[] _editor;

    /**
    * List of properties DacFindPanelUI implements
    */
    protected Hashtable _properties  = new Hashtable();

    /**
    *  command to implement each property
    */
    protected Hashtable _commands    = new Hashtable();

    /**
    * Directory where the image file for the icon is located
    */
    private static final String _IMAGES_DIR = "/oracle/dacf/images/";

    /**
    * image file name for the icon
    */
    private static final String _IMAGE_NAME = "search.gif";

    /**
    * Are we in debug mode ?
    */
    private static final boolean _DEBUG = true;

    /**
    * button id's. This id is used to generate notifications
    * (see DacFindPanelUIListener).
    *
    * Find button id
    */
    private static final int FIND_BUTTON = 0;

    /*
    * Reset button id
    */
    private static final int RESET_BUTTON = 1;

    /*
    * Close button id
    */
    private static final int CLOSE_BUTTON = 2;

    /*
    * Help button id
    */
    private static final int HELP_BUTTON = 3;

    /*
    * OR button id
    */
    private static final int OR_BUTTON = 4;

    /*
    * Remove button id
    */
    private static final int REMOVE_BUTTON = 5;


    /*
    * Remove All button id
    */
    private static final int REMOVE_ALL_BUTTON = 6;

    /**
    * button click listeners
    */
    protected Vector _buttonListeners =  new Vector();

    /**
    *  font for label
    */
    protected String _defaultLabelFontName =
        Res.getString(Res.LABEL_FONT_NAME);

    /**
    *  font for text field
    */
    protected String _defaultTextFontName =
        Res.getString(Res.TEXT_FONT_NAME);;

    /**
    *  button size
    */
    protected Dimension _preferredButtonSize = new Dimension(80,25);

    /**
    *  display find icon using this label
    */
    protected JLabel _labelIcon = new JLabel();

    /**
    *  tooltip text
    */
    private String _tooltipText =
        new String( Res.getString(Res.FIND_FIELD_TOOLTIP_TEXT));

    /**
    *  property values
    */
    private int _labelPosition = FindPanel.LEFT;

    /**
    * direction in which the text fields are laid out
    */
    private int _itemDirection  = FindPanel.Y_AXIS;

    /**
    *  do we show the find icon ?
    */
    private boolean _showFindIcon = true;

    /**
    *  do we show the status bar ?
    */
    private boolean _showStatusBar = true;

    /**
    *  find icon
    */
    protected Icon _findIcon = null;

    /**
    *  font for label
    */
    protected Font _labelFont = new Font(_defaultLabelFontName,Font.PLAIN, 12);

    /**
    *  font for text field
    */
    protected Font _textFont = new Font(_defaultLabelFontName,Font.PLAIN, 12);

    /**
    *  foreground color for the label
    */
    protected Color   _labelForeColor = new Color(0,0,0);

    /**
    *  background color for the label
    */
    protected Color   _labelBackColor = new Color(255,255,255);

    /**
    *  foreground color for the textfield
    */
    protected Color   _textForeColor = new Color(0,0,0);
    /**
    *  background color for the textfield
    */
    protected Color   _textBackColor = new Color(255,255,255);

    /**
    *  default column width for the text field
    */
    protected int     _textColumnWidth = 10;

    /**
    * FindPanel enabled/disabled
    */
    protected boolean _enabled = true;

    /**
    * order in which the find buttons are laid out
    */
    private static final int FIND_ORDER = 0;
    private static final int OR_ORDER = 1;
    private static final int REMOVE_ORDER = 2;
    private static final int REMOVE_ALL_ORDER = 3;
    private static final int RESET_ORDER =4;
    private static final int CLOSE_ORDER = 5;
    private static final int HELP_ORDER = 6;

    private static final int _buttonCount = 7;
    protected JButton _buttons[] =
    { _findButton, _orButton, _removeButton, _removeAllButton,
      _resetButton, _closeButton, _helpButton };

    protected boolean _buttonState[] = new boolean[_buttonCount];

    private static final String _findStatusBarExecFailed =
        Res.getString(Res.FIND_STATUSBAR_EXEC_FAILED);

    private static final String _findStatusBarExecSucc =
        Res.getString(Res.FIND_STATUSBAR_EXEC_SUCC);


    /**
    * This is the conatainer object to which the FindPanel is added
    * to.
    *
    * The NavigationBar uses this property to set the dialog object
    * used to display the FindDialog. The findpanelUI implementation
    * can use this object to close the dialog.
    *
    * @see NavigationBar.setFindPanelUI
    */
    Object _parentContainer = null;


    /**
    * Constructor
    */
    public DacFindPanelUI()
    {
        _findIcon = _loadDefaultIcon();
        _bottomPanel =  _createBottomPanel();

        // content panel contains the text fields
        _contentPanel = _createContentPanel();

        // tabbed pane
        JTabbedPane tabbedPane = _createTabbedContentPane(_contentPanel);

        // the find panel contains the content and the bottom panels
        _panel.setLayout(new BorderLayout());
        _panel.add(_bottomPanel, BorderLayout.SOUTH);
        //_panel.add(_contentPanel, BorderLayout.CENTER);
        _panel.add(tabbedPane, BorderLayout.CENTER);

        _setShowFindButton(new Boolean(true));
        _setShowORButton(new Boolean(true));
        _setShowRemoveButton(new Boolean(true));
        _setShowRemoveAllButton(new Boolean(true));
        _setShowCloseButton(new Boolean(true));
        _setShowResetButton(new Boolean(true));
        _setShowHelpButton(new Boolean(true));
        _setShowStatusBar(new Boolean(true));
    }

    /**
    *  set the parent which will use the customized UI panel.
    *  Implementors of this interface will make use of the 'parent' argument to
    *  retrive values to display and to execute query
    *
    *  @param parent
    */
    public void setParent(FindPanel parent)
    {
        _parent = parent;
    }

    /**
    * A notification from the parent that one or more data item names changed.
    * Implementation should rebuild the UI
    */
    public void itemChanged()
    {
        if ( _parent != null )
        {
            int colCount = _parent.getColumnCount();
            _textField = new JTextField[colCount];
            _label = new JLabel[colCount];
            for ( int i=0; i < colCount; i++)
            {
                _textField[i] = new JTextField(_textColumnWidth);
                _textField[i].setToolTipText(_getTooltipText(i));
                _label[i] = new JLabel(_getColumnDisplayLabel(i));
                _label[i].setHorizontalAlignment(SwingConstants.RIGHT);
            }
            if (_editor != null)
                _initEditorButtons(_editor);
            _rebuildUI();
        }
    }

    /**
    * A notification from the paraent that the column value changed.
    * Implementation should refresh the values for this column like the column
    * display label
    *
    * @param column whose value (some attribute) has changed
    */
    public void itemValueChanged(int column)
    {
        _textField[column].setText(_getColumnValue(column));
        _textField[column].setToolTipText(_getTooltipText(column));
        _label[column].setText(_getColumnDisplayLabel(column));
    }

    /**
    * return a Panel reflectiong the panel to be displayed.
    * @return Component built
    */
    public Component buildPanel()
    {
        return _panel;
    }

    /**
    * specify a property value to customize the UI
    *
    * @param property id for the property we are trying to set
    * @value property value
    */
    public void setProperty(int property, Object value)
    {
        switch (property)
        {
        case LABEL_POSITION:
            _setLabelPosition(value);
            break;
        case ITEM_DIRECTION :
            _setItemDirection(value);
            break;
        case SHOW_FIND_BUTTON:
            _setShowFindButton(value);
            break;
        case SHOW_RESET_BUTTON:
            _setShowResetButton(value);
            break;
        case SHOW_CLOSE_BUTTON:
            _setShowCloseButton(value);
            break;
        case SHOW_HELP_BUTTON:
            _setShowHelpButton(value);
            break;
        case SHOW_FIND_ICON:
            _setShowFindIcon(value);
            break;
        case FIND_ICON:
            _setFindIcon(value);
            break;
        case INNER_PANEL_LYT_MGR:
            break;
        case INNER_PANEL:
            break;
        case LABEL_FONT:
            _setLabelFont(value);
            break;
        case TEXT_FONT:
            _setTextFont(value);
            break;
        case LABEL_FORE_CLR:
            _setLabelForeColor(value);
            break;
        case TEXT_FORE_CLR:
            _setTextForeColor(value);
            break;
        case LABEL_BACK_CLR:
            _setLabelBackColor(value);
            break;
        case TEXT_BACK_CLR:
            _setTextBackColor(value);
            break;
        case TEXT_COLUMN_WIDTH:
            _setTextColumnWidth(value);
            break;
        case ITEM_EDITORS:
            _setCustomEditors(value);
            break;
        case SHOW_STATUS_BAR:
            _setShowStatusBar(value);
            break;
        case ENABLED :
            _setEnabled(value);
            break;
        case SHOW_OR_BUTTON:
            _setShowORButton(value);
            break;
        case SHOW_REMOVE_BUTTON:
            _setShowRemoveButton(value);
            break;
        case SHOW_REMOVE_ALL_BUTTON:
            _setShowRemoveAllButton(value);
            break;

        case PARENT_CONTAINER :
            _parentContainer = value;
            break;
        }
    }

    /**
    * get property value
    *
    * @param property id for the property we are interested in
    * @return property value
    */
    public Object getProperty(int property)
    {
        switch (property)
        {
        case LABEL_POSITION:
            return new Integer(_labelPosition);
        case ITEM_DIRECTION :
            return new Integer(_itemDirection);
        case SHOW_FIND_BUTTON:
            return new Boolean (_buttonState[FIND_ORDER]);
        case SHOW_RESET_BUTTON:
            return new Boolean (_buttonState[RESET_ORDER]);
        case SHOW_CLOSE_BUTTON:
            return new Boolean (_buttonState[CLOSE_ORDER]);
        case SHOW_HELP_BUTTON:
            return new Boolean (_buttonState[HELP_ORDER]);
        case SHOW_FIND_ICON:
            return new Boolean(_showFindIcon);
        case FIND_ICON:
            return _findIcon;
        case INNER_PANEL_LYT_MGR:
            break;
        case INNER_PANEL:
            return _panel;
        case LABEL_FONT:
            return _labelFont;
        case TEXT_FONT:
            return _textFont;
        case LABEL_FORE_CLR:
            return _labelForeColor;
        case TEXT_FORE_CLR:
            return _textForeColor;
        case LABEL_BACK_CLR:
            return _labelBackColor;
        case TEXT_BACK_CLR:
            return _textBackColor;
        case TEXT_COLUMN_WIDTH:
            return new Integer(_textColumnWidth);
        case ITEM_EDITORS:
            return _editor;
        case SHOW_STATUS_BAR:
            return new Boolean(_showStatusBar);
        case ENABLED :
            return new Boolean(_enabled);
        case SHOW_OR_BUTTON:
            return new Boolean (_buttonState[OR_ORDER]);
        case SHOW_REMOVE_BUTTON:
            return new Boolean (_buttonState[REMOVE_ORDER]);
        case SHOW_REMOVE_ALL_BUTTON:
            return new Boolean (_buttonState[REMOVE_ALL_ORDER]);
        }
        return null;
    }

    /**
    * Adds a button click listener to this control. <P>
    *
    * The listener will be notified when one of the button is clicked by
    * the user
    *
    * @param listener  The listener to add.
    * @see Control#addNavigatedListener
    */
    public final void addButtonClickListener(DacFindPanelUIListener listener)
    {
        _buttonListeners.addElement(listener);
    }

    /**
    * Removes a button listener  <P>
    *
    * @param listener  The listener to remove.
    */
    public final void removeButtonClickListener(DacFindPanelUIListener l)
    {
        _buttonListeners.removeElement(l);
    }

    // Action Listener interface
    /**
    * Button click occured
    *
    * @param e ActionEvent object with event details
    */
    public void actionPerformed(ActionEvent e)
    {
        Object source = e.getSource();
        if ( source == _findButton )
            _doButtonFind();
        else if ( source == _closeButton )
            _doButtonClose();
        else if ( e.getSource() == _helpButton)
            _doButtonHelp();
        else
            _doButtonReset();
    }

    /**
    *  get column value for specified column
    */
    private String _getColumnValue(int column)
    {
        Object columnValue = _parent.getColumnValue(column);
        return (columnValue==null) ? "" : columnValue.toString();
    }

    /**
    *  get colum display label for specified column
    *
    *  @param column index
    *  @return column display label
    */
    private String _getColumnDisplayLabel(int column)
    {
        return _parent.getColumnDisplayLabel(column);
    }

    /**
    *  rebuild the UI
    */
    private void _rebuildUI()
    {
        GridBagConstraints gc;

        _dataPanel.removeAll();
        _dataPanel.setLayout( new GridBagLayout());

        if ( _textField == null || _textField.length == 0)
        {
            String msg =
                Res.getString(Res.NO_QUERYABLE_COLUMNS_MSG);

            JPanel panel = new JPanel();
            JLabel label = new JLabel(msg);

            panel.add(label);

            gc =_setConstr(0, 1, 1, 1,
                           new Insets(5, 5, 5, 5),
                           0, 0, GridBagConstraints.NONE,
                           GridBagConstraints.EAST, 0,0);
            _dataPanel.add(panel, gc);
        }
        else
        {

            _applyProperties();

            int labelPos = _parent.getLabelPosition();
            int arrangeItem = _parent.getItemDirection();  // ABOVE

            if ( labelPos == FindPanel.LEFT)
            {
                if ( arrangeItem == FindPanel.X_AXIS)
                {
                    // labels left
                    // items left to right
                    int x =0;
                    int label_width = 1;
                    int text_width = 2;
                    for(int i=0; i < _textField.length; i++)
                    {
                        gc =_setConstr(x , 1,  label_width, 1,
                                       new Insets(5,5,5,5),
                                       0,0,GridBagConstraints.NONE,
                                       GridBagConstraints.EAST, 0,0);
                        _dataPanel.add(_label[i],gc);
                        x = x + label_width;

                        // text field
                        JPanel panel = new JPanel();
                        panel.setLayout( new BorderLayout());
                        panel.add(_textField[i], BorderLayout.CENTER);
                        if (( _buttonCustomEditor != null) &&
                            (_buttonCustomEditor[i] != null))
                            panel.add(_buttonCustomEditor[i],
                                      BorderLayout.EAST);

                        gc =_setConstr(x , 1,  text_width, 1,
                                       new Insets(5,5,5,5),
                                       0,0,GridBagConstraints.HORIZONTAL,
                                       GridBagConstraints.EAST, 1,0);
                        _dataPanel.add(panel,gc);
                        x = x + text_width;
                    }
                }
                else
                {
                    int textFieldHeight = 5;
                    for ( int i=0 ; i < _textField.length; i++)
                    {
                        // labels left
                        // items top down

                        // label field
                        gc = _setConstr(0 , i * textFieldHeight, 1, 1,
                                        new Insets(0,5,5,5),
                                        0,0,GridBagConstraints.NONE,
                                        GridBagConstraints.EAST, 0.1,0);
                        _dataPanel.add(_label[i],gc);

                        // text field
                        JPanel panel = new JPanel();
                        panel.setLayout( new BorderLayout());
                        panel.add(_textField[i], BorderLayout.CENTER);
                        if (( _buttonCustomEditor != null) &&
                            (_buttonCustomEditor[i] != null))
                            panel.add(_buttonCustomEditor[i],
                                      BorderLayout.EAST);

                        gc = _setConstr(1 , i* textFieldHeight , 3,
                                        textFieldHeight,
                                        new Insets(0,5,5,5), 0,0,
                                        GridBagConstraints.BOTH,
                                        GridBagConstraints.NORTH, 0.9,0);
                        _dataPanel.add(panel, gc);
                    }
                }
            }
            else
            {
                if ( arrangeItem == FindPanel.Y_AXIS)
                {
                    // label above
                    // items top down
                    int y = 0;
                    int label_width = 1;
                    int text_width = GridBagConstraints.REMAINDER;
                    for ( int i=0; i < _textField.length; i++)
                    {
                        _label[i].setHorizontalAlignment(SwingConstants.LEFT);
                        gc =_setConstr(0 , i * y,  label_width, 1,
                                       new Insets(0,5,0,1),
                                       0,0,GridBagConstraints.NONE,
                                       GridBagConstraints.WEST, 0,0);
                        _dataPanel.add(_label[i],gc);


                        JPanel panel = new JPanel();
                        panel.setLayout( new BorderLayout());
                        panel.add(_textField[i], BorderLayout.CENTER);
                        if (( _buttonCustomEditor != null) &&
                            (_buttonCustomEditor[i] != null))
                            panel.add(_buttonCustomEditor[i],
                                      BorderLayout.EAST);

                        gc =_setConstr(0, i * y + 1,  text_width, 1,
                                       new Insets(0,5,5,5),
                                       0,0,GridBagConstraints.HORIZONTAL,
                                       GridBagConstraints.WEST, 1,0);
                        _dataPanel.add(panel,gc);
                        y = y + 2 + 1; // 2 per field + 1 extra line
                    }
                }
                else
                {
                    // label above
                    // items left to right

                    int x =0;
                    int label_width = 1 ;
                    int text_width = 2;

                    for ( int i=0; i < _textField.length; i++)
                    {
                        _label[i].setHorizontalAlignment(SwingConstants.LEFT);
                        gc =_setConstr(x , 0 ,  label_width, 1,
                                       new Insets(1,5,0,5),
                                       0,0,GridBagConstraints.NONE,
                                       GridBagConstraints.WEST, 0,0);
                        _dataPanel.add(_label[i],gc);

                        JPanel panel = new JPanel();
                        panel.setLayout( new BorderLayout());
                        panel.add(_textField[i], BorderLayout.CENTER);
                        if (( _buttonCustomEditor != null) &&
                            (_buttonCustomEditor[i] != null))
                            panel.add(_buttonCustomEditor[i],
                                      BorderLayout.EAST);

                        gc =_setConstr(x, 1,  text_width, 1,
                                       new Insets(5,5,5,5),
                                       0,0,GridBagConstraints.HORIZONTAL,
                                       GridBagConstraints.WEST, 1,0);
                        _dataPanel.add(panel,gc);
                        x = x  + label_width + text_width;
                    }
                }
            }
        }
    }

    /**
    * Helper method to layout the UI using GridBagLayout
    */
    private GridBagConstraints _setConstr(int gridx, int gridy,
                                          int gridwidth, int gridheight,
                                          Insets insets, int ipadx, int ipady,
                                          int fill, int anchor,
                                          double weightx, double weighty)
    {
        GridBagConstraints gc = new GridBagConstraints();

        gc.gridx = gridx;
        gc.gridy = gridy;

        gc.gridwidth = gridwidth;
        gc.gridheight = gridheight;

        gc.insets = insets;

        gc.ipadx = ipadx;
        gc.ipady = ipady;

        gc.fill = fill;

        gc.anchor = anchor;

        gc.weightx = weightx;
        gc.weighty = weighty;

        return gc;
    }

    /**
    * Creates the button panel. The button panel contains Find, Help and
    * Reset buttons
    */
    private JPanel _createButtonPanel()
    {
        JPanel panel = new JPanel();
        panel.setLayout( new FlowLayout());

        _findButton.addActionListener(this);
        _orButton.addActionListener(this);
        _removeButton.addActionListener(this);
        _removeAllButton.addActionListener(this);
        _resetButton.addActionListener(this);
        _closeButton.addActionListener(this);
        _helpButton.addActionListener(this);

        // button mnemonics
        _findButton.setMnemonic(Res.getString(Res.FIND_BUTTON_MNEMONIC).charAt(0));
        _orButton.setMnemonic(Res.getString(Res.OR_BUTTON_MNEMONIC).charAt(0));
        _removeButton.setMnemonic(Res.getString(Res.REMOVE_BUTTON_MNEMONIC).charAt(0));
        _removeAllButton.setMnemonic(Res.getString(Res.REMOVE_ALL_BUTTON_MNEMONIC).charAt(0));
        _resetButton.setMnemonic(Res.getString(Res.RESET_BUTTON_MNEMONIC).charAt(0));
        _closeButton.setMnemonic(Res.getString(Res.CLOSE_BUTTON_MNEMONIC).charAt(0));
        _helpButton.setMnemonic(Res.getString(Res.HELP_BUTTON_MNEMONIC).charAt(0));

        // preferred size
        _findButton.setPreferredSize(_preferredButtonSize);
        _orButton.setPreferredSize(_preferredButtonSize);
        _removeButton.setPreferredSize(_preferredButtonSize);
        _removeAllButton.setPreferredSize(new Dimension(100,25));
        _resetButton.setPreferredSize(_preferredButtonSize);
        _closeButton.setPreferredSize(_preferredButtonSize);
        _helpButton.setPreferredSize(_preferredButtonSize);


        // temporary
        _orButton.setEnabled(false);
        _removeButton.setEnabled(false);
        _removeAllButton.setEnabled(false);

        return panel;
    }

    /**
    * create a tabbed version of content panel
    */
    protected JTabbedPane _createTabbedContentPane(JPanel contents)
    {

        JTabbedPane tabbedPane = new JTabbedPane();
        tabbedPane.addTab("Criteria 1", contents);
        return tabbedPane;
    }

    /**
    *  create a panel which contains the icon panel and the data panel
    */
    protected JPanel _createContentPanel()
    {
        _iconPanel = new JPanel();
        _iconPanel.setLayout(new BorderLayout(10,10));
        _iconPanel.setBorder( BorderFactory.createEmptyBorder(10,10,10,10));
        _labelIcon.setIcon(_findIcon);
        _iconPanel.add( _labelIcon, BorderLayout.NORTH);

        _dataPanel = new JPanel();
        _dataPanel.setLayout(new GridBagLayout());

        JScrollPane scrollPane = new JScrollPane();
        scrollPane.setViewportView(_dataPanel);
        scrollPane.setBorder(null);


        _contentPanel = new JPanel();
        _contentPanel.setLayout( new BorderLayout());
        _contentPanel.add( _iconPanel, BorderLayout.WEST);
        _contentPanel.add( scrollPane, BorderLayout.CENTER);

        return _contentPanel;
    }

    protected JPanel _createBottomPanel()
    {
        JPanel panel = new JPanel();
        panel.setLayout(new BorderLayout());
        _labelStatusBar.setBorder(BorderFactory.createBevelBorder(BevelBorder.LOWERED));
        _buttonPanel = _createButtonPanel();
        // bottomPanel contains the status bar and the buttonPanel
        panel.add( _labelStatusBar, BorderLayout.SOUTH);
        panel.add( _buttonPanel,BorderLayout.CENTER);
        return panel;
    }

    /**
    * Find button clicked
    */
    private void _doButtonFind()
    {
        _notifyButtonClick(FIND_BUTTON);
        if ( _parent != null)
        {
            if( _textField != null)
            {
                for ( int i=0 ; i < _textField.length; i++)
                    _parent.setColumnValue(i, _textField[i].getText());
                _parent.runQuery();
                // update status bar
                ScrollableRowsetAccess rs =
                    (ScrollableRowsetAccess)_parent.getDataItem();
                String status = "";
                if ( rs != null )
                {
                    int rc = rs.getRowCount();
                    if ( rc == -1)
                        status = _findStatusBarExecFailed;
                    else
                    {
                        String msg = _findStatusBarExecSucc;
                        Object arg[] = { new Integer( rc )};
                        status = MessageFormat.format(msg, arg);
                    }
                }
                _labelStatusBar.setText(status);

            }
        }
    }

    /**
    *  Reset button clicked
    */
    private void _doButtonReset()
    {
        _notifyButtonClick(RESET_BUTTON);
        _parent.resetFields();
    }

    /**
    * Close button clicked
    */
    private void _doButtonClose()
    {
        if ((_parentContainer != null ) && ( _parentContainer instanceof JDialog))
        {
             JDialog dlg = (JDialog)_parentContainer;
             dlg.hide();
        }
        _notifyButtonClick(CLOSE_BUTTON);
    }

    /**
    *  Help button clicked
    */
    private void _doButtonHelp()
    {
        _notifyButtonClick(HELP_BUTTON);
        _displayMessageDialog(_helpMessage,
                              JOptionPane.INFORMATION_MESSAGE);
    }

    /**
    * Helper method to display a message
    *
    * @param message to be displayed
    * @param style for the dialog
    */
    private void _displayMessageDialog(String message, int style)
    {
        JPanel helpPanel = new JPanel(new BorderLayout(), false);
        JTextArea area = new JTextArea(message, 6, 40);
        area.setLineWrap(true);
        area.setWrapStyleWord(true);
        area.setEditable(false);
        helpPanel.add(new JScrollPane(area),
                      BorderLayout.CENTER);
        JOptionPane.showMessageDialog(null,
                                      helpPanel,
                                      _helpDlgTitle,
                                      style);
    }


    /**
    * Initialize the Find Icon
    *
    * @return Icon for the find dialog
    */
    private Icon _loadDefaultIcon()
    {
        Class cl = DacFindPanelUI.class;
        URL img =  cl.getResource(_IMAGES_DIR + _IMAGE_NAME);
        if ( img != null)
            return (new ImageIcon(img));
        else
        {
            return null;
        }
    }


    /**
    * Helper method which set the properties
    */
    private void _applyProperties()
    {
        if ( _label != null)
        {
            for (int i=0; i < _label.length;i++)
            {
                _label[i].setBackground(_labelBackColor);
                _label[i].setForeground(_labelForeColor);
                _label[i].setFont(_labelFont);
            }
        }

        if ( _textField != null)
        {
            for (int i=0; i < _textField.length;i++)
            {
                _textField[i].setBackground(_textBackColor);
                _textField[i].setForeground(_textForeColor);
                _textField[i].setFont(_textFont);
                _textField[i].setColumns(_textColumnWidth);
            }
        }
        _enableControls(_enabled);
    }

    /**
    * Get tool tip text for a column
    *
    * @param column index for which the tooltip should be obtained
    * @return the tooltip text for the column
    */
    private String _getTooltipText(int column)
    {
        FindItemModel findItemModel = _parent.getFindItemModel(column);
        int sqlType = findItemModel.getSQLType();
        String tooltip =  null;

        if (( sqlType == Types.DATE) ||( sqlType == Types.TIME) ||
            ( sqlType == Types.TIMESTAMP))
        {
            tooltip = _tooltipText + " " + _getColumnDisplayLabel(column) +
                "( " + findItemModel.getSQLFormatString() + " )";
        }
        else
        {
            tooltip = _tooltipText + " " + _getColumnDisplayLabel(column);
        }
        return tooltip;
    }

    /**
    * set the layout manager for the inner panel
    *
    * @param value layout manager to use
    */
    private void _setInnerPanelLayoutManager(Object value)
    {
        _rebuildUI();
    }

    /**
    *  no-op
    */
    private void _setInnerPanel(Object value)
    {
    }

    /**
    * set label foreground color
    *
    * @param value label foreground color
    */
    private void _setLabelForeColor(Object value)
    {
        _labelForeColor = (Color)value;
        if ( _label != null)
        {
            for ( int i=0; i < _label.length; i++)
                _label[i].setForeground(_labelForeColor);
        }
    }

    /**
    * set label background  color
    *
    * @param value label background color
    */
    private void _setLabelBackColor(Object value)
    {
        _labelBackColor = (Color)value;
        if ( _label != null)
        {
            for(int i=0; i < _label.length; i++)
            {
                _label[i].setBackground(_labelBackColor);
            }
        }
    }

    /**
    * set the font for the label
    *
    * @param value font for the label
    */
    private void _setLabelFont(Object value)
    {
        _labelFont = (Font)value;
        if ( _label != null)
        {
            for ( int i=0; i < _label.length; i++)
                _label[i].setFont((Font)value);
        }
    }

    /**
    * set the label position. Label could be place either above or to the
    * left of the text field
    *
    * @param value label position
    */
    private void _setLabelPosition(Object value)
    {
        _labelPosition = ((Integer)value).intValue();
        _rebuildUI();
    }

    /**
    * specify the direction in which the items should be laid out. The items
    * could be laid out either from top to bottom or from left to right
    *
    * @param value item direction
    */
    private void _setItemDirection(Object value)
    {
        _itemDirection = ((Integer)value).intValue();
        _rebuildUI();
    }

    /**
    * set the background color for the text field
    *
    * @param value text background color
    */
    private void _setTextBackColor(Object value)
    {
        _textBackColor = (Color)value;
        if ( _textField != null)
        {
            for ( int i=0; i < _textField.length; i++)
            {
                _textField[i].setBackground((Color)value);
            }
        }
    }

    /**
    * set the foreground color for the text field.
    *
    * @param value foreground color for the textfield
    */
    private void _setTextForeColor(Object value)
    {
        _textForeColor = (Color)value;
        if ( _textField != null)
        {
            for ( int i=0; i < _textField.length; i++)
            {
                _textField[i].setForeground((Color)value);
            }
        }
    }

    /**
    * set the font for the text field
    *
    * @param value font for the text field
    */
    private void _setTextFont(Object value)
    {
        _textFont = (Font)value;
        if ( _textField != null)
        {
            for ( int i=0; i < _textField.length; i++)
            {
                _textField[i].setFont((Font)value);
            }
        }
    }

    /**
    * set the column width for the text field
    *
    * @param value textfield column width
    */
    private void _setTextColumnWidth(Object value)
    {
        _textColumnWidth = ((Integer)value).intValue();
        if ( _textField != null)
        {
            for ( int i=0; i < _textField.length; i++)
            {
                _textField[i].setColumns(_textColumnWidth);
            }
        }
    }

    /**
    * set the icon for the Find panel
    *
    * @param value icon for the find panel
    */
    private void _setFindIcon(Object value)
    {
        if ( value instanceof Icon)
        {
            _findIcon = (Icon)value;
            _labelIcon.setIcon(_findIcon);
        }
    }

    /**
    * should the find icon be displayed ?
    *
    * @param value boolean value to indicate if the Find icon should be
    *              displayed
    */
    private void _setShowFindIcon(Object value)
    {
        _showFindIcon = ((Boolean)value).booleanValue();
        if ( _showFindIcon )
            _contentPanel.add(_iconPanel, BorderLayout.WEST);
        else
            _contentPanel.remove(_iconPanel);
    }

    /**
    * should the Find button be displayed in the FindPanel
    *
    * @param value a boolean value to indicate if the Find button should be
    *              displayed
    */
    private void _setShowFindButton(Object value)
    {
        _showButtonHelper(FIND_ORDER, value);
    }

    /**
    * should the Close button be displayed in the FindPanel
    *
    * @param value a boolean value to indicate if the Close button should be
    *              displayed
    */
    private void _setShowCloseButton(Object value)
    {
        _showButtonHelper(CLOSE_ORDER, value);
    }

    /**
    * should the Reset button be displayed in the FindPanel
    *
    * @param value a boolean value to indicate if the Reset button should be
    *              displayed
    */
    private void _setShowResetButton(Object value)
    {
        _showButtonHelper(RESET_ORDER, value);
    }

    /**
    * should the Help button be displayed in the FindPanel
    *
    * @param value a boolean value to indicate if the Help button should be
    *              displayed
    */
    private void _setShowHelpButton(Object value)
    {
        _showButtonHelper(HELP_ORDER, value);
    }


    private void _setCustomEditors(Object value)
    {
        _editor = (FindItemEditor[])value;
        _initEditorButtons(_editor);
        _rebuildUI();
    }

    /**
    * should the Status bar displayed in the FindPanel
    *
    * @param value a boolean value to indicate if the status bar should be
    * displayed
    */
    private void _setShowStatusBar(Object value)
    {
        _showStatusBar  = ((Boolean)value).booleanValue();
        if ( _showStatusBar )
            _bottomPanel.add(_labelStatusBar, BorderLayout.SOUTH);
        else
            _bottomPanel.remove(_labelStatusBar);

    }

    private void _setEnabled(Object value)
    {
        _enabled = ((Boolean)value).booleanValue();
        _enableControls(_enabled);
    }

    /**
    * should the OR button be displayed in the FindPanel
    *
    * @param value a boolean value to indicate if the OR button should be
    *              displayed
    */
    private void _setShowORButton(Object value)
    {
        _showButtonHelper(OR_ORDER, value);
    }

    /**
    * should the REMOVE button be displayed in the FindPanel
    *
    * @param value a boolean value to indicate if the Remove button should be
    *              displayed
    */
    private void _setShowRemoveButton(Object value)
    {
        _showButtonHelper(REMOVE_ORDER, value);
    }


    /**
    * should the Remove All button be displayed in the FindPanel
    *
    * @param value a boolean value to indicate if the RemoveAll button
    *              should be displayed
    */
    private void _setShowRemoveAllButton(Object value)
    {
        _showButtonHelper(REMOVE_ALL_ORDER, value);
    }

    private void _enableControls(boolean flag)
    {
        if ( _label != null)
            for (int i=0; i < _label.length;i++)
                _label[i].setEnabled(flag);

        if ( _textField != null)
            for (int i=0; i < _textField.length;i++)
                _textField[i].setEnabled(flag);

        _findButton.setEnabled(flag);
        _resetButton.setEnabled(flag);
    }

    private void _initEditorButtons(FindItemEditor[] editor)
    {
        _buttonCustomEditor = new  JButton[_editor.length];
        Dimension buttonSize = new Dimension(25,20);
        for (int i=0; i < _editor.length; i++)
        {
            if ((_editor != null) && (_editor[i] != null))
            {
                _buttonCustomEditor[i] = new JButton("...");
                _buttonCustomEditor[i].setPreferredSize(buttonSize);
            }
        }
        _installCustomEditors();
    }

    private void _installCustomEditors()
    {
        if ((_editor != null) && (_textField != null))
        {
            for (int i=0; i < _editor.length; i++)
            {
                if ((_editor[i] != null) && ( _textField[i] != null))
                {
                    final FindItemEditor editor = _editor[i];
                    final JTextField editThis = _textField[i];
                    final FindItemModel findItemModel = _parent.getFindItemModel(i);

                    _buttonCustomEditor[i].addActionListener( new ActionListener()
                                                              {
                                                                  public void actionPerformed(ActionEvent e)
                                                                      {
                                                                          Object o = editor.editItem(findItemModel,
                                                                                                     (Object)editThis.getText());
                                                                          editThis.setText(o.toString());
                                                                      }
                                                              }
                                                              );
                }
            }
        }
    }

    /**
    * notification that the button click happened. The notification will be
    * passed to the button click listeners
    *
    * @param whichButton a constant indicating which button was clicked
    */
    public void _notifyButtonClick(int whichButton)
    {
        DacFindPanelUIListener listeners[];
        int count = 0;
        synchronized (_buttonListeners)
        {
            count = _buttonListeners.size();
            listeners = new DacFindPanelUIListener[count];
            _buttonListeners.copyInto(listeners);
        }

        for (int i = 0; (i < count); i++)
        {
            DacFindPanelUIListener l = listeners[i];
            switch (whichButton)
            {
            case FIND_BUTTON:
                l.findButtonClicked();
                break;
            case RESET_BUTTON:
                l.resetButtonClicked();
                break;
            case CLOSE_BUTTON:
                l.closeButtonClicked();
                break;
            }// switch
        }
    }


    /**
    * A helper method to show/hide button
    *
    */
    private void _showButtonHelper(int order , Object val)
    {
        boolean state = ((Boolean)val).booleanValue();
        if ( state == _buttonState[order])
            return;
        else
        {
            if ( state )
                _buttonPanel.add(_buttons[order], _getButtonPosition(order));
            else
                _buttonPanel.remove(_buttons[order]);

            _buttonState[order] = state;
        }
    }

    private int _getButtonPosition(int order)
    {
        if ( order == 0 )
            return 0;

        int pos = 0;
        for ( int i=0; i <= (order -1); i++)
        {
            if ( _buttonState[i] )
                pos++;
        }
        return pos;
    }
}


