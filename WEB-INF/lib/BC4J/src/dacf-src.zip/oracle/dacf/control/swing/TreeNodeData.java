/*
 * @(#)TreeNodeData.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.dacf.control.swing;

import javax.infobus.ArrayAccess;
import javax.infobus.ImmediateAccess;
import javax.infobus.ScrollableRowsetAccess;

// imports
/**
 **  Contains a reference to the TreeNodeDef that was used to contruct a
 **  TreeControlNode.  This object can be retrieved from a TreeControlNode
 **  using the method TreeControlNode.getTreeNodeData()
 **
 ** @version public
 */
public class TreeNodeData
{
    /**
    **  a reference to the TreeNodeDef used when creating the TreeControlNode.
    */
    public TreeNodeDef def = null;
    ImmediateAccess value = null;
    ImmediateAccess[] pKeys = null;
    ImmediateAccess[] fKeys = null;
    ImmediateAccess detailsCol = null;
    ScrollableRowsetAccess details = null;
    ArrayAccess array = null; // into the details
    
    TreeNodeData()
    {
        
    }

    void clear()
    {
        def = null;
        value = null;
        pKeys = null;
        fKeys = null;
        detailsCol = null;
        details = null;
        array = null;
    }
}  // TreeNodeData
