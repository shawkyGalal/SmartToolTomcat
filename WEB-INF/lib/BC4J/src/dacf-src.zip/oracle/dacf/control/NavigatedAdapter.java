/*
 * @(#)NavigatedAdapter.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.dacf.control;

/**
 * This class provides an empty implementation of the NavigatedListener
 * interface.Listeners that are not interested in receiving
 * all the NavigatedEvents should subclass from
 * NavigatedAdapter and override appropriate methods.
 *
 */
public class NavigatedAdapter
    implements NavigatedListener
{
    private static final boolean _DEBUG = false;
    
    /**
    * This method is called when Control receiving the focus is bound to a
    * different column than the Control loosing the focus. </P>
    * @param event  A NAVIGATE_IN type of event with a column level change.
    */
    public void navigatedInColumn(NavigatedEvent event)
    {
        // _debug("InColumn", event);
    }

    /**
    * This method is called when Control loosing the focus is bound to a
    * different column than the Control gaining the focus. </P>
    * @param event  A NAVIGATE_OUT type of event with a column level change.
    */
    public void navigatedOutColumn(NavigatedEvent event)
    {
        // _debug("OutColumn", event);
    }

    /**
    * This method is called when Control receiving the focus is bound to a
    * different row than the Control loosing the focus. </P>
    * @param event  A NAVIGATE_IN type of event with a row level change.
    */
    public void navigatedInRow(NavigatedEvent event)
    {
        // _debug("InRow", event);
    }

    /**
    * This method is called when Control loosing the focus is
    * bound to a different column than the Control gaining the focus. </P>
    * @param event  A NAVIGATE_OUT type of event with a row level change.
    */
    public void navigatedOutRow(NavigatedEvent event)
    {
        // _debug("OutRow", event);
    }

    /**
    * This method is called when Control receiving the focus is bound
    * to a different queryview  than the Control loosing the focus. </P>
    * @param event  A NAVIGATE_IN type of event with a queryview level of
    *               change.
    */
    public void navigatedInQueryView(NavigatedEvent event)
    {
        // _debug("InQueryView", event);
    }


    /**
    * This method is called when Control loosing the focus is bound to a
    * different queryview than the Control gaining the focus. </P>
    * @param event  A NAVIGATE_OUT type of event with a queryview level change.
    */
    public void navigatedOutQueryView(NavigatedEvent event)
    {
        // _debug("OutQueryView", event);
    }


    /**
    * This method is called when Control receiving the focus is bound to a
    * different workunit than the Control loosing the focus.</P>
    *
    * @param event  A NAVIGATE_IN type of event with a work unit level of
    *               change.
    */
    public void navigatedInSession(NavigatedEvent event)
    {
        // _debug("InSession", event);
    }

    /**
    * This method is called when Control loosing the focus is bound to a
    * different workunit than the Control gaining the focus. </P>
    * @param event  A NAVIGATE_OUT type of event with a workunit level change.
    */
    public void navigatedOutSession(NavigatedEvent event)
    {
        // _debug("OutSession", event);
    }

    private void _debug(String name, NavigatedEvent event)
    {
        if (_DEBUG)
        {
            System.out.println("NavigatedAdapter.navigated" + name +
                               ": " + event);
        }
    }
}


