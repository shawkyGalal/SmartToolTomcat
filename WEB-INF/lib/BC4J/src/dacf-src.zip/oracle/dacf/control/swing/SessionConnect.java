/*
 * @(#)SessionConnect.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.dacf.control.swing;

import java.sql.SQLException;
import javax.infobus.DbAccess;
import javax.infobus.InfoBusItemAvailableEvent;
import oracle.dacf.control.DbAccessSupport;

/**
 * DbAccess aware object which automatically does a 'connect'.
 *
 * This object subscribes and waits for a DbAccess item to be available on the 
 * InfoBus and does a 'connect' when available. 
 *
 * @version SDK
 *
 * @see LoginDlg
 * @see DbAccessSupport
 */
public class SessionConnect
    extends DbAccessSupport
{
    /**
    *  name of the data item we are looking for
    */
    private String _dataItemName;

    /**
    * user name
    */
    private String _user;

    /**
    *  password
    */
    private String _password;

    /**
    *  connect string
    */
    private String _connectString;
   

    /**
    *  Constructor
    *
    * @param dataItemnName name of the session to connect to
    * @param user          user name
    * @param password      password
    * @param connectString connect string
    */
    public SessionConnect(String dataItemName, String user, String password,
                          String connectString)
    {
        super();
        _dataItemName = dataItemName;
        _user = user;
        _password = password;
        _connectString = connectString;
    }

    /**
    * This method is called by the <TT>InfoBus</TT> class on behalf of a data
    * producer that is announcing the availability of a new data item by
    * name. <P>
    */

    public void dataItemAvailable(InfoBusItemAvailableEvent event)
    {
        if ( _dataItemName.compareTo(event.getDataItemName()) == 0)
        {
            setDataItemName(_dataItemName);
            DbAccess dbAccess = (DbAccess)getDataItem();
            if (dbAccess != null)
            {
                try
                {
                    dbAccess.connect(_connectString, _user, _password);
                }
                catch(SQLException e)
                {
                }
            }
        }
    }
}
