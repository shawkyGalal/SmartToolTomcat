/*
 * @(#)CancellableButtonModelImpl.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.dacf.control.swing;

import java.awt.event.ActionEvent;
import java.awt.event.ItemEvent;
import java.util.Vector;
import javax.swing.DefaultButtonModel;

/**
 * Extends JFC's DefaultButtonModel to provide a two-state button model that
 * can be used by toggle buttons. The model can be either in selected or
 * deselected state at any time <P>
 *
 *
 * @version SDK
 */
public class CancellableButtonModelImpl
    extends DefaultButtonModel
    implements CancellableButtonModel
{
    private Vector _listeners = null;

    /**
    *   Constructs a default instance
    */
    public CancellableButtonModelImpl()
    {

    }
    /**
    * Add a vetoable change listener for the this model. </P>
    * @param listener listener to add
    */
    public synchronized void
        addSelectionChangingListener(SelectionChangingListener listener)
    {
        if (_listeners == null)
            _listeners = new Vector();

        _listeners.addElement(listener);
    }

    /**
    * Remove a existing vetoable change listener from model. </P>
    * @param listener listener to remove
    */
    public synchronized void
        removeSelectionChangingListener(SelectionChangingListener listener)
    {
        if (_listeners != null)
        {
            _listeners.removeElement(listener);
        }
    }

    /**
    *  Fires a SelectionChanging event
    *  @exception   ChangeVetoException    Indicates rejection of fire event.
    */
    protected void fireSelectionChanging() throws ChangeVetoException
    {
        Vector targets = null;
        synchronized(this)
        {
            if (_listeners != null)
                targets = (Vector)_listeners.clone();
            else
                return;
        }
        int count = targets.size();
        SelectionChangingEvent evt = new SelectionChangingEvent(this);

        for(int i = 0; i < count ; i++)
        {
            ((SelectionChangingListener)targets.elementAt(i)).selectionChanging(evt);
        }

    }

    /**
    *   Get the selected state of the model <P>
    *   @return true if model is selected else returns false
    */
    public boolean isSelected()
    {
        if (group != null)
        {
            return group.isSelected(this);
        }
        else
        {
            return (stateMask & SELECTED) != 0;
        }
    }


    /**
    * Sets the state of the model.
    * @param b true sets the state to selected,
    *          false sets the state to deselected
    */
    public void setSelected(boolean selected)
    {

        Boolean oldValue = new Boolean(isSelected());
        Boolean newValue = new Boolean(selected);


        if (group != null)
        {
            // use the group model instead
            group.setSelected(this, selected);
        }


        if (selected != isSelected())
        {
            // Attempt to select a button
            try
            {
                fireSelectionChanging();
            }
            catch(ChangeVetoException e)
            {
                return ;
            }
        }

        if (selected)
        {
            stateMask |= SELECTED;
        }
        else
        {
            stateMask &= ~SELECTED;
        }

        // Send ChangeEvent
        fireStateChanged();

        // Send ItemEvent
        fireItemStateChanged(
                             new ItemEvent(this,
                                           ItemEvent.ITEM_STATE_CHANGED,
                                           this,
                                           (this.isSelected() ?
                                            ItemEvent.SELECTED :
                                            ItemEvent.DESELECTED)));
    }


    /**
    * Sets the pressed state of the toggle button.
    *
    */
    public void setPressed(boolean pressed)
    {
        boolean selected = isSelected();
        if ((isPressed() == pressed) || !isEnabled())
        {
            return;
        }

        // Change selection state before
        // sending the pressed change event
        // Component is redrawn on pressed
        // event using the selection state
        if (!pressed && isArmed())
        {
            setSelected(!selected);
        }

        // Update pressed state
        if (pressed)
        {
            stateMask |= PRESSED;
        }
        else
        {
            stateMask &= ~PRESSED;
        }
        fireStateChanged();


        // If Mouse was released on the button
        if (!pressed && isArmed())
        {
            // If the selection changed
            if (selected != isSelected())
            {
                fireActionPerformed(
                                    new ActionEvent(this,
                                                    ActionEvent.ACTION_PERFORMED,
                                                    getActionCommand())
                                    );
            }
        }

    }
}
