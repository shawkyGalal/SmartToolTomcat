/*
 * @(#)GridCellEditor.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.dacf.control.swing;

import java.awt.Component;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.sql.SQLException;
import java.util.Locale;
import javax.infobus.ImmediateAccess;
import javax.infobus.RowsetValidationException;
import javax.infobus.ScrollableRowsetAccess;
import javax.swing.DefaultCellEditor;
import javax.swing.JTable;
import javax.swing.JTextField;

public class GridCellEditor
    extends DefaultCellEditor
    implements FocusListener
{
    private Object _item ;
    private static final boolean _DEBUG = false;
    
    public GridCellEditor(JTextField text)
    {
        super(text);
    }

    public Component getTableCellEditorComponent(JTable table, Object value,
                                                 boolean isSelected,
                                                 int row, int column)
    {
        // _debug("getting editor for cell: " + row + "," + column);
        Object dataItem = null;
        JTextField text = (JTextField)super.getComponent();

        if (table instanceof GridControlTable)
        {
            dataItem =
                ((GridControlTable)table)._getGridControl().getDataItem();
        }
        if (dataItem != null && dataItem instanceof ScrollableRowsetAccess)
        {
            ScrollableRowsetAccess rowset = (ScrollableRowsetAccess)dataItem;
            try
            {
                if (rowset.absolute(row + 1))
                {
                    _item = rowset.getColumnItem(column + 1);
                }
            }
            catch (RowsetValidationException e)
            {
                //XXX revert back the editing
            }
            catch (SQLException e)
            {

            }
            catch (IndexOutOfBoundsException e)
            {

            }
        }
        text.setText(value.toString());
        return(text);
    }

    public void focusLost(FocusEvent e)
    {
        // _debug("focusLost");
        if (!e.isTemporary() && _item != null)
        {
            Object oldVal =
                ((ImmediateAccess)_item).getPresentationString(Locale.getDefault());
            Object newVal = getCellEditorValue();

            if ( ( oldVal == null ) || !(oldVal.equals(newVal)))
            {
                stopCellEditing();
            }
        }
    }

    public void focusGained(FocusEvent e)
    {
        // _debug("focusGained: e: " + e);
    }
    
    private void _debug(String s)
    {
        if (_DEBUG)
        {
            System.out.println("GridCellEditor: " + s);
        }        
    } // _debug

}  // GridCellEditor

