/*
 * @(#)ChartDataSource.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.dacf.control.tdg.chart;

import javax.infobus.ArrayAccess;
import javax.infobus.DataItemAddedEvent;
import javax.infobus.DataItemChangeListener;
import javax.infobus.DataItemChangeManager;
import javax.infobus.DataItemDeletedEvent;
import javax.infobus.DataItemRevokedEvent;
import javax.infobus.DataItemValueChangedEvent;
import javax.infobus.DataItemView;
import javax.infobus.ImmediateAccess;
import javax.infobus.RowsetCursorMovedEvent;
import javax.infobus.ScrollableRowsetAccess;
import javax.swing.SwingUtilities;
import oracle.dacf.control.tdg.ChartControl;
import oracle.dacf.util.DesignTime;
import tdg.data.in.TDGDataGrid;

/**
 *  Data source for the chart control.
 *
 */
abstract public class ChartDataSource
      implements TDGDataGrid, DataItemChangeListener
{
    protected  ChartControl              _control;

    protected ScrollableRowsetAccess    _rowset;
    protected DataItemView              _view;

    /**
    *  Constructor
    */
    public ChartDataSource(ChartControl parent)
    {
        _control = parent;
    }

    public String getTitle()
    {
       return _control.getTitleString();
    }

    public String getSubtitle()
    {
       return  _control.getSubtitleString();
    }

    public String getFootnote()
    {
       return _control.getFootnoteString();
    }

    public String getX1AxisTitle()
    {
      return _control.getX1TitleString();
    }

    public String getY1AxisTitle()
    {
       return _control.getY1TitleString();
    }

    public String getO1AxisTitle()
    {
       return _control.getO1TitleString();
    }

    public String getO2AxisTitle()
    {
       return _control.getO2TitleString();
    }

    public String getY2AxisTitle()
    {
      return _control.getY2TitleString();
    }

    abstract public String columnLabel(int i);


    public int getColumns()
    {
       if (DesignTime.inDesignTime())
          return 5;

       if ( _rowset != null )
          return _rowset.getColumnCount();
       return 0;
    }

    abstract public String rowLabel(int i);

    public int getRows()
    {
        if (DesignTime.inDesignTime())
            return 5;

        if ( _rowset != null )
           return _rowset.getRowCount();
        return 0;
    }

    public Object getValue(int row, int col)
    {
        if (DesignTime.inDesignTime())
            return new Integer(row+col);
        if ( _view != null )
        {
            ArrayAccess access = _view.getView(_rowset.getRowCount());
            int coord[] = null;
            Object item = null;
            coord = new int[] { row, col };
            try
            {
                item = access.getItemByCoordinates(coord);
                if ((item != null) &&  (item instanceof ImmediateAccess))
                {
                    Object val =((ImmediateAccess)item).getValueAsObject();
                    return ((val==null) ? "" : val);
                }
            }
            catch(Exception exc)
            {
                return null;
            }
        }
        return null;
    }

    public boolean isDirty()
    {
       return false;
    }

    /**
    * Specify data source for row labels. The labels could be
    * <UL>
    * <LI> column values of a table
    * <LI> column names (display names) of a table
    * </UL>
    * <P>
    * The dataitem name of the column should be specified to indicate
    * the column values of a table
    *<P> The dataitem name of the rowset should be specified to indicate
    * the column display name of some table
    *
    * @see setRowLabelDataSource(Object)
    * @param dataitemName of the column values or the rowset
    */
    abstract public void setRowLabelDataItemName(String dataItemName);


    /**
    *  data item name for the row labels, if used
    */
    abstract public String getRowLabelDataItemName();

    abstract public void setRowLabelDataSource(ChartLabelDataSource labelSource);

    abstract public ChartLabelDataSource getRowLabelDataSource();

    abstract public void setRowLabel(Object[] labels);

    abstract public Object[] getRowLabel();

    /**
    * Specify data source for row labels. The labels could be
    * <UL>
    * <LI> column values of a table
    * <LI> column names (display names) of a table
    * </UL>
    * <P>
    * The dataitem name of the column should be specified to indicate
    * the column values of a table
    *<P> The dataitem name of the rowset should be specified to indicate
    * the column display name of some table
    *
    * @see setRowLabelDataSource(Object)
    * @param dataitemName of the column values or the rowset
    */
    abstract public void setColumnLabelDataItemName(String dataItemName);

    /**
    *  data item name for the row labels, if used
    */
    abstract public String getColumnLabelDataItemName();

    abstract public void setColumnLabelDataSource(ChartLabelDataSource labelSource);

    abstract public ChartLabelDataSource getColumnLabelDataSource();

    abstract public void setColumnLabel(Object[] labels);

    abstract public Object[] getColumnLabel();

    public synchronized void dataItemChanged(Object oldDataItem,
                                             Object newDataItem)
    {
        if (_rowset != null)
        {
            if (_rowset instanceof DataItemChangeManager)
            {
                ((DataItemChangeManager)_rowset).
                          removeDataItemChangeListener(this);
            }
           _rowset = null;
        }

        if (newDataItem instanceof DataItemChangeManager)
        {
             ((DataItemChangeManager)newDataItem).
                                                addDataItemChangeListener(this);
        }

        if ((newDataItem != null) &&
                (newDataItem instanceof ScrollableRowsetAccess))
        {
              _rowset = (ScrollableRowsetAccess)newDataItem;
              if (newDataItem instanceof DataItemView)
                  _view = (DataItemView)newDataItem;
              _updateBufferSize();
              _control.repaint();
        }
    }

    // DataItemChangedListener Interface

    /**
    * Indicates a changed value in the bound data item. <P>
    * A reference to the data item that changed can be obtained from the
    * event. <P>
    * @param event Contains change information.
    * @see javax.infobus.DataItemChangeListener#dataItemValueChanged
    */
    public void dataItemValueChanged(final DataItemValueChangedEvent e)
    {
       _updateBufferSize();
       _updateChart();
    }

    /**
    * Indicates that a new item was added to the bound aggregate data item
    * (e.g. <TT>ArrayAccess</TT>, a JDK Collection, etc). <P>
    * A reference to the data item that was added, and a reference to the one
    * that gained it, can be obtained from the event. <P>
    * @param event Contains details of the addition.
    * @see javax.infobus.DataItemChangeListener#dataItemAdded
    */
    public void dataItemAdded(final DataItemAddedEvent e)
    {

        _updateBufferSize();
        _updateChart();
    }

    /**
    * Indicates that an item was deleted from the bound aggregate data item
    * (e. g. <TT>ArrayAccess</TT>, a JDK Collection, etc). <P>
    * A reference to the data item that was deleted, and a reference to the
    * one that lost it, can be obtained from the event. <P>
    * @param event Contains details of the deletion.
    * @see javax.infobus.DataItemChangeListener#dataItemDeleted
    */
    public void dataItemDeleted(final DataItemDeletedEvent e)
    {
        _updateBufferSize();
        _updateChart();
    }

    /**
    * Indicates that the bound data item (and its sub-items, if any) has been
    * revoked, and is temporarily unavailable. <P>
    * A reference to the data item that was revoked can be obtained from
    * the event. <P>
    * @param event Contains details of the revoked data.
    * @see javax.infobus.DataItemChangeListener#dataItemRevoked
    */
    public void dataItemRevoked(DataItemRevokedEvent e)
    {
         _control.setDataFromDataGrid(ChartDataSource.this);
    }

    /**
    * Indicates that the cursor for the bound <TT>RowsetAccess</TT> data item
    * has changed rows. <P>
    * A reference to the rowset data item can be obtained from the event. <P>
    * @param event Contains details of the cursor move.
    * @see javax.infobus.DataItemChangeListener#rowsetCursorMoved
    */
    public void rowsetCursorMoved(RowsetCursorMovedEvent e)
    {
    }

    protected void _updateBufferSize()
    {
       if ( _rowset != null)
       {
           int rc = _rowset.getRowCount();
           if ( rc >= 1)
              _rowset.setBufferSize(rc);
       }
    }

    void _updateChart()
    {
        SwingUtilities.invokeLater(
                  new Runnable()
                  {
                      public void run()
                      {
                         _control.setDataFromDataGrid(ChartDataSource.this);
                      }
                 }
        );
    }


}

