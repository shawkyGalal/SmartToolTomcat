/*
 * @(#)ColumnModelSupport.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.dacf.control.swing;

import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.beans.PropertyVetoException;
import java.beans.VetoableChangeListener;
import java.sql.SQLException;
import javax.infobus.ArrayAccess;
import javax.infobus.DataItem;
import javax.infobus.DataItemAddedEvent;
import javax.infobus.DataItemChangeListener;
import javax.infobus.DataItemChangeManager;
import javax.infobus.DataItemDeletedEvent;
import javax.infobus.DataItemRevokedEvent;
import javax.infobus.DataItemValueChangedEvent;
import javax.infobus.DataItemView;
import javax.infobus.InfoBus;
import javax.infobus.InfoBusDataConsumer;
import javax.infobus.InfoBusItemAvailableEvent;
import javax.infobus.InfoBusItemRevokedEvent;
import javax.infobus.InfoBusMember;
import javax.infobus.InfoBusMembershipException;
import javax.infobus.RowsetCursorMovedEvent;
import javax.infobus.RowsetValidationException;
import javax.infobus.ScrollableRowsetAccess;
import javax.swing.AbstractListModel;
import oracle.dacf.control.Control;
import oracle.dacf.control.InfoBusManager;
import oracle.dacf.control.InfoBusManagerListener;
import oracle.dacf.control.InfoBusManagerReleaseEvent;
import oracle.dacf.dataset.DataItemProperties;
import oracle.dacf.dataset.InfoObject;
import oracle.dacf.rp.Consumer;
import oracle.dacf.util.InfoBusMemberHelper;

/**
 *  ColumnModelSupport provides a JFC's ListModel implementation which gets
 *  its items from a infobus <TT>ScrollableRowsetAccess</TT>.<P>
 *  ColumnModel binds itself to the given column
 *  in a <TT>ScrollableRowsetAccess</TT> dataItem and provides a read-only
 *  access to all the column values.
 *
 *
 *  @version SDK
 */
public class ColumnModelSupport
    extends AbstractListModel
    implements InfoBusMember, InfoBusDataConsumer, DataItemChangeListener,
               Consumer, InfoBusManagerListener
{
    private String _dataItemName;
    private String _rowsetItemName;
    private ScrollableRowsetAccess _rowset;
    private String _columnName;
    private int _columnIndex = -1;
    private int _selection = -1;        // 0 based selection
    private DataItemView _view;
    private ArrayAccess _list;
    private int _rowCount;
    private InfoBusMemberHelper _infoBusSupport;
    private String _infoBusName;
    private Control _control;


    protected boolean bDisableEvent = false;

    /**
    *  Constructs a ColumnModelSupport object
    */
    public  ColumnModelSupport(Control control)
    {
        _control = control;
        _infoBusSupport = new InfoBusMemberHelper(this);
        setInfoBusName(Control.DEFAULT_INFOBUS_NAME);
        _infoBusSupport.addInfoBusPropertyListener(this);
        InfoBusManager.getInstance().addInfoBusManagerListener(this);
    }


    /**
    *  Returns name of the infobus this model is connected to. <P>
    *  @return name of the infobus
    */
    public String getInfoBusName()
    {
        return _infoBusName;
    }

    /**
    *  Specifies name of the new infobus this model should be connected.<P>
    *  The model leaves the previous infobus before connecting to
    *  the given infobus. <P>
    *  @param  name of the infobus to connect to
    */
    public synchronized void setInfoBusName(String infoBusName)
    {
        if (infoBusName == _infoBusName ||
            (infoBusName != null && infoBusName.equals(_infoBusName)))
        {
            return;
        }

        if (_infoBusName != null)
        {
            _dropInfoBus();
        }
        _infoBusName = infoBusName;

        if (infoBusName != null)
        {
            try
            {
                _infoBusSupport.joinInfoBus(infoBusName);
                InfoBus infoBus = getInfoBus();
                if (infoBus == null)
                {
                    // XXX - throw exception?
                    return;
                }

                infoBus.addDataConsumer(this);

                if (_dataItemName != null)
                {
                    _bind(_dataItemName);
                }
            }
            catch (InfoBusMembershipException e)
            {
                // XXX - Do something useful here
            }
            catch (PropertyVetoException e)
            {
                // XXX - Do something useful here
            }
        }
    }

    // InfoBusManagerListener interface implementation
    public void releaseResources(InfoBusManagerReleaseEvent e)
    {
        if (_control != null && e.appliesTo(_control.getComponent()))
        {
            removeInfoBusPropertyListener(this);
            InfoBusManager.getInstance().removeInfoBusManagerListener(this);
            _dropInfoBus();
            _control = null;
			_releaseResourcesInternal(e); // for the derived class to release
        }
    }

	protected void _releaseResourcesInternal(InfoBusManagerReleaseEvent e)
	{
		// nothing to do
	}

    /**
    * Specifies the name of the dataItem this model uses to get its
    * list of values.
    * @param  Fully qaulified dataItemName published on the infobus
    */
    public synchronized void setDataItemName(String dataItemName)
    {

        if (dataItemName == _dataItemName ||
            (dataItemName != null && dataItemName.equals(_dataItemName)))
        {
            return;
        }
        _columnName=null;
        _columnIndex = -1;

        // JRS Don't simply set _rowset to null.  Make sure that the object
        // state is consistent by using _setupRowSet with a null rowset.
        _setupRowSet(null);

        _dataItemName = dataItemName;
        _bind(dataItemName);

    }

    /**
    * Gets the name of the dataItem this model uses to get its
    * list of values.
    * @return  Fully qaulified dataItemName
    */
    public String getDataItemName()
    {
        return _dataItemName;
    }


    // AbstractListModel overrides
    /*
    * Get the number of items this model contains.
    * @return the number of items
    */
    public int getSize()
    {
        return ((_rowCount < 0 ) ? 0 : _rowCount);
    }

    /**
    * Get the item at the specifed 0 based index
    * @return the item
    */
    public Object getElementAt(int index)
    {
        return (_getItemFromCursor(index));
    }


    /**
    *  Convenience method to move the cursor of the bound
    *  <TT>ScrollableRowsetAccess</TT> to the specified position
    *  @param selection  0 based, new cursor position.
    */

    public void setSelection(int selection)
    {
        int currSelection = _selection;
        if ( _rowset == null )
        {
            _bind(_dataItemName);
        }
        if (currSelection != selection && _rowset != null)
        {
            synchronized (_rowset)
            {
                try
                {
                    // Rowset is one based
                    _rowset.absolute(selection + 1);
                    _selection = selection;    // Update selection
                    fireContentsChanged(this, currSelection, selection);
                }
                catch (RowsetValidationException e)
                {
                }
                catch (SQLException e)
                {
                }
            }
        }
    }


    /**
    *  Get the 0 based cursor position of the ScrollableRowsetAccess this
    *  model is bound to
    *  @return cursor postion
    */
    public int getSelection()
    {
        return _selection;
    }

    private int _getColumnIndex()
    {
		if (_columnIndex == -1 && _columnName != null && _rowset != null)
        {
			_columnIndex = _findColumnIndex(_columnName);
		}
		return _columnIndex;
    }

	protected int _findColumnIndex(String columnName)
	{
		int index = -1;

		int n = _rowset.getColumnCount();
		for (int i = 0; i < n; i++)
		{
			String colName = null;
			try
			{
				DataItem di = (DataItem)_rowset.getColumnItem(i+1);
				colName =
					(String)di.getProperty(DataItemProperties.DATASOURCE_NAME);
			}
			catch(Exception e)
			{
				System.err.println("model : failed to determine column index");
				colName = _rowset.getColumnName(i+1);
			}
			if  ((colName != null) && (colName.equalsIgnoreCase(columnName)))
			{
				index = i+1;
				break;
			}
		}
        
        return index;

	}

    private Object _getItemFromCursor(int rowIndex)
    {
		int columnIndex = _getColumnIndex()-1;
		return _getItemFromCursor(rowIndex, columnIndex);
    }

	protected Object _getItemFromCursor(int rowIndex, int colIndex)
	{
		   // Array access is 0 based
        Object item = null;
        
		if (_view != null)
        {
            if (_view.getViewStart() != 0)
            {
                _view.setViewStart(0);
            }
            if (_list == null)
            {
                _list = _view.getView(-1);
            }
            if (_list != null)
            {
                int coord[] = new int[] { rowIndex, colIndex};
                try
                {
                    item = _list.getItemByCoordinates(coord);
                }
                catch(IndexOutOfBoundsException e)
                {
                    item = null;
                }
            }
        }
        return(item);
	}

    /**
    * Indicates a changed value in the bound data item. <P>
    * ColumnModelSupport notifies its listeners upon receiving this
    * event. <P>
    * @param event Contains change information.
    * @see javax.infobus.DataItemChangeListener#dataItemValueChanged
    */
    public void dataItemValueChanged(DataItemValueChangedEvent e)
    {
        if (_rowset != null)
        {
            int firstRow = 0;
            int oldRowCount = _rowCount;

            _rowCount = _rowset.getRowCount();

            boolean bRefresh = _isViewRefreshed(e);
            if ((oldRowCount != _rowCount ) || (bRefresh))
            {
                if (_view != null)
                {
                    _list = _view.getView(-1);
                }
				
				// view range refresh ==> dataItemValueChanged
				if (bRefresh)
				{
					rowsRevoked(); 
					rowsAvailable();
				}

                // size change occured, refresh the entire list
                if (!bDisableEvent)
                    fireContentsChanged(this, -1, -1);
                return;
            }

            int lastRow = getSize();

            // Check for properties indicating the starting row
            // and nuber of rows changed
            Object rowp = e.getProperty(Control.EVENT_PROPERTY_ROW);
			int rowCount = 0;
            if (rowp != null && rowp instanceof Integer)
            {
                firstRow = ((Integer)rowp).intValue();

                Object countp = e.getProperty(Control.EVENT_PROPERTY_ROW_COUNT);
                if (countp != null && countp instanceof Integer)
                {
                    rowCount = ((Integer)countp).intValue();
                    if (rowCount < 0)
                    {
                        firstRow = 0;
                    }
                    else
                    {
                        lastRow = firstRow + rowCount - 1;
                    }
                }
                else
                {
                    lastRow = firstRow;
                }
            }

			if (_isRowChanged(e))
			    rowsChanged(firstRow, rowCount);

            // Notify about changes
            if (!bDisableEvent)
				fireContentsChanged(this, firstRow, lastRow);
                
        }
    }

    /**
    * Indicates that a new item was added to the bound aggregate data item
    * (e.g. <TT>ArrayAccess</TT>, a JDK Collection, etc). <P>
    * A reference to the data item that was added, and a reference to the one
    * that gained it, can be obtained from the event. <P>
    * ColumnModelSupport notifies its listeners upon receiving this
    * event. <P>
    * @param event Contains details of the addition.
    * @see javax.infobus.DataItemChangeListener#dataItemAdded
    */
    public void dataItemAdded(final DataItemAddedEvent e)
    {
        // What's the current size
        int lastRow = getSize();

        // Get the currently selected row in the table.
        // Must be done before any notifications are sent to the table.
        int currentRow = 0;
        if (_rowset != null && _rowset.getRowCount() != 0)
        {
            currentRow = _rowset.getRow() - 1;
        }

        if (_view != null)
        {
            _list = _view.getView(-1);
        }

        // Check for properties indicating the starting row and row count
        // to minimize the repaints necessary.
        boolean gotProperties = false;
        Object rowp = e.getProperty(Control.EVENT_PROPERTY_ROW);
        if (rowp != null && rowp instanceof Integer)
        {
            int row = ((Integer)rowp).intValue();
            Object countp = e.getProperty(Control.EVENT_PROPERTY_ROW_COUNT);
            if (countp != null && countp instanceof Integer)
            {
                int rowCount = ((Integer)countp).intValue();
                if (rowCount > 0)
                {
                    _rowCount += rowCount;
					
					rowsAdded(row, rowCount);
                    fireIntervalAdded(this, row, row + rowCount - 1);
                    gotProperties = true;
                }
            }
        }

        if (! gotProperties)
        {
            fireContentsChanged(this, 0, lastRow);
        }
    }


    /**
    * Indicates that an item was deleted from the bound aggregate data item
    * (e. g. <TT>ArrayAccess</TT>, a JDK Collection, etc). <P>
    * A reference to the data item that was deleted, and a reference to the
    * one that lost it, can be obtained from the event. <P>
    * ColumnModelSupport notifies its listeners upon receiving this
    * event. <P>
    * @param event Contains details of the deletion.
    * @see javax.infobus.DataItemChangeListener#dataItemDeleted
    */
    public void dataItemDeleted(final DataItemDeletedEvent e)
    {
        // What's the current size
        int lastRow = getSize();
        int currentRow = 0;

        // Get the currently selected row in the table.
        // Must be done before any notifications are sent to the table.
        if (_rowset != null && _rowset.getRowCount() != 0)
        {
            currentRow = _rowset.getRow() - 1;
        }

        if (_view != null)
        {
            _list = _view.getView(-1);
        }

        // Check for properties indicating the starting row and row count
        // to minimize the repaints necessary.
        boolean gotProperties = false;
        Object rowp = e.getProperty(Control.EVENT_PROPERTY_ROW);
        if (rowp != null && rowp instanceof Integer)
        {
            int row = ((Integer)rowp).intValue();
            Object countp = e.getProperty(Control.EVENT_PROPERTY_ROW_COUNT);
            if (countp != null && countp instanceof Integer)
            {
                int rowCount = ((Integer)countp).intValue();
                if (rowCount > 0)
                {
                    _rowCount -= rowCount;
					rowsDeleted(row, rowCount);
                    fireIntervalRemoved(this, row, row + rowCount - 1);
                    gotProperties = true;
                }
            }
        }

        // If didn't find properties, refresh the whole grid.
        if (!gotProperties)
        {
            fireContentsChanged(this, 0, lastRow);
        }
    }

    /**
    * Indicates that the bound data item (and its sub-items, if any) has been
    * revoked, and is temporarily unavailable. <P>
    * A reference to the data item that was revoked can be obtained from
    * the event. <P>
    * ColumnModelSupport notifies its listeners upon receiving this
    * event. <P>
    * @param event Contains details of the revoked data.
    * @see javax.infobus.DataItemChangeListener#dataItemRevoked
    */
    public void dataItemRevoked(DataItemRevokedEvent e)
    {
        //_bind(null);
    }

    /**
    * Indicates that the cursor for the bound <TT>RowsetAccess</TT> data item
    * has changed rows. <P>
    * A reference to the rowset data item can be obtained from the event. <P>
    * ColumnModelSupport notifies its listeners upon receiving this
    * event. <P>
    * @param event Contains details of the cursor move.
    * @see javax.infobus.DataItemChangeListener#rowsetCursorMoved
    */
    public void rowsetCursorMoved(RowsetCursorMovedEvent e)
    {
        Object dataItem = e.getSource();
        if (dataItem != null && dataItem instanceof ScrollableRowsetAccess)
        {
            // Rowset is 1 based
            int newSelection = ((ScrollableRowsetAccess)dataItem).getRow() - 1;

            if (_selection != newSelection)
            {
                int oldSelection = _selection;
                _selection = newSelection;
                if ( !bDisableEvent)
                    fireContentsChanged(this, oldSelection, newSelection);
            }
        }
    }

    /**
    * Removes this object from its currently bound InfoBus and data item. <P>
    */
    private synchronized void _dropInfoBus()
    {
        _bind(null);

        InfoBus infoBus = getInfoBus();
        if (infoBus != null)
        {
            infoBus.removeDataConsumer(this);
        }

        try
        {
            _infoBusSupport.leaveInfoBus();
        }
        catch (InfoBusMembershipException e)
        {
            // Ignore
        }
        catch (PropertyVetoException e)
        {
            // Ignore
        }
    }

    private void _bind(String dataItemName)
    {
        Object rowset = null;
        
        if (dataItemName != null)
        {
            int i = dataItemName.lastIndexOf(InfoObject.ITEMNAME_DELIMITER);
            if (i > 0)
            {
                _columnName = dataItemName.substring(i+1);
                _rowsetItemName = dataItemName.substring(0, i);
            }
            InfoBus infoBus = getInfoBus();
            if (infoBus != null)
            {
                rowset = infoBus.findDataItem(_rowsetItemName, null, this);
            }
        }
        _setupRowSet(rowset);
    }

    private void _setupRowSet(Object rowset)
    {
        int oldRowCount = _rowCount;
		ScrollableRowsetAccess cursor;

        if (_rowset != null)
        {
            if (_rowset instanceof DataItemChangeManager)
            {
                ((DataItemChangeManager)_rowset).removeDataItemChangeListener(this);
            }
            _rowset = null;
            _rowCount = 0;
            _view = null;
			_list = null;
        }

        // Create a copy
        _rowset = (ScrollableRowsetAccess)rowset;
            
        if (rowset != null && rowset instanceof ScrollableRowsetAccess)
        {
            cursor = _rowset.newCursor();
            cursor.setBufferSize(-1); // all rows
            _rowCount = cursor.getRowCount();
			_list = null;

            if (cursor instanceof DataItemView)
            {
                _view = (DataItemView)cursor;
            }

            // Listen for changed items
            if (_rowset instanceof DataItemChangeManager)
            {
                ((DataItemChangeManager)_rowset).addDataItemChangeListener(this);
            }
        }

		if (_rowset == null)
			rowsRevoked();
		else
			rowsAvailable();

        // Notify listeners about data changes
		if (!bDisableEvent)
		{
			fireContentsChanged(this, 0,
                            (oldRowCount>_rowCount?oldRowCount:_rowCount));
		}
    }

    // Consumer methods
    public void available(String name, Object publishedObject)
    {
        // _debug(name + " announced as available");
        if (_rowsetItemName != null &&
            _rowsetItemName.equals(name))
        {
            _setupRowSet(publishedObject);
        }
    }

    public void revoked(String name, Object publishedObject)
    {
        // _debug(name + " revoked");
        if (_rowsetItemName != null &&
            _rowsetItemName.equals(name))
        {
            _setupRowSet(null);
        }
    }

    // InfoBusDataConsumer Interface

    /**
    * This method is called by the <TT>InfoBus</TT> class on behalf of a data
    * producer that is announcing the availability of a new data item by
    * name. <P>
    * @param event The event.
    */
    public void dataItemAvailable(InfoBusItemAvailableEvent event)
    {
        /*
		String dataItemName = event.getDataItemName();

        if (_dataItemName != null &&
            _dataItemName.equals(dataItemName))
        {
            _bind(dataItemName);
        }
		*/
    }

    /**
    * This method is called by the <TT>InfoBus</TT> class on behalf of a data
    * producer that is revoking the availability of a previously announced
    * data item. <P>
    * @param event The event.
    */
    public void dataItemRevoked(InfoBusItemRevokedEvent event)
    {
        /*
		String dataItemName = _dataItemName;

        if (dataItemName != null &&
            dataItemName.equals(event.getDataItemName()))
        {
            _bind(null);
        }
		*/
    }

    /**
    * This method gets called when the object's <TT>InfoBus</TT> property
    * is changed. <P>
    * The object is removed as a data consumer from its previous InfoBus,
    * and is added as a consumer to its new InfoBus. <P>
    * @param event The event.
    */
    public void propertyChange(PropertyChangeEvent event)
    {
        if (event.getPropertyName().equals("InfoBus"))
        {
            Object oldVal = event.getOldValue();
            Object newVal = event.getNewValue();

            if (oldVal != newVal)
            {
                if (oldVal != null && oldVal instanceof InfoBus)
                {
                    ((InfoBus)oldVal).removeDataConsumer(this);
                }

                if (newVal != null && newVal instanceof InfoBus)
                {
                    ((InfoBus)newVal).addDataConsumer(this);
                }
            }
        }
    }


    // InfobusMember interface

    /**
    *  Adds a PropertyChangeListener that will be alerted whenever the
    *  InfoBusMember's setInfoBus method is called and not vetoed.
    *  @param l  the PropertyChangeListener to be added
    */
    public void addInfoBusPropertyListener(PropertyChangeListener l)
    {
        _infoBusSupport.addInfoBusPropertyListener(l);
    }

    /**
    *
    * Removes a PropertyChangeListener
    * from the list of listeners requesting notification of an InfoBus change.
    *
    * @param l the listener to be removed
    */
    public void removeInfoBusPropertyListener(PropertyChangeListener l)
    {
        _infoBusSupport.removeInfoBusPropertyListener(l);
    }

    /**
    * Adds a VetoableChangeListener to the list of listeners that
    * will be alerted whenever the InfoBusMember's setInfoBus method is called.
    * @param l  the VetoableChangeListener to be added
    */
    public void addInfoBusVetoableListener(VetoableChangeListener l)
    {
        _infoBusSupport.addInfoBusVetoableListener(l);
    }


    /**
    *
    * Removes a VetoableChangeListener
    * from the list of listeners requesting notification of an InfoBus change.
    *
    * @param l the listener to be removed
    */

    public void removeInfoBusVetoableListener(VetoableChangeListener l)
    {
        _infoBusSupport.removeInfoBusVetoableListener(l);
    }

    /**
    * Gets the infobus this model is currently connected to. <P>
    * @return the infobus
    */
    public InfoBus getInfoBus()
    {
        return (_infoBusSupport.getInfoBus());
    }

    /**
    * Specifies the infobus this model should be connected to.<P>
    * @param infobus to connect to.
    * @exception PropertyVetoException thrown if any of the listeners
    *            vetoes this change.
    */
    public void setInfoBus(InfoBus infobus) throws PropertyVetoException
    {
        _infoBusSupport.setInfoBus(infobus);
    }

    protected boolean _isViewRefreshed(DataItemValueChangedEvent e)
    {
        Object o = e.getProperty(Control.EVENT_PROPERTY_VIEW_REFRESHED);
        if ( o instanceof Boolean)
            return ((Boolean)o).booleanValue();
        return false;
    }

	protected boolean _isRowChanged(DataItemValueChangedEvent e)
    {
        Object o = e.getProperty(Control.EVENT_PROPERTY_ROW_CHANGE);
        if ( o instanceof Boolean)
            return ((Boolean)o).booleanValue();
        return false;
    }

	protected ScrollableRowsetAccess getRowsetAccess()
	{
		return _rowset;
	}

	protected ArrayAccess getArrayAccess()
	{
		return _list;
	}


	protected void rowsAvailable()
	{
		// don't care		
	}

	protected void rowsRevoked()
	{
		// don't care
	}
    

	protected void rowsAdded(int startIndex, int count)
	{
		// don't care
	}

	protected void rowsDeleted(int startIndex, int count)
	{
		// don't care
	}

	protected void rowsChanged(int startIndex, int count)
	{
		// don't care
	}
}
