/*
 * @(#)FindActionQueryBuilder.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.dacf.control.swing.find;

import oracle.dacf.control.swing.find.FindItemModel;

/**
 *  A interface which lets customize building WHERE clause. The FindAction
 *  class uses this interface to build and execute a query. This
 *  interface lets users customize the way the Query is built and also
 *  let's him to modify the query and re-execute it.
 *
 *  The FindAction classes uses this interface in the following way.
 *
 *  setFindItemModel(model);//  column name,values used to construct query
 *
 *
 *  executeQuery(buildQuery());
 *  setProperty(FindActionQueryBuilder.NEW_ROW_COUNT, ...);
 *  while(canReExecuteQuery())
 *  {
 *      executeQuery(modifyQuery());
 *      setProperty(FindActionQueryBuilder.NEW_ROW_COUNT, ...);
 *  }
 *
 *
 *  @version  INTERNAL
 *  @see      FindAction
 */
public interface FindActionQueryBuilder
{
   /**
   *  property used to indicate the number of rows in the
   *  record set after executing query returned from
   *  buildQuery or modifyQuery methods
   */
   public static String ROW_COUNT = "RowCount"; // do not Localize


   // do not Localize
   public static String CASE_SENSITIVE_SEARCH = "SearchType";

   /**
   *  specify the model used to construct WHERE clause
   *
   *  @param model to retrive column values and SQL type
   */
   public void setFindItemModel(FindItemModel[] model);

   /**
   *  get the model used to construct WHERE clause
   *
   *  @return model use to construct query
   */
   public FindItemModel[]  getFindItemModel();


   /**
   *  The query can be modified and re-executed. Return a true value
   *  if the query has to executed again
   *
   *  @return true if query has to be reexecuted
   */
   public boolean canReExecuteQuery();


   /**
   * Build the WHERE clause for the query
   *
   * @return WHERE clause for the query
   */
   public String buildQuery();

   /**
   * modify the WHERE clause
   *
   * @return modified query
   */
   public String modifyQuery();

   /**
   *  set arbitary property value
   *
   * @param name of the property
   * @param value to be used to set the property
   */
   public void setProperty(String name, Object value);


   /**
   *  get property value
   *
   * @param name of the property
   * @param value to be used to set the property
   */
   public Object getProperty(String name);

}
