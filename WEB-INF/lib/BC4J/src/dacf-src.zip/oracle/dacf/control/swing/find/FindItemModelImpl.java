/*
 * @(#)FindItemModelImpl.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.dacf.control.swing.find;

import java.sql.Timestamp;
import java.sql.Types;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.infobus.DataItem;
import javax.infobus.ImmediateAccess;
import javax.infobus.ScrollableRowsetAccess;
import oracle.dacf.control.DataItemAccessHelper;
import oracle.dacf.dataset.AttributeInfo;
import oracle.dacf.dataset.ColumnInfo;
import oracle.dacf.dataset.DacfErrorMessageContext;
import oracle.dacf.dataset.DacfSeverity;
import oracle.dacf.dataset.DacfType;
import oracle.dacf.dataset.DataItemProperties;
import oracle.dacf.util.WhereClauseBuilder;
import oracle.dacf.util.errormanager.ErrorMessage;
import oracle.dacf.util.errormanager.ErrorMessageText;

/**
 *  FindItemModelImpl implements the FindItemModel interface. It binds to a
 *  dataitem representing a column value and retrives the SQL type, value
 *  and display label.
 *
 *  @version   INTERNAL
 *  @see       FindItemModel
 *  @see       FindAction
 *
 */
public class FindItemModelImpl
    extends DataItemAccessHelper
    implements FindItemModel
{
    /**
    * initial value of the column
    */
    private Object _value; // cache the data value. do not set the data object

    /**
    * name of the column
    */
    private String _columnName;

    /**
    * SQL type of the column
    */
    private int _sqlType;

    /**
    * Display label for the column
    */
    private String _columnDisplayName;

    /**
    * formatter use to format date values in some standard format
    */
    private SimpleDateFormat  _dateFormatter = new SimpleDateFormat();

    /**
    * SQL date format
    */
    public static String _defaultSQLDateFormatString = "YYYY-MM-DD";

    /**
    * SQL time format
    */
    public static String _defaultSQLTimeFormatString = "YYYY-MM-DD HH:MI:SS";

    /**
    * date format string used in date formatter
    */
    public static String _defaultDateFormatString = "yyyy-MM-dd";

    /**
    *  Constructor
    */
    public FindItemModelImpl()
    {
    }

    // FindItemModel implementation

    /**
    * get the column value
    */
    public Object getItemValue()
    {
       return _value;
    }

    /**
    * set the column value
    *
    * @param value value for the column
    */
    public void setItemValue(Object value)
    {
        _value = value;
    }

    /**
    * get the column name
    *
    * @return name of the column to use in the query
    */
    public String getColumnName()
    {
       return _columnName;
    }

    /**
    * get SQL type for this column
    *
    */
    public int getSQLType()
    {
       return _sqlType;
    }

    /**
    *  get column display name
    */
    public String getColumnDisplayName()
    {
       return _columnDisplayName;
    }

    /**
    * return the format string used. ( Special case used
    * in association with Date datatype)
    *
    * @return format string for this column
    */
    public String getFormatString()
    {
        ColumnInfo columnInfo = _getInfoObject();
        String formatString = columnInfo.getFormatString();
        if ( columnInfo != null )
        {

             int sqlType = _getSQLType(columnInfo);
             if (( sqlType == Types.DATE) ||( sqlType == Types.TIME) ||
                                             ( sqlType == Types.TIMESTAMP))
             {
                 formatString = _defaultDateFormatString;
                 return formatString;
             }
        }
        return formatString;
     }

     /**
     * get the SQL format string
     *
     * @return SQL format string
     */
     public String getSQLFormatString()
     {
         int sqlType = getSQLType();
         if (( sqlType == Types.DATE) ||( sqlType == Types.TIME) ||
                                     ( sqlType == Types.TIMESTAMP))
         {
             String date = WhereClauseBuilder.parseDataValue(getItemValue());
             if (_isTime(date))
                return _defaultSQLTimeFormatString;
             else if (_isDate(date))
                return  _defaultSQLDateFormatString;
             else
             {
                 if ( date.compareTo("") != 0)
                 {
                     DacfErrorMessageContext emc = new DacfErrorMessageContext();
                     ErrorMessageText s =
                          new ErrorMessageText("Find Error");
                     ErrorMessage em = new ErrorMessage(this,
                                     DacfType.SERVER_APPLICATION,
                                     DacfSeverity.ERROR, s, emc);
                     //ErrorManager.addErrorMessage(em);
                     System.out.println("Find : invalid date specified");
                 }
             }
         }
         return "";
     }


    /**
    * Sets the name of the InfoBus DataItem this object is bound to. <P>
    * The DataItem with the given name is searched for on the InfoBus, and
    * if found, is bound to this object. <P>
    * If the object is already bound to a DataItem, it is unbound first. <P>

    * @param dataItemName  The name of the DataItem to bind to.
    * @see #getDataItem
    */
    public void setDataItemName(String dataItemName)
    {
       super.setDataItemName(dataItemName);
       if (getDataItem() != null)
          _init();
    }


    /**
    * Sets the name of the InfoBus this transaction monitor is connected to. <P>
    * By default, the it is connected to the default InfoBus,
    * named <TT>Control.DEFAULT_INFOBUS_NAME</TT>. <P>
    * If the named InfoBus does not exist, it is created automatically. <P>
    * @param infoBusName   The name of the InfoBus to connect to.
    */
    public void setInfoBusName(String infoBusName)
    {
        super.setInfoBusName(infoBusName);
        if (getDataItem() != null)
           _init();
    }

    /**
    * override the derived class method inorder to initialize
    */
    protected void dataItemPublished()
    {
       super.dataItemPublished();
       _init();
    }

    // implementation helpers
    protected void _init()
    {
        ColumnInfo attrInfo = _getInfoObject();
       _columnName = _getColumnName((DataItem)getDataItem());
       _sqlType = _getSQLType(attrInfo);
       _columnDisplayName = _getColumnDisplayName(attrInfo);
       _value = _getItemValue();
    }

    /**
    * get the item value
    *
    * @return get the item value
    */
    protected Object _getItemValue()
    {
       //read the value from data item once
       if ( _value == null )
       {
           Object di = getDataItem();
           if ((di !=null) && (di instanceof ImmediateAccess))
           {
              int sqlType = getSQLType();
              if (( sqlType == Types.DATE) ||( sqlType == Types.TIME) ||
                                             ( sqlType == Types.TIMESTAMP))
              {
                  ColumnInfo columnInfo = _getInfoObject();
                  if ( columnInfo != null )
                  {
                       String formatString = getFormatString();
                       _dateFormatter.applyPattern(formatString);
                       Object val = ((ImmediateAccess)di).getValueAsObject();
                       try
                       {
                          if ( val instanceof Date)
                              return _dateFormatter.format((Date)val);

                          if ( val instanceof Timestamp)
                              return _dateFormatter.format((Timestamp)val);
                       }
                       catch (Exception exc)
                       {
                          return "";
                       }
                  }
                  else
                       return "";
              }
              else
                   _value = ((ImmediateAccess)di).getValueAsString();
           }
       }
       return _value;
    }

    protected String _getName(ColumnInfo attrInfo)
    {
        return ((attrInfo == null) ? "" : attrInfo.getName());
    }

    /**
    * get the column name
    *
    * @return name of the column to use in the query
    */
    protected String _getColumnName(ColumnInfo attrInfo)
    {
       return ((attrInfo == null) ? "" : attrInfo.getColumnName());
    }

    protected String _getColumnName(DataItem di)
    {
        return ((di == null) ? "" :((String)di.getProperty(
                                           DataItemProperties.COLUMN_NAME)));
    }

    /**
    * get the LOV Foriegn key name
    *
    * @return name of the foreign key to use in the query
    */
    protected String _getLOVForeignKeyName(ColumnInfo colInfo)
    {
       AttributeInfo attrInfo = null;
       if ( colInfo instanceof AttributeInfo)
       {
           attrInfo = (AttributeInfo)colInfo;
           return ((attrInfo == null) ? "" : attrInfo.getLOVForeignKeyName());
       }
       return "";
    }

    /**
    * get SQL type for this column
    *
    */
    protected int _getSQLType(ColumnInfo attrInfo)
    {
       return ((attrInfo == null) ? -1 : attrInfo.getSQLType());
    }

    /**
    *  get column display name
    */
    protected String _getColumnDisplayName(ColumnInfo attrInfo)
    {
       if ( attrInfo == null)
           return "";
       else
       {
          String label = attrInfo.getLabel();
          return ((label == null )? attrInfo.getName() : label);
       }
    }

    /**
    *  get the data object associated with the data item
    */
    protected ColumnInfo _getInfoObject()
    {
       Object di = getDataItem();
       if (( di != null ) && (di instanceof ImmediateAccess))
       {
           Object dataObj =
               ((DataItem)di).getProperty(DataItemProperties.INFO_OBJECT);
           if ((dataObj != null) &&( dataObj instanceof ColumnInfo))
              return (ColumnInfo)dataObj;
       }
       return _getInfoObjectFromParent();
    }

    /**
    * If the dataitem corresponding to column object is revoked because
    * the result set has zero rows, attempt to get the dataitem from the
    * parent rowset.
    */
    protected ColumnInfo _getInfoObjectFromParent()
    {
        DataItemAccessHelper parentObj = new DataItemAccessHelper();
        String s = _getParentDataItemName(getDataItemName());
        parentObj.setDataItemName(s);
        ScrollableRowsetAccess rs=(ScrollableRowsetAccess)
                                                    parentObj.getDataItem();
        if ( rs != null )
        {
            int columnCount = rs.getColumnCount();
            for ( int i= 1; i <= columnCount; i++)
            {
                try
                {
                    DataItem di = (DataItem)rs.getColumnItem(i);
                    if ( di != null )
                    {
                        String name = (String)di.getProperty(
                                                   DataItemProperties.NAME);
                        if ((name != null) && (name.equals(getDataItemName())))
                            return (ColumnInfo)di.getProperty(
                                              DataItemProperties.INFO_OBJECT);
                    }
                }
                catch(Exception e)
                {
                }
            }
        }
        return null;
    }

    private String _getParentDataItemName(String s)
    {
       int end = s.lastIndexOf('/');
       return ( (end == -1) ?  "" : s.substring(0, end));
    }


    /**
    * does the string represent time in YYYY-MM-DD HH:MI:SS format ?
    *
    * return true if the string represent time in above format
    */
    private boolean _isTime(String s)
    {
        try
        {
            Timestamp.valueOf(s);
            return true;
        }
        catch (IllegalArgumentException e)
        {
        }
        return false;
    }


    /**
    * does the string represent date in YYYY-MM-DD format ?
    *
    * return true if the string represent date in above format
    */
    private boolean _isDate(String s)
    {
        try
        {
            _dateFormatter.applyPattern(_defaultDateFormatString);
            _dateFormatter.parse(s);
            return true;
        }
        catch (ParseException e)
        {
        }
        return false;
    }
}
