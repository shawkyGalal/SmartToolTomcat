/*
 * @(#)StaticComboBoxDataSource.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.dacf.control.swing;

import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.beans.PropertyVetoException;
import java.beans.VetoableChangeListener;
import java.util.Vector;
import javax.infobus.DataItemAddedEvent;
import javax.infobus.DataItemChangeListener;
import javax.infobus.DataItemDeletedEvent;
import javax.infobus.DataItemRevokedEvent;
import javax.infobus.DataItemValueChangedEvent;
import javax.infobus.ImmediateAccess;
import javax.infobus.InfoBus;
import javax.infobus.InfoBusDataConsumer;
import javax.infobus.InfoBusItemAvailableEvent;
import javax.infobus.InfoBusItemRevokedEvent;
import javax.infobus.InfoBusMember;
import javax.infobus.InfoBusMembershipException;
import javax.infobus.RowsetCursorMovedEvent;
import javax.swing.DefaultComboBoxModel;
import oracle.dacf.control.Control;
import oracle.dacf.control.InfoBusManagerReleaseEvent;
import oracle.dacf.rp.Consumer;
import oracle.dacf.util.InfoBusMemberHelper;

public class StaticComboBoxDataSource
    extends DefaultComboBoxModel
    implements InfoBusMember, InfoBusDataConsumer, DataItemChangeListener,
               Consumer
{
    private String _dataItemName;
    private String _infoBusName;
    private ImmediateAccess _dataItem;
    private InfoBusMemberHelper _infoBusSupport;
    private static final boolean _DEBUG = true;
    
    /**
    ** Constructs a "static" or non-query based ComboBox Model.
    */
    public StaticComboBoxDataSource()
    {
        super();
        _init();
    } // StaticComboBoxDataSource
    
    /**
    ** Constructs a "static" or non-query based ComboBox Model.
    **
    ** @param items     The object that will be displayed in the ComboBox list
    */
    public StaticComboBoxDataSource(Object[] items)
    {
        super(items);
        _init();
    } // StaticComboBoxDataSource
    
    /**
    ** Constructs a "static" or non-query based ComboBox Model.
    **
    ** @param items     The object that will be displayed in the ComboBox list
    */
    public StaticComboBoxDataSource(Vector items)
    {
        super(items);
        _init();
    } // StaticComboBoxDataSource

    private void _init()
    {
        _infoBusSupport = new InfoBusMemberHelper(this);
        setInfoBusName(Control.DEFAULT_INFOBUS_NAME);
        _infoBusSupport.addInfoBusPropertyListener(this);
    }
    
    // InfoBusManagerListener interface implementation
    public void releaseResources(InfoBusManagerReleaseEvent e)
    {
         removeInfoBusPropertyListener(this);
         _dropInfoBus();
    }

    /**
    ** Makes the passed Object the current object in the ComboBox model. <P>
    **
    **
    ** @param nu the newly selected object
    */
    public void setSelectedItem(Object nu)
    {
        Object cur = super.getSelectedItem();

        try
        {
            if (_dataItem != null)
            {
                if (!cur.equals(nu))
                {
                    _dataItem.setValue(nu);
                }
            }
            super.setSelectedItem(nu);
        }
        catch(Exception e)
        {
            super.setSelectedItem(cur);
        }
    } // setSelectedItem

    /**
    *  Returns name of the infobus this model is connected to. <P>
    *  @return name of the infobus
    */
    public String getInfoBusName()
    {
        return _infoBusName;
    }

    /**
    *  Specifies name of the new infobus this model should be connected.<P>
    *  The model leaves the previous infobus before connecting to
    *  the given infobus. <P>
    *  @param  name of the infobus to connect to
    */
    public synchronized void setInfoBusName(String infoBusName)
    {
        if (infoBusName == _infoBusName ||
            (infoBusName != null && infoBusName.equals(_infoBusName)))
        {
            return;
        }

        if (_infoBusName != null)
        {
            _dropInfoBus();
        }
        _infoBusName = infoBusName;

        if (infoBusName != null)
        {
            try
            {
                _infoBusSupport.joinInfoBus(infoBusName);
                InfoBus infoBus = getInfoBus();
                if (infoBus == null)
                {
                    return;
                }

                infoBus.addDataConsumer(this);

                if (_dataItemName != null)
                {
                    _bind(_dataItemName);
                }
            }
            catch (InfoBusMembershipException e)
            {
                // XXX - Do something useful here
            }
            catch (PropertyVetoException e)
            {
                // XXX - Do something useful here
            }
        }
    }

    /**
    * Specifies the name of the dataItem this model uses to get its
    * list of values.
    * @param  Fully qaulified dataItemName published on the infobus
    */
    public synchronized void setDataItemName(String dataItemName)
    {

        if (dataItemName == _dataItemName ||
            (dataItemName != null && dataItemName.equals(_dataItemName)))
        {
            return;
        }

        _dataItemName = dataItemName;
        _bind(dataItemName);
    }

    /**
    * Gets the name of the dataItem this model uses to get its
    * list of values.
    * @return  Fully qaulified dataItemName
    */
    public String getDataItemName()
    {
        return _dataItemName;
    }


    // InfoBusMember interface
    /**
    *  Adds a PropertyChangeListener that will be alerted whenever the
    *  InfoBusMember's setInfoBus method is called and not vetoed.
    *  @param l  the PropertyChangeListener to be added
    */
    public void addInfoBusPropertyListener(PropertyChangeListener l)
    {
        _infoBusSupport.addInfoBusPropertyListener(l);
    }

    /**
    *
    * Removes a PropertyChangeListener
    * from the list of listeners requesting notification of an InfoBus change.
    *
    * @param l the listener to be removed
    */
    public void removeInfoBusPropertyListener(PropertyChangeListener l)
    {
        _infoBusSupport.removeInfoBusPropertyListener(l);
    }

    /**
    * Adds a VetoableChangeListener to the list of listeners that
    * will be alerted whenever the InfoBusMember's setInfoBus method is called.
    * @param l  the VetoableChangeListener to be added
    */
    public void addInfoBusVetoableListener(VetoableChangeListener l)
    {
        _infoBusSupport.addInfoBusVetoableListener(l);
    }


    /**
    *
    * Removes a VetoableChangeListener
    * from the list of listeners requesting notification of an InfoBus change.
    *
    * @param l the listener to be removed
    */

    public void removeInfoBusVetoableListener(VetoableChangeListener l)
    {
        _infoBusSupport.removeInfoBusVetoableListener(l);
    }

    /**
    * Gets the infobus this model is currently connected to. <P>
    * @return the infobus
    */
    public InfoBus getInfoBus()
    {
        return (_infoBusSupport.getInfoBus());
    }

    /**
    * Specifies the infobus this model should be connected to.<P>
    * @param infobus to connect to.
    * @exception PropertyVetoException thrown if any of the listeners
    *            vetoes this change.
    */
    public void setInfoBus(InfoBus infobus) throws PropertyVetoException
    {
        _infoBusSupport.setInfoBus(infobus);
    }
    
    /**
    * This method gets called when the object's <TT>InfoBus</TT> property
    * is changed. <P>
    * The object is removed as a data consumer from its previous InfoBus,
    * and is added as a consumer to its new InfoBus. <P>
    * @param event The event.
    */
    public void propertyChange(PropertyChangeEvent event)
    {
        if (event.getPropertyName().equals("InfoBus"))
        {
            Object oldVal = event.getOldValue();
            Object newVal = event.getNewValue();

            if (oldVal != newVal)
            {
                if (oldVal != null && oldVal instanceof InfoBus)
                {
                    ((InfoBus)oldVal).removeDataConsumer(this);
                }

                if (newVal != null && newVal instanceof InfoBus)
                {
                    ((InfoBus)newVal).addDataConsumer(this);
                }
            }
        }
    }


    
    // DataItemChangedListener interface
    public void dataItemValueChanged(DataItemValueChangedEvent event)
    {
        if (_dataItem != null)
        {
            Object val = _dataItem.getValueAsObject();
            super.setSelectedItem(val);
        }
    }

    public void dataItemAdded(DataItemAddedEvent event)
    {
    }

    public void dataItemDeleted(DataItemDeletedEvent event)
    {
    }
    
    public void dataItemRevoked(DataItemRevokedEvent event)
    {
    }

    public void rowsetCursorMoved(RowsetCursorMovedEvent event)
    {
    }

    // Consumer methods
    public void available(String name, Object publishedObject)
    {
        // _debug(name + " announced as available");
        if (_dataItemName != null &&
            _dataItemName.equals(name))
        {
            _bind(name);
            if (_dataItem != null)
            {
                super.setSelectedItem(_dataItem.getValueAsObject());
            }
        }
    }

    public void revoked(String name, Object publishedObject)
    {
        // _debug(name + " revoked");
        if (_dataItemName != null &&
            _dataItemName.equals(name))
        {
            _bind(null);
        }
    }

    //InfoBusDataConsumer interface
    public void dataItemAvailable(InfoBusItemAvailableEvent event)
    {
        String dataItemName = event.getDataItemName();
        if (_dataItemName != null &&
            _dataItemName.equals(dataItemName))
        {
            _bind(dataItemName);
            if (_dataItem != null)
            {
                super.setSelectedItem(_dataItem.getValueAsObject());
            }
        }
    }

    public void dataItemRevoked(InfoBusItemRevokedEvent event)
    {
        String dataItemName = _dataItemName;
        if (dataItemName != null &&
            dataItemName.equals(event.getDataItemName()))
        {
            _bind(null);
        }
    }

    /**
    * Removes this object from its currently bound InfoBus and data item. <P>
    */
    private synchronized void _dropInfoBus()
    {
        _bind(null);

        InfoBus infoBus = getInfoBus();
        if (infoBus != null)
        {
            infoBus.removeDataConsumer(this);
        }

        try
        {
            _infoBusSupport.leaveInfoBus();
        }
        catch (InfoBusMembershipException e)
        {
            // Ignore
        }
        catch (PropertyVetoException e)
        {
            // Ignore
        }
    }

    private void _bind(String dataItemName)
    {
        InfoBus infoBus = getInfoBus();

        if (dataItemName != null && infoBus != null)
        {
            Object obj = infoBus.findDataItem(dataItemName, null, this);

            if (obj instanceof ImmediateAccess)
            {
                _dataItem = (ImmediateAccess)obj;
            }
        }
    }


    /**
    ** <one line description>. <P>
    **
    ** <long description>
    **
    ** @param <name> <desc>
    ** @see #<method>(<sig>)
    ** @see <Class>#<method>(<sig>)
    */
    private void _debug(String s)
    {
        if (_DEBUG)
        {
            System.out.println("StaticComboBoxDataSource: " + s);
        }        
    } // _debug
    
}  // StaticComboBoxDataSource

