/*
 * @(#)RadioButtonControl.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.dacf.control.swing;

import javax.swing.JRadioButton;

/**
 * Radiobutton to be used with the data aware RadioPanelControl <P>
 * A radiobutton can be associated with a value which detrmines
 * the state of the button. If the value associated with the RadioButton
 * equals the value of the item bound to the RadioPanelControl the button
 * is considered to be selected.
 *
 * @version PUBLIC
 */
public class RadioButtonControl extends JRadioButton
{

  private RadioButtonModel _model = new RadioButtonModel();

  /**
   *  Construct a default RadioButtonControl
   */
  public RadioButtonControl()
  {
     this(null, null);
  }

  /**
   *  Construct a RadioButtonControl with the given label.<P>
   *  @param label Label to be used for the button
   */
  public RadioButtonControl(String label)
  {
     this(label, null);
  }

  /**
   *  Construct a RadioButtonControl with the given label and a value.<P>
   *  @param label Label to be used for the button
   *  @param dataValue Value to be associated with this button
   */
public RadioButtonControl(String label, String dataValue)
  {
     super(label);
     _model.setValue(dataValue);
     setModel(_model);
  }


  /**
   *  Sets the value associated with this button
   *  @param value Value to be associated with this button
   */
  public final void setValue(String value)
  {
      if(_model != null)
        _model.setValue(value);
  }

  /**
   *  Gets the value associated with this button
   *  @return Value associated with this button
   */

  public final String getValue()
  {
     if(_model != null)
       return _model.getValue();
     return null;
  }

}
