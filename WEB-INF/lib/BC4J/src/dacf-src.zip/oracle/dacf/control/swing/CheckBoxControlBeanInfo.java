/*
 * @(#)CheckBoxControlBeanInfo.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.dacf.control.swing;

import java.beans.PropertyDescriptor;

/**
 * bean info class for the check box control
 *
 * @version SDK
 */
public class CheckBoxControlBeanInfo extends ControlBeanInfoHelper
{
  /**
  * Constructor
  */
  public CheckBoxControlBeanInfo()
  {
    super();
  }

  /**
  * get the Class object for the bean
  *
  * @return Class object for the bean
  */
  protected Class getBeanClass()
  {
    return CheckBoxControl.class;
  }

  /**
  * get property descriptors for the bean
  *
  * @return PropertyDescriptors specific to this bean
  */
  protected PropertyDescriptor[] getAdditionalPropertyDescriptors()
  {
    try
    {
      PropertyDescriptor selectionValue =
            new PropertyDescriptor("selectionValue", getBeanClass(),
                "getSelectionValue", "setSelectionValue");

      PropertyDescriptor  deselectionValue =
            new PropertyDescriptor("deselectionValue", getBeanClass(),
                "getDeselectionValue", "setDeselectionValue");

      PropertyDescriptor  mode =
            new PropertyDescriptor("mode", getBeanClass(),
                  "getMode", "setMode");
      mode.setPropertyEditorClass(
           Class.forName("oracle.jdeveloper.daceditors.CheckBoxModeEditor"));


      PropertyDescriptor[] ret = { selectionValue, deselectionValue, mode };
      return ret;
    }
    catch (Exception exc)
    {
      exc.printStackTrace();
      return null;
    }
  }

}
