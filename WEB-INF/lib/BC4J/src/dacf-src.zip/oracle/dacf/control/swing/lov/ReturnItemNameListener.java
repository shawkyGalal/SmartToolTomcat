/*
 * @(#)ReturnItemNameListener.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.dacf.control.swing.lov;

import javax.infobus.DataItem;
import javax.infobus.InfoBusItemAvailableEvent;
import javax.infobus.InfoBusItemRevokedEvent;
import javax.infobus.RowsetAccess;
import oracle.dacf.control.DataItemAccessHelper;
import oracle.dacf.dataset.DataItemProperties;

/**
 *  This class discover the 'return item' names through RowsetAccess from the
 *  ResultSetInfo data producers.
 *
 *  The return item names are exposed thro' getProperty method of the
 *  RowsetAccess. This class listens for the dataItemAvailable event and
 *  queries the RowsetAccess for return item names
 *
 *  @version Internal
 *
 */
public class ReturnItemNameListener extends DataItemAccessHelper
{

  /**
  *  object capable of returning values based on return item names
  */
  private ReturnItem _returnItem;

  private static final String RETURN_ITEM_NAME = "ReturnItem";

  /**
  *  Constructor
  */
  public ReturnItemNameListener( ReturnItem returnItem)
  {
      _returnItem = returnItem;
  }

   /**
   * specify a InfoBus based dataset. Specify a data item name
   *
   * @param dataItemName - data item name to bind to
   */
   public void setDataItemName(String dataItemName)
   {
       super.setDataItemName(dataItemName);
       Object di = getDataItem();
       _getReturnItemNames(di);
   }

   public void available(String name, Object publishedObject)
   {
      super.available(name, publishedObject);

      if (publishedObject instanceof DataItem)
      {
         _getReturnItemNames((DataItem)publishedObject);
      }
   }

   // InfoBusDataConsumer Interface
   /**
   * This method is called by the <TT>InfoBus</TT> class on behalf of a data
   * producer that is announcing the availability of a new data item by
   * name. <P>
   */
   public void dataItemAvailable(InfoBusItemAvailableEvent event)
   {
       String dataItemName = getDataItemName();
       String name = event.getDataItemName();
       if (dataItemName.equals(name))
       {
           DataItem di = (DataItem)event.requestDataItem(this,null);
           _getReturnItemNames(di);
       }
   }

   protected void _getReturnItemNames(Object di)
   {
       if ((di != null) && ( di instanceof RowsetAccess))
       {
          // read return item names
          DataItem dataitem = (DataItem)di;
          Object[] returnItemNames =
          (Object [])dataitem.getProperty(DataItemProperties.RETURN_ITEM_NAMES);
          if ( returnItemNames != null )
          {
              for ( int i=0; i < returnItemNames.length; i++)
                 _returnItem.setReturnItemName(i,returnItemNames[i]);
          }
       }
   }

   /**
   * This method is called by the <TT>InfoBus</TT> class on behalf of a data
   * producer that is revoking the availability of a previously announced
   * data item. <P>
   *
   * @param event The event.
   */
   public void dataItemRevoked(InfoBusItemRevokedEvent event)
   {
       super.dataItemRevoked(event);
   }
}
