/*
 * @(#)NavigatingException.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.dacf.control;

/**
 * This exception is thrown to stop the NavigationEvent delivery cycle
 * and to transfer the focus to some other control. NavigationEvent's are
 * delivered when focus changes from one control to another.
 *
 * @see Control
 * @see NavigationEvent
 * @see NavigationListener
 *
 */
public class NavigatingException extends Exception
{

   /**
    *  Constructs a NavigatingException.
    *
    * @param target   Control to which focus should now be redirected
    */

   public NavigatingException(Control target)
   {
     this(target, "Redirect") ;
   }

   /**
    *  Constructs a NavigatingException.
    *
    * @param target   Control to which focus should now be redirected
    * @param msg      Detailed message describing the reason for
    *                 redirecting the focus
    */

   public NavigatingException(Control target, String msg)
   {
       super(msg);
       _target = target ;

   }


   /**
    * Returns the control that should receive focus.
    *
    * @return   the Control object
    */
   public final Control getTarget()
   {
      return _target ;
   }

   private Control _target = null ;
}


