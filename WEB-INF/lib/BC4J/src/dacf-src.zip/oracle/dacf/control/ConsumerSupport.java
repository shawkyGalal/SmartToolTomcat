/*
 * @(#)ConsumerSupport.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.dacf.control;

import javax.infobus.DataItem;
import javax.infobus.InfoBusMember;
import oracle.dacf.rp.Consumer;
import oracle.dacf.util.InfoBusMemberHelper;

public abstract class ConsumerSupport
    extends InfoBusMemberHelper
    implements Consumer
{

    public ConsumerSupport()
    {
        this(null);
    }

    public ConsumerSupport(InfoBusMember infobusmember)
    {
       super(infobusmember);
    }

    // Consumer methods
    public void available(String name, Object publishedObject)
    {
        // _debug(name + " announced as available");
        if (publishedObject instanceof DataItem)
        {
            _setDataItem(publishedObject);
        }
    }

    public void revoked(String name, Object publishedObject)
    {
        // _debug(name + " revoked");
        if (publishedObject == getDataItem())
        {
            _setDataItem(null);
        }
    }

    protected abstract void _setDataItem(Object di);
    public abstract Object getDataItem();


}  // ConsumerSupport
