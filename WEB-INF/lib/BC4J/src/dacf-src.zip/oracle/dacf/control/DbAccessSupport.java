/*
 * @(#)DbAccessSupport.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.dacf.control;

import java.beans.PropertyChangeEvent;
import java.beans.PropertyVetoException;
import javax.infobus.InfoBus;
import javax.infobus.InfoBusDataConsumer;
import javax.infobus.InfoBusItemAvailableEvent;
import javax.infobus.InfoBusItemRevokedEvent;
import javax.infobus.InfoBusMembershipException;
import oracle.dacf.util.InfoBusMemberHelper;

/**
 *  This class provides support to access a DbAccess data item.
 *
 *  @version INTERNAL
 * 
 *  @see DbAccessMonitor
 *  @see SessionConnect
 */
// Most of the functionality is avail in ControlSupport. This class should
// be eliminated/modified to make use of ControlSupport. This class was
// initially addded because it just needed part of ControlSupport
public class DbAccessSupport
    extends InfoBusMemberHelper
    implements InfoBusDataConsumer
{
    /**
    **  Name of the InfoBus we are part of
    */
    private String _infoBusName;
     
    /**
    **  name of the workunit
    */
    private String _dataItemName;
     
    /**
    **  DbAccess item corresponding to the Session.
    */
    private Object _dataItem;

    /**
    **  support for focus validated
    */
    private boolean _focusValidated;

    /**
    ** Constructor
    */
    public DbAccessSupport()
    {
        super(null);
        addInfoBusPropertyListener(this);
        setInfoBusName(Control.DEFAULT_INFOBUS_NAME); // TODO : is this ok ?
    }

    // InfoBusDataConsumer Interface

    /**
    ** This method is called by the <TT>InfoBus</TT> class on behalf of a data
    ** producer that is announcing the availability of a new data item by
    ** name. <P>
    */
    public void dataItemAvailable(InfoBusItemAvailableEvent event)
    {
        // dont care
    }

    /**
    ** This method is called by the <TT>InfoBus</TT> class on behalf of a data
    ** producer that is revoking the availability of a previously announced
    ** data item. <P>
    **
    ** @param event The event.
    */
    public void dataItemRevoked(InfoBusItemRevokedEvent event)
    {
        String dataItemName = _dataItemName;
        
        if (dataItemName != null &&
            dataItemName.equals(event.getDataItemName()))
        {
            _setDataItem(null);
        }
    }

    /**
    ** This method gets called when the object's <TT>InfoBus</TT> property
    ** is changed. <P>
    ** The object is removed as a data consumer from its previous InfoBus,
    ** and is added as a consumer to its new InfoBus. <P>
    ** @param event The event.
    */
    public void propertyChange(PropertyChangeEvent event)
    {
        if (event.getPropertyName().equals("InfoBus"))
        {
            Object oldVal = event.getOldValue();
            Object newVal = event.getNewValue();

            if (oldVal != newVal)
            {
                if (oldVal != null && oldVal instanceof InfoBus)
                {
                    ((InfoBus)oldVal).removeDataConsumer(this);
                }

                if (newVal != null && newVal instanceof InfoBus)
                {
                    ((InfoBus)newVal).addDataConsumer(this);
                }
            }
        }
    }

    /**
    ** Sets the name of the InfoBus this transaction monitor is connected.<P>
    **
    ** By default, the it is connected to the default InfoBus,
    ** named <TT>Control.DEFAULT_INFOBUS_NAME</TT>. <P>
    ** If the named InfoBus does not exist, it is created automatically. <P>
    ** @param infoBusName   The name of the InfoBus to connect to.
    */
    public synchronized void setInfoBusName(String infoBusName)
    {
        if (infoBusName == _infoBusName ||
            (infoBusName != null && infoBusName.equals(_infoBusName)))
        {
            return;
        }

        if (_infoBusName != null)
        {
            dropInfoBus();
        }
        _infoBusName = infoBusName;

        if (infoBusName != null)
        {
            try
            {
                joinInfoBus(infoBusName);
                InfoBus infoBus = getInfoBus();
                if (infoBus == null)
                {
                    // XXX - throw exception?
                    System.err.println("setInfoBusName(): stale InfoBus");
                    return;
                }

                infoBus.addDataConsumer(this);

                if (_dataItemName != null)
                {
                    _setDataItem(infoBus.findDataItem(_dataItemName, null,
                                                      this));
                }
            }
            catch (InfoBusMembershipException e)
            {
                // XXX - Do something useful here
                System.err.println("setInfoBusName() warning: " +
                                   "joinInfoBus failed because InfoBus already set: " + e);
            }
            catch (PropertyVetoException e)
            {
                // XXX - Do something useful here
                System.out.println("setInfoBusName() warning: " +
                                   "joinInfoBus failed because voter vetoed setInfoBus: "+ e);
            }
        }
    }

    public String getInfoBusName()
    {
        return _infoBusName;
    }

    public boolean isFocusValidated()
    {
        return _focusValidated;
    }

    public void setFocusValidated(boolean focusValidated)
    {
        _focusValidated = focusValidated;
    }

    /**
    ** Sets the name of the InfoBus DataItem this object is bound to. <P>
    ** The DataItem with the given name is searched for on the InfoBus, and
    ** if found, is bound to this object. <P>
    ** If the object is already bound to a DataItem, it is unbound first. <P>
    ** @param dataItemName  The name of the DataItem to bind to.
    ** @see #getDataItem
    */
    public synchronized void setDataItemName(String dataItemName)
    {
        if (dataItemName == _dataItemName ||
            (dataItemName != null && dataItemName.equals(_dataItemName)))
        {
            return;
        }

        _dataItemName = dataItemName;

        InfoBus infoBus = getInfoBus();
        if (infoBus != null)
        {
            _setDataItem(infoBus.findDataItem(dataItemName, null, this));
        }
    }

    public String getDataItemName()
    {
        return(_dataItemName != null ? _dataItemName : "");
    }


    /**
    **  return the data item the object is currently bound to.
    **
    **  @return the data item which the object is currently bound to.
    */
    public synchronized Object getDataItem()
    {
        InfoBus infoBus = getInfoBus();
        
        if (_dataItem == null &&
            _dataItemName != null &&
            !_dataItemName.equals("") &&
            infoBus != null)
        {
            _setDataItem(infoBus.findDataItem(_dataItemName, null, this));
        }
    	return(_dataItem);
    }

    /**
    ** Removes this object from its currently bound InfoBus and data item. <P>
    */
    public synchronized void dropInfoBus()
    {
        _setDataItem(null);

        try
        {
            leaveInfoBus();
        }
        catch (InfoBusMembershipException e)
        {
            // Ignore
        }
        catch (PropertyVetoException e)
        {
            // Ignore
        }
    }

    /**
    ** Binds to a data item. <P>
    ** @param dataItem  The new data item to bind to.
    */
    private synchronized void _setDataItem(Object dataItem)
    {
        if (dataItem != _dataItem)
        {
            _dataItem = dataItem;
        }
    }
}
