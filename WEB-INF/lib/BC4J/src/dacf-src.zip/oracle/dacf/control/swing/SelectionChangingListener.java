/*
 * @(#)SelectionChangingListener.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.dacf.control.swing;

import java.util.EventListener;

/**
 * Defines the interface for receiving ChangingEvents
 *
 * @version SDK
 */
public interface SelectionChangingListener extends EventListener
{
    /*
     * Notification from the source that a state has changed
     */
    void selectionChanging(SelectionChangingEvent event)
                                    throws ChangeVetoException;
}
