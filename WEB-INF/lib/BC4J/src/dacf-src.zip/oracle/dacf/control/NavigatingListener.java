/*
 * @(#)NavigatingListener.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.dacf.control;

import java.util.EventListener;

/**
 * Interface for receiving <TT>NavigatingEvent</TT> fired by
 * a <TT>Control</TT>.<P>
 * <TT>NavigatingEvent</TT> is fired after <TT>ValidationEvent</TT>
 * but before the <TT>NavigatedEvent</TT>
 * @see NavigatingAdapter
 * @see NavigatingEvent
 * @see Control
 */
public interface NavigatingListener extends EventListener
{
  public void navigatingOut(NavigatingEvent event) throws NavigatingException ;

}
