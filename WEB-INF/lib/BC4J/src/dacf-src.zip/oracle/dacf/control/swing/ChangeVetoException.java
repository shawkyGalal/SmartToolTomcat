/*
 * @(#)ChangeVetoException.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.dacf.control.swing;

/**
 * This exception can be thrown by <TT>SelectionChangingListener</TT> in response
 * to a
 * SelectionChangingEvent to veto a selection change
 * is invalid. </P>
 *
 * @version SDK
 */
public class ChangeVetoException extends Exception
{
  /**
  * Constructor
  *
  * @param message to be used
  */
  public ChangeVetoException(String message)
  {
    super(message);
  }

}
