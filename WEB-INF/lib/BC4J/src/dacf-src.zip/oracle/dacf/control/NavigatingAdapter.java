/*
 * @(#)NavigatingAdapter.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.dacf.control;

/**
 * This class provides an empty implementation of the NavigatingListener
 * interface.Listeners that are not interested in receiving
 * all the NavigatingEvents should subclass from
 * NavigatingAdapter and override appropriate methods.
 *
 */
public class NavigatingAdapter
    implements NavigatingListener
{
    private static final boolean _DEBUG = false;

    public void navigatingOut(NavigatingEvent event) throws NavigatingException
    {
        //_debug("navigatingOut", event) ;
    }

    private void _debug(String name, NavigatingEvent event) {

        if (_DEBUG) {
            System.out.println("NavigatingAdapter." + name +
                               ": " + event);
        }
    }
}
