/*
 * @(#)FindAction.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.dacf.control.swing.find;

import java.awt.event.ActionEvent;
import javax.infobus.DataItem;
import javax.infobus.DbAccess;
import javax.infobus.RowsetAccess;
import javax.infobus.ScrollableRowsetAccess;
import javax.swing.AbstractAction;
import javax.swing.Icon;
import oracle.dacf.control.DataItemAccessHelper;
import oracle.dacf.control.swing.find.FindActionQueryBuilder;
import oracle.dacf.control.swing.find.NavbarFindActionQueryBuilder;
import oracle.dacf.dataset.DataItemProperties;
import oracle.dacf.dataset.InfoObject;
import oracle.dacf.dataset.ResultSetInfo;
import oracle.dacf.dataset.RowSetManager;

/**
 *  Action object which can create a WHERE clause and execute a Query.
 *
 *  This class is a building block to create FindButtonControl, FindPanel
 *
 *  A data item name for a rowset has to be specified. This rowset will be used
 *  to execute the query.
 *
 *  This control creates a WHERE clause of form
 *     WHERE (  ( col1 = val1) AND (col2 = val2)....)
 * and sets this as a query condtion and executes the query.
 *
 *  For each column a FindItemModelhas to be specified. The FindItemModel specifies
 *  the column name, type and value used to build the query.
 *
 *
 *  @version    SDK
 *  @see        FindItemModel
 *  @see        FindPanel
 */
public class FindAction
    extends AbstractAction
{
   /**
   *  A helper class to build the query condition
   */
   private FindActionQueryBuilder _queryBuilder =
       new NavbarFindActionQueryBuilder();


   /**
   * A helper class to retrieve RowsetAccess data item, which will be used to
   * execute the query
   */
   DataItemAccessHelper _rowset = new DataItemAccessHelper();

   /**
   * You could specify a rowset thro' a data item name or directly
   * thro' a rowset
   */
   ScrollableRowsetAccess _rsAccess = null;

   private static final boolean _DEBUG = true;

   /**
   * Create Action object with default text and icon
   */
   public FindAction()
   {
     super();
   }

   /**
   *  Create Action object with specified text
   *
   *  @param text to be used for the Action object
   */
   public FindAction(String text)
   {
      super(text);
   }

   /**
   * Create Action object with specified text and icon
   *
   * @param text to be used for the action object
   * @param icon to be used for the action object
   */
   public FindAction(String text, Icon icon)
   {
     super(text, icon);
   }

   /**
   * Sets the name of the InfoBus this transaction monitor is connected to. <P>
   * By default, the it is connected to the default InfoBus,
   * named <TT>Control.DEFAULT_INFOBUS_NAME</TT>. <P>
   * If the named InfoBus does not exist, it is created automatically. <P>
   * @param infoBusName   The name of the InfoBus to connect to.
   */
   public synchronized void setInfoBusName(String infoBusName)
   {
      _rowset.setInfoBusName(infoBusName);
   }

   public String getInfoBusName()
   {
      return _rowset.getInfoBusName();
   }

   /**
   * Specify the data item name for the rowset. The
   * Query condition will be specified on the rowset and
   * the query executed.
   *
   * @param data item name for the rowset
   *
   * @see setRowsetAccess
   */
   public void setDataItemName(String dataItemName)
   {
       _rowset.setDataItemName(dataItemName);
   }

   /**
   *  Return the data item name for the row set.
   *
   *  @return data item name for the row set
   */

   public String getDataItemName()
   {
     return _rowset.getDataItemName();
   }

   /**
   *  set the FindItem model for the child objects. The colum name,
   *  SQL type and value will be used to build the WHERE clause.
   *
   *  @param findItemModel describes the column items
   */

   public void setFindItemModel( FindItemModel[] findItemModel)
   {
       _queryBuilder.setFindItemModel(findItemModel);
   }

   /**
   *  return the item model of the column objects
   *
   * @return  Find item model for each column object.
   */
   public FindItemModel[] getFindItemModel()
   {
     return _queryBuilder.getFindItemModel();
   }


   /**
   * specify the query bulder. Query bulder provides control over how the query
   * is created
   *
   * @param queryBuilder object which implements custom query building mechanism
   */
   public void setQueryBuilder(FindActionQueryBuilder queryBuilder)
   {
      _queryBuilder = queryBuilder;
   }

   /**
   * get the query builder currently in use.
   *
   * @return query builder in use
   */
   public FindActionQueryBuilder getQueryBuilder()
   {
      return (_queryBuilder);
   }

   /**
   * get the data item associated with this object. The dataitem represents a
   * rowset used to execute the query.
   *
   * @return rowset access data item used to execute the query
   */
   public RowsetAccess getDataItem()
   {
         Object di = _rowset.getDataItem();
         if ( di instanceof RowsetAccess)
             return  (RowsetAccess) di;
         else
             return null;
   }

   /**
   *  An alternative way to specify a rowset
   *
   *  @param  rsAccess rowset to use
   *  @see    setDataItemName
   */
   public void setRowsetAccess(ScrollableRowsetAccess rsAccess)
   {
       _rsAccess  = rsAccess;
   }

   /**
   * get the rowset access currently in use
   *
   * @return rowset currently used to execute a query
   */
   public ScrollableRowsetAccess getRowsetAccess()
   {
       if ( getDataItemName() != null )
       {
            DataItem di = (DataItem)_rowset.getDataItem();
            if ( ( di != null ) && (di instanceof ScrollableRowsetAccess))
                _rsAccess = (ScrollableRowsetAccess)di;
       }
       return _rsAccess;
   }


   /**
   * Specify if case sensitive search is to performed for Character data
   * types.
   *
   * By default this property is true.
   *
   * @param flag true if the search should be case sensitive
   */
   public void setCaseSensitiveSearch(boolean flag)
   {
      _queryBuilder.setProperty(FindActionQueryBuilder.CASE_SENSITIVE_SEARCH,
                                                        new Boolean(flag));
   }


   /**
   *  Return true, if the FindPanel does a case sensitive search for
   *  character data types.
   *
   *  @return true if the search is case sensitive for Character data types.
   */
   public boolean isCaseSensitiveSearch()
   {
       Boolean b = (Boolean)_queryBuilder.getProperty
                               (FindActionQueryBuilder.CASE_SENSITIVE_SEARCH);
       return ((b != null) ? b.booleanValue() : true);
   }


   /**
   *  execute query in response to action performed
   *  event
   *
   *  @param evt ActionEvent
   */
   public void actionPerformed(ActionEvent evt)
   {
       executeQuery(false);
   }

   /**
   * execute the query. If the query condition is ignored, then the query will
   * be executed without a WHERE clause
   *
   * @param   bIgnoreQueryCondition should the WHERE clause be used or not ?
   */
   public void executeQuery(boolean bIgnoreQueryCondition)
   {
      ScrollableRowsetAccess rsAccess = getRowsetAccess();
      if (rsAccess == null)
         return;

      ResultSetInfo rsInfo = _getInfoObject((DataItem)rsAccess);

      String queryCondition = _queryBuilder.buildQuery();
      _executeQuery(rsAccess, rsInfo,
                    (bIgnoreQueryCondition) ? null : queryCondition);

      // set Property on queryBuilder
      boolean hasRows = false;
      if (rsAccess instanceof RowSetManager)
      {
         hasRows = ((RowSetManager)rsAccess).hasRows();
      }
      else
      {
         hasRows = (rsAccess.getRowCount() > 0);
      }

      if (!hasRows)
      {
          while (_queryBuilder.canReExecuteQuery())
          {
             queryCondition = _queryBuilder.modifyQuery();
             _executeQuery(rsAccess, rsInfo, queryCondition);
             // set Property
          }
      }
   }

   /**
   * a helper function to execute the query
   *
   * @param rsAccess rowset access used to execute the query
   * @param rsInfo   rowset info object on which the query condition is set
   * @param queryCondition the WHERE clause
   */
   private void _executeQuery(ScrollableRowsetAccess rsAccess,
                              ResultSetInfo rsInfo, String queryCondition)
   {
        try
        {
            if ( _isDirty(rsInfo))
                 (rsAccess.getDb()).rollbackTransaction();
            if (rsInfo.isActive())
            {
               rsInfo.getSession().setActive(false, true);
            }
            rsInfo.setQueryCondition(queryCondition);
            if (!rsInfo.isActive())
            {
               rsInfo.getSession().setActive(true, true);
            }
            rsInfo.executeQuery();
            if (rsAccess.getRowCount() > 0)
               rsAccess.first();
        }
        catch (Exception exc)
        {
            exc.printStackTrace();
        }
   }

   /**
   * get the data objet
   *
   * @return the data object
   */
   private ResultSetInfo _getInfoObject(DataItem di)
   {
       InfoObject  dataObj =
           (InfoObject)di.getProperty(DataItemProperties.INFO_OBJECT);
       if ((dataObj != null) &&( dataObj instanceof ResultSetInfo))
       {
           ResultSetInfo rsInfo = (ResultSetInfo)dataObj;
           return rsInfo;
       }
       return null;
   }

    /**
    * check if the RowsetInfo is dirty
    *
    */
    private boolean _isDirty(InfoObject rowset)
    {
        return rowset.isDirty();
    }

    /**
    *  check if the transaction is dirty
    *
    *  @param rowset whose transaction status has to be checked
    */
    private boolean _isDirty(RowsetAccess rowset)
    {
        DbAccess db = rowset.getDb();
        Object dirty =
            (Boolean)((DataItem)db).getProperty(DataItemProperties.PENDING_CHANGES);
        if (dirty != null && dirty instanceof Boolean)
            return ((Boolean)dirty).booleanValue();
        return true;
    }
}


