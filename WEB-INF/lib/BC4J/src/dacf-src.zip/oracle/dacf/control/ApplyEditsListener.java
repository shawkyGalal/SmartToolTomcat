/*
 * @(#)ApplyEditsListener.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.dacf.control;

/**
 ** This interface is used by the NavigationManager and navigation aware
 ** controls like the NavigationBar to manage the movement of values from the
 ** control to the appropriate DataItem.
 */
public interface ApplyEditsListener 
{
    /**
    **  @throws ApplyEditsValidationException when a validation exception is
    **          thrown by the InfoBus producer object when the edits are
    **          applied.
    */
    public void applyEdits();
    public void cancelEdits();
}

