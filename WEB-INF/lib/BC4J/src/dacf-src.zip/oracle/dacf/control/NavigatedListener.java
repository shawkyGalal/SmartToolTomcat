/*
 * @(#)NavigatedListener.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.dacf.control;

import java.util.EventListener;

/**
 * This defines the interface for receiving Navigated events fired by
 * a <TT>Control</TT>.
 * A Control notifies its listeners whenever it looses or gains focus.
 * The navigateOutXXX methods are called by the Control that is loosing focus.
 * The navigateInXXX methods are called by the Control that is gaining
 * focus.<P>
 * NavigatedAdapter provides a empty implementation of this interface.
 * Listeners that are not interested in receiving all the events should
 * subclass from NavigatedAdapter and override appropriate methods.
 *
 * @see NavigatedAdapter
 */
public interface NavigatedListener
    extends EventListener
{
    /**
    * This method is called when Control receiving the focus is bound to a
    * different column than the Control loosing the focus. <P>
    * @param event  A NAVIGATE_IN type of event with a column level change.
    */
    public void navigatedInColumn(NavigatedEvent event);

    
    /**
    * This method is called when Control loosing the focus is bound to a
    * different column than the Control gaining the focus. <P>
    * @param event  A NAVIGATE_OUT type of event with a column level change.
    */
    public void navigatedOutColumn(NavigatedEvent event);


    /**
    * This method is called when Control receiving the focus is bound to a
    * different row than the Control loosing the focus. <P>
    * @param event  A NAVIGATE_IN type of event with a row level change.
    */
    public void navigatedInRow(NavigatedEvent event);

    
    /**
    * This method is called when Control loosing the focus is
    * bound to a different column than the Control gaining the focus. <P>
    * @param event  A NAVIGATE_OUT type of event with a row level change.
    */
    public void navigatedOutRow(NavigatedEvent event);


    /**
    * This method is called when Control receiving the focus is bound
    * to a different queryview  than the Control loosing the focus. <P>
    * @param event  A NAVIGATE_IN type of event with a queryview level of
    *               change.
    */
    public void navigatedInQueryView(NavigatedEvent event);


    /**
    * This method is called when Control loosing the focus is bound to a
    * different queryview than the Control gaining the focus. <P>
    * @param event  A NAVIGATE_OUT type of event with a queryview level change.
    */
    public void navigatedOutQueryView(NavigatedEvent event);


    /**
    * This method is called when Control receiving the focus is bound to a
    * different workunit than the Control loosing the focus.<P>
    *
    * @param event  A NAVIGATE_IN type of event with a work unit level of
    *               change.
    */
    public void navigatedInSession(NavigatedEvent event);

    
    /**
    * This method is called when Control loosing the focus is bound to a
    * different workunit than the Control gaining the focus. <P>
    * @param event  A NAVIGATE_OUT type of event with a workunit level change.
    */
    public void navigatedOutSession(NavigatedEvent event);
}


