/*
 * @(#)TreeNodeDef.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.dacf.control.swing;

import javax.infobus.DataItem;
import javax.infobus.ScrollableRowsetAccess;
import oracle.dacf.dataset.DataItemProperties;
import oracle.dacf.dataset.QueryListener;

// imports
/**
 ** Encapsulates the information supplied via TreeControl.setNodeDefinitions().
 **
 ** The TreeNodeDef class is primarily an internal bookkeeping class.  The
 ** public methods
 ** <ul>
 ** <li>isSelfReferential()
 ** <li>getRowsetName()
 ** <li>getDisplayColName()
 ** <li>getPrimaryKeyColNames()
 ** <li>getForeignKeyColNames()
 ** </ul>
 ** will allow writers of TreeSelection listeners to track the DataItems that
 ** provide the information "behind" a node.  
 **
 ** @version public
 */
public class TreeNodeDef
{
    private boolean _selfRef;
    private String _dispName;
    private int _dispIndex;
    private String _linkName;
    private int _linkIndex;
    private String[] _pKeyNames;
    private int[] _pKeyIndices;
    private String[] _fKeyNames;
    private int[] _fKeyIndices;
    private String _sraName;
    private ScrollableRowsetAccess _rowset; // may be a clone of the original
    private ScrollableRowsetAccess _originalRowset;
    private ScrollableRowsetAccess _searchRowset;
    private QueryListener _queryListener;

    private static final boolean _DEBUG = true;

    TreeNodeDef()
    {
        this(null, null, null, null, null, false, null);
    }
    
    TreeNodeDef(String sraName, String dispName, String linkName,
                String[] pKeyNames, String[] fKeyNames, boolean selfRef)
    {
        this(sraName, dispName, linkName, pKeyNames, fKeyNames, selfRef, null);
    }
    
    TreeNodeDef(String sraName, String dispName, String linkName,
                String[] pKeyNames, String[] fKeyNames, boolean selfRef,
                ScrollableRowsetAccess sra)
    {
        setRowsetName(sraName);
        setDisplayColName(dispName);
        setLinkColName(linkName);
        setRowsetItem(sra);
        setPrimaryKeyColNames(pKeyNames);
        setForeignKeyColNames(fKeyNames);
    } // TreeNodeDef

    void setSelfReferential(boolean selfRef)
    {
        _selfRef = selfRef;
    }

    /**
    **  Indicates whether the node definition recurses back into itself.  This
    **  will typically be true if the node definition is describing something
    **  like a self-join.
    **
    **  @return True if this node definition recurses back into itself.
    */
    public boolean isSelfReferential()
    {
        return(_selfRef);
    }
    
    void setRowsetItem(ScrollableRowsetAccess sra)
    {
        _rowset = sra;
    }

    ScrollableRowsetAccess getRowsetItem()
    {
        return(_rowset);
    }
    
    void setOriginalRowset(ScrollableRowsetAccess sra)
    {
        _originalRowset = sra;
    }

    ScrollableRowsetAccess getOriginalRowset()
    {
        return(_originalRowset);
    }

    void setSearchRowset(ScrollableRowsetAccess sra)
    {
        _searchRowset = sra;
    }

    ScrollableRowsetAccess getSearchRowset()
    {
        return(_searchRowset);
    }

    /**
    **
    **
    **  @return the name of the InfoBus DataItem that enumerates the child
    **          nodes.
    */
    public String getRowsetName()
    {
        return(_sraName);
    }

    void  setRowsetName(String name)
    {
        _sraName = name;
    }

    String getLinkColName()
    {
        return(_linkName);
    }

    void setLinkColName(String name)
    {
        _linkName = (name != null && !name.equals("") ? name : null);
        _linkIndex = -1;
    }

    int getLinkColIndex()
    {
        if (_linkIndex == -1)
        {
            _linkIndex = _findColIndex(_linkName);
        }
        return(_linkIndex);
    }

    /**
    **  @return the name of the InfoBus DataItem that supplies the label for
    **          the nodes.
    */
    public String getDisplayColName()
    {
        return(_dispName);
    }

    void  setDisplayColName(String name)
    {
        _dispName = name != null && !name.equals("") ? name : null;
        _dispIndex = -1;
    }

    int getDisplayColIndex()
    {
        if (_dispIndex == -1)
        {
            _dispIndex = _findColIndex(_dispName);
        }
        return(_dispIndex);
    }

    /**
    **  Returns the names of the columns that compose the primary key for the
    **  DataItem.
    **
    **  @return an array of column names
    */
    public String[] getPrimaryKeyColNames()
    {
        return(_pKeyNames);
    }

    void  setPrimaryKeyColNames(String[] names)
    {
        _pKeyNames = names;
        _pKeyIndices = null;
    }

    int[] getPrimaryKeyColIndices()
    {
        if (_pKeyIndices == null)
        {
            _pKeyIndices = new int[_pKeyNames.length];
            for(int i = 0; i < _pKeyNames.length; i++)
            {
                _pKeyIndices[i] = _findColIndex(_pKeyNames[i]);
            }
        }
        return(_pKeyIndices);
    }

    /**
    **  Returns the names of the columns that compose the foreign key for the
    **  DataItem.
    **
    **  @return an array of column names
    */
    public String[] getForeignKeyColNames()
    {
        return(_fKeyNames);
    }

    void  setForeignKeyColNames(String[] names)
    {
        _fKeyNames = names;
        _fKeyIndices = null;
    }

    int[] getForeignKeyColIndices()
    {
        if (_fKeyIndices == null)
        {
            _fKeyIndices = new int[_fKeyNames.length];
            for(int i = 0; i < _fKeyNames.length; i++)
            {
                _fKeyIndices[i] = _findColIndex(_fKeyNames[i]);
            }
        }
        return(_fKeyIndices);
    }

    void setQueryListener(QueryListener ql)
    {
        _queryListener = ql;
    }
    
    QueryListener getQueryListener()
    {
        return(_queryListener);
    }
    
    private int _findColIndex(String colName)
    {
        int index = -1;

        if (_rowset != null && colName != null)
        {
            try
            {
                DataItem di = (DataItem)_originalRowset.getColumnItem(colName);

                if (di != null)
                {
                    index = ((Integer)di.getProperty(DataItemProperties.COLUMN_INDEX)).intValue();
                }
            }
            catch(Exception e)
            {
            }
        }
        return(index);
    }
    
    private static void _debug(String s)
    {
        if (_DEBUG)
        {
            System.out.println("### TreeNodeDef: " + s);
        }        
    } // _debug
}  // TreeNodeDef


