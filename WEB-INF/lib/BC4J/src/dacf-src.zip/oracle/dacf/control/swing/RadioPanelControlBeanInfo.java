/*
 * @(#)RadioPanelControlBeanInfo.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.dacf.control.swing;

import java.beans.PropertyDescriptor;

/**
 * bean info class for the RadioPanel control
 *
 * @version SDK
 */
public class RadioPanelControlBeanInfo
    extends ControlBeanInfoHelper
{
    /**
    * Constructor
    */
    public RadioPanelControlBeanInfo()
    {
        super();
    }

    /**
    * get the bean class object for the bean
    *
    * @return bean class for the bean
    */
    protected Class getBeanClass()
    {
        return RadioPanelControl.class;
    }

    /**
    * get property descriptors for the bean
    *
    * @return PropertyDescriptors specific to this bean
    */
    protected PropertyDescriptor[] getAdditionalPropertyDescriptors()
    {
        try
        {
            PropertyDescriptor orientation =
                new PropertyDescriptor("orientation", getBeanClass(),
                                       "getOrientation", "setOrientation");
            orientation.setPropertyEditorClass(Class.forName("oracle.jdeveloper.daceditors.RadioPanelDirectionEditor"));
            PropertyDescriptor[] ret = { orientation };
            return ret;
        }
        catch (Exception exc)
        {
            exc.printStackTrace();
            return null;
        }
    }
}
