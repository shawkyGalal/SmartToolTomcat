/*
 * @(#)ViewCriteriaModelImpl.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.dacf.control.swing.find;

import java.sql.Types;
import javax.infobus.DataItem;
import javax.infobus.ImmediateAccess;
import javax.infobus.ScrollableRowsetAccess;
import oracle.dacf.dataset.DataItemProperties;
import oracle.dacf.dataset.UnmangledQueryCriteriaStore;

/**
 *  This class makes available the BC4J ViewCriteriaRows and ViewCriteria.
 *  These objects are used to create and execute parameterized queries.
 *
 *  This implementation indirectly creates and uses ViewCriteria objects
 *  through the ResultSetInfo object.
 *
 *  @see FindPanel
 *  @see ViweCriteriaModel
 *  @see ResultSetInfo
 *  @see oracle.jbo.ViewCriteria
 *  @see oracle.jbo.ViewCriteriaRow
 *  @version Internal
 */
public class ViewCriteriaModelImpl
           implements ViewCriteriaModel
{
     protected ScrollableRowsetAccess _rsAccess;
	 protected UnmangledQueryCriteriaStore _unmangledQueryCriteriaStore;
     protected Object[] _columnLabels = null;

     /**
     * Constructor
     */
     public ViewCriteriaModelImpl()
     {
     }

     /**
     * Specify the ScrollableRowsetAccess object to delegate request for
     * creating ViewCriteria objects.
     */
     public void setRowsetAccess(ScrollableRowsetAccess rsAccess)
     {
         _rsAccess = rsAccess;
         if ( _rsAccess != null )
		 {
		 
            _columnLabels = (Object [])((DataItem)_rsAccess).getProperty(
                          DataItemProperties.COLUMN_LABELS);

			if (rsAccess instanceof UnmangledQueryCriteriaStore)
				_unmangledQueryCriteriaStore = 
				     (UnmangledQueryCriteriaStore)_rsAccess;
		 }
     }

     /**
     *
     */
     public ScrollableRowsetAccess getRowsetAccess()
     {
         return _rsAccess;
     }

     /**
     *  return the number of ViewCriteriaRows
     */
     public int getRowCount()
     {
             return _rsAccess.getRowCount();
     }
     /**
     *  get the row number of the current row.
     */
     public int getRow()
     {
         return _rsAccess.getRow();
     }

     /**
     *  move to a specific ViewCriteriaRow
     */
     public boolean absolute(int rowIndex)
     {
         try
         {
             return _rsAccess.absolute(rowIndex);
         }
         catch(Exception e)
         {
             return false;
         }
     }


     /**
     *  move to previous ViewCriteriaRow
     */
     public boolean previous()
     {
         try
         {
             return _rsAccess.previous();
         }
         catch( Exception e)
         {
             return false;
         }
     }

     /**
     * move to the first ViewCriteriaRow
     */
     public boolean first()
     {
         try
         {
             return _rsAccess.first();
         }
         catch( Exception e)
         {
             return false;
         }
     }

     /**
     * move to the next ViewCriteriaRow
     */
     public boolean next()
     {
         try
         {
             return _rsAccess.next();
         }
         catch( Exception e)
         {
             return false;
         }
     }


     /**
     * move to the last ViewCriteriaRow
     */
     public boolean last()
     {
         try
         {
             return _rsAccess.last();
         }
         catch( Exception e)
         {
             return false;
         }

     }


     /**
     * create a new ViewCriteriaRow
     */
     public void newRow()
     {
         try
         {
            _rsAccess.newRow();
         }
         catch(Exception e)
         {
         }
     }


     /**
     * delete current ViewCriteriaRow
     */
     public void deleteRow()
     {
         try
         {
             _rsAccess.deleteRow();
         }
         catch( Exception e)
         {
         }
     }


     // column attributes

     /**
     *  @return the number of columns
     */
     public int getColumnCount()
     {
         return _rsAccess.getColumnCount();

     }


     /**
     * return the column display name for a particular column
     */
     public String getColumnDisplayLabel(int colIndex)
     {
         String name = "";
         
         if ( _columnLabels != null &&
              _columnLabels[colIndex] != null)
         {
             name = _columnLabels[colIndex].toString();
         }
         else
         {
             if ( _rsAccess != null )
             {
                 name = _rsAccess.getColumnName(colIndex + 1);
             }
         }

         return(name);
     }


     /**
     * get the column name., zero based index.
     *
     * @return name of the column to use in the query
     */
     public String getColumnName(int colIndex)
     {
         return _rsAccess.getColumnName(colIndex + 1);
     }


     /**
     * get SQL type for this column., zero based index.
     *
     */
     public int getSQLType(int colIndex)
     {
        return _rsAccess.getColumnDatatypeNumber(colIndex + 1);
     }


     /**
     * return the column value for a particular column
     *
     * @param colIndex column index whose column value we are interested in.,
     *                 zero based index used
     *
     * @return column value
     *
     */
     public Object getColumnValue(int colIndex)

     {
        try
        {
            Object o = _rsAccess.getColumnItem(colIndex+1);
            if (( o != null ) && ( o instanceof ImmediateAccess))
                return ((ImmediateAccess)o).getValueAsObject();
        }
        catch(Exception e)
        {
        };
        return null;
     }

     
     /**
     * specify the column value for a particular column
     *
     * @param colIndex column index whose value has to be set
     *                 zero based index used
     *
     */
     public void setColumnValue(int colIndex, Object value)
     {
         try
         {
             _rsAccess.setColumnValue(colIndex+1, value);
         }
         catch(Exception e)
         {
         }
     }

	 public Object getUserData(int colIndex)
	 {
		 if (_unmangledQueryCriteriaStore != null)
			 return (_unmangledQueryCriteriaStore.getUserData(colIndex));
		 
		 return null;
	 }


	 public void setUserData(int colIndex, Object value)
	 {
		 if (_unmangledQueryCriteriaStore != null)
			 _unmangledQueryCriteriaStore.setUserData(colIndex, value);

	 }

     /**
     */
     public FindItemModel getFindItemModel(int row, int col)
     {
         return new ViewCriteriaFindItemModel(this, row, col);
     }
}

/**
* FindItem Model implementation which makes use of ViewCriteriaModel
*/
class ViewCriteriaFindItemModel implements FindItemModel
{
     ViewCriteriaModelImpl _owner = null;
     int _row = 0;
     int _col = 1;

     /**
     * FindItemModel which makes use of
     */
     ViewCriteriaFindItemModel(ViewCriteriaModelImpl owner, int row, int col)
     {
         _owner  = owner;
         _row = row;
         _col = col;
     }

    /**
    *  value to be used in building the WHERE clause
    *
    *  @return value to be used in the WHERE clause
    */
    public Object getItemValue()
    {
        _restoreRow();
        return _owner.getColumnValue(_col);
    }

    /**
    *  specify the value to be used in the WHERE clause
    *
    *  @param value
    */
    public void setItemValue(Object value)
    {
        _restoreRow();
        _owner.setColumnValue(_col, value);
    }

    /**
    * get the column name
    *
    * @return name of the column to use in the query
    */
    public String getColumnName()
    {
        _restoreRow();
        return _owner.getColumnName(_col);
    }

    /**
    * get SQL type for this column
    *
    */
    public int getSQLType()
    {
        _restoreRow();
        return _owner.getSQLType(_col);
    }


    /**
    * get column name for display purpose.
    */
    public String getColumnDisplayName()
    {
        _restoreRow();
        return _owner.getColumnDisplayLabel(_col);
    }


    /**
    *  return the format string used. ( Special case used
    *  in association with Date datatype)
    */
    public String getFormatString()
    {
        return "";
    }

    /**
    *  return the SQL format string used (for ex., in TO_DATE function)
    *
    */
    public String getSQLFormatString()
    {
        int sqlType = getSQLType();
        if (( sqlType == Types.DATE) ||( sqlType == Types.TIME) ||
                                     ( sqlType == Types.TIMESTAMP))
            return "yyyy-MM-dd";
        return "";

    }

    protected void _restoreRow()
    {
         if (_owner.getRow() != _row)
             _owner.absolute(_row);
    }
}
