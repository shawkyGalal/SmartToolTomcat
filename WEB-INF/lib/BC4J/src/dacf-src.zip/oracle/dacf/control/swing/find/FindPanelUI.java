/*
 * @(#)FindPanelUI.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.dacf.control.swing.find;

import java.awt.Component;
import oracle.dacf.control.swing.FindPanel;

/**
 *  FindPanelUI. This interface used by FindPanel to customize the UI displayed.
 *
 *
 *  @version SDK
 *  @see FindPanel
 */
public interface FindPanelUI
{
    /*
    * property identifiers
    */

    /**
    * property id for label position
    */
    public static final int  LABEL_POSITION        =  0;

    /**
    * property id for item direction
    */
    public static final int  ITEM_DIRECTION        =  1;

    /**
    * property id to control whether Find button is displayed
    */
    public static final int  SHOW_FIND_BUTTON      =  2;

    /**
    * property id to control whether RESET button is displayed
    */
    public static final int  SHOW_RESET_BUTTON     =  3;

    /**
    * property id to control whether CLOSE button is displayed
    */
    public static final int  SHOW_CLOSE_BUTTON    =  4;

    /**
    * property id to control whether HELP button is displayed
    */
    public static final int  SHOW_HELP_BUTTON      =  5;

    /**
    * property id to control whether find icon is displayed
    */
    public static final int  SHOW_FIND_ICON        =  6;

    /**
    * property id to set the find icon
    */
    public static final int  FIND_ICON             =  7;

    /**
    * property id to set the inner panel layout manager
    */
    public static final int  INNER_PANEL_LYT_MGR   =  8;

    /**
    * property id to retrieve the inner panel
    */
    public static final int  INNER_PANEL           =  9;

    /**
    * property id to specify the font for the label
    */
    public static final int  LABEL_FONT            =  10;

    /**
    * property id to specify the font for the textfield
    */
    public static final int  TEXT_FONT             =  12;

    /**
    * property id to specify the foreground color for the label
    */
    public static final int  LABEL_FORE_CLR        =  13;

    /**
    * property id to specify the foreground color for the textfield
    */
    public static final int  TEXT_FORE_CLR         =  14;

    /**
    * property id to specify the background color for the label
    */
    public static final int  LABEL_BACK_CLR         = 15;

    /**
    * property id to specify the background color for the textfield
    */
    public static final int  TEXT_BACK_CLR         =  16;

    /**
    * property id to specify the column width for the textfield
    */
    public static final int  TEXT_COLUMN_WIDTH     =  17;

    /**
    * property id to specify the editor used for each column
    */
    public static final int  ITEM_EDITORS          =  18;

    /**
    * property id to specify if the status bar should be displayed
    */
    public static final int  SHOW_STATUS_BAR      =  19;

    /**
    * property id to specify if the OR button should be displayed
    */
    public static final int  SHOW_OR_BUTTON      =  20;

    /**
    * property id to specify if the REMOVE button should be displayed
    */
    public static final int  SHOW_REMOVE_BUTTON   =  21;

    /**
    * property id to specify if the remove all button should be displayed
    */
    public static final int  SHOW_REMOVE_ALL_BUTTON =  22;

    /**
    * property id to specify if the FindPanel should be enable/disabled
    */
    public static final int  ENABLED     =  25;

    /**
    * property id to specify the 'Parent container' which holds the
    * FindPanel object. The Find Panel could be added to a JDialog. The
    * 'parent container' in this case will be the JDialog object.
    */
    public static final int  PARENT_CONTAINER     =  27;


    /**
    *  set the parent which will use the customized UI panel.
    *  Implementors of this interface will make use of the 'parent' argument to
    *  retrive values to display and to execute query
    *
    *  @param parent
    */
    public void setParent(FindPanel parent);

    /**
    * A notification from the parent that one or more data item names changed.
    * Implementation should rebuild the UI
    */
    public void itemChanged();

    /**
    * A notification from the paraent that the column value changed.
    * Implementation should refresh the values for this column like the column
    * display label
    *
    * @param column whose value (some attribute) has changed
    */
    public void itemValueChanged(int column);

    /**
    * return a Panel reflectiong the panel to be displayed.
    * @return Panel
    */
     public Component buildPanel();

    /**
    * specify a property value to customize the UI
    * @param property id for the property. one of the constants defined above
    * @param value for the property
    */
    public void setProperty(int property, Object value);

    /**
    * get property value
    *
    * @param property id for the property. one of the constants defined above
    * @return property value
    */
    public Object getProperty(int property);

}
