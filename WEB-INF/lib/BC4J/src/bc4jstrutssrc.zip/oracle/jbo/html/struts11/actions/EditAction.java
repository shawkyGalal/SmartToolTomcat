/*
 * @(#)EditAction.java
 *
 * Copyright 2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.html.struts11.actions;

import java.util.HashMap;
import java.util.Hashtable;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import oracle.jbo.AttributeDef;
import oracle.jbo.JboException;
import oracle.jbo.LocaleContext;
import oracle.jbo.Row;
import oracle.jbo.ViewObject;
import oracle.jbo.html.BC4JContext;
import oracle.jbo.html.HtmlServices;
import oracle.jbo.html.jsp.datatags.DataTagBase;
import oracle.jbo.html.jsp.datatags.OnEventTag;
import oracle.jbo.html.struts11.BC4JUtils;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.actions.DispatchAction;
import org.apache.struts.upload.DiskFile;
import org.apache.struts.upload.FormFile;
import org.apache.struts.upload.MultipartRequestHandler;

/**
 * <p><strong>EditAction</strong>
 * </p>
 *
 * @since JDeveloper 9.0.3
 */
public class EditAction extends DispatchAction
{
   /**
    * "edit" dispatch method
    * 
    */
   public ActionForward edit(ActionMapping mapping,
                             ActionForm form,
                             HttpServletRequest request,
                             HttpServletResponse response)
   {
      BC4JContext context = BC4JContext.getContext(request);
      
      populateBC4JFormBean(context, form);

      return BC4JUtils.getForwardFromContext(context, mapping);
   }

   /**
    * "delete" dispatch method
    * 
    */
   public ActionForward delete(ActionMapping mapping,
                             ActionForm form,
                             HttpServletRequest request,
                             HttpServletResponse response)
   {
      BC4JContext context = BC4JContext.getContext(request);
      
      context.getRow().remove();

      return BC4JUtils.getForwardFromContext(context, mapping);
   }

   /**
    * "create" dispatch method
    * 
    */
   public ActionForward create(ActionMapping mapping,
                               ActionForm form,
                               HttpServletRequest request,
                               HttpServletResponse response)
   {
      BC4JContext context = BC4JContext.getContext(request);
      
      ViewObject vo = context.getViewObject();
      
      // Create a new Row only to retrieve the default value
      // This row will not be inserted in the set and will
      // be garbage collected.
      Row newRow = vo.createRow();
      newRow.setNewRowState(Row.STATUS_INITIALIZED);
      
      // Update the context with the temporary
      context.setRow(newRow);

      populateBC4JFormBean(context, form);
      
      return BC4JUtils.getForwardFromContext(context, mapping);
   }

   /**
    * unspecified dispatch method
    * This is the case whe no event is specified.
    */
   public ActionForward unspecified(ActionMapping mapping,
                             ActionForm form,
                             HttpServletRequest request,
                             HttpServletResponse response)
   {
      BC4JContext context = BC4JContext.getContext(request);
      
      ViewObject vo = context.getViewObject();
      
      // Bind the row to the ActionForm
      Row r = null;
      // Try the rowkey
      if (context.getRowkey() != null)
      {
         r = context.getRow();
      }

      if (r == null)
      {
         // Then try the current row
         r = vo.getCurrentRow();
         if (r == null)
         {
            // Then get the first row
            r = vo.first();
            if (r == null)
            {
               vo.executeQuery();
               r = vo.first();
            }
         }
      }
      
      // Update the context with the new.
      context.setRow(r);
      
      populateBC4JFormBean(context, form);

      // When the method is unspecified assume it to be an "edit"
      return mapping.findForward("edit");
   }

   /**
    * This method transfer the data from the Model to the FormBean
    */
   protected void populateBC4JFormBean(BC4JContext context, ActionForm form)
   {
      ViewObject vo = context.getViewObject();
      AttributeDef attr[] = vo.getAttributeDefs();
      Row row = context.getRow();
      LocaleContext localeContext = context.getApplicationModule().getSession().getLocaleContext();

      HashMap properties = new HashMap();
      
      // Predefined properties jboEvent, jboEventVo, jboRowKey, amId
      properties.put(OnEventTag.JBOEVENT, "update");
      properties.put(OnEventTag.JBOEVENTVO, vo.getFullName());
      // Do not pass along reference to a row which will be deleted.
      properties.put(DataTagBase.ROWKEY_PARAM, "create".equalsIgnoreCase(context.getEvent()) ? "" : context.getRowkey());
      properties.put("amId", context.getSessionCookie().getApplicationId());
      
      for (int i=0; i < attr.length; i++)
      {
         Object attrValue;
         String attrName = attr[i].getName();

         if (HtmlServices.isOrdDomainType(attr[i]))
         {
            MultipartRequestHandler requestHandler = form.getMultipartRequestHandler();
            FormFile file;
            if (requestHandler != null)
            {
               Hashtable fileElements = requestHandler.getFileElements();
               file = (FormFile) fileElements.get(attrName);
            }
            else
            {
               file = new DiskFile("");
            }
   
            attrValue = file;
         }
         else
         {
            attrValue =  HtmlServices.getAttributeStringValue(row, attr[i], localeContext);
         }
         
         properties.put(attrName, attrValue);
      }

      // Set the corresponding properties of our bean
      try
      {
         BeanUtils.populate(form, properties);
      }
      catch (JboException e)
      {
         throw e;
      }
      catch (Exception e)
      {
         throw new JboException(e);
      }
   }
}
