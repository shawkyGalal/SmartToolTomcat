/*
 * @(#)QueryAction.java
 *
 * Copyright 2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */
package oracle.jbo.html.struts11.actions;

import java.lang.NumberFormatException;
import java.util.Map;
import java.util.HashMap;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.actions.LookupDispatchAction;

import oracle.jbo.ViewObject;
import oracle.jbo.ViewCriteria;
import oracle.jbo.ViewCriteriaRow;
import oracle.jbo.AttributeDef;
import oracle.jbo.JboException;
import oracle.jbo.html.BC4JContext;

import oracle.jbo.html.struts11.BC4JUtils;

/**
 * <p><strong>QueryAction</strong>
 * </p>
 *
 * @since JDeveloper 9.0.3
 */
public class QueryAction extends LookupDispatchAction 
{
   /**
    * getKeyMethodMap
    * Override abtract method getKeyMethodMap
    */
   protected Map getKeyMethodMap()
   {
      Map map = new HashMap();

      map.put("DataQuery.search", "search");
      map.put("DataQuery.addCriteria", "addCriteria");
      map.put("DataQuery.removeCriteria", "removeCriteria");
      map.put("DataQuery.clearAll", "clearAll");

      return map;
   }

   /**
    * "search" dispatch method called by LookupDispatchAction
    * 
    */
   public ActionForward search(ActionMapping mapping,
                               ActionForm form,
                               HttpServletRequest request,
                               HttpServletResponse response)
   {
      BC4JContext context = BC4JContext.getContext(request);

      ViewObject vo = context.getViewObject();
      addViewCriteria(vo, request);
      vo.executeQuery();   

      return BC4JUtils.getForwardFromContext(context, mapping);
   }

   /**
    * "addCriteria" dispatch method called by LookupDispatchAction
    * 
    */
   public ActionForward addCriteria(ActionMapping mapping,
                               ActionForm form,
                               HttpServletRequest request,
                               HttpServletResponse response)
   {
      BC4JContext context = BC4JContext.getContext(request);

      addViewCriteria(context.getViewObject(), request);

      return BC4JUtils.getForwardFromContext(context, mapping);
   }

   // Method called by the DispathMethod
   public ActionForward removeCriteria(ActionMapping mapping,
                               ActionForm form,
                               HttpServletRequest request,
                               HttpServletResponse response)
   {
      BC4JContext context = BC4JContext.getContext(request);

      ViewCriteria vc = context.getViewObject().getViewCriteria();
      int index;

      if (vc != null)
      {
         try
         {
            index = Integer.parseInt(request.getParameter("index"));
         }
         catch (NumberFormatException ex)
         {
            throw new JboException(ex);
         }

         vc.removeElementAt(index);
      }

      return BC4JUtils.getForwardFromContext(context, mapping);
   }

   /**
    * "clearAll" dispatch method called by LookupDispatchAction
    * 
    */
   public ActionForward clearAll(ActionMapping mapping,
                                 ActionForm form,
                                 HttpServletRequest request,
                                 HttpServletResponse response)
   {
      BC4JContext context = BC4JContext.getContext(request);

      context.getViewObject().applyViewCriteria(null);

      return BC4JUtils.getForwardFromContext(context, mapping);
   }

   /**
    * "addViewCriteria" dispatch method called by LookupDispatchAction
    * 
    */
   protected void addViewCriteria(ViewObject vo, HttpServletRequest request)
   {
      ViewCriteria vc = vo.createViewCriteria();

      int nRows = 0;
      try
      {
         nRows = Integer.parseInt(request.getParameter("nRows"));
      }
      catch (NumberFormatException ex)
      {}

      AttributeDef dattrs[] = vo.getAttributeDefs();
      for (int index=0; index < nRows; index++)
      {
         ViewCriteriaRow vr = vc.createViewCriteriaRow();
         boolean isEmpty = true;

         for (int attr = 0; attr < dattrs.length; attr++)
         {
            if (!dattrs[attr].isQueriable())
            {
               continue;
            }
            String attrName = dattrs[attr].getName();
            String value = request.getParameter("row" + index + "_" + attrName);

            vr.setAttribute(attrName, value);
            if (isEmpty)
            {
               isEmpty = (vr.getAttribute(attrName) == null);
            }
         }

         if (!isEmpty)
         {
            vc.addElement(vr);
         }
      }

      vo.applyViewCriteria(vc);
   }

}