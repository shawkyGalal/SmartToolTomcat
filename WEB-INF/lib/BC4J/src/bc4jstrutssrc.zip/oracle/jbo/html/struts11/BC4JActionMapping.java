/*
 * @(#)BC4JActionMapping.java
 *
 * Copyright 2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.html.struts11;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.ActionMapping;

import oracle.jbo.common.ampool.SessionCookie;
import oracle.jbo.http.HttpContainer;
import oracle.jbo.ViewObject;
import oracle.jbo.ApplicationModule;
import oracle.jbo.html.BC4JContext;
import oracle.jbo.JboException;

/**
 * <p><strong>BC4JActionMapping</strong> is a customization of Struts1.1
 * ActionMapping Javabean. It override several methods to provide
 * integration with the BC4J Model.</p>
 *
 * @since JDeveloper 9.0.3
 */
public class BC4JActionMapping extends ActionMapping
{
   protected String method;
   protected String viewObject;
   protected String releaseMode;
   protected String application;

   public void setEvent(String value)
   {
      this.method = value;
   }

   public String getEvent()
   {
      return method;
   }

   /**
    * The name of the ViewObject usage which will be the default for this action
    */
   public void setViewobject(String value)
   {
      if (value != null)
      {
         this.viewObject = value.trim();
      }
      else
      {
         viewObject = null;
      }
   }

   public String getViewobject()
   {
      return viewObject;
   }

   public void setReleasemode(String value)
   {
      this.releaseMode = value;
   }

   public String getReleasemode()
   {
      return releaseMode;
   }

   /**
    * The name of the Application Model which will be the default for this action
    */
   public void setApplication(String value)
   {
      this.application = value;
   }

   public String getApplication()
   {
      return application;
   }

   public void initializeContext(HttpServletRequest request, HttpServletResponse response, BC4JContext context)
   {
      context.setEvent(getEvent());

      if (getApplication() != null)
      {
         // Try to retrieve am instance from mapping info
         HttpContainer container = HttpContainer.getInstanceFromSession(request.getSession());
         SessionCookie cookie = container.getSessionCookie(getApplication());
         if (cookie == null)
         {
            throw new JboException(Res.format(Res.CANNOT_RETRIEVE_COOKIE, getApplication()));
         }

         context.setSessionCookie(cookie);
      }
      
      if (getViewobject() != null)
      {
         ApplicationModule amInstance = context.getApplicationModule();
         ViewObject vo = amInstance.findViewObject(getViewobject());
         if (vo == null)
         {
            //$$$ Need to throw exception here
            //throw new JboException(Res.format(Res.DATASOURCE_CANT_FIND_VO, voName, amInstance.getName()));
         }
         
         context.setViewObject(vo);
      }
   }
}