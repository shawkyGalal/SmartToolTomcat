/*
 * @(#)UpdateAction.java
 *
 * Copyright 2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.html.struts11.actions;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import oracle.jbo.ApplicationModule;
import oracle.jbo.AttrValException;
import oracle.jbo.AttributeDef;
import oracle.jbo.DMLException;
import oracle.jbo.JboException;
import oracle.jbo.LocaleContext;
import oracle.jbo.Row;
import oracle.jbo.RowNotFoundException;
import oracle.jbo.ViewObject;
import oracle.jbo.common.TransPostControl;
import oracle.jbo.html.BC4JContext;
import oracle.jbo.html.HtmlServices;
import oracle.jbo.html.struts11.BC4JUtils;
import oracle.jbo.html.struts11.MultipartUtil;

import oracle.jdeveloper.html.HTMLElement;

import org.apache.commons.beanutils.PropertyUtils;
import org.apache.struts.action.Action;
import org.apache.struts.action.ActionError;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.upload.FormFile;

/**
 * <p><strong>UpdateAction</strong>
 * </p>
 *
 * @since JDeveloper 9.0.3
 */
public class UpdateAction extends Action
{
   public ActionForward execute( ActionMapping mapping,
                                 ActionForm form,
                                 HttpServletRequest request,
                                 HttpServletResponse response)
   {
      if (!isCancelled(request))
      {
         final BC4JContext context = BC4JContext.getContext(request);
         Row row;

         if (isCreate(request, context)) // case of an "update" following a "create"
         {
            row = context.getViewObject().createRow();
            context.setRow(row);
         }
         else
         {
            row = context.getRow();
         }

         if (row != null)
         {
            ActionErrors errors = validate(request, context, form, row);
            
            if (errors != null && !errors.isEmpty())
            {
               saveErrors(request, errors);               
               return mapping.getInputForward();
            }
         }
      }
      
      return BC4JUtils.getForwardFromContext(request, mapping);
   }

   /**
    * Kept for backward compatibility.
    * isCreate with the request should be the method to override
    */
   protected boolean isCreate(BC4JContext context)
   {
      return (context.getRowkey() == null);
   }
   
   protected boolean isCreate(HttpServletRequest request, BC4JContext context)
   {
      return isCreate(context);
   }
   
   protected ActionErrors validate(HttpServletRequest request, BC4JContext context, ActionForm form, Row row)
   {
      ActionErrors errors = null;      
      
      ApplicationModule am = context.getApplicationModule();
      if (am != null)
      {
         // Set the bundle exception mode to collect all the validation errors at once.
         am.getTransaction().setBundledExceptionMode(true);      
      }

      try
      {
         populateRow(context, form, row);
         
         row.validate();

         if (isCreate(request, context))
         {
            // Insert the row at the beginning of the current range
            // to make it immediately visible.
            context.getViewObject().insertRowAtRangeIndex(0, row); 
         }
      }
      catch (JboException ex)
      {
         // Called method to build list of ActionError from exception tree
         errors = buildErrorsFromException(request, ex);


         // Create case. If a row has been created and the validation failed,
         // we need to remove this row because a new one will be created on the
         // next try.
         if (isCreate(request, context))
         {
            row.remove();
         }

      }

      return errors;
   }

   public void populateRow(BC4JContext context, ActionForm form, Row row)
   {
      final AttributeDef attr[] = context.getViewObject().getAttributeDefs();
      final LocaleContext localeContext = context.getApplicationModule().getSession().getLocaleContext();

      Map properties;
      
      try
      {
         properties = PropertyUtils.describe(form);
      }
      catch (JboException e)
      {
         throw e;
      }
      catch (Exception e)
      {
         throw new JboException(e);
      }
      
      for (int i=0; i < attr.length; i++)
      {
         if (!row.isAttributeUpdateable(i))
         {
            continue;
         }
         
         Object value = properties.get(attr[i].getName());
         if (value == null)
         {
            continue;
         }
         
         Object objVal = null;
         
         if (HtmlServices.isOrdDomainType(attr[i]))
         {
            try
            {
               objVal = MultipartUtil.getOrdObject(attr[i], (FormFile)value, row, context.getApplicationModule());
            }
            catch(Exception e)
            {}

            if (objVal != null)
            {
               row.setAttribute(i, objVal);
            }
         }
         else
         {
            objVal = attr[i].getUIHelper().parseFormattedAttribute((String)value, localeContext);
            row.setAttribute(i, objVal);
         }
      }
   }

   /**
    * Recursive method adding a new error for each level of the tree of exception
    */
   protected void addError(BC4JContext context, int num, int lev, ActionErrors errors, Exception ex)
   {
      String property = ActionErrors.GLOBAL_ERROR;

      if (ex instanceof AttrValException)
      {
         // In the case of AttrValException, use the attribute name
         // as the error property name to map the error to the
         // particular input field on the corresponding form.
         AttrValException ave = (AttrValException) ex;
         property = ave.getAttrName();
      }
      else if (ex instanceof DMLException)
      {
         try
         {
            DMLException dmle = (DMLException) ex;
            ((TransPostControl) context.getApplicationModule()).transPostRevert(dmle.getEntityRowHandle());
         }
         catch (RowNotFoundException rnfe)
         {
            //$$$ Dump to servlet log
            return;
         }
      
      }
      else if (ex instanceof JboException)
      {
         JboException jboex = (JboException) ex;
      }
      else
      {
         // Not a JboException, add the error message and return
         errors.add(ActionErrors.GLOBAL_ERROR, new ActionError("error.Validate0", HTMLElement.quote(ex.getMessage())));
         return;
      }

      errors.add(property, new ActionError("error.Validate" + lev, HTMLElement.quote(ex.getMessage())));
      
      // It is a JboException so recurse into the exception tree
      Object[] nextLevDetails = ((JboException) ex).getDetails();
   
      if (nextLevDetails != null)
      {
         for (int j = 0; j < nextLevDetails.length; j++)
         {
            addError(context, j, lev + 1, errors, (Exception) nextLevDetails[j]);
         }
      }
   }

   /**
    * Generic error handling method producing an "indented" error list representing
    * the tree of exceptions inside a JboException.
    *
    * Overwrite this method to customize the error reporting.
    */
   public ActionErrors buildErrorsFromException(
                           HttpServletRequest request,
                           Exception ex)
   {
      ActionErrors errors = new ActionErrors();
      BC4JContext context = BC4JContext.getContext(request);

      if (ex instanceof JboException)
      {
         // Tell the JboException which ViewObject name should be used to display
         // error coming from the entity level.
         ((JboException)ex).doEntityToVOMapping(context.getApplicationModule(), new ViewObject[] { context.getViewObject() });
      }

      addError(context, 0, 0, errors, ex);

      return errors;
   }
  

}
