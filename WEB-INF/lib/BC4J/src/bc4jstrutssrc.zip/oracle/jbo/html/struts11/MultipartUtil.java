/*
 * @(#)MultipartUtil.java
 *
 * Copyright 2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */
package oracle.jbo.html.struts11;

import java.io.InputStream;

import java.util.Enumeration;
import java.util.HashMap;
import java.util.Hashtable;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;

import oracle.jbo.ApplicationModule;
import oracle.jbo.AttributeDef;
import oracle.jbo.JboException;
import oracle.jbo.Row;
import oracle.jbo.common.JboEnvUtil;
import oracle.jbo.html.HtmlServices;

import oracle.ord.im.OrdDomainIOInterface;
import oracle.ord.im.OrdDomainUtil;
import oracle.ord.im.OrdFileSource;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.struts.Globals;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionServlet;
import org.apache.struts.action.ActionServletWrapper;
import org.apache.struts.config.ModuleConfig;
import org.apache.struts.upload.FormFile;
import org.apache.struts.upload.MultipartRequestHandler;
import org.apache.struts.upload.MultipartRequestWrapper;
import org.apache.struts.util.RequestUtils;

/**
 * <p><strong>MultipartUtil</strong> contains method helping the handling of multipart request.
 * </p>
 *
 * @since JDeveloper 9.0.3
 */
public class MultipartUtil
{
   /**
    * Commons Logging instance.
    */
   protected static Log log = LogFactory.getLog(MultipartUtil.class);
   
   /**
    * Try to locate a multipart request handler for this request. Look at the
    * the global multipart handler defined in Struts controller. If not 
    * specified, use the default <code>DiskMultipartRequestHandler</code>.
    *
    * @param request The HTTP request for which the multipart handler should
    *                be found.
    * @param servlet The <code>ActionServletWrapper</code> processing the supplied
    *                request.
    *
    * @return the multipart handler to use, or <code>null</code> if none is
    *         found.
    *
    * @exception ServletException if any exception is thrown while attempting
    *                             to locate the multipart handler.
    */

   /*
    * Copied from RequestUtils.getMultipartHandler because the method is private
    */
   static MultipartRequestHandler _getMultipartHandler(HttpServletRequest request)
      throws ServletException
   {

      MultipartRequestHandler multipartHandler = null;
      String multipartClass = (String) request.getAttribute(Globals.MULTIPART_KEY);
      request.removeAttribute(Globals.MULTIPART_KEY);
      
      // Try to initialize the mapping specific request handler
      if (multipartClass != null)
      {
         try
         {
            multipartHandler = (MultipartRequestHandler)
               RequestUtils.applicationInstance(multipartClass);
         }
         catch (ClassNotFoundException cnfe)
         {
            log.error("MultipartRequestHandler class \"" +
                       multipartClass + "\" in mapping class not found, " +
                       "defaulting to global multipart class");
         }
         catch (InstantiationException ie)
         {
            log.error("InstantiaionException when instantiating " +
                      "MultipartRequestHandler \"" + multipartClass + "\", " +
                      "defaulting to global multipart class, exception: " +
                      ie.getMessage());
         }
         catch (IllegalAccessException iae)
         {
            log.error("IllegalAccessException when instantiating " +
                      "MultipartRequestHandler \"" + multipartClass + "\", " +
                      "defaulting to global multipart class, exception: " +
                      iae.getMessage());
         }

         if (multipartHandler != null)
            return multipartHandler;
      }

      ModuleConfig moduleConfig = (ModuleConfig) request.getAttribute(Globals.MODULE_KEY);
      multipartClass = moduleConfig.getControllerConfig().getMultipartClass();

      // Try to initialize the global request handler
      if (multipartClass != null)
      {
         try
         {
            multipartHandler = (MultipartRequestHandler)
               RequestUtils.applicationInstance(multipartClass);
         }
         catch (ClassNotFoundException cnfe)
         {
            throw new ServletException("Cannot find multipart class \"" +
                                       multipartClass + "\"" +
                                       ", exception: " + cnfe.getMessage());
         }
         catch (InstantiationException ie)
         {
            throw new ServletException(
               "InstantiaionException when instantiating " +
               "multipart class \"" + multipartClass +
               "\", exception: " + ie.getMessage());
         }
         catch (IllegalAccessException iae)
         {
            throw new ServletException(
               "IllegalAccessException when instantiating " +
               "multipart class \"" + multipartClass +
               "\", exception: " + iae.getMessage());
         }
         
         if (multipartHandler != null)
            return multipartHandler;
      }

      return multipartHandler;
   }

   /**
    * Populate the properties of the specified JavaBean from the specified
    * HTTP request, based on matching each parameter name (plus an optional
    * prefix and/or suffix) against the corresponding JavaBeans "property
    * setter" methods in the bean's class.  Suitable conversion is done for
    * argument types as described under <code>setProperties()</code>.
    * <p>
    * If you specify a non-null <code>prefix</code> and a non-null
    * <code>suffix</code>, the parameter name must match <strong>both</strong>
    * conditions for its value(s) to be used in populating bean properties.
    * <p>
    * If the request's content type is "multipart/form-data" and the
    * method is "POST", the HttpServletRequest object will be wrapped in
    * a MultipartRequestWrapper object.
    * The parsing of "multipart/form-data" POST request happens in <code>
    * processMultipart</code> method. The parsed results are used in this
    * method.
    *
    * @param bean The JavaBean whose properties are to be set
    * @param prefix The prefix (if any) to be prepend to bean property
    *               names when looking for matching parameters
    * @param suffix The suffix (if any) to be appended to bean property
    *               names when looking for matching parameters
    * @param request The HTTP request whose parameters are to be used
    *                to populate bean properties
    *
    * @exception ServletException if an exception is thrown while setting
    *            property values
    */

   /*
    * Copied from RequestUtils.populate().
    */
   public static void populate(Object bean, String prefix, String suffix,
                               HttpServletRequest request)
      throws ServletException 
   {
      // Build a list of relevant request parameters from this request
      HashMap properties = new HashMap();
      // Iterator of parameter names
      Enumeration names = null;
      // Hashtable for multipart values
      Hashtable multipartElements = null;

      boolean isMultipart = false;

      if (isMultipart = HtmlServices.isMultipartPost(request))
      {
         //
         // The multipartHandler object was set to request scope in 
         // processMultipart() method.
         //
         MultipartRequestHandler multipartHandler = retrieveMultipartHandler(request);

         ((ActionForm) bean).setMultipartRequestHandler(multipartHandler);

         if (multipartHandler != null)
         {
            multipartElements = multipartHandler.getAllElements();
            names = multipartElements.keys();
         }
      }

      if (!isMultipart)
      {
         names = request.getParameterNames();
      }

      while (names.hasMoreElements())
      {
         String name = (String) names.nextElement();
         String stripped = name;
         int subscript = stripped.lastIndexOf("[");
         if (prefix != null)
         {
            if (!stripped.startsWith(prefix))
               continue;
            stripped = stripped.substring(prefix.length());
         }
         if (suffix != null)
         {
            if (!stripped.endsWith(suffix))
               continue;
            stripped =
            stripped.substring(0, stripped.length() - suffix.length());
         }
         if (isMultipart)
         {
            properties.put(stripped, multipartElements.get(name));
         }
         else
         {
            properties.put(stripped, request.getParameterValues(name));
         }
      }

      // Set the corresponding properties of our bean
      try 
      {
         BeanUtils.populate(bean, properties);
      }
      catch (Exception e)
      {
         throw new ServletException("BeanUtils.populate", e);
      }
   }

   /*
    * Parse "multipart/form-data" POST request using MultipartRequestHandler.
    * Set the MultipartRequestHandler in request scope at attribute name defined
    * at Constants.BC4J_MULTIPART_HANDLER_ATTR_NAME.
    */
   public static MultipartRequestWrapper parseMultipartRequest(HttpServletRequest request,
                                                               ActionServlet servlet)
      throws ServletException
   {
      MultipartRequestWrapper requestWrapper = new MultipartRequestWrapper(request);

      // Get the ActionServletWrapper from the form bean
      ActionServletWrapper servletWrapper = new ActionServletWrapper(servlet);

      // Obtain a MultipartRequestHandler
      MultipartRequestHandler multipartHandler =
         MultipartUtil._getMultipartHandler(request);

      if (multipartHandler != null)
      {
         // Set servlet and mapping info
         servletWrapper.setServletFor(multipartHandler);

         // Initialize multipart request class handler
         multipartHandler.handleRequest(request);

         // what if exceeds maximum length? Should a ServletException be thrown?
         // Or go back to the previous page?

         Boolean maxLengthExceeded = (Boolean)
                                     request.getAttribute(MultipartRequestHandler.ATTRIBUTE_MAX_LENGTH_EXCEEDED);

         if ((maxLengthExceeded != null) && (maxLengthExceeded.booleanValue()))
         {
            throw new ServletException("Maximum upload size has been exceeded.");
         }

      }

      setWrapperParams(multipartHandler, requestWrapper);

      _storeMultipartHandler(requestWrapper, multipartHandler);

      return requestWrapper;
   }

   /**
    * Get an interMedia object for the browser uploaded file. 
    */
   public static Object getOrdObject(AttributeDef attrDef, 
                                     FormFile file, 
                                     Row row, 
                                     ApplicationModule am)
   {
      OrdDomainIOInterface obj = null;
      String sName = attrDef.getName();

      String contentType = file.getContentType();
      int size = file.getFileSize();
      String filename = file.getFileName();

      if ((file != null) &&
          (! filename.equals("")) &&
          ( size >= 0 ))
      {
         //
         // When (mFile!=null) && (! mFile.getOriginalFileName().equals(""))
         // && ( mFile.getContentLength() == 0 ), user uploads a valid empty 
         // file. This means nuke out any existing content in the domain.
         //

         //
         // Find the tmp directory to store temp files
         //
         String tmpDir = JboEnvUtil.getBC4JTempDir(am);

         //
         // Make a copy of the browser uploaded content to a temp file. Use this 
         // temp file for database upload and passivation/activation. The browser
         // uploaded content will be released in the <ReleasePageResources> tag.
         // 
         OrdFileSource tempFile = null;

         try
         {
            InputStream inStream = file.getInputStream();
            tempFile = OrdDomainUtil.
                       createTempFile(inStream, contentType, tmpDir);
         
            obj = (OrdDomainIOInterface) HtmlServices.getOrdObject(attrDef, tempFile, row, am, contentType);
         }
         catch (java.io.IOException e)
         {
            throw new JboException(e);
         }
         catch (java.lang.InstantiationException e)
         {
            throw new JboException(e);
         }
         catch (Exception e)
         {
            throw new JboException("Can not create temp file");
         }

      }

      return obj;
   }

   /**
    * Stores the <code>MultipartRequestHandler</code> object to the HttpRequest
    * scope.
    */
   static void _storeMultipartHandler(HttpServletRequest request,
                                      MultipartRequestHandler handler)
   {
      request.setAttribute(Constants.BC4J_MULTIPART_HANDLER_ATTR_NAME, handler);
   }

   /**
    * Retrieves the <code>MultipartRequestHandler</code> object from the
    * HttpRequest scope.
    */
   public static MultipartRequestHandler retrieveMultipartHandler(HttpServletRequest request)
   {
      return (MultipartRequestHandler) request.getAttribute(Constants.BC4J_MULTIPART_HANDLER_ATTR_NAME);
   }

   public static void setWrapperParams(MultipartRequestHandler multipartHandler,
                                       MultipartRequestWrapper requestWrapper)
   {
      // Iterator of parameter names
      Enumeration names = null;
      // Hashtable for multipart values
      Hashtable multipartTextElements = null;

      multipartTextElements = multipartHandler.getTextElements();
      names = multipartTextElements.keys();

      while (names.hasMoreElements())
      {
         String name = (String) names.nextElement();

         String[] textValues = (String[]) multipartTextElements.get(name);

         if (textValues != null)
         {
            for (int i=0; i<textValues.length; i++)
            {
               requestWrapper.setParameter(name, textValues[i]);
            }
         }
      }
   }
}
