#!/bin/env bash
PROFILE="$HOME/.profile"
case Linux in
  Linux)  PROFILE="$HOME/.bash_profile"  ;;
  CYGWIN_NT-[0-9].[0-9]) PROFILE="$HOME/.bash_profile" ;;
esac
if [ -e "$PROFILE" ]; then . $PROFILE>/dev/null 2>&1;fi
export ORACLE_HOME=/u01/app/oracle/product/11.2.0.4/dbhome_1
export ORACLE_SID=PROD
export CRS_HOME=/u01/app/12.1.0.2/grid
export OUTPUTDIR=/root/orachk_042716_133102
export TMPDIR=/tmp
export RTEMPDIR=/tmp/.orachk
export TMP_OUTPUT=/tmp/.orachk
set +u
if [[ "${LD_LIBRARY_PATH:-unset}"  = "unset" ]] ; then LD_LIBRARY_PATH=""; fi
LD_LIBRARY_PATH=${LD_LIBRARY_PATH}:/u01/app/oracle/product/11.2.0.4/dbhome_1/lib
export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:/u01/app/oracle/product/11.2.0.4/dbhome_1/lib:/u01/app/12.1.0.2/grid/lib
export OUTPUTDIR=/tmp/.orachk/orachk_042716_133102

#!/bin/env bash

if [ -e "/etc/profile" ] ; then . /etc/profile >/dev/null 2>&1; fi; if [ -e "$HOME/.bash_profile" ] ; then . $HOME/.bash_profile >/dev/null 2>&1; elif [ -e "$HOME/.bash_login" ] ; then . $HOME/.bash_login >/dev/null 2>&1; elif [ -e "$HOME/.profile" ] ; then . $HOME/.profile >/dev/null 2>&1; fi

status=0
MASTERENVFILE=$OUTPUTDIR/raccheck_env.out
total_mem="$(cat /proc/meminfo |grep MemTotal |awk '{print $2 * 1024}')"
total_huge_pages=$(grep -w HugePages_Total: /proc/meminfo| awk '{print $2}')
huge_page_size=$(grep -w Hugepagesize /proc/meminfo| awk '{print $2 * 1024}')
total_huge_pages_memory=$(echo "$total_huge_pages $huge_page_size"|awk '{print $1 * $2}')
non_huge_page_memory=$(echo "$total_mem $total_huge_pages_memory"|awk '{print $1 - $2}')
total_pga_memory=0
for param_file in $(ls -l $OUTPUTDIR/*_v_parameter_*|grep -v v_parameter_u|awk '{print $NF}')
do
   #echo $param_file
   asm_instance_file=$(echo $param_file|grep -ic asm)
   pga_aggregate_limit_found=$(egrep -wc pga_aggregate_limit $param_file)
   param_db_name=$(egrep -wi db_name $param_file|awk '{print $NF}'|uniq)
   #echo $param_db_name
   env_has_map=$(grep -iwc map $MASTERENVFILE)
   if [ $env_has_map -gt 0 ]
   then
      inst_host_name=$(egrep -wi MAP $MASTERENVFILE|grep $(hostname -s)|tail -1|cut -d= -f1|cut -d: -f2|tr -d ' ')
   else
      inst_host_name=$(hostname -s)
   fi
   inst_grep_expr=$(echo $inst_host_name.$param_db_name.INSTANCE_NAME)
   if [ $asm_instance_file -gt 0 ]
   then
       param_inst_name=$(ps -ef|grep asm_pmon|grep -v grep |awk '{print $NF}'|cut -d_ -f3)
   else
       param_inst_name=$(egrep -wi "$inst_grep_expr" $MASTERENVFILE|awk '{print $NF'})
   fi
   if [ -n "$param_inst_name" ]
   then
       if [ $pga_aggregate_limit_found -gt 0 ]
       then
           pga_size=$(egrep -w "$param_inst_name.pga_aggregate_limit" $param_file|awk '{print $NF}'|uniq)
       else
           pga_size=$(egrep -w "$param_inst_name.pga_aggregate_target" $param_file|awk '{print $NF}'|uniq)
           if [ -n "$pga_size" ]; then pga_size=$(echo "$pga_size * 3"|bc);fi
       fi
   fi
   #echo $pga_size
if [[ -n "$pga_size" && $pga_size -gt 0 ]]; then total_pga_memory=$(perl -e "printf \"%.0f\", $total_pga_memory+$pga_size");fi
#read -p "stop"
done
#echo $total_pga_memory
if [ $non_huge_page_memory -le $total_pga_memory ];then status=1;fi
echo $status 
total_mem=$(echo "$total_mem/1024/1024"|bc)
total_huge_pages_memory=$(echo "$total_huge_pages_memory/1024/1024"|bc)
non_huge_page_memory=$(echo "$non_huge_page_memory/1024/1024"|bc)
total_pga_memory=$(echo "$total_pga_memory/1024/1024"|bc)
echo -e "Total memory on $(hostname) = $total_mem MB\nTotal memory allocated to hugepages = $total_huge_pages_memory MB\nTotal available memory for PGA allocation = $non_huge_page_memory MB\nMemory allocated to all PGAs = $total_pga_memory MB\n\n" 
if [ -n "$ALVL" ]; then echo "ALVL=$ALVL" > /tmp/.orachk/.localcmd.val; fi
if [ -n "$rat_exitcode" ]; then exit $rat_exitcode; else exit 0;fi
