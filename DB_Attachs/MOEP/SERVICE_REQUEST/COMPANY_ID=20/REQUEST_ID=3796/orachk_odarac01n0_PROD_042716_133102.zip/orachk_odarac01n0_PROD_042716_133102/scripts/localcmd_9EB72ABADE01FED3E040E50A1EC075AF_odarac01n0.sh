#!/bin/env bash
PROFILE="$HOME/.profile"
case Linux in
  Linux)  PROFILE="$HOME/.bash_profile"  ;;
  CYGWIN_NT-[0-9].[0-9]) PROFILE="$HOME/.bash_profile" ;;
esac
if [ -e "$PROFILE" ]; then . $PROFILE>/dev/null 2>&1;fi
export CRS_HOME=/u01/app/12.1.0.2/grid
export OUTPUTDIR=/root/orachk_042716_133102
export TMPDIR=/tmp
export RTEMPDIR=/tmp/.orachk
export TMP_OUTPUT=/tmp/.orachk
set +u
export ORACLE_SID=PROD
export ORACLE_HOME=/u01/app/oracle/product/11.2.0.4/dbhome_1
if [[ "${LD_LIBRARY_PATH:-unset}"  = "unset" ]] ; then LD_LIBRARY_PATH=""; fi
LD_LIBRARY_PATH=/u01/app/12.1.0.2/grid/lib:/u01/app/oracle/product/11.2.0.4/dbhome_1/lib:${LD_LIBRARY_PATH}:/u01/app/oracle/product/11.2.0.4/dbhome_1/lib
export LD_LIBRARY_PATH=/u01/app/12.1.0.2/grid/lib:/u01/app/oracle/product/11.2.0.4/dbhome_1/lib:${LD_LIBRARY_PATH}:/u01/app/oracle/product/11.2.0.4/dbhome_1/lib

#!/bin/env bash

if [ -e "/etc/profile" ] ; then . /etc/profile >/dev/null 2>&1; fi; if [ -e "$HOME/.bash_profile" ] ; then . $HOME/.bash_profile >/dev/null 2>&1; elif [ -e "$HOME/.bash_login" ] ; then . $HOME/.bash_login >/dev/null 2>&1; elif [ -e "$HOME/.profile" ] ; then . $HOME/.profile >/dev/null 2>&1; fi

user=`ls -l $CRS_HOME/bin/oracle |awk '{print $3}'`;lim=`grep -w $user /etc/security/limits.conf |grep soft |grep nproc|grep -v ^# |awk '{print $4}'`;if [ -z "$lim" ]; then group=$(ls -l $CRS_HOME/bin/oracle |awk '{print $4}');lim=`grep -w $group /etc/security/limits.conf |grep soft |grep nproc|grep -v ^# |awk '{print $4}'`;fi;if [ -z "$lim" ]; then lim=`grep '\* soft nproc' /etc/security/limits.conf |grep -v ^#|awk '{print $4}'`;if [ -z "$lim" ]; then lim=0;fi;elif [ $lim = unlimited ];then lim=999999;fi;echo $lim 
 cat /etc/security/limits.conf|grep -v '#' 
if [ -n "$ALVL" ]; then echo "ALVL=$ALVL" > /tmp/.orachk/.localcmd.val; fi
if [ -n "$rat_exitcode" ]; then exit $rat_exitcode; else exit 0;fi
