#!/bin/env bash
PROFILE="$HOME/.profile"
case Linux in
  Linux)  PROFILE="$HOME/.bash_profile"  ;;
  CYGWIN_NT-[0-9].[0-9]) PROFILE="$HOME/.bash_profile" ;;
esac
if [ -e "$PROFILE" ]; then . $PROFILE>/dev/null 2>&1;fi
export CRS_HOME=/u01/app/12.1.0.2/grid
export OUTPUTDIR=/root/orachk_042716_133102
export TMPDIR=/tmp
export RTEMPDIR=/tmp/.orachk
export TMP_OUTPUT=/tmp/.orachk
set +u
export OUTPUTDIR=/tmp/.orachk/orachk_042716_133102
export ORACLE_SID=+ASM2
export ORACLE_HOME=/u01/app/12.1.0.2/grid
if [[ "${LD_LIBRARY_PATH:-unset}"  = "unset" ]] ; then LD_LIBRARY_PATH=""; fi
LD_LIBRARY_PATH=/u01/app/12.1.0.2/grid/lib:${LD_LIBRARY_PATH}:/u01/app/oracle/product/11.2.0.4/dbhome_1/lib
export LD_LIBRARY_PATH=/u01/app/12.1.0.2/grid/lib:${LD_LIBRARY_PATH}:/u01/app/oracle/product/11.2.0.4/dbhome_1/lib

#!/bin/env bash

if [ -e "/etc/profile" ] ; then . /etc/profile >/dev/null 2>&1; fi; if [ -e "$HOME/.bash_profile" ] ; then . $HOME/.bash_profile >/dev/null 2>&1; elif [ -e "$HOME/.bash_login" ] ; then . $HOME/.bash_login >/dev/null 2>&1; elif [ -e "$HOME/.profile" ] ; then . $HOME/.profile >/dev/null 2>&1; fi

afdest=$(echo -e "set heading off timing off feedback off lines 180\n select value from v\$parameter where name='audit_file_dest';"|$ORACLE_HOME/bin/sqlplus -s / as sysdba|grep -v ^$)
aud_files=$(find $afdest -name '*.*' 2>/dev/null|wc -l)
if [ $aud_files -gt 100000 ]
then
      echo 1 
else
      echo 0
fi 
echo -e "Number of audit files at $afdest = $aud_files" 
if [ -n "$ALVL" ]; then echo "ALVL=$ALVL" > /tmp/.orachk/.localcmd.val; fi
if [ -n "$rat_exitcode" ]; then exit $rat_exitcode; else exit 0;fi
