#!/bin/env bash
if [ -e "/etc/profile" ] ; then . /etc/profile >/dev/null 2>&1; fi; if [ -e "$HOME/.bash_profile" ] ; then . $HOME/.bash_profile >/dev/null 2>&1; elif [ -e "$HOME/.bash_login" ] ; then . $HOME/.bash_login >/dev/null 2>&1; elif [ -e "$HOME/.profile" ] ; then . $HOME/.profile >/dev/null 2>&1; fi

if [ -e /root/.bash_profile ]; then . /root/.bash_profile>/dev/null 2>&1;fi
export ORACLE_HOME=/u01/app/oracle/product/11.2.0.4/dbhome_1
export CRS_HOME=/u01/app/12.1.0.2/grid
export TMPDIR=/tmp
export RTEMPDIR=/tmp/.orachk
export ORACLE_SID=
echo -e "\n\n`date '+%a %b %d %H:%M:%S %Y'` - STARTED ON  `hostname|cut -d. -f1`\n" 
echo -e "TO REVIEW COLLECTED DATA FROM ODARAC01N1 FOR CRS USER LIMITS CONFIGURATION \n\n\n" 
echo "Collecting - CRS user limits configuration "
echo -e "`date '+%a %b %d %H:%M:%S %Y'` - CRS user limits configuration on `hostname|cut -d. -f1`" 
occsd_pid=$(ps -ef |grep "ocssd.bin"|grep -v grep|awk '{print $2}');hslimit=$(cat /proc/${occsd_pid}/limits |grep "Max stack size"|awk '{print $5}');if [[ "$hslimit" = "unlimited" || $hslimit -gt 10240 ]]; then echo "crs_user_hslimit = 0";else echo "crs_user_hslimit = 1";fi                
occsd_pid=$(ps -ef |grep "ocssd.bin"|grep -v grep|awk '{print $2}');cat /proc/${occsd_pid}/limits 
echo -e "TO REVIEW COLLECTED DATA FROM ODARAC01N1 FOR FIRMWARE AND SOFTWARE VERSIONS \n\n\n" 
echo "Collecting - Firmware and software versions "
echo -e "`date '+%a %b %d %H:%M:%S %Y'` - Firmware and software versions on `hostname|cut -d. -f1`" 
oak_version=$(/opt/oracle/oak/bin/oakcli show version|tail -1|tr -d '.')   
if [ $oak_version -eq 21000 ]   
then    
    command_output=$(/opt/oracle/oak/pkgrepos/System/2.1.0.0.0/bin/oakpatch -d -v)   
    final_status=$(echo "oak_firmware_software_status = $(echo "$command_output"|egrep -ic 'WARNING|FAIL')")   
else    
     command_output1=$(/opt/oracle/oak/bin/oakcli show version -detail)   
     command_output2=$(/opt/oracle/oak/bin/oakcli show dbhomes -detail)  
     command_output=$(echo -e "$command_output1 \n $command_output2")   
     final_status=$(echo "oak_firmware_software_status = $(echo "$command_output1"|tail -n +5|egrep -vi 'GI_HOME|DB_HOME|Up-to-date|11.2.0'|awk '$4 != $5 {print $4 " " $5}'|wc -l)")   
fi   
echo "$final_status"  
echo "$command_output" 
echo -e "TO REVIEW COLLECTED DATA FROM ODARAC01N1 FOR SYSTEM COMPONENT STATUS \n\n\n" 
echo "Collecting - System Component Status "
echo -e "`date '+%a %b %d %H:%M:%S %Y'` - System Component Status on `hostname|cut -d. -f1`" 
unset command_output  
/opt/oracle/oak/bin/oakcli validate -c SystemComponents -f  $TMPDIR/o_exadata_disk.out   
command_output=$(cat  $TMPDIR/o_exadata_disk.out)  
echo "validate_system_component = $(echo "$command_output"|egrep -c  'ERROR|WARNING')"  
echo "$command_output" 
echo -e "TO REVIEW COLLECTED DATA FROM ODARAC01N1 FOR VALIDATE SHARED STORAGE \n\n\n" 
echo "Collecting - Validate Shared storage "
echo -e "`date '+%a %b %d %H:%M:%S %Y'` - Validate Shared storage on `hostname|cut -d. -f1`" 
unset command_output  
/opt/oracle/oak/bin/oakcli validate -c SharedStorage -f  $TMPDIR/o_exadata_disk.out   
command_output=$(cat  $TMPDIR/o_exadata_disk.out)  
echo "validate_shared_storage = $(echo "$command_output"|egrep -c  'ERROR|WARNING')"  
echo "$command_output" 
