#!/bin/env bash
PROFILE="$HOME/.profile"
case Linux in
  Linux)  PROFILE="$HOME/.bash_profile"  ;;
  CYGWIN_NT-[0-9].[0-9]) PROFILE="$HOME/.bash_profile" ;;
esac
if [ -e "$PROFILE" ]; then . $PROFILE>/dev/null 2>&1;fi
export CRS_HOME=/u01/app/12.1.0.2/grid
export OUTPUTDIR=/root/orachk_101716_094824
export TMPDIR=/tmp
export RTEMPDIR=/tmp/.orachk
export TMP_OUTPUT=/tmp/.orachk
set +u
export ORACLE_SID=
export ORACLE_HOME=/u01/app/oracle/product/11.2.0.4/dbhome_1
if [[ "${LD_LIBRARY_PATH:-unset}"  = "unset" ]] ; then LD_LIBRARY_PATH=""; fi
LD_LIBRARY_PATH=/u01/app/12.1.0.2/grid/lib:${LD_LIBRARY_PATH}:/u01/app/oracle/product/11.2.0.4/dbhome_1/lib
export LD_LIBRARY_PATH=/u01/app/12.1.0.2/grid/lib:${LD_LIBRARY_PATH}:/u01/app/oracle/product/11.2.0.4/dbhome_1/lib

#!/bin/env bash

if [ -e "/etc/profile" ] ; then . /etc/profile >/dev/null 2>&1; fi; if [ -e "$HOME/.bash_profile" ] ; then . $HOME/.bash_profile >/dev/null 2>&1; elif [ -e "$HOME/.bash_login" ] ; then . $HOME/.bash_login >/dev/null 2>&1; elif [ -e "$HOME/.profile" ] ; then . $HOME/.profile >/dev/null 2>&1; fi

if [ -e $TMPDIR/o_root_clusterwide_check_root_time_zone.out ]; then cat $TMPDIR/o_root_clusterwide_check_root_time_zone.out 2> /dev/null;rm $TMPDIR/o_root_clusterwide_check_root_time_zone.out>/dev/null 2>&1;fi 
if [ -e $TMPDIR/o_root_clusterwide_check_root_time_zone_report.out ]; then cat $TMPDIR/o_root_clusterwide_check_root_time_zone_report.out 2> /dev/null;rm $TMPDIR/o_root_clusterwide_check_root_time_zone_report.out>/dev/null 2>&1;fi 
echo -e "\n\n" 
if [ -n "$ALVL" ]; then echo "ALVL=$ALVL" > /tmp/.orachk/.localcmd.val; fi
exit 0
